"""Package for testing Python relationship extraction."""

# This file makes the directory a Python package