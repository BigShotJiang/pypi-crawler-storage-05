"""
Configuration module initialization.
"""

from .settings import config

__all__ = ["config"]
