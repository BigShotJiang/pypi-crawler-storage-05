This module is an add-on for the Fleet application in Odoo. It allows you to track your Fleet Vehicles in stock moves.
