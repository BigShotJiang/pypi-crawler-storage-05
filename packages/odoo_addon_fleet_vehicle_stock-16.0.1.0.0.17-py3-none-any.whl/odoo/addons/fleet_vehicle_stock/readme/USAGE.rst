A completed stock move for a properly configured Product on a configured
stock Operation Type will automatically create a fleet vehicle.
