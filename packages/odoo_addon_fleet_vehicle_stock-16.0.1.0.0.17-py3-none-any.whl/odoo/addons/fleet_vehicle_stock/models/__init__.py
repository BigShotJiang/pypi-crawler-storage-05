from . import fleet_vehicle_model
from . import fleet_vehicle
from . import product_template
from . import stock_picking_type
from . import stock_production_lot
from . import stock_move
from . import product_product
