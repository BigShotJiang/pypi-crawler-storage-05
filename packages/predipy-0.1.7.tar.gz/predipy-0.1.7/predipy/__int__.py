from .predipy import (
    mse,
    akurasi,
    RegresiLinier,
    RegresiLogistik,
    MLP
)

from . import preprocess  # ← ini penting!
	
