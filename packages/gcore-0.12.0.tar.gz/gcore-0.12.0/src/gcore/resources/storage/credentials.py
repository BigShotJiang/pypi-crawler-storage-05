# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import NOT_GIVEN, Body, Query, Headers, NotGiven
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.storage import credential_recreate_params
from ...types.storage.storage import Storage

__all__ = ["CredentialsResource", "AsyncCredentialsResource"]


class CredentialsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CredentialsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/G-Core/gcore-python#accessing-raw-response-data-eg-headers
        """
        return CredentialsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CredentialsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/G-Core/gcore-python#with_streaming_response
        """
        return CredentialsResourceWithStreamingResponse(self)

    def recreate(
        self,
        storage_id: int,
        *,
        delete_sftp_password: bool | NotGiven = NOT_GIVEN,
        generate_s3_keys: bool | NotGiven = NOT_GIVEN,
        generate_sftp_password: bool | NotGiven = NOT_GIVEN,
        reset_sftp_keys: bool | NotGiven = NOT_GIVEN,
        sftp_password: str | NotGiven = NOT_GIVEN,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> Storage:
        """
        Generates new access credentials for the storage (S3 keys for S3 storage, SFTP
        password for SFTP storage).

        Args:
          delete_sftp_password: Remove the SFTP password, disabling password authentication. Only applicable to
              SFTP storage type.

          generate_s3_keys: Generate new S3 access and secret keys for S3 storage. Only applicable to S3
              storage type.

          generate_sftp_password: Generate a new random password for SFTP access. Only applicable to SFTP storage
              type.

          reset_sftp_keys: Reset/remove all SSH keys associated with the SFTP storage. Only applicable to
              SFTP storage type.

          sftp_password: Set a custom password for SFTP access. Only applicable to SFTP storage type.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            f"/storage/provisioning/v1/storage/{storage_id}/credentials",
            body=maybe_transform(
                {
                    "delete_sftp_password": delete_sftp_password,
                    "generate_s3_keys": generate_s3_keys,
                    "generate_sftp_password": generate_sftp_password,
                    "reset_sftp_keys": reset_sftp_keys,
                    "sftp_password": sftp_password,
                },
                credential_recreate_params.CredentialRecreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Storage,
        )


class AsyncCredentialsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCredentialsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/G-Core/gcore-python#accessing-raw-response-data-eg-headers
        """
        return AsyncCredentialsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCredentialsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/G-Core/gcore-python#with_streaming_response
        """
        return AsyncCredentialsResourceWithStreamingResponse(self)

    async def recreate(
        self,
        storage_id: int,
        *,
        delete_sftp_password: bool | NotGiven = NOT_GIVEN,
        generate_s3_keys: bool | NotGiven = NOT_GIVEN,
        generate_sftp_password: bool | NotGiven = NOT_GIVEN,
        reset_sftp_keys: bool | NotGiven = NOT_GIVEN,
        sftp_password: str | NotGiven = NOT_GIVEN,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> Storage:
        """
        Generates new access credentials for the storage (S3 keys for S3 storage, SFTP
        password for SFTP storage).

        Args:
          delete_sftp_password: Remove the SFTP password, disabling password authentication. Only applicable to
              SFTP storage type.

          generate_s3_keys: Generate new S3 access and secret keys for S3 storage. Only applicable to S3
              storage type.

          generate_sftp_password: Generate a new random password for SFTP access. Only applicable to SFTP storage
              type.

          reset_sftp_keys: Reset/remove all SSH keys associated with the SFTP storage. Only applicable to
              SFTP storage type.

          sftp_password: Set a custom password for SFTP access. Only applicable to SFTP storage type.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            f"/storage/provisioning/v1/storage/{storage_id}/credentials",
            body=await async_maybe_transform(
                {
                    "delete_sftp_password": delete_sftp_password,
                    "generate_s3_keys": generate_s3_keys,
                    "generate_sftp_password": generate_sftp_password,
                    "reset_sftp_keys": reset_sftp_keys,
                    "sftp_password": sftp_password,
                },
                credential_recreate_params.CredentialRecreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Storage,
        )


class CredentialsResourceWithRawResponse:
    def __init__(self, credentials: CredentialsResource) -> None:
        self._credentials = credentials

        self.recreate = to_raw_response_wrapper(
            credentials.recreate,
        )


class AsyncCredentialsResourceWithRawResponse:
    def __init__(self, credentials: AsyncCredentialsResource) -> None:
        self._credentials = credentials

        self.recreate = async_to_raw_response_wrapper(
            credentials.recreate,
        )


class CredentialsResourceWithStreamingResponse:
    def __init__(self, credentials: CredentialsResource) -> None:
        self._credentials = credentials

        self.recreate = to_streamed_response_wrapper(
            credentials.recreate,
        )


class AsyncCredentialsResourceWithStreamingResponse:
    def __init__(self, credentials: AsyncCredentialsResource) -> None:
        self._credentials = credentials

        self.recreate = async_to_streamed_response_wrapper(
            credentials.recreate,
        )
