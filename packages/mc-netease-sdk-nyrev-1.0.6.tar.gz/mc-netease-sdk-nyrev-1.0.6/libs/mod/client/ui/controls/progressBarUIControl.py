# -*- coding: utf-8 -*-

from mod.client.ui.controls.baseUIControl import BaseUIControl

class ProgressBarUIControl(BaseUIControl):
    def SetValue(self, progress):
        # type: (float) -> 'None'
        """
        设置进度条的进度
        """
        pass

