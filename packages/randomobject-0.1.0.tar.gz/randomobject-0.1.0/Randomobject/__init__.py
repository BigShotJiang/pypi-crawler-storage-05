from .core import RandomObject
