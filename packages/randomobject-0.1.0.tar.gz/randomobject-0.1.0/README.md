# Randomobject

کتابخونه‌ای ساده برای انتخاب رندومی از بین آبجکت‌ها یا متن‌ها.

## نصب
```bash
pip install Randomobject
```

## استفاده
```python
from Randomobject import RandomObject

r = RandomObject("سلام", "خوبی؟", "چه خبر؟")
print(r.get())
```
