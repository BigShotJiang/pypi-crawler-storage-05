# __main__.py

from mcp_server_windbg import main

main()