"""
Brasil API MCP - Ferramenta de consulta de dados do Brasil API
"""

__version__ = "0.1.0"
__author__ = "Lucian Fialho"