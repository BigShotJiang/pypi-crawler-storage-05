URL_ENDPOINT = "https://ik.imagekit.io/your_imagekit_id/endpoint/"
BASIC_GENERATED_URL = (
    "https://ik.imagekit.io/your_imagekit_id/endpoint/tr:h-300,w-400/default-image.jpg",
)
