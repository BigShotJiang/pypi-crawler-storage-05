from enum import Enum


class CustomMetaDataTypeEnum(Enum):
    Text = 1
    Textarea = 2
    Number = 3
    Date = 4
    Boolean = 5
    SingleSelect = 6
    MultiSelect = 7
