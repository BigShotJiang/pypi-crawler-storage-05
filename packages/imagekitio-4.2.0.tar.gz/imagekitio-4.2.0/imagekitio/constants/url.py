class URL:
    API_BASE_URL = "https://api.imagekit.io"
    UPLOAD_BASE_URL = "https://upload.imagekit.io"
    BULK_FILE_DELETE = "/batch/deleteByFileIds"
