# h5py-stubs
Type stubs for H5py
