"""Storage types module."""
