"""Local storage module."""

# TODO deprecation warning (when most of future is implemented)
from ..future.types.fs import FSStorage  # noqa
