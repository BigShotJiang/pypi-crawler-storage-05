"""Storage errors."""

# TODO replace when .future is promoted to top level

from .future.errors import *  # noqa
