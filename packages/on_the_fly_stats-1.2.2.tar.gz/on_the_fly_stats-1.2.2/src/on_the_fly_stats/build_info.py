class BuildInfo:  # pylint: disable=too-few-public-methods
    python_version = '3.12.3'
    os_name = 'posix:ubuntu'
    version = '1.2.2'
    git_sha = 'b8a77646e0fa6eef5f0707d7224504a5d51c42ee'
    git_branch = 'master'
    git_uncommitted = [
    ]
    git_unpushed = [
    ]
