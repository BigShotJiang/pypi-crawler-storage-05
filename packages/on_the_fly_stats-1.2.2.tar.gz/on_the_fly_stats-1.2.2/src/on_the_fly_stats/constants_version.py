from dataclasses import dataclass


# --------------------
## holds constants
@dataclass
class ConstantsVersion:
    ## current App version
    version = '1.2.2'
