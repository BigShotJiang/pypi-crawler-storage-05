# Pygeist
Pygeist is a Python module that abstracts the application protocol `Zeitgeist`.

## Protocol
See [here](https://github.com/mateogall0/zeitgeist_core) to look into the core implementation of the protocol.
