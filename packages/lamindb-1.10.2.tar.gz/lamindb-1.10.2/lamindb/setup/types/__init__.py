import lamindb_setup as _lamindb_setup
from lamindb_setup.types import *  # noqa: F403

__doc__ = _lamindb_setup.types.__doc__.replace("lamindb_setup", "lamindb.setup")
