import lamindb as ln


def test_vew():
    ln.view(modules="core")
    ln.view()
