# Query & search

```{toctree}
:maxdepth: 1

registries
arrays
```
