# Guide

```{toctree}
:hidden:
:caption: "How to"

query-search
track
curate
bio-registries
transfer
```

```{toctree}
:hidden:
:caption: Other topics

faq
storage
```
