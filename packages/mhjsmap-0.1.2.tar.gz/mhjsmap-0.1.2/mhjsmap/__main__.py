from .mcpmap import run

def main():
    import asyncio
    asyncio.run(run())
