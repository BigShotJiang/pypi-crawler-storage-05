"""Logging components for FastSQS."""

from .logger import Logger
