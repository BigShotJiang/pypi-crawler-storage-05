"""Concurrency utilities for FastSQS."""

from .concurrency import ThreadPoolManager
from .decorators import background