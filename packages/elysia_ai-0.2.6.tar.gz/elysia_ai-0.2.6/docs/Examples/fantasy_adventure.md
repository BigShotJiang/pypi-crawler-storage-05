# Example: Creating a Fantasy Adventure Game

Coming soon.
<!-- Say we want to use Elysia in a different way to the default setup. So instead of querying and searching data in Weaviate collections, we want Elysia to create and keep track of a fantasy tabletop RPG.  -->





<!-- Let's consider adding the example tool we created in [the tool construction overview](Customising/advanced_tool_construction.md#example-dealing-cards-randomly-from-a-deck-intermediate), which dealt a set of random cards from a possible five. The tool is called `DealCards`.
 -->
