Within the Elysia package, the API endpoints are included but are specific to the [Elysia Frontend](https://github.com/weaviate/elysia-frontend). 

However, there are a range of functionalities included that can be useful for using Elysia in an app environment.