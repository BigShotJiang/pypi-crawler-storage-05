FAASMCTL_VERSION = "0.1.17"


def get_version():
    return FAASMCTL_VERSION
