from pydantic import BaseModel


class AthenaUpdateDataCatalogResponse(BaseModel):
    pass