from pydantic import (
    BaseModel
)


class AthenaCreatePreparedStatementResponse(BaseModel):
    pass