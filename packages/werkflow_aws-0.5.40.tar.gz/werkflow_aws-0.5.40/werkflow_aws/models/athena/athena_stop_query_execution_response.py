from pydantic import BaseModel


class AthenaStopQueryExecutionResponse(BaseModel):
    pass