from typing import Literal


AthenaStatementType = Literal[
    'DDL',
    'DML',
    'UTILITY',
]