from typing import Literal

AthenaDataCatalogType = Literal[
    'LAMBDA',
    'GLUE',
    'HIVE',
    'FEDERATED',
]
