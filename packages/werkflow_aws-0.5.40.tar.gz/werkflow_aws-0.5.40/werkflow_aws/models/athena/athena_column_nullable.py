from typing import Literal


AthenaColumnNullable = Literal[
    "NOT_NULL",
    "NULLABLE",
    "UNKNOWN",
]