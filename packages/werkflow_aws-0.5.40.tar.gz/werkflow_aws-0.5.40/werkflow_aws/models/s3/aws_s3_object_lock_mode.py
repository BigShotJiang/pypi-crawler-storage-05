from typing import Literal

AWSS3ObjectLockMode = Literal[
    'GOVERNANCE',
    'COMPLIANCE'
]