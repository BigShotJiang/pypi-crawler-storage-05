from typing import Literal

AWSS3ObjectLockLegalHoldStatus = Literal[
    'ON',
    'OFF'
]