from typing import Literal


CloudWatchLabelOptions = dict[
    Literal["Timezone"],
    str,
]