from typing import Literal


EC2Operations = Literal['describe_volumes']