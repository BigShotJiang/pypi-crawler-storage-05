from followthemoney.exc import FollowTheMoneyException


class NomenklaturaException(FollowTheMoneyException):
    pass


class MetadataException(NomenklaturaException):
    pass
