INSTALL_TYPE = "lite" # lite or full
