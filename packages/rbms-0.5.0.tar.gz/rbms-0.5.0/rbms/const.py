import torch

LOG_FILE_HEADER = ["empty_col"]
INT_DTYPE = torch.int32
