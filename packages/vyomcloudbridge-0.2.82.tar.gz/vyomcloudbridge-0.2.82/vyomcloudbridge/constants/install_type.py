INSTALLATION_TYPE = "lite" # lite or full
