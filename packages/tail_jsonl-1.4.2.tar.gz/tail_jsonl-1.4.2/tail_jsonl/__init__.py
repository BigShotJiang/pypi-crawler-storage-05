"""tail_jsonl."""

from ._runtime_type_check_setup import configure_runtime_type_checking_mode

__version__ = '1.4.2'
__pkg_name__ = 'tail_jsonl'

configure_runtime_type_checking_mode()


# == Above code must always be first ==
