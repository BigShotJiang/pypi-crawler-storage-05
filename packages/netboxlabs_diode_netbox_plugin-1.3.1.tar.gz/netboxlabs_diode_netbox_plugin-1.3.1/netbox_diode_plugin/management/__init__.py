"""Django management package for netbox_diode_plugin."""
