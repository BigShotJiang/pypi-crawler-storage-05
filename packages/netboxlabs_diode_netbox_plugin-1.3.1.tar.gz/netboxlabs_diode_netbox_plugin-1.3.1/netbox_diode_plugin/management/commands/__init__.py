"""Django management commands for netbox_diode_plugin."""
