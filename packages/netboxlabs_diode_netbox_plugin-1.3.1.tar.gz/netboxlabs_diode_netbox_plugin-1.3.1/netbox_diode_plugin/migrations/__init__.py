#!/usr/bin/env python
# Copyright 2025 NetBox Labs, Inc.
"""Diode Netbox Plugin - Database migrations."""
