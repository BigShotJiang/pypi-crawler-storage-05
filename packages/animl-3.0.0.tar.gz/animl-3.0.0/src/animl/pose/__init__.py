from animl.pose import viewpoint

from animl.pose.viewpoint import (predict_viewpoints,)

__all__ = ['predict_viewpoints', 'viewpoint']
