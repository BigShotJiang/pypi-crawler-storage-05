""" Initialize app for core_linked_records
"""

default_app_config = "core_linked_records_app.apps.LinkedRecordsAppConfig"
