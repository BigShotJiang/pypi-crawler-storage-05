var retrieveBlobPidUrl = "{% url 'core_linked_records_retrieve_blob_pid' %}";
