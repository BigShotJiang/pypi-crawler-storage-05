let retrieveListPidUrl = "{% url 'core_linked_records_retrieve_list_pid' %}";
