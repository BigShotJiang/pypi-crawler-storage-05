""" Rights for core_linked_records_app.
"""

APP_CONTENT_TYPE = "core_linked_records_app"

CAN_READ_PID_SETTINGS = "read_pid_settings"
