"""Python package for the tap-betterstack CLI."""

from __future__ import annotations
