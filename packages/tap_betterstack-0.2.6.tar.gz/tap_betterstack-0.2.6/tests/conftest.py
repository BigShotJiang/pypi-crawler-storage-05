"""Pytest configuration for tests in this directory."""

from __future__ import annotations
