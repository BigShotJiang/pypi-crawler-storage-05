"""
Nagios MCP Server Initialization
"""

from .server import main

__all__ = ["main"]
