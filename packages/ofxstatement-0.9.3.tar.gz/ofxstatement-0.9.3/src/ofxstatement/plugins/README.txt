Namespace package for ofxstatement plugins

Please do not remove this file.