"""
A module to designed to perform package installations, and verification of install,
for students enrolled in Structural Python courses.
"""
__version__ = "0.4.2"
