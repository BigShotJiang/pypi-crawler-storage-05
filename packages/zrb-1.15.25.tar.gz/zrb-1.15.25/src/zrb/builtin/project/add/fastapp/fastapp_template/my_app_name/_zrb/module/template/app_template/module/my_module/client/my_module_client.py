from abc import ABC, abstractmethod


class MyModuleClient(ABC):
    """
    Defining client methods
    """
