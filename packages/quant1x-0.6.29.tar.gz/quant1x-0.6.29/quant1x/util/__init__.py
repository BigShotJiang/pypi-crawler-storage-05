import os

CURRENT_PATH = os.path.dirname(__file__)
FONT_SimHei = CURRENT_PATH + '/SimHei.ttf'
