Generate a template for this exploit with `pwnkit`:
```
pip install pwnkit
pwnkit xpl.py -f ./travelgraph -l ./libc.so.6 -t heap
```

Writeup: https://4xura.com/writeups-for-ctfs/pwn-travelgraph/
