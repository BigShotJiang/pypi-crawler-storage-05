if __name__ == '__main__':
    import fire
    from .cli import OhMyBatch
    fire.Fire(OhMyBatch)