# Webhook To Fedora Messaging messages

A schema package for [Webhook To Fedora Messaging](http://github.com/fedora-infra/webhook-to-fedora-messaging).

See the [detailed documentation](https://fedora-messaging.readthedocs.io/en/stable/user-guide/messages.html#packaging) on packaging your schemas.

![PyPI](https://img.shields.io/pypi/v/webhook-to-fedora-messaging-messages.svg)
![Supported Python versions](https://img.shields.io/pypi/pyversions/webhook-to-fedora-messaging-messages.svg)
![Build status](http://github.com/fedora-infra/webhook-to-fedora-messaging-messages/actions/workflows/main.yml/badge.svg?branch=main)
