# SPDX-FileCopyrightText: 2024 Contributors to the Fedora Project
#
# SPDX-License-Identifier: LGPL-3.0-or-later

from .v1 import DiscourseMessageV1

__all__ = ("DiscourseMessageV1",)
