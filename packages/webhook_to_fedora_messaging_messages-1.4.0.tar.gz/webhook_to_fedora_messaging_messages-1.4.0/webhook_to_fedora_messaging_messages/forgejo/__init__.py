# SPDX-FileCopyrightText: 2024-2025 Contributors to the Fedora Project
#
# SPDX-License-Identifier: LGPL-3.0-or-later

from .v1 import ForgejoMessageV1

__all__ = ("ForgejoMessageV1",)
