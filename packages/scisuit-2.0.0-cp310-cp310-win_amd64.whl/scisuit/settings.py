NDIGITS = 3
"""
Number of decimal points to be used when rounding a floating number (used during outputs)
"""