# This version placeholder will be replaced during package build.
# Do not commit this file.
__version__ ="3.4.4"#
#
def __version() -> str:
    return __version__