# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.


from graspologic.layouts.nooverlap.nooverlap import remove_overlaps

__all__ = ["remove_overlaps"]
