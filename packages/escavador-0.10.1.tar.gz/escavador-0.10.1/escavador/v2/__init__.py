from .resources.envolvido import Envolvido
from .resources.movimentacao import Movimentacao
from .resources.processo import Processo
from .resources.tribunal import Tribunal
