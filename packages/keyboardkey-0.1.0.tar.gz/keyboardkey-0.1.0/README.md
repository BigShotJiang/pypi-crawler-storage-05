# keyboardkey

A Python module that provides lists of keyboard keys (letters, digits, function keys, control keys, special characters).

## Usage
```py
import keyboardkey
print(keyboardkey.letters)
print(keyboardkey.every_key)
