#  This code is a part of the Democratising Archival X-ray Astronomy (DAXA) module.
#  Last modified by David J Turner (turne540@msu.edu) 21/10/2024, 22:15. Copyright (c) The Contributors

# TODO HERE WE WILL (TEMPORARILY I HOPE) INCLUDE WAYS TO RUN CIAO'S NICE SOURCE DETECTION ROUTINES
