from django.contrib import admin
from .models import ExternalAlertFeedEntry

admin.site.register(ExternalAlertFeedEntry)
