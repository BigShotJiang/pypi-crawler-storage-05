from .user_activities import (
    UserActivityChartTitleConfig,
    UserActivityModelTitleConfig,
    UserActivityTableTitleConfig,
    UserActivityUserChartTitleConfig,
    UserActivityUserModelTitleConfig,
)
from .users import (
    UserModelTitleConfig,
    UserPermissionsModelTitleConfig,
    UserProfileModelTitleConfig,
)
