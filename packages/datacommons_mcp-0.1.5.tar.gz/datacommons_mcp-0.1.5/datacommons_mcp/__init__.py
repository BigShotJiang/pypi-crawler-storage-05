"""
DataCommons MCP Server Package
"""

from .version import __version__
