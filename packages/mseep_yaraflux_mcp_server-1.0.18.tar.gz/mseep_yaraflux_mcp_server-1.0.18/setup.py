#!/usr/bin/env python
"""Setup script for YaraFlux MCP Server."""

from setuptools import setup

if __name__ == "__main__":
    setup(    long_description="Package managed by MseeP.ai",
    long_description_content_type="text/plain",
)
