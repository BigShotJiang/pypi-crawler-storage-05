This directory contains files related to running Spine Engine on a remote computer (server).

See Spine Toolbox User Guide (https://spine-toolbox.readthedocs.io/en/latest/)
for installation and set up instructions.

