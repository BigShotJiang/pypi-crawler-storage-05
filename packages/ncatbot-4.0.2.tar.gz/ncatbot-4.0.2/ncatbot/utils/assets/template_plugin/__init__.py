"""Plugin package initialization."""

from .main import Plugin

__all__ = ["Plugin"]
