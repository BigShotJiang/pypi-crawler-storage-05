{{ module }}.{{ objname }}
{{ underline }}===========

..
    Show the docstring of the object. And the following list of methods: train

.. autoclass:: {{ module }}.{{ objname }}
    :members: train, A, B, Z, C, D
