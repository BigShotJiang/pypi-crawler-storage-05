:::{include} ../README.md
:::


:::{toctree}
:hidden:

Getting Started <getting_started/index>
API Reference <reference/index>
Development <development/index>
:::
