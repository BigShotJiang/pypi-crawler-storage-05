"""Endpoint modules for bitvavo_client."""
