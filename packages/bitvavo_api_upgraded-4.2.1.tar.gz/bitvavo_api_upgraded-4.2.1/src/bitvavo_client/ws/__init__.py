"""WebSocket modules for bitvavo_client."""
