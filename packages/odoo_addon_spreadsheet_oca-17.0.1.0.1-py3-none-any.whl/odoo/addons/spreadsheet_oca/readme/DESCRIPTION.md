This module adds a functionality for adding and editing Spreadsheets
using Odoo CE.

It is an alternative to the proprietary module `spreadsheet_edition` of
Odoo Enterprise Edition.
