"""Pyagenity API - A Python API framework with GraphQL support and task management."""

__version__ = "1.0.0"
__author__ = "Shudipto Trafder"
__email__ = "shudiptotrafder@gmail.com"
