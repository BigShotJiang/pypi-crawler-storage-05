# Library
1. Snowflow
2. Fastapi Injecttor
3. Cloud Upload
4. Textract
5. Pyagenity

# Next Sets of Actions
1. Snowflowflake -> v2
2. DI -> v1
3. Fastapi, Taskiq, Mcp -> v1

Major Things:
1. Auth -> Fon


10xScale-OSS


# Ranking
1. Graph -> Graph is slow -> Typesense/ElasticSearch


