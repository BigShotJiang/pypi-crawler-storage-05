def get_hello(gretting: str = "Symmora World" ) -> str:
    return f"{'*'*5} version 8 {'*'*3} : Hello, {gretting}!!!"

def symmora_add(a: int, b: int) -> int:
    return a + b

