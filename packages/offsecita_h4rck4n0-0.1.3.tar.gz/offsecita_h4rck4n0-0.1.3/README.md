# OffSec Italia       

Una biblioteca Python per consultare i corsi Offensive Security Italia.

## Corsi disponibili:

- Corso Hacking Etico [60 ore] 
- Corso Linux da zero [15 ore]
- Corso Python Offensive [50 ore]
- Corso Personalizzazione Linux [3 ore]


## Macchine risolte nelle varie piattaforme:

- Hacking Macchine TryHackMe: https://www.youtube.com/watch?v=aqibENOVnUY&list=PLKZZXjqZrqQvhBNpeY6aE1c0u1PeJ2fdV
- Hacking Macchine HackTheBox: https://www.youtube.com/watch?v=f4BoQLl6XPM&list=PLKZZXjqZrqQukyaAE6TvryVvSOjaopSGW
- Hacking Tutorial Vari: https://www.youtube.com/watch?v=v4f_IN9jjWY&list=PLKZZXjqZrqQv1QVu91WJjJyoUrzVMkrrK


## Social Media:

- GitHub https://github.com/roby7979
- Discord OffSec Italia: https://discord.gg/ARWVZn8QWg
- Twitter https://twitter.com/ModernNaval
- TryHackMe Italia https://www.facebook.com/groups/606428807774402
- Offensive Security Italia https://www.facebook.com/groups/1279369172893764
- Twitch Roby7979: https://www.twitch.tv/roby7979
- Youtube: https://www.youtube.com/channel/UCAwPX5amsoJBiJyj-vmHhcQ


