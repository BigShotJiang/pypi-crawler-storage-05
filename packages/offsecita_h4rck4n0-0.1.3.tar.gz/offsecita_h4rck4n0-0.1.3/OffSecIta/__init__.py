# importiamo tutto dal modulo corsi 

from .corsi import *
from .utils import *
