from importlib.metadata import version

from . import pl

__all__ = ["pl"]

__version__ = version("spatialdata-plot")
