# Changelog

Please refer directly to the [Releases](https://github.com/scverse/spatialdata-plot/releases) section on GitHub, where you can find curated release notes for each release.
For developers, please consult the [contributing guide](https://github.com/scverse/spatialdata/blob/main/docs/contributing.md), which explains how to keep release notes are up-to-date at each release.
