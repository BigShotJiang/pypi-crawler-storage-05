from .fandom_scraper import scrape_fandom

__all__ = ["scrape_fandom"]

def main():
    print("Hello from fandom_scraper")