from __future__ import annotations

# Python formatting string to use for converting datetime to ISO8601
ISO8601_PYTHON_FORMAT = "%Y-%m-%d"
ISO8601_PYTHON_TS_FORMAT = "%Y-%m-%d %H:%M:%S"
