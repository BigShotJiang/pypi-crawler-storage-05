from __future__ import annotations

from metricflow_semantics.test_helpers.config_helpers import DirectoryPathAnchor

DW_VALIDATION_MANIFEST_ANCHOR = DirectoryPathAnchor()
