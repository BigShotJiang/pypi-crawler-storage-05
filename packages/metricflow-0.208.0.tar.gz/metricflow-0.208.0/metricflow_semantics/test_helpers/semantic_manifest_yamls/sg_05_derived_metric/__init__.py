from __future__ import annotations

from metricflow_semantics.test_helpers.config_helpers import DirectoryPathAnchor

SG_05_DERIVED_METRIC_MANIFEST = DirectoryPathAnchor()
