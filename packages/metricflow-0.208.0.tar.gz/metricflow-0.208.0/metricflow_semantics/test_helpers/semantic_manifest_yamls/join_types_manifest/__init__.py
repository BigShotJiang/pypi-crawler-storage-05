from __future__ import annotations

from metricflow_semantics.test_helpers.config_helpers import DirectoryPathAnchor

JOIN_TYPES_MANIFEST_ANCHOR = DirectoryPathAnchor()
