"""Workarounds for issues present in dependency projects.

These can be removed once the issues in dependency projects are resolved.
"""
