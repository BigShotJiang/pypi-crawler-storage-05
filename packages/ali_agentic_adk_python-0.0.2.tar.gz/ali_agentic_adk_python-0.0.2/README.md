# use
````
 pip install ali-agentic-adk-python
````

# License
Apache-2.0
Copyright (C) 2025 AIDC-AI All rights reserved.