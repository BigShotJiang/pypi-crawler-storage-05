import pydantic

PYDANTIC_VERSION = tuple(map(int, pydantic.__version__.split(".")))
