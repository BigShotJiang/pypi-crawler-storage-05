"""Test suite for core functionalities."""
