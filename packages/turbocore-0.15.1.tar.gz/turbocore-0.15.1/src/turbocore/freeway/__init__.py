import turbocore


def fw_test():
    pass


def main():
    turbocore.cli_this(__name__, 'fw_')
    # os.environ.get("WP_USER", "")
    # os.environ.get("WP_PASS", "")
    # os.environ.get("WP_DBHOST", "")
    # os.environ.get("WP_DBNAME", "")
    # os.environ.get("WP_DBPORT", "")
