from turbocore.misc.sshcompile import main


if __name__ == "__main__":
    main()
