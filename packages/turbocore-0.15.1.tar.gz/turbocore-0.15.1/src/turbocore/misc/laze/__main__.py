from turbocore.misc.laze import main


if __name__ == "__main__":
    main()
