from .cosmic_flagger import *
__version__ = "0.2.0"
__author__ = 'Autumn Stephens'