# cosmic-flagger
A small package for flagging, verifying, and removing cosmic ray contamination from data.
