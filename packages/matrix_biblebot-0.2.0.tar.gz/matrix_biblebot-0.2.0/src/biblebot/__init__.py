"""BibleBot for Matrix - A simple bot that fetches Bible verses."""

# Single source of truth for version - setup.py reads from here
__version__ = "0.2.0"
