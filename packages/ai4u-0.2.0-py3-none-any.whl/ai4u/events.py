class EnvEventCallback:
    def on_step(self, action, state, info):
        pass

    def on_reset(self, info):
        pass
