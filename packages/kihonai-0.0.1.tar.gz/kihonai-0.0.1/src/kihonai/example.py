def hello_world():
    return """
    Kihon is the first platform to build voice agents that run completely on edge devices.
    """
