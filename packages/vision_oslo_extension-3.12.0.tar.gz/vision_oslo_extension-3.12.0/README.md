# Project Name: VISION OSLO Extension

This is VISION-OSLO extension package in order to support the simulation data post processing.

Please refer to the document manual for instructions.

## Copyright

Copyright (c) 2024 [Jieming Ye, Engineering Services, Network Rail]

This package is developed by Jieming Ye. Senior Design Engineer, Engineering Services, Network Rail.
The source code is open to public but restrict for commerical use.

Network Rail Infrastructure Limited are registered in England and Wales under company number 02904587.

## Development Status
[![Python application - build and test](https://github.com/NR-JYe/Vision-Oslo-Extension/actions/workflows/py_app_test.yml/badge.svg)](https://github.com/NR-JYe/Vision-Oslo-Extension/actions/workflows/py_app_test.yml)

## Installation
The repository of this package is saved on GitHub:
https://github.com/NR-JYe/Vision-Oslo-Extension

## Usage
Pre-installtion of Python and VISION-OSLO required.

## What's New

This version fixed multiple bugs and had minor improvment.

## History / Key Upgrade
Version 3.12.0: Introduction of customised database library.

Version 3.11.0: Support Vision Oslo RN29.

Version 3.10.0: Major version upgrade to speed up GUI performance.

Version 3.9.0: Enable batch simulation control via Windows platform.

Version 3.8.0: Enable settings of working directory. Now the application could work as a copilot.

Version 3.7.0: Add feature to support new battery train modelling from Vision Oslo RN29.

Version 3.5.0: Add feature to support dynamic grid calculation for HV analysis

Version 3.4.0: Add feature to Output AC OSLO connection plot.

Version 3.3.0: Add feature to support CIF import process.

Version 3.2.0: Add feature to filter low voltage output

Version 3.1.0: Add feature to remove TIPLOCS from CIF.

Version 3.0.0: Including license mechanisim. License update.

Version 2.0.0: Major UI update + Add Falling Voltage Protection assessment

Version 1.3.0: Add Battery EMU Modelling Assessment

Version 1.2.0: Add Single End Feeding assessment in DC.

Version 1.1.0: Add SFC Assessment.

Version 1.0.0 (Stable version): First official version to all stakeholders

Version 0.1.1 (Beta version): First version published for user testing.

## Contributing
Engineering Services, part of Route Services, Network Rail

## License
Copyright (c) 2025 [Jieming Ye]  
This Python source code is licensed under the  
Open Source Non-Commercial License (OSNCL) v1.0  
See LICENSE for details.
