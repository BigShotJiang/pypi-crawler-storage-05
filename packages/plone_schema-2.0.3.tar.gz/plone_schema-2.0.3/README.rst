Provides additional fields and widgets for z3c.form and optional integration with Plone.

- Email Field and Widget
- JSON Field and Widget
- URI Field and Widget
- IPath as IChoice derivative (and implementation)
- integration with plone.supermodel, optional (extra "supermodel")
- integration with plone.schemaeditor, optional (extra "schemaeditor")


Source Code
===========

Contributors please read the document `Process for Plone core's development <https://docs.plone.org/develop/coredev/docs/index.html>`_

Sources are at the `Plone code repository hosted at Github <https://github.com/plone/plone.schema>`_.

