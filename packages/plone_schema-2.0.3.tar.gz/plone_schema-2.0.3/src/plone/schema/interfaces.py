from z3c.form.interfaces import IFormLayer as IBaseFormLayer


class IFormLayer(IBaseFormLayer):
    """Request layer. Must be enabled to activate widgets"""
