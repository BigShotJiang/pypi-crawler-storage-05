# Empty settings file just so we can pass Django
