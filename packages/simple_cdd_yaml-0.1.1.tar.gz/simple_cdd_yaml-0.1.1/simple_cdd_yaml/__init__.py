""" Simple-CDD-YAML: A YAML recipe interpreter for Simple-CDD """


__version__ = '0.1.1'
