from cloudproxy.providers import manager

manager.init_schedule()
