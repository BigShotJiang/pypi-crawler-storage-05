"""
Template directory for NGINX configurations.

This package contains individual NGINX configuration templates for various services.
""" 