# Dex

- DEX = Cryptocurrency Decentralized Exchanges (加密货币去中心化交易所)

## Installation

```ruby

uv add azdex

```

## DEX Rankings

- ✅ [CoinMarketCap - DEX](https://coinmarketcap.com/rankings/exchanges/dex/)

## DEX Exchanges

### Hyperliquid

- ✅ [Hyperliquid](https://app.hyperliquid.xyz/trade)
- ✅ [Python SDK](https://github.com/hyperliquid-dex/hyperliquid-python-sdk)
