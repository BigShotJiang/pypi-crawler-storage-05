"""Zenith Framework version."""

__version__ = "0.1.2"
