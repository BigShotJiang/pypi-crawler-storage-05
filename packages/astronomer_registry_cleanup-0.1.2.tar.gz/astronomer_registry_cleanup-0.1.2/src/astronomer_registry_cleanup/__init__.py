"""Astronomer registry cleanup package."""

from astronomer_registry_cleanup.main import main

__all__ = ["main"]
