from .checker import armstrong
