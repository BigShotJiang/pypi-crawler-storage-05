"""Entry point for running sauce-api-mcp as a module."""

from .main import main

if __name__ == "__main__":
    main()