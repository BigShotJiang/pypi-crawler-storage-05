``zope.componentvocabulary``
============================

.. image:: https://img.shields.io/pypi/v/zope.componentvocabulary.svg
        :target: https://pypi.python.org/pypi/zope.componentvocabulary/
        :alt: Latest release

.. image:: https://img.shields.io/pypi/pyversions/zope.componentvocabulary.svg
        :target: https://pypi.org/project/zope.componentvocabulary/
        :alt: Supported Python versions

.. image:: https://github.com/zopefoundation/zope.componentvocabulary/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.componentvocabulary/actions/workflows/tests.yml

.. image:: https://coveralls.io/repos/github/zopefoundation/zope.componentvocabulary/badge.svg?branch=master
        :target: https://coveralls.io/github/zopefoundation/zope.componentvocabulary?branch=master



This package contains various vocabularies.
