"""Synapse and synapse parameters representation and operations."""

from .synapse_types import Synapse, AmpanmdaSynapse, GabaabSynapse, GluSynapse
from .synapse_factory import SynapseFactory
