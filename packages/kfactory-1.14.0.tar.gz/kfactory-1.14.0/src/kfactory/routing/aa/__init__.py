"""All-angle routing."""

from . import optical

__all__ = ["optical"]
