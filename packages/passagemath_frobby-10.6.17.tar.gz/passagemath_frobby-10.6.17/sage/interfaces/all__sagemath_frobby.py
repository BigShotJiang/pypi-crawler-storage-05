# sage_setup: distribution = sagemath-frobby
