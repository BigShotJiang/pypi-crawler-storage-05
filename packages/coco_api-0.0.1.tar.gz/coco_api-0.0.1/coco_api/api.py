class CocoAPI:
    def run(self) -> None:
        return None
