"""coco_api

Minimal package stub for the coco-api project.
"""

__version__ = "0.0.1"

from .api import CocoAPI

__all__ = ["__version__", "CocoAPI"]
