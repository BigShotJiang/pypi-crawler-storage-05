"""Terminal User Interface for GitFlow Analytics."""

from .app import GitFlowAnalyticsApp

__all__ = ["GitFlowAnalyticsApp"]
