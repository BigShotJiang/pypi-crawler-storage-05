"""Tests for metrics calculation."""
