class APIError(Exception):
    pass
