<h2 align="center">Send responses to aiohttp using pytest</h2>


Heavily inspired by [pytest-httpx](https://github.com/Colin-b/pytest_httpx)
