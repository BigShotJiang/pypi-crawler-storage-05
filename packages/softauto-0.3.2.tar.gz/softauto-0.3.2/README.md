# softauto 0.3.1 – tiny-data safe SMOTE, advisor, plots
