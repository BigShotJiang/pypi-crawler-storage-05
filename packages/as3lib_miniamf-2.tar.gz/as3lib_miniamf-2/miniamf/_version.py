"""
This file provides the current version number of Mini-AMF.
"""

from .versions import Version


version = Version(*(0, 9, 1))
