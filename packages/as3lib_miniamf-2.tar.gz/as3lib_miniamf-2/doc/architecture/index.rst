***************
 Architecture
***************

.. toctree::
   :maxdepth: 1

   overview.rst
   typemap.rst
   adapters.rst
   classmapping.rst
   future.rst
