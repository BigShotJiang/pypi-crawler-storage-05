# Clumpick: An interactive visualization tool for aligned clustering results from population structures analyses
Powered by JavaScript D3

## Basic Usage
````
python -m clumpick --membership_folder Data/Cape_Verde_Data --alignment_file Data/Cape_Verde_Alignment.txt 
````
