"""
Slidedown: A tool for generating HTML slides from Markdown

"""

__version__ = "0.1.0"