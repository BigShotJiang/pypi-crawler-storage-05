This module integrates module *Purchase Order UBL* with module *Stock/Inventory*.
