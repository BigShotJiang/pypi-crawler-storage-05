# LlamaIndex Response Synthesizers Integration: Google
