"""DIGSY project."""
