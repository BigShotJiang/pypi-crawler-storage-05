"""Test suite for :mod:`message_ix_models`."""
