# ISSUE-SOLVER

This project is a collection of bots that help solve issues and automate tasks in software development workflows.
The bots are designed to work with popular platforms like GitLab and GitHub, and can be extended to support other
platforms as well.