class ClarifaiException(Exception):
    pass
