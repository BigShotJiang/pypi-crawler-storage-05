# auto-chart-patterns
Automatically identify chart patterns from OHLC data
