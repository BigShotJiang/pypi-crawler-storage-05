from snakesay.snakesay import snakesay

__version__ = "0.10.4"