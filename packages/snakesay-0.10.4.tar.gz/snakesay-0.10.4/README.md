```
< speaking snake >
   \
    ~<:>>>>>>>>>
```

If you want to use it in the command line, install it with [pipx](https://pypa.github.io/pipx/),
but you may also use `snakesay()` directly in your own code for beautiful output. 