class RecFailedException(Exception):
    pass
