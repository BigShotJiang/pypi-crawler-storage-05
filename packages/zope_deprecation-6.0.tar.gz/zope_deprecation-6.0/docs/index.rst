:mod:`zope.deprecation` Documentation
=====================================

Contents:

.. toctree::
   :maxdepth: 2

   api
   hacking


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

