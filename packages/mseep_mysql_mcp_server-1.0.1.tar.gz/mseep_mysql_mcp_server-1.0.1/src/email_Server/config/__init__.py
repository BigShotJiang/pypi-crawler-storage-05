from  .dbconfig import  *
__all__=[
    "get_db_config",
    "get_config"
]


