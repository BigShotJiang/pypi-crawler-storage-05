"""Chat integration tests."""
