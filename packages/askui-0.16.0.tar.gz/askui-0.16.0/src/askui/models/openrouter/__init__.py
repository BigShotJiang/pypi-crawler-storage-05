"""OpenRouter model implementations."""
