.. linux.ubuntu2204 documentation file, created by FIREWHEELs Model Component generation.
   You can adapt this file completely to your liking.

.. _linux.ubuntu2204_mc:

################
linux.ubuntu2204
################

This Model Component provides initialization for an Ubuntu2204 VM.
It contains Ubuntu2204 Server.





**Model Component Dependencies:**
    * :ref:`linux.ubuntu_mc`





*****************
Available Objects
*****************

.. automodule:: linux.ubuntu2204
    :members:
    :undoc-members:
    :special-members:
    :private-members:
    :show-inheritance:
    :exclude-members: __dict__,__weakref__,__module__

