"""Metadata presenters - file info, document properties."""

from .info import *

__all__ = ["metadata"]
