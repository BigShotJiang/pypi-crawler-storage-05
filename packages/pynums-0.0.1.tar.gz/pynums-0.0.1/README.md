# Pynums
A library for adding configurable Enum-type objects to python!

## How to create Enums:
    g
