This directory and subdirectories contains TEMPLATES which are deployed by acforge cli to the target repository,
e.g., during init, update or merge operations. These files serve as blueprints for .claude, .devcontainer and other
directories in the repository root.

When modifying these files, you MUST modify the files here, in templates. Once the modifications are implemented
and released, they will be deployed by acforge cli.
