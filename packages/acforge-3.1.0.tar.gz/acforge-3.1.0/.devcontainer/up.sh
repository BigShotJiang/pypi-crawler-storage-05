
[ -f devcontainer.json ] && cd ..
devcontainer up --workspace-folder . $@