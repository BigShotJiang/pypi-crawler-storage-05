This package provides session support.
