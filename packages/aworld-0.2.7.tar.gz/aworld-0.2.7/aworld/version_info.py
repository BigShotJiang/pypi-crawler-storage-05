# auto generated
class VersionInfo:
    BUILD_DATE = "2025-09-10 20:46:24"
    BUILD_VERSION = "0.2.7"
    BUILD_USER = "ganrunsheng" 
    SCENARIO = "AWORLD_SDIST"
