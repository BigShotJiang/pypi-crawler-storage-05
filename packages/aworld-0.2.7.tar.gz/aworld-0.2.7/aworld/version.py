
# auto generated
class VersionInfo(object):
    @property
    def build_date(self):
      return "2025-09-10 20:46:24"

    @property
    def version(self):
      return "0.2.7"

    @property
    def build_user(self):
      return "ganrunsheng"
