These files are taken from CMake v3.14.5 at
[github](https://github.com/Kitware/CMake/tree/f3e9a6ff62f6f58cd661dd447c22a01c50f6f4ad)
with small modifications to allow them to work outside of their expected
location.

They are used in the modules for CMake < 3.12
