#include <iostream>
#include <jrl_cmakemodule/lib.hh>

void lib_function() {
  std::cout << "JRL CMake module - unittest - lib_function" << std::endl;
}
