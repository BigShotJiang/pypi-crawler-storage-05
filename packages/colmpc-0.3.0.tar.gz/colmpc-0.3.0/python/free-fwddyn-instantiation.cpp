#include <colmpc/free-fwddyn.hpp>
#include <colmpc/free-fwddyn.hxx>

namespace colmpc {

template class DifferentialActionModelFreeFwdDynamicsTpl<double>;
template class DifferentialActionDataFreeFwdDynamicsTpl<double>;

}  // namespace colmpc
