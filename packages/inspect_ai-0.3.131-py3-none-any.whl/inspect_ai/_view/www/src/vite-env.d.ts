/// <reference types="vite/client" />

declare const __VIEW_SERVER_API_URL__: string;
