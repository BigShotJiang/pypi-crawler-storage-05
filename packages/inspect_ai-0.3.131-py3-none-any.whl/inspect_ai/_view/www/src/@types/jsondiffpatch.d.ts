declare module "jsondiffpatch/formatters/html" {
  export {
    default as HtmlFormatter,
    showUnchanged,
    hideUnchanged,
    format,
  } from "jsondiffpatch/lib/formatters/html";
}
