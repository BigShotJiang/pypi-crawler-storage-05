# SPDX-License-Identifier: GPL-2.0+
from .gfort2py import fFort, mod_info, lib_ext, compile
from .version import __version__
