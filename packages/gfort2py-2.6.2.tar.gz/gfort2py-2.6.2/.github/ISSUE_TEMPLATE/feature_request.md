---
name: Feature request
about: Suggest an idea for this project
title: "[ENH]"
labels: enhancement
assignees: ''

---

**Description of the new feature**

**Proposed Fortran code**
An example of what the Fortran code looks like

**Proposed Python code**
An example of what the Python code might look like
