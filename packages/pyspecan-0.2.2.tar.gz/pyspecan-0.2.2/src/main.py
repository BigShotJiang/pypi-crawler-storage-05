from pyspecan._internal.main import main
import pyspecan.view
import pyspecan.controller

import pyspecan.view.cui
import pyspecan.view.tk_gui

main()
