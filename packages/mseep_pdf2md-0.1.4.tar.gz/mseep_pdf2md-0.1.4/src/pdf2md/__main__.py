"""
PDF to Markdown Conversion Service Startup Script
"""
import asyncio
from . import main

if __name__ == "__main__":
    main()