from kizano import Config
Config.APP_NAME = 'smartmetertx'
from smartmetertx.api import MeterReader
from smartmetertx.smtx2mongo import Smtx2Mongo
