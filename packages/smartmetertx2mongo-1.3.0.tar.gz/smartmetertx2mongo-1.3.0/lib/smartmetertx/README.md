https://github.com/cmulk/python_smartmetertx

# python-smartmetertx
SmartMeterTX Python class provides a JSON interface to the electricity usage data available at https://www.smartmetertexas.com.  
You must have an account established at the site.
