Ticket Manager
==============

The :class:`~py_superops.managers.TicketManager` provides comprehensive functionality for managing SuperOps tickets.

Documentation coming soon. See the full manager reference below.

.. autoclass:: py_superops.managers.TicketManager
   :members:
   :inherited-members:
   :show-inheritance:
