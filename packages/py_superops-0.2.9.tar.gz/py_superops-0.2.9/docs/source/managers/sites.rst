Sites Manager
=============

The :class:`~py_superops.managers.SitesManager` provides comprehensive functionality for managing SuperOps sites resources.

Documentation coming soon. See the full manager reference below.

.. autoclass:: py_superops.managers.SitesManager
   :members:
   :inherited-members:
   :show-inheritance:
