Projects Manager
================

The :class:`~py_superops.managers.ProjectsManager` provides comprehensive functionality for managing SuperOps projects resources.

Documentation coming soon. See the full manager reference below.

.. autoclass:: py_superops.managers.ProjectsManager
   :members:
   :inherited-members:
   :show-inheritance:
