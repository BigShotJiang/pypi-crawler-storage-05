Contacts Manager
================

The :class:`~py_superops.managers.ContactsManager` provides comprehensive functionality for managing SuperOps contacts resources.

Documentation coming soon. See the full manager reference below.

.. autoclass:: py_superops.managers.ContactsManager
   :members:
   :inherited-members:
   :show-inheritance:
