Automation Manager
==================

The :class:`~py_superops.managers.AutomationManager` provides comprehensive functionality for managing SuperOps automation resources.

Documentation coming soon. See the full manager reference below.

.. autoclass:: py_superops.managers.AutomationManager
   :members:
   :inherited-members:
   :show-inheritance:
