Attachments Manager
===================

The :class:`~py_superops.managers.AttachmentsManager` provides comprehensive functionality for managing SuperOps attachments resources.

Documentation coming soon. See the full manager reference below.

.. autoclass:: py_superops.managers.AttachmentsManager
   :members:
   :inherited-members:
   :show-inheritance:
