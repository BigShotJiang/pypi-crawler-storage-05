Webhooks Manager
================

The :class:`~py_superops.managers.WebhooksManager` provides comprehensive functionality for managing SuperOps webhooks resources.

Documentation coming soon. See the full manager reference below.

.. autoclass:: py_superops.managers.WebhooksManager
   :members:
   :inherited-members:
   :show-inheritance:
