Time Entries Manager
====================

The :class:`~py_superops.managers.Time_entriesManager` provides comprehensive functionality for managing SuperOps time-entries resources.

Documentation coming soon. See the full manager reference below.

.. autoclass:: py_superops.managers.Time_entriesManager
   :members:
   :inherited-members:
   :show-inheritance:
