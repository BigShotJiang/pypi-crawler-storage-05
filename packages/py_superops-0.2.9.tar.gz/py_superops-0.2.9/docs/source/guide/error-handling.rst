Error Handling
==============

Error handling guide coming soon. See the :doc:`../api/exceptions` for API reference.

.. toctree::
   :hidden:
