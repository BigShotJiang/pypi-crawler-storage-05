Managers API
============

All resource managers for the SuperOps API.

.. automodule:: py_superops.managers
   :members:
   :inherited-members:
   :show-inheritance:

Base Manager
------------

.. autoclass:: py_superops.managers.ResourceManager
   :members:
   :inherited-members:
   :show-inheritance:
