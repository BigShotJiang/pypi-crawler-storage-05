GraphQL API
===========

GraphQL utilities and query builders.

.. automodule:: py_superops.graphql
   :members:
   :inherited-members:
   :show-inheritance:
