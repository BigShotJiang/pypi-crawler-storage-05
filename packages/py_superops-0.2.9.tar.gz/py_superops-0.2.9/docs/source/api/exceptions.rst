Exceptions API
==============

Exception classes for error handling.

.. automodule:: py_superops.exceptions
   :members:
   :inherited-members:
   :show-inheritance:
