Authentication API
==================

Authentication handling.

.. autoclass:: py_superops.auth.AuthHandler
   :members:
   :inherited-members:
   :show-inheritance:
