Advanced Patterns Examples
===========================

Coming soon.
