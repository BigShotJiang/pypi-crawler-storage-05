Automation Script Examples
===========================

Coming soon.
