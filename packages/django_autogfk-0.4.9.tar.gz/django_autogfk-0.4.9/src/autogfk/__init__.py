default_app_config = "autogfk.apps.AutoGenericForeignKeyConfig"
__version__ = "0.4.9"
__all__ = ["fields"]