class BalanceNotEnough(Exception):
    pass


class NoPositionsToRedeem(Exception):
    pass
