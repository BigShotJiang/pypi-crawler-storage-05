from .fandom_scraper import scrape_fandom

__all__ = ["scrape_fandom"]