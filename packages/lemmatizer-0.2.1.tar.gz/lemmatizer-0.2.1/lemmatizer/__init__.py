from .lemmatizer import Lemmatizer as Lemmatizer

__version__ = "0.2.1"
