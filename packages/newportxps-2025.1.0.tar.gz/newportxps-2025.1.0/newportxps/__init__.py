from .version import __version__, __version_tuple__

from .newportxps import NewportXPS
