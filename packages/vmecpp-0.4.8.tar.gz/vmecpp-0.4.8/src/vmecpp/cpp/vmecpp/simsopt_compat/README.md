# Simsopt compatibility utils

Functionality to make VMEC++ and SIMSOPT play nice.
