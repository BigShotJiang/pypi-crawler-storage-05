"""
YouTube Translate MCP package for accessing YouTube video transcripts and translations.
"""

__version__ = "0.1.0" 