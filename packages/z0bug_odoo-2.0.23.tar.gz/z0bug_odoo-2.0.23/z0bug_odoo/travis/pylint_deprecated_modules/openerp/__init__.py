# -*- coding: utf-8 -*-

from . import osv  # pylint: disable=W0402
