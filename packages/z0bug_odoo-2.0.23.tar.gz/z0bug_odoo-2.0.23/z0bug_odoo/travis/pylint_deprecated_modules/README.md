Pylint has next issue:

https://bitbucket.org/logilab/pylint/issues/362/bug-w0402-not-show-fails-if-module-not-is

This folder add all packages deprecated to show the error.
