# -*- coding: utf-8 -*-
print("Uincode ")
