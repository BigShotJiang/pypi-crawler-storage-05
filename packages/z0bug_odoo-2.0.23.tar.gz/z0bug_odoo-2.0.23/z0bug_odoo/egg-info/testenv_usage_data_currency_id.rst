If value is empty, currency of user company is used.
