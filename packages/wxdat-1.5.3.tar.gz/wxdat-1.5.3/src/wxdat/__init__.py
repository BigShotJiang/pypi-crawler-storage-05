"""Module interface to wxdat."""
