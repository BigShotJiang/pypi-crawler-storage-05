def joiner(values: list[str]) -> str:
    """
    Returns a list of strings joined by a space
    """
    return " ".join(values)
