import sys

from vscode_task_runner import console

sys.exit(console.run())
