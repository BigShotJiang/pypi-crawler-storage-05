===================
pathlib-artifactory
===================

|pypi| |docs|

Python client for Artifactory.


.. |pypi| image:: https://img.shields.io/pypi/v/pathlib-artifactory.svg
    :target: https://pypi.python.org/pypi/pathlib-artifactory
    :alt: Latest version released on PyPi

.. |docs| image:: https://readthedocs.org/projects/pathlib-artifactory/badge
    :target: http://pathlib-artifactory.readthedocs.io/en/latest
    :alt: Documentation
