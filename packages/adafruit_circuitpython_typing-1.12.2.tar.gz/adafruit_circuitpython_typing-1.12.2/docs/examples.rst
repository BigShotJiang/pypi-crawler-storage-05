Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/typing_simpletest.py
    :caption: examples/typing_simpletest.py
    :linenos:
