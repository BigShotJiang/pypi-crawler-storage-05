# Makes examples runnable as a package: python -m examples.<name>
