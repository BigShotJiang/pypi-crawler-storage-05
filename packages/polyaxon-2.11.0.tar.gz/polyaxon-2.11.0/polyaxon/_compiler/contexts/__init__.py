from polyaxon._compiler.contexts.contexts import (
    resolve_contexts,
    resolve_globals_contexts,
)
