DROP DATABASE rapt_test_db;
DROP USER raptor;