# -*- coding: utf-8 -*-
#初始化 表单数据

Clientin = {
    "aily_app_id": "spring_f17d05d924__c",
    "app_id": "cli_a6e3aea1a13c900c",
    "app_secret": "J0fAPt3BL6bv4KUJV0dJMdTUdr0pv3xx",
    "cookie": "X-Kunlun-SessionId=L%3A3b34958803f34f43a52c.eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2YWwiOnsidGVuYW50X2lkIjozOTAsInVzZXJfaWQiOjE3MjIxNjYwNzMxOTk2NDUsInRlbmFudF9kb21haW5fbmFtZSI6ImFwYWFzIiwic2Vzc2lvbl92ZXJzaW9uIjoidjIwMjAtMDUtMTkiLCJ3c190b2tlbiI6Ilc6OTk3Y2MwNTA3OTRlNGFmYWFkYzEiLCJsb2dpbl90b2tlbiI6IjE3MDE3ZmFlMWJlNjVlMzdzSzBhMzA0ZjY0N2MyZmFjY2QwSjRFYmNmNGVjNzAzZDgwOWYxNDVnNDY0MzY1ZjEyNWI0YmZlZDhhTmMiLCJzb3VyY2VfY2hhbm5lbCI6ImZlaXNodSIsInRlbmFudF9rZXkiOiI3MzY1ODhjOTI2MGYxNzVkIiwiZXh0ZXJuYWxfZG9tYWluX25hbWUiOiJieXRlZGFuY2UiLCJvcmlnaW5hbF90ZW5hbnRfaWQiOjAsIm9yaWdpbmFsX3VzZXJfaWQiOjAsImlkcF9jaGFubmVsIjoiIn0sImV4cCI6MTc1ODk0MTY3MH0.l9yn5zbWFhOEJml5iA69TpFwZ7qgLMzj7L0cj4Ryozc; passport_web_did=7487801556726579201; passport_trace_id=7487801556748156956; QXV0aHpDb250ZXh0=2f506053fdd544e7aa0df84c66a287f9; locale=zh-CN; landing_url=https://accounts.feishu.cn/accounts/page/login?app_id=107&no_trap=1&redirect_uri=https%3A%2F%2Fapaas.feishu.cn%2Fai%2Fspring_f17d05d924__c%2Fmanagement%2Fchat-log; _gcl_au=1.1.1249684330.1743389657; s_v_web_id=verify_m8wh6ssk_JRUTLUkb_AJsu_4Xjm_ANzV_gLPDip941iqw; __tea__ug__uid=7487801495396992562; _ga=GA1.2.1834362348.1743389657; _gid=GA1.2.758422620.1743389658; session=XN0YXJ0-4e7g6c2c-da65-4492-a6f6-6413002bd949-WVuZA; session_list=XN0YXJ0-4e7g6c2c-da65-4492-a6f6-6413002bd949-WVuZA; login_recently=1; _ga_VPYRHN104D=GS1.1.1743389657.1.1.1743389669.48.0.0; msToken=4W_kQaUJyB5jBl5FX8vjfY6SYAFcNAp7NiDqM3-QyBN0XIF24a5SyaOeTpfzIZAuNfH-cGjXK1u3tNXV3ETo8Z2ZTQFLGSTFF2KmMr35XQsODVrddz8FdHAfyJg4F7ayxiDsicO5ObKgK0Y_95Bq1d12vKKbJ99vm9IZWEpcRFLG; kunlun-session-v2=L%3A3b34958803f34f43a52c.eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2YWwiOnsidGVuYW50X2lkIjozOTAsInVzZXJfaWQiOjE3MjIxNjYwNzMxOTk2NDUsInRlbmFudF9kb21haW5fbmFtZSI6ImFwYWFzIiwic2Vzc2lvbl92ZXJzaW9uIjoidjIwMjAtMDUtMTkiLCJ3c190b2tlbiI6Ilc6OTk3Y2MwNTA3OTRlNGFmYWFkYzEiLCJsb2dpbl90b2tlbiI6IjE3MDE3ZmFlMWJlNjVlMzdzSzBhMzA0ZjY0N2MyZmFjY2QwSjRFYmNmNGVjNzAzZDgwOWYxNDVnNDY0MzY1ZjEyNWI0YmZlZDhhTmMiLCJzb3VyY2VfY2hhbm5lbCI6ImZlaXNodSIsInRlbmFudF9rZXkiOiI3MzY1ODhjOTI2MGYxNzVkIiwiZXh0ZXJuYWxfZG9tYWluX25hbWUiOiJieXRlZGFuY2UiLCJvcmlnaW5hbF90ZW5hbnRfaWQiOjAsIm9yaWdpbmFsX3VzZXJfaWQiOjAsImlkcF9jaGFubmVsIjoiIn0sImV4cCI6MTc1ODk0MTY3MH0.l9yn5zbWFhOEJml5iA69TpFwZ7qgLMzj7L0cj4Ryozc; kunlun-session-token=2b32fc3c28f44fb89bab94ad072a05c9f2f844c49705c95d76bae40479a189b7; _tea_utm_cache_1229=undefined; sl_session=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NDM0MzI4NzEsInVuaXQiOiJldV9uYyIsInJhdyI6eyJtZXRhIjoiQVdIazBuRzhRUUFDQUFBQUFBQUFBQUZuNmdQWUFVNEFBV2ZxQTlnQlRnQUJaK29ENWRES3dBSUNLZ0VBUVVGQlFVRkJRVUZCUVVKdU5tZFFiRE40ZDBGQlp6MDkiLCJzdW0iOiJlMmM4YTIwMTcyMDcxNmVjYTFiOWRlOTQ5Yjc3OGJkNDczOGIzOTAwNWJiNTJhYTkyOTM2YTRhZWIzMGI2ZTY0IiwibG9jIjoiemhfY24iLCJhcGMiOiJSZWxlYXNlIiwiaWF0IjoxNzQzMzg5NjcxLCJzYWMiOnsiVXNlclN0YWZmU3RhdHVzIjoiMSIsIlVzZXJUeXBlIjoiNDIifSwibG9kIjpudWxsLCJjbmYiOnsiamt0IjoiYkx6aTdPRDBHS09mNllOQ0xGamtPZWtuQkNRSHM2ZFh5STdmcTVubE93VSJ9LCJucyI6ImxhcmsiLCJuc191aWQiOiI3MDUzOTk0MzAyMzAwNTUzMjE4IiwibnNfdGlkIjoiMSIsIm90IjozLCJjdCI6MTc0MzM4OTY3MCwicnQiOjE3NDMzODk2NzB9fQ.2pQlqU6fuqnw_iqtJe1sH1FfSSXBpFQ0RAoaRccxHEaHSBvqsdc9_7e4zjgcHOhTjISi3mGw3EC3EXftLj5Otw; passport_app_access_token=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NDM0MzI4NzIsInVuaXQiOiJldV9uYyIsInJhdyI6eyJtX2FjY2Vzc19pbmZvIjp7IjEwNyI6eyJpYXQiOjE3NDMzODk2NzIsImFjY2VzcyI6dHJ1ZX19LCJzdW0iOiJlMmM4YTIwMTcyMDcxNmVjYTFiOWRlOTQ5Yjc3OGJkNDczOGIzOTAwNWJiNTJhYTkyOTM2YTRhZWIzMGI2ZTY0In19.jtfbxALtDnZYTJx4cb6ohPy2uDVCHTuh0x-Dg7Ui1F4vMO3aka7rvOeZTIwGJ7IlAn0b-OjBOWQEVQvHthhEwQ; swp_csrf_token=a239a297-e0f7-4820-aa3a-6349c8a04977; t_beda37=10a0c227407070710f979ef9d5b530118d080fd0ec27f2c3ce04c251a5a20d70",
    "x-kunlun-token": "17017fae1be65e37sK0a304f647c2faccd0J4Ebcf4ec703d809f145g464365f125b4bfed8aNc",
    "x-tt-env": "ppe_cn_env_self_test_feat_cr_a",
    "Authorization": "Basic cm40cmFpdTRwenY1cGlsYTo2bWhvOXV3ZXFrOHZpbDllcXRxMHZ1YmVnc2xjeXBucg==",
}

class SingletonMeta(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]

class Clientassign(metaclass=SingletonMeta):
    """
    定义一个全局变量 Client
    该类为单例类，确保整个应用中只有一个实例
    """
    def __init__(self, Clientinfox):

        self.aily_app_id = Clientinfox.get("data_set_ailyappid") or Clientin["aily_app_id"]
        self.app_id = Clientinfox.get("data_set_appid") or Clientin["app_id"]
        self.app_secret = Clientinfox.get("data_set_appsecret") or Clientin["app_secret"]
        self.cookie = Clientinfox.get("data_set_cookie") or Clientin["cookie"]
        self.x_kunlun_token = Clientinfox.get("data_set_kunluntoken") or Clientin["x-kunlun-token"]
        self.x_tt_env = Clientinfox.get("data_set_ppeenv") or Clientin["x-tt-env"]
        self.authorization = Clientinfox.get("data_set_auth") or Clientin["Authorization"]


if __name__ == '__main__':
    Clientinfox = {
        "data_set_ailyappid": "123",
        "data_set_appid": "456",
        "data_set_appsecret": "789",
        "data_set_cookie": "012",
        "data_set_kunluntoken": "345",
        "data_set_ppeenv": "678",
        "data_set_auth": "901",
    }
    b=Clientassign(Clientinfox)



