# Azure AI Inference instrumentation module
