Este módulo permite a exportação dos documentos fiscais por período.
