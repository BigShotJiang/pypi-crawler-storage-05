Abra o menu Fiscal>Contador>Fechamento Fiscal e defina as exportações de documentos fiscais por período.

Obs. No caso de documentos emitidos pelos parceiros, os arquivos exportados serão aqueles que estão como anexo do documento fiscal.
