* `KMEE <https://www.kmee.com.br>`_:

  * Luis Felipe Mileo <mileo@kmee.com.br>
  * Luis Otavio Malta Conceição <luis.malta@kmee.com.br>

* `Akretion <https://www.akretion.com/pt-BR>`_:

  * Renato Lima <renato.lima@akretion.com.br>

* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>
