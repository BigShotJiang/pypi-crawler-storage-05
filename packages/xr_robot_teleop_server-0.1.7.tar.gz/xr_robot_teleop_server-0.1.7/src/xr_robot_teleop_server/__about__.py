name = "xr-robot-teleop-server"
version = "0.1.7"
copyright = "Copyright 2025, Yunho Cho"
