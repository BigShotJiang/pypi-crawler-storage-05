# x6c1 - Hex Translator

A comprehensive command-line tool and Python library for converting between hexadecimal representations and their corresponding text or numeric values with file support.

## Installation

```bash
pip install x6c1
```
