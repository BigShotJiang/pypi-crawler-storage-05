"""Version information for kepler-downloader-dr25"""

__version__ = "1.2.0"