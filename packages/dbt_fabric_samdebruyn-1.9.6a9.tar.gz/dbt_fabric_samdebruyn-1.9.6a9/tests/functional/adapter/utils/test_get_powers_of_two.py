from dbt.tests.adapter.utils.test_get_powers_of_two import BaseGetPowersOfTwo


class TestGetPowersOfTwoFabric(BaseGetPowersOfTwo):
    pass
