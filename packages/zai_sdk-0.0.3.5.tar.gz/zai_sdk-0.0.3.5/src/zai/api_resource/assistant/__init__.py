from zai.api_resource.assistant.assistant import Assistant

__all__ = ['Assistant']
