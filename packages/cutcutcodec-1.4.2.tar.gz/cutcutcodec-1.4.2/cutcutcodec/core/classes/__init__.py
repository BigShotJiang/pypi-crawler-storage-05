#!/usr/bin/env python3

"""Defines the data structure used throughout the rest of the module."""
