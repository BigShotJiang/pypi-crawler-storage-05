#!/usr/bin/env python3

"""Group common propreties to avoid redundency, as a java interface."""
