#!/usr/bin/env python3

"""Contains the models structure."""
