#!/usr/bin/env python3

"""Main neuronal network module."""
