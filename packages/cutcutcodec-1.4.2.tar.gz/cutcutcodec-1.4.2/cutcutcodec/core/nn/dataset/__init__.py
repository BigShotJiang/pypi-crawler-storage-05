#!/usr/bin/env python3

"""Implement some data-loader."""
