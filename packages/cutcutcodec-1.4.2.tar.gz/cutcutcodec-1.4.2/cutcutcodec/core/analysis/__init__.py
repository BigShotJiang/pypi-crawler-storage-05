#!/usr/bin/env python3

"""Explore data to extract information."""
