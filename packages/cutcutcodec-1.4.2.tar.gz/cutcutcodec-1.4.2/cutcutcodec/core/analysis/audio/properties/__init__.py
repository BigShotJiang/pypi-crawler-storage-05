#!/usr/bin/env python3

"""Recover basic audio information."""

from .duration import get_duration_audio


__all__ = ["get_duration_audio"]
