#!/usr/bin/env python3

"""Probe audio data."""

from .properties import get_duration_audio


__all__ = ["get_duration_audio"]
