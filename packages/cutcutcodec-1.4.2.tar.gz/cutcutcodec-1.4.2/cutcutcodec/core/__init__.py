#!/usr/bin/env python3

"""Main module of the cutcutcodec calculation kernel."""
