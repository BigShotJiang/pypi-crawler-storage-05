#!/usr/bin/env python3

"""Clean the cache."""
