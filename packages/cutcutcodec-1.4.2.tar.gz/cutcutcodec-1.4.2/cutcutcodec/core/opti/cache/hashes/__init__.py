#!/usr/bin/env python3

"""Compute the hash of the tree for a fast cache decision tree."""
