#!/usr/bin/env python3

"""Provide tools for managing the duality CPU/GPU as best a possible."""
