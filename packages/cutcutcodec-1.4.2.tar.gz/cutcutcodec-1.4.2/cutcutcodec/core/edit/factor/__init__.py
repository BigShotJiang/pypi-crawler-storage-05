#!/usr/bin/env python3

"""Try to simplify several nodes in one."""
