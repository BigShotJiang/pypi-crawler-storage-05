#!/usr/bin/env python3

"""Define basic operations to manipulate an assembly graph."""
