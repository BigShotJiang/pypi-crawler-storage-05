#!/usr/bin/env python3

"""Allow to transform, edit and perform operations to transform the assembly graph."""
