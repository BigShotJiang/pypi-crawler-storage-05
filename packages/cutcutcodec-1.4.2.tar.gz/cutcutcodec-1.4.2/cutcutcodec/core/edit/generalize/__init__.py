#!/usr/bin/env python3

"""Try to find the general form of each node."""
