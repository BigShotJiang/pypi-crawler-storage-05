#!/usr/bin/env python3

"""Change the number of channels."""
