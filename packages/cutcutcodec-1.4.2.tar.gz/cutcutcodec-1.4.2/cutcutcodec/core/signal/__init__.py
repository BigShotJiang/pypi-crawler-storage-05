#!/usr/bin/env python3

"""Some usefull function for signal processing."""
