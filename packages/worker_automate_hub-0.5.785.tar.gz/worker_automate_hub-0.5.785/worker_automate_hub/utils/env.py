import os 

CREDENTIALS = os.environ.get("CREDENTIALS")