#ifndef __VERSION_HPP__
#define __VERSION_HPP__

#define HCLE_VERSION "0.0.1"
#define HCLE_VERSION_MAJOR "0"
#define HCLE_VERSION_MINOR "0"
#define HCLE_VERSION_PATCH "1"

#define CYNES_VERSION "0.1.0"

#endif // __VERSION_HPP__
