var searchData=
[
  ['new_5fa_0',['new_A',['../classdnscode_1_1dnscode_1_1Zone.html#a231de844d4fb88390d37a0be6dbc962e',1,'dnscode::dnscode::Zone']]],
  ['new_5faaaa_1',['new_AAAA',['../classdnscode_1_1dnscode_1_1Zone.html#af16862a7d8680f1eb6ab66a92105301f',1,'dnscode::dnscode::Zone']]],
  ['new_5fcname_2',['new_CNAME',['../classdnscode_1_1dnscode_1_1Zone.html#a2718e32544f9310ce721bce73082bb97',1,'dnscode::dnscode::Zone']]],
  ['new_5fmx_3',['new_MX',['../classdnscode_1_1dnscode_1_1Zone.html#a41dc247963652b15be123b329aeb1bcf',1,'dnscode::dnscode::Zone']]],
  ['new_5fns_4',['new_NS',['../classdnscode_1_1dnscode_1_1Zone.html#ae0a178b817cb174866bb5bb33507cb98',1,'dnscode::dnscode::Zone']]],
  ['new_5fptr_5',['new_PTR',['../classdnscode_1_1dnscode_1_1Zone.html#a579ec534602081efd30fbcbc279bc625',1,'dnscode::dnscode::Zone']]],
  ['new_5frecord_6',['new_record',['../classdnscode_1_1dnscode_1_1Zone.html#a6ff7d4cb63c08a7d06fc47c341e3bba4',1,'dnscode::dnscode::Zone']]],
  ['new_5fsoa_7',['new_SOA',['../classdnscode_1_1dnscode_1_1Zone.html#aabed9788e2e4be4c6b0628214492fdbe',1,'dnscode::dnscode::Zone']]],
  ['new_5fsrv_8',['new_SRV',['../classdnscode_1_1dnscode_1_1Zone.html#a9b7c828acb3d62f8c677efb4a858ef97',1,'dnscode::dnscode::Zone']]],
  ['new_5ftxt_9',['new_TXT',['../classdnscode_1_1dnscode_1_1Zone.html#a602dd6071a6c3d1017e155c7ca2512a2',1,'dnscode::dnscode::Zone']]]
];
