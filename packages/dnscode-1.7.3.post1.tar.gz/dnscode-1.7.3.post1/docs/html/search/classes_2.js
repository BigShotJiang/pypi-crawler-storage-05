var searchData=
[
  ['invaliddataexception_0',['InvalidDataException',['../classdnscode_1_1dnscode_1_1InvalidDataException.html',1,'dnscode::dnscode']]]
];
