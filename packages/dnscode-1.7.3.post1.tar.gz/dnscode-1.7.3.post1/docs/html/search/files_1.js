var searchData=
[
  ['dnscode_2epy_0',['dnscode.py',['../dnscode_8py.html',1,'']]]
];
