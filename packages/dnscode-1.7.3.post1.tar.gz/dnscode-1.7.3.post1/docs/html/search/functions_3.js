var searchData=
[
  ['save_5ffile_0',['save_file',['../classdnscode_1_1dnscode_1_1Zone.html#adfe5442ed2137a324f1c5ba676ba2043',1,'dnscode::dnscode::Zone']]],
  ['save_5fstdout_1',['save_stdout',['../classdnscode_1_1dnscode_1_1Zone.html#a9c2c7f534d5ab0f841bf4ad2fb62f188',1,'dnscode::dnscode::Zone']]]
];
