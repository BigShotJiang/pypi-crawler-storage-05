var searchData=
[
  ['serial_0',['serial',['../classdnscode_1_1dnscode_1_1SOA.html#add157e2edf998925f74a55fc672616c2',1,'dnscode::dnscode::SOA']]],
  ['service_1',['service',['../classdnscode_1_1dnscode_1_1SRV.html#a365a2b7ffaf0bdc718c49e20940213a0',1,'dnscode::dnscode::SRV']]]
];
