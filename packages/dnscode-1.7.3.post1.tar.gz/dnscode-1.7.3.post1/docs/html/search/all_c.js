var searchData=
[
  ['save_5ffile_0',['save_file',['../classdnscode_1_1dnscode_1_1Zone.html#adfe5442ed2137a324f1c5ba676ba2043',1,'dnscode::dnscode::Zone']]],
  ['save_5fstdout_1',['save_stdout',['../classdnscode_1_1dnscode_1_1Zone.html#a9c2c7f534d5ab0f841bf4ad2fb62f188',1,'dnscode::dnscode::Zone']]],
  ['serial_2',['serial',['../classdnscode_1_1dnscode_1_1SOA.html#add157e2edf998925f74a55fc672616c2',1,'dnscode::dnscode::SOA']]],
  ['service_3',['service',['../classdnscode_1_1dnscode_1_1SRV.html#a365a2b7ffaf0bdc718c49e20940213a0',1,'dnscode::dnscode::SRV']]],
  ['simplifying_20dns_20zone_20management_4',['Simplifying DNS Zone management',['../index.html#autotoc_md1',1,'']]],
  ['soa_5',['SOA',['../classdnscode_1_1dnscode_1_1SOA.html',1,'dnscode::dnscode']]],
  ['srv_6',['SRV',['../classdnscode_1_1dnscode_1_1SRV.html',1,'dnscode::dnscode']]]
];
