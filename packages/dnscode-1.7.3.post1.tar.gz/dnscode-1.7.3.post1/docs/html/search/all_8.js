var searchData=
[
  ['name_0',['name',['../classdnscode_1_1dnscode_1_1Record.html#a0f33da03220ff62ce0b7e61947c1aae9',1,'dnscode.dnscode.Record.name'],['../classdnscode_1_1dnscode_1_1A.html',1,'dnscode.dnscode.A.name'],['../classdnscode_1_1dnscode_1_1AAAA.html',1,'dnscode.dnscode.AAAA.name'],['../classdnscode_1_1dnscode_1_1CNAME.html',1,'dnscode.dnscode.CNAME.name'],['../classdnscode_1_1dnscode_1_1MX.html',1,'dnscode.dnscode.MX.name'],['../classdnscode_1_1dnscode_1_1NS.html',1,'dnscode.dnscode.NS.name'],['../classdnscode_1_1dnscode_1_1PTR.html',1,'dnscode.dnscode.PTR.name'],['../classdnscode_1_1dnscode_1_1SOA.html',1,'dnscode.dnscode.SOA.name'],['../classdnscode_1_1dnscode_1_1SRV.html',1,'dnscode.dnscode.SRV.name'],['../classdnscode_1_1dnscode_1_1TXT.html',1,'dnscode.dnscode.TXT.name']]],
  ['new_5fa_1',['new_A',['../classdnscode_1_1dnscode_1_1Zone.html#a231de844d4fb88390d37a0be6dbc962e',1,'dnscode::dnscode::Zone']]],
  ['new_5faaaa_2',['new_AAAA',['../classdnscode_1_1dnscode_1_1Zone.html#af16862a7d8680f1eb6ab66a92105301f',1,'dnscode::dnscode::Zone']]],
  ['new_5fcname_3',['new_CNAME',['../classdnscode_1_1dnscode_1_1Zone.html#a2718e32544f9310ce721bce73082bb97',1,'dnscode::dnscode::Zone']]],
  ['new_5fmx_4',['new_MX',['../classdnscode_1_1dnscode_1_1Zone.html#a41dc247963652b15be123b329aeb1bcf',1,'dnscode::dnscode::Zone']]],
  ['new_5fns_5',['new_NS',['../classdnscode_1_1dnscode_1_1Zone.html#ae0a178b817cb174866bb5bb33507cb98',1,'dnscode::dnscode::Zone']]],
  ['new_5fptr_6',['new_PTR',['../classdnscode_1_1dnscode_1_1Zone.html#a579ec534602081efd30fbcbc279bc625',1,'dnscode::dnscode::Zone']]],
  ['new_5frecord_7',['new_record',['../classdnscode_1_1dnscode_1_1Zone.html#a6ff7d4cb63c08a7d06fc47c341e3bba4',1,'dnscode::dnscode::Zone']]],
  ['new_5fsoa_8',['new_SOA',['../classdnscode_1_1dnscode_1_1Zone.html#aabed9788e2e4be4c6b0628214492fdbe',1,'dnscode::dnscode::Zone']]],
  ['new_5fsrv_9',['new_SRV',['../classdnscode_1_1dnscode_1_1Zone.html#a9b7c828acb3d62f8c677efb4a858ef97',1,'dnscode::dnscode::Zone']]],
  ['new_5ftxt_10',['new_TXT',['../classdnscode_1_1dnscode_1_1Zone.html#a602dd6071a6c3d1017e155c7ca2512a2',1,'dnscode::dnscode::Zone']]],
  ['ns_11',['NS',['../classdnscode_1_1dnscode_1_1NS.html',1,'dnscode::dnscode']]]
];
