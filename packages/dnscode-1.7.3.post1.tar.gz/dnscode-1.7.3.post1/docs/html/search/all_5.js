var searchData=
[
  ['host_0',['host',['../classdnscode_1_1dnscode_1_1MX.html#a467154486271ccfc3bdfb8edfebd33ba',1,'dnscode.dnscode.MX.host'],['../classdnscode_1_1dnscode_1_1NS.html#aa418dd4df63fed40a6f37077f61f502e',1,'dnscode.dnscode.NS.host'],['../classdnscode_1_1dnscode_1_1SRV.html#a135e00e809ece952d3b15964f97a0714',1,'dnscode.dnscode.SRV.host']]]
];
