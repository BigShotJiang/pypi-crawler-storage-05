var searchData=
[
  ['port_0',['port',['../classdnscode_1_1dnscode_1_1SRV.html#a43cb8d9167030aecbcd03d73ef536f1d',1,'dnscode::dnscode::SRV']]],
  ['priority_1',['priority',['../classdnscode_1_1dnscode_1_1MX.html#af5955c1d1b6c2bbbf9331ede00e9f814',1,'dnscode.dnscode.MX.priority'],['../classdnscode_1_1dnscode_1_1SRV.html#a84d67e5dbb4cd6cf98e66401e2d7d7a4',1,'dnscode.dnscode.SRV.priority']]],
  ['protocol_2',['protocol',['../classdnscode_1_1dnscode_1_1SRV.html#a369bc7ff3b95a5250b9cb3db23bef840',1,'dnscode::dnscode::SRV']]],
  ['ptr_3',['PTR',['../classdnscode_1_1dnscode_1_1PTR.html',1,'dnscode::dnscode']]]
];
