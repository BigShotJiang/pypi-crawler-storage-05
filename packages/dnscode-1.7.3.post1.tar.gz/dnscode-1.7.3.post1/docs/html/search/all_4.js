var searchData=
[
  ['expire_0',['expire',['../classdnscode_1_1dnscode_1_1SOA.html#aa1db92c41ea81f1a993bf94673fb8df2',1,'dnscode::dnscode::SOA']]]
];
