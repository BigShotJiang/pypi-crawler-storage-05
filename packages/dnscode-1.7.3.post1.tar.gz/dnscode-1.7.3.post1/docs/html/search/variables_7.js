var searchData=
[
  ['rclass_0',['rclass',['../classdnscode_1_1dnscode_1_1Record.html#aedb647dcc5a07491d105b5550cfaf28d',1,'dnscode::dnscode::Record']]],
  ['records_1',['records',['../classdnscode_1_1dnscode_1_1Zone.html#a8e3137b233ce53fed0a87915be1b1fcd',1,'dnscode::dnscode::Zone']]],
  ['refresh_2',['refresh',['../classdnscode_1_1dnscode_1_1SOA.html#a78c16bb26cea2e23329499b1be27744f',1,'dnscode::dnscode::SOA']]],
  ['retry_3',['retry',['../classdnscode_1_1dnscode_1_1SOA.html#a0519536bbe01453e69e9b3a937734e05',1,'dnscode::dnscode::SOA']]],
  ['rname_4',['rname',['../classdnscode_1_1dnscode_1_1SOA.html#a2d07bdbe2641a211cac2a638682003f7',1,'dnscode::dnscode::SOA']]],
  ['rtype_5',['rtype',['../classdnscode_1_1dnscode_1_1Record.html#a13073663684cfa4c84b7bc6c3551a622',1,'dnscode.dnscode.Record.rtype'],['../classdnscode_1_1dnscode_1_1A.html',1,'dnscode.dnscode.A.rtype'],['../classdnscode_1_1dnscode_1_1AAAA.html',1,'dnscode.dnscode.AAAA.rtype'],['../classdnscode_1_1dnscode_1_1CNAME.html',1,'dnscode.dnscode.CNAME.rtype'],['../classdnscode_1_1dnscode_1_1MX.html',1,'dnscode.dnscode.MX.rtype'],['../classdnscode_1_1dnscode_1_1NS.html',1,'dnscode.dnscode.NS.rtype'],['../classdnscode_1_1dnscode_1_1PTR.html',1,'dnscode.dnscode.PTR.rtype'],['../classdnscode_1_1dnscode_1_1SOA.html',1,'dnscode.dnscode.SOA.rtype'],['../classdnscode_1_1dnscode_1_1SRV.html',1,'dnscode.dnscode.SRV.rtype'],['../classdnscode_1_1dnscode_1_1TXT.html',1,'dnscode.dnscode.TXT.rtype']]]
];
