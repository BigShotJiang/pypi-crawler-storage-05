var searchData=
[
  ['installation_0',['Installation',['../index.html#autotoc_md4',1,'']]],
  ['invaliddataexception_1',['InvalidDataException',['../classdnscode_1_1dnscode_1_1InvalidDataException.html',1,'dnscode::dnscode']]]
];
