var searchData=
[
  ['origin_0',['origin',['../classdnscode_1_1dnscode_1_1Zone.html#a9edba14298d59d7453cc27786b57f457',1,'dnscode::dnscode::Zone']]]
];
