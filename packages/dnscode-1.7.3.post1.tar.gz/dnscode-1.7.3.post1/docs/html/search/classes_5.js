var searchData=
[
  ['ptr_0',['PTR',['../classdnscode_1_1dnscode_1_1PTR.html',1,'dnscode::dnscode']]]
];
