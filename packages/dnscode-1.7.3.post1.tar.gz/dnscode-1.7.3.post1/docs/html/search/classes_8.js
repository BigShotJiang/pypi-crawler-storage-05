var searchData=
[
  ['txt_0',['TXT',['../classdnscode_1_1dnscode_1_1TXT.html',1,'dnscode::dnscode']]]
];
