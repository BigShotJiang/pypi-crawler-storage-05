var searchData=
[
  ['management_0',['Simplifying DNS Zone management',['../index.html#autotoc_md1',1,'']]],
  ['message_1',['message',['../classdnscode_1_1dnscode_1_1InvalidDataException.html#abe6f6a4e6ebc59a440ebbc43330e3811',1,'dnscode::dnscode::InvalidDataException']]],
  ['mname_2',['mname',['../classdnscode_1_1dnscode_1_1SOA.html#aa8ccf7ebc102ae4493f630e3f85dab33',1,'dnscode::dnscode::SOA']]],
  ['mx_3',['MX',['../classdnscode_1_1dnscode_1_1MX.html',1,'dnscode::dnscode']]]
];
