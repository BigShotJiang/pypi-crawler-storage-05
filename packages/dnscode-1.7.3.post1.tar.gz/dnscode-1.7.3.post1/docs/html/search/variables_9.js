var searchData=
[
  ['ttl_0',['ttl',['../classdnscode_1_1dnscode_1_1Record.html#a875d04fc6789b0e36e0b56dbfa8aa7b8',1,'dnscode.dnscode.Record.ttl'],['../classdnscode_1_1dnscode_1_1A.html',1,'dnscode.dnscode.A.ttl'],['../classdnscode_1_1dnscode_1_1AAAA.html',1,'dnscode.dnscode.AAAA.ttl'],['../classdnscode_1_1dnscode_1_1CNAME.html',1,'dnscode.dnscode.CNAME.ttl'],['../classdnscode_1_1dnscode_1_1MX.html',1,'dnscode.dnscode.MX.ttl'],['../classdnscode_1_1dnscode_1_1NS.html',1,'dnscode.dnscode.NS.ttl'],['../classdnscode_1_1dnscode_1_1PTR.html',1,'dnscode.dnscode.PTR.ttl'],['../classdnscode_1_1dnscode_1_1SOA.html',1,'dnscode.dnscode.SOA.ttl'],['../classdnscode_1_1dnscode_1_1SRV.html',1,'dnscode.dnscode.SRV.ttl'],['../classdnscode_1_1dnscode_1_1TXT.html',1,'dnscode.dnscode.TXT.ttl']]]
];
