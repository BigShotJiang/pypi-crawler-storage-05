var hierarchy =
[
    [ "Exception", null, [
      [ "dnscode.dnscode.InvalidDataException", "classdnscode_1_1dnscode_1_1InvalidDataException.html", null ]
    ] ],
    [ "dnscode.dnscode.Record", "classdnscode_1_1dnscode_1_1Record.html", [
      [ "dnscode.dnscode.A", "classdnscode_1_1dnscode_1_1A.html", null ],
      [ "dnscode.dnscode.AAAA", "classdnscode_1_1dnscode_1_1AAAA.html", null ],
      [ "dnscode.dnscode.CNAME", "classdnscode_1_1dnscode_1_1CNAME.html", null ],
      [ "dnscode.dnscode.MX", "classdnscode_1_1dnscode_1_1MX.html", null ],
      [ "dnscode.dnscode.NS", "classdnscode_1_1dnscode_1_1NS.html", null ],
      [ "dnscode.dnscode.PTR", "classdnscode_1_1dnscode_1_1PTR.html", null ],
      [ "dnscode.dnscode.SOA", "classdnscode_1_1dnscode_1_1SOA.html", null ],
      [ "dnscode.dnscode.SRV", "classdnscode_1_1dnscode_1_1SRV.html", null ],
      [ "dnscode.dnscode.TXT", "classdnscode_1_1dnscode_1_1TXT.html", null ]
    ] ],
    [ "dnscode.dnscode.Zone", "classdnscode_1_1dnscode_1_1Zone.html", null ]
];