var classdnscode_1_1dnscode_1_1Zone =
[
    [ "__post_init__", "classdnscode_1_1dnscode_1_1Zone.html#ad696206776c2c68471126d950fa178d1", null ],
    [ "__str__", "classdnscode_1_1dnscode_1_1Zone.html#a31e74a07a8f0b0f95a14662d20f1df8c", null ],
    [ "add", "classdnscode_1_1dnscode_1_1Zone.html#a338bc686b7c7db2cab7827996a3f23f3", null ],
    [ "new_A", "classdnscode_1_1dnscode_1_1Zone.html#a231de844d4fb88390d37a0be6dbc962e", null ],
    [ "new_AAAA", "classdnscode_1_1dnscode_1_1Zone.html#af16862a7d8680f1eb6ab66a92105301f", null ],
    [ "new_CNAME", "classdnscode_1_1dnscode_1_1Zone.html#a2718e32544f9310ce721bce73082bb97", null ],
    [ "new_MX", "classdnscode_1_1dnscode_1_1Zone.html#a41dc247963652b15be123b329aeb1bcf", null ],
    [ "new_NS", "classdnscode_1_1dnscode_1_1Zone.html#ae0a178b817cb174866bb5bb33507cb98", null ],
    [ "new_PTR", "classdnscode_1_1dnscode_1_1Zone.html#a579ec534602081efd30fbcbc279bc625", null ],
    [ "new_record", "classdnscode_1_1dnscode_1_1Zone.html#a6ff7d4cb63c08a7d06fc47c341e3bba4", null ],
    [ "new_SOA", "classdnscode_1_1dnscode_1_1Zone.html#aabed9788e2e4be4c6b0628214492fdbe", null ],
    [ "new_SRV", "classdnscode_1_1dnscode_1_1Zone.html#a9b7c828acb3d62f8c677efb4a858ef97", null ],
    [ "new_TXT", "classdnscode_1_1dnscode_1_1Zone.html#a602dd6071a6c3d1017e155c7ca2512a2", null ],
    [ "save_file", "classdnscode_1_1dnscode_1_1Zone.html#adfe5442ed2137a324f1c5ba676ba2043", null ],
    [ "save_stdout", "classdnscode_1_1dnscode_1_1Zone.html#a9c2c7f534d5ab0f841bf4ad2fb62f188", null ]
];