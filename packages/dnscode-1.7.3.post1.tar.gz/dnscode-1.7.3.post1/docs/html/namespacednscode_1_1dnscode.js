var namespacednscode_1_1dnscode =
[
    [ "A", "classdnscode_1_1dnscode_1_1A.html", "classdnscode_1_1dnscode_1_1A" ],
    [ "AAAA", "classdnscode_1_1dnscode_1_1AAAA.html", "classdnscode_1_1dnscode_1_1AAAA" ],
    [ "CNAME", "classdnscode_1_1dnscode_1_1CNAME.html", "classdnscode_1_1dnscode_1_1CNAME" ],
    [ "InvalidDataException", "classdnscode_1_1dnscode_1_1InvalidDataException.html", "classdnscode_1_1dnscode_1_1InvalidDataException" ],
    [ "MX", "classdnscode_1_1dnscode_1_1MX.html", "classdnscode_1_1dnscode_1_1MX" ],
    [ "NS", "classdnscode_1_1dnscode_1_1NS.html", "classdnscode_1_1dnscode_1_1NS" ],
    [ "PTR", "classdnscode_1_1dnscode_1_1PTR.html", "classdnscode_1_1dnscode_1_1PTR" ],
    [ "Record", "classdnscode_1_1dnscode_1_1Record.html", "classdnscode_1_1dnscode_1_1Record" ],
    [ "SOA", "classdnscode_1_1dnscode_1_1SOA.html", "classdnscode_1_1dnscode_1_1SOA" ],
    [ "SRV", "classdnscode_1_1dnscode_1_1SRV.html", "classdnscode_1_1dnscode_1_1SRV" ],
    [ "TXT", "classdnscode_1_1dnscode_1_1TXT.html", "classdnscode_1_1dnscode_1_1TXT" ],
    [ "Zone", "classdnscode_1_1dnscode_1_1Zone.html", "classdnscode_1_1dnscode_1_1Zone" ]
];