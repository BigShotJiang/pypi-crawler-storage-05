var classdnscode_1_1dnscode_1_1PTR =
[
    [ "__init__", "classdnscode_1_1dnscode_1_1PTR.html#a97e7c140d6bd930a2611e68753a0d8eb", null ]
];