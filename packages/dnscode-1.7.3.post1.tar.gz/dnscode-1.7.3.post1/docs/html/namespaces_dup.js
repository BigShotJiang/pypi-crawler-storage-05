var namespaces_dup =
[
    [ "dnscode", "namespacednscode.html", "namespacednscode" ]
];