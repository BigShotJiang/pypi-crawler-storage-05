var classdnscode_1_1dnscode_1_1SRV =
[
    [ "__init__", "classdnscode_1_1dnscode_1_1SRV.html#a488bf7130d42c3eb3316cf9903d5454e", null ],
    [ "host", "classdnscode_1_1dnscode_1_1SRV.html#a135e00e809ece952d3b15964f97a0714", null ],
    [ "port", "classdnscode_1_1dnscode_1_1SRV.html#a43cb8d9167030aecbcd03d73ef536f1d", null ],
    [ "priority", "classdnscode_1_1dnscode_1_1SRV.html#a84d67e5dbb4cd6cf98e66401e2d7d7a4", null ],
    [ "protocol", "classdnscode_1_1dnscode_1_1SRV.html#a369bc7ff3b95a5250b9cb3db23bef840", null ],
    [ "service", "classdnscode_1_1dnscode_1_1SRV.html#a365a2b7ffaf0bdc718c49e20940213a0", null ],
    [ "weight", "classdnscode_1_1dnscode_1_1SRV.html#a8612b39fe2585831e7069dcb044ffa75", null ]
];