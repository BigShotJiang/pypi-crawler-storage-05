var classdnscode_1_1dnscode_1_1InvalidDataException =
[
    [ "__init__", "classdnscode_1_1dnscode_1_1InvalidDataException.html#ae0a05fa4d708dd9eab0c1ead5b2098a8", null ],
    [ "message", "classdnscode_1_1dnscode_1_1InvalidDataException.html#abe6f6a4e6ebc59a440ebbc43330e3811", null ]
];