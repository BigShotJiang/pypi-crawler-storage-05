var classdnscode_1_1dnscode_1_1SOA =
[
    [ "__init__", "classdnscode_1_1dnscode_1_1SOA.html#a3318d09d5bead318b42aa9f939262982", null ],
    [ "expire", "classdnscode_1_1dnscode_1_1SOA.html#aa1db92c41ea81f1a993bf94673fb8df2", null ],
    [ "mname", "classdnscode_1_1dnscode_1_1SOA.html#aa8ccf7ebc102ae4493f630e3f85dab33", null ],
    [ "refresh", "classdnscode_1_1dnscode_1_1SOA.html#a78c16bb26cea2e23329499b1be27744f", null ],
    [ "retry", "classdnscode_1_1dnscode_1_1SOA.html#a0519536bbe01453e69e9b3a937734e05", null ],
    [ "rname", "classdnscode_1_1dnscode_1_1SOA.html#a2d07bdbe2641a211cac2a638682003f7", null ],
    [ "serial", "classdnscode_1_1dnscode_1_1SOA.html#add157e2edf998925f74a55fc672616c2", null ]
];