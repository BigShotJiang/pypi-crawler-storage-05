var classdnscode_1_1dnscode_1_1NS =
[
    [ "__init__", "classdnscode_1_1dnscode_1_1NS.html#a30214975313b4fdc1af03b45cc2bd414", null ],
    [ "host", "classdnscode_1_1dnscode_1_1NS.html#aa418dd4df63fed40a6f37077f61f502e", null ]
];