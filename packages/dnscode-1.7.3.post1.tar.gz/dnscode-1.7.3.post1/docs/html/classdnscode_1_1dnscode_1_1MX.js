var classdnscode_1_1dnscode_1_1MX =
[
    [ "__init__", "classdnscode_1_1dnscode_1_1MX.html#a4dafe8f75646ca4ec6e2ea77a2d838f5", null ],
    [ "host", "classdnscode_1_1dnscode_1_1MX.html#a467154486271ccfc3bdfb8edfebd33ba", null ],
    [ "priority", "classdnscode_1_1dnscode_1_1MX.html#af5955c1d1b6c2bbbf9331ede00e9f814", null ]
];