var dir_9064fec3e9ce615219688699dadf995c =
[
    [ "__init__.py", "____init_____8py.html", null ],
    [ "dnscode.py", "dnscode_8py.html", "dnscode_8py" ]
];