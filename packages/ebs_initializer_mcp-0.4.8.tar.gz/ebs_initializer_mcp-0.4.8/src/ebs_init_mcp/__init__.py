"""EBS Volume Initialization MCP Server

A Model Context Protocol (MCP) server for automating AWS EBS volume initialization.
"""

__version__ = "0.1.0"