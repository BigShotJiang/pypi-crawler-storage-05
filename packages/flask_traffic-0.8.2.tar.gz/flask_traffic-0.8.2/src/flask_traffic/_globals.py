IGNORE_LOCALS = (
    "on_endpoints",
    "skip_endpoints",
    "on_status_codes",
    "skip_status_codes",
    "only_on_exception",
    "skip_on_exception",
    "max_request_path_length",
)
