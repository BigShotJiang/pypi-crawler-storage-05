from TCT.server import mcp

def main():
    """Entry point for tct-server script"""
    mcp.run()

if __name__ == "__main__":
    main()