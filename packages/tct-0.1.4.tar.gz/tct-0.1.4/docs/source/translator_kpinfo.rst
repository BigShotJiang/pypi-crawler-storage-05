TCT.translator_kpinfo
=====================
.. automodule:: TCT.translator_kpinfo
   :members:
