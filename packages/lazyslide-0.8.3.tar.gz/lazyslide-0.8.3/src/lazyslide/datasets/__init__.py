from ._sample import (
    gtex_artery,
    gtex_small_intestine,
    lung_carcinoma,
    sample,
)
