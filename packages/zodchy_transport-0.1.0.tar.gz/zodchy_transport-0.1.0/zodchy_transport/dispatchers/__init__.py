from .rabbitmq import RabbitDispatcher

__all__ = ["RabbitDispatcher"]
