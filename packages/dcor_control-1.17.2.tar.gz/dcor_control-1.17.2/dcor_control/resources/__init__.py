import pathlib

resource_location = pathlib.Path(__file__).parent.resolve()
