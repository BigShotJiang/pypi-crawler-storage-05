from .base_pruner import BasePruner

MetaPruner=BasePruner # deprecated, for compatibility
MagnitudePruner=BasePruner # deprecated, for compatibility