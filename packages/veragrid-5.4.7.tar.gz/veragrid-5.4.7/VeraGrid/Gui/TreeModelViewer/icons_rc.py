# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.7.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x08\xe6\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22p\
lus.svg\x22\x0a   inks\
cape:version=\x220.\
92.4 (unknown)\x22>\
\x0a  <metadata\x0a   \
  id=\x22metadata8\x22\
>\x0a    <rdf:RDF>\x0a\
      <cc:Work\x0a \
        rdf:abou\
t=\x22\x22>\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0a        <dc:t\
ype\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0a        \
<dc:title />\x0a   \
   </cc:Work>\x0a  \
  </rdf:RDF>\x0a  <\
/metadata>\x0a  <de\
fs\x0a     id=\x22defs\
6\x22 />\x0a  <sodipod\
i:namedview\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#666666\x22\x0a\
     borderopaci\
ty=\x221\x22\x0a     obje\
cttolerance=\x2210\x22\
\x0a     gridtolera\
nce=\x2210\x22\x0a     gu\
idetolerance=\x2210\
\x22\x0a     inkscape:\
pageopacity=\x220\x22\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0a   \
  inkscape:windo\
w-width=\x221863\x22\x0a \
    inkscape:win\
dow-height=\x221025\
\x22\x0a     id=\x22named\
view4\x22\x0a     show\
grid=\x22false\x22\x0a   \
  inkscape:zoom=\
\x221.7383042\x22\x0a    \
 inkscape:cx=\x22-2\
13.83542\x22\x0a     i\
nkscape:cy=\x22209.\
44504\x22\x0a     inks\
cape:window-x=\x225\
7\x22\x0a     inkscape\
:window-y=\x2227\x22\x0a \
    inkscape:win\
dow-maximized=\x221\
\x22\x0a     inkscape:\
current-layer=\x22s\
vg2\x22 />\x0a  <g\x0a   \
  id=\x22g831\x22\x0a    \
 style=\x22stroke:#\
37c8ab;stroke-li\
necap:round;stro\
ke-opacity:1\x22>\x0a \
   <path\x0a       \
sodipodi:nodetyp\
es=\x22cc\x22\x0a       i\
nkscape:connecto\
r-curvature=\x220\x22\x0a\
       id=\x22path8\
12\x22\x0a       d=\x22m \
95.091973,56.172\
243 0.09447,79.7\
95097\x22\x0a       st\
yle=\x22fill:none;f\
ill-rule:evenodd\
;stroke:#37c8ab;\
stroke-width:16;\
stroke-linecap:r\
ound;stroke-line\
join:miter;strok\
e-miterlimit:4;s\
troke-dasharray:\
none;stroke-opac\
ity:1\x22 />\x0a    <p\
ath\x0a       sodip\
odi:nodetypes=\x22c\
c\x22\x0a       inksca\
pe:connector-cur\
vature=\x220\x22\x0a     \
  id=\x22path812-3\x22\
\x0a       d=\x22m 134\
.96147,95.594487\
 -79.795108,0.09\
45\x22\x0a       style\
=\x22fill:none;fill\
-rule:evenodd;st\
roke:#37c8ab;str\
oke-width:16;str\
oke-linecap:roun\
d;stroke-linejoi\
n:miter;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-opacity\
:1\x22 />\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x07}\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   inks\
cape:version=\x221.\
0 (4035a4fb49, 2\
020-05-01)\x22\x0a   s\
odipodi:docname=\
\x22down.svg\x22\x0a   id\
=\x22svg6\x22\x0a   versi\
on=\x221.1\x22\x0a   view\
Box=\x220 0 48 48\x22\x0a\
   height=\x2248\x22\x0a \
  width=\x2248\x22>\x0a  \
<metadata\x0a     i\
d=\x22metadata12\x22>\x0a\
    <rdf:RDF>\x0a  \
    <cc:Work\x0a   \
      rdf:about=\
\x22\x22>\x0a        <dc:\
format>image/svg\
+xml</dc:format>\
\x0a        <dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0a        <d\
c:title />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs10\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
inkscape:documen\
t-rotation=\x220\x22\x0a \
    inkscape:cur\
rent-layer=\x22svg6\
\x22\x0a     inkscape:\
window-maximized\
=\x221\x22\x0a     inksca\
pe:window-y=\x2226\x22\
\x0a     inkscape:w\
indow-x=\x2260\x22\x0a   \
  inkscape:cy=\x222\
4\x22\x0a     inkscape\
:cx=\x22-34.05977\x22\x0a\
     inkscape:zo\
om=\x224.9166667\x22\x0a \
    showgrid=\x22fa\
lse\x22\x0a     id=\x22na\
medview8\x22\x0a     i\
nkscape:window-h\
eight=\x221017\x22\x0a   \
  inkscape:windo\
w-width=\x221860\x22\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0a    \
 inkscape:pageop\
acity=\x220\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     gridtole\
rance=\x2210\x22\x0a     \
objecttolerance=\
\x2210\x22\x0a     border\
opacity=\x221\x22\x0a    \
 bordercolor=\x22#6\
66666\x22\x0a     page\
color=\x22#ffffff\x22 \
/>\x0a  <path\x0a     \
fill=\x22none\x22\x0a    \
 id=\x22path2\x22\x0a    \
 d=\x22M0 0h48v48h-\
48z\x22 />\x0a  <path\x0a\
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a     id=\x22p\
ath4489\x22\x0a     d=\
\x22M 7.6708428,9.3\
577254 40.934572\
,9.2064897 23.56\
5339,38.459516 Z\
\x22\x0a     style=\x22fi\
ll:#cccccc;fill-\
rule:evenodd;str\
oke:none;stroke-\
width:2.973;stro\
ke-linecap:butt;\
stroke-linejoin:\
round;stroke-mit\
erlimit:4;stroke\
-dasharray:none;\
stroke-opacity:1\
;paint-order:str\
oke fill markers\
\x22 />\x0a</svg>\x0a\
\x00\x00\x09,\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22p\
lus (gray).svg\x22\x0a\
   inkscape:vers\
ion=\x220.92.4 (unk\
nown)\x22>\x0a  <metad\
ata\x0a     id=\x22met\
adata8\x22>\x0a    <rd\
f:RDF>\x0a      <cc\
:Work\x0a         r\
df:about=\x22\x22>\x0a   \
     <dc:format>\
image/svg+xml</d\
c:format>\x0a      \
  <dc:type\x0a     \
      rdf:resour\
ce=\x22http://purl.\
org/dc/dcmitype/\
StillImage\x22 />\x0a \
       <dc:title\
 />\x0a      </cc:W\
ork>\x0a    </rdf:R\
DF>\x0a  </metadata\
>\x0a  <defs\x0a     i\
d=\x22defs6\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     pagecolo\
r=\x22#ffffff\x22\x0a    \
 bordercolor=\x22#6\
66666\x22\x0a     bord\
eropacity=\x221\x22\x0a  \
   objecttoleran\
ce=\x2210\x22\x0a     gri\
dtolerance=\x2210\x22\x0a\
     guidetolera\
nce=\x2210\x22\x0a     in\
kscape:pageopaci\
ty=\x220\x22\x0a     inks\
cape:pageshadow=\
\x222\x22\x0a     inkscap\
e:window-width=\x22\
1863\x22\x0a     inksc\
ape:window-heigh\
t=\x221025\x22\x0a     id\
=\x22namedview4\x22\x0a  \
   showgrid=\x22fal\
se\x22\x0a     inkscap\
e:zoom=\x221.738304\
2\x22\x0a     inkscape\
:cx=\x22133.79315\x22\x0a\
     inkscape:cy\
=\x2271.379447\x22\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0a     in\
kscape:window-y=\
\x2227\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg2\x22 />\x0a  \
<g\x0a     id=\x22g831\
\x22\x0a     style=\x22st\
roke:#aeaeae;str\
oke-linecap:roun\
d;stroke-opacity\
:1;fill:#aeaeae;\
fill-opacity:1\x22>\
\x0a    <path\x0a     \
  sodipodi:nodet\
ypes=\x22cc\x22\x0a      \
 inkscape:connec\
tor-curvature=\x220\
\x22\x0a       id=\x22pat\
h812\x22\x0a       d=\x22\
m 95.091973,56.1\
72243 0.09447,79\
.795097\x22\x0a       \
style=\x22fill:#aea\
eae;fill-rule:ev\
enodd;stroke:#ae\
aeae;stroke-widt\
h:16;stroke-line\
cap:round;stroke\
-linejoin:miter;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1;fill-\
opacity:1\x22 />\x0a  \
  <path\x0a       s\
odipodi:nodetype\
s=\x22cc\x22\x0a       in\
kscape:connector\
-curvature=\x220\x22\x0a \
      id=\x22path81\
2-3\x22\x0a       d=\x22m\
 134.96147,95.59\
4487 -79.795108,\
0.0945\x22\x0a       s\
tyle=\x22fill:#aeae\
ae;fill-rule:eve\
nodd;stroke:#aea\
eae;stroke-width\
:16;stroke-linec\
ap:round;stroke-\
linejoin:miter;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
opacity:1;fill-o\
pacity:1\x22 />\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x07\x1b\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg4\x22\x0a   so\
dipodi:docname=\x22\
ic_extension_48p\
x.svg\x22\x0a   inksca\
pe:version=\x220.92\
.3 (2405546, 201\
8-03-11)\x22>\x0a  <me\
tadata\x0a     id=\x22\
metadata10\x22>\x0a   \
 <rdf:RDF>\x0a     \
 <cc:Work\x0a      \
   rdf:about=\x22\x22>\
\x0a        <dc:for\
mat>image/svg+xm\
l</dc:format>\x0a  \
      <dc:type\x0a \
          rdf:re\
source=\x22http://p\
url.org/dc/dcmit\
ype/StillImage\x22 \
/>\x0a      </cc:Wo\
rk>\x0a    </rdf:RD\
F>\x0a  </metadata>\
\x0a  <defs\x0a     id\
=\x22defs8\x22 />\x0a  <s\
odipodi:namedvie\
w\x0a     pagecolor\
=\x22#ffffff\x22\x0a     \
bordercolor=\x22#66\
6666\x22\x0a     borde\
ropacity=\x221\x22\x0a   \
  objecttoleranc\
e=\x2210\x22\x0a     grid\
tolerance=\x2210\x22\x0a \
    guidetoleran\
ce=\x2210\x22\x0a     ink\
scape:pageopacit\
y=\x220\x22\x0a     inksc\
ape:pageshadow=\x22\
2\x22\x0a     inkscape\
:window-width=\x221\
055\x22\x0a     inksca\
pe:window-height\
=\x22803\x22\x0a     id=\x22\
namedview6\x22\x0a    \
 showgrid=\x22false\
\x22\x0a     inkscape:\
zoom=\x224.9166667\x22\
\x0a     inkscape:c\
x=\x2221.050847\x22\x0a  \
   inkscape:cy=\x22\
24\x22\x0a     inkscap\
e:window-x=\x2269\x22\x0a\
     inkscape:wi\
ndow-y=\x2227\x22\x0a    \
 inkscape:window\
-maximized=\x220\x22\x0a \
    inkscape:cur\
rent-layer=\x22svg4\
\x22 />\x0a  <path\x0a   \
  d=\x22M41 22h-3v-\
8c0-2.21-1.79-4-\
4-4h-8V7c0-2.76-\
2.24-5-5-5s-5 2.\
24-5 5v3H8c-2.21\
 0-3.98 1.79-3.9\
8 4l-.01 7.6H7c2\
.98 0 5.4 2.42 5\
.4 5.4S9.98 32.4\
 7 32.4H4.01L4 4\
0c0 2.21 1.79 4 \
4 4h7.6v-3c0-2.9\
8 2.42-5.4 5.4-5\
.4 2.98 0 5.4 2.\
42 5.4 5.4v3H34c\
2.21 0 4-1.79 4-\
4v-8h3c2.76 0 5-\
2.24 5-5s-2.24-5\
-5-5z\x22\x0a     id=\x22\
path2\x22\x0a     styl\
e=\x22fill:#999999;\
fill-opacity:1\x22 \
/>\x0a</svg>\x0a\
\x00\x00\x0c\xce\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg6\x22\x0a   so\
dipodi:docname=\x22\
undo.svg\x22\x0a   ink\
scape:version=\x220\
.92.3 (2405546, \
2018-03-11)\x22>\x0a  \
<metadata\x0a     i\
d=\x22metadata12\x22>\x0a\
    <rdf:RDF>\x0a  \
    <cc:Work\x0a   \
      rdf:about=\
\x22\x22>\x0a        <dc:\
format>image/svg\
+xml</dc:format>\
\x0a        <dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0a        <d\
c:title />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs10\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#666666\x22\x0a \
    borderopacit\
y=\x221\x22\x0a     objec\
ttolerance=\x2210\x22\x0a\
     gridtoleran\
ce=\x2210\x22\x0a     gui\
detolerance=\x2210\x22\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0a    \
 inkscape:window\
-width=\x22904\x22\x0a   \
  inkscape:windo\
w-height=\x22427\x22\x0a \
    id=\x22namedvie\
w8\x22\x0a     showgri\
d=\x22false\x22\x0a     i\
nkscape:zoom=\x224.\
9166667\x22\x0a     in\
kscape:cx=\x2224\x22\x0a \
    inkscape:cy=\
\x2233.15853\x22\x0a     \
inkscape:window-\
x=\x22554\x22\x0a     ink\
scape:window-y=\x22\
553\x22\x0a     inksca\
pe:window-maximi\
zed=\x220\x22\x0a     ink\
scape:current-la\
yer=\x22g820\x22 />\x0a  \
<path\x0a     d=\x22M0\
 0h48v48h-48z\x22\x0a \
    id=\x22path2\x22\x0a \
    fill=\x22none\x22 \
/>\x0a  <g\x0a     id=\
\x22g820\x22\x0a     tran\
sform=\x22matrix(0.\
66577573,0,0,0.6\
7580692,171.1283\
1,3.1164509)\x22\x0a  \
   style=\x22stroke\
:#37c8ab\x22>\x0a    <\
path\x0a       sodi\
podi:nodetypes=\x22\
csc\x22\x0a       inks\
cape:connector-c\
urvature=\x220\x22\x0a   \
    id=\x22path816\x22\
\x0a       d=\x22m -24\
3.25424,36.20339\
 c 7.47466,23.42\
7449 32.21453,21\
.503685 40.62787\
,8.634724 8.4108\
6,-12.865143 1.3\
1409,-37.4864107\
 -28.0177,-31.00\
7606\x22\x0a       sty\
le=\x22fill:none;fi\
ll-rule:evenodd;\
stroke:#37c8ab;s\
troke-width:6;st\
roke-linecap:rou\
nd;stroke-linejo\
in:miter;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne;stroke-opacit\
y:1\x22 />\x0a    <pat\
h\x0a       inkscap\
e:connector-curv\
ature=\x220\x22\x0a      \
 id=\x22path4489\x22\x0a \
      d=\x22m -225.\
0508,25.423733 0\
.20339,-22.37288\
18 -19.72881,11.\
5932198 z\x22\x0a     \
  style=\x22fill:#3\
7c8ab;fill-rule:\
evenodd;stroke:#\
37c8ab;stroke-wi\
dth:2;stroke-lin\
ecap:butt;stroke\
-linejoin:round;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22 />\x0a \
 </g>\x0a  <g\x0a     \
id=\x22g820-3\x22\x0a    \
 transform=\x22matr\
ix(-0.66577573,0\
,0,0.67580692,-3\
34.44009,-10.682\
883)\x22>\x0a    <path\
\x0a       sodipodi\
:nodetypes=\x22csc\x22\
\x0a       inkscape\
:connector-curva\
ture=\x220\x22\x0a       \
id=\x22path816-6\x22\x0a \
      d=\x22m -243.\
25424,36.20339 c\
 7.47466,23.4274\
49 32.21453,21.5\
03685 40.62787,8\
.634724 8.41086,\
-12.865143 1.314\
09,-37.4864107 -\
28.0177,-31.0076\
06\x22\x0a       style\
=\x22fill:none;fill\
-rule:evenodd;st\
roke:#999999;str\
oke-width:6;stro\
ke-linecap:round\
;stroke-linejoin\
:miter;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1\x22 />\x0a    <path\x0a\
       inkscape:\
connector-curvat\
ure=\x220\x22\x0a       i\
d=\x22path4489-7\x22\x0a \
      d=\x22m -225.\
0508,25.423733 0\
.20339,-22.37288\
18 -19.72881,11.\
5932198 z\x22\x0a     \
  style=\x22fill:#9\
99999;fill-rule:\
evenodd;stroke:#\
999999;stroke-wi\
dth:2;stroke-lin\
ecap:butt;stroke\
-linejoin:round;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22 />\x0a \
 </g>\x0a</svg>\x0a\
\x00\x00\x0dZ\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22g\
ear.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x22784\x22\x0a     i\
nkscape:window-h\
eight=\x22480\x22\x0a    \
 id=\x22namedview4\x22\
\x0a     showgrid=\x22\
false\x22\x0a     inks\
cape:zoom=\x221.229\
1667\x22\x0a     inksc\
ape:cx=\x22-47.9999\
97\x22\x0a     inkscap\
e:cy=\x2296.000003\x22\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0a     in\
kscape:window-ma\
ximized=\x220\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <path\x0a     s\
tyle=\x22fill:#9999\
99;stroke-width:\
1.33333337\x22\x0a    \
 d=\x22m 77.685212,\
176.62546 c -0.3\
6495,-0.59051 -1\
.359378,-6.15571\
 -2.20984,-12.36\
712 -0.85046,-6.\
21142 -1.647284,\
-11.29448 -1.770\
72,-11.2957 -0.2\
92876,-0.003 -8.\
928958,-4.7575 -\
11.737142,-6.461\
93 -1.605474,-0.\
97444 -5.033267,\
-0.14448 -13.016\
802,3.15168 -6.6\
91473,2.76271 -1\
1.300681,3.99631\
 -12.048381,3.22\
459 -2.638601,-2\
.72336 -17.42210\
1,-29.37153 -17.\
422101,-31.4044 \
0,-1.19223 3.885\
057,-5.09518 8.6\
3346,-8.67324 l \
8.63346,-6.50555\
 v -8.666671 -8.\
666667 l -8.6334\
6,-6.505556 c -4\
.748403,-3.57805\
6 -8.63346,-7.48\
1016 -8.63346,-8\
.673242 0,-2.039\
252 14.78798,-28\
.686171 17.43578\
9,-31.41809 0.76\
5807,-0.790132 5\
.266256,0.388912\
 12.011621,3.146\
851 10.735632,4.\
389415 10.808082\
,4.399033 15.223\
394,2.021232 9.2\
26118,-4.968593 \
9.854293,-5.9181\
76 11.40331,-17.\
237861 0.802812,\
-5.866667 1.9121\
58,-11.134266 2.\
465212,-11.70577\
5 0.553056,-0.57\
1509 9.357958,-0\
.871509 19.56645\
2,-0.666667 l 18\
.560886,0.372442\
 2,11.741416 2,1\
1.741416 6.3294,\
3.92525 c 3.4811\
7,2.158888 6.792\
53,3.925251 7.35\
858,3.925251 0.5\
6605,0 5.41918,-\
1.844483 10.7847\
4,-4.098851 5.36\
556,-2.254369 10\
.45926,-3.828818\
 11.31934,-3.498\
777 2.03324,0.78\
0228 18.20794,29\
.028695 18.20794\
,31.799445 0,1.1\
66222 -3.88505,5\
.047904 -8.63345\
,8.62596 l -8.63\
347,6.505556 v 8\
.666667 8.666671\
 l 8.63347,6.505\
55 c 4.7484,3.57\
806 8.63345,7.48\
101 8.63345,8.67\
324 0,2.03287 -1\
4.7835,28.68104 \
-17.4221,31.4044\
 -0.74772,0.7717\
4 -5.29872,-0.43\
786 -11.89703,-3\
.1621 l -10.6860\
6,-4.41197 -7.21\
862,3.77944 -7.2\
1861,3.77943 -1.\
77879,12.04933 -\
1.77879,12.04933\
 -18.899066,0.36\
932 c -10.394484\
,0.20314 -19.197\
66,-0.11386 -19.\
562612,-0.7043 z\
 m 29.504508,-53\
.06908 c 14.6252\
1,-6.10929 21.57\
602,-23.26646 15\
.09602,-37.26259\
4 -10.20217,-22.\
03565 -40.74219,\
-22.03565 -50.94\
4364,0 -10.32964\
1,22.310974 13.1\
68754,46.736394 \
35.848344,37.262\
594 z\x22\x0a     id=\x22\
path817\x22\x0a     in\
kscape:connector\
-curvature=\x220\x22 /\
>\x0a</svg>\x0a\
\x00\x00\x0f\xa0\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22p\
lot.svg\x22\x0a   inks\
cape:version=\x220.\
92.3 (2405546, 2\
018-03-11)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x221851\x22\x0a     \
inkscape:window-\
height=\x221025\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0a     ink\
scape:cx=\x22-47.99\
9998\x22\x0a     inksc\
ape:cy=\x2296.00000\
6\x22\x0a     inkscape\
:window-x=\x2269\x22\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0a  <path\x0a    \
 style=\x22fill:non\
e;fill-rule:even\
odd;stroke:#ff00\
00;stroke-width:\
6;stroke-linecap\
:round;stroke-li\
nejoin:miter;str\
oke-miterlimit:4\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22\x0a     d=\
\x22M 19.514459,83.\
80134 C 28.17302\
2,74.616437 31.0\
2386,60.80883 58\
.945963,57.74172\
2 82.147121,60.6\
3598 84.918418,8\
0.7924 103.71939\
,80.546389 c 24.\
26383,-1.274365 \
22.69186,-13.651\
999 44.24393,-13\
.027666 21.85487\
,-2.039903 20.28\
547,1.799283 32.\
6583,-17.05689\x22\x0a\
     id=\x22path814\
\x22\x0a     inkscape:\
connector-curvat\
ure=\x220\x22\x0a     sod\
ipodi:nodetypes=\
\x22ccccc\x22 />\x0a  <pa\
th\x0a     style=\x22f\
ill:none;fill-ru\
le:evenodd;strok\
e:#ffcc00;stroke\
-width:6;stroke-\
linecap:round;st\
roke-linejoin:mi\
ter;stroke-miter\
limit:4;stroke-d\
asharray:none;st\
roke-opacity:1\x22\x0a\
     d=\x22M 19.351\
568,101.88747 C \
28.010131,92.702\
567 34.115206,77\
.267842 58.78307\
2,75.827852 81.9\
8423,78.72211 84\
.755527,98.87853\
 103.5565,98.632\
519 c 24.26383,-\
1.274365 22.6918\
6,-13.651999 44.\
24393,-13.027666\
 21.85487,-2.039\
903 20.28547,1.7\
99283 32.6583,-1\
7.05689\x22\x0a     id\
=\x22path814-3\x22\x0a   \
  inkscape:conne\
ctor-curvature=\x22\
0\x22\x0a     sodipodi\
:nodetypes=\x22cccc\
c\x22 />\x0a  <path\x0a  \
   style=\x22fill:n\
one;fill-rule:ev\
enodd;stroke:#00\
aad4;stroke-widt\
h:6;stroke-linec\
ap:round;stroke-\
linejoin:miter;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
opacity:1\x22\x0a     \
d=\x22m 17.724451,1\
26.29425 c 8.658\
56,-9.1849 19.64\
4994,-24.61963 3\
9.4315,-26.05961\
 23.20116,2.8942\
5 25.97246,23.05\
067 44.773429,22\
.80466 24.26383,\
-1.27436 22.6918\
6,-13.652 44.243\
93,-13.02766 21.\
85487,-2.03991 2\
0.28547,1.79928 \
32.6583,-17.0568\
94\x22\x0a     id=\x22pat\
h814-3-6\x22\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22\x0a\
     sodipodi:no\
detypes=\x22ccccc\x22 \
/>\x0a  <path\x0a     \
style=\x22fill:none\
;fill-rule:eveno\
dd;stroke:#00d4a\
a;stroke-width:6\
;stroke-linecap:\
round;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22\x0a     d=\x22\
m 19.35156,101.8\
8746 c 8.65857,-\
9.184897 20.4585\
53,-14.043351 40\
.245069,-15.4833\
46 17.506235,1.2\
67141 25.158891,\
5.152375 43.9598\
61,4.906365 24.2\
6384,-1.27436 16\
.99695,3.432746 \
38.54902,4.05708\
6 21.85487,-2.03\
991 17.03124,-5.\
522754 39.16678,\
-15.429781\x22\x0a    \
 id=\x22path814-3-7\
\x22\x0a     inkscape:\
connector-curvat\
ure=\x220\x22\x0a     sod\
ipodi:nodetypes=\
\x22ccccc\x22 />\x0a  <pa\
th\x0a     style=\x22f\
ill:none;fill-ru\
le:evenodd;strok\
e:#999999;stroke\
-width:10;stroke\
-linecap:round;s\
troke-linejoin:m\
iter;stroke-opac\
ity:1;stroke-mit\
erlimit:4;stroke\
-dasharray:none\x22\
\x0a     d=\x22M 181.4\
2373,170.84746 H\
 16.271186 l 1e-\
6,-152.135596\x22\x0a \
    id=\x22path812\x22\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22\x0a     sodi\
podi:nodetypes=\x22\
ccc\x22 />\x0a</svg>\x0a\
\x00\x00\x0c/\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   width=\x2248\
\x22\x0a   height=\x2248\x22\
\x0a   viewBox=\x220 0\
 48.000001 48.00\
0001\x22\x0a   id=\x22svg\
2\x22\x0a   version=\x221\
.1\x22\x0a   inkscape:\
version=\x220.92.2 \
(5c3e80d, 2017-0\
8-06)\x22\x0a   sodipo\
di:docname=\x22resi\
ze.svg\x22>\x0a  <defs\
\x0a     id=\x22defs4\x22\
 />\x0a  <sodipodi:\
namedview\x0a     i\
d=\x22base\x22\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0a     bordercol\
or=\x22#666666\x22\x0a   \
  borderopacity=\
\x221.0\x22\x0a     inksc\
ape:pageopacity=\
\x220.0\x22\x0a     inksc\
ape:pageshadow=\x22\
2\x22\x0a     inkscape\
:zoom=\x227.9195959\
\x22\x0a     inkscape:\
cx=\x2223.580795\x22\x0a \
    inkscape:cy=\
\x2231.52398\x22\x0a     \
inkscape:documen\
t-units=\x22px\x22\x0a   \
  inkscape:curre\
nt-layer=\x22layer1\
\x22\x0a     showgrid=\
\x22false\x22\x0a     uni\
ts=\x22px\x22\x0a     ink\
scape:window-wid\
th=\x221863\x22\x0a     i\
nkscape:window-h\
eight=\x221025\x22\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0a     in\
kscape:window-y=\
\x2227\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22 />\x0a  <me\
tadata\x0a     id=\x22\
metadata7\x22>\x0a    \
<rdf:RDF>\x0a      \
<cc:Work\x0a       \
  rdf:about=\x22\x22>\x0a\
        <dc:form\
at>image/svg+xml\
</dc:format>\x0a   \
     <dc:type\x0a  \
         rdf:res\
ource=\x22http://pu\
rl.org/dc/dcmity\
pe/StillImage\x22 /\
>\x0a        <dc:ti\
tle />\x0a      </c\
c:Work>\x0a    </rd\
f:RDF>\x0a  </metad\
ata>\x0a  <g\x0a     i\
nkscape:label=\x22C\
apa 1\x22\x0a     inks\
cape:groupmode=\x22\
layer\x22\x0a     id=\x22\
layer1\x22\x0a     tra\
nsform=\x22translat\
e(0,-1004.3622)\x22\
>\x0a    <rect\x0a    \
   style=\x22fill:n\
one;fill-opacity\
:0.84951453;stro\
ke:#999999;strok\
e-width:3.857414\
25;stroke-linejo\
in:round;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne\x22\x0a       id=\x22r\
ect4136\x22\x0a       \
width=\x2244.142586\
\x22\x0a       height=\
\x2244.142586\x22\x0a    \
   x=\x221.9287071\x22\
\x0a       y=\x221006.\
2909\x22\x0a       ry=\
\x2210.186751\x22 />\x0a \
   <g\x0a       id=\
\x22g4157\x22\x0a       t\
ransform=\x22matrix\
(0.84603094,0,0,\
0.78857975,5.043\
4872,217.0903)\x22\x0a\
       style=\x22st\
roke:#999999;fil\
l:#999999\x22>\x0a    \
  <path\x0a        \
 sodipodi:nodety\
pes=\x22ccc\x22\x0a      \
   inkscape:conn\
ector-curvature=\
\x220\x22\x0a         id=\
\x22path4138\x22\x0a     \
    d=\x22m 9.18824\
93,1043.1259 28.\
1788757,-28.9184\
 0,0\x22\x0a         s\
tyle=\x22fill:#9999\
99;fill-rule:eve\
nodd;stroke:#999\
999;stroke-width\
:4.74617958;stro\
ke-linecap:butt;\
stroke-linejoin:\
miter;stroke-mit\
erlimit:4;stroke\
-dasharray:none;\
stroke-opacity:1\
\x22 />\x0a      <path\
\x0a         sodipo\
di:nodetypes=\x22cc\
cc\x22\x0a         ink\
scape:connector-\
curvature=\x220\x22\x0a  \
       id=\x22path4\
140-3\x22\x0a         \
d=\x22m 38.871283,1\
019.5549 -6.5631\
79,-7.2978 8.297\
448,-1.8083 z\x22\x0a \
        style=\x22f\
ill:#999999;fill\
-rule:evenodd;st\
roke:#999999;str\
oke-width:1px;st\
roke-linecap:but\
t;stroke-linejoi\
n:miter;stroke-o\
pacity:1\x22 />\x0a   \
   <path\x0a       \
  sodipodi:nodet\
ypes=\x22cccc\x22\x0a    \
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a         i\
d=\x22path4140-3-6\x22\
\x0a         d=\x22m 6\
.8693068,1038.42\
58 6.5632192,7.2\
979 -8.2974502,1\
.8083 z\x22\x0a       \
  style=\x22fill:#9\
99999;fill-rule:\
evenodd;stroke:#\
999999;stroke-wi\
dth:1px;stroke-l\
inecap:butt;stro\
ke-linejoin:mite\
r;stroke-opacity\
:1\x22 />\x0a    </g>\x0a\
  </g>\x0a</svg>\x0a\
\x00\x00\x0a\xc2\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22l\
oad_add.svg\x22\x0a   \
inkscape:version\
=\x220.92.3 (240554\
6, 2018-03-11)\x22>\
\x0a  <metadata\x0a   \
  id=\x22metadata8\x22\
>\x0a    <rdf:RDF>\x0a\
      <cc:Work\x0a \
        rdf:abou\
t=\x22\x22>\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0a        <dc:t\
ype\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0a        \
<dc:title />\x0a   \
   </cc:Work>\x0a  \
  </rdf:RDF>\x0a  <\
/metadata>\x0a  <de\
fs\x0a     id=\x22defs\
6\x22 />\x0a  <sodipod\
i:namedview\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#666666\x22\x0a\
     borderopaci\
ty=\x221\x22\x0a     obje\
cttolerance=\x2210\x22\
\x0a     gridtolera\
nce=\x2210\x22\x0a     gu\
idetolerance=\x2210\
\x22\x0a     inkscape:\
pageopacity=\x220\x22\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0a   \
  inkscape:windo\
w-width=\x221525\x22\x0a \
    inkscape:win\
dow-height=\x22684\x22\
\x0a     id=\x22namedv\
iew4\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
1.2291667\x22\x0a     \
inkscape:cx=\x22-19\
2.00001\x22\x0a     in\
kscape:cy=\x2296.00\
0009\x22\x0a     inksc\
ape:window-x=\x2267\
\x22\x0a     inkscape:\
window-y=\x2227\x22\x0a  \
   inkscape:wind\
ow-maximized=\x220\x22\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g2\x22 />\x0a  <path\x0a \
    style=\x22fill:\
#37c8ab;stroke-w\
idth:1.33333337\x22\
\x0a     d=\x22m 37.55\
9322,154.44068 v\
 -8 h 56.000004 \
56.000004 v 8 8 \
H 93.559326 37.5\
59322 Z m 32,-48\
 V 82.440678 H 5\
3.896671 38.2340\
21 l 27.66265,-2\
7.662651 27.6626\
55,-27.66265 27.\
662654,27.66265 \
27.66266,27.6626\
51 h -15.66266 -\
15.66265 v 24.00\
0002 24 H 93.559\
326 69.559322 Z\x22\
\x0a     id=\x22path81\
7\x22\x0a     inkscape\
:connector-curva\
ture=\x220\x22 />\x0a  <g\
\x0a     style=\x22str\
oke:#ff6600;stro\
ke-linecap:round\
;stroke-opacity:\
1\x22\x0a     id=\x22g831\
\x22\x0a     transform\
=\x22matrix(0.71514\
701,0,0,0.674974\
96,87.405149,-30\
.675212)\x22>\x0a    <\
path\x0a       styl\
e=\x22fill:none;fil\
l-rule:evenodd;s\
troke:#ff6600;st\
roke-width:16;st\
roke-linecap:rou\
nd;stroke-linejo\
in:miter;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne;stroke-opacit\
y:1\x22\x0a       d=\x22m\
 95.091973,56.17\
2243 0.09447,79.\
795097\x22\x0a       i\
d=\x22path812\x22\x0a    \
   inkscape:conn\
ector-curvature=\
\x220\x22\x0a       sodip\
odi:nodetypes=\x22c\
c\x22 />\x0a    <path\x0a\
       style=\x22fi\
ll:none;fill-rul\
e:evenodd;stroke\
:#ff6600;stroke-\
width:16;stroke-\
linecap:round;st\
roke-linejoin:mi\
ter;stroke-miter\
limit:4;stroke-d\
asharray:none;st\
roke-opacity:1\x22\x0a\
       d=\x22m 134.\
96147,95.594487 \
-79.795108,0.094\
5\x22\x0a       id=\x22pa\
th812-3\x22\x0a       \
inkscape:connect\
or-curvature=\x220\x22\
\x0a       sodipodi\
:nodetypes=\x22cc\x22 \
/>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x09s\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg6\x22\x0a   so\
dipodi:docname=\x22\
redo.svg\x22\x0a   ink\
scape:version=\x220\
.92.3 (2405546, \
2018-03-11)\x22>\x0a  \
<metadata\x0a     i\
d=\x22metadata12\x22>\x0a\
    <rdf:RDF>\x0a  \
    <cc:Work\x0a   \
      rdf:about=\
\x22\x22>\x0a        <dc:\
format>image/svg\
+xml</dc:format>\
\x0a        <dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0a        <d\
c:title />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs10\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#666666\x22\x0a \
    borderopacit\
y=\x221\x22\x0a     objec\
ttolerance=\x2210\x22\x0a\
     gridtoleran\
ce=\x2210\x22\x0a     gui\
detolerance=\x2210\x22\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0a    \
 inkscape:window\
-width=\x221863\x22\x0a  \
   inkscape:wind\
ow-height=\x221025\x22\
\x0a     id=\x22namedv\
iew8\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
4.9166667\x22\x0a     \
inkscape:cx=\x22-43\
.204849\x22\x0a     in\
kscape:cy=\x2224\x22\x0a \
    inkscape:win\
dow-x=\x2257\x22\x0a     \
inkscape:window-\
y=\x2227\x22\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0a     i\
nkscape:current-\
layer=\x22g820\x22 />\x0a\
  <path\x0a     d=\x22\
M0 0h48v48h-48z\x22\
\x0a     id=\x22path2\x22\
\x0a     fill=\x22none\
\x22 />\x0a  <g\x0a     i\
d=\x22g820\x22\x0a     tr\
ansform=\x22matrix(\
-0.66577573,0,0,\
0.67580692,-124.\
33839,3.757795)\x22\
\x0a     style=\x22str\
oke:#00aad4\x22>\x0a  \
  <path\x0a       s\
odipodi:nodetype\
s=\x22csc\x22\x0a       i\
nkscape:connecto\
r-curvature=\x220\x22\x0a\
       id=\x22path8\
16\x22\x0a       d=\x22m \
-243.25424,36.20\
339 c 7.47466,23\
.427449 32.21453\
,21.503685 40.62\
787,8.634724 8.4\
1086,-12.865143 \
1.31409,-37.4864\
107 -28.0177,-31\
.007606\x22\x0a       \
style=\x22fill:none\
;fill-rule:eveno\
dd;stroke:#00aad\
4;stroke-width:6\
;stroke-linecap:\
round;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22 />\x0a    <\
path\x0a       inks\
cape:connector-c\
urvature=\x220\x22\x0a   \
    id=\x22path4489\
-3\x22\x0a       d=\x22m \
-225.0508,25.423\
733 0.20339,-22.\
3728818 -19.7288\
1,11.5932198 z\x22\x0a\
       style=\x22fi\
ll:#00aad4;fill-\
rule:evenodd;str\
oke:#00aad4;stro\
ke-width:2;strok\
e-linecap:butt;s\
troke-linejoin:r\
ound;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
 />\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x09\x91\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg6\x22\x0a   so\
dipodi:docname=\x22\
clear_runs.svg\x22\x0a\
   inkscape:vers\
ion=\x221.0 (4035a4\
fb49, 2020-05-01\
)\x22>\x0a  <metadata\x0a\
     id=\x22metadat\
a12\x22>\x0a    <rdf:R\
DF>\x0a      <cc:Wo\
rk\x0a         rdf:\
about=\x22\x22>\x0a      \
  <dc:format>ima\
ge/svg+xml</dc:f\
ormat>\x0a        <\
dc:type\x0a        \
   rdf:resource=\
\x22http://purl.org\
/dc/dcmitype/Sti\
llImage\x22 />\x0a    \
    <dc:title />\
\x0a      </cc:Work\
>\x0a    </rdf:RDF>\
\x0a  </metadata>\x0a \
 <defs\x0a     id=\x22\
defs10\x22 />\x0a  <so\
dipodi:namedview\
\x0a     pagecolor=\
\x22#ffffff\x22\x0a     b\
ordercolor=\x22#666\
666\x22\x0a     border\
opacity=\x221\x22\x0a    \
 objecttolerance\
=\x2210\x22\x0a     gridt\
olerance=\x2210\x22\x0a  \
   guidetoleranc\
e=\x2210\x22\x0a     inks\
cape:pageopacity\
=\x220\x22\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0a     inkscape:\
window-width=\x2296\
3\x22\x0a     inkscape\
:window-height=\x22\
753\x22\x0a     id=\x22na\
medview8\x22\x0a     s\
howgrid=\x22false\x22\x0a\
     inkscape:zo\
om=\x221.7383042\x22\x0a \
    inkscape:cx=\
\x2228.919447\x22\x0a    \
 inkscape:cy=\x22-6\
7.163857\x22\x0a     i\
nkscape:window-x\
=\x22173\x22\x0a     inks\
cape:window-y=\x222\
01\x22\x0a     inkscap\
e:window-maximiz\
ed=\x220\x22\x0a     inks\
cape:current-lay\
er=\x22svg6\x22\x0a     i\
nkscape:document\
-rotation=\x220\x22 />\
\x0a  <path\x0a     so\
dipodi:nodetypes\
=\x22csscc\x22\x0a     id\
=\x22path836\x22\x0a     \
d=\x22m 6.2346543,2\
2.700042 c 7.715\
9037,2.037933 15\
.1042447,-2.0166\
72 16.7611707,-0\
.582958 0,0 5.48\
4116,2.679027 6.\
127844,5.302337 \
0.855518,3.48639\
1 -5.305974,14.0\
09468 -5.305974,\
14.009468 C 11.7\
46956,38.027462 \
7.0322016,31.259\
994 6.2346543,22\
.700042 Z\x22\x0a     \
style=\x22fill:#e6e\
6e6;stroke:#8080\
80;stroke-width:\
1px;stroke-linec\
ap:butt;stroke-l\
inejoin:miter;st\
roke-opacity:1\x22 \
/>\x0a  <path\x0a     \
sodipodi:nodetyp\
es=\x22csccc\x22\x0a     \
id=\x22path838\x22\x0a   \
  d=\x22M 25.637402\
,23.588184 41.85\
822,7.750306 c 0\
.767688,-0.74956\
4 2.438884,0.876\
482 1.782516,1.6\
14332 L 27.46747\
2,24.948699 Z\x22\x0a \
    style=\x22fill:\
#808080;stroke:#\
808080;stroke-wi\
dth:1px;stroke-l\
inecap:butt;stro\
ke-linejoin:mite\
r;stroke-opacity\
:1\x22 />\x0a  <path\x0a \
    id=\x22path840\x22\
\x0a     d=\x22M 28.50\
1261,30.871441 1\
8.215729,22.4820\
94\x22\x0a     style=\x22\
fill:none;stroke\
:#808080;stroke-\
width:1px;stroke\
-linecap:butt;st\
roke-linejoin:mi\
ter;stroke-opaci\
ty:1\x22 />\x0a</svg>\x0a\
\
\x00\x00\x0b\x13\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22c\
opy2down.svg\x22\x0a  \
 inkscape:versio\
n=\x220.92.3 (24055\
46, 2018-03-11)\x22\
>\x0a  <metadata\x0a  \
   id=\x22metadata8\
\x22>\x0a    <rdf:RDF>\
\x0a      <cc:Work\x0a\
         rdf:abo\
ut=\x22\x22>\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0a        <dc:\
type\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0a       \
 <dc:title />\x0a  \
    </cc:Work>\x0a \
   </rdf:RDF>\x0a  \
</metadata>\x0a  <d\
efs\x0a     id=\x22def\
s6\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0a     id=\x22name\
dview4\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x221.2291667\x22\x0a   \
  inkscape:cx=\x22-\
328.06314\x22\x0a     \
inkscape:cy=\x2296.\
000009\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
g820\x22 />\x0a  <path\
\x0a     style=\x22fil\
l:#999999;stroke\
-width:1.3333333\
7\x22\x0a     d=\x22m 53.\
118644,179.49816\
 c -1.46666,-0.6\
2009 -4.16666,-2\
.7414 -6,-4.7140\
1 l -3.33333,-3.\
58656 V 108.6639\
8 46.130379 l 4.\
35897,-4.358975 \
4.35898,-4.35897\
4 h 50.615376 50\
.61539 l 4.35897\
,4.358974 4.3589\
7,4.358975 v 62.\
615381 62.61539 \
l -4.35758,4.358\
97 -4.3576,4.358\
97 -48.97574,0.2\
7327 c -26.93665\
6,0.15029 -50.17\
5736,-0.23409 -5\
1.642406,-0.8542\
 z m 93.999996,-\
70.7524 V 52.745\
763 h -44 -43.99\
9996 v 55.999997\
 56 h 43.999996 \
44 z M 11.412064\
,73.437035 l 0.3\
7325,-59.308728 \
4.35767,-4.35793\
95 4.35768,-4.35\
79381 51.30899,-\
0.3786652 51.308\
986,-0.3786654 v\
 8.0453322 8.045\
332 h -47.999996\
 -48 v 56 55.999\
997 h -8.03992 -\
8.03991 z\x22\x0a     \
id=\x22path817\x22\x0a   \
  inkscape:conne\
ctor-curvature=\x22\
0\x22 />\x0a  <g\x0a     \
id=\x22g820\x22\x0a     t\
ransform=\x22matrix\
(-4,0,0,-4,-202.\
16948,208.67797)\
\x22>\x0a    <path\x0a   \
    id=\x22path2\x22\x0a \
      d=\x22M 0,0 H\
 48 V 48 H 0 Z\x22\x0a\
       inkscape:\
connector-curvat\
ure=\x220\x22\x0a       s\
tyle=\x22fill:none\x22\
 />\x0a    <path\x0a  \
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a       id=\
\x22path4489\x22\x0a     \
  d=\x22m -82.71455\
9,29.629973 13.0\
37829,0.118525 -\
6.755966,-11.496\
992 z\x22\x0a       st\
yle=\x22fill:#37c8a\
b;fill-rule:even\
odd;stroke:#37c8\
ab;stroke-width:\
1.16550279;strok\
e-linecap:butt;s\
troke-linejoin:r\
ound;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
 />\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x0e\x17\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   version\
=\x221.1\x22\x0a   id=\x22sv\
g2\x22\x0a   width=\x2219\
2\x22\x0a   height=\x2219\
2\x22\x0a   viewBox=\x220\
 0 192 192\x22\x0a   s\
odipodi:docname=\
\x22area_transfer.s\
vg\x22\x0a   inkscape:\
version=\x221.1 (c6\
8e22c387, 2021-0\
5-23)\x22\x0a   xmlns:\
inkscape=\x22http:/\
/www.inkscape.or\
g/namespaces/ink\
scape\x22\x0a   xmlns:\
sodipodi=\x22http:/\
/sodipodi.source\
forge.net/DTD/so\
dipodi-0.dtd\x22\x0a  \
 xmlns=\x22http://w\
ww.w3.org/2000/s\
vg\x22\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:rdf=\x22http\
://www.w3.org/19\
99/02/22-rdf-syn\
tax-ns#\x22\x0a   xmln\
s:cc=\x22http://cre\
ativecommons.org\
/ns#\x22\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22>\x0a  <metadat\
a\x0a     id=\x22metad\
ata8\x22>\x0a    <rdf:\
RDF>\x0a      <cc:W\
ork\x0a         rdf\
:about=\x22\x22>\x0a     \
   <dc:format>im\
age/svg+xml</dc:\
format>\x0a        \
<dc:type\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0a   \
     <dc:title /\
>\x0a      </cc:Wor\
k>\x0a    </rdf:RDF\
>\x0a  </metadata>\x0a\
  <defs\x0a     id=\
\x22defs6\x22 />\x0a  <so\
dipodi:namedview\
\x0a     pagecolor=\
\x22#ffffff\x22\x0a     b\
ordercolor=\x22#666\
666\x22\x0a     border\
opacity=\x221\x22\x0a    \
 objecttolerance\
=\x2210\x22\x0a     gridt\
olerance=\x2210\x22\x0a  \
   guidetoleranc\
e=\x2210\x22\x0a     inks\
cape:pageopacity\
=\x220\x22\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0a     inkscape:\
window-width=\x2218\
58\x22\x0a     inkscap\
e:window-height=\
\x221057\x22\x0a     id=\x22\
namedview4\x22\x0a    \
 showgrid=\x22false\
\x22\x0a     inkscape:\
zoom=\x223.2578125\x22\
\x0a     inkscape:c\
x=\x2245.275779\x22\x0a  \
   inkscape:cy=\x22\
109.1223\x22\x0a     i\
nkscape:window-x\
=\x2254\x22\x0a     inksc\
ape:window-y=\x22-8\
\x22\x0a     inkscape:\
window-maximized\
=\x221\x22\x0a     inksca\
pe:current-layer\
=\x22g833\x22\x0a     ink\
scape:pagechecke\
rboard=\x220\x22 />\x0a  \
<g\x0a     id=\x22g893\
\x22\x0a     transform\
=\x22matrix(0.34525\
501,0,0,0.345255\
01,12.167256,11.\
139857)\x22>\x0a    <g\
\x0a       id=\x22g835\
\x22>\x0a\x09<g\x0a   id=\x22g8\
33\x22>\x0a\x09\x09<path\x0a   \
d=\x22m 356.7,0.45 \
h -43.8 c -6.8,0\
 -12.3,5.5 -12.3\
,12.3 0,6.8 5.5,\
12.2 12.3,12.2 h\
 43.8 c 39.4,0 7\
1.5,32.1 71.5,71\
.5 v 61.9 L 412,\
142.15 c -4.8,-4\
.8 -12.5,-4.8 -1\
7.3,0 -4.8,4.8 -\
4.8,12.5 0,17.3 \
l 37.1,37.1 c 2.\
3,2.3 5.4,3.6 8.\
7,3.6 3.2,0 6.4,\
-1.3 8.7,-3.6 l \
37.1,-37.1 c 4.8\
,-4.8 4.8,-12.5 \
0,-17.3 -4.8,-4.\
8 -12.5,-4.8 -17\
.3,0 l -16.2,16.\
2 v -61.9 c -0.1\
,-52.9 -43.2,-96\
 -96.1,-96 z\x22\x0a  \
 id=\x22path825\x22\x0a  \
 style=\x22fill:#37\
abc8\x22 />\x0a\x0a\x09\x09<pat\
h\x0a   d=\x22M 238.8,\
227.95 V 13.65 c\
 0,-6.8 -5.5,-12\
.3 -12.3,-12.3 H\
 12.3 C 5.5,1.35\
 0,6.85 0,13.65 \
v 214.3 c 0,6.8 \
5.5,12.3 12.3,12\
.3 h 214.3 c 6.7\
,-0.1 12.2,-5.6 \
12.2,-12.3 z m -\
24.5,-12.3 H 24.\
5 V 25.95 h 189.\
8 z\x22\x0a   id=\x22path\
827\x22\x0a   style=\x22f\
ill:#37abc8\x22 />\x0a\
\x0a\x09\x09<path\x0a   d=\x22m\
 133.1,489.45 h \
43.8 c 6.8,0 12.\
3,-5.5 12.3,-12.\
3 0,-6.8 -5.5,-1\
2.2 -12.3,-12.2 \
h -43.8 c -39.4,\
0 -71.5,-32.1 -7\
1.5,-71.5 v -61.\
9 l 16.2,16.2 c \
2.4,2.4 5.5,3.6 \
8.7,3.6 3.2,0 6.\
3,-1.2 8.7,-3.6 \
4.8,-4.8 4.8,-12\
.5 0,-17.3 l -37\
.1,-37.1 c -2.3,\
-2.3 -5.4,-3.6 -\
8.7,-3.6 -3.2,0 \
-6.4,1.3 -8.7,3.\
6 l -37.1,37.1 c\
 -4.8,4.8 -4.8,1\
2.5 0,17.3 4.8,4\
.8 12.5,4.8 17.3\
,0 l 16.2,-16.2 \
v 61.9 c 0,52.9 \
43.1,96 96,96 z\x22\
\x0a   id=\x22path829\x22\
\x0a   style=\x22fill:\
#37c8ab\x22 />\x0a\x0a\x09\x09<\
path\x0a   d=\x22m 263\
.2,488.45 h 214.\
3 c 6.8,0 12.3,-\
5.5 12.3,-12.3 v\
 -214.2 c 0,-6.8\
 -5.5,-12.3 -12.\
3,-12.3 H 263.2 \
c -6.8,0 -12.3,5\
.5 -12.3,12.3 v \
214.3 c 0.1,6.8 \
5.6,12.2 12.3,12\
.2 z m 12.3,-214\
.2 h 189.8 v 189\
.7 H 275.5 Z\x22\x0a  \
 id=\x22path831\x22\x0a  \
 style=\x22fill:#37\
c8ab\x22 />\x0a\x0a\x09</g>\x0a\
\x0a</g>\x0a    <g\x0a   \
    id=\x22g837\x22>\x0a<\
/g>\x0a    <g\x0a     \
  id=\x22g839\x22>\x0a</g\
>\x0a    <g\x0a       \
id=\x22g841\x22>\x0a</g>\x0a\
    <g\x0a       id\
=\x22g843\x22>\x0a</g>\x0a  \
  <g\x0a       id=\x22\
g845\x22>\x0a</g>\x0a    \
<g\x0a       id=\x22g8\
47\x22>\x0a</g>\x0a    <g\
\x0a       id=\x22g849\
\x22>\x0a</g>\x0a    <g\x0a \
      id=\x22g851\x22>\
\x0a</g>\x0a    <g\x0a   \
    id=\x22g853\x22>\x0a<\
/g>\x0a    <g\x0a     \
  id=\x22g855\x22>\x0a</g\
>\x0a    <g\x0a       \
id=\x22g857\x22>\x0a</g>\x0a\
    <g\x0a       id\
=\x22g859\x22>\x0a</g>\x0a  \
  <g\x0a       id=\x22\
g861\x22>\x0a</g>\x0a    \
<g\x0a       id=\x22g8\
63\x22>\x0a</g>\x0a    <g\
\x0a       id=\x22g865\
\x22>\x0a</g>\x0a  </g>\x0a<\
/svg>\x0a\
\x00\x00\x071\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg6\x22\x0a   so\
dipodi:docname=\x22\
up.svg\x22\x0a   inksc\
ape:version=\x220.9\
2.4 (unknown)\x22>\x0a\
  <metadata\x0a    \
 id=\x22metadata12\x22\
>\x0a    <rdf:RDF>\x0a\
      <cc:Work\x0a \
        rdf:abou\
t=\x22\x22>\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0a        <dc:t\
ype\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0a        \
<dc:title />\x0a   \
   </cc:Work>\x0a  \
  </rdf:RDF>\x0a  <\
/metadata>\x0a  <de\
fs\x0a     id=\x22defs\
10\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0a     id=\x22name\
dview8\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x224.9166667\x22\x0a   \
  inkscape:cx=\x22-\
84.191565\x22\x0a     \
inkscape:cy=\x2224\x22\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg6\x22 /\
>\x0a  <path\x0a     d\
=\x22M0 0h48v48h-48\
z\x22\x0a     id=\x22path\
2\x22\x0a     fill=\x22no\
ne\x22 />\x0a  <path\x0a \
    style=\x22fill:\
#cccccc;fill-rul\
e:evenodd;stroke\
:none;stroke-wid\
th:2.97348356;st\
roke-linecap:but\
t;stroke-linejoi\
n:round;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-opacity\
:1\x22\x0a     d=\x22M 7.\
6054021,38.16002\
8 40.868101,38.4\
62416 23.631976,\
9.1307637 Z\x22\x0a   \
  id=\x22path4489\x22\x0a\
     inkscape:co\
nnector-curvatur\
e=\x220\x22 />\x0a</svg>\x0a\
\
\x00\x00\x09\xa5\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22n\
ew.svg\x22\x0a   inksc\
ape:version=\x220.9\
2.4 (unknown)\x22>\x0a\
  <metadata\x0a    \
 id=\x22metadata8\x22>\
\x0a    <rdf:RDF>\x0a \
     <cc:Work\x0a  \
       rdf:about\
=\x22\x22>\x0a        <dc\
:format>image/sv\
g+xml</dc:format\
>\x0a        <dc:ty\
pe\x0a           rd\
f:resource=\x22http\
://purl.org/dc/d\
cmitype/StillIma\
ge\x22 />\x0a        <\
dc:title />\x0a    \
  </cc:Work>\x0a   \
 </rdf:RDF>\x0a  </\
metadata>\x0a  <def\
s\x0a     id=\x22defs6\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#666666\x22\x0a \
    borderopacit\
y=\x221\x22\x0a     objec\
ttolerance=\x2210\x22\x0a\
     gridtoleran\
ce=\x2210\x22\x0a     gui\
detolerance=\x2210\x22\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0a    \
 inkscape:window\
-width=\x221863\x22\x0a  \
   inkscape:wind\
ow-height=\x221025\x22\
\x0a     id=\x22namedv\
iew4\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
1.2291667\x22\x0a     \
inkscape:cx=\x22-26\
8.70903\x22\x0a     in\
kscape:cy=\x22226.9\
1964\x22\x0a     inksc\
ape:window-x=\x2257\
\x22\x0a     inkscape:\
window-y=\x2227\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g2\x22 />\x0a  <path\x0a \
    style=\x22fill:\
#37c8ab;stroke-w\
idth:1.53763843;\
paint-order:stro\
ke fill markers\x22\
\x0a     d=\x22m 36.10\
8101,186.43995 c\
 -1.691407,-0.71\
413 -4.517488,-0\
.85858 -6.631737\
,-3.13345 -1.281\
364,-1.37871 -4.\
131729,-6.43722 \
-4.131729,-6.437\
22 V 95.527895 1\
4.186505 c 0,0 0\
.09785,-4.798740\
2 3.622112,-7.79\
53982 2.682346,-\
2.2807839 6.4265\
71,-2.2583917 6.\
426571,-2.258391\
7 L 75.729307,3.\
696707 116.0653,\
3.2606988 l 28.1\
1566,28.1824962 \
28.11566,28.1824\
96 -0.43817,58.7\
17629 -0.43817,5\
8.71764 c 0,0 -1\
.60321,4.73908 -\
3.29965,6.46354 \
-1.78715,1.81668\
 -6.7513,3.58719\
 -6.7513,3.58719\
 l -61.09298,0.3\
1333 c -33.60113\
5,0.17234 -62.47\
6843,-0.27095 -6\
4.168249,-0.9850\
7 z M 158.35036,\
67.542824 c 0,-0\
.221039 -11.4169\
7,-11.803123 -25\
.37103,-25.73796\
8 l -25.37104,-2\
5.33608 v 25.737\
967 25.737968 h \
25.37104 c 13.95\
406,0 25.37103,-\
0.180851 25.3710\
3,-0.401887 z\x22\x0a \
    id=\x22path817\x22\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22\x0a     sodi\
podi:nodetypes=\x22\
cscccscccccccscs\
csscccss\x22 />\x0a</s\
vg>\x0a\
\x00\x00\x07{\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22l\
oadc.svg\x22\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0a  \
<metadata\x0a     i\
d=\x22metadata8\x22>\x0a \
   <rdf:RDF>\x0a   \
   <cc:Work\x0a    \
     rdf:about=\x22\
\x22>\x0a        <dc:f\
ormat>image/svg+\
xml</dc:format>\x0a\
        <dc:type\
\x0a           rdf:\
resource=\x22http:/\
/purl.org/dc/dcm\
itype/StillImage\
\x22 />\x0a        <dc\
:title />\x0a      \
</cc:Work>\x0a    <\
/rdf:RDF>\x0a  </me\
tadata>\x0a  <defs\x0a\
     id=\x22defs6\x22 \
/>\x0a  <sodipodi:n\
amedview\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0a     bordercol\
or=\x22#666666\x22\x0a   \
  borderopacity=\
\x221\x22\x0a     objectt\
olerance=\x2210\x22\x0a  \
   gridtolerance\
=\x2210\x22\x0a     guide\
tolerance=\x2210\x22\x0a \
    inkscape:pag\
eopacity=\x220\x22\x0a   \
  inkscape:pages\
hadow=\x222\x22\x0a     i\
nkscape:window-w\
idth=\x221525\x22\x0a    \
 inkscape:window\
-height=\x22684\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0a     ink\
scape:cx=\x22-192\x22\x0a\
     inkscape:cy\
=\x2296.000006\x22\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0a     in\
kscape:window-y=\
\x2227\x22\x0a     inksca\
pe:window-maximi\
zed=\x220\x22\x0a     ink\
scape:current-la\
yer=\x22svg2\x22 />\x0a  \
<path\x0a     style\
=\x22fill:#37c8ab;s\
troke-width:1.33\
333337\x22\x0a     d=\x22\
m 37.559322,154.\
44068 v -8 h 56.\
000004 56.000004\
 v 8 8 H 93.5593\
26 37.559322 Z m\
 32,-48 V 82.440\
678 H 53.896671 \
38.234021 l 27.6\
6265,-27.662651 \
27.662655,-27.66\
265 27.662654,27\
.66265 27.66266,\
27.662651 h -15.\
66266 -15.66265 \
v 24.000002 24 H\
 93.559326 69.55\
9322 Z\x22\x0a     id=\
\x22path817\x22\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22 \
/>\x0a</svg>\x0a\
\x00\x00\x12\xa1\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   version\
=\x221.1\x22\x0a   id=\x22sv\
g2\x22\x0a   width=\x2219\
2\x22\x0a   height=\x2219\
2\x22\x0a   viewBox=\x220\
 0 192 192\x22\x0a   s\
odipodi:docname=\
\x22import_models.s\
vg\x22\x0a   inkscape:\
version=\x221.2.1 (\
9c6d41e410, 2022\
-07-14)\x22\x0a   xml:\
space=\x22preserve\x22\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0a   xmlns:sodipo\
di=\x22http://sodip\
odi.sourceforge.\
net/DTD/sodipodi\
-0.dtd\x22\x0a   xmlns\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:svg=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0a   xmlns:cc=\x22\
http://creativec\
ommons.org/ns#\x22\x0a\
   xmlns:dc=\x22htt\
p://purl.org/dc/\
elements/1.1/\x22><\
metadata\x0a     id\
=\x22metadata8\x22><rd\
f:RDF><cc:Work\x0a \
        rdf:abou\
t=\x22\x22><dc:format>\
image/svg+xml</d\
c:format><dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 /><dc:title /\
></cc:Work></rdf\
:RDF></metadata>\
<defs\x0a     id=\x22d\
efs6\x22 /><sodipod\
i:namedview\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#666666\x22\x0a\
     borderopaci\
ty=\x221\x22\x0a     obje\
cttolerance=\x2210\x22\
\x0a     gridtolera\
nce=\x2210\x22\x0a     gu\
idetolerance=\x2210\
\x22\x0a     inkscape:\
pageopacity=\x220\x22\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0a   \
  inkscape:windo\
w-width=\x222544\x22\x0a \
    inkscape:win\
dow-height=\x221001\
\x22\x0a     id=\x22named\
view4\x22\x0a     show\
grid=\x22false\x22\x0a   \
  inkscape:zoom=\
\x221.3085938\x22\x0a    \
 inkscape:cx=\x22-3\
41.58806\x22\x0a     i\
nkscape:cy=\x222.29\
25373\x22\x0a     inks\
cape:window-x=\x222\
4\x22\x0a     inkscape\
:window-y=\x226\x22\x0a  \
   inkscape:wind\
ow-maximized=\x220\x22\
\x0a     inkscape:c\
urrent-layer=\x22g2\
568\x22\x0a     inksca\
pe:showpageshado\
w=\x222\x22\x0a     inksc\
ape:pagecheckerb\
oard=\x220\x22\x0a     in\
kscape:deskcolor\
=\x22#d1d1d1\x22 /><g\x0a\
     id=\x22g2678\x22\x0a\
     transform=\x22\
matrix(0.5532004\
2,0,0,0.59846942\
,8.6310018,192.6\
7497)\x22><path\x0a   \
    style=\x22opaci\
ty:1;fill:#0066f\
f;fill-opacity:1\
;stroke-width:2.\
11176;paint-orde\
r:stroke fill ma\
rkers\x22\x0a       d=\
\x22m 23.837619,-39\
.213637 c -2.322\
935,-0.980768 -6\
.204202,-1.17915\
2 -9.107857,-4.3\
034 -1.759793,-1\
.893485 -5.67441\
11,-8.840713 -5.\
6744111,-8.84071\
3 V -164.06992 -\
275.7821 c 0,0 0\
.134385,-6.59047\
 4.9745161,-10.7\
0601 3.683865,-3\
.13236 8.826087,\
-3.10161 8.82608\
7,-3.10161 l 55.\
396413,-0.59881 \
55.396423,-0.598\
8 38.61332,38.70\
512 38.61333,38.\
70513 -0.60177,8\
0.64128 -0.60177\
,80.641299 c 0,0\
 -2.20181,6.5085\
31 -4.53166,8.87\
686 -2.45442,2.4\
94982 -9.27206,4\
.926555 -9.27206\
,4.926555 l -83.\
90353,0.430319 c\
 -46.146941,0.23\
6687 -85.804098,\
-0.372116 -88.12\
7031,-1.35287 z \
M 191.72201,-202\
.5039 c 0,-0.303\
57 -15.67978,-16\
.2101 -34.84393,\
-35.34787 l -34.\
84394,-34.79592 \
v 35.34787 35.34\
787 h 34.84394 c\
 19.16415,0 34.8\
4393,-0.24839 34\
.84393,-0.55195 \
z\x22\x0a       id=\x22pa\
th817\x22\x0a       in\
kscape:connector\
-curvature=\x220\x22\x0a \
      sodipodi:n\
odetypes=\x22cscccs\
cccccccscscssccc\
ss\x22 /><g\x0a       \
id=\x22g2568\x22\x0a     \
  transform=\x22mat\
rix(0.9128977,0,\
0,0.64716112,24.\
343284,-37.48601\
1)\x22><g\x0a         \
id=\x22g1140\x22\x0a     \
    style=\x22fill:\
#ffffff;stroke:n\
one\x22\x0a         tr\
ansform=\x22transla\
te(407.30746,32.\
477612)\x22><rect\x0a \
          style=\
\x22opacity:1;fill:\
#ffffff;stroke:n\
one;stroke-width\
:1.17752\x22\x0a      \
     id=\x22rect101\
1\x22\x0a           wi\
dth=\x22123.59569\x22\x0a\
           heigh\
t=\x22139.93283\x22\x0a  \
         x=\x22-375\
.9761\x22\x0a         \
  y=\x22-226.0116\x22\x0a\
           ry=\x221\
1.583521\x22 /><rec\
t\x0a           sty\
le=\x22opacity:1;fi\
ll:#ffffff;strok\
e:none\x22\x0a        \
   id=\x22rect1013\x22\
\x0a           widt\
h=\x2248.907463\x22\x0a  \
         height=\
\x2238.208954\x22\x0a    \
       x=\x22-366.8\
0597\x22\x0a          \
 y=\x22-220.08357\x22 \
/><rect\x0a        \
   style=\x22fill:#\
ffffff;stroke:no\
ne\x22\x0a           i\
d=\x22rect1013-4\x22\x0a \
          width=\
\x2248.907463\x22\x0a    \
       height=\x223\
8.208954\x22\x0a      \
     x=\x22-310.728\
36\x22\x0a           y\
=\x22-219.76704\x22 />\
<rect\x0a          \
 style=\x22fill:#ff\
ffff;stroke:none\
\x22\x0a           id=\
\x22rect1013-6\x22\x0a   \
        width=\x224\
8.907463\x22\x0a      \
     height=\x2238.\
208954\x22\x0a        \
   x=\x22-366.3588\x22\
\x0a           y=\x22-\
174.88535\x22 /><re\
ct\x0a           st\
yle=\x22fill:#fffff\
f;stroke:none\x22\x0a \
          id=\x22re\
ct1013-4-6\x22\x0a    \
       width=\x2248\
.907463\x22\x0a       \
    height=\x2238.2\
08954\x22\x0a         \
  x=\x22-310.28119\x22\
\x0a           y=\x22-\
174.56882\x22 /><re\
ct\x0a           st\
yle=\x22fill:#fffff\
f;stroke:none\x22\x0a \
          id=\x22re\
ct1013-1\x22\x0a      \
     width=\x2248.9\
07463\x22\x0a         \
  height=\x2238.208\
954\x22\x0a           \
x=\x22-365.81845\x22\x0a \
          y=\x22-13\
0.41977\x22 /><rect\
\x0a           styl\
e=\x22fill:#ffffff;\
stroke:none\x22\x0a   \
        id=\x22rect\
1013-4-5\x22\x0a      \
     width=\x2248.9\
07463\x22\x0a         \
  height=\x2238.208\
954\x22\x0a           \
x=\x22-309.74084\x22\x0a \
          y=\x22-13\
0.41977\x22 /></g><\
/g></g><path\x0a   \
  inkscape:conne\
ctor-curvature=\x22\
0\x22\x0a     id=\x22path\
817-5\x22\x0a     d=\x22m\
 127.7435,178.61\
424 v -3.96301 h\
 28.90983 28.909\
84 v 3.96301 3.9\
6302 H 156.65333\
 127.7435 Z m 14\
.45492,-26.08983\
 -14.09816,-13.5\
4029 h 8.08158 8\
.08156 v -11.889\
04 -11.88904 h 1\
2.38993 12.38994\
 v 11.88904 11.8\
8904 h 8.08157 8\
.08156 l -14.098\
14,13.54029 c -7\
.754,7.44717 -14\
.25871,13.54031 \
-14.45493,13.540\
31 -0.19621,0 -6\
.70092,-6.09314 \
-14.45491,-13.54\
031 z\x22\x0a     styl\
e=\x22fill:#5500d4;\
stroke-width:0.6\
74273\x22 /></svg>\x0a\
\
\x00\x00\x09-\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   version\
=\x221.1\x22\x0a   id=\x22sv\
g2\x22\x0a   width=\x2219\
2\x22\x0a   height=\x2219\
2\x22\x0a   viewBox=\x220\
 0 192 192\x22\x0a   s\
odipodi:docname=\
\x22stats.svg\x22\x0a   i\
nkscape:version=\
\x221.1 (c68e22c387\
, 2021-05-23)\x22\x0a \
  xmlns:inkscape\
=\x22http://www.ink\
scape.org/namesp\
aces/inkscape\x22\x0a \
  xmlns:sodipodi\
=\x22http://sodipod\
i.sourceforge.ne\
t/DTD/sodipodi-0\
.dtd\x22\x0a   xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns:svg=\x22http:/\
/www.w3.org/2000\
/svg\x22\x0a   xmlns:r\
df=\x22http://www.w\
3.org/1999/02/22\
-rdf-syntax-ns#\x22\
\x0a   xmlns:cc=\x22ht\
tp://creativecom\
mons.org/ns#\x22\x0a  \
 xmlns:dc=\x22http:\
//purl.org/dc/el\
ements/1.1/\x22>\x0a  \
<metadata\x0a     i\
d=\x22metadata8\x22>\x0a \
   <rdf:RDF>\x0a   \
   <cc:Work\x0a    \
     rdf:about=\x22\
\x22>\x0a        <dc:f\
ormat>image/svg+\
xml</dc:format>\x0a\
        <dc:type\
\x0a           rdf:\
resource=\x22http:/\
/purl.org/dc/dcm\
itype/StillImage\
\x22 />\x0a      </cc:\
Work>\x0a    </rdf:\
RDF>\x0a  </metadat\
a>\x0a  <defs\x0a     \
id=\x22defs6\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     pagecol\
or=\x22#ffffff\x22\x0a   \
  bordercolor=\x22#\
666666\x22\x0a     bor\
deropacity=\x221\x22\x0a \
    objecttolera\
nce=\x2210\x22\x0a     gr\
idtolerance=\x2210\x22\
\x0a     guidetoler\
ance=\x2210\x22\x0a     i\
nkscape:pageopac\
ity=\x220\x22\x0a     ink\
scape:pageshadow\
=\x222\x22\x0a     inksca\
pe:window-width=\
\x221858\x22\x0a     inks\
cape:window-heig\
ht=\x221057\x22\x0a     i\
d=\x22namedview4\x22\x0a \
    showgrid=\x22fa\
lse\x22\x0a     inksca\
pe:zoom=\x221.73830\
42\x22\x0a     inkscap\
e:cx=\x22-63.567699\
\x22\x0a     inkscape:\
cy=\x2286.578631\x22\x0a \
    inkscape:win\
dow-x=\x2254\x22\x0a     \
inkscape:window-\
y=\x22-8\x22\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0a     i\
nkscape:current-\
layer=\x22svg2\x22\x0a   \
  inkscape:pagec\
heckerboard=\x220\x22 \
/>\x0a  <g\x0a     id=\
\x22g828\x22\x0a     tran\
sform=\x22matrix(1.\
377566,0,0,1.377\
566,-36.393109,-\
35.973294)\x22>\x0a   \
 <rect\x0a       st\
yle=\x22fill:#00225\
5;stroke:#002255\
;stroke-width:3.\
8;stroke-linecap\
:round;stroke-li\
nejoin:round\x22\x0a  \
     id=\x22rect844\
\x22\x0a       width=\x22\
16\x22\x0a       heigh\
t=\x2256\x22\x0a       x=\
\x2257.150547\x22\x0a    \
   y=\x2294.620117\x22\
\x0a       ry=\x225.79\
702\x22 />\x0a    <rec\
t\x0a       style=\x22\
fill:#0088aa;str\
oke:#0088aa;stro\
ke-width:3.8;str\
oke-linecap:roun\
d;stroke-linejoi\
n:round\x22\x0a       \
id=\x22rect846\x22\x0a   \
    width=\x2216\x22\x0a \
      height=\x2280\
\x22\x0a       x=\x2289.1\
50543\x22\x0a       y=\
\x2270.620117\x22\x0a    \
   ry=\x225.79702\x22 \
/>\x0a    <rect\x0a   \
    style=\x22fill:\
#00aa88;stroke:#\
00aa88;stroke-wi\
dth:3.8;stroke-l\
inecap:round;str\
oke-linejoin:rou\
nd\x22\x0a       id=\x22r\
ect848\x22\x0a       w\
idth=\x2216\x22\x0a      \
 height=\x2232\x22\x0a   \
    x=\x22121.15054\
\x22\x0a       y=\x22118.\
62012\x22\x0a       ry\
=\x225.79702\x22 />\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x04\xca\
\x00\
\x00\x1d\x9dx\xda\xed\x99Ko\xe36\x10\xc7\xef\xfb)\
\x0c\xe5\xd2\xa2\x10\xc5\x87H\x91\xaa\x9d\x05\x8a`\x81\x1e\
z\xd9n\xd13#\xd1\xb66\xb2hHr\x9c\xe4\xd3\
w\xf4\x96\x5c\xdb\x8d\xb1h\xb1\x05$\xc0\x8193|\
\xfdf\xf87\x85,?\xbe\xec\xd2\xc5\xb3\xc9\x8b\xc4f\
+\x87 \xec,L\x16\xd98\xc96+\xe7\x8f/\x9f\
\x5c\xe9,\x8aRg\xb1NmfVNf\x9d\x8f\xf7\
\x1f\x96\xc5\xf3\xe6\xc3b\xb1\x80\xceY\x11\xc6\xd1\xca\xd9\
\x96\xe5>\xf4\xbc\xfd!O\x91\xcd7^\x1cy&5\
;\x93\x95\x85G\x10\xf1\x9c!<\x1a\xc2\xa3\xdc\xe82\
y6\x91\xdd\xedlV\xd4=\xb3\xe2n\x14\x9c\xc7\xeb\
>\xfax<\xa2#\xab\x83\x88R\xca\xc3\xd4\xa3\xd4\x85\
\x08\xb7x\xcdJ\xfd\xe2N\xbb\xc2\x1a\xcfu\xa5\x18c\
\x0f|C\xe4\xfb\xa2\xc2\x02\xa8\xec\xe1\xd3\x87w\x06T\
\xd8C\x1e\x995\xf43(3\xa5\xf7\xf0\xe5\xa1w\xba\
\x18\xc5e<\x1a&\xc9\x9e\x8aH\xef\xcdd\xd6\xce\xd8\
\x10\xd0;S\xecud\x0a\xaf\xb3\xd7\xfd\x8fI\x5cn\
W\x8e/\xeb\xd6\xd6$\x9bm\xd97\x9f\x13s\xfc\xc5\
\xbe\xac\x1c\xbc\xc0\x0b_.:\xf3\x90ZR\x1b\x92x\
\xe5\xc0\xbeD\xdd\xe8\x16\x19\xc66\xaaf]9\x91N\
\xa3C\xaaK\x9b\xa3n\xf7\xdd\x1a\xc2~,\x8c\x14E\
\xfe\xe2\x87C\xf6\x94\xd9c\xf6\xa3s\x0fq\xcb\x9d)\
u\xacK]\xf5i\xe6\xe9,\x84\xd6\x11\x10\x03\xc9\x0a\
??|jZ\xd0\x8e\xa2\xf0O\x9b?\xb5Mx\xaa\
\x00\xfdh\x0f\xb01\xe7\xbe7/\xe3(\x04\xbc;]\
\xde';\xbd1Uf~\x02\x9cKopL\x82\xcb\
\xd7\xbd\x19\x06m\x86\xcdM\x93\xa7\xb3\xc5\x1aG\xbb\xa4\
\xea\xe4\xfd^&i\xfak5\x89\xb3\xf0N\x06M\xca\
\xd4\x0c\xc6\xa5\xd7\xae\xbe\xdd\x9b7\xda\xdc\xd2\xeb\xf6^\
\xb7b\xb3.\x06,U\x8b\xe0v\xf8e\x9f\x83*\x01\
q\x95\xc6&r\x0fK\x88lj\xf3\x95s\xb7\xae\x1f\
\xa7q<\xda<6y\xe7\x12\xf53qY\xa8\x1d\xd8\
\x0c\xe4\xbc5\xdb\xc7\xaf&*K\x9b\x9a\x5cg\x15\x00\
\x98\xbd\xf1lr\xa8\xa9s\xf6C\x12\x9bs\x8e\xbe\x18\
\xaa\xe5\xf5\x13\x9d\xf5\x16[\x1d\xdb\xe3\xca\xa1\xa7\xcec\
\x92\x81\xc3m\xcb\x99H\xc1.Dt%N0\xe5\xce\
\xc0\xaf\x07%[c\xb1\xb5\xc7j'+g\xad\xd3\xc2\
\x9c\x8e\xf6f\xedn\xe5($Y\xfd\x9c\xba#84\
\xaeBXa?P\xe4o^\xd8\x1ee\xc8\xe7\xbe\x94\
\xe2\xc2:a\x00\x1e\x5c\xf0U\xdd/\xf9v\xfa%\xd9\
%o&\x1eR5\xcc{\xc8sPO7\xd5\xaf&\
o\x8fl[1{]n\x9bh\xe8\xf8\x1b\x9c\xf7\xad\
/\x9f}\xb9u}\xf96\xc2T\x85u\xec\xd7P\xd4\
\x95xg]U/s\xa8\x88\x96^\xf9\x9aB\x8a\xdb\
d\x86\xe4\xe7*8\xbccA$\xf5c\xddp\x07_\
Q\xe6\xf6\xc9\x84\xd5H\xed\xf7&\x8f!h\x02\x0f$\
\x85OgO\x93\xcc\xc0V\xc2\xdc\x1e\xb2xl\xfcj\
\x93,|4\xcf&\xed\xacp\xf6L\x9e\x02\x8b2\xf4\
;[\xac\xa1\x80\xf2\x5c\xbfN&\xab\xacv\xbd.L\
\x19\xe2\xce6\xacn\xaf\x13@V\x1f\x02\xe8\x05\xb2\x90\
\x8exT;\x96\xa4\xcba[}\x8c\xa2 \xf0\x19\xe9\
\xf8\xf7\xaaJ\x11\x0e|\x85;\x80\x90b\x89\x18\xc1>\
\xebK\x042\xcb\x10\xe5>eA\x17\x95\x83\x8d#,\
%aD\xbd\x9bts\xbao \xcd|\xca\x09\x93\xe2\
;'\xed\xb2)k\xca\x91\xaf\x14'\xfe\x09k\x81\x14\
\xe1\x9431\xb0&\x14Q%\x08f\x03\xeb\xa0\xe2*\
\xb9$#\xd6\x18\xce\xb4\xa0\x82)\xfe\xef\xc1&T*\
!\xa4\xfc\xeea\xbb'\xa5\xcdO0\xf3\x09^\x9f\x09\
.Fx\x1b\x8dc\x81\x9c\xe0\x15\xd8\x17\x9c\x085\xe3\
\x05\xbc\xa7\xf5|\x0d\xb0B$\xc0\x94\xd0\x09`\x8ei\
\xa5\x0b3\xe0K\x80\xf9\xbb\x01\x83\x96\x04 \x06\xdc\x9f\
\x02\x06\xc2|\x06|\x190\xbdI\x22\x08&\x84\x8f\x00\
+\x14`\xc10\x9f\x01_\x96\x08W\xdd$\x12\xa0\xb8\
\xfd\xed\xbdE\x0c7\x0a_\xcc\x88/\x8b\x84Kn\x92\
\x09\xae|\x1cL\x10KPf9W\xf1e\xc4\xc1M\
2\xc1\xe1\xa66\xbe\x14s$)\x0df\xbe\xd7T\x02\
\xdf\xa4\x12\x8aQ.\xa7\x84A\x89\xe5\xfcKwM%\
\xd4-*!\xb1T\xe3\xb7\x0d@\xac\x88\x14tF|\
\x19\xb1\xc0\xdf\x22\x13$@4\xc0D\x91\x99\xf0\x15\x9d\
\x10\xdf\xa2\x13\x80\x98\x11I\xd8L\xf8\x8aL\xd0\x9be\
bZ\xc4L\x88\xfez\xf1\x9f\x11\x06\xad\x92\x01Q\xff\
\x0b\x95\x80\xbf\xffpa#\x18A\xc5pN\x06\xd6\x0c\
\x04\x83R\x86\xe9\xe4\xe2\xa6$\xc7b\x0c\x9b@\x81\x07\
\x01eb\xae\xe6\x86\xb5|w5\x03a\xc6\xa4\x14\xc1\
\xf4\x0dZr\xd2\xbfT\xcf\x82q\x0e\xf1-\xd7\xe3\x0a\
\xb2\x80\xdf81\x91\x0c\x1fc%\xaeh\xc6\xb2\xfa\xff\
\xd6\xfd\x87\xbf\x00\x8b\x9b!\x17\
\x00\x00\x09\x09\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22d\
elete.svg\x22\x0a   in\
kscape:version=\x22\
0.92.4 (unknown)\
\x22>\x0a  <metadata\x0a \
    id=\x22metadata\
8\x22>\x0a    <rdf:RDF\
>\x0a      <cc:Work\
\x0a         rdf:ab\
out=\x22\x22>\x0a        \
<dc:format>image\
/svg+xml</dc:for\
mat>\x0a        <dc\
:type\x0a          \
 rdf:resource=\x22h\
ttp://purl.org/d\
c/dcmitype/Still\
Image\x22 />\x0a      \
  <dc:title></dc\
:title>\x0a      </\
cc:Work>\x0a    </r\
df:RDF>\x0a  </meta\
data>\x0a  <defs\x0a  \
   id=\x22defs6\x22 />\
\x0a  <sodipodi:nam\
edview\x0a     page\
color=\x22#ffffff\x22\x0a\
     bordercolor\
=\x22#666666\x22\x0a     \
borderopacity=\x221\
\x22\x0a     objecttol\
erance=\x2210\x22\x0a    \
 gridtolerance=\x22\
10\x22\x0a     guideto\
lerance=\x2210\x22\x0a   \
  inkscape:pageo\
pacity=\x220\x22\x0a     \
inkscape:pagesha\
dow=\x222\x22\x0a     ink\
scape:window-wid\
th=\x221863\x22\x0a     i\
nkscape:window-h\
eight=\x221025\x22\x0a   \
  id=\x22namedview4\
\x22\x0a     showgrid=\
\x22false\x22\x0a     ink\
scape:zoom=\x220.30\
729167\x22\x0a     ink\
scape:cx=\x22-93.92\
063\x22\x0a     inksca\
pe:cy=\x2249.326186\
\x22\x0a     inkscape:\
window-x=\x2257\x22\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22g831\x22 \
/>\x0a  <g\x0a     id=\
\x22g831\x22\x0a     styl\
e=\x22stroke:#37c8a\
b;stroke-width:2\
1;stroke-miterli\
mit:4;stroke-das\
harray:none\x22>\x0a  \
  <path\x0a       i\
nkscape:connecto\
r-curvature=\x220\x22\x0a\
       id=\x22path8\
12\x22\x0a       d=\x22M \
44.745763,46.372\
881 145.91476,14\
6.49003\x22\x0a       \
style=\x22fill:none\
;fill-rule:eveno\
dd;stroke:#b3b3b\
3;stroke-width:2\
1;stroke-linecap\
:round;stroke-li\
nejoin:miter;str\
oke-miterlimit:4\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22\x0a       \
sodipodi:nodetyp\
es=\x22cc\x22 />\x0a    <\
path\x0a       inks\
cape:connector-c\
urvature=\x220\x22\x0a   \
    id=\x22path812-\
3\x22\x0a       d=\x22M 1\
44.62039,46.8043\
35 46.040128,146\
.05858\x22\x0a       s\
tyle=\x22fill:none;\
fill-rule:evenod\
d;stroke:#b3b3b3\
;stroke-width:21\
;stroke-linecap:\
round;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22\x0a       s\
odipodi:nodetype\
s=\x22cc\x22 />\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x07\x9e\
\x00\
\x00&\x19x\xda\xddZ\xdd\x93\xe2\xb8\x11\x7f\x9f\xbf\xc2\
\xf1\xbe\xecV\xb0\xac\xd6\xb7\x08\xccU\xe5\xb6\xae\xea^\
\x93\xbb\xba\xc7\x94\xb1\x0d\xe3\xac\xb1)\xdb\x0c3\xf7\xd7\
\xa7e\xb0\x01\x1b\xae\xf6v\xc8\x0e\x89\x99\xa9B\xea\x96\
\xd4\xfa\xa9?ef?\xbc\xacs\xef9\xad\xea\xac,\
\xe6>\x10\xea{i\x11\x97IV\xac\xe6\xfe\xaf\xbf\xfc\
\x14\x18\xdf\xab\x9b\xa8H\xa2\xbc,\xd2\xb9_\x94\xfe\x0f\
\x8f\x0f\xb3\xbf\x04\x81\xf7c\x95FM\x9ax\xbb\xacy\
\xf2~.\xbe\xd4q\xb4I\xbd\x8fOM\xb3\x99\x86\xe1\
n\xb7#\xd9\xa1\x93\x94\xd5*\xfc\xe4\x05\xc1\xe3\xc3\xc3\
\xac~^=x\x9e\x87\xeb\x16\xf54\x89\xe7\xfea\xc0\
f[\xe5-c\x12\x87i\x9e\xae\xd3\xa2\xa9C \x10\
\xfaG\xf6\xf8\xc8\x1e\xbb\xd5\xb3\xe74.\xd7\xeb\xb2\xa8\
\xdb\x91E\xfd\xe1\x84\xb9J\x96=\xb7\x93f\xc7[&\
\xb0\xd6\x86\x94\x85\x8c\x05\xc8\x11\xd4\xafE\x13\xbd\x04\xe7\
CQ\xc6KC\x19\xa54D\xda\x91\xf3\xeb\xb8\xa65\
\x02\xba\xc1\xff\x9e\xbd\xeb u\xb9\xad\xe2t\x89\xe3R\
R\xa4M\xf8\xf9\x97\xcf=1\xa0$i\x92\x93i:\
<\xcfV=\x03\xb9\x88\xd6i\xbd\x89\xe2\xb4\x0e\xbb\xfe\
v\xfc.K\x9a\xa7\xb9/L\xdbzJ\xb3\xd5S\xd3\
7\x9f\xb3t\xf7\xf7\xf2e\xeeS\x8fz\xc2\xe0\x1f\xa1\
\xee\x81\x96\x9a%s\x1fw\xc3\xf6\xacGM9P\x0f\
\xabL{\x0a%\x96\x11\xee}d\x82J)\xd4\xc4c\
\x14L@y\x00\xf0\xa9\x1d\xd2mo\x9a\x94\xb1\x93w\
\xee\xc7e^V\xffZUYB\x1cn\x8f\xc85K\
\xd2e\xed\xb8\xf7\x02\xb8\x96\xf0\xbd\xb0%\xf5\x13\xb8\xd1\
\x89\x93\xfe\xc8\xb8\x88\xea\xfd\x8e=o\x13\xad\xd2v\xe6\
\xb9\xffa\xd9>\x07\xc2\xa2\xac\x92\xb4\xeaH\xaa}\xce\
H%\x22\x985\xaf{{8\xcc\xdd\xed\xd3\xcd\xda\xd3\
\xe9ez\xfd\x14%\xe5n\xee\xb3!\xf1\xf7\xb2\x5c\xe3\
\xac\x8c\x80\x90\x86\xf3!9\xc63\x00I8\x13R\xc3\
\x88\x88\xeb1M\x0ch\x0abHD(\xb7\xceb\x82\
m\x915\xa8\x95\x9b\x97\xd1\xf0mU9\x86<zM\
q\xdb+.D\xb7D\xfdT\xee\x1c\xf8s\x7f\x19\xe5\
=|Wg\xdae\x05\xee.8\xa8\x14\x18\xc5\xafp\
tj\x06\x94\xc9+,\xb8a\xa9\xaf\xd0\xda\xfd^\xa1\
\xad\xa3\x97l\x9d\xfd\x9e\xa2\xcc\xd0\xa9\xc5:m\xa2$\
j\xa2\xa32t=\xbaU)dA\x83\x9f\xfe\xe3\xf3\
O\xfb\x16\xb6\xe3x\xfa[Y}94\xf1q\x0c\xd1\
\xa2\xdc\xa2\xd4\xfec\xdf=K\xe2)\x9a\xe8:j\x1e\
\xb35\x9e\xaf\xb3\xee\xbf\xa2I\xce\xc2#\xe1\x8c\xb9y\
\xdd\xa4\xc7I\xf7\xd3V\xe9\xde\xd6/:\xbc$^g\
nP\xf8\xcf&\xcb\xf3\x9f\xdd\x22\x87m\x9dL\x9a5\
yz\xec\x9c\x85\x07\xe9\x0f{\x0bO67\x0b\xbb\xad\
\xb7\xad\xd5\x00\xc4<Z\xa4\xf9\xdc\xff1\xdaD\xdeH\
\xcfVU\xb9\xdd\xac\xcb\x04\x05mu\xc5?\xe2\xd9\xb6\
\xbb\x01M\x15\x15\xb5\xdb\xfc\xdco\xbf\xe6\x18\x0c>\xd2\
I\x00\x94\x0a\xc2\x15c\x9f:\xd4W\xdd6\xdc\x1c\xa7\
\x8aw6\x09\x82Xe/\x1f)1J\x81\xe2\x92O\
\xa8\xfb\x1c\x9b\x8c(\xa9\xb5\xd1v\x02\x5c\x13\xd0\x8c\x1f\
\x1cJ\xab\xc3\xcdk\x8e\x12/\x11\xbd\xe9\xc1\xda\xffV\
7U\xf9%\x9d~\x10\x89\xfb\xf4\xe79\xdbD\xcd\xd3\
\xf1t\x8e\x16R\x16E\x1a7e\x15\xa0\xad<G\xcd\
\xb6\xc2\x09\xa9\x7f\xc2\x89\xe2\xbb\xb1\x82\xf5:\xeb\x1e\xa7\
h\x1e\xda\xb4fT1\x14\x8e\xe2w&@z\x80\xae\
Ph#\xc4$\xe0D1\x80\x93A\x97\xe4u\x8d\xa0\
\xda\xe6\xe94}N\x8b2I\xfa\x1d\xc4\xca\xf9\xe3C\
soyS7\xb9\xb2\xa0\xb4\xda\xbct\x94<\xc3\x1d\
D\x9b\xe9b\xdb4\xa7}\xff.\xb3b\x8a\x1a\x96V\
]\xef\xc1\x85M\xe1D\xcdn\x01\x8c\x1c\x02\xc3\xdc\x09\
\x1aj\x95\x03F\x13\x8b\xc7\xefqB\x190\xc3'\x81\
!JP\xfb\xcd\xb8,\x97v1\xc6\xc5\xe01p\xcd\
\xf4=\xe1\x02C\x5c\x14\xa1\xd2hi%\xe2\xc28\x01\
%\x99\xa7\x09\xc3\x83VRN0\x08hk\xbe\x19\x17\
J\x13\xd1\x1b\xc0\x01\x17\xf8\xf3`\xb4\x8d\x1c\x1dm3\
\x15]_\x12at\xab\xaa\xe8uZ`B\xf8_\x86\
\xad\x0f-GuB\x8c@\x1a\xcb\x106\xa1\x89F\xdc\
<\xcc,\xd0\xf8\xa4\xe6\x80\xde\x87(\xad\xbf\x197\xc5\
\x9cF\x8d\xed\x8cK\xc1\xc0\xdc\x91>)\xb8`g\xe8\
\x1d\xadvv\xc6\x0d\xd1J 0\x92\x08e\x0c\xb7\x13\
E\x18\xa3\xdf\xaeO\x0b\xbd\x5c\x0a5\xb23\xf4r\x96\
\xdd\x97\xff\xb1c;\xe3\xe8r\xa4t\x8e\x99#\x1e\xd2\
z\xc0\xf1H-7\x16&@\xac\xd5o\xf1?zy\
\xc9/K\x5c\x06\xf8\x1d\xe1\xa2\xc7\x01\x0b\xb1\x00\xa5L\
\xab/\x14\x13R\x06\x9e$\x00@\x8dFu\x11\xe8\xb4\
\xdf\xe0~N\xe2o\x0f\x8b\x16\x9c\x1aA\xe1\x9e`\x19\
\x85+\x81\xc7\x07RQ\xd8\x9b\x91\xa4Zx\x18\xda\xad\
\xe4\xadwA\xa5\xa7o\x00&V\xcb%7#;\xe2\
Ti\xd0\xf6\x9e\xfc\xcb\xc8\x8e0\xe5bF\x00\x13.\
\x8e\x0b\x22\x85\xb5h[\xe8\xa1\x193\x13\x97\xe9P\x0e\
7\xc6\xc5\x02&z\xf6\xae\xf4e\xe4v\x05#\xd2\xa0\
{qQ\x1cC\xba\xe6\xc2\x0b,q\x9c\x92\xb9\xb4\x8f\
K\x05op/\x0b=v/\xdaR\x81\xab\xddS8\
\x92\xfc\x82{\xa1\xc6\xd2V]0f\xa3My\xb1G\
\x09\xa7T\x03\xe6\xc3\x14!b\xca\x13.\xe1\x01@\xa4\
4\x91\x80\x99\xe1\xb0\xe3\x0d.\xc8\xc5\xf2\x91F1\x83\
^_\x8a;\x82\xee,\xcb\xdbGr@\xb7\xc3%k\
3f\x8bE\x8f\xd1\x9eA\xd1\xa5\xd2X\x03\x81>\x03\
\xfb\x16\xa8hL:%\xa3w\x15\xaf \x18\xa9\x14g\
\xc4`\xea\xa7\x5c\xea\xc7\x81\x08\x8d\x0a\x84\x8ad@a\
*\xe8\x14\xc6\x22To\xb05\x93\x5c\xb05N9\xe7\
\x96\xdd\x0c\x9a8\xab\xe2\xfc\xe4n\xa0r\x97L\xa7Q\
\xc8]\xf3`\x09m\x08\x87\xb3*\xd3\xdd\x0d1\xe7w\
\xa55\xe6\x02f(\xa6\xfa\x9a\xcd\xf7R\xfd!\x16\x8a\
\x0d\xb1\x80\xef\x0d\x01fi\xc0\xed\x10\x02\xae\xd0/\xa0\
\x13\x91W \x08\xf8\xad@\xc0\x94\x17\xb3\xbbw\x06\x01\
c\x0aW\xa0\x06 \x886\x815g\x89\xeb\x19\x087\
\xd3\x04\xbbp\xba\xf0\xce p\xe7\x045\x1f\x82\x801\
\x84\x0a.\xf85\x10\xf4\xed\xcca|\xfb\xf2\xddAp\
\xc5.\xa6\xe6C\x8f`\x10\x1a\xab%\xbb\x06\x82\xbc\x15\
\x08\x97J\xe3\xef\x0f\x82t\x97;0\x00\x01\xd3Q\xe6\
R\xf6\xab p\xf9\xffe\x0fX\xa7I\x90\x03\x140\
\xe1\xb2\x0aU\xc4\x5cu\x0a\xecv\x061\xceK\xbf\xbf\
kdX\x90\x98\xa1.\x08,\xd0\xb0H9K\xd4\xcf\
P\xb0\xb7\x02\x81Rw+\xf2\xdeA\x92\x11e\xd50\
>\x00fG\xc2\x02\xbb\xaa\x0ap+\x10\x22{\x07\xae\
\x11\x93d<q;t\x8d\x14k\x09)\xe9\xd5L\x01\
n\x17!\x1c\x08\xef\xae\x0bh\x10\x9c\xd9\xa1[\xc0L\
\xd9P#\xce\x22\xc7\x00\x06z;\x18L\xf2\xee0p\
\xf7&\x86\x8f`@C\x11\x02\xae[\xc4\xed\x1c\xc3]\
\xa4\x0b\x5c\x13#\xd8\xd0$\x90S\x03\xd3\xec:\x0a\xfc\
v(\xa4\xef_C0K(\xc8\x0b\xf9\x82\x00\xa9\x94\
\xbd\x0e\x83\xfa\xdf\x88\x12\xb7)\xb4\xcfv\xbb/\xb5-\
VYz\xff\x96\x85\x1bb,\x08/p\xd7[Ja\
\xf9\x1dH\xc2@\xfcA\xa9\xdd\xea\xff\x9f3\x90[\x97\
\xda\xb3p\xd5\xbd\xf3G$.\xbd%n__\x9d\x9d\
#E\x93\xb1\x12\x84\xe4\xc7|\xaf}\xceE\xe5\xc4H\
-@09\x12\xaa*\xb7E\xf2\xf5o\xcf\xfc\xd3\x17\
\xe3NN\x01'E|\xf7\x9b\x1d\xe1.\xe7\xa59\x12\
\xfa\x9f\xef\x8c(N\xb9\xdd%\x97\xa6'\x09\xd0\xfeB\
A\x11fO\xde\xb4Vm/\x01\xa3\xb4\xec\x7fA\xe1\
0\x9b\xb9\x1f7<>\xfc\x07\xcd\xfd\x1aD\
\x00\x00\x10\x95\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x2248\x22\x0a   heig\
ht=\x2248\x22\x0a   viewB\
ox=\x220 0 48 48\x22\x0a \
  id=\x22svg2\x22\x0a   v\
ersion=\x221.1\x22\x0a   \
inkscape:version\
=\x221.1.2 (0a00cf5\
339, 2022-02-04)\
\x22\x0a   sodipodi:do\
cname=\x22histogram\
.svg\x22\x0a   xmlns:i\
nkscape=\x22http://\
www.inkscape.org\
/namespaces/inks\
cape\x22\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0a   \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22\x0a   xmlns:svg=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:rdf=\x22http:\
//www.w3.org/199\
9/02/22-rdf-synt\
ax-ns#\x22\x0a   xmlns\
:cc=\x22http://crea\
tivecommons.org/\
ns#\x22\x0a   xmlns:dc\
=\x22http://purl.or\
g/dc/elements/1.\
1/\x22>\x0a  <metadata\
\x0a     id=\x22metada\
ta12\x22>\x0a    <rdf:\
RDF>\x0a      <cc:W\
ork\x0a         rdf\
:about=\x22\x22>\x0a     \
   <dc:format>im\
age/svg+xml</dc:\
format>\x0a        \
<dc:type\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0a   \
   </cc:Work>\x0a  \
  </rdf:RDF>\x0a  <\
/metadata>\x0a  <de\
fs\x0a     id=\x22defs\
10\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x222491\x22\x0a\
     inkscape:wi\
ndow-height=\x22101\
6\x22\x0a     id=\x22name\
dview8\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x225.9956763\x22\x0a   \
  inkscape:cx=\x22-\
67.715464\x22\x0a     \
inkscape:cy=\x226.7\
548677\x22\x0a     ink\
scape:window-x=\x22\
69\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
g4150\x22\x0a     inks\
cape:pagechecker\
board=\x220\x22 />\x0a  <\
path\x0a     d=\x22M0 \
0h48v48h-48z\x22\x0a  \
   fill=\x22none\x22\x0a \
    id=\x22path4\x22 /\
>\x0a  <g\x0a     id=\x22\
g4150\x22\x0a     tran\
sform=\x22matrix(1.\
5481578,0,0,1.64\
49357,-25.483574\
,-28.185397)\x22\x0a  \
   style=\x22stroke\
:#1a1a1a\x22>\x0a    <\
g\x0a       transfo\
rm=\x22translate(1.\
0067283,-25.8872\
99)\x22\x0a       id=\x22\
g4144\x22\x0a       st\
yle=\x22stroke:#1a1\
a1a\x22 />\x0a    <g\x0a \
      id=\x22g4172\x22\
\x0a       transfor\
m=\x22matrix(0.8399\
6404,0,0,0.83996\
404,5.1306444,5.\
680952)\x22\x0a       \
style=\x22stroke:#2\
16778\x22>\x0a      <p\
ath\x0a         sty\
le=\x22fill:none;fi\
ll-rule:evenodd;\
stroke:#216778;s\
troke-width:0.57\
4108;stroke-line\
cap:round;stroke\
-linejoin:miter;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22\x0a    \
     d=\x22m 15.206\
583,16.082449 -0\
.0045,28.851617\x22\
\x0a         id=\x22pa\
th4148\x22\x0a        \
 inkscape:connec\
tor-curvature=\x220\
\x22\x0a         sodip\
odi:nodetypes=\x22c\
c\x22 />\x0a      <pat\
h\x0a         style\
=\x22fill:none;fill\
-rule:evenodd;st\
roke:#216778;str\
oke-width:0.5147\
22;stroke-lineca\
p:round;stroke-l\
inejoin:miter;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none;stroke-o\
pacity:1\x22\x0a      \
   d=\x22m 15.20020\
1,44.988746 33.7\
69032,0.0051\x22\x0a  \
       id=\x22path4\
148-5\x22\x0a         \
inkscape:connect\
or-curvature=\x220\x22\
\x0a         sodipo\
di:nodetypes=\x22cc\
\x22 />\x0a    </g>\x0a  \
  <rect\x0a       s\
tyle=\x22fill:#1644\
50;stroke:none;s\
troke-width:0.88\
8814;stroke-line\
cap:round;stroke\
-linejoin:round;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;paint-\
order:markers st\
roke fill\x22\x0a     \
  id=\x22rect1082\x22\x0a\
       width=\x223.\
4775972\x22\x0a       \
height=\x2210.97723\
5\x22\x0a       x=\x2220.\
343279\x22\x0a       y\
=\x2232.139153\x22\x0a   \
    ry=\x220\x22 />\x0a  \
  <rect\x0a       s\
tyle=\x22fill:#87cd\
de;stroke:none;s\
troke-width:0.87\
0871;stroke-line\
cap:round;stroke\
-linejoin:round;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;paint-\
order:markers st\
roke fill\x22\x0a     \
  id=\x22rect1082-9\
\x22\x0a       width=\x22\
3.4775972\x22\x0a     \
  height=\x2210.538\
495\x22\x0a       x=\x223\
9.084335\x22\x0a      \
 y=\x2232.514355\x22\x0a \
      ry=\x220\x22 />\x0a\
    <rect\x0a      \
 style=\x22fill:#21\
6778;stroke:none\
;stroke-width:1.\
10845;stroke-lin\
ecap:round;strok\
e-linejoin:round\
;stroke-miterlim\
it:4;stroke-dash\
array:none;paint\
-order:markers s\
troke fill\x22\x0a    \
   id=\x22rect1082-\
0\x22\x0a       width=\
\x223.4775972\x22\x0a    \
   height=\x2217.07\
2744\x22\x0a       x=\x22\
25.112736\x22\x0a     \
  y=\x2226.04364\x22\x0a \
      ry=\x220\x22 />\x0a\
    <rect\x0a      \
 style=\x22fill:#37\
abc8;stroke:none\
;stroke-width:1.\
10845;stroke-lin\
ecap:round;strok\
e-linejoin:round\
;stroke-miterlim\
it:4;stroke-dash\
array:none;paint\
-order:markers s\
troke fill\x22\x0a    \
   id=\x22rect1082-\
0-1\x22\x0a       widt\
h=\x223.4775972\x22\x0a  \
     height=\x2217.\
072744\x22\x0a       x\
=\x2234.499439\x22\x0a   \
    y=\x2225.968277\
\x22\x0a       ry=\x220\x22 \
/>\x0a    <rect\x0a   \
    style=\x22fill:\
#2c89a0;stroke:n\
one;stroke-width\
:1.28508;stroke-\
linecap:round;st\
roke-linejoin:ro\
und;stroke-miter\
limit:4;stroke-d\
asharray:none;pa\
int-order:marker\
s stroke fill\x22\x0a \
      id=\x22rect10\
82-0-8\x22\x0a       w\
idth=\x223.4775972\x22\
\x0a       height=\x22\
22.947119\x22\x0a     \
  x=\x2229.770622\x22\x0a\
       y=\x2220.155\
022\x22\x0a       ry=\x22\
0\x22 />\x0a  </g>\x0a</s\
vg>\x0a\
\x00\x00\x08\x1f\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22e\
dit.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x221863\x22\x0a     \
inkscape:window-\
height=\x221025\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x222.4\
583333\x22\x0a     ink\
scape:cx=\x2225.852\
3\x22\x0a     inkscape\
:cy=\x22102.01301\x22\x0a\
     inkscape:wi\
ndow-x=\x2257\x22\x0a    \
 inkscape:window\
-y=\x2227\x22\x0a     ink\
scape:window-max\
imized=\x221\x22\x0a     \
inkscape:current\
-layer=\x22svg2\x22 />\
\x0a  <path\x0a     st\
yle=\x22fill:#99999\
9;stroke:#999999\
;stroke-width:1.\
33333337\x22\x0a     d\
=\x22M 24.40678,148\
.92473 V 133.917\
28 L 68.754672,8\
9.5842 113.10257\
,45.251123 l 14.\
97875,15.021359 \
14.97874,15.0213\
6 -44.333988,44.\
319178 -44.334,4\
4.31918 H 39.399\
422 24.40678 Z m\
 112.28181,-97.3\
56802 -15.0515,-\
15.114105 8.6027\
7,-8.260811 c 5.\
40008,-5.185426 \
9.73241,-8.26080\
9 11.63711,-8.26\
0809 4.22102,0 2\
6.52981,22.33462\
4 26.52981,26.56\
0551 0,1.957621 \
-3.01092,6.15863\
2 -8.33333,11.62\
7168 l -8.33334,\
8.562112 z\x22\x0a    \
 id=\x22path817\x22\x0a  \
   inkscape:conn\
ector-curvature=\
\x220\x22 />\x0a</svg>\x0a\
\x00\x00\x078\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg6\x22\x0a   so\
dipodi:docname=\x22\
prev.svg\x22\x0a   ink\
scape:version=\x220\
.92.3 (2405546, \
2018-03-11)\x22>\x0a  \
<metadata\x0a     i\
d=\x22metadata12\x22>\x0a\
    <rdf:RDF>\x0a  \
    <cc:Work\x0a   \
      rdf:about=\
\x22\x22>\x0a        <dc:\
format>image/svg\
+xml</dc:format>\
\x0a        <dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0a        <d\
c:title />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs10\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#666666\x22\x0a \
    borderopacit\
y=\x221\x22\x0a     objec\
ttolerance=\x2210\x22\x0a\
     gridtoleran\
ce=\x2210\x22\x0a     gui\
detolerance=\x2210\x22\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0a    \
 inkscape:window\
-width=\x221863\x22\x0a  \
   inkscape:wind\
ow-height=\x221025\x22\
\x0a     id=\x22namedv\
iew8\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
4.9166667\x22\x0a     \
inkscape:cx=\x22-26\
.001716\x22\x0a     in\
kscape:cy=\x2224\x22\x0a \
    inkscape:win\
dow-x=\x2257\x22\x0a     \
inkscape:window-\
y=\x2227\x22\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0a     i\
nkscape:current-\
layer=\x22svg6\x22 />\x0a\
  <path\x0a     d=\x22\
M0 0h48v48h-48z\x22\
\x0a     id=\x22path2\x22\
\x0a     fill=\x22none\
\x22 />\x0a  <path\x0a   \
  style=\x22fill:#0\
0d455;fill-rule:\
evenodd;stroke:#\
00d455;stroke-wi\
dth:2;stroke-lin\
ecap:butt;stroke\
-linejoin:round;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22\x0a    \
 d=\x22m 33.661067,\
35.186445 0.2033\
9,-22.372882 -19\
.728814,11.59322\
 z\x22\x0a     id=\x22pat\
h4489\x22\x0a     inks\
cape:connector-c\
urvature=\x220\x22 />\x0a\
</svg>\x0a\
\x00\x00\x07\x14\
\x00\
\x00& x\xda\xddZ[o\xa3H\x16~\xcf\xaf`\
\xe8\x97n\x8d)\xea\xd4\xbdX;#\xcd\xb4F\x9a\xd7\
\xb9h\x1fW\x04\x88\xcd6\x06\x0bp\x9c\xf4\xaf\x9fS\
\xd8\xe0\x0ba\x95\x95\xbc\x92\xd78QRuN]\xce\
W\xe7Zx\xfe\xd3\xeb\xba\xf0^\xb2\xba\xc9\xabr\xe1\
\x03\xa1\xbe\x97\x95I\x95\xe6\xe5r\xe1\xff\xf5\xe7\xaf\x81\
\xf1\xbd\xa6\x8d\xcb4.\xaa2[\xf8e\xe5\xff\xf4\xf8\
0\xff!\x08\xbc_\xea,n\xb3\xd4\xdb\xe5\xed\xca\xfb\
\xad\xfc\xd6$\xf1&\xf3>\xaf\xdav\x13\x85\xe1n\xb7\
#\xf9\xa1\x93T\xf52\xfc\xe2\x05\xc1\xe3\xc3\xc3\xbcy\
Y>x\x9e\x87\xeb\x96M\x94&\x0b\xff0`\xb3\xad\
\x8b\x8e1M\xc2\xac\xc8\xd6Y\xd96!\x10\x08\xfd#\
{rdO\xdc\xea\xf9K\x96T\xebuU6\xdd\xc8\
\xb2\xf9t\xc2\x5c\xa7\xcf\x03\xb7\xdb\xcd\x8ewL`\xad\
\x0d)\x0b\x19\x0b\x90#h\xde\xca6~\x0d\xce\x87\xe2\
\x1e\xdf\x1b\xca(\xa5!\xd2\x8e\x9c\x1f\xe3\x8a\x1a\x04t\
\x83\xbf\x03{\xdfA\x9aj['\xd93\x8e\xcbH\x99\
\xb5\xe1\xd7?\xbf\x0e\xc4\x80\x92\xb4MO\xa6\xe9\xf1<\
[\xf5\x0c\xe42^g\xcd&N\xb2&\xec\xfb\xbb\xf1\
\xbb<mW\x0b_\x98\xae\xb5\xca\xf2\xe5\xaa\x1d\x9a/\
y\xb6\xfb\xb9z]\xf8\xd4\xa3\x9e0\xf8C\xa8{\xa0\
\xa3\xe6\xe9\xc2Gi\xd8\x9e\xf5\xa8)\x07\xeaa\x95h\
\xa0Pb\x19a\xdeg\x99\xf0\xcc\xd0t\xe61\x0a:\
\xa0&\xa0\xeaK7\xa4\x17/J\xab\xc4\xedw\xe1\xc7\
\xdb\xb6Z\xe3i&\xff*\xe2\xb7j\xdb\x12\x87\xde#\
\xf2\xce\xd3\xec\xb9qc\xf6\xdbp-\xe1{aG\x1a\
\xa6qs\xa4N\x86#\xe3S\xdc\xec\xe5\xf6\xbcM\xbc\
D\x1d)\xaaz\xe1\x7fz\xee\x9e\x03\xe1\xa9\xaa\xd3\xac\
\xeeI\xaa{\xceH\x15\xe2\x98\xb7o{\xab8\xcc\xdd\
K\xebf\x1d\xe8\xf4}z\xb3\x8a\xd3j\xb7\xf0\xd9%\
\xf1{U\xad\x11|\xa2\x8d\x12\xd2\xf0Kr\x82'\x11\
\xe0\x19X\x0a\xca\x9a\x11\x15\x17d@4\xe3L\x8c\x86\
\x22\xa2[g8\xc1\xb6\xcc[T\xce\xcd\xebh\xf8\xb6\
\xae\x1d\x03\x02\x9d\xa1\xdcK.\x04\x1cx\x9aU\xb5[\
\xd6\x0e\xbe\xe7\xb8\x18\xf0\x9b\x9ci\x97\x97(^p\xd0\
,0\x8aOp\xf4\xda\x06\x94\xc9\x09\x16\x94X\xea\x09\
\x9a\x93w\x8a\xb6\x8e_\xf3u\xfe=\xc3=C\xaf\x17\
\xeb\xac\x8d\xd3\xb8\x8d\x8f\xda\xd0\xf7\xe8N\xa7\x90\x05\xed\
>\xfa\xfd\xeb\xaf\xfb\x16\xb6\x93$\xfagU\x7f;4\
\xf1q\x0c\xf1\x13j\xe2\xc2\xf7\x1f\x87\xeey\x9aDh\
\xa9\xa8\xa9\x8f\xf9\x1a\x0f\xd8\x19\xf9\x8fh\x99\xf3\xf0H\
8cn\xdf6\xd9q\xd2\xfd\xb4u\xb67\xf9w\xfd\
^\x9a\xacs7(\xfc\xa3\xcd\x8b\xe27\xb7\xc8A\xac\
\x93I\xf3\xb6\xc8\x8e\x9d\xf3\xf0\xb0\xfb\x83l\xe1\x89p\
\xf3\xb0\x17\xbdk-/@,\xe2\xa7\xacX\xf8\xbf\xc4\
\x9b\xd8\x83K\x84\x97u\xb5\xdd\xac\xab\x147\xda\xe9\x8a\
\x7f\xc4\xb3k\xf7\x03\xda:.\x1b'\xfc\xc2\xef\xfe-\
0&|\xa6\xb3\x00(\x15\x84+\xc6\xbe\xf4\xa8/{\
1\xdc\x1c\xa7\x8aw6\x09\x82X\xe7\xaf\x9f)1J\
\x81\xe2\x92\xcf\xa8\xfb\x1c\x9b\x8c(\xa9\xb5\xd1v\x06\x5c\
\x13@C\x80/\xc3DM\xfbV\xe0\x8e\x9f\x11\xbd\xe8\
`\xee\xffh\xda\xba\xfa\x96E\x9fD\xea>\xfe\xf1\xd4\
\xf3:)N\xce\xa7v\x96.\xfdc\x8735\x14\xc3\
\x10\x0e\x83vv\xfd\xa8\xaeL\x10)\xa45\xe6\xa4\xdf\
\xc9\xb5\x89\xdb\x15\xe7\x5c\x9dt\xbf\xb7'\xd7\x08\x0e\x0e\
$\x82}\xb3\xde\x16Y\x94\xbdde\x95\xa6\xc3\xa6m\
\xf7\x1c\x9a{c\x8b`\xf3\xdaw\x14y\x99\xe1qE\
O\xdb\xb6=\xed\xfbw\x95\x97\x11\xeaRV\xf7\xbd\xc3\
b'\x0a\xf5Q\x08\x80\x13\xe0\xf6\x12\x02D\x9f\x1a*\
(\x9b\x80 \xe0w\x05\x02S\xa8\xce\xa0.@\x10\x9c\
XaQ\x1b\xa7@\xb8/M\xe0\xd6Y\x1f\xbf\x04\x81\
\x12A\x05\x17|\x0a\x04}W \x08M45#\x8f\
`\x10\x1a\xab\xe5\xa49\xc8\xfb\x02A\xa2Kfp\x01\
\x02\x08\xc2\xa4\xa20\xed\x13\xee\x0b\x05.\x09H\x90\x17\
(HB\xadB\x151\x93N\x81\xdd\x97k\xc4\x98\xac\
\xcc\xc8+\x10\x83\x8a 4L\xa1`\xef+H\x22\x08\
V]\xc6\x07\x00\x22\x84\x056\xa9\x0ap_ X\x82\
'n/]#%LII\xe5$\x08w\x16!\xd0\
 8\xb3\x97n\x81\x03Z\x84\x11g\x91\xe3\x02\x06z\
_\xde\x91\xb9:u\x04\x03\x1a\x0a&\xff\xd3\x16qg\
\x8e\x01\xf3d#\xd8\xa5I \xa7\x06\xa6\xd94\x0aw\
\x96>[B1T\x8e\xf3\x05\x01R);\x0d\xc3\xff\
I\x02\xedv|\x22\xc3p\xdfR\x958m[\xd5A\
\xb2\xad_\xe2v[\xe3\xfe\xe9;\xd2\x0av\x06\x8e\xbb\
\xb6\xf0\x14\xa1\xd2hi\xe5\x0c\xf1\xc3\x1aLI\xe6i\
t\xa5\x94\xa27\x9dI\xc2\xb55\x1fA\xe7\xe3p\xfc\
\xf7`t\x8d\x22\xc7?\x91\xe8\xfb\xd2\xb8Y\xc5u\x1d\
\xbfEeUf\xffk\xd8\xf8%l\x80\xf9\x97\xb1\x94\
\x09\x07\x9b&\x16\xa4\x97x\x94pJ5\x88Y\x80\xc5\
\x0ac\xca\x13\x0eH\x006\x0b4\x91 \xc4\xa8\xe3\xaa\
\xc8\xba[Qcp+\xe2\x964N^B\xc7\xdcE\
\x8b\xc1\xec\x15\xa1\x03\x84\x8e#.\x9cP\x86\x09\x0c\x9f\
\x05X\xe1\x08j\xaf\x8c\x0bV\x11\x96k\xa6o\x09\x17\
=R)\x17\xc9(\xeet\xd6%z\x0c\x9d\x96\x07x\
\xa6B\x1b\x81*\xc5\x09\x96Bpm\x85\x11\xca\x82\xd2\
\xea\x96\x80\xb1c\x17\xc5QG\xa4t\xc0`1$\xa4\
\xf5\xa0\xbb\x12\xe1\xa8\xec3 \xd6j{u\x5c\xdc\xcd\
\x1b\xf0\x1b\xc2E\xc1;\x86$\xb5\xb6\xda\x19\x127D\
+!\xbd\x00\xf1Q\xc6p;S\x841j\xaemH\
\xa8\x95\x96\xdd\x94\xbe\xa8\x91oF\x7f\xcc@\x1a\xcbf\
\xfb{\x14\x8ci^\x00\xee}\x86\xd4\x1cf\x01\x10\xa5\
\xf5\xd5\x15\x86K\xc1\xc0\xdc\x120#C\xc2,Q\x0b\
\xab\xc1\xc5z\xcc\x8a8\xd5\xda\xc3\x08\xcf\x19\x15\xa8C\
@8&\x02\xd7\xc6\x05\x003\x88[J\x81\xf4\xc8\x8e\
\x04#\xd2\xa0\x7f\x99u\x17\xb0Ts\xe1\x05\x968N\
\xc9\x9c\xdf\xe5R]\xdb\xefjK\x05\xaevK\xea\xa2\
G\x81Z\xb8\xe3s7m{\xff\x22\xa9\x16\x1e\xc6(\
+ygE\xe8\x0d\xa8\xba\xba\x83\xe1Ti\xd0\xf6\x96\
\x80\xd1\xef$\x7f\x02\x942\x9d\xe3\xa5\x04\xd0\xf0\xd1\x8e\
\x00\x80\x1a\x8d~W\x98\xab\xc3\xa2\x05\xc7\xaa\x9e\xde\x92\
\x1d\x9d\x95\x05{\xbf\x8b5\x19\x06h\xd6%v\xee\x12\
\xdfh\xcf`N*\x95\x9e1\x02Z\xf2k\xa3\x82U\
\x8ad\x94\xdf\x94w\x09F\xf1\x883b0\x1e)\x17\
\x8f8\x10\xa1\xb12\xc0\x0a\xc1\x80\xc2\xf8\xe4*\x01\x8b\
P]\x1b\x1aN\xb1\xb6\xb5\xec\xc6\xa09\xab\xb4\xf7\xe0\
X,\x84\xf4>X\xa3\x93\xc1\x8c\x0e\xbd\xaf\xf3\xc2J\
!`\x98\xce0\x10\xb7\x0d\xce<\x5c\xf6\xef\xfc\x11\x89\
\xf7\xde\x12w\x15\xea\xd9\x1d\x02\x9e\xbe\xb0X\x00J\xfe\
\x1f\xb7\xca\x89\x91Z\xa0\x7f\x91\xa3M\xd5\xd5\xb6L?\
^ \xfb\xa7/\xc6\xdd>\x05\x9c\xbc@\xee\xbf\xba#\
\x9c/CM\x1d\x08\xc3\xb7xF\x14w\xb1\xe2\xeaM\
MO\x02\xea\xfee6f\x9e\xf6\xa4\x84\xab\xbb^\x02\
Fi9|\x83\xc2a6w_nx|\xf8\x1b\x9b\
j\x14\x0c\
\x00\x00\x11\xba\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   width=\x22\
512\x22\x0a   height=\x22\
512\x22\x0a   viewBox=\
\x220 0 135.46666 1\
35.46667\x22\x0a   ver\
sion=\x221.1\x22\x0a   id\
=\x22svg5\x22\x0a   xml:s\
pace=\x22preserve\x22\x0a\
   inkscape:vers\
ion=\x221.2.1 (9c6d\
41e410, 2022-07-\
14)\x22\x0a   sodipodi\
:docname=\x22roseta\
.svg\x22\x0a   xmlns:i\
nkscape=\x22http://\
www.inkscape.org\
/namespaces/inks\
cape\x22\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0a   \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22\x0a   xmlns:svg=\
\x22http://www.w3.o\
rg/2000/svg\x22><so\
dipodi:namedview\
\x0a     id=\x22namedv\
iew7\x22\x0a     pagec\
olor=\x22#ffffff\x22\x0a \
    bordercolor=\
\x22#000000\x22\x0a     b\
orderopacity=\x220.\
25\x22\x0a     inkscap\
e:showpageshadow\
=\x222\x22\x0a     inksca\
pe:pageopacity=\x22\
0.0\x22\x0a     inksca\
pe:pagecheckerbo\
ard=\x220\x22\x0a     ink\
scape:deskcolor=\
\x22#d1d1d1\x22\x0a     i\
nkscape:document\
-units=\x22mm\x22\x0a    \
 showgrid=\x22false\
\x22\x0a     inkscape:\
zoom=\x220.37282197\
\x22\x0a     inkscape:\
cx=\x22-193.12167\x22\x0a\
     inkscape:cy\
=\x22276.27127\x22\x0a   \
  inkscape:windo\
w-width=\x222560\x22\x0a \
    inkscape:win\
dow-height=\x221017\
\x22\x0a     inkscape:\
window-x=\x22-8\x22\x0a  \
   inkscape:wind\
ow-y=\x22-8\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22g5998\x22\
 /><defs\x0a     id\
=\x22defs2\x22 /><g\x0a  \
   inkscape:labe\
l=\x22Layer 1\x22\x0a    \
 inkscape:groupm\
ode=\x22layer\x22\x0a    \
 id=\x22layer1\x22><g\x0a\
       id=\x22g5998\
\x22\x0a       transfo\
rm=\x22translate(79\
.009279,-56.9685\
48)\x22><path\x0a     \
    style=\x22fill:\
#00222b;fill-opa\
city:1;stroke-wi\
dth:0.264583\x22\x0a  \
       d=\x22m -55.\
19995,94.34173 9\
.785448,-7.52726\
7 1.505452,-4.01\
4541 2.509089,-0\
.25091 8.530899,\
-6.52363 12.2945\
34,-5.519994 13.\
7999865,-4.51636\
 10.03635,-2.007\
27 11.7927205,1.\
003636 2.76,0.75\
2727 2.00727,3.0\
10905 4.26545,20\
.574526 8.02908,\
17.061808 3.7636\
4,10.28726 1.254\
54,41.14905 -8.2\
7999,10.53817 -1\
4.0509,10.53818 \
-8.2799905,3.763\
63 -6.77453999,0\
.25091 -4.767270\
01,0.75272 h -3.\
0109 l -4.014539\
5,1.25455 -5.519\
999,-0.50182 -4.\
265451,1.50545 -\
8.781809,-1.2545\
4 -9.785448,1.25\
454 -6.27272,0.5\
0182 -7.276357,-\
2.50909 -1.50545\
2,-1.50545 -1.75\
6363,-3.76363 0.\
501817,-10.53818\
 -0.752726,-9.28\
362 1.003636,-2.\
00727 1.254543,-\
17.81453 -1.2545\
43,-5.26909 1.00\
3636,-3.26181 -0\
.50182,-3.76364 \
z\x22\x0a         id=\x22\
path412\x22 /><path\
\x0a         style=\
\x22fill:none;fill-\
opacity:1;stroke\
:#ffffff;stroke-\
width:4;stroke-l\
inecap:round;str\
oke-dasharray:no\
ne;stroke-opacit\
y:1\x22\x0a         d=\
\x22m -45.163594,10\
3.12354 7.778176\
,-3.01091 6.0218\
11,1.50546 12.79\
6352,-1.756367 5\
.519995,-1.75636\
2 c 0,0 13.54907\
771,2.258179 15.\
0545308,2.509089\
 1.5054531,0.250\
91 13.7999872,-2\
.759996 13.79998\
72,-2.759996 l 3\
.512724,-0.50181\
9\x22\x0a         id=\x22\
path4455\x22 /><pat\
h\x0a         style\
=\x22fill:none;fill\
-opacity:1;strok\
e:#ffffff;stroke\
-width:4;stroke-\
linecap:round;st\
roke-dasharray:n\
one;stroke-opaci\
ty:1\x22\x0a         d\
=\x22m -44.536321,1\
18.80534 7.77817\
5,-3.01091 6.021\
811,1.50546 12.7\
96352,-1.75636 5\
.519995,-1.75636\
 c 0,0 13.549078\
3,2.25817 15.054\
5313,2.50908 1.5\
05453,0.25091 13\
.7999867,-2.7599\
9 13.7999867,-2.\
75999 l 3.512724\
,-0.50182\x22\x0a     \
    id=\x22path4455\
-8\x22 /><path\x0a    \
     style=\x22fill\
:none;fill-opaci\
ty:1;stroke:#fff\
fff;stroke-width\
:4;stroke-lineca\
p:round;stroke-d\
asharray:none;st\
roke-opacity:1\x22\x0a\
         d=\x22m -4\
3.030869,134.110\
79 7.778176,-3.0\
1091 6.021811,1.\
50546 12.796352,\
-1.75637 5.51999\
5,-1.75636 c 0,0\
 13.5490781,2.25\
818 15.0545311,2\
.50909 1.505453,\
0.25091 13.79998\
69,-2.76 13.7999\
869,-2.76 l 3.51\
2724,-0.50182\x22\x0a \
        id=\x22path\
4455-5\x22 /><path\x0a\
         style=\x22\
fill:none;fill-o\
pacity:1;stroke:\
#ffffff;stroke-w\
idth:4;stroke-li\
necap:round;stro\
ke-dasharray:non\
e;stroke-opacity\
:1\x22\x0a         d=\x22\
m -43.783595,149\
.16532 7.778176,\
-3.01091 6.02181\
1,1.50546 12.796\
352,-1.75637 5.5\
19995,-1.75636 c\
 0,0 13.5490773,\
2.25818 15.05453\
04,2.50909 1.505\
4532,0.25091 13.\
7999876,-2.76 13\
.7999876,-2.76 l\
 3.512724,-0.501\
82\x22\x0a         id=\
\x22path4455-3\x22 /><\
path\x0a         st\
yle=\x22fill:none;f\
ill-opacity:1;st\
roke:#ffffff;str\
oke-width:4;stro\
ke-linecap:round\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22\x0a       \
  d=\x22m -44.28541\
4,164.21985 7.77\
8176,-3.01091 6.\
021811,1.50546 1\
2.796352,-1.7563\
7 5.519995,-1.75\
636 c 0,0 13.549\
0784,2.25818 15.\
0545314,2.50909 \
1.505453,0.25091\
 13.7999866,-2.7\
6 13.7999866,-2.\
76 l 3.512724,-0\
.50181\x22\x0a        \
 id=\x22path4455-38\
\x22 /><path\x0a      \
   style=\x22fill:n\
one;fill-opacity\
:1;stroke:#fffff\
f;stroke-width:4\
;stroke-linecap:\
round;stroke-das\
harray:none;stro\
ke-opacity:1\x22\x0a  \
       d=\x22m -32.\
743606,85.685379\
 c 3.592875,-0.7\
13706 -1.589798,\
-0.332789 6.5236\
3,-0.501814 l 3.\
763633,-0.501826\
 5.519995,-1.756\
36 c 0,0 13.5490\
781,2.25818 15.0\
545311,2.50909 1\
.50545298,0.2509\
1 13.7999869,-2.\
76 13.7999869,-2\
.76 l 3.512724,-\
0.50182\x22\x0a       \
  id=\x22path4455-4\
\x22\x0a         sodip\
odi:nodetypes=\x22c\
cccscc\x22 /></g></\
g></svg>\x0a\
\x00\x00\x09@\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg4\x22\x0a   so\
dipodi:docname=\x22\
Catalogue.svg\x22\x0a \
  inkscape:versi\
on=\x220.92.3 (2405\
546, 2018-03-11)\
\x22>\x0a  <metadata\x0a \
    id=\x22metadata\
10\x22>\x0a    <rdf:RD\
F>\x0a      <cc:Wor\
k\x0a         rdf:a\
bout=\x22\x22>\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0a        <d\
c:type\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs8\x22\
 />\x0a  <sodipodi:\
namedview\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#666666\x22\x0a  \
   borderopacity\
=\x221\x22\x0a     object\
tolerance=\x2210\x22\x0a \
    gridtoleranc\
e=\x2210\x22\x0a     guid\
etolerance=\x2210\x22\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0a  \
   inkscape:page\
shadow=\x222\x22\x0a     \
inkscape:window-\
width=\x221851\x22\x0a   \
  inkscape:windo\
w-height=\x221025\x22\x0a\
     id=\x22namedvi\
ew6\x22\x0a     showgr\
id=\x22false\x22\x0a     \
inkscape:zoom=\x222\
.4583333\x22\x0a     i\
nkscape:cx=\x22-87.\
829627\x22\x0a     ink\
scape:cy=\x2265.809\
318\x22\x0a     inksca\
pe:window-x=\x2269\x22\
\x0a     inkscape:w\
indow-y=\x2227\x22\x0a   \
  inkscape:windo\
w-maximized=\x221\x22\x0a\
     inkscape:cu\
rrent-layer=\x22svg\
4\x22 />\x0a  <path\x0a  \
   style=\x22fill:n\
one;fill-rule:ev\
enodd;stroke:#99\
9999;stroke-widt\
h:2.35818648;str\
oke-linecap:roun\
d;stroke-linejoi\
n:bevel;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-opacity\
:1\x22\x0a     d=\x22M 44\
.660175,10.45798\
4 C 38.726902,8.\
637125 32.892432\
,9.4085 24.48078\
7,12.898461 l -0\
.23736,25.43598 \
c 9.22158,-3.350\
699 14.846721,-3\
.943904 20.55241\
,-2.372345 z\x22\x0a  \
   id=\x22path816-3\
-7\x22\x0a     inkscap\
e:connector-curv\
ature=\x220\x22\x0a     s\
odipodi:nodetype\
s=\x22ccccc\x22 />\x0a  <\
path\x0a     style=\
\x22fill:none;fill-\
rule:evenodd;str\
oke:#999999;stro\
ke-width:2.35818\
648;stroke-linec\
ap:round;stroke-\
linejoin:bevel;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
opacity:1\x22\x0a     \
d=\x22M 3.8266767,1\
0.457984 C 9.759\
9467,8.637125 15\
.594417,9.4085 2\
4.006067,12.8984\
61 l 0.23736,25.\
43598 C 15.02184\
7,34.983742 9.39\
67067,34.390537 \
3.6910067,35.962\
096 Z\x22\x0a     id=\x22\
path816-3-7-5\x22\x0a \
    inkscape:con\
nector-curvature\
=\x220\x22\x0a     sodipo\
di:nodetypes=\x22cc\
ccc\x22 />\x0a</svg>\x0a\
\x00\x00\x0e\x11\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22d\
elete2.svg\x22\x0a   i\
nkscape:version=\
\x220.92.4 (unknown\
)\x22>\x0a  <metadata\x0a\
     id=\x22metadat\
a8\x22>\x0a    <rdf:RD\
F>\x0a      <cc:Wor\
k\x0a         rdf:a\
bout=\x22\x22>\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0a        <d\
c:type\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 />\x0a     \
   <dc:title />\x0a\
      </cc:Work>\
\x0a    </rdf:RDF>\x0a\
  </metadata>\x0a  \
<defs\x0a     id=\x22d\
efs6\x22 />\x0a  <sodi\
podi:namedview\x0a \
    pagecolor=\x22#\
ffffff\x22\x0a     bor\
dercolor=\x22#66666\
6\x22\x0a     borderop\
acity=\x221\x22\x0a     o\
bjecttolerance=\x22\
10\x22\x0a     gridtol\
erance=\x2210\x22\x0a    \
 guidetolerance=\
\x2210\x22\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0a     inkscape\
:pageshadow=\x222\x22\x0a\
     inkscape:wi\
ndow-width=\x221863\
\x22\x0a     inkscape:\
window-height=\x221\
025\x22\x0a     id=\x22na\
medview4\x22\x0a     s\
howgrid=\x22false\x22\x0a\
     inkscape:zo\
om=\x220.61458333\x22\x0a\
     inkscape:cx\
=\x22404.84924\x22\x0a   \
  inkscape:cy=\x22-\
120.74709\x22\x0a     \
inkscape:window-\
x=\x2257\x22\x0a     inks\
cape:window-y=\x222\
7\x22\x0a     inkscape\
:window-maximize\
d=\x221\x22\x0a     inksc\
ape:current-laye\
r=\x22g831\x22 />\x0a  <g\
\x0a     id=\x22g831\x22\x0a\
     style=\x22stro\
ke:#37c8ab;strok\
e-width:21;strok\
e-miterlimit:4;s\
troke-dasharray:\
none\x22>\x0a    <g\x0a  \
     id=\x22g1454\x22\x0a\
       transform\
=\x22matrix(0.88034\
148,0,0,0.880341\
48,4.0850408,-3.\
8557222)\x22>\x0a     \
 <path\x0a         \
sodipodi:nodetyp\
es=\x22cc\x22\x0a        \
 style=\x22fill:non\
e;fill-rule:even\
odd;stroke:#37c8\
ab;stroke-width:\
21;stroke-lineca\
p:round;stroke-l\
inejoin:miter;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none;stroke-o\
pacity:1\x22\x0a      \
   d=\x22M 44.74576\
3,46.372881 145.\
91476,146.49003\x22\
\x0a         id=\x22pa\
th812\x22\x0a         \
inkscape:connect\
or-curvature=\x220\x22\
 />\x0a      <path\x0a\
         sodipod\
i:nodetypes=\x22cc\x22\
\x0a         style=\
\x22fill:none;fill-\
rule:evenodd;str\
oke:#37c8ab;stro\
ke-width:21;stro\
ke-linecap:round\
;stroke-linejoin\
:miter;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1\x22\x0a         d=\x22M\
 144.62039,46.80\
4335 46.040128,1\
46.05858\x22\x0a      \
   id=\x22path812-3\
\x22\x0a         inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0a \
   </g>\x0a    <g\x0a \
      id=\x22g1450\x22\
\x0a       transfor\
m=\x22matrix(0.4389\
1751,2.6767091,-\
2.6767091,0.4389\
1751,1499.9421,-\
969.76044)\x22>\x0a   \
   <circle\x0a     \
    r=\x2214.588048\
\x22\x0a         cy=\x225\
56.85822\x22\x0a      \
   cx=\x22311.52576\
\x22\x0a         id=\x22p\
ath1093\x22\x0a       \
  style=\x22opacity\
:1;fill:#999999;\
fill-opacity:1;s\
troke:none;strok\
e-width:17.22429\
085;stroke-linec\
ap:round;stroke-\
linejoin:bevel;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
dashoffset:0;str\
oke-opacity:1;pa\
int-order:normal\
\x22 />\x0a      <path\
\x0a         sodipo\
di:nodetypes=\x22cc\
\x22\x0a         inksc\
ape:connector-cu\
rvature=\x220\x22\x0a    \
     id=\x22path109\
5\x22\x0a         d=\x22m\
 316.74974,562.7\
9153 16.99663,17\
.62227\x22\x0a        \
 style=\x22fill:#b3\
b3b3;fill-rule:e\
venodd;stroke:#9\
99999;stroke-wid\
th:7;stroke-line\
cap:round;stroke\
-linejoin:miter;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22 />\x0a \
     <circle\x0a   \
      r=\x2212.9737\
15\x22\x0a         cy=\
\x22556.82678\x22\x0a    \
     cx=\x22311.444\
46\x22\x0a         id=\
\x22path1093-3\x22\x0a   \
      style=\x22opa\
city:1;fill:#e6e\
6e6;fill-opacity\
:1;stroke:none;s\
troke-width:15.3\
1822777;stroke-l\
inecap:round;str\
oke-linejoin:bev\
el;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-dashoffset:0\
;stroke-opacity:\
1;paint-order:no\
rmal\x22 />\x0a    </g\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x18\x18\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   version\
=\x221.1\x22\x0a   id=\x22sv\
g2\x22\x0a   width=\x2219\
2\x22\x0a   height=\x2219\
2\x22\x0a   viewBox=\x220\
 0 192 192\x22\x0a   s\
odipodi:docname=\
\x22import_models.s\
vg\x22\x0a   inkscape:\
version=\x221.2.1 (\
9c6d41e410, 2022\
-07-14)\x22\x0a   xml:\
space=\x22preserve\x22\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0a   xmlns:sodipo\
di=\x22http://sodip\
odi.sourceforge.\
net/DTD/sodipodi\
-0.dtd\x22\x0a   xmlns\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:svg=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0a   xmlns:cc=\x22\
http://creativec\
ommons.org/ns#\x22\x0a\
   xmlns:dc=\x22htt\
p://purl.org/dc/\
elements/1.1/\x22><\
metadata\x0a     id\
=\x22metadata8\x22><rd\
f:RDF><cc:Work\x0a \
        rdf:abou\
t=\x22\x22><dc:format>\
image/svg+xml</d\
c:format><dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 /><dc:title /\
></cc:Work></rdf\
:RDF></metadata>\
<defs\x0a     id=\x22d\
efs6\x22 /><sodipod\
i:namedview\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#666666\x22\x0a\
     borderopaci\
ty=\x221\x22\x0a     obje\
cttolerance=\x2210\x22\
\x0a     gridtolera\
nce=\x2210\x22\x0a     gu\
idetolerance=\x2210\
\x22\x0a     inkscape:\
pageopacity=\x220\x22\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0a   \
  inkscape:windo\
w-width=\x222560\x22\x0a \
    inkscape:win\
dow-height=\x221017\
\x22\x0a     id=\x22named\
view4\x22\x0a     show\
grid=\x22false\x22\x0a   \
  inkscape:zoom=\
\x220.65429688\x22\x0a   \
  inkscape:cx=\x22-\
588.41791\x22\x0a     \
inkscape:cy=\x22-20\
7.85672\x22\x0a     in\
kscape:window-x=\
\x22-8\x22\x0a     inksca\
pe:window-y=\x22-8\x22\
\x0a     inkscape:w\
indow-maximized=\
\x221\x22\x0a     inkscap\
e:current-layer=\
\x22svg2\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pagechecke\
rboard=\x220\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22 /><\
g\x0a     id=\x22g2678\
\x22\x0a     transform\
=\x22matrix(0.55320\
042,0,0,0.598469\
42,8.6310018,192\
.67497)\x22><path\x0a \
      style=\x22opa\
city:1;fill:#1fa\
766;fill-opacity\
:1;stroke-width:\
2.11176;paint-or\
der:stroke fill \
markers\x22\x0a       \
d=\x22m 23.837619,-\
39.213637 c -2.3\
22935,-0.980768 \
-6.204202,-1.179\
152 -9.107857,-4\
.3034 -1.759793,\
-1.893485 -5.674\
4111,-8.840713 -\
5.6744111,-8.840\
713 V -164.06992\
 -275.7821 c 0,0\
 0.134385,-6.590\
47 4.9745161,-10\
.70601 3.683865,\
-3.13236 8.82608\
7,-3.10161 8.826\
087,-3.10161 l 5\
5.396413,-0.5988\
1 55.396423,-0.5\
988 38.61332,38.\
70512 38.61333,3\
8.70513 -0.60177\
,80.64128 -0.601\
77,80.641299 c 0\
,0 -2.20181,6.50\
8531 -4.53166,8.\
87686 -2.45442,2\
.494982 -9.27206\
,4.926555 -9.272\
06,4.926555 l -8\
3.90353,0.430319\
 c -46.146941,0.\
236687 -85.80409\
8,-0.372116 -88.\
127031,-1.35287 \
z M 191.72201,-2\
02.5039 c 0,-0.3\
0357 -15.67978,-\
16.2101 -34.8439\
3,-35.34787 l -3\
4.84394,-34.7959\
2 v 35.34787 35.\
34787 h 34.84394\
 c 19.16415,0 34\
.84393,-0.24839 \
34.84393,-0.5519\
5 z\x22\x0a       id=\x22\
path817\x22\x0a       \
inkscape:connect\
or-curvature=\x220\x22\
\x0a       sodipodi\
:nodetypes=\x22cscc\
cscccccccscscssc\
ccss\x22 /><g\x0a     \
  id=\x22g2568\x22\x0a   \
    transform=\x22m\
atrix(0.9128977,\
0,0,0.64716112,2\
4.343284,-37.486\
011)\x22><g\x0a       \
  id=\x22g1140\x22\x0a   \
      style=\x22fil\
l:#ffffff;stroke\
:none\x22\x0a         \
transform=\x22trans\
late(407.30746,3\
2.477612)\x22><rect\
\x0a           styl\
e=\x22opacity:1;fil\
l:#ffffff;stroke\
:none;stroke-wid\
th:1.17752\x22\x0a    \
       id=\x22rect1\
011\x22\x0a           \
width=\x22123.59569\
\x22\x0a           hei\
ght=\x22139.93283\x22\x0a\
           x=\x22-3\
75.9761\x22\x0a       \
    y=\x22-226.0116\
\x22\x0a           ry=\
\x2211.583521\x22 /><r\
ect\x0a           s\
tyle=\x22opacity:1;\
fill:#ffffff;str\
oke:none\x22\x0a      \
     id=\x22rect101\
3\x22\x0a           wi\
dth=\x2248.907463\x22\x0a\
           heigh\
t=\x2238.208954\x22\x0a  \
         x=\x22-366\
.80597\x22\x0a        \
   y=\x22-220.08357\
\x22 /><rect\x0a      \
     style=\x22fill\
:#ffffff;stroke:\
none\x22\x0a          \
 id=\x22rect1013-4\x22\
\x0a           widt\
h=\x2248.907463\x22\x0a  \
         height=\
\x2238.208954\x22\x0a    \
       x=\x22-310.7\
2836\x22\x0a          \
 y=\x22-219.76704\x22 \
/><rect\x0a        \
   style=\x22fill:#\
ffffff;stroke:no\
ne\x22\x0a           i\
d=\x22rect1013-6\x22\x0a \
          width=\
\x2248.907463\x22\x0a    \
       height=\x223\
8.208954\x22\x0a      \
     x=\x22-366.358\
8\x22\x0a           y=\
\x22-174.88535\x22 /><\
rect\x0a           \
style=\x22fill:#fff\
fff;stroke:none\x22\
\x0a           id=\x22\
rect1013-4-6\x22\x0a  \
         width=\x22\
48.907463\x22\x0a     \
      height=\x2238\
.208954\x22\x0a       \
    x=\x22-310.2811\
9\x22\x0a           y=\
\x22-174.56882\x22 /><\
rect\x0a           \
style=\x22fill:#fff\
fff;stroke:none\x22\
\x0a           id=\x22\
rect1013-1\x22\x0a    \
       width=\x2248\
.907463\x22\x0a       \
    height=\x2238.2\
08954\x22\x0a         \
  x=\x22-365.81845\x22\
\x0a           y=\x22-\
130.41977\x22 /><re\
ct\x0a           st\
yle=\x22fill:#fffff\
f;stroke:none\x22\x0a \
          id=\x22re\
ct1013-4-5\x22\x0a    \
       width=\x2248\
.907463\x22\x0a       \
    height=\x2238.2\
08954\x22\x0a         \
  x=\x22-309.74084\x22\
\x0a           y=\x22-\
130.41977\x22 /></g\
><path\x0a         \
style=\x22opacity:1\
;fill:#20a867;fi\
ll-opacity:1;str\
oke:none;stroke-\
width:0.270178\x22\x0a\
         d=\x22m 40\
.675762,-168.534\
91 v -19.04755 h\
 24.31603 24.316\
03 v 19.04755 19\
.04756 h -24.316\
03 -24.31603 z\x22\x0a\
         id=\x22pat\
h1775\x22 /><path\x0a \
        style=\x22o\
pacity:1;fill:#2\
0a867;fill-opaci\
ty:1;stroke:none\
;stroke-width:0.\
270178\x22\x0a        \
 d=\x22m 96.602632,\
-168.12964 v -18\
.91247 h 24.3160\
28 24.31603 v 18\
.91247 18.91247 \
H 120.91866 96.6\
02632 Z\x22\x0a       \
  id=\x22path1777\x22 \
/><path\x0a        \
 style=\x22opacity:\
1;fill:#20a867;f\
ill-opacity:1;st\
roke:none;stroke\
-width:0.270178\x22\
\x0a         d=\x22m 9\
7.142992,-123.00\
989 v -18.91247 \
h 24.316028 24.3\
1603 v 18.91247 \
18.91246 H 121.4\
5902 97.142992 Z\
\x22\x0a         id=\x22p\
ath1779\x22 /><path\
\x0a         style=\
\x22opacity:1;fill:\
#20a867;fill-opa\
city:1;stroke:no\
ne;stroke-width:\
0.270178\x22\x0a      \
   d=\x22m 41.21612\
2,-123.28007 v -\
18.91247 h 24.31\
603 24.31603 v 1\
8.91247 18.91247\
 h -24.31603 -24\
.31603 z\x22\x0a      \
   id=\x22path1781\x22\
 /><path\x0a       \
  style=\x22opacity\
:1;fill:#20a867;\
fill-opacity:1;s\
troke:none;strok\
e-width:0.270178\
\x22\x0a         d=\x22m \
41.756472,-78.83\
5768 v -19.04756\
 h 24.31603 24.3\
1603 v 19.04756 \
19.047554 h -24.\
31603 -24.31603 \
z\x22\x0a         id=\x22\
path1783\x22 /><pat\
h\x0a         style\
=\x22opacity:1;fill\
:#20a867;fill-op\
acity:1;stroke:n\
one;stroke-width\
:0.270178\x22\x0a     \
    d=\x22m 97.6833\
42,-78.835768 v \
-19.04756 h 24.3\
16028 24.31603 v\
 19.04756 19.047\
554 H 121.99937 \
97.683342 Z\x22\x0a   \
      id=\x22path17\
85\x22 /></g></g><p\
ath\x0a     inkscap\
e:connector-curv\
ature=\x220\x22\x0a     i\
d=\x22path817-5\x22\x0a  \
   d=\x22m 127.7435\
,178.61424 v -3.\
96301 h 28.90983\
 28.90984 v 3.96\
301 3.96302 H 15\
6.65333 127.7435\
 Z m 14.45492,-2\
6.08983 -14.0981\
6,-13.54029 h 8.\
08158 8.08156 v \
-11.88904 -11.88\
904 h 12.38993 1\
2.38994 v 11.889\
04 11.88904 h 8.\
08157 8.08156 l \
-14.09814,13.540\
29 c -7.754,7.44\
717 -14.25871,13\
.54031 -14.45493\
,13.54031 -0.196\
21,0 -6.70092,-6\
.09314 -14.45491\
,-13.54031 z\x22\x0a  \
   style=\x22fill:#\
5500d4;stroke-wi\
dth:0.674273\x22 />\
</svg>\x0a\
\x00\x00\x0b\x1d\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22c\
opy2right.svg\x22\x0a \
  inkscape:versi\
on=\x220.92.3 (2405\
546, 2018-03-11)\
\x22>\x0a  <metadata\x0a \
    id=\x22metadata\
8\x22>\x0a    <rdf:RDF\
>\x0a      <cc:Work\
\x0a         rdf:ab\
out=\x22\x22>\x0a        \
<dc:format>image\
/svg+xml</dc:for\
mat>\x0a        <dc\
:type\x0a          \
 rdf:resource=\x22h\
ttp://purl.org/d\
c/dcmitype/Still\
Image\x22 />\x0a      \
  <dc:title></dc\
:title>\x0a      </\
cc:Work>\x0a    </r\
df:RDF>\x0a  </meta\
data>\x0a  <defs\x0a  \
   id=\x22defs6\x22 />\
\x0a  <sodipodi:nam\
edview\x0a     page\
color=\x22#ffffff\x22\x0a\
     bordercolor\
=\x22#666666\x22\x0a     \
borderopacity=\x221\
\x22\x0a     objecttol\
erance=\x2210\x22\x0a    \
 gridtolerance=\x22\
10\x22\x0a     guideto\
lerance=\x2210\x22\x0a   \
  inkscape:pageo\
pacity=\x220\x22\x0a     \
inkscape:pagesha\
dow=\x222\x22\x0a     ink\
scape:window-wid\
th=\x221851\x22\x0a     i\
nkscape:window-h\
eight=\x221025\x22\x0a   \
  id=\x22namedview4\
\x22\x0a     showgrid=\
\x22false\x22\x0a     ink\
scape:zoom=\x221.22\
91667\x22\x0a     inks\
cape:cx=\x22-123.45\
297\x22\x0a     inksca\
pe:cy=\x2296.000006\
\x22\x0a     inkscape:\
window-x=\x2269\x22\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22g820\x22 \
/>\x0a  <path\x0a     \
style=\x22fill:#999\
999;stroke-width\
:1.33333337\x22\x0a   \
  d=\x22m 53.118644\
,179.49816 c -1.\
46666,-0.62009 -\
4.16666,-2.7414 \
-6,-4.71401 l -3\
.33333,-3.58656 \
V 108.66398 46.1\
30379 l 4.35897,\
-4.358975 4.3589\
8,-4.358974 h 50\
.615376 50.61539\
 l 4.35897,4.358\
974 4.35897,4.35\
8975 v 62.615381\
 62.61539 l -4.3\
5758,4.35897 -4.\
3576,4.35897 -48\
.97574,0.27327 c\
 -26.936656,0.15\
029 -50.175736,-\
0.23409 -51.6424\
06,-0.8542 z m 9\
3.999996,-70.752\
4 V 52.745763 h \
-44 -43.999996 v\
 55.999997 56 h \
43.999996 44 z M\
 11.412064,73.43\
7035 l 0.37325,-\
59.308728 4.3576\
7,-4.3579395 4.3\
5768,-4.3579381 \
51.30899,-0.3786\
652 51.308986,-0\
.3786654 v 8.045\
3322 8.045332 h \
-47.999996 -48 v\
 56 55.999997 h \
-8.03992 -8.0399\
1 z\x22\x0a     id=\x22pa\
th817\x22\x0a     inks\
cape:connector-c\
urvature=\x220\x22 />\x0a\
  <g\x0a     id=\x22g8\
20\x22\x0a     transfo\
rm=\x22matrix(-4,0,\
0,-4,-202.16948,\
208.67797)\x22>\x0a   \
 <path\x0a       id\
=\x22path2\x22\x0a       \
d=\x22M 0,0 H 48 V \
48 H 0 Z\x22\x0a      \
 inkscape:connec\
tor-curvature=\x220\
\x22\x0a       style=\x22\
fill:none\x22 />\x0a  \
  <path\x0a       i\
nkscape:connecto\
r-curvature=\x220\x22\x0a\
       id=\x22path4\
489\x22\x0a       d=\x22m\
 -70.565674,30.5\
18916 0.118525,-\
13.037829 -11.49\
6992,6.755966 z\x22\
\x0a       style=\x22f\
ill:#37c8ab;fill\
-rule:evenodd;st\
roke:#37c8ab;str\
oke-width:1.1655\
0279;stroke-line\
cap:butt;stroke-\
linejoin:round;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
opacity:1\x22 />\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x09\xc9\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg6\x22\x0a   so\
dipodi:docname=\x22\
magnifying_glass\
.svg\x22\x0a   inkscap\
e:version=\x220.92.\
4 (unknown)\x22>\x0a  \
<metadata\x0a     i\
d=\x22metadata12\x22>\x0a\
    <rdf:RDF>\x0a  \
    <cc:Work\x0a   \
      rdf:about=\
\x22\x22>\x0a        <dc:\
format>image/svg\
+xml</dc:format>\
\x0a        <dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0a        <d\
c:title />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs10\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#666666\x22\x0a \
    borderopacit\
y=\x221\x22\x0a     objec\
ttolerance=\x2210\x22\x0a\
     gridtoleran\
ce=\x2210\x22\x0a     gui\
detolerance=\x2210\x22\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0a    \
 inkscape:window\
-width=\x221863\x22\x0a  \
   inkscape:wind\
ow-height=\x221025\x22\
\x0a     id=\x22namedv\
iew8\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
2.3975339\x22\x0a     \
inkscape:cx=\x22-16\
5.85427\x22\x0a     in\
kscape:cy=\x22105.8\
8619\x22\x0a     inksc\
ape:window-x=\x2257\
\x22\x0a     inkscape:\
window-y=\x2227\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g6\x22 />\x0a  <path\x0a \
    d=\x22M0 0h48v4\
8h-48z\x22\x0a     id=\
\x22path2\x22\x0a     fil\
l=\x22none\x22 />\x0a  <c\
ircle\x0a     style\
=\x22opacity:1;fill\
:#999999;fill-op\
acity:1;stroke:n\
one;stroke-width\
:17.22429085;str\
oke-linecap:roun\
d;stroke-linejoi\
n:bevel;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-dashoff\
set:0;stroke-opa\
city:1;paint-ord\
er:normal\x22\x0a     \
id=\x22path1093\x22\x0a  \
   cx=\x2218.237631\
\x22\x0a     cy=\x2217.87\
5154\x22\x0a     r=\x2214\
.588048\x22 />\x0a  <p\
ath\x0a     style=\x22\
fill:#b3b3b3;fil\
l-rule:evenodd;s\
troke:#999999;st\
roke-width:7;str\
oke-linecap:roun\
d;stroke-linejoi\
n:miter;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-opacity\
:1\x22\x0a     d=\x22M 23\
.461607,23.80847\
6 40.458238,41.4\
3075\x22\x0a     id=\x22p\
ath1095\x22\x0a     in\
kscape:connector\
-curvature=\x220\x22\x0a \
    sodipodi:nod\
etypes=\x22cc\x22 />\x0a \
 <circle\x0a     st\
yle=\x22opacity:1;f\
ill:#e6e6e6;fill\
-opacity:1;strok\
e:none;stroke-wi\
dth:15.31822777;\
stroke-linecap:r\
ound;stroke-line\
join:bevel;strok\
e-miterlimit:4;s\
troke-dasharray:\
none;stroke-dash\
offset:0;stroke-\
opacity:1;paint-\
order:normal\x22\x0a  \
   id=\x22path1093-\
3\x22\x0a     cx=\x2218.1\
56338\x22\x0a     cy=\x22\
17.843712\x22\x0a     \
r=\x2212.973715\x22 />\
\x0a</svg>\x0a\
\x00\x00\x09\xd1\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg6\x22\x0a   so\
dipodi:docname=\x22\
magnifying_glass\
2.svg\x22\x0a   inksca\
pe:version=\x220.92\
.4 (unknown)\x22>\x0a \
 <metadata\x0a     \
id=\x22metadata12\x22>\
\x0a    <rdf:RDF>\x0a \
     <cc:Work\x0a  \
       rdf:about\
=\x22\x22>\x0a        <dc\
:format>image/sv\
g+xml</dc:format\
>\x0a        <dc:ty\
pe\x0a           rd\
f:resource=\x22http\
://purl.org/dc/d\
cmitype/StillIma\
ge\x22 />\x0a        <\
dc:title></dc:ti\
tle>\x0a      </cc:\
Work>\x0a    </rdf:\
RDF>\x0a  </metadat\
a>\x0a  <defs\x0a     \
id=\x22defs10\x22 />\x0a \
 <sodipodi:named\
view\x0a     pageco\
lor=\x22#ffffff\x22\x0a  \
   bordercolor=\x22\
#666666\x22\x0a     bo\
rderopacity=\x221\x22\x0a\
     objecttoler\
ance=\x2210\x22\x0a     g\
ridtolerance=\x2210\
\x22\x0a     guidetole\
rance=\x2210\x22\x0a     \
inkscape:pageopa\
city=\x220\x22\x0a     in\
kscape:pageshado\
w=\x222\x22\x0a     inksc\
ape:window-width\
=\x221863\x22\x0a     ink\
scape:window-hei\
ght=\x221025\x22\x0a     \
id=\x22namedview8\x22\x0a\
     showgrid=\x22f\
alse\x22\x0a     inksc\
ape:zoom=\x2213.260\
417\x22\x0a     inksca\
pe:cx=\x2215.581624\
\x22\x0a     inkscape:\
cy=\x2222.07805\x22\x0a  \
   inkscape:wind\
ow-x=\x2257\x22\x0a     i\
nkscape:window-y\
=\x2227\x22\x0a     inksc\
ape:window-maxim\
ized=\x221\x22\x0a     in\
kscape:current-l\
ayer=\x22svg6\x22 />\x0a \
 <path\x0a     d=\x22M\
0 0h48v48h-48z\x22\x0a\
     id=\x22path2\x22\x0a\
     fill=\x22none\x22\
 />\x0a  <circle\x0a  \
   style=\x22opacit\
y:1;fill:#00d4aa\
;fill-opacity:1;\
stroke:none;stro\
ke-width:17.2242\
9085;stroke-line\
cap:round;stroke\
-linejoin:bevel;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-dashoffset:0;st\
roke-opacity:1;p\
aint-order:norma\
l\x22\x0a     id=\x22path\
1093\x22\x0a     cx=\x221\
8.237631\x22\x0a     c\
y=\x2217.875154\x22\x0a  \
   r=\x2214.588048\x22\
 />\x0a  <path\x0a    \
 style=\x22fill:#00\
d4aa;fill-rule:e\
venodd;stroke:#0\
0d4aa;stroke-wid\
th:7;stroke-line\
cap:round;stroke\
-linejoin:miter;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22\x0a    \
 d=\x22M 23.461607,\
23.808476 40.458\
238,41.43075\x22\x0a  \
   id=\x22path1095\x22\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22\x0a     sodi\
podi:nodetypes=\x22\
cc\x22 />\x0a  <circle\
\x0a     style=\x22opa\
city:1;fill:#e6e\
6e6;fill-opacity\
:1;stroke:none;s\
troke-width:15.3\
1822777;stroke-l\
inecap:round;str\
oke-linejoin:bev\
el;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-dashoffset:0\
;stroke-opacity:\
1;paint-order:no\
rmal\x22\x0a     id=\x22p\
ath1093-3\x22\x0a     \
cx=\x2218.156338\x22\x0a \
    cy=\x2217.84371\
2\x22\x0a     r=\x2212.97\
3715\x22 />\x0a</svg>\x0a\
\
\x00\x00\x0aH\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22e\
xport_pickle.svg\
\x22\x0a   inkscape:ve\
rsion=\x220.92.3 (2\
405546, 2018-03-\
11)\x22>\x0a  <metadat\
a\x0a     id=\x22metad\
ata8\x22>\x0a    <rdf:\
RDF>\x0a      <cc:W\
ork\x0a         rdf\
:about=\x22\x22>\x0a     \
   <dc:format>im\
age/svg+xml</dc:\
format>\x0a        \
<dc:type\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0a   \
     <dc:title /\
>\x0a      </cc:Wor\
k>\x0a    </rdf:RDF\
>\x0a  </metadata>\x0a\
  <defs\x0a     id=\
\x22defs6\x22 />\x0a  <so\
dipodi:namedview\
\x0a     pagecolor=\
\x22#ffffff\x22\x0a     b\
ordercolor=\x22#666\
666\x22\x0a     border\
opacity=\x221\x22\x0a    \
 objecttolerance\
=\x2210\x22\x0a     gridt\
olerance=\x2210\x22\x0a  \
   guidetoleranc\
e=\x2210\x22\x0a     inks\
cape:pageopacity\
=\x220\x22\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0a     inkscape:\
window-width=\x2218\
63\x22\x0a     inkscap\
e:window-height=\
\x221025\x22\x0a     id=\x22\
namedview4\x22\x0a    \
 showgrid=\x22false\
\x22\x0a     inkscape:\
zoom=\x220.86915209\
\x22\x0a     inkscape:\
cx=\x22163.84604\x22\x0a \
    inkscape:cy=\
\x22212.80747\x22\x0a    \
 inkscape:window\
-x=\x2257\x22\x0a     ink\
scape:window-y=\x22\
27\x22\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0a     inks\
cape:current-lay\
er=\x22svg2\x22 />\x0a  <\
path\x0a     style=\
\x22fill:#999999;st\
roke-width:1.333\
33337\x22\x0a     d=\x22m\
 11.559322,153.6\
2712 v -8 h 56 5\
5.999998 v 8 8 h\
 -55.999998 -56 \
z m 28,-52.66667\
 -27.30894,-27.3\
33331 h 15.65447\
1 15.654469 v -2\
4 -24 h 24 23.99\
9998 v 24 24 h 1\
5.65447 15.65446\
 L 95.55932,100.\
96045 c -15.0199\
2,15.03334 -27.6\
19918,27.33334 -\
27.999998,27.333\
34 -0.38008,0 -1\
2.98008,-12.3 -2\
8,-27.33334 z\x22\x0a \
    id=\x22path817\x22\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22 />\x0a  <pat\
h\x0a     style=\x22fi\
ll:#20b2aa;fill-\
opacity:1;fill-r\
ule:evenodd;stro\
ke:none;stroke-w\
idth:0.73913848p\
x;stroke-linecap\
:butt;stroke-lin\
ejoin:bevel;stro\
ke-opacity:1\x22\x0a  \
   d=\x22m 105.6322\
7,107.57797 v 73\
.96397 l 72.1599\
7,0.30066 V 88.3\
35317 l -56.5253\
,-0.601334 z\x22\x0a  \
   id=\x22path812\x22\x0a\
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a     sodip\
odi:nodetypes=\x22c\
ccccc\x22 />\x0a  <pat\
h\x0a     style=\x22fi\
ll:#f5f5f5;fill-\
rule:evenodd;str\
oke:none;stroke-\
width:0.73913848\
px;stroke-lineca\
p:round;stroke-l\
inejoin:bevel;st\
roke-opacity:1\x22\x0a\
     d=\x22m 105.63\
227,107.57797 15\
.93533,0.15034 -\
0.30066,-19.9943\
27 z\x22\x0a     id=\x22p\
ath814\x22\x0a     ink\
scape:connector-\
curvature=\x220\x22\x0a  \
   sodipodi:node\
types=\x22cccc\x22 />\x0a\
</svg>\x0a\
\x00\x00\x04]\
\x00\
\x00\x0e\xf6x\xda\xddW\xdfo\xdb6\x10~\xcf_\xc1\
\xa9/\x1bfQ$EQ\x94j\xbb\xc0V\x14\xebC\
_\xb6n{V$\xdaV#\x89\x06E\xdbq\xff\xfa\
\x1em\xfd\xb0\x13ek\x11 \x05\xaa \x80\xee\xee#\
y\xf7\xdd\xc7S2\x7fs_Wh\xafL[\xeaf\
\xe1QL<\xa4\x9a\x5c\x17e\xb3^x\x7f\x7f|\xe7\
K\x0f\xb56k\x8a\xac\xd2\x8dZx\x8d\xf6\xde,o\
\xe6?\xf9>\xfa\xdd\xa8\xcc\xaa\x02\x1dJ\xbbA\xef\x9b\
\xbb6\xcf\xb6\x0a\xfd\xbc\xb1v\x9b\x06\xc1\xe1p\xc0e\
\xe7\xc4\xda\xac\x83_\x90\xef/on\xe6\xed~}\x83\
\x10\x82s\x9b6-\xf2\x85\xd7-\xd8\xeeLu\x02\x16\
y\xa0*U\xab\xc6\xb6\x01\xc54\xf0Fx>\xc2s\
wz\xb9W\xb9\xaek\xdd\xb4\xa7\x95M\xfb\xea\x02l\
\x8a\xd5\x80v\xd9\x1c\xc2\x13\x88&I\x12\x10\x160\xe6\
\x03\xc2o\x8f\x8d\xcd\xee\xfd\xeb\xa5\x90\xe3\xd4RF\x08\
\x09 6\x22\xbf\x0e\x95\xb6@\xe8\x16~\x07x\xef\xc0\
\xad\xde\x99\x5c\xad`\x9d\xc2\x8d\xb2\xc1\xdb\x8fo\x87\xa0\
Opa\x8b\x8bmz>\xafN\xbd\x22\xb9\xc9j\xd5\
n\xb3\x5c\xb5A\xef?\xad\xbf\xe80=9\xcab\xe1\
A\x8e\xecd\x1c\xca\xc2n \x96\x9c\xcd\x8d*\xd7\x1b\
;\xda\xfbR\x1d~\xd3\xf7\x0b\x8f \x82\xc0\x89\xfa@\
\x9fhZ\xe8\xdc\x9d\xbc\xf0\xf2J\xe7w\xb8/\xbeO\
!\x1d\x8e'8a\x98\x22C\xa30\xa6\xde\x12@\xf3\
Z\xd9\xac\xc8l\xe6\x16\x9c\xf3\xea=\xf2\x04\x00\x08\xf4\
)\xfd\xf3\xed\xbb\xb3\x05v\x9e\xa7\xffjs\xd7\x99\xf0\
8@v\xabw\x90\xb4\xb7\x1c\xdc\xf3\x22O\x81\xd9:\
\xb3\xcb\xb2\xce\xd6\xca5\xe5W`r\x1e\x8c\x81+\xb0\
=n\xd5\xb8\xe9y[\xa3\xce-\x9a\xd4i\x91\xd7\xa5\
[\x14\xfce\xcb\xaaz\xef\x0e\xf1P\xf0`\xd3\xd2V\
jt\xce\x83.\xfb\xae\xb6\xe0\xa2\xb8y\xd0\x97~\xb2\
\x0a\xb5jGV\x9c%\xba\xdd\xe7\x03\xf3\x8e\xf6\xc25\
\xe8\x0c\xdcB\x06\xb9\xae\xb4Yx\xafV\xa7\xc7;\x07\
n\xb5)\x94\xe9C\xe2\xf4\x5c\x854\xa8\x06j\x81\xae\
wn}\xfbI\xe5\xd6\xeaJ\x99\xacq\xf5S\xd2E\
\xd6\x06\xf42\xe5\xdf\x95\x85\x9a\x0a\x0c:p\xe9\x0d\x07\
MF\xdbMV\xe8\xc3\xc2c\x0f\x83\x87\xb2\x81\x80\xdf\
K\x95I\xf2\x04\xa2Wo\x12\x0f{\x00{\x03O\xbc\
s\xb6\x1b}p\x85,\xbcUV\xb5\xea\xe1f\x9f\xb5\
\xae\xddm\x89C\x19\x12\xfe(\x9b\x1cn\x03#\x1c\xb3\
\x98I\xfe(\x08\xc5\xf9T`\xc6C\x16\xcb'\xd2\x84\
\x0d\xfc\xa7b\xc7\xff\x88\xd5\xd9}Y\x97\x9fU1v\
j<xg\x0c\x8cM\xbf\xca\x8e\xcat\xf7\xbb\x13\xcc\
6\xb3\x9b\xaep{\xac\xa09]\x1bR\x82#\x1a\xc2\
\xc4\x22\xf4\xf5\x0a4\x9c60\xe6_\xb7\xd6\xe8;\x95\
\x82\x84\x5c\xa43\xcf\xdc\xa7QoVe\xa3\xe0\xd8\xd4\
\xe8]S\x5c:?\xe9\xb2I\xe1b(\xd3{OF\
\x05y\xdb\x94\xf7\xbe\x22\x83^\x1b\x93\x1d/\x8f\xf4\xfb\
\xb4\xfa\xda\xdc8@I\x8c\x05\xa7\x92\xb0\x19%\x14\xcb\
\x98\x86\x11\xf2C\x86\xa5\xa0qDg\x11\xc5L0y\
\xd1mW-\xe7\xc9\xe3\xb6\xe9\x06r\xb6\xda\xf8@\xd5\
>\xb3;\xa3\x9c\x0e;\x8eTU\x95\xdbVM\xd2t\
\xc9\x8e{\x1b\x13\x1d\xc8J\xa4\xfb\xb9&\x8b\x11\xccY\
\xc2dD\xa2\xe7s1V&\xfb\xca\x9c\x0e\x13\x81\xa3\
\xde\x04\xe5$\x11\xe6\xf0\x89\x1b\x8a7\x00\x91\x1c\xc72\
\x0a\xa3\x1eg\x8e\x83O<-\x91\xc7z\x98*\x91\xc2\
@\x0f\x85\x8c%\xa1/\xad\x8c\x0fN\x19\xa1\x08\x81\xdd\
\xb32$4\x1dE\xc0\x07\x8f\x05\xa33!p\x12\x0b\
\x19M\x10\xc8\xbfM\x1a\xcf\xe0F\x84\xd0\x8cH\xbc<\
7\x94\xc7\x98\x13J\xe3\x99\x08q$cx\x9d\xbaI\
\x13\xdc\xf8\xd1W\xb2\xf3\x00ea\xf0\xb7\xee\xc3\xea\xe7\
0\x86\x94qC\x0efd\xc8\xc3\x84\xcb\xff\x05\x83&\
\xb9\xc4!\x0b\x13A\x9f\xc9\xbb\xc4\x11\x8b\x938\xa4\xf2\
;H2\xc1,\x11\xdc)\x12.\x18\xa3B\xa0\x7f\x10\
\x83\xc2\xa20a\xfc\xf1\x90z\x19%~?F`|\
\x0b\xb8\x99\x89\x04!R\x01\x7f\x7f\xc60\xb4\xd1\x1e\xd1\
\x18G\xf0*&\x18\xf1\xd9\x0f\xce\xc9\x07\x04_/\xca\
\x05\x8b\xd8\x0c\xae\xa4\x94\x04F\x04\xfa\x03\xae,p\xc2\
#\xc2\xa6H\xe1?<)0\x98p$D,fp\
\x89\x04\x11\x92\x86\x8e\x14\xc10\xd0\xf3\x04)~\xf8\x0d\
\xb4\xcc\xdd\xbf\x00\xcb\x9b/\xdf\xef\x96$\
\x00\x00\x07G\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg6\x22\x0a   so\
dipodi:docname=\x22\
next.svg\x22\x0a   ink\
scape:version=\x220\
.92.3 (2405546, \
2018-03-11)\x22>\x0a  \
<metadata\x0a     i\
d=\x22metadata12\x22>\x0a\
    <rdf:RDF>\x0a  \
    <cc:Work\x0a   \
      rdf:about=\
\x22\x22>\x0a        <dc:\
format>image/svg\
+xml</dc:format>\
\x0a        <dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0a        <d\
c:title />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs10\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#666666\x22\x0a \
    borderopacit\
y=\x221\x22\x0a     objec\
ttolerance=\x2210\x22\x0a\
     gridtoleran\
ce=\x2210\x22\x0a     gui\
detolerance=\x2210\x22\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0a    \
 inkscape:window\
-width=\x221863\x22\x0a  \
   inkscape:wind\
ow-height=\x221025\x22\
\x0a     id=\x22namedv\
iew8\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
4.9166667\x22\x0a     \
inkscape:cx=\x22-99\
.152543\x22\x0a     in\
kscape:cy=\x2224\x22\x0a \
    inkscape:win\
dow-x=\x2257\x22\x0a     \
inkscape:window-\
y=\x2227\x22\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0a     i\
nkscape:current-\
layer=\x22svg6\x22 />\x0a\
  <path\x0a     d=\x22\
M0 0h48v48h-48z\x22\
\x0a     id=\x22path2\x22\
\x0a     fill=\x22none\
\x22 />\x0a  <path\x0a   \
  style=\x22fill:#0\
0d455;fill-rule:\
evenodd;stroke:#\
00d455;stroke-wi\
dth:2;stroke-lin\
ecap:butt;stroke\
-linejoin:round;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1;fill-\
opacity:1\x22\x0a     \
d=\x22m 14.339033,1\
2.813563 -0.2033\
9,22.372882 19.7\
28814,-11.59322 \
z\x22\x0a     id=\x22path\
4489\x22\x0a     inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0a<\
/svg>\x0a\
\x00\x00\x08v\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22n\
ew2.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x22784\x22\x0a     i\
nkscape:window-h\
eight=\x22480\x22\x0a    \
 id=\x22namedview4\x22\
\x0a     showgrid=\x22\
false\x22\x0a     inks\
cape:zoom=\x221.229\
1667\x22\x0a     inksc\
ape:cx=\x22-47.9999\
97\x22\x0a     inkscap\
e:cy=\x2296.000003\x22\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0a     in\
kscape:window-ma\
ximized=\x220\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <path\x0a     s\
tyle=\x22fill:#9999\
99;stroke-width:\
1.33333337\x22\x0a    \
 d=\x22m 42,172.310\
16 c -1.466667,-\
0.61924 -4.16666\
7,-2.73984 -6,-4\
.71245 l -3.3333\
33,-3.58656 V 93\
.477545 22.94393\
8 l 4.35676,-4.3\
58975 4.356761,-\
4.358974 34.9765\
72,-0.378076 34.\
97657,-0.378076 \
24.37995,24.4379\
04 24.37995,24.4\
37905 -0.37995,5\
0.915854 -0.3799\
5,50.91586 -4.35\
774,4.35764 -4.3\
5775,4.35765 -52\
.975588,0.2717 C\
 68.50568,173.31\
379 43.466667,17\
2.9294 42,172.31\
016 Z M 148,69.2\
10834 c 0,-0.191\
669 -9.9,-10.234\
849 -22,-22.3181\
79 l -22,-21.969\
69 v 22.318178 2\
2.318179 h 22 c \
12.1,0 22,-0.156\
82 22,-0.348488 \
z\x22\x0a     id=\x22path\
817\x22\x0a     inksca\
pe:connector-cur\
vature=\x220\x22 />\x0a</\
svg>\x0a\
\x00\x00\x08L\
\x00\
\x00\x1d\xa9x\xda\xedYY\x8f\xdb\xc8\x11~\xf7\xaf \
8/\x1eD\xa4\xfa>4\xd2,\x12\x18\x8b\x0d\xb0A\
\x80]{s\xbc\x04\x1c\xb2\xa5\xe1\x0eE\x0aMJ\x9a\
\xf1\xafO5\xc5S\xa2\xc6c\xac\xb3@\x90\xc8\xb0\xad\
\xae\xea\xa3\xce\xaf\xaa[\xcb\xef\x9e\xb7\x99w0\xb6L\
\x8b|\xe5\xe3\x10\xf9\x9e\xc9\xe3\x22I\xf3\xcd\xca\xff\xf4\
\xf1\xfb@\xf9^YEy\x12eEnV~^\xf8\
\xdf\xdd\xbf[\x96\x87\xcd;\xcf\xf3\x8eiR=\xae|\
\xa6|7z4\xe9\xe6\xb1\xea\x86\x87\xd4\x1c\xffT<\
\xaf|\xe4!\x8f)\xaf!\xa7\xc9\xca\x87\xe5\xe44\xa7\
?\x19\x9f\xb8\xf9S\x19G;\xb3\x18r\xbc\xf7\xb1P\
\x86\x90\x98*9\xf3\x08\x228@< \xf4\xb6^R\
\x82\xb4;\xf8\xbbH\x8a8\x8f\xb6 d\x9a\xef\xf6U\
\xf9\xaf(\x8f\xb2\x972-=\x12\xc2\x81\xf5\x5c\xd06\
/\x17\xed!+\xff\xb1\xaav\x8b\xf9\xfcx<\x86-\
1,\xecf\xee\xf6)wQl\xcayK\x1f\xaco\
O\xec\xd6\xb7\x84\xb0,\xf666k\xd8\xc2\x84\xb9\xa9\
\xe6\x1f>~\xe8\x98\x01\x0a\x93*\xe9\xb7\x19\x9d~\xa4\
\xf5\xb9\x04!4\x1f\x0b\x0b\xa37\xce\xb4\xc9zj&\
\xd6Z\xcf\x11\x99\x13\x12\xc0\x8c\xa0|\xc9\xab\xe89\xc8\
\xcb\x9b\xc1\xd28\xeeV\xc6\xd6DUz0q\xb1\xdd\
\x16yy2\xc7hr\xd2O\xde\xedmV\xcfH\xe2\
\xb9\xc9\xcc\xd6\xe4U9\x07\x8f\xcd\xfd{\x98\xbf\xdc\x9a\
*J\xa2*rkO\x9eo)\x98\xd43`\x0e\xc8\
\xb4\xf8\xe9\xc3\xf7\xa7\x11\x8c\xe3x\xf1\xb7\xc2>5C\
\xf8\xb8\x09\xd1C\xb1\x87\xc8\xf2\xef;\xf22\x89\x17`\
\xe7mT\xdd\xa7\xdbhc\x9c-\xfe\x00\xf2-\xe7=\
c4\xb9z\xd9\x99~\xd3\xd3\xb6\xd6\x9c\x1c6\xa9O\
\x12oS\xb7h\xfes\x95f\xd9\x9f\xdd!\xbe7\xef\
\xe4\x9c7\x826j\xcc\x07z,\xe7\xad\x9a\xf5(1\
\xeb\xb2\xb7\x80\x1ba\xd4j\xbf\x8d\xec\x93\xb1\xad\x5c]\
\xf4\x97U\x11?\xb9\xd9\x7f\xb4\xb68\xe2\x1f!\x05m\
\xe5\xb7\xd3\x0a\x9b\x82\xa1W~\xb4\xaf\x8a\x8eh\xcd\xfa\
\x1f\x90k\x90\xc1\x03\xca\xdf\xc7\x94\xab;\x96\xd5K\x06\
V( \xeb\xd6Yq\x5c\x1c\xd22}\xc8\x8c\x7f!\
XZ\xd6\xa2\xad\xfc\xca\xeeM\xe7\x8e\xe5.\xaa\x1e{\
\xe3\xbac\x1c\x85q\xad\xfc\x9e\x0c\xd4\xbfx \xce\x0c\
\xfez?z\x1c\xbe\x05\xbc\xfe\x1a`\x12\xf2\x01\xf9D\
m\xa7~\xf6\x06\x9b4\x92\xae\xc1%\x81\xddgfa\
\x0e&/\x92\xe4\xae\xacl\xf1d\x167\xa8\xfe4\xc3\
\xa0F\xa8\x05\xe0\xda\xae\x1alR\xd9(/]\x90\x00\
\x14\xc5Qf\xde\xa3P\xdd\x9e\xa8YT\x99\xf7'q\
n;w\x83Ck?5#\xd0\xad26o\xf7k\
\x86\x9f\xf2\xb4\x82\xa4\xde\x97\xc6\xfe\xec\xa0\xe3\xaf\xf9\xa7\
\xb2\xb7`\x03\x954\xa4\x88\x11ID\xc7\xe8P3\xd4\
\x5c\x0b\x8czN\xb3\xef\xc7^\xd8^B\x19\x0a\xc1\xb5\
\x96|\xa6CF%l\xaanGnn\x16\xbb9\xbd\
\x9b*\xf3\x5c\xf5V\x80lY\xd4 \x07\xb3!\x13\x8c\
=\x98\x09C\x17y\x15\xd4\xdf\x17\xb9\xcb\xaa\xec\xae\xa6\
\x1ck\xa9G\xa42\xfdl\x16\x22\xe4\x5cR\xb2{\xbe\
\xcb\xd2\xdc\x04'\xe5\xc0\xfe\x84\x9f&\xad\xa3m\x9a\xbd\
,J\xd0#\x80\x13\xd3\xf5\x9d\xf3\xe4\xe2\xe6\x81\xba?\
\xf5 (@&\xc8\xbc\x05n}\x9aC\xe9\x19;\x14\
\x85XPM\xe9@^(4\x80\xb0\x8c\x12\xc2\x98\x16\
\x03\xc6\x8b\xb3\xad\x12Br\xa9\xfdq\x90:{`.\
\x85\x7f\xbf\xac\xc0\x12\xf9\x10\x1f\xba\xb2b\x0bg\x07\xa7\
\x8e?\xe4\xd7\xeb\xdd\x22\xd8\x80\x8d8\x83\x10}]\xb1\
\xeb\xca\xbc\xa2\xce\x99B\xf7h9\xaf\xc5\xb8\x87\xffA\
\x9d6`\x1b\xff\x9f\xe0\xc8aN\xfd\xadS\xca\x15\xb8\
\xc4U\xe8wM\xa8m\x00\xf0\xb3\xc2\xae\xfc\x9bu\xfd\
iN|(lbl\xcb\x12\xf5g\xc4jt\x82:\
\xdd\x90\x8b\x87_M\x5cU`4\x08V\x17[\xb8\xc5\
\x9f\x8d\x05u\xa7\xe8\xfb41S\x8c\x0eu\x9cx\xdd\
A\x93\xdc\xf21J\x8a\xe3\xca'\xe7\xccc\x9a\x03#\
h\xd2\x0f+\xae\xae\xcch\xf3\x10#.\xfd\x1e\xae;\
C\xb5\xeb\xca\xc7\xe2\xe84\x01\x07GY\x97\xe0\xddn\
\x9f\x8b\x02\x12\x15\xd3\x90\x13\xa4:\x9fv\xec\x18\xfcJ\
5\x80\x80\x96\xe8B\x92\x18\xb4\xa38\x14\x1a+\xca\xae\
\x88\x09\xeb\xf95\x1e,\x0f\xae\xa9\xb7\x8d\x9e\xd3-d\
h\xd2{\xaa?wo-\x14\x94 \x8b^\x0c\xb8y\
\x83\x09\x9f4r\xfchb@\xc1\x87\x22\xb2\x89\xf3\xc3\
\x09\x1e\x97\x9b\xdeZ\x1b\x86yW\xdb6C<\xda0\
\xce\xd8\x97\x0b\x06E\x17\x05c\x86\xbc\x1f\x5c\xff\xf8\x8b\
\xfb\xe7\x07\xe8%\xff9\xcc\xe2N\x87\x22\xcf!\xee\x0a\
\x1b\x806\x87\xa8\xda[\xd3\x87\xcayV:@\x19\xd6\
\xf2\xcdX\x94\x8dFx\xbaZ@Wa\xd3\xe7\xf7P\
O$\xd5D\xb3\x19H7\xebGB\x87\xd0lq\xcc\
gD\x86X\x11M\xf1\xed\xb0g\xb1 \xe15\xa4\x18\
\x80\xdc\xe2F\xd7\x9f1L@HQ\xc5\x90\x14\xbc\xa5\
;L\x02\xe5\x01\xa1\xf6y2$\xfeZ\xa4\xf9\x98\x0a\
\xad\x8c\xb1\x19D@\xb5`--\x89 k\xac\x8d^\
F\x00\xdb\x81\xd4\x05\xda9\xe95\x1bcQ[\xd6D\
((\x15z\x0c\x84mJQ\x1eb\xaa\xe8\x19L:\
\x84\x13(\x94\x12i\xca\xcf\x01.\xc0:\x84$\x80U\
#\x8e\x05\x16\x0f\xa9\x96\x9a\x0b6\xf0\xe0\xd8\x87\x8d\x17\
%\xd3r\xb4\xba\x9a\xaa\xa4(\xe4\x0a\xd2\x11a=t\
\xd5\xf9\x86\xcd\x96\x83\xcc\xb8\x1e\x1d4D\x08#@\xee\
::\xa0\x95\xe0\x1a\x11\xc4g\x18\x83\x1d\xa4\xc2\xcaE\
\x87@\x9a\x102>\xf2\x22/\xc6\xb6\x17\x08a\xff\x9c\
y%\x84\xba\xd2\xa2\xa4\xd2\x9a^,s\xad\xb8\x17p\
\xe9\x84\xa3J\xcc\x02,C\x821b\xda{\x84\xfb\x92\
F\x8cQ\xea\x1d<\x16R\x0e>\x17@\x0d:\xf2\xe7\
\x91\xe5_\x95\x1b\xba!\x09\xed\xc9\x7f\xa7\xd8\xfc?'\
6\x0a\x85\x84b\x84'\xc5\xa6\xfc7\xc9\xad\xbe\xb5\xdc\
8\xa4\x0c1,'\xe5fW\xe4fSro\xceO\
\x88l\x1aA\xddy0Y_\x97\xbc\xcb\x1eM*q\
=\xf4\x07\xcd'\xa5\x9c\xd1\xc9\xe6\xb3n\xc6\x10JX\
\x14]t_\x00\x00J\x5cl\x7f\x99\xd8\x00V\x94S\
\x00\xba\x13\xee\x0f\x86\xee\x02#\x88V\x92B\xbeK)\
\x00M\xe8yn_q[ge\x0a-=!\x14\xf6\
b\xa1\x84\x86\x10+\xb0&\xd4\x16\xe8#\x98\x00#\x07\
\xae\xa7\xa0L0/\x83\x0bS\x08Q\xcf\xb9\x00!\x00\
F\xa4\x0b\x1eh\x179\xb4\x0eZ\x03\x1f\xd8\x88\x01\x1e\
\xcf\x82\x96\xff\x08\xd7)A\x98R\xa4\xf6\x17\xa0\x8f\x10\
\xb4?\x80\x03\x15\xd6\x13\xae\xf4\xc9\x87B 0\x0a\xf8\
\xf0R\xde\xaeZSL\xd4\xa5\x8f\xe7\x9b3\xc2\xf8\xd6\
\xf1\x96\xbb\xc7o\xb9\x81\xb8X\x14\x8a~\xf5\x0d\xa4)\
\xb9_q\x03AJ\x93\x0b\xa1]U\xe3\x02\x12\x0a\x0b\
&/\xb8\xae\xb2\x89P\x0b\x81\x99\xd0W\xc3\x1d\x92\x9e\
N\xdeI\xdev39\xbb\x9f\xb8\xdd\xd8\xc4\x84\xd15\
\xe55\xed\xbf\xa0\xf1\x97t>\xd7z\xfa\xc6\xf2?\x1d\
-\x12\xec\x82'\x83\x05pEA\xcb\x87\xd8k\xc1\xc2\
\xd07\x0d\x16\xf5{\x04\xcb\xb4\xca\xe7J\xff?V\xce\
\x0c\x87C\xe6\xdaIq-X\xa0\x8feR\xbd\x1e,\
\xc1\xb7\xc5\x16\x15\xfc\x0e\xe8rU\xefs\xcd_\x8b\x98\
\xb3\xd2t\xa5\xc3\x17\xec\x8b\x1d~]J1\x81\x1a\xdb\
4\x02\xdd0\xe0\xee5\x87c<\x0bT\x88\xb5T\x84\
\xb375\xf9o\xb8\xeb\x8e\xab\xef\xa5\xa9\x9cy\xdd/\
4\xa3\xbbm\xfb\xaa\x9e\xda83W\xf2\xa0wI\xdf\
 NG\xebd\x07\x05y!)\xa6o\xbb\x95>\x98\
\x83\xc9\xbe\xfeV\xea\xa8\xc5z]\x9aj\x81.n\xaa\
w\xbb(\x85\xfc\xab\xdf\xa3\x9a\xb4\xbdj6\x8c&\xfa\
\x5c\xf7*\x03\x17N\xaa\x05\xe1\x97\xc1\xec\x9ee\xb0\x0a\
%\x22\x92]Z\xdd\x02\x93\x01\x06Ph\xa3\xde\xd6\xa8\
\x8fR\xa31\xe8k\xef\xd9\x97\x16\x97!TR\xc1\xde\
f\xf1\xda\xc8\xdf\xea\x1d\xa0\xebW\x09\x98\x8b\x11h2\
g\x14\xae\x0fD\xc3m\xd6\x03\x1bA?,\xb5{\x93\
\xc6\x081\xf5\x9a\x17./)o\x7f\xcb9\xc3*\xb0\
\x97q\xbf\xd4\x94+?\x8e\xcf|0\xca\xf9\xc1\xa0\xfb\
\xda\x7f\xe9\xe0`\xf2\x9d\x00\x1ae$$Q\xd0\xa0\x13\
\x1e*%A\xe7\xf1\x93\xfb\x86a\xd6?J\x9c?\x7f\
\x09\xdck|\xed!\x02\x13\xa6\x89n\x7fw\xa8%[\
\xba\x1f\xb6\xee\xdf\xfd\x1b\xda\x80\xb5 \
\x00\x00\x06\xc6\
\x00\
\x00$\xebx\xda\xddZYo\xe36\x10~\xcf\xafP\
\xb5/\xbb\xa8EqxS\xb5S\xa0],\xd0\xd7\x1e\
\xe8\xb3\x221\xb6\xba\xb2dHr\x9c\xf4\xd7w(\xdf\
\x87\x80\xb4pQ\xd7r\x82\x84\x9c\xe1\xf5\xe9\x9b\x8b\xc9\
\xf8\xfb\xd7y\x19\xbc\xb8\xa6-\xeaj\x12\x02\xa1a\xe0\
\xaa\xac\xce\x8bj:\x09\x7f\xfb\xf5Kd\xc2\xa0\xed\xd2\
*O\xcb\xbar\x93\xb0\xaa\xc3\xef\x1f\x1f\xc6\xdfDQ\
\xf0c\xe3\xd2\xce\xe5\xc1\xaa\xe8f\xc1O\xd5\xd76K\
\x17.\xf88\xeb\xbaE\x12\xc7\xab\xd5\x8a\x14\x9bNR\
7\xd3\xf8S\x10E\x8f\x0f\x0f\xe3\xf6e\xfa\x10\x04\x01\
\xae[\xb5I\x9eM\xc2\xcd\x80\xc5\xb2){\xc5<\x8b\
]\xe9\xe6\xae\xea\xda\x18\x08\xc4\xe1^=\xdb\xabg~\
\xf5\xe2\xc5e\xf5|^Wm?\xb2j?\x1c(7\
\xf9\xf3N\xdb\xeff\xc5{%\xb0\xd6\xc6\x94\xc5\x8cE\
\xa8\x11\xb5oU\x97\xbeF\xc7Cq\x8f\x97\x862J\
i\x8c\xb2\xbd\xe6\xfb\xb4\x92\x16\x01]\xe0\xf7N}\xdb\
A\xdaz\xd9d\xee\x19\xc79R\xb9.\xfe\xfc\xeb\xe7\
\x9d0\xa2$\xef\xf2\x83i\xb6x\x1e\xadz\x04r\x95\
\xce]\xbbH3\xd7\xc6\xdb\xfe~\xfc\xaa\xc8\xbb\xd9$\
\x14\xa6o\xcd\x5c1\x9du\xbb\xe6K\xe1V?\xd4\xaf\
\x93\x90\x064\x10\x06\xbf\x08\xf5\x0f\xf4\xd2\x22\x9f\x84x\
\x1a\xb6V\xdd3e#\xdd\xac\x92\xec$\x94XFx\
\xf0\x91\x09*\xa5P\xa3\x80Q0\x11\xe5\x11\xc0\xa7~\
\xc8\xf6xI^g~\xbf8}6ss|\x9b\x19\
\xf1\xb0=\xa2\xd28w\xcf\xadW^\xaf\xef[\x22\x0c\
\xe2^\xb4\x1b\xef\x07\xe7~\xf3{\xc5\xa7\xb4]\x1f8\
\x08\x16\xe9\x14\xc9Q\xd6\xcd$\xfc\xf0\xdc?\x1b\xc1S\
\xdd\xe4\xae\xd9\x8aT\xff\x1c\x89j\x04\xb0\xe8\xde\xd6\xe6\
\xb0\x99{{L?\xebNN/\xcb\xdbY\x9a\xd7\xab\
I\xc8N\x85\x7f\xd6\xf5\x1cQ'\xda(!\x0d?\x15\
g\xf8\x0a\x04\x10\xa9\xad\xa5\xfaL\xe8\xf7#\x09\xe7\x16\
@\x9e\x0a\x11\xc9\xa57\x98hY\x15\x1d\x92r\xf1z\
6|\xd94^\xa1L\xdf\x1c\x1e{\xca\x85\x80\x8dN\
;\xabW\xd3\xc6\xa3\xf7\x9c\x96;\xf8\x06gZ\x15\x15\
\x9e.\xda0\x0a\x8c\x84\x01\x8d-\xcb\x8029\xa0\x82\
\x07Vv@\x86\xe7ez@6O_\x8by\xf1\xa7\
\xc3=\xc3\x96\x16s\xd7\xa5y\xda\xa5{2l{t\
O)TA{O~\xfe\xfce\xdd\xc2v\x96%\xbf\
\xd7\xcd\xd7M\x13\x1f\xaf\x90>\xd5K\xdcu\xf8\xb8\xeb\
\x1e\xe7Y\x82\x16\x8a\x0c},\xe6\xf8~\xbdq\x7f\x8b\
\x169\x8e\xf7\x82#\xe5\xeem\xe1\xf6\x93\xae\xa7m\xdc\
\xda\xd4/\xfa\xbb<\x9b\x17~P\xfcKW\x94\xe5O\
~\x91\xcd\xb1\x0e&-\xba\xd2\xed;\xc7\xf1f\xf7\x9b\
\xb3\xc5\x07\x87\x1b\xc7\xdb\xa3\xf7\xad\xe9\x09\x88e\xfa\xe4\
\xcaI\xf8c\xbaH\x83\xb3\x977m\xea\xe5b^\xe7\
\xb8\xd1\x9e+\xe1\x1e\xcf\xbe\xbd\x1d\xd05i\xd5\xfa\xc3\
O\xc2\xfe\xd7\x12c\xc1G:\x8a\x80RA\xb8b\xec\
\xd3\x16\xf5\xe9\xf6\x18~\x8eC\xe2\x1dM\x82 6\xc5\
\xebGJ\x8cR\xa0\xb8\xe4#\xea?\xfb&#Jj\
m\xb4\x1d\x01\xd7\x044\xe3\x1b\x7f\xd2s\xb8{+q\
\xc7\xcf\x88^\xb2\xb1\xf6\xef\xda\xae\xa9\xbf\xba\xe4\x83\xc8\
\xfd'\xdc\xbf\xf5\xa2\xc9\xca\x83\xf7\xd3xC\x97\xe1\xbe\
\xa375J\x0d\xe1 \xf5a?\xd2\x95\x09\x22\x85\xb4\
\xc6\x1c\xf4\xfbs-\xd2n\xc69W\x07\xdd\x97\xf6\xe4\
\x1b\xd1\xc6\x7f$\xb0n6\xcb\xd2%\xee\xc5Uu\x9e\
\xef6m\xfbg\xd3\x5c\x1b[\x02\x8b\xd7mGYT\
\x0e_W\xf2\xb4\xec\xba\xc3\xbe?\xea\xa2J\x90K\xae\
\xd9\xf6\xee\x16; \xd4{!\x00N\x80\xdbS\x08\x10\
}j\xa8\xa0l\x00\x82\x88\xdf\x15\x08L!\x9dA\x9d\
\x80 8\xb1\xc2\x22\x1b\x87@\xb8/&p\xeb\xad\x8f\
\x9f\x82@\x89\xa0\x82\x0b>\x04\x82\xbe+\x10\x84&\x9a\
\x9a3\x8f`\x10\x1a\xab\xe5\xa09\xc8\xfb\x02A\xa2K\
fp\x02\x02\x08\xc2\xa4\xa20\xec\x13\xee\x0b\x05.\x09\
H\x90'(HB\xadB\x8a\x98A\xa7\xc0\xee\xcb5\
bLV\xe6\xcc+\x10\x83D\x10\x1a\x86P\xb0\xf7\x15\
$\x11\x04\xabN\xe3\x03\x00\x11\xc2\x02\x1b\xa4\x02\xdc\x1b\
\x138\xb3\xa7\xf6\xc0\x01\xa9`\xc4\x91\xcb<\x06!\xa2\
\xf7\xe5\x16\x18\xc1\xbc\xf4\x0c\x06d\x08f\xbd\xc3T\xb8\
3\x8b\xc0\x04\xd1\x08v\x1a&}a\x0bL\xb3a\x14\
\xfe'y\xa3\xdf\xf1\xc1\x19v\x15v]\xe1\xb4]\xdd\
DXk\xbf\xa4\xdd\xb2\xc1\xfd\xd3\x0b\xa7\x15L\x1e\x1a\
\xbf/T\x03E\xa84ZZ9B[\xc2\xac[I\
\x16h\xc2\x14\xa5J\xca\x11\x96\xfd\xda\x9a\xf7\xa0\xf3~\
8\xfe>\x18}\xa3\xc4\xba\xbbK\xc4\xb6/O\xdbY\
\xda4\xe9[R\xd5\x95\xfb\xb7a\x93\xa7\xb01_\x1f\
\x1a\x0c\xba\x08\x1bhb\xb1\xb8\x0c8\xa1\x0c\xfd.\x1f\
E\x98\x98\x09j\xaf\x0a\x9b_\x8fY\xae\x99\xbe%:\
\xe9S\x5c\xc0\xfb!\x8a;\x1d\xf5\xf1\x89\x09\x90\x01P\
\xacX\xb4\x11b\x14q\x82\x19\x1c\x5c\x19\x18+\x94\x05\
\xa5\xd5-\x01c\xcf\xed\x8c#G\xa4\xf4\xc0`\x0e\x87\
\x95|\x00}%\xc7\x8d\x85\x11\x10k\xb5\xbd:.\xfe\
\xc2\x00\xf8\x0d\xe1\xa2\xe0\x82!I\xad\xad\xf6\x86\xc4\x0d\
\xd1J\xc8 B|\x941\xdc\x8e\x14a\x8c\x9ak\x1b\
\x12\xb2\xd2\xb2\x9b\xe2\x8b\xe2g\xb8\xa0\x13\x06i,\x1b\
\xad\xcb?t\xccA\x84\xb9\x9dF\xa3\xe30\x8a\x80(\
\xad\xafN\x18.\x05\x03sK\xc0\x9c\x19\x12\xc6x-\
\xac\x06\x1f\xb0\xb0\xf8\xe3T\xeb\xc0\xdfN3*\x90C\
@8F\xb3k\xe3\x02\x80a\xf0\x96\xe2\xb8>\xb3#\
\xc1\x884\xe8_F\xfd\xbd\x11\xd5\x5c\x04\x91%^S\
2\xefw\xb9T\xd7\xf6\xbb\xdaR\x81\xab\xdd\x12]\xf4\
Y\xa0\x16\xfe\xf5\xf9\x0b\x82\xb5\x7f\x91T\x8b\x00c\x94\
\x95\xbc\xb7\x22\xf4\x06T]\xdd\xc1p\xaa4h{K\
\xc0\x9cGjt\xb2\x80Et\xefx)\x014|\xb4\
#\x00\xa0F\xa3\xdf\x15\xe6\xea\xb0h\xc1\xb1&\xa3\xb7\
dGG\xb9\xed\xda\xefb\xb5\x80\x01\x9a\xf5\x89\x9d\xbf\
{4:0\xc42\xa9\xf4\x88\x11\xd0\x92_\x1b\x15L\
\xb5%\xa3\xfc\xa6\xbcKt\x16\x8f\xb0\x944\x18\x8f\x94\
\x8fGX]\x0b\xcdT\x10!\xd5Aa|\x1aE\x98\
\x02#T\xd7\x86\x86S,\xd0,\xbb1h\x8en\xd8\
\xd7\xe0X\x22A\xaf\x835:\x19\xcc\xe8\xd0\xfbz/\
\xac\x14\x02\x86\xe9\x0c\x03q\xf3\xe0\xbc\xf7\xd6\xc9bV\
\x7f\x94\xab\xf6E6\xc5\x9aQJ*\x87\x8b\xec\xab]\
\xc9S\x9a\x8b4\xfd\xaf\xef\x9d,\xa1 /\xdcFc\
\xc5\xa3\x94\x1d\x86A\xfd?`\xb8B\x0d\xc4/\x84\x1c\
j,e\xc2')\xda\xc7\xe5 \x0b(\xa6pT\x03\
\xfa\x10\x8a\xe9\x0az\x15\xe1o\x1f\x00\x98w*\x12\xb0\
\xae>\xed\xf8\xc7\x86t\x091\xffO#\x06\x0dV\x8a\
\xeb@7\x8e\xa7\xeb?\x84\xe3\x8f\xb1\xff{\xfd\xe3\xc3\
__|\xbf\xa1\
\x00\x00\x0a\x03\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   in\
kscape:version=\x22\
1.1 (c68e22c387,\
 2021-05-23)\x22\x0a  \
 sodipodi:docnam\
e=\x22fusion.svg\x22\x0a \
  id=\x22svg6\x22\x0a   v\
ersion=\x221.1\x22\x0a   \
viewBox=\x220 0 48 \
48\x22\x0a   height=\x224\
8\x22\x0a   width=\x2248\x22\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0a   xmlns:sodipo\
di=\x22http://sodip\
odi.sourceforge.\
net/DTD/sodipodi\
-0.dtd\x22\x0a   xmlns\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:svg=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0a   xmlns:cc=\x22\
http://creativec\
ommons.org/ns#\x22\x0a\
   xmlns:dc=\x22htt\
p://purl.org/dc/\
elements/1.1/\x22>\x0a\
  <metadata\x0a    \
 id=\x22metadata12\x22\
>\x0a    <rdf:RDF>\x0a\
      <cc:Work\x0a \
        rdf:abou\
t=\x22\x22>\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0a        <dc:t\
ype\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0a      </\
cc:Work>\x0a    </r\
df:RDF>\x0a  </meta\
data>\x0a  <defs\x0a  \
   id=\x22defs10\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     ink\
scape:document-r\
otation=\x220\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg6\x22\x0a \
    inkscape:win\
dow-maximized=\x221\
\x22\x0a     inkscape:\
window-y=\x22-8\x22\x0a  \
   inkscape:wind\
ow-x=\x2254\x22\x0a     i\
nkscape:cy=\x22-91.\
728813\x22\x0a     ink\
scape:cx=\x22-31.52\
5423\x22\x0a     inksc\
ape:zoom=\x222.4583\
334\x22\x0a     showgr\
id=\x22false\x22\x0a     \
id=\x22namedview8\x22\x0a\
     inkscape:wi\
ndow-height=\x22105\
7\x22\x0a     inkscape\
:window-width=\x221\
858\x22\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0a     inkscape:\
pageopacity=\x220\x22\x0a\
     guidetolera\
nce=\x2210\x22\x0a     gr\
idtolerance=\x2210\x22\
\x0a     objecttole\
rance=\x2210\x22\x0a     \
borderopacity=\x221\
\x22\x0a     bordercol\
or=\x22#666666\x22\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     inksc\
ape:pagecheckerb\
oard=\x220\x22 />\x0a  <p\
ath\x0a     fill=\x22n\
one\x22\x0a     id=\x22pa\
th2\x22\x0a     d=\x22M0 \
0h48v48h-48z\x22 />\
\x0a  <g\x0a     id=\x22g\
21885\x22\x0a     tran\
sform=\x22matrix(1.\
5947499,0,0,1.59\
47499,198.17822,\
40.617172)\x22>\x0a   \
 <ellipse\x0a      \
 style=\x22fill:#ae\
aeae;fill-opacit\
y:1;stroke:#ffff\
ff;stroke-width:\
0.377953;stroke-\
linecap:round;st\
roke-linejoin:ro\
und\x22\x0a       id=\x22\
path848\x22\x0a       \
cx=\x22-116.94915\x22\x0a\
       cy=\x22-11.1\
8644\x22\x0a       rx=\
\x226.1016951\x22\x0a    \
   ry=\x226.3050847\
\x22 />\x0a    <ellips\
e\x0a       style=\x22\
fill:#aeaeae;fil\
l-opacity:1;stro\
ke:#ffffff;strok\
e-width:0.377953\
;stroke-linecap:\
round;stroke-lin\
ejoin:round\x22\x0a   \
    id=\x22path848-\
6\x22\x0a       cx=\x22-1\
00.77966\x22\x0a      \
 cy=\x22-7.8305092\x22\
\x0a       rx=\x226.10\
16951\x22\x0a       ry\
=\x226.3050847\x22 />\x0a\
    <path\x0a      \
 style=\x22fill:#ae\
aeae;fill-opacit\
y:1;stroke:none;\
stroke-width:1px\
;stroke-linecap:\
butt;stroke-line\
join:miter;strok\
e-opacity:1\x22\x0a   \
    d=\x22m -113.89\
831,-16.423729 c\
 5.28813,3.75833\
9 6.58476,4.7817\
23 11.87289,2.59\
3221 l -3.3305,9\
.8135589 c -2.07\
314,-1.9708122 -\
5.14567,-2.79845\
53 -10.75425,-1.\
1949153 z\x22\x0a     \
  id=\x22path990\x22\x0a \
      sodipodi:n\
odetypes=\x22ccccc\x22\
 />\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x08\xe8\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22c\
opy.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x221863\x22\x0a     \
inkscape:window-\
height=\x221025\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0a     ink\
scape:cx=\x22-47.99\
9997\x22\x0a     inksc\
ape:cy=\x2296.00000\
3\x22\x0a     inkscape\
:window-x=\x2257\x22\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0a  <path\x0a    \
 style=\x22fill:#99\
9999;stroke-widt\
h:1.33333337\x22\x0a  \
   d=\x22m 59.62711\
6,180.31172 c -1\
.46666,-0.62009 \
-4.16666,-2.7414\
 -6,-4.71401 l -\
3.33333,-3.58656\
 V 109.47754 46.\
943938 l 4.35897\
,-4.358975 4.358\
98,-4.358974 h 5\
0.615384 50.6153\
9 l 4.35897,4.35\
8974 4.35897,4.3\
58975 v 62.61538\
2 62.61539 l -4.\
35758,4.35897 -4\
.3576,4.35897 -4\
8.97574,0.27327 \
c -26.936664,0.1\
5029 -50.175744,\
-0.23409 -51.642\
414,-0.8542 z m \
94.000004,-70.75\
24 V 53.559322 h\
 -44 -44.000004 \
v 55.999998 56 h\
 44.000004 44 z \
M 17.920536,74.2\
50594 l 0.37325,\
-59.308728 4.357\
67,-4.357939 4.3\
5768,-4.3579383 \
51.30899,-0.3786\
652 51.308994,-0\
.3786654 v 8.045\
3319 8.045332 h \
-48.000004 -48 v\
 56 55.999998 h \
-8.03992 -8.0399\
1 z\x22\x0a     id=\x22pa\
th817\x22\x0a     inks\
cape:connector-c\
urvature=\x220\x22 />\x0a\
</svg>\x0a\
\x00\x00\x07=\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg6\x22\x0a   so\
dipodi:docname=\x22\
run_cascade_step\
.svg\x22\x0a   inkscap\
e:version=\x220.92.\
2 (5c3e80d, 2017\
-08-06)\x22>\x0a  <met\
adata\x0a     id=\x22m\
etadata12\x22>\x0a    \
<rdf:RDF>\x0a      \
<cc:Work\x0a       \
  rdf:about=\x22\x22>\x0a\
        <dc:form\
at>image/svg+xml\
</dc:format>\x0a   \
     <dc:type\x0a  \
         rdf:res\
ource=\x22http://pu\
rl.org/dc/dcmity\
pe/StillImage\x22 /\
>\x0a        <dc:ti\
tle />\x0a      </c\
c:Work>\x0a    </rd\
f:RDF>\x0a  </metad\
ata>\x0a  <defs\x0a   \
  id=\x22defs10\x22 />\
\x0a  <sodipodi:nam\
edview\x0a     page\
color=\x22#ffffff\x22\x0a\
     bordercolor\
=\x22#666666\x22\x0a     \
borderopacity=\x221\
\x22\x0a     objecttol\
erance=\x2210\x22\x0a    \
 gridtolerance=\x22\
10\x22\x0a     guideto\
lerance=\x2210\x22\x0a   \
  inkscape:pageo\
pacity=\x220\x22\x0a     \
inkscape:pagesha\
dow=\x222\x22\x0a     ink\
scape:window-wid\
th=\x221863\x22\x0a     i\
nkscape:window-h\
eight=\x221025\x22\x0a   \
  id=\x22namedview8\
\x22\x0a     showgrid=\
\x22false\x22\x0a     ink\
scape:zoom=\x224.91\
66667\x22\x0a     inks\
cape:cx=\x22-48\x22\x0a  \
   inkscape:cy=\x22\
24\x22\x0a     inkscap\
e:window-x=\x2257\x22\x0a\
     inkscape:wi\
ndow-y=\x2227\x22\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0a \
    inkscape:cur\
rent-layer=\x22svg6\
\x22 />\x0a  <path\x0a   \
  d=\x22M0 0h48v48h\
-48z\x22\x0a     id=\x22p\
ath2\x22\x0a     fill=\
\x22none\x22 />\x0a  <pat\
h\x0a     style=\x22fi\
ll:#999999;fill-\
rule:evenodd;str\
oke:#999999;stro\
ke-width:2;strok\
e-linecap:butt;s\
troke-linejoin:r\
ound;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
\x0a     d=\x22m 14.33\
9033,12.813563 -\
0.20339,22.37288\
2 19.728814,-11.\
59322 z\x22\x0a     id\
=\x22path4489\x22\x0a    \
 inkscape:connec\
tor-curvature=\x220\
\x22 />\x0a</svg>\x0a\
\x00\x00\x06\xcf\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg4\x22\x0a   so\
dipodi:docname=\x22\
ic_content_paste\
_48px.svg\x22\x0a   in\
kscape:version=\x22\
0.92.3 (2405546,\
 2018-03-11)\x22>\x0a \
 <metadata\x0a     \
id=\x22metadata10\x22>\
\x0a    <rdf:RDF>\x0a \
     <cc:Work\x0a  \
       rdf:about\
=\x22\x22>\x0a        <dc\
:format>image/sv\
g+xml</dc:format\
>\x0a        <dc:ty\
pe\x0a           rd\
f:resource=\x22http\
://purl.org/dc/d\
cmitype/StillIma\
ge\x22 />\x0a      </c\
c:Work>\x0a    </rd\
f:RDF>\x0a  </metad\
ata>\x0a  <defs\x0a   \
  id=\x22defs8\x22 />\x0a\
  <sodipodi:name\
dview\x0a     pagec\
olor=\x22#ffffff\x22\x0a \
    bordercolor=\
\x22#666666\x22\x0a     b\
orderopacity=\x221\x22\
\x0a     objecttole\
rance=\x2210\x22\x0a     \
gridtolerance=\x221\
0\x22\x0a     guidetol\
erance=\x2210\x22\x0a    \
 inkscape:pageop\
acity=\x220\x22\x0a     i\
nkscape:pageshad\
ow=\x222\x22\x0a     inks\
cape:window-widt\
h=\x221851\x22\x0a     in\
kscape:window-he\
ight=\x221025\x22\x0a    \
 id=\x22namedview6\x22\
\x0a     showgrid=\x22\
false\x22\x0a     inks\
cape:zoom=\x224.916\
6667\x22\x0a     inksc\
ape:cx=\x2224\x22\x0a    \
 inkscape:cy=\x2224\
\x22\x0a     inkscape:\
window-x=\x2269\x22\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg4\x22 \
/>\x0a  <path\x0a     \
d=\x22M38 4h-8.37c-\
.82-2.32-3.02-4-\
5.63-4s-4.81 1.6\
8-5.63 4H10C7.79\
 4 6 5.79 6 8v32\
c0 2.21 1.79 4 4\
 4h28c2.21 0 4-1\
.79 4-4V8c0-2.21\
-1.79-4-4-4zM24 \
4c1.1 0 2 .89 2 \
2s-.9 2-2 2-2-.8\
9-2-2 .9-2 2-2zm\
14 36H10V8h4v6h2\
0V8h4v32z\x22\x0a     \
id=\x22path2\x22\x0a     \
style=\x22fill:#999\
999;fill-opacity\
:1\x22 />\x0a</svg>\x0a\
\x00\x00\x07\xa3\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22s\
quares.svg\x22\x0a   i\
nkscape:version=\
\x220.92.2 (5c3e80d\
, 2017-08-06)\x22>\x0a\
  <metadata\x0a    \
 id=\x22metadata8\x22>\
\x0a    <rdf:RDF>\x0a \
     <cc:Work\x0a  \
       rdf:about\
=\x22\x22>\x0a        <dc\
:format>image/sv\
g+xml</dc:format\
>\x0a        <dc:ty\
pe\x0a           rd\
f:resource=\x22http\
://purl.org/dc/d\
cmitype/StillIma\
ge\x22 />\x0a        <\
dc:title />\x0a    \
  </cc:Work>\x0a   \
 </rdf:RDF>\x0a  </\
metadata>\x0a  <def\
s\x0a     id=\x22defs6\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#666666\x22\x0a \
    borderopacit\
y=\x221\x22\x0a     objec\
ttolerance=\x2210\x22\x0a\
     gridtoleran\
ce=\x2210\x22\x0a     gui\
detolerance=\x2210\x22\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0a    \
 inkscape:window\
-width=\x221863\x22\x0a  \
   inkscape:wind\
ow-height=\x221025\x22\
\x0a     id=\x22namedv\
iew4\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
1.2291667\x22\x0a     \
inkscape:cx=\x22-47\
.999997\x22\x0a     in\
kscape:cy=\x2296.00\
0003\x22\x0a     inksc\
ape:window-x=\x2257\
\x22\x0a     inkscape:\
window-y=\x2227\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g2\x22 />\x0a  <path\x0a \
    style=\x22fill:\
#999999;stroke-w\
idth:1.33333337\x22\
\x0a     d=\x22M 26.44\
0678,96 V 24 h 7\
2.000004 71.9999\
98 v 72 72 H 98.\
440682 26.440678\
 Z m 64.000004,3\
2 v -24 h -24.00\
0004 -24 v 24 24\
 h 24 24.000004 \
z m 63.999998,0 \
v -24 h -24 -24 \
v 24 24 h 24 24 \
z M 90.440682,64\
 V 40 h -24.0000\
04 -24 v 24 24 h\
 24 24.000004 z \
m 63.999998,0 V \
40 h -24 -24 v 2\
4 24 h 24 24 z\x22\x0a\
     id=\x22path817\
\x22\x0a     inkscape:\
connector-curvat\
ure=\x220\x22 />\x0a</svg\
>\x0a\
\x00\x00\x0b\x05\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22c\
opy2up.svg\x22\x0a   i\
nkscape:version=\
\x220.92.4 (unknown\
)\x22>\x0a  <metadata\x0a\
     id=\x22metadat\
a8\x22>\x0a    <rdf:RD\
F>\x0a      <cc:Wor\
k\x0a         rdf:a\
bout=\x22\x22>\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0a        <d\
c:type\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 />\x0a     \
   <dc:title />\x0a\
      </cc:Work>\
\x0a    </rdf:RDF>\x0a\
  </metadata>\x0a  \
<defs\x0a     id=\x22d\
efs6\x22 />\x0a  <sodi\
podi:namedview\x0a \
    pagecolor=\x22#\
ffffff\x22\x0a     bor\
dercolor=\x22#66666\
6\x22\x0a     borderop\
acity=\x221\x22\x0a     o\
bjecttolerance=\x22\
10\x22\x0a     gridtol\
erance=\x2210\x22\x0a    \
 guidetolerance=\
\x2210\x22\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0a     inkscape\
:pageshadow=\x222\x22\x0a\
     inkscape:wi\
ndow-width=\x221863\
\x22\x0a     inkscape:\
window-height=\x221\
025\x22\x0a     id=\x22na\
medview4\x22\x0a     s\
howgrid=\x22false\x22\x0a\
     inkscape:zo\
om=\x221.2291667\x22\x0a \
    inkscape:cx=\
\x22-400.27119\x22\x0a   \
  inkscape:cy=\x229\
6.000012\x22\x0a     i\
nkscape:window-x\
=\x2257\x22\x0a     inksc\
ape:window-y=\x2227\
\x22\x0a     inkscape:\
window-maximized\
=\x221\x22\x0a     inksca\
pe:current-layer\
=\x22g820\x22 />\x0a  <pa\
th\x0a     style=\x22f\
ill:#999999;stro\
ke-width:1.33333\
337\x22\x0a     d=\x22m 5\
3.118644,179.498\
16 c -1.46666,-0\
.62009 -4.16666,\
-2.7414 -6,-4.71\
401 l -3.33333,-\
3.58656 V 108.66\
398 46.130379 l \
4.35897,-4.35897\
5 4.35898,-4.358\
974 h 50.615376 \
50.61539 l 4.358\
97,4.358974 4.35\
897,4.358975 v 6\
2.615381 62.6153\
9 l -4.35758,4.3\
5897 -4.3576,4.3\
5897 -48.97574,0\
.27327 c -26.936\
656,0.15029 -50.\
175736,-0.23409 \
-51.642406,-0.85\
42 z m 93.999996\
,-70.7524 V 52.7\
45763 h -44 -43.\
999996 v 55.9999\
97 56 h 43.99999\
6 44 z M 11.4120\
64,73.437035 l 0\
.37325,-59.30872\
8 4.35767,-4.357\
9395 4.35768,-4.\
3579381 51.30899\
,-0.3786652 51.3\
08986,-0.3786654\
 v 8.0453322 8.0\
45332 h -47.9999\
96 -48 v 56 55.9\
99997 h -8.03992\
 -8.03991 z\x22\x0a   \
  id=\x22path817\x22\x0a \
    inkscape:con\
nector-curvature\
=\x220\x22 />\x0a  <g\x0a   \
  id=\x22g820\x22\x0a    \
 transform=\x22matr\
ix(-4,0,0,-4,-20\
2.16948,208.6779\
7)\x22>\x0a    <path\x0a \
      id=\x22path2\x22\
\x0a       d=\x22M 0,0\
 H 48 V 48 H 0 Z\
\x22\x0a       inkscap\
e:connector-curv\
ature=\x220\x22\x0a      \
 style=\x22fill:non\
e\x22 />\x0a    <path\x0a\
       inkscape:\
connector-curvat\
ure=\x220\x22\x0a       i\
d=\x22path4489\x22\x0a   \
    d=\x22m -82.714\
559,18.370089 13\
.037829,-0.11852\
5 -6.755966,11.4\
96992 z\x22\x0a       \
style=\x22fill:#37c\
8ab;fill-rule:ev\
enodd;stroke:#37\
c8ab;stroke-widt\
h:1.16550279;str\
oke-linecap:butt\
;stroke-linejoin\
:round;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1\x22 />\x0a  </g>\x0a</s\
vg>\x0a\
\x00\x00\x04Q\
\x00\
\x00*\x95x\xda\xedZ]o\xa38\x14}\xcf\xaf`\
\xe9K\xab\x1d\x8c\xcdW\x80\x85\x8c\xb4[\x8d4\xaf\xbb\
3\x9ag\x17;\x09S\xc0\x91q\x9af~\xfd^\x13\
>\x92&\xdd\xeev$\xb6R\xb1T)>\xf7\xda\xbe\
>\xf7\xda\x07P\x93\x8f\x8fea<pY\xe7\xa2J\
M\x82\xb0i\xf0*\x13,\xafV\xa9\xf9\xf5\xcb'+\
4\x8dZ\xd1\x8a\xd1BT<5+a~\x5c\xcc\x92\
_,\xcb\xf8Cr\xaa83v\xb9Z\x1b\x9f\xab\xfb\
:\xa3\x1bn\x5c\xaf\x95\xda\xc4\xb6\xbd\xdb\xedP\xde\x82\
H\xc8\x95}cX\xd6b6K\xea\x87\xd5\xcc0\x0c\
X\xb7\xaac\x96\xa5f;`\xb3\x95E\xe3\xc82\x9b\
\x17\xbc\xe4\x95\xaam\x82\x88m\x0e\xee\xd9\xe0\x9e\xe9\xd5\
\xf3\x07\x9e\x89\xb2\x14U\xdd\x8c\xac\xea\xab#g\xc9\x96\
\xbd\xb7\x8ef\xe76N$\x8a\x22\x1b;\xb6\xe3X\xe0\
a\xd5\xfbJ\xd1G\xebt(\xc4xi\xa8\x831\xb6\
\xc16x\xfe;\xaf\xb8\x06B7\xf0\xd7\xbbw\x00\xaa\
\xc5Vf|\x09\xe38\xaa\xb8\xb2o\xbf\xdc\xf6F\x0b\
#\xa6\xd8\xd14\x1d\x9f'\xab\x9e\x90\x5c\xd1\x92\xd7\x1b\
\x9a\xf1\xda\xee\xf0f\xfcQ\x86I\x03\xe4,5!F\
\xa7\xe9\xecr\xa6\xd6`\x8b\x0e\xdd5\xcfWk5\xf4\
\x1fr\xbe\xfb]<\xa6&6\xb0\x01\xa0\xd1\x19\xba@\
c&2\xbdrjR)\xe9\x1eu\x9b\xefB\x88\xfb\
\xe51\x8a\x1c\xe4\x1b\xd7\x0e\x0e0\xcf\xc82Z~0\
\x1c\xec`\x0b{\x16\x0eo\xcc\x05\x0cKJ\xae(\xa3\
\x8a\xea)\x0e\x91vH\xd88\x80\x0bd.\xfe\xf3\xf6\
\xd3\xa1\x07\xfd,\x8b\xbf\x09y\xdfv\xa1i\x07z'\
\xb6\xb0\x0ds\xd1\xc3\x09\xcbb\xe0\xba\xa4j\x91\x97t\
\xc5u\x9a~\x05n\x13{0\x9c8\xab\xfd\x86\x0f\x93\
\x1e\xa6\x95\xfc\x90\xb4\x8b\x95\xcb\xb22\xd7\x83\xec\xbfT\
^\x14\x9f\xf5\x22\xa6a?\x994W\x05\x1f\xc0\xc4n\
\xa3o\xf7f\x1fm.\xb1\xbb\xad7=\xc6\x97\xf5\xc0\
\x8a\xee\x05\xed\xecI\x9f\x0b\x9d\x08\xa6Svp\xdc@\
\x04\x99(\x84L\xcd\xabe\xd3\xcc\x83\xe1NH\xc6e\
g\x0a\x9avb\x12PG\xb0\x17\xa8\x83\x16\x16w\xdf\
y\xa6\x94(\xb8\xa4\x95\xde?\xc1\xade%\xa1\x82.\
\xe1\xdb\x9c\xf1K\x86\xbe2tx\xfdB\x17\xad\xf5\x9a\
2\xb1KM\xe7\xa9q\x97W`\xb0\xba\xe2\x0d\xbd\xf0\
\x19\x8f\xbe\x9e1\xe9]\x80\xbe\x9e(\xaf\x05\xeb\xb5\xd8\
\xe9\x9d\xa4\xe6\x92\x165\x7f:\xdb\x0f!J\x08\x03y\
~\xe8B{j\xce\xe0\x80X\xc4AQ\xe4\xf9.9\
\xb3\xc2\xf6\xa2\x009A\xe8z\xe4\x998a\x82\xf9s\
\xbb\x84\xe1\x8e\xff\x8c\xad\xa4\x8fy\x99\xff\xe0lH\xd5\
\xb0\xeeVJ\xb8I\xad\x82\xee\xb9l\x8f|[1\xab\
\x81\x8aU\xe4v\xdc+HU\xad\x8fBj6?\x0b\
\xb8\xe3\xaf\x09\x8a\x88\xef\xf8\xa4=\xa1\xfa\x00B%t\
E-\xf7\xcd\xbd\x12\xe1\xa0#\xc504\x14\xa1 \xf2\
\x22\xe2\xf5\xe0c\x03\x12\x12\x06\xde\xe0\xd9e\xc7\xc1=\
\xd4\xa6\xf4\x08\xd1A\xea%C\xe2\xf4X\xad\xf6\x05\xd4\
T[=1\xf9m\x09'.\xbe\x8a\x9a\xd6t\xac\xc1\
V+)\xeey\x5c\x81\x88\xb5\xbf\x0f\x85\x13\xbbh>\
\x8f|g\x1e\x04\x1d^\xe4\x15\x07\xeeb)\xb6\x15;\
\x06\xbf\x8b\xbc:E\xe1\xacsY\x00\xf9*\xf6:\x8c\
Q\xa8X}\x0d\x9e,6D\xb2\xa19\xe4\xa39a\
qI\xe5=\x5c\x8d\xc6\xc1\xc9\xd01\xf7\xb7\xc5\xab)\
\xf6\x1d\xe4h\x8e\xc3WSl\xb9\x13\xc9/\x90\x1c\xfa\
\xc8\xc5>\x0e\xbd\x9f \xd9\x0a&\x9a_\xba.H\x88\
\xdc(\xec\xef\xd3W\xd1<\x9fh~\x89f\x9f \xc0\
|\xf7gh\xf6\xdf\x07\xcd\x89\xbd:\x96\xcf\x7f\xd6\xcb\
\x0f\xae\x8b\x5c\xdf\x8f\x5c\xf7\xc6<\x95[+\xfa\xff\xa5\
\xd4\x9a\xc4t\x0c1\x9dh\x1eIN\xadp\x22z\x14\
A\x85\xcbk\x22z\x0cI}/\xcf.\xffMT\x83\
\x00\xcd\x1b\xe9;\x13U\xf7\x0d\x88\xea\xf4T?\x8a\xa8\
\x92\x89\xe6qDuzz\x19KT\xa7\xcf.#\xa9\
*\x99T\xf5\x5cU\x09\xc6\x08\x07\xf3\xf0\xfcM\xd5{\
\x03\xaa:}\xc4\x19EU\xa77\xa8\x91T\xd5\x9b\x88\
\x1eGU\xfd\x89\xe8qD\x15O\xa2zAT]\x17\
y\x8e;?\xff\xfe\xeb\x06o@U\xa7\x97\xa8QT\
\x15O4\x8f\xa3\xaa\xd3\xb7\x97\x91TuzU\x1dI\
U\x9dw\xa4\xaa\x89\xfe\x7f\xbc\xc5\xeco-U\xb1\xe3\
\
\x00\x00\x0b\x1c\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22c\
opy2left.svg\x22\x0a  \
 inkscape:versio\
n=\x220.92.3 (24055\
46, 2018-03-11)\x22\
>\x0a  <metadata\x0a  \
   id=\x22metadata8\
\x22>\x0a    <rdf:RDF>\
\x0a      <cc:Work\x0a\
         rdf:abo\
ut=\x22\x22>\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0a        <dc:\
type\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0a       \
 <dc:title></dc:\
title>\x0a      </c\
c:Work>\x0a    </rd\
f:RDF>\x0a  </metad\
ata>\x0a  <defs\x0a   \
  id=\x22defs6\x22 />\x0a\
  <sodipodi:name\
dview\x0a     pagec\
olor=\x22#ffffff\x22\x0a \
    bordercolor=\
\x22#666666\x22\x0a     b\
orderopacity=\x221\x22\
\x0a     objecttole\
rance=\x2210\x22\x0a     \
gridtolerance=\x221\
0\x22\x0a     guidetol\
erance=\x2210\x22\x0a    \
 inkscape:pageop\
acity=\x220\x22\x0a     i\
nkscape:pageshad\
ow=\x222\x22\x0a     inks\
cape:window-widt\
h=\x221851\x22\x0a     in\
kscape:window-he\
ight=\x221025\x22\x0a    \
 id=\x22namedview4\x22\
\x0a     showgrid=\x22\
false\x22\x0a     inks\
cape:zoom=\x221.229\
1667\x22\x0a     inksc\
ape:cx=\x22-123.452\
97\x22\x0a     inkscap\
e:cy=\x2296.000006\x22\
\x0a     inkscape:w\
indow-x=\x2269\x22\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0a    \
 inkscape:curren\
t-layer=\x22g820\x22 /\
>\x0a  <path\x0a     s\
tyle=\x22fill:#9999\
99;stroke-width:\
1.33333337\x22\x0a    \
 d=\x22m 53.118644,\
179.49816 c -1.4\
6666,-0.62009 -4\
.16666,-2.7414 -\
6,-4.71401 l -3.\
33333,-3.58656 V\
 108.66398 46.13\
0379 l 4.35897,-\
4.358975 4.35898\
,-4.358974 h 50.\
615376 50.61539 \
l 4.35897,4.3589\
74 4.35897,4.358\
975 v 62.615381 \
62.61539 l -4.35\
758,4.35897 -4.3\
576,4.35897 -48.\
97574,0.27327 c \
-26.936656,0.150\
29 -50.175736,-0\
.23409 -51.64240\
6,-0.8542 z m 93\
.999996,-70.7524\
 V 52.745763 h -\
44 -43.999996 v \
55.999997 56 h 4\
3.999996 44 z M \
11.412064,73.437\
035 l 0.37325,-5\
9.308728 4.35767\
,-4.3579395 4.35\
768,-4.3579381 5\
1.30899,-0.37866\
52 51.308986,-0.\
3786654 v 8.0453\
322 8.045332 h -\
47.999996 -48 v \
56 55.999997 h -\
8.03992 -8.03991\
 z\x22\x0a     id=\x22pat\
h817\x22\x0a     inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0a \
 <g\x0a     id=\x22g82\
0\x22\x0a     transfor\
m=\x22matrix(-4,0,0\
,-4,-202.16948,2\
08.67797)\x22>\x0a    \
<path\x0a       id=\
\x22path2\x22\x0a       d\
=\x22M 0,0 H 48 V 4\
8 H 0 Z\x22\x0a       \
inkscape:connect\
or-curvature=\x220\x22\
\x0a       style=\x22f\
ill:none\x22 />\x0a   \
 <path\x0a       in\
kscape:connector\
-curvature=\x220\x22\x0a \
      id=\x22path44\
89\x22\x0a       d=\x22m \
-80.825616,17.48\
1088 -0.118525,1\
3.037828 11.4969\
93,-6.755965 z\x22\x0a\
       style=\x22fi\
ll:#37c8ab;fill-\
rule:evenodd;str\
oke:#37c8ab;stro\
ke-width:1.16550\
279;stroke-linec\
ap:butt;stroke-l\
inejoin:round;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none;stroke-o\
pacity:1\x22 />\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x07\xdd\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22s\
avec.svg\x22\x0a   ink\
scape:version=\x220\
.92.4 (unknown)\x22\
>\x0a  <metadata\x0a  \
   id=\x22metadata8\
\x22>\x0a    <rdf:RDF>\
\x0a      <cc:Work\x0a\
         rdf:abo\
ut=\x22\x22>\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0a        <dc:\
type\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0a       \
 <dc:title />\x0a  \
    </cc:Work>\x0a \
   </rdf:RDF>\x0a  \
</metadata>\x0a  <d\
efs\x0a     id=\x22def\
s6\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0a     id=\x22name\
dview4\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x221.1020922\x22\x0a   \
  inkscape:cx=\x22-\
112.84034\x22\x0a     \
inkscape:cy=\x22120\
.23219\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
svg2\x22 />\x0a  <path\
\x0a     style=\x22fil\
l:#5555ff;stroke\
-width:4;stroke:\
none;stroke-opac\
ity:1;stroke-mit\
erlimit:4;stroke\
-dasharray:none\x22\
\x0a     d=\x22m 37.55\
9322,153.62712 v\
 -8 h 56 55.9999\
98 v 8 8 h -55.9\
99998 -56 z m 28\
,-52.66667 -27.3\
0894,-27.333331 \
h 15.654471 15.6\
54469 v -24 -24 \
h 24 23.999998 v\
 24 24 h 15.6544\
7 15.65446 l -27\
.30893,27.333331\
 c -15.01992,15.\
03334 -27.619918\
,27.33334 -27.99\
9998,27.33334 -0\
.38008,0 -12.980\
08,-12.3 -28,-27\
.33334 z\x22\x0a     i\
d=\x22path817\x22\x0a    \
 inkscape:connec\
tor-curvature=\x220\
\x22 />\x0a</svg>\x0a\
\x00\x00\x07\x95\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22m\
inus (gray).svg\x22\
\x0a   inkscape:ver\
sion=\x220.92.4 (un\
known)\x22>\x0a  <meta\
data\x0a     id=\x22me\
tadata8\x22>\x0a    <r\
df:RDF>\x0a      <c\
c:Work\x0a         \
rdf:about=\x22\x22>\x0a  \
      <dc:format\
>image/svg+xml</\
dc:format>\x0a     \
   <dc:type\x0a    \
       rdf:resou\
rce=\x22http://purl\
.org/dc/dcmitype\
/StillImage\x22 />\x0a\
        <dc:titl\
e />\x0a      </cc:\
Work>\x0a    </rdf:\
RDF>\x0a  </metadat\
a>\x0a  <defs\x0a     \
id=\x22defs6\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     pagecol\
or=\x22#ffffff\x22\x0a   \
  bordercolor=\x22#\
666666\x22\x0a     bor\
deropacity=\x221\x22\x0a \
    objecttolera\
nce=\x2210\x22\x0a     gr\
idtolerance=\x2210\x22\
\x0a     guidetoler\
ance=\x2210\x22\x0a     i\
nkscape:pageopac\
ity=\x220\x22\x0a     ink\
scape:pageshadow\
=\x222\x22\x0a     inksca\
pe:window-width=\
\x221863\x22\x0a     inks\
cape:window-heig\
ht=\x221025\x22\x0a     i\
d=\x22namedview4\x22\x0a \
    showgrid=\x22fa\
lse\x22\x0a     inksca\
pe:zoom=\x221.73830\
42\x22\x0a     inkscap\
e:cx=\x22-319.39807\
\x22\x0a     inkscape:\
cy=\x22209.44504\x22\x0a \
    inkscape:win\
dow-x=\x2257\x22\x0a     \
inkscape:window-\
y=\x2227\x22\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0a     i\
nkscape:current-\
layer=\x22g831\x22 />\x0a\
  <g\x0a     id=\x22g8\
31\x22\x0a     style=\x22\
stroke:#b3b3b3;s\
troke-linecap:ro\
und\x22>\x0a    <path\x0a\
       sodipodi:\
nodetypes=\x22cc\x22\x0a \
      inkscape:c\
onnector-curvatu\
re=\x220\x22\x0a       id\
=\x22path812-3\x22\x0a   \
    d=\x22m 134.961\
47,95.594487 -79\
.795108,0.0945\x22\x0a\
       style=\x22fi\
ll:#37c8ab;fill-\
rule:evenodd;str\
oke:#aeaeae;stro\
ke-width:16;stro\
ke-linecap:round\
;stroke-linejoin\
:miter;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1\x22 />\x0a  </g>\x0a</s\
vg>\x0a\
\x00\x00\x07\x7f\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22l\
oad.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x22784\x22\x0a     i\
nkscape:window-h\
eight=\x22480\x22\x0a    \
 id=\x22namedview4\x22\
\x0a     showgrid=\x22\
false\x22\x0a     inks\
cape:zoom=\x221.229\
1667\x22\x0a     inksc\
ape:cx=\x22-47.9999\
97\x22\x0a     inkscap\
e:cy=\x2296.000003\x22\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0a     in\
kscape:window-ma\
ximized=\x220\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <path\x0a     s\
tyle=\x22fill:#9999\
99;stroke-width:\
1.33333337\x22\x0a    \
 d=\x22m 37.559322,\
154.44068 v -8 h\
 56.000004 56.00\
0004 v 8 8 H 93.\
559326 37.559322\
 Z m 32,-48 V 82\
.440678 H 53.896\
671 38.234021 l \
27.66265,-27.662\
651 27.662655,-2\
7.66265 27.66265\
4,27.66265 27.66\
266,27.662651 h \
-15.66266 -15.66\
265 v 24.000002 \
24 H 93.559326 6\
9.559322 Z\x22\x0a    \
 id=\x22path817\x22\x0a  \
   inkscape:conn\
ector-curvature=\
\x220\x22 />\x0a</svg>\x0a\
\x00\x00\x06=\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg4\x22\x0a   so\
dipodi:docname=\x22\
ic_view_headline\
_48px.svg\x22\x0a   in\
kscape:version=\x22\
0.92.3 (2405546,\
 2018-03-11)\x22>\x0a \
 <metadata\x0a     \
id=\x22metadata10\x22>\
\x0a    <rdf:RDF>\x0a \
     <cc:Work\x0a  \
       rdf:about\
=\x22\x22>\x0a        <dc\
:format>image/sv\
g+xml</dc:format\
>\x0a        <dc:ty\
pe\x0a           rd\
f:resource=\x22http\
://purl.org/dc/d\
cmitype/StillIma\
ge\x22 />\x0a      </c\
c:Work>\x0a    </rd\
f:RDF>\x0a  </metad\
ata>\x0a  <defs\x0a   \
  id=\x22defs8\x22 />\x0a\
  <sodipodi:name\
dview\x0a     pagec\
olor=\x22#ffffff\x22\x0a \
    bordercolor=\
\x22#666666\x22\x0a     b\
orderopacity=\x221\x22\
\x0a     objecttole\
rance=\x2210\x22\x0a     \
gridtolerance=\x221\
0\x22\x0a     guidetol\
erance=\x2210\x22\x0a    \
 inkscape:pageop\
acity=\x220\x22\x0a     i\
nkscape:pageshad\
ow=\x222\x22\x0a     inks\
cape:window-widt\
h=\x22826\x22\x0a     ink\
scape:window-hei\
ght=\x22480\x22\x0a     i\
d=\x22namedview6\x22\x0a \
    showgrid=\x22fa\
lse\x22\x0a     inksca\
pe:zoom=\x224.91666\
67\x22\x0a     inkscap\
e:cx=\x222.6440678\x22\
\x0a     inkscape:c\
y=\x2224\x22\x0a     inks\
cape:window-x=\x226\
9\x22\x0a     inkscape\
:window-y=\x2227\x22\x0a \
    inkscape:win\
dow-maximized=\x220\
\x22\x0a     inkscape:\
current-layer=\x22s\
vg4\x22 />\x0a  <path\x0a\
     d=\x22M8 30h34\
v-4H8v4zm0 8h34v\
-4H8v4zm0-16h34v\
-4H8v4zm0-12v4h3\
4v-4H8z\x22\x0a     id\
=\x22path2\x22\x0a     st\
yle=\x22fill:#99999\
9;fill-opacity:1\
\x22 />\x0a</svg>\x0a\
\x00\x00\x07\x8e\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22m\
inus.svg\x22\x0a   ink\
scape:version=\x220\
.92.4 (unknown)\x22\
>\x0a  <metadata\x0a  \
   id=\x22metadata8\
\x22>\x0a    <rdf:RDF>\
\x0a      <cc:Work\x0a\
         rdf:abo\
ut=\x22\x22>\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0a        <dc:\
type\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0a       \
 <dc:title />\x0a  \
    </cc:Work>\x0a \
   </rdf:RDF>\x0a  \
</metadata>\x0a  <d\
efs\x0a     id=\x22def\
s6\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0a     id=\x22name\
dview4\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x221.7383042\x22\x0a   \
  inkscape:cx=\x22-\
213.83542\x22\x0a     \
inkscape:cy=\x22209\
.44504\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
g831\x22 />\x0a  <g\x0a  \
   id=\x22g831\x22\x0a   \
  style=\x22stroke:\
#b3b3b3;stroke-l\
inecap:round\x22>\x0a \
   <path\x0a       \
sodipodi:nodetyp\
es=\x22cc\x22\x0a       i\
nkscape:connecto\
r-curvature=\x220\x22\x0a\
       id=\x22path8\
12-3\x22\x0a       d=\x22\
m 134.96147,95.5\
94487 -79.795108\
,0.0945\x22\x0a       \
style=\x22fill:#37c\
8ab;fill-rule:ev\
enodd;stroke:#37\
c8ab;stroke-widt\
h:16;stroke-line\
cap:round;stroke\
-linejoin:miter;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22 />\x0a \
 </g>\x0a</svg>\x0a\
\x00\x00\x06\xc2\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg4\x22\x0a   so\
dipodi:docname=\x22\
uncheck_all.svg\x22\
\x0a   inkscape:ver\
sion=\x220.92.3 (24\
05546, 2018-03-1\
1)\x22>\x0a  <metadata\
\x0a     id=\x22metada\
ta10\x22>\x0a    <rdf:\
RDF>\x0a      <cc:W\
ork\x0a         rdf\
:about=\x22\x22>\x0a     \
   <dc:format>im\
age/svg+xml</dc:\
format>\x0a        \
<dc:type\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0a   \
     <dc:title /\
>\x0a      </cc:Wor\
k>\x0a    </rdf:RDF\
>\x0a  </metadata>\x0a\
  <defs\x0a     id=\
\x22defs8\x22 />\x0a  <so\
dipodi:namedview\
\x0a     pagecolor=\
\x22#ffffff\x22\x0a     b\
ordercolor=\x22#666\
666\x22\x0a     border\
opacity=\x221\x22\x0a    \
 objecttolerance\
=\x2210\x22\x0a     gridt\
olerance=\x2210\x22\x0a  \
   guidetoleranc\
e=\x2210\x22\x0a     inks\
cape:pageopacity\
=\x220\x22\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0a     inkscape:\
window-width=\x2218\
51\x22\x0a     inkscap\
e:window-height=\
\x221025\x22\x0a     id=\x22\
namedview6\x22\x0a    \
 showgrid=\x22false\
\x22\x0a     inkscape:\
zoom=\x224.9166667\x22\
\x0a     inkscape:c\
x=\x22-82.372882\x22\x0a \
    inkscape:cy=\
\x2224\x22\x0a     inksca\
pe:window-x=\x2269\x22\
\x0a     inkscape:w\
indow-y=\x2227\x22\x0a   \
  inkscape:windo\
w-maximized=\x221\x22\x0a\
     inkscape:cu\
rrent-layer=\x22svg\
4\x22 />\x0a  <rect\x0a  \
   style=\x22opacit\
y:0.328;fill:non\
e;stroke:#000000\
;stroke-width:3;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22\x0a    \
 id=\x22rect818\x22\x0a  \
   width=\x2238.033\
897\x22\x0a     height\
=\x2239.254238\x22\x0a   \
  x=\x225.0847454\x22\x0a\
     y=\x224.677966\
1\x22\x0a     ry=\x225.89\
83049\x22 />\x0a</svg>\
\x0a\
\x00\x00\x07n\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg4\x22\x0a   so\
dipodi:docname=\x22\
ic_system_update\
_alt_48px.svg\x22\x0a \
  inkscape:versi\
on=\x220.92.3 (2405\
546, 2018-03-11)\
\x22>\x0a  <metadata\x0a \
    id=\x22metadata\
10\x22>\x0a    <rdf:RD\
F>\x0a      <cc:Wor\
k\x0a         rdf:a\
bout=\x22\x22>\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0a        <d\
c:type\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs8\x22\
 />\x0a  <sodipodi:\
namedview\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#666666\x22\x0a  \
   borderopacity\
=\x221\x22\x0a     object\
tolerance=\x2210\x22\x0a \
    gridtoleranc\
e=\x2210\x22\x0a     guid\
etolerance=\x2210\x22\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0a  \
   inkscape:page\
shadow=\x222\x22\x0a     \
inkscape:window-\
width=\x221851\x22\x0a   \
  inkscape:windo\
w-height=\x221025\x22\x0a\
     id=\x22namedvi\
ew6\x22\x0a     showgr\
id=\x22false\x22\x0a     \
inkscape:zoom=\x222\
.4583333\x22\x0a     i\
nkscape:cx=\x22-50.\
292978\x22\x0a     ink\
scape:cy=\x2274.807\
176\x22\x0a     inksca\
pe:window-x=\x2269\x22\
\x0a     inkscape:w\
indow-y=\x2227\x22\x0a   \
  inkscape:windo\
w-maximized=\x221\x22\x0a\
     inkscape:cu\
rrent-layer=\x22svg\
4\x22 />\x0a  <path\x0a  \
   style=\x22stroke\
:#37c8ab;stroke-\
opacity:1;fill:#\
37c8ab;fill-opac\
ity:1\x22\x0a     d=\x22m\
 24,32.5 8,-8 h \
-6 v -18 h -4 v \
18 h -6 z\x22\x0a     \
id=\x22path819\x22 />\x0a\
  <path\x0a     sty\
le=\x22stroke:#9999\
99;stroke-opacit\
y:1;fill:#999999\
;fill-opacity:1\x22\
\x0a     d=\x22M 42,6.\
5 H 30 v 3.97 H \
42 V 38.53 H 6 V\
 10.47 H 18 V 6.\
5 H 6 c -2.21,0 \
-4,1.79 -4,4 v 2\
8 c 0,2.21 1.79,\
4 4,4 h 36 c 2.2\
1,0 4,-1.79 4,-4\
 v -28 c 0,-2.21\
 -1.79,-4 -4,-4 \
z\x22\x0a     id=\x22path\
2\x22 />\x0a</svg>\x0a\
\x00\x00\x08\xe2\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   width=\x2248\
\x22\x0a   height=\x2248\x22\
\x0a   viewBox=\x220 0\
 48.000001 48.00\
0001\x22\x0a   id=\x22svg\
2\x22\x0a   version=\x221\
.1\x22\x0a   inkscape:\
version=\x220.92.2 \
(5c3e80d, 2017-0\
8-06)\x22\x0a   sodipo\
di:docname=\x22cons\
ole.svg\x22>\x0a  <def\
s\x0a     id=\x22defs4\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
id=\x22base\x22\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#666666\x22\x0a  \
   borderopacity\
=\x221.0\x22\x0a     inks\
cape:pageopacity\
=\x220.0\x22\x0a     inks\
cape:pageshadow=\
\x222\x22\x0a     inkscap\
e:zoom=\x227.919595\
9\x22\x0a     inkscape\
:cx=\x221.2311698\x22\x0a\
     inkscape:cy\
=\x2231.52398\x22\x0a    \
 inkscape:docume\
nt-units=\x22px\x22\x0a  \
   inkscape:curr\
ent-layer=\x22layer\
1\x22\x0a     showgrid\
=\x22false\x22\x0a     un\
its=\x22px\x22\x0a     in\
kscape:window-wi\
dth=\x221863\x22\x0a     \
inkscape:window-\
height=\x221025\x22\x0a  \
   inkscape:wind\
ow-x=\x2257\x22\x0a     i\
nkscape:window-y\
=\x2227\x22\x0a     inksc\
ape:window-maxim\
ized=\x221\x22 />\x0a  <m\
etadata\x0a     id=\
\x22metadata7\x22>\x0a   \
 <rdf:RDF>\x0a     \
 <cc:Work\x0a      \
   rdf:about=\x22\x22>\
\x0a        <dc:for\
mat>image/svg+xm\
l</dc:format>\x0a  \
      <dc:type\x0a \
          rdf:re\
source=\x22http://p\
url.org/dc/dcmit\
ype/StillImage\x22 \
/>\x0a        <dc:t\
itle />\x0a      </\
cc:Work>\x0a    </r\
df:RDF>\x0a  </meta\
data>\x0a  <g\x0a     \
inkscape:label=\x22\
Capa 1\x22\x0a     ink\
scape:groupmode=\
\x22layer\x22\x0a     id=\
\x22layer1\x22\x0a     tr\
ansform=\x22transla\
te(0,-1004.3622)\
\x22>\x0a    <rect\x0a   \
    style=\x22fill:\
none;fill-opacit\
y:0.84951453;str\
oke:#999999;stro\
ke-width:3.85741\
425;stroke-linej\
oin:round;stroke\
-miterlimit:4;st\
roke-dasharray:n\
one\x22\x0a       id=\x22\
rect4136\x22\x0a      \
 width=\x2244.14258\
6\x22\x0a       height\
=\x2244.142586\x22\x0a   \
    x=\x221.9287071\
\x22\x0a       y=\x221006\
.2909\x22\x0a       ry\
=\x2210.186751\x22 />\x0a\
    <path\x0a      \
 style=\x22fill:non\
e;fill-rule:even\
odd;stroke:#9999\
99;stroke-width:\
3;stroke-linecap\
:butt;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22\x0a       d\
=\x22M 8.0812208,10\
40.6192 H 22.223\
356\x22\x0a       id=\x22\
path817\x22\x0a       \
inkscape:connect\
or-curvature=\x220\x22\
\x0a       sodipodi\
:nodetypes=\x22cc\x22 \
/>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x08]\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22b\
ars.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x22784\x22\x0a     i\
nkscape:window-h\
eight=\x22480\x22\x0a    \
 id=\x22namedview4\x22\
\x0a     showgrid=\x22\
false\x22\x0a     inks\
cape:zoom=\x221.229\
1667\x22\x0a     inksc\
ape:cx=\x22-47.9999\
97\x22\x0a     inkscap\
e:cy=\x2296.000003\x22\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0a     in\
kscape:window-ma\
ximized=\x220\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <path\x0a     s\
tyle=\x22fill:#9999\
99;stroke-width:\
1.33333337\x22\x0a    \
 d=\x22m 34,167.561\
8 c -1.466667,-0\
.6178 -4.166667,\
-2.73724 -6,-4.7\
0985 l -3.333333\
,-3.58656 V 96.7\
31782 34.198175 \
L 29.025641,29.8\
392 33.384616,25\
.480226 H 96 158\
.61539 l 4.35897\
,4.358974 4.3589\
7,4.358975 v 62.\
615384 62.615391\
 l -4.35798,4.35\
897 -4.358,4.358\
97 -60.975342,0.\
2691 C 64.105569\
,168.56399 35.46\
6667,168.17961 3\
4,167.5618 Z M 7\
2,108.81356 V 80\
.813559 h -8 -8 \
v 28.000001 28 h\
 8 8 z m 32,-12.\
000001 v -40 h -\
8 -8 v 40 40.000\
001 h 8 8 z m 32\
,24.000001 v -16\
 h -8 -8 v 16 16\
 h 8 8 z\x22\x0a     i\
d=\x22path817\x22\x0a    \
 inkscape:connec\
tor-curvature=\x220\
\x22 />\x0a</svg>\x0a\
\x00\x00\x08r\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22n\
ew2c.svg\x22\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0a  \
<metadata\x0a     i\
d=\x22metadata8\x22>\x0a \
   <rdf:RDF>\x0a   \
   <cc:Work\x0a    \
     rdf:about=\x22\
\x22>\x0a        <dc:f\
ormat>image/svg+\
xml</dc:format>\x0a\
        <dc:type\
\x0a           rdf:\
resource=\x22http:/\
/purl.org/dc/dcm\
itype/StillImage\
\x22 />\x0a        <dc\
:title />\x0a      \
</cc:Work>\x0a    <\
/rdf:RDF>\x0a  </me\
tadata>\x0a  <defs\x0a\
     id=\x22defs6\x22 \
/>\x0a  <sodipodi:n\
amedview\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0a     bordercol\
or=\x22#666666\x22\x0a   \
  borderopacity=\
\x221\x22\x0a     objectt\
olerance=\x2210\x22\x0a  \
   gridtolerance\
=\x2210\x22\x0a     guide\
tolerance=\x2210\x22\x0a \
    inkscape:pag\
eopacity=\x220\x22\x0a   \
  inkscape:pages\
hadow=\x222\x22\x0a     i\
nkscape:window-w\
idth=\x221617\x22\x0a    \
 inkscape:window\
-height=\x22628\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0a     ink\
scape:cx=\x22-192\x22\x0a\
     inkscape:cy\
=\x2296.000006\x22\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0a     in\
kscape:window-y=\
\x2227\x22\x0a     inksca\
pe:window-maximi\
zed=\x220\x22\x0a     ink\
scape:current-la\
yer=\x22svg2\x22 />\x0a  \
<path\x0a     style\
=\x22fill:#6f7c91;s\
troke-width:1.33\
333337\x22\x0a     d=\x22\
m 42,172.31016 c\
 -1.466667,-0.61\
924 -4.166667,-2\
.73984 -6,-4.712\
45 l -3.333333,-\
3.58656 V 93.477\
545 22.943938 l \
4.35676,-4.35897\
5 4.356761,-4.35\
8974 34.976572,-\
0.378076 34.9765\
7,-0.378076 24.3\
7995,24.437904 2\
4.37995,24.43790\
5 -0.37995,50.91\
5854 -0.37995,50\
.91586 -4.35774,\
4.35764 -4.35775\
,4.35765 -52.975\
588,0.2717 C 68.\
50568,173.31379 \
43.466667,172.92\
94 42,172.31016 \
Z M 148,69.21083\
4 c 0,-0.191669 \
-9.9,-10.234849 \
-22,-22.318179 l\
 -22,-21.96969 v\
 22.318178 22.31\
8179 h 22 c 12.1\
,0 22,-0.15682 2\
2,-0.348488 z\x22\x0a \
    id=\x22path817\x22\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22 />\x0a</svg>\
\x0a\
\x00\x00\x08\x03\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg4\x22\x0a   so\
dipodi:docname=\x22\
check_all.svg\x22\x0a \
  inkscape:versi\
on=\x220.92.3 (2405\
546, 2018-03-11)\
\x22>\x0a  <metadata\x0a \
    id=\x22metadata\
10\x22>\x0a    <rdf:RD\
F>\x0a      <cc:Wor\
k\x0a         rdf:a\
bout=\x22\x22>\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0a        <d\
c:type\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs8\x22\
 />\x0a  <sodipodi:\
namedview\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#666666\x22\x0a  \
   borderopacity\
=\x221\x22\x0a     object\
tolerance=\x2210\x22\x0a \
    gridtoleranc\
e=\x2210\x22\x0a     guid\
etolerance=\x2210\x22\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0a  \
   inkscape:page\
shadow=\x222\x22\x0a     \
inkscape:window-\
width=\x221851\x22\x0a   \
  inkscape:windo\
w-height=\x221025\x22\x0a\
     id=\x22namedvi\
ew6\x22\x0a     showgr\
id=\x22false\x22\x0a     \
inkscape:zoom=\x224\
.9166667\x22\x0a     i\
nkscape:cx=\x22-78.\
057517\x22\x0a     ink\
scape:cy=\x2224\x22\x0a  \
   inkscape:wind\
ow-x=\x2269\x22\x0a     i\
nkscape:window-y\
=\x2227\x22\x0a     inksc\
ape:window-maxim\
ized=\x221\x22\x0a     in\
kscape:current-l\
ayer=\x22svg4\x22 />\x0a \
 <rect\x0a     styl\
e=\x22opacity:0.328\
;fill:none;strok\
e:#000000;stroke\
-width:3;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne;stroke-opacit\
y:1\x22\x0a     id=\x22re\
ct818\x22\x0a     widt\
h=\x2238.033897\x22\x0a  \
   height=\x2239.25\
4238\x22\x0a     x=\x225.\
0847454\x22\x0a     y=\
\x224.6779661\x22\x0a    \
 ry=\x225.8983049\x22 \
/>\x0a  <path\x0a     \
style=\x22fill:#00d\
4aa;fill-rule:ev\
enodd;stroke:#00\
d4aa;stroke-widt\
h:1.04499948px;s\
troke-linecap:bu\
tt;stroke-linejo\
in:miter;stroke-\
opacity:1\x22\x0a     \
d=\x22M 8.5033805,2\
1.366378 18.9179\
51,34.543999 46.\
335905,11.164348\
 42.297602,8.401\
2989 20.193204,2\
4.979595 12.7542\
25,20.091123 Z\x22\x0a\
     id=\x22path815\
\x22\x0a     inkscape:\
connector-curvat\
ure=\x220\x22 />\x0a</svg\
>\x0a\
\x00\x00\x07\x9c\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22s\
ave.svg\x22\x0a   inks\
cape:version=\x220.\
92.4 (unknown)\x22>\
\x0a  <metadata\x0a   \
  id=\x22metadata8\x22\
>\x0a    <rdf:RDF>\x0a\
      <cc:Work\x0a \
        rdf:abou\
t=\x22\x22>\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0a        <dc:t\
ype\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0a        \
<dc:title />\x0a   \
   </cc:Work>\x0a  \
  </rdf:RDF>\x0a  <\
/metadata>\x0a  <de\
fs\x0a     id=\x22defs\
6\x22 />\x0a  <sodipod\
i:namedview\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#666666\x22\x0a\
     borderopaci\
ty=\x221\x22\x0a     obje\
cttolerance=\x2210\x22\
\x0a     gridtolera\
nce=\x2210\x22\x0a     gu\
idetolerance=\x2210\
\x22\x0a     inkscape:\
pageopacity=\x220\x22\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0a   \
  inkscape:windo\
w-width=\x22902\x22\x0a  \
   inkscape:wind\
ow-height=\x22480\x22\x0a\
     id=\x22namedvi\
ew4\x22\x0a     showgr\
id=\x22false\x22\x0a     \
inkscape:zoom=\x221\
.2291667\x22\x0a     i\
nkscape:cx=\x22-47.\
999998\x22\x0a     ink\
scape:cy=\x2296.000\
006\x22\x0a     inksca\
pe:window-x=\x2257\x22\
\x0a     inkscape:w\
indow-y=\x2227\x22\x0a   \
  inkscape:windo\
w-maximized=\x220\x22\x0a\
     inkscape:cu\
rrent-layer=\x22svg\
2\x22 />\x0a  <path\x0a  \
   style=\x22fill:#\
999999;stroke-wi\
dth:1.33333337\x22\x0a\
     d=\x22m 37.559\
322,153.62712 v \
-8 h 56 55.99999\
8 v 8 8 h -55.99\
9998 -56 z m 28,\
-52.66667 -27.30\
894,-27.333331 h\
 15.654471 15.65\
4469 v -24 -24 h\
 24 23.999998 v \
24 24 h 15.65447\
 15.65446 l -27.\
30893,27.333331 \
c -15.01992,15.0\
3334 -27.619918,\
27.33334 -27.999\
998,27.33334 -0.\
38008,0 -12.9800\
8,-12.3 -28,-27.\
33334 z\x22\x0a     id\
=\x22path817\x22\x0a     \
inkscape:connect\
or-curvature=\x220\x22\
 />\x0a</svg>\x0a\
\x00\x00\x0c\x08\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:xlink=\x22htt\
p://www.w3.org/1\
999/xlink\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns:inksc\
ape=\x22http://www.\
inkscape.org/nam\
espaces/inkscape\
\x22\x0a   version=\x221.\
1\x22\x0a   id=\x22svg2\x22\x0a\
   width=\x22192\x22\x0a \
  height=\x22192\x22\x0a \
  viewBox=\x220 0 1\
92 192\x22\x0a   sodip\
odi:docname=\x22pic\
.svg\x22\x0a   inkscap\
e:version=\x220.92.\
3 (2405546, 2018\
-03-11)\x22>\x0a  <met\
adata\x0a     id=\x22m\
etadata8\x22>\x0a    <\
rdf:RDF>\x0a      <\
cc:Work\x0a        \
 rdf:about=\x22\x22>\x0a \
       <dc:forma\
t>image/svg+xml<\
/dc:format>\x0a    \
    <dc:type\x0a   \
        rdf:reso\
urce=\x22http://pur\
l.org/dc/dcmityp\
e/StillImage\x22 />\
\x0a        <dc:tit\
le />\x0a      </cc\
:Work>\x0a    </rdf\
:RDF>\x0a  </metada\
ta>\x0a  <defs\x0a    \
 id=\x22defs6\x22>\x0a   \
 <linearGradient\
\x0a       inkscape\
:collect=\x22always\
\x22\x0a       id=\x22lin\
earGradient816\x22>\
\x0a      <stop\x0a   \
      style=\x22sto\
p-color:#1db090;\
stop-opacity:1\x22\x0a\
         offset=\
\x220\x22\x0a         id=\
\x22stop812\x22 />\x0a   \
   <stop\x0a       \
  style=\x22stop-co\
lor:#509fd7;stop\
-opacity:0.788\x22\x0a\
         offset=\
\x221\x22\x0a         id=\
\x22stop814\x22 />\x0a   \
 </linearGradien\
t>\x0a    <linearGr\
adient\x0a       in\
kscape:collect=\x22\
always\x22\x0a       x\
link:href=\x22#line\
arGradient816\x22\x0a \
      id=\x22linear\
Gradient820\x22\x0a   \
    gradientUnit\
s=\x22userSpaceOnUs\
e\x22\x0a       x1=\x2297\
.887009\x22\x0a       \
y1=\x22158.79446\x22\x0a \
      x2=\x2298.180\
786\x22\x0a       y2=\x22\
39.201252\x22 />\x0a  \
</defs>\x0a  <sodip\
odi:namedview\x0a  \
   pagecolor=\x22#f\
fffff\x22\x0a     bord\
ercolor=\x22#666666\
\x22\x0a     borderopa\
city=\x221\x22\x0a     ob\
jecttolerance=\x221\
0\x22\x0a     gridtole\
rance=\x2210\x22\x0a     \
guidetolerance=\x22\
10\x22\x0a     inkscap\
e:pageopacity=\x220\
\x22\x0a     inkscape:\
pageshadow=\x222\x22\x0a \
    inkscape:win\
dow-width=\x221851\x22\
\x0a     inkscape:w\
indow-height=\x2210\
25\x22\x0a     id=\x22nam\
edview4\x22\x0a     sh\
owgrid=\x22false\x22\x0a \
    inkscape:zoo\
m=\x221.2291667\x22\x0a  \
   inkscape:cx=\x22\
-192\x22\x0a     inksc\
ape:cy=\x2296.00000\
6\x22\x0a     inkscape\
:window-x=\x2269\x22\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0a  <path\x0a    \
 style=\x22fill:url\
(#linearGradient\
820);stroke-widt\
h:1.33333337;fil\
l-opacity:1\x22\x0a   \
  d=\x22m 34,170.00\
247 c -1.466667,\
-0.6178 -4.16666\
7,-2.73724 -6,-4\
.70985 l -3.3333\
33,-3.58656 V 99\
.17246 36.638853\
 l 4.358974,-4.3\
58975 4.358975,-\
4.358974 H 96 15\
8.61539 l 4.3589\
7,4.358974 4.358\
97,4.358975 v 62\
.615384 62.61538\
3 l -4.35798,4.3\
5897 -4.358,4.35\
897 -60.975342,0\
.2691 C 64.10556\
9,171.00466 35.4\
66667,170.62028 \
34,170.00247 Z M\
 134.51609,123.9\
209 c -9.63117,-\
12.83333 -17.995\
45,-23.33333 -18\
.5873,-23.33333 \
-0.59184,0 -6.89\
532,7.5 -14.0077\
2,16.66667 -7.11\
2399,9.16666 -13\
.402486,16.66666\
 -13.977969,16.6\
6666 -0.575482,0\
 -5.049877,-4.8 \
-9.943101,-10.66\
667 -4.893224,-5\
.86666 -9.395195\
,-10.66666 -10.0\
04381,-10.66666 \
-0.609186,0 -5.1\
74263,5.25 -10.1\
44615,11.66666 -\
4.970352,6.41667\
 -11.092431,14.2\
1667 -13.60462,1\
7.33333 l -4.567\
616,5.66667 h 56\
.174268 56.17427\
4 z\x22\x0a     id=\x22pa\
th817\x22\x0a     inks\
cape:connector-c\
urvature=\x220\x22 />\x0a\
</svg>\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x08\
\x03\xc6T'\
\x00p\
\x00l\x00u\x00s\x00.\x00s\x00v\x00g\
\x00\x08\
\x06\xe1W\xa7\
\x00d\
\x00o\x00w\x00n\x00.\x00s\x00v\x00g\
\x00\x0f\
\x00 ['\
\x00p\
\x00l\x00u\x00s\x00 \x00(\x00g\x00r\x00a\x00y\x00)\x00.\x00s\x00v\x00g\
\x00\x09\
\x0b\x98\xb7'\
\x00p\
\x00i\x00e\x00c\x00e\x00.\x00s\x00v\x00g\
\x00\x08\
\x04\xb2UG\
\x00u\
\x00n\x00d\x00o\x00.\x00s\x00v\x00g\
\x00\x08\
\x0b\x85Wg\
\x00g\
\x00e\x00a\x00r\x00.\x00s\x00v\x00g\
\x00\x08\
\x03gT'\
\x00p\
\x00l\x00o\x00t\x00.\x00s\x00v\x00g\
\x00\x0a\
\x01\x0bC\x87\
\x00r\
\x00e\x00s\x00i\x00z\x00e\x00.\x00s\x00v\x00g\
\x00\x0c\
\x09\xcd\xaeg\
\x00l\
\x00o\x00a\x00d\x00_\x00a\x00d\x00d\x00.\x00s\x00v\x00g\
\x00\x08\
\x0b\xb2U\xc7\
\x00r\
\x00e\x00d\x00o\x00.\x00s\x00v\x00g\
\x00\x0e\
\x01'M\x07\
\x00c\
\x00l\x00e\x00a\x00r\x00_\x00r\x00u\x00n\x00s\x00.\x00s\x00v\x00g\
\x00\x0d\
\x02.\xca\x07\
\x00c\
\x00o\x00p\x00y\x002\x00d\x00o\x00w\x00n\x00.\x00s\x00v\x00g\
\x00\x11\
\x00\x16|'\
\x00a\
\x00r\x00e\x00a\x00_\x00t\x00r\x00a\x00n\x00s\x00f\x00e\x00r\x00.\x00s\x00v\x00g\
\
\x00\x06\
\x07\xc3Z\xc7\
\x00u\
\x00p\x00.\x00s\x00v\x00g\
\x00\x07\
\x04\xcaZ'\
\x00n\
\x00e\x00w\x00.\x00s\x00v\x00g\
\x00\x09\
\x07\xa6\xbcg\
\x00l\
\x00o\x00a\x00d\x00c\x00.\x00s\x00v\x00g\
\x00\x11\
\x0b;\xcc'\
\x00i\
\x00m\x00p\x00o\x00r\x00t\x00_\x00m\x00o\x00d\x00e\x00l\x00s\x00.\x00s\x00v\x00g\
\
\x00\x09\
\x08\xb6\xaf\x87\
\x00s\
\x00t\x00a\x00t\x00s\x00.\x00s\x00v\x00g\
\x00\x0e\
\x0b0\xc5\xa7\
\x00c\
\x00a\x00l\x00c\x00u\x00l\x00a\x00t\x00o\x00r\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x0e\
\x04\x9aK\x87\
\x00c\
\x00o\x00l\x00o\x00r\x00_\x00g\x00r\x00i\x00d\x00.\x00s\x00v\x00g\
\x00\x0d\
\x06m0\xa7\
\x00h\
\x00i\x00s\x00t\x00o\x00g\x00r\x00a\x00m\x00.\x00s\x00v\x00g\
\x00\x08\
\x0b\x07W\xa7\
\x00e\
\x00d\x00i\x00t\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\xc9T'\
\x00p\
\x00r\x00e\x00v\x00.\x00s\x00v\x00g\
\x00\x14\
\x0b3\xdd\x87\
\x00a\
\x00u\x00t\x00o\x00m\x00a\x00t\x00i\x00c\x00_\x00l\x00a\x00y\x00o\x00u\x00t\x00.\
\x00s\x00v\x00g\
\x00\x0a\
\x0c\xafw\xe7\
\x00r\
\x00o\x00s\x00e\x00t\x00a\x00.\x00s\x00v\x00g\
\x00\x0d\
\x0d\xa5]G\
\x00C\
\x00a\x00t\x00a\x00l\x00o\x00g\x00u\x00e\x00.\x00s\x00v\x00g\
\x00\x0b\
\x0aP\xdfG\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x002\x00.\x00s\x00v\x00g\
\x00\x13\
\x0f-z\xc7\
\x00i\
\x00m\x00p\x00o\x00r\x00t\x00_\x00p\x00r\x00o\x00f\x00i\x00l\x00e\x00s\x00.\x00s\
\x00v\x00g\
\x00\x0e\
\x01\x0eq\xa7\
\x00c\
\x00o\x00p\x00y\x002\x00r\x00i\x00g\x00h\x00t\x00.\x00s\x00v\x00g\
\x00\x14\
\x0f\xaf \xc7\
\x00m\
\x00a\x00g\x00n\x00i\x00f\x00y\x00i\x00n\x00g\x00_\x00g\x00l\x00a\x00s\x00s\x00.\
\x00s\x00v\x00g\
\x00\x15\
\x0a\xf2\xfb'\
\x00m\
\x00a\x00g\x00n\x00i\x00f\x00y\x00i\x00n\x00g\x00_\x00g\x00l\x00a\x00s\x00s\x002\
\x00.\x00s\x00v\x00g\
\x00\x11\
\x04\xdbX'\
\x00e\
\x00x\x00p\x00o\x00r\x00t\x00_\x00p\x00i\x00c\x00k\x00l\x00e\x00.\x00s\x00v\x00g\
\
\x00\x09\
\x05\x9e\x8e\xa7\
\x00c\
\x00l\x00o\x00c\x00k\x00.\x00s\x00v\x00g\
\x00\x08\
\x0c\xf7TG\
\x00n\
\x00e\x00x\x00t\x00.\x00s\x00v\x00g\
\x00\x08\
\x0c\xa5TG\
\x00n\
\x00e\x00w\x002\x00.\x00s\x00v\x00g\
\x00\x15\
\x0d\x18\x91g\
\x00i\
\x00n\x00p\x00u\x00t\x00s\x00_\x00a\x00n\x00a\x00l\x00y\x00s\x00i\x00s\x00 \x002\
\x00.\x00s\x00v\x00g\
\x00\x0d\
\x09\xcb\xdc'\
\x00s\
\x00c\x00h\x00e\x00m\x00a\x00t\x00i\x00c\x00.\x00s\x00v\x00g\
\x00\x0a\
\x00l\xe3\x87\
\x00f\
\x00u\x00s\x00i\x00o\x00n\x00.\x00s\x00v\x00g\
\x00\x08\
\x06|W\x87\
\x00c\
\x00o\x00p\x00y\x00.\x00s\x00v\x00g\
\x00\x14\
\x09 i\x07\
\x00r\
\x00u\x00n\x00_\x00c\x00a\x00s\x00c\x00a\x00d\x00e\x00_\x00s\x00t\x00e\x00p\x00.\
\x00s\x00v\x00g\
\x00\x09\
\x0a\xa8\xb7\xc7\
\x00p\
\x00a\x00s\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x0b\
\x083M\xc7\
\x00s\
\x00q\x00u\x00a\x00r\x00e\x00s\x00.\x00s\x00v\x00g\
\x00\x0b\
\x09\x17\x95G\
\x00c\
\x00o\x00p\x00y\x002\x00u\x00p\x00.\x00s\x00v\x00g\
\x00\x09\
\x08\x8c\x8b\xe7\
\x00a\
\x00r\x00r\x00a\x00y\x00.\x00s\x00v\x00g\
\x00\x0d\
\x0f\x18\xc9'\
\x00c\
\x00o\x00p\x00y\x002\x00l\x00e\x00f\x00t\x00.\x00s\x00v\x00g\
\x00\x09\
\x0c\xb6\xa9\xc7\
\x00s\
\x00a\x00v\x00e\x00c\x00.\x00s\x00v\x00g\
\x00\x10\
\x00\x04\x86\xa7\
\x00m\
\x00i\x00n\x00u\x00s\x00 \x00(\x00g\x00r\x00a\x00y\x00)\x00.\x00s\x00v\x00g\
\x00\x08\
\x05wT\xa7\
\x00l\
\x00o\x00a\x00d\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\xa4W\x87\
\x00d\
\x00a\x00t\x00a\x00.\x00s\x00v\x00g\
\x00\x09\
\x05\xc6\xb2\xc7\
\x00m\
\x00i\x00n\x00u\x00s\x00.\x00s\x00v\x00g\
\x00\x0f\
\x07\xf8iG\
\x00u\
\x00n\x00c\x00h\x00e\x00c\x00k\x00_\x00a\x00l\x00l\x00.\x00s\x00v\x00g\
\x00\x0a\
\x06\x99R'\
\x00i\
\x00m\x00p\x00o\x00r\x00t\x00.\x00s\x00v\x00g\
\x00\x0b\
\x06\xf4\x91\x87\
\x00c\
\x00o\x00n\x00s\x00o\x00l\x00e\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\x96W\xc7\
\x00b\
\x00a\x00r\x00s\x00.\x00s\x00v\x00g\
\x00\x09\
\x0a\x86\xb3G\
\x00n\
\x00e\x00w\x002\x00c\x00.\x00s\x00v\x00g\
\x00\x0d\
\x07\xf8\x19\xc7\
\x00c\
\x00h\x00e\x00c\x00k\x00_\x00a\x00l\x00l\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\xc8U\xe7\
\x00s\
\x00a\x00v\x00e\x00.\x00s\x00v\x00g\
\x00\x07\
\x06\xf6Z'\
\x00p\
\x00i\x00c\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00;\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x05\x94\x00\x00\x00\x00\x00\x01\x00\x01\xd7\x14\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x01Z\x00\x00\x00\x00\x00\x01\x00\x00\x7f\xaa\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x00L\x00\x00\x00\x00\x00\x01\x00\x00\x10k\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x04\x96\x00\x00\x00\x00\x00\x01\x00\x01\x8c\x07\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x00\xca\x00\x00\x00\x00\x00\x01\x00\x00J\x8e\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x03Z\x00\x00\x00\x00\x00\x01\x00\x01?\xb8\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x01\x18\x00\x00\x00\x00\x00\x01\x00\x00j\xfe\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x01:\x00\x00\x00\x00\x00\x01\x00\x00t\x93\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x00\xb4\x00\x00\x00\x00\x00\x01\x00\x00:\xea\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x02<\x00\x01\x00\x00\x00\x01\x00\x00\xcf\xd3\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x00\x88\x00\x00\x00\x00\x00\x01\x00\x00 \xba\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x01\x94\x00\x00\x00\x00\x00\x01\x00\x00\x94\xfa\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x03\xda\x00\x00\x00\x00\x00\x01\x00\x01^{\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x05\xba\x00\x00\x00\x00\x00\x01\x00\x01\xde\xad\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x04\x02\x00\x01\x00\x00\x00\x01\x00\x01h\xc7\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x05\xe6\x00\x00\x00\x00\x00\x01\x00\x01\xecq\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x02^\x00\x00\x00\x00\x00\x01\x00\x00\xd7u\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x04\xb0\x00\x00\x00\x00\x00\x01\x00\x01\x96\x0e\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x06\x22\x00\x00\x00\x00\x00\x01\x00\x01\xfa\xc9\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x006\x00\x00\x00\x00\x00\x01\x00\x00\x08\xea\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x06<\x00\x00\x00\x00\x00\x01\x00\x02\x02;\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x06\xbc\x00\x00\x00\x00\x00\x01\x00\x02+\x9f\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x01\xa8\x00\x00\x00\x00\x00\x01\x00\x00\x9e\xa3\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x01\x82\x00\x00\x00\x00\x00\x01\x00\x00\x8d\xc5\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x06\x86\x00\x00\x00\x00\x00\x01\x00\x02\x1b\xf8\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x05\xfe\x00\x00\x00\x00\x00\x01\x00\x01\xf4\x03\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x05\x0c\x00\x00\x00\x00\x00\x01\x00\x01\xad\x0e\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x05D\x00\x01\x00\x00\x00\x01\x00\x01\xbf\xbe\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x06X\x00\x00\x00\x00\x00\x01\x00\x02\x0b!\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x05\xd0\x00\x00\x00\x00\x00\x01\x00\x01\xe60\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x01\xe8\x00\x00\x00\x00\x00\x01\x00\x00\xb8\xc7\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x06\xa6\x00\x00\x00\x00\x00\x01\x00\x02#\xff\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x02\x94\x00\x00\x00\x00\x00\x01\x00\x00\xf01\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x05(\x00\x00\x00\x00\x00\x01\x00\x01\xb4\xb5\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x04\xc6\x00\x00\x00\x00\x00\x01\x00\x01\x9e\xfa\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x04v\x00\x01\x00\x00\x00\x01\x00\x01\x85=\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x00\xe4\x00\x00\x00\x00\x00\x01\x00\x00V\xc1\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x03\x12\x00\x00\x00\x00\x00\x01\x00\x01\x19\x87\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x06n\x00\x00\x00\x00\x00\x01\x00\x02\x13\x82\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x04\xf4\x00\x00\x00\x00\x00\x01\x00\x01\xa6;\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x03\xaa\x00\x00\x00\x00\x00\x01\x00\x01T\xa6\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x02~\x00\x00\x00\x00\x00\x01\x00\x00\xe8\x0e\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x02\x00\x00\x01\x00\x00\x00\x01\x00\x00\xc1\xf8\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x02\xaa\x00\x01\x00\x00\x00\x01\x00\x00\xf7m\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00\xa6\x22\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x00\x9e\x00\x00\x00\x00\x00\x01\x00\x00-\x8c\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x00p\x00\x00\x00\x00\x00\x01\x00\x00\x19\x9b\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x01\x02\x00\x00\x00\x00\x00\x01\x00\x00a\x87\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x040\x00\x00\x00\x00\x00\x01\x00\x01ts\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x02\x22\x00\x00\x00\x00\x00\x01\x00\x00\xc6\xc6\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x02\xd8\x00\x00\x00\x00\x00\x01\x00\x00\xfe\x85\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x05|\x00\x00\x00\x00\x00\x01\x00\x01\xcf3\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x04\x1a\x00\x00\x00\x00\x00\x01\x00\x01m(\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x04F\x00\x01\x00\x00\x00\x01\x00\x01|\xed\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x02\xf2\x00\x00\x00\x00\x00\x01\x00\x01\x10C\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x05\x5c\x00\x00\x00\x00\x00\x01\x00\x01\xc4\x13\
\x00\x00\x01\x8b\xd7}+\x8a\
\x00\x00\x03.\x00\x00\x00\x00\x00\x01\x00\x01'\x9c\
\x00\x00\x01\x8b\xd7}+\x8e\
\x00\x00\x03|\x00\x00\x00\x00\x00\x01\x00\x01J\xd9\
\x00\x00\x01\x8b\xd7}+\x8e\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
