# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.7.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x07r\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22g\
ear.svg\x22\x0a   inks\
cape:version=\x220.\
92.4 (5da689c313\
, 2019-01-14)\x22>\x0a\
  <metadata\x0a    \
 id=\x22metadata8\x22>\
\x0a    <rdf:RDF>\x0a \
     <cc:Work\x0a  \
       rdf:about\
=\x22\x22>\x0a        <dc\
:format>image/sv\
g+xml</dc:format\
>\x0a        <dc:ty\
pe\x0a           rd\
f:resource=\x22http\
://purl.org/dc/d\
cmitype/StillIma\
ge\x22 />\x0a        <\
dc:title />\x0a    \
  </cc:Work>\x0a   \
 </rdf:RDF>\x0a  </\
metadata>\x0a  <def\
s\x0a     id=\x22defs6\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#666666\x22\x0a \
    borderopacit\
y=\x221\x22\x0a     objec\
ttolerance=\x2210\x22\x0a\
     gridtoleran\
ce=\x2210\x22\x0a     gui\
detolerance=\x2210\x22\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0a    \
 inkscape:window\
-width=\x221858\x22\x0a  \
   inkscape:wind\
ow-height=\x221057\x22\
\x0a     id=\x22namedv\
iew4\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
1.2291667\x22\x0a     \
inkscape:cx=\x22-19\
6.88135\x22\x0a     in\
kscape:cy=\x2296.00\
0006\x22\x0a     inksc\
ape:window-x=\x2254\
\x22\x0a     inkscape:\
window-y=\x22-8\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g2\x22 />\x0a  <path\x0a \
    style=\x22fill:\
#999999;fill-opa\
city:1;stroke:no\
ne;stroke-width:\
1.05025125px;str\
oke-linecap:butt\
;stroke-linejoin\
:miter;stroke-op\
acity:1\x22\x0a     d=\
\x22M 10.576272,94.\
017211 60.13389,\
154.68255 180.61\
016,60.693977 17\
0.35686,50.44067\
9 62.697217,126.\
48598 22.538455,\
87.181671 Z\x22\x0a   \
  id=\x22path812\x22\x0a \
    inkscape:con\
nector-curvature\
=\x220\x22\x0a     sodipo\
di:nodetypes=\x22cc\
ccccc\x22 />\x0a</svg>\
\x0a\
\x00\x00\x0f\xd3\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   version\
=\x221.1\x22\x0a   id=\x22sv\
g2\x22\x0a   width=\x2219\
2\x22\x0a   height=\x2219\
2\x22\x0a   viewBox=\x220\
 0 192 192\x22\x0a   s\
odipodi:docname=\
\x22plot.svg\x22\x0a   in\
kscape:version=\x22\
1.2.2 (b0a848654\
1, 2022-12-01)\x22\x0a\
   xml:space=\x22pr\
eserve\x22\x0a   xmlns\
:inkscape=\x22http:\
//www.inkscape.o\
rg/namespaces/in\
kscape\x22\x0a   xmlns\
:sodipodi=\x22http:\
//sodipodi.sourc\
eforge.net/DTD/s\
odipodi-0.dtd\x22\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0a   xmlns:sv\
g=\x22http://www.w3\
.org/2000/svg\x22\x0a \
  xmlns:rdf=\x22htt\
p://www.w3.org/1\
999/02/22-rdf-sy\
ntax-ns#\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
dc=\x22http://purl.\
org/dc/elements/\
1.1/\x22><metadata\x0a\
     id=\x22metadat\
a8\x22><rdf:RDF><cc\
:Work\x0a         r\
df:about=\x22\x22><dc:\
format>image/svg\
+xml</dc:format>\
<dc:type\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 /><dc:\
title /></cc:Wor\
k></rdf:RDF></me\
tadata><defs\x0a   \
  id=\x22defs6\x22 /><\
sodipodi:namedvi\
ew\x0a     pagecolo\
r=\x22#ffffff\x22\x0a    \
 bordercolor=\x22#6\
66666\x22\x0a     bord\
eropacity=\x221\x22\x0a  \
   objecttoleran\
ce=\x2210\x22\x0a     gri\
dtolerance=\x2210\x22\x0a\
     guidetolera\
nce=\x2210\x22\x0a     in\
kscape:pageopaci\
ty=\x220\x22\x0a     inks\
cape:pageshadow=\
\x222\x22\x0a     inkscap\
e:window-width=\x22\
1255\x22\x0a     inksc\
ape:window-heigh\
t=\x221011\x22\x0a     id\
=\x22namedview4\x22\x0a  \
   showgrid=\x22fal\
se\x22\x0a     inkscap\
e:zoom=\x221.229166\
7\x22\x0a     inkscape\
:cx=\x22-47.186439\x22\
\x0a     inkscape:c\
y=\x2297.220336\x22\x0a  \
   inkscape:wind\
ow-x=\x221305\x22\x0a    \
 inkscape:window\
-y=\x2232\x22\x0a     ink\
scape:window-max\
imized=\x220\x22\x0a     \
inkscape:current\
-layer=\x22svg2\x22\x0a  \
   inkscape:show\
pageshadow=\x222\x22\x0a \
    inkscape:pag\
echeckerboard=\x220\
\x22\x0a     inkscape:\
deskcolor=\x22#d1d1\
d1\x22 /><path\x0a    \
 style=\x22fill:non\
e;fill-rule:even\
odd;stroke:#0022\
55;stroke-width:\
6;stroke-linecap\
:round;stroke-li\
nejoin:miter;str\
oke-miterlimit:4\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22\x0a     d=\
\x22M 19.514459,83.\
80134 C 28.17302\
2,74.616437 31.0\
2386,60.80883 58\
.945963,57.74172\
2 82.147121,60.6\
3598 84.918418,8\
0.7924 103.71939\
,80.546389 c 24.\
26383,-1.274365 \
22.69186,-13.651\
999 44.24393,-13\
.027666 21.85487\
,-2.039903 20.28\
547,1.799283 32.\
6583,-17.05689\x22\x0a\
     id=\x22path814\
\x22\x0a     inkscape:\
connector-curvat\
ure=\x220\x22\x0a     sod\
ipodi:nodetypes=\
\x22ccccc\x22 /><path\x0a\
     style=\x22fill\
:none;fill-rule:\
evenodd;stroke:#\
0088aa;stroke-wi\
dth:6;stroke-lin\
ecap:round;strok\
e-linejoin:miter\
;stroke-miterlim\
it:4;stroke-dash\
array:none;strok\
e-opacity:1\x22\x0a   \
  d=\x22M 19.351568\
,101.88747 C 28.\
010131,92.702567\
 34.115206,77.26\
7842 58.783072,7\
5.827852 81.9842\
3,78.72211 84.75\
5527,98.87853 10\
3.5565,98.632519\
 c 24.26383,-1.2\
74365 22.69186,-\
13.651999 44.243\
93,-13.027666 21\
.85487,-2.039903\
 20.28547,1.7992\
83 32.6583,-17.0\
5689\x22\x0a     id=\x22p\
ath814-3\x22\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22\x0a\
     sodipodi:no\
detypes=\x22ccccc\x22 \
/><path\x0a     sty\
le=\x22fill:none;fi\
ll-rule:evenodd;\
stroke:#00aad4;s\
troke-width:6;st\
roke-linecap:rou\
nd;stroke-linejo\
in:miter;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne;stroke-opacit\
y:1\x22\x0a     d=\x22m 1\
7.724451,126.294\
25 c 8.65856,-9.\
1849 19.644994,-\
24.61963 39.4315\
,-26.05961 23.20\
116,2.89425 25.9\
7246,23.05067 44\
.773429,22.80466\
 24.26383,-1.274\
36 22.69186,-13.\
652 44.24393,-13\
.02766 21.85487,\
-2.03991 20.2854\
7,1.79928 32.658\
3,-17.056894\x22\x0a  \
   id=\x22path814-3\
-6\x22\x0a     inkscap\
e:connector-curv\
ature=\x220\x22\x0a     s\
odipodi:nodetype\
s=\x22ccccc\x22 /><pat\
h\x0a     style=\x22fi\
ll:none;fill-rul\
e:evenodd;stroke\
:#00d4aa;stroke-\
width:6;stroke-l\
inecap:round;str\
oke-linejoin:mit\
er;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-opacity:1\x22\x0a \
    d=\x22m 19.3515\
6,101.88746 c 8.\
65857,-9.184897 \
20.458553,-14.04\
3351 40.245069,-\
15.483346 17.506\
235,1.267141 25.\
158891,5.152375 \
43.959861,4.9063\
65 24.26384,-1.2\
7436 16.99695,3.\
432746 38.54902,\
4.057086 21.8548\
7,-2.03991 17.03\
124,-5.522754 39\
.16678,-15.42978\
1\x22\x0a     id=\x22path\
814-3-7\x22\x0a     in\
kscape:connector\
-curvature=\x220\x22\x0a \
    sodipodi:nod\
etypes=\x22ccccc\x22 /\
><path\x0a     styl\
e=\x22fill:none;fil\
l-rule:evenodd;s\
troke:#999999;st\
roke-width:10;st\
roke-linecap:rou\
nd;stroke-linejo\
in:miter;stroke-\
opacity:1;stroke\
-miterlimit:4;st\
roke-dasharray:n\
one\x22\x0a     d=\x22M 1\
81.42373,170.847\
46 H 16.271186 l\
 1e-6,-152.13559\
6\x22\x0a     id=\x22path\
812\x22\x0a     inksca\
pe:connector-cur\
vature=\x220\x22\x0a     \
sodipodi:nodetyp\
es=\x22ccc\x22 /></svg\
>\x0a\
\x00\x00\x04\x9d\
\x00\
\x00\x10\x03x\xda\xe5WK\x8f\xdb6\x10\xbe\xef\xaf`\
\x95K\x82\x9a\x14IQ\xa2\xa4\xda\x0e\xd0\x04\x01r\xe8\
\xa5M\xd13-\xd2k%\x92hH\xf4z7\xbf>\
CY\x0f{\x1f\xc06)\x0al\xcb\xc5\x02\x9e\x079\
3\xdf|\x1c\xda\xcb\xb7\xb7u\x85nL\xdb\x95\xb6Y\
\x05\x8c\xd0\x00\x99\xa6\xb0\xbal\xaeW\xc1\x9f\x9f>\xe0\
4@\x9dS\x8dV\x95m\xcc*hl\xf0v}\xb5\
\xfc\x09c\xf4\xae5\xca\x19\x8d\x8e\xa5\xdb\xa1\x8f\xcd\x97\
\xaeP{\x83^\xef\x9c\xdb\xe7ax<\x1eI9(\
\x89m\xaf\xc37\x08\xe3\xf5\xd5\xd5\xb2\xbb\xb9\xbeB\x08\
A\xdc\xa6\xcbu\xb1\x0a\x86\x0d\xfbC[\xf5\x8e\xba\x08\
Mej\xd3\xb8.d\x84\x85\xc1\xec^\xcc\xee\x85\x8f\
^\xde\x98\xc2\xd6\xb5m\xba~g\xd3\xbd:sn\xf5\
v\xf2\xf6\xd9\x1c\xa3\xde\x89eY\x16R\x1er\x8e\xc1\
\x03ww\x8dS\xb7\xf8r+\xe4\xf8\xd8VN)\x0d\
\xc16{>\xcf+\xef\x00\xd0=\xfcO\xee\xa3\x82t\
\xf6\xd0\x16f\x0b\xfb\x0ci\x8c\x0b\xdf\x7fz?\x191\
%\xda\xe9\xb3cF</\xa2^\x80\xdc\xa8\xdat{\
U\x98.\x1c\xf5\xfd\xfe\xb3\x0e\xb3^Q\xeaU\x009\
\xf2^8\x96\xda\xed\xc0\x96\x9d\xc4\x9d)\xafwn\x96\
oJs\xfc\xd5\xde\xae\x02\x8a(\x02%\x1a\x0dc\xa2\
\xb9\xb6\x85\x8f\xbc\x0a*\x88\x8a\x9d\xc5\x1dt\xb0p\x10\
\x91\x8c@\x8c\xe9\xe4S*\x94d\x9cD\xe85\x174\
\x8eE\xb2@\x9c\xb2\x14\xd3\x083\xf6&X\xc3\x9ee\
m\x9c\xd2\xca)\xbf\xff\x94\xf2\xa8I{\x07p\x81\x16\
\xe6\xbf\xbf\xffp\x92@.\x8a\xfc/\xdb~\x19DX\
\xdeAm\xec\x01\xea\x09\xd6\x93z\xa9\x8b\x1c@\xaf\x95\
[\x97\xb5\xba6\xbe_?\x03\xc8\xcbp6\x5c8\xbb\
\xbb\xbd\x99\x0f=\x1d\xdb\x9aS\xf7\x1e\xa5\xb0.\xea\xd2\
o\x0a\xffpeU}\xf4A\x02\x14\xde;\xb4t\x95\
Y\xf71O\x1f\xc7*\xc2\xa1\x8c\xa1\xc8\xf0\xac\xcae\
8b\xd0K\xdal\xbb\x19\x1e/%C\x98\xe5\xd4\x1d\
\xdf\x1a\xed\x9bxr\xdcC*\x85\xadl\xbb\x0a^m\
\xfb\x15\x9c\x0c\x1b\xdbj\xd3\x8e\xa6\xa4_\x17&\x0b\xcc\
\x82\xa2\x80\x19\x83\xdan>C\x9b\x9d\xadL\xab\x1a\x0f\
\x04\xa3\x83\xe5\xba\x05N=\xa6?\x94\xda<f\x98\xf8\
\xe1\xd3\x9b\x02=j\xedvJ\xdb\xe3*\xe0\xf7\x8d\xc7\
\xb2\x01\x03\x1e\xe9\x9c&\xd1\x13\x1e\x13\xc3)\x8f\x83\x19\
\xbe\x09(1(\xbb\x9d=\xfaJV\xc1VU\x9d\xb9\
\x7f\xdaWkk\x7f\xa58\xcfX\x92\xc8\xfb\xe6\x02\xae\
\x0c\x16\x92d~\xa5\x0f\xacP^\x96\x10\xeaW\xf2D\
\x9ep@,\x9f\xb0\xc1v\xfe\x94\xadV\xb7e]~\
5zn\xd5\x1c\xf7\xd0\xb60[q\xa5\xeeL;\x0c\
\x81\x811-4s(\xdc\xddU\xd0\x9d\xa1\x0f9\xfb\
e\x0b$\xce_\xa5\x8ao\x0c\xef\x05<\xdb:\xd7\xda\
/&\x1f\xc84\x88\xa7.\xe4\x94DRf1\x97\xf1\
\xa8\x87\x11a \x91\xbc\xb5\x87F\x9f+?\xdb\xb2\xc9\
7\xe6\xc6T\xa3\x16n\x90i+\xa8\xc4\xe5b\xd4i\
\x05\xedo[u\x977\xf0 \x8d\xda9\x99\xbd*\xa1\
\xb8\x9e\xae\xe0\x01\x17\xb9:k\xb0/0e#o\x06\
\x9e\x88\x880\xe0\x8a\x18\x990\x92C0\x222\x16\xf3\
\x91\x0c\xbe\x9b,\x95$\xe6\xb1\x18uw^\xc7\xc1\x91\
\xd1tl\x86\x03jw~\x86\x00\xb8\x85\xaa\xcck\x0c\
\xf3\xec\xb9\x08\x0b\x96d\x86\xbdx\x84q\xf4\xfd\x18\xc3\
\x8d\xe9]\xb33\x8c3Jh\x9a\xa6<{\x06\xc6{\
\xe5v\x17\x18\xf7\xc8\xf6\xb5\xf4\xb0\xb6\x87\xca\xe4\x00B\
c\xb5\x9e\x90M\xa9\xff\xbbD\xf6\x01\xa0\x9b\x83s\x0f\
\xf0\xec!\xfc\xfbxz\xad\xddn;\xe3r\xfa\x00\xe3\
\xa1J\xc0\xf37\xc4DL8cR.\x18\x85\xefg\
\x8c'\x12\xbdC\x8c\x0a\x92$<\x11\x8bL\x90,M\
i\x14!\xc6\xe0cB\xa3x!\x19\x89b\xc1c\x8e\
DB\xa4\x94Q,\x17IF\x04\xe5\x19\xe7g\xdd\xf2\
P\xcd\xa0\xce#\xc26P\xb0\xb3-\x86aq\xa3\xdc\
\xa15\xf3(\x9e\x9f\x15\x0b\x93\x1c^8\xf8\x12T\x14\
\xcf'\xf8\x86\xd2\xf4\xe5\x8f\x10\x9c\xfc\xd8\x10\xa1\x09c\
g\xfcNRB\xb9\x14\xd3{\xfb\xbf\xe1w\x0d\xfc\x16\
D\x0a)\xa2\x05\x5c\xfc\x04\x08\x9apT ,(\x89\
\x01\xb9h\x81\xe1\x8d\xe4\x22\x89\x10\xe6\x19\x91\xa9\xa4\xe9\
\x82GDr\x91e\x08g\xf0\xbaJJe\xb4\x80!\
\x0c<\x9f\x00<c7\x96\xff&\xbf7*\x8eu\xf4\
\xf2\xf9\x1d\xff0\xbfiz\xfeHJ\x0e\x9d\x82\x89\xf5\
\x9f!\xf8\x13\xc3z$3`Bb\x99\x0a>\x0ck\
\x96\xa5\xa0\x84q\x1c\xc7\x91\xcc\xbe\x7fV\xe3\xe8\x9fb\
\xf3\xd2\xff\xe8Y_}\x03\x0d\xf2\xdf\xcb\
\x00\x00\x09\x91\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg6\x22\x0a   so\
dipodi:docname=\x22\
clear_runs.svg\x22\x0a\
   inkscape:vers\
ion=\x221.0 (4035a4\
fb49, 2020-05-01\
)\x22>\x0a  <metadata\x0a\
     id=\x22metadat\
a12\x22>\x0a    <rdf:R\
DF>\x0a      <cc:Wo\
rk\x0a         rdf:\
about=\x22\x22>\x0a      \
  <dc:format>ima\
ge/svg+xml</dc:f\
ormat>\x0a        <\
dc:type\x0a        \
   rdf:resource=\
\x22http://purl.org\
/dc/dcmitype/Sti\
llImage\x22 />\x0a    \
    <dc:title />\
\x0a      </cc:Work\
>\x0a    </rdf:RDF>\
\x0a  </metadata>\x0a \
 <defs\x0a     id=\x22\
defs10\x22 />\x0a  <so\
dipodi:namedview\
\x0a     pagecolor=\
\x22#ffffff\x22\x0a     b\
ordercolor=\x22#666\
666\x22\x0a     border\
opacity=\x221\x22\x0a    \
 objecttolerance\
=\x2210\x22\x0a     gridt\
olerance=\x2210\x22\x0a  \
   guidetoleranc\
e=\x2210\x22\x0a     inks\
cape:pageopacity\
=\x220\x22\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0a     inkscape:\
window-width=\x2296\
3\x22\x0a     inkscape\
:window-height=\x22\
753\x22\x0a     id=\x22na\
medview8\x22\x0a     s\
howgrid=\x22false\x22\x0a\
     inkscape:zo\
om=\x221.7383042\x22\x0a \
    inkscape:cx=\
\x2228.919447\x22\x0a    \
 inkscape:cy=\x22-6\
7.163857\x22\x0a     i\
nkscape:window-x\
=\x22173\x22\x0a     inks\
cape:window-y=\x222\
01\x22\x0a     inkscap\
e:window-maximiz\
ed=\x220\x22\x0a     inks\
cape:current-lay\
er=\x22svg6\x22\x0a     i\
nkscape:document\
-rotation=\x220\x22 />\
\x0a  <path\x0a     so\
dipodi:nodetypes\
=\x22csscc\x22\x0a     id\
=\x22path836\x22\x0a     \
d=\x22m 6.2346543,2\
2.700042 c 7.715\
9037,2.037933 15\
.1042447,-2.0166\
72 16.7611707,-0\
.582958 0,0 5.48\
4116,2.679027 6.\
127844,5.302337 \
0.855518,3.48639\
1 -5.305974,14.0\
09468 -5.305974,\
14.009468 C 11.7\
46956,38.027462 \
7.0322016,31.259\
994 6.2346543,22\
.700042 Z\x22\x0a     \
style=\x22fill:#e6e\
6e6;stroke:#8080\
80;stroke-width:\
1px;stroke-linec\
ap:butt;stroke-l\
inejoin:miter;st\
roke-opacity:1\x22 \
/>\x0a  <path\x0a     \
sodipodi:nodetyp\
es=\x22csccc\x22\x0a     \
id=\x22path838\x22\x0a   \
  d=\x22M 25.637402\
,23.588184 41.85\
822,7.750306 c 0\
.767688,-0.74956\
4 2.438884,0.876\
482 1.782516,1.6\
14332 L 27.46747\
2,24.948699 Z\x22\x0a \
    style=\x22fill:\
#808080;stroke:#\
808080;stroke-wi\
dth:1px;stroke-l\
inecap:butt;stro\
ke-linejoin:mite\
r;stroke-opacity\
:1\x22 />\x0a  <path\x0a \
    id=\x22path840\x22\
\x0a     d=\x22M 28.50\
1261,30.871441 1\
8.215729,22.4820\
94\x22\x0a     style=\x22\
fill:none;stroke\
:#808080;stroke-\
width:1px;stroke\
-linecap:butt;st\
roke-linejoin:mi\
ter;stroke-opaci\
ty:1\x22 />\x0a</svg>\x0a\
\
\x00\x00\x0b\x13\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22c\
opy2down.svg\x22\x0a  \
 inkscape:versio\
n=\x220.92.3 (24055\
46, 2018-03-11)\x22\
>\x0a  <metadata\x0a  \
   id=\x22metadata8\
\x22>\x0a    <rdf:RDF>\
\x0a      <cc:Work\x0a\
         rdf:abo\
ut=\x22\x22>\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0a        <dc:\
type\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0a       \
 <dc:title />\x0a  \
    </cc:Work>\x0a \
   </rdf:RDF>\x0a  \
</metadata>\x0a  <d\
efs\x0a     id=\x22def\
s6\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0a     id=\x22name\
dview4\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x221.2291667\x22\x0a   \
  inkscape:cx=\x22-\
328.06314\x22\x0a     \
inkscape:cy=\x2296.\
000009\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
g820\x22 />\x0a  <path\
\x0a     style=\x22fil\
l:#999999;stroke\
-width:1.3333333\
7\x22\x0a     d=\x22m 53.\
118644,179.49816\
 c -1.46666,-0.6\
2009 -4.16666,-2\
.7414 -6,-4.7140\
1 l -3.33333,-3.\
58656 V 108.6639\
8 46.130379 l 4.\
35897,-4.358975 \
4.35898,-4.35897\
4 h 50.615376 50\
.61539 l 4.35897\
,4.358974 4.3589\
7,4.358975 v 62.\
615381 62.61539 \
l -4.35758,4.358\
97 -4.3576,4.358\
97 -48.97574,0.2\
7327 c -26.93665\
6,0.15029 -50.17\
5736,-0.23409 -5\
1.642406,-0.8542\
 z m 93.999996,-\
70.7524 V 52.745\
763 h -44 -43.99\
9996 v 55.999997\
 56 h 43.999996 \
44 z M 11.412064\
,73.437035 l 0.3\
7325,-59.308728 \
4.35767,-4.35793\
95 4.35768,-4.35\
79381 51.30899,-\
0.3786652 51.308\
986,-0.3786654 v\
 8.0453322 8.045\
332 h -47.999996\
 -48 v 56 55.999\
997 h -8.03992 -\
8.03991 z\x22\x0a     \
id=\x22path817\x22\x0a   \
  inkscape:conne\
ctor-curvature=\x22\
0\x22 />\x0a  <g\x0a     \
id=\x22g820\x22\x0a     t\
ransform=\x22matrix\
(-4,0,0,-4,-202.\
16948,208.67797)\
\x22>\x0a    <path\x0a   \
    id=\x22path2\x22\x0a \
      d=\x22M 0,0 H\
 48 V 48 H 0 Z\x22\x0a\
       inkscape:\
connector-curvat\
ure=\x220\x22\x0a       s\
tyle=\x22fill:none\x22\
 />\x0a    <path\x0a  \
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a       id=\
\x22path4489\x22\x0a     \
  d=\x22m -82.71455\
9,29.629973 13.0\
37829,0.118525 -\
6.755966,-11.496\
992 z\x22\x0a       st\
yle=\x22fill:#37c8a\
b;fill-rule:even\
odd;stroke:#37c8\
ab;stroke-width:\
1.16550279;strok\
e-linecap:butt;s\
troke-linejoin:r\
ound;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
 />\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x09\xf5\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22a\
uto-link.svg\x22\x0a  \
 inkscape:versio\
n=\x220.92.3 (24055\
46, 2018-03-11)\x22\
>\x0a  <metadata\x0a  \
   id=\x22metadata8\
\x22>\x0a    <rdf:RDF>\
\x0a      <cc:Work\x0a\
         rdf:abo\
ut=\x22\x22>\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0a        <dc:\
type\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0a       \
 <dc:title />\x0a  \
    </cc:Work>\x0a \
   </rdf:RDF>\x0a  \
</metadata>\x0a  <d\
efs\x0a     id=\x22def\
s6\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0a     id=\x22name\
dview4\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x221.2291667\x22\x0a   \
  inkscape:cx=\x22-\
47.999998\x22\x0a     \
inkscape:cy=\x2296.\
000006\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
svg2\x22 />\x0a  <rect\
\x0a     style=\x22opa\
city:1;fill:#416\
9e1;fill-opacity\
:1;stroke:#fffff\
f;stroke-width:0\
.37795275;stroke\
-linecap:round;s\
troke-linejoin:b\
evel;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1;\
paint-order:norm\
al\x22\x0a     id=\x22rec\
t812\x22\x0a     width\
=\x2243.118645\x22\x0a   \
  height=\x2241.491\
524\x22\x0a     x=\x223.2\
542515\x22\x0a     y=\x22\
64.271187\x22 />\x0a  \
<rect\x0a     style\
=\x22opacity:1;fill\
:#20b2aa;fill-op\
acity:1;stroke:#\
ffffff;stroke-wi\
dth:0.37795275;s\
troke-linecap:ro\
und;stroke-linej\
oin:bevel;stroke\
-miterlimit:4;st\
roke-dasharray:n\
one;stroke-opaci\
ty:1;paint-order\
:normal\x22\x0a     id\
=\x22rect812-3\x22\x0a   \
  width=\x2243.1186\
45\x22\x0a     height=\
\x2241.491524\x22\x0a    \
 x=\x22143.59323\x22\x0a \
    y=\x2295.593224\
\x22 />\x0a  <path\x0a   \
  style=\x22fill:no\
ne;fill-rule:eve\
nodd;stroke:#808\
080;stroke-width\
:5;stroke-lineca\
p:butt;stroke-li\
nejoin:miter;str\
oke-opacity:1;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none\x22\x0a     d=\
\x22M 45.567915,84.\
669386 C 86.1170\
49,90.694019 75.\
819334,114.3278 \
144.00233,116.27\
913\x22\x0a     id=\x22pa\
th829\x22\x0a     inks\
cape:connector-c\
urvature=\x220\x22\x0a   \
  sodipodi:nodet\
ypes=\x22cc\x22 />\x0a</s\
vg>\x0a\
\x00\x00\x08K\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22d\
elete.svg\x22\x0a   in\
kscape:version=\x22\
0.92.2 (5c3e80d,\
 2017-08-06)\x22>\x0a \
 <metadata\x0a     \
id=\x22metadata8\x22>\x0a\
    <rdf:RDF>\x0a  \
    <cc:Work\x0a   \
      rdf:about=\
\x22\x22>\x0a        <dc:\
format>image/svg\
+xml</dc:format>\
\x0a        <dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0a        <d\
c:title />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs6\x22\
 />\x0a  <sodipodi:\
namedview\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#666666\x22\x0a  \
   borderopacity\
=\x221\x22\x0a     object\
tolerance=\x2210\x22\x0a \
    gridtoleranc\
e=\x2210\x22\x0a     guid\
etolerance=\x2210\x22\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0a  \
   inkscape:page\
shadow=\x222\x22\x0a     \
inkscape:window-\
width=\x22784\x22\x0a    \
 inkscape:window\
-height=\x22480\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0a     ink\
scape:cx=\x22-47.99\
9997\x22\x0a     inksc\
ape:cy=\x2296.00000\
3\x22\x0a     inkscape\
:window-x=\x2257\x22\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0a     \
inkscape:window-\
maximized=\x220\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0a  <path\x0a    \
 style=\x22fill:#99\
9999;stroke-widt\
h:1.33333337\x22\x0a  \
   d=\x22M 44.01994\
,147.1665 38.367\
572,141.51412 60\
.68885,119.16384\
 83.010129,96.81\
3559 60.68885,74\
.463272 38.36757\
2,52.112986 44.0\
1994,46.460618 4\
9.672308,40.8082\
5 72.022594,63.1\
29528 94.372885,\
85.450807 116.72\
318,63.129528 13\
9.07346,40.80825\
 l 5.65238,5.652\
368 5.65236,5.65\
2368 -22.32128,2\
2.350286 -22.321\
28,22.350287 22.\
32128,22.350281 \
22.32128,22.3502\
8 -5.65236,5.652\
38 -5.65238,5.65\
236 -22.35028,-2\
2.32128 -22.3502\
95,-22.32127 -22\
.350291,22.32127\
 -22.350286,22.3\
2128 z\x22\x0a     id=\
\x22path817\x22\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22 \
/>\x0a</svg>\x0a\
\x00\x00\x0a\xef\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22i\
mport_profiles.s\
vg\x22\x0a   inkscape:\
version=\x220.92.3 \
(2405546, 2018-0\
3-11)\x22>\x0a  <metad\
ata\x0a     id=\x22met\
adata8\x22>\x0a    <rd\
f:RDF>\x0a      <cc\
:Work\x0a         r\
df:about=\x22\x22>\x0a   \
     <dc:format>\
image/svg+xml</d\
c:format>\x0a      \
  <dc:type\x0a     \
      rdf:resour\
ce=\x22http://purl.\
org/dc/dcmitype/\
StillImage\x22 />\x0a \
       <dc:title\
 />\x0a      </cc:W\
ork>\x0a    </rdf:R\
DF>\x0a  </metadata\
>\x0a  <defs\x0a     i\
d=\x22defs6\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     pagecolo\
r=\x22#ffffff\x22\x0a    \
 bordercolor=\x22#6\
66666\x22\x0a     bord\
eropacity=\x221\x22\x0a  \
   objecttoleran\
ce=\x2210\x22\x0a     gri\
dtolerance=\x2210\x22\x0a\
     guidetolera\
nce=\x2210\x22\x0a     in\
kscape:pageopaci\
ty=\x220\x22\x0a     inks\
cape:pageshadow=\
\x222\x22\x0a     inkscap\
e:window-width=\x22\
1851\x22\x0a     inksc\
ape:window-heigh\
t=\x221025\x22\x0a     id\
=\x22namedview4\x22\x0a  \
   showgrid=\x22fal\
se\x22\x0a     inkscap\
e:zoom=\x221.229166\
7\x22\x0a     inkscape\
:cx=\x22-346.57627\x22\
\x0a     inkscape:c\
y=\x2296.000009\x22\x0a  \
   inkscape:wind\
ow-x=\x2269\x22\x0a     i\
nkscape:window-y\
=\x2227\x22\x0a     inksc\
ape:window-maxim\
ized=\x221\x22\x0a     in\
kscape:current-l\
ayer=\x22svg2\x22 />\x0a \
 <g\x0a     id=\x22g83\
5\x22\x0a     transfor\
m=\x22matrix(1.1587\
003,0,0,1.158700\
3,275.47132,85.1\
71948)\x22>\x0a    <pa\
th\x0a       inksca\
pe:connector-cur\
vature=\x220\x22\x0a     \
  id=\x22path817\x22\x0a \
      d=\x22m -218.\
01167,4.573994 0\
.37325,59.308728\
 4.35767,4.35793\
9 4.35768,4.3579\
38 51.30899,0.37\
8665 51.309,0.37\
8666 v -8.045332\
 -8.045332 h -48\
.00001 -48 v -56\
 -55.999998 h -8\
.03992 -8.03991 \
z\x22\x0a       style=\
\x22fill:#999999;st\
roke-width:1.333\
33337\x22 />\x0a    <p\
ath\x0a       inksc\
ape:connector-cu\
rvature=\x220\x22\x0a    \
   id=\x22path817-3\
\x22\x0a       d=\x22m -9\
0.5985,4.5739917\
 -0.37325,59.308\
7243 -4.35767,4.\
35794 -4.35768,4\
.35794 -51.30899\
,0.37867 -51.309\
,0.37866 v -8.04\
533 -8.04533 h 4\
8.00001 48 V 1.2\
652637 -54.73473\
1 h 8.03992 8.03\
991 z\x22\x0a       st\
yle=\x22fill:#99999\
9;stroke-width:1\
.33333337\x22 />\x0a  \
</g>\x0a  <path\x0a   \
  inkscape:conne\
ctor-curvature=\x22\
0\x22\x0a     id=\x22path\
817-5\x22\x0a     d=\x22m\
 61.642009,123.8\
6307 v -5.22167 \
h 36.551624 36.5\
51627 v 5.22167 \
5.22166 H 98.193\
633 61.642009 Z \
M 79.917819,89.4\
87134 62.093068,\
71.646462 h 10.2\
17791 10.21779 V\
 55.981481 40.31\
6499 h 15.664984\
 15.664987 v 15.\
664982 15.664981\
 h 10.21779 10.2\
1778 l -17.82474\
,17.840672 c -9.\
80362,9.812372 -\
18.027727,17.840\
686 -18.275817,1\
7.840686 -0.2480\
82,0 -8.472201,-\
8.028314 -18.275\
814,-17.840686 z\
\x22\x0a     style=\x22fi\
ll:#37c8ab;strok\
e-width:0.870276\
75\x22 />\x0a</svg>\x0a\
\x00\x00\x08\xe8\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22c\
opy.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x221863\x22\x0a     \
inkscape:window-\
height=\x221025\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0a     ink\
scape:cx=\x22-47.99\
9997\x22\x0a     inksc\
ape:cy=\x2296.00000\
3\x22\x0a     inkscape\
:window-x=\x2257\x22\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0a  <path\x0a    \
 style=\x22fill:#99\
9999;stroke-widt\
h:1.33333337\x22\x0a  \
   d=\x22m 59.62711\
6,180.31172 c -1\
.46666,-0.62009 \
-4.16666,-2.7414\
 -6,-4.71401 l -\
3.33333,-3.58656\
 V 109.47754 46.\
943938 l 4.35897\
,-4.358975 4.358\
98,-4.358974 h 5\
0.615384 50.6153\
9 l 4.35897,4.35\
8974 4.35897,4.3\
58975 v 62.61538\
2 62.61539 l -4.\
35758,4.35897 -4\
.3576,4.35897 -4\
8.97574,0.27327 \
c -26.936664,0.1\
5029 -50.175744,\
-0.23409 -51.642\
414,-0.8542 z m \
94.000004,-70.75\
24 V 53.559322 h\
 -44 -44.000004 \
v 55.999998 56 h\
 44.000004 44 z \
M 17.920536,74.2\
50594 l 0.37325,\
-59.308728 4.357\
67,-4.357939 4.3\
5768,-4.3579383 \
51.30899,-0.3786\
652 51.308994,-0\
.3786654 v 8.045\
3319 8.045332 h \
-48.000004 -48 v\
 56 55.999998 h \
-8.03992 -8.0399\
1 z\x22\x0a     id=\x22pa\
th817\x22\x0a     inks\
cape:connector-c\
urvature=\x220\x22 />\x0a\
</svg>\x0a\
\x00\x00\x04\x97\
\x00\
\x00\x0f\xfdx\xda\xe5W[o\xdb6\x14~\xcf\xaf\xe0\
\x94\x97\x143)\x92\xa2DI\xb3]`-\x0a\xf4a\
/[\x87=3\x22\x1d\xab\x91D\x83\xa2\xe3\xa4\xbf~\
G\xb2.v.@\xd6\x0e\x03\xda1\x08\xe0s#\xcf\
\xf9\xce\xc7C{\xf9\xf6\xbe\xae\xd0\x9dqmi\x9bU\
\xc0\x08\x0d\x90i\x0a\xab\xcb\xe6f\x15\xfc\xf9\xe9\x03N\
\x03\xd4z\xd5hU\xd9\xc6\xac\x82\xc6\x06o\xd7\x17\xcb\
\x9f0F\xef\x9cQ\xdeht(\xfd\x16}ln\xdb\
B\xed\x0c\xba\xdaz\xbf\xcb\xc3\xf0p8\x90rP\x12\
\xebn\xc27\x08\xe3\xf5\xc5\xc5\xb2\xbd\xbb\xb9@\x08\xc1\
\xb9M\x9b\xebb\x15\x0c\x01\xbb\xbd\xabzG]\x84\xa6\
2\xb5i|\x1b2\xc2\xc2`v/f\xf7\xa2;\xbd\
\xbc3\x85\xadk\xdb\xb4}d\xd3^\x9e8;\xbd\x99\
\xbc\xbbl\x0eQ\xef\xc4\xb2,\x0b)\x0f9\xc7\xe0\x81\
\xdb\x87\xc6\xab{|\x1e\x0a9>\x17\xca)\xa5!\xd8\
f\xcf\xd7y\xe5-\x00\xba\x83\xff\xc9}T\x90\xd6\xee\
]a6\x10gHc|\xf8\xfe\xd3\xfb\xc9\x88)\xd1\
^\x9fl3\xe2yv\xea\x19\xc8\x8d\xaaM\xbbS\x85\
i\xc3Q\xdf\xc7\x9ft\x98\xf5\x8aR\xaf\x02\xc8\x91\xf7\
\xc2\xa1\xd4~\x0b\xb6\xec(nMy\xb3\xf5\xb3|W\
\x9a\xc3\xaf\xf6~\x15PD\x11(\xd1h\x18\x13\xcd\xb5\
-\xba\x93WA\x05\xa7bo\xb1\xaa*2B0&\
\x92OIP\x92q\x12\xa1+.h\x1c\x8bd\x818\
e)\xa6\x11f\xecM\xb0\x86\x98em\xbc\xd2\xca\xab\
.\xfe\x98\xec\xa8I{\x07p\x81\xe6\xe5\xbf\xbf\xffp\
\x94@.\x8a\xfc/\xebn\x07\x11V\xe7\xa0\xae\xed\x1e\
*\x09\xd6\x93z\xa9\x8b\x1c\xe0\xae\x95_\x97\xb5\xba1\
]\xa7~\x06x\x97\xe1l8s\xf6\x0f;3oz\
\xdc\xd6\x99c\xdf\x9e%\xaf.\xea\xb2\x0b\x0a\xff\xf0e\
U}\xec\x0e\x09P\xf8h\xd3\xd2Wf\xdd\x9fy\xfc\
8V\x11\x0ee\x0cE\x86'U.\xc3\x11\x83^\xd2\
f\xd3\xce\xf0tR2\x1c\xb3\x9c\xfa\xd25Ew\xed\
;:\xee \x95\xc2V\xd6\xad\x82\xcbM\xbf\x82\xa3\xe1\
\xda:m\xdchJ\xfauf\xb2\xc0)(\x0a81\
\xa8\xed\xf5gSxo+\xe3T\xd3\x01\xc1\xe8`\xb9\
q\xc0\xa6\xe7\xf4\xfbR\x9b\xe7\x0c\x13?\xba\xf4\xa6\x83\
\x9e\xb5\xb6[\xa5\xeda\x15\xf0\xc7\xc6C\xd9\x80\x01\x8f\
DN\x93\xe8\x05\x8f\x89\xdb\x94\xc7\xc1\x0c\xdf\x04\x94\x18\
\x94\xed\xd6\x1e\xbaJV\xc1FU\xady\xbc\xdb\x17k\
\xeb\xee2q\x9e\xb1$\x91\x8f\xcd\x05\x5c\x16,$\xc9\
\xba\x95>\xb1ByYBh\xb7\x92\x17\xf2\x84\x0db\
\xf9\x82\x0d\xc2\xf9K\xb6Z\xdd\x97u\xf9\xc5\xe8\xb9U\
\xf3\xb9{\xe7`\xaa\xe2J=\x187\x5c\xff\x811\x0e\
\x9a9\x14\xee\x1f*\xe8\xce\xd0\x87\x9c\xfd\xb2\x01\x12\xe7\
\x97\x9c^s\xa5z\x01\xcf\xb6\xd6;{k\xf2\x81L\
\x83x\xecBNI$e\x16s\x19\x8fz\x18\x0e\x06\
\x12\xc9\x9d\xdd7\xfaT\xf9\xd9\x96M~m\xeeL5\
j\xe1\x06\x19WA%>\x17\xa3N+h\xbfs\xea\
!o\xe0)\x1a\xb5s2;UBq=]\xc1\x03\
.ru\xd2\xe0\xae\xc0\x94\x8d\xbc\x19x\x22\x22\xc2\x80\
+bd\xc2H\x0e\xc1\x88\xc8X\xccG2t\xddd\
\xa9$1\x8f\xc5\xa8{\xe8t\x1c\x1c\x19M\xc7fx\
\xa0v\xdb\xcd\x10\x00\xb7P\x95\xb9\xc20\xcf^\x8b\xb0\
`If\xd8w\x8f0\x8e\xbe\x1ec\xb81\xbdkv\
\x82qF\x09M\xd3\x94g\xaf\xc0x\xa7\xfc\xf6\x0c\xe3\
\x1e\xd9\xbe\x96\x1eV\xb7\xafL\x0e 4V\xeb\x09\xd9\
\x94v\x7f\xe7\xc8>\x01\xf4z\xef\xfd\x13<{\x08\xff\
9\x9e\x9d\xd6n6\xad\xf19}\x82\xf1P%\xe0\xf9\
\x1bb\x22&\x9c1)\x17\x8c\xc273\xc6\x13\x89\xde\
!F\x05I\x12\x9e\x88E&H\x96\xa64\x8a\x10c\
\xf01\xa1Q\xbc\x90\x8cD\xb1\xe01G\x22!R\xca\
(\x96\x8b$#\x82\xf2\x8c\xf3\x93nuP\xcd\xa0\xce\
#\xc26P\xb0\xb7\x0e\xc3\xb0\xb8S~\xef\xcc<\x8a\
\xe7g\xc5\xc2$\x87\x17\x0e\xbe\xfe\x14\xc5\xab\x09N\x8f\
@\x7f\xf7\x04O\xbem\x88\xd0\x84\xb1\x13~')\xa1\
\x5c\x8a\xe9\xbd\xfd\xdf\xf0\xbb\x06~\x0b\x22\x85\x14\xd1\x02\
.~\x02\x04M8*\x10\x16\x94\xc4\x80\x5c\xb4\xc0\xf0\
Fr\x91D\x08\xf3\x8c\xc8T\xd2t\xc1#\x22\xb9\xc8\
2\x843x]%\xa52Z\xc0\x10\x06\x9eO\x00\x9e\
\xb0\x1b\xcb\xff\x92\xdf\x82\x1a\xaa\x7f\x00~\xc7\xdf\xcco\
\x9a\x9e>\x92\x92C\xa7`b\xfd0\x04\x7faX\x8f\
d\x06LH,S\xc1\x87a\xcd\xb2\x14\x940\x8e\xe3\
8\x92\xd9\xd7\xcfj\x1c\xfd[l^v?z\xd6\x17\
\x7f\x03\xa6\xde\xdc\xcb\
\x00\x00\x09\x10\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22d\
elete3.svg\x22\x0a   i\
nkscape:version=\
\x220.92.4 (unknown\
)\x22>\x0a  <metadata\x0a\
     id=\x22metadat\
a8\x22>\x0a    <rdf:RD\
F>\x0a      <cc:Wor\
k\x0a         rdf:a\
bout=\x22\x22>\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0a        <d\
c:type\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 />\x0a     \
   <dc:title />\x0a\
      </cc:Work>\
\x0a    </rdf:RDF>\x0a\
  </metadata>\x0a  \
<defs\x0a     id=\x22d\
efs6\x22 />\x0a  <sodi\
podi:namedview\x0a \
    pagecolor=\x22#\
ffffff\x22\x0a     bor\
dercolor=\x22#66666\
6\x22\x0a     borderop\
acity=\x221\x22\x0a     o\
bjecttolerance=\x22\
10\x22\x0a     gridtol\
erance=\x2210\x22\x0a    \
 guidetolerance=\
\x2210\x22\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0a     inkscape\
:pageshadow=\x222\x22\x0a\
     inkscape:wi\
ndow-width=\x221863\
\x22\x0a     inkscape:\
window-height=\x221\
025\x22\x0a     id=\x22na\
medview4\x22\x0a     s\
howgrid=\x22false\x22\x0a\
     inkscape:zo\
om=\x221.7383042\x22\x0a \
    inkscape:cx=\
\x2228.86947\x22\x0a     \
inkscape:cy=\x226.5\
751461\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
g831\x22 />\x0a  <g\x0a  \
   id=\x22g831\x22\x0a   \
  style=\x22stroke:\
#37c8ab;stroke-w\
idth:21;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e\x22>\x0a    <path\x0a  \
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a       id=\
\x22path812\x22\x0a      \
 d=\x22M 59.837063,\
61.191958 134.85\
037,135.42536\x22\x0a \
      style=\x22fil\
l:none;fill-rule\
:evenodd;stroke:\
#ff8080;stroke-w\
idth:15.57077312\
;stroke-linecap:\
round;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22\x0a       s\
odipodi:nodetype\
s=\x22cc\x22 />\x0a    <p\
ath\x0a       inksc\
ape:connector-cu\
rvature=\x220\x22\x0a    \
   id=\x22path812-3\
\x22\x0a       d=\x22M 13\
3.89064,61.51186\
6 60.79679,135.1\
0545\x22\x0a       sty\
le=\x22fill:none;fi\
ll-rule:evenodd;\
stroke:#ff8080;s\
troke-width:15.5\
7077312;stroke-l\
inecap:round;str\
oke-linejoin:mit\
er;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-opacity:1\x22\x0a \
      sodipodi:n\
odetypes=\x22cc\x22 />\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x08\xea\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22m\
ultiply.svg\x22\x0a   \
inkscape:version\
=\x220.92.3 (240554\
6, 2018-03-11)\x22>\
\x0a  <metadata\x0a   \
  id=\x22metadata8\x22\
>\x0a    <rdf:RDF>\x0a\
      <cc:Work\x0a \
        rdf:abou\
t=\x22\x22>\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0a        <dc:t\
ype\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0a        \
<dc:title />\x0a   \
   </cc:Work>\x0a  \
  </rdf:RDF>\x0a  <\
/metadata>\x0a  <de\
fs\x0a     id=\x22defs\
6\x22 />\x0a  <sodipod\
i:namedview\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#666666\x22\x0a\
     borderopaci\
ty=\x221\x22\x0a     obje\
cttolerance=\x2210\x22\
\x0a     gridtolera\
nce=\x2210\x22\x0a     gu\
idetolerance=\x2210\
\x22\x0a     inkscape:\
pageopacity=\x220\x22\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0a   \
  inkscape:windo\
w-width=\x221851\x22\x0a \
    inkscape:win\
dow-height=\x22998\x22\
\x0a     id=\x22namedv\
iew4\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
1.7383042\x22\x0a     \
inkscape:cx=\x22-74\
.178672\x22\x0a     in\
kscape:cy=\x22209.4\
4504\x22\x0a     inksc\
ape:window-x=\x2269\
\x22\x0a     inkscape:\
window-y=\x2227\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22g8\
31\x22 />\x0a  <g\x0a    \
 id=\x22g831\x22\x0a     \
style=\x22stroke:#b\
3b3b3;stroke-lin\
ecap:round\x22>\x0a   \
 <path\x0a       so\
dipodi:nodetypes\
=\x22cc\x22\x0a       ink\
scape:connector-\
curvature=\x220\x22\x0a  \
     id=\x22path812\
-3\x22\x0a       d=\x22M \
128.27157,122.07\
037 71.060637,66\
.445036\x22\x0a       \
style=\x22fill:none\
;fill-rule:eveno\
dd;stroke:#b3b3b\
3;stroke-width:1\
6;stroke-linecap\
:round;stroke-li\
nejoin:miter;str\
oke-miterlimit:4\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22 />\x0a    \
<path\x0a       sod\
ipodi:nodetypes=\
\x22cc\x22\x0a       inks\
cape:connector-c\
urvature=\x220\x22\x0a   \
    id=\x22path812-\
3-3\x22\x0a       d=\x22M\
 71.065141,122.0\
75 128.26707,66.\
440407\x22\x0a       s\
tyle=\x22fill:none;\
fill-rule:evenod\
d;stroke:#b3b3b3\
;stroke-width:16\
;stroke-linecap:\
round;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22 />\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x09i\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22t\
ransform.svg\x22\x0a  \
 inkscape:versio\
n=\x220.92.4 (5da68\
9c313, 2019-01-1\
4)\x22>\x0a  <metadata\
\x0a     id=\x22metada\
ta8\x22>\x0a    <rdf:R\
DF>\x0a      <cc:Wo\
rk\x0a         rdf:\
about=\x22\x22>\x0a      \
  <dc:format>ima\
ge/svg+xml</dc:f\
ormat>\x0a        <\
dc:type\x0a        \
   rdf:resource=\
\x22http://purl.org\
/dc/dcmitype/Sti\
llImage\x22 />\x0a    \
    <dc:title />\
\x0a      </cc:Work\
>\x0a    </rdf:RDF>\
\x0a  </metadata>\x0a \
 <defs\x0a     id=\x22\
defs6\x22 />\x0a  <sod\
ipodi:namedview\x0a\
     pagecolor=\x22\
#ffffff\x22\x0a     bo\
rdercolor=\x22#6666\
66\x22\x0a     bordero\
pacity=\x221\x22\x0a     \
objecttolerance=\
\x2210\x22\x0a     gridto\
lerance=\x2210\x22\x0a   \
  guidetolerance\
=\x2210\x22\x0a     inksc\
ape:pageopacity=\
\x220\x22\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0a     inkscape:w\
indow-width=\x22185\
8\x22\x0a     inkscape\
:window-height=\x22\
1057\x22\x0a     id=\x22n\
amedview4\x22\x0a     \
showgrid=\x22false\x22\
\x0a     inkscape:z\
oom=\x221.2291667\x22\x0a\
     inkscape:cx\
=\x22-299.28913\x22\x0a  \
   inkscape:cy=\x22\
290.26511\x22\x0a     \
inkscape:window-\
x=\x2254\x22\x0a     inks\
cape:window-y=\x22-\
8\x22\x0a     inkscape\
:window-maximize\
d=\x221\x22\x0a     inksc\
ape:current-laye\
r=\x22svg2\x22 />\x0a  <c\
ircle\x0a     style\
=\x22fill:none;fill\
-opacity:1;fill-\
rule:evenodd;str\
oke:#999999;stro\
ke-width:8.59070\
206;stroke-linec\
ap:round;stroke-\
linejoin:round;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
dashoffset:0;str\
oke-opacity:1\x22\x0a \
    id=\x22path4515\
\x22\x0a     cx=\x2296.55\
9441\x22\x0a     cy=\x229\
6.254112\x22\x0a     r\
=\x2265.134018\x22 />\x0a\
  <path\x0a     sty\
le=\x22fill:#999999\
;fill-opacity:1;\
stroke:none;stro\
ke-width:0.70588\
231px;stroke-lin\
ecap:round;strok\
e-linejoin:round\
;stroke-opacity:\
1\x22\x0a     d=\x22M 85.\
352775,11.154757\
 82.214223,52.38\
7421 122.49388,3\
4.105774 Z\x22\x0a    \
 id=\x22path4517\x22\x0a \
    inkscape:con\
nector-curvature\
=\x220\x22 />\x0a  <path\x0a\
     style=\x22fill\
:#999999;fill-op\
acity:1;stroke:n\
one;stroke-width\
:0.70588231px;st\
roke-linecap:rou\
nd;stroke-linejo\
in:round;stroke-\
opacity:1\x22\x0a     \
d=\x22m 113.89831,1\
40.41077 -0.5742\
8,41.34795 -38.4\
76572,-21.82253 \
z\x22\x0a     id=\x22path\
4517-3\x22\x0a     ink\
scape:connector-\
curvature=\x220\x22 />\
\x0a</svg>\x0a\
\x00\x00\x04\x97\
\x00\
\x00\x0f\x88x\xda\xd5W[o\xdb6\x14~\xcf\xaf\xe0\
\xd4\x97\x16\xb3(\xdet\xa1f\xbb\xc0Z\x14\xe8\xc3^\
\xb6\x0e{\xa6E:V+\x89\x06E\xc7I\x7f\xfd\x8e\
d]\xec\xc4\x19\x82u\x18Z\x06\x01rn<\xe7|\
\xe7#\xa9,\xdf\xde\xd7\x15\xba3\xae-m\xb3\x0a(\
&\x012Mau\xd9\xdc\xae\x82??}\x08\xb3\x00\
\xb5^5ZU\xb61\xab\xa0\xb1\xc1\xdb\xf5\xcd\xf2\xa7\
0D\xef\x9cQ\xdeht,\xfd\x0e}l\xbe\xb4\x85\
\xda\x1b\xf4z\xe7\xfd>\x8f\xa2\xe3\xf1\x88\xcbA\x89\xad\
\xbb\x8d\xde\xa00\x5c\xdf\xdc,\xdb\xbb\xdb\x1b\x84\x10\xe4\
m\xda\x5c\x17\xab`\x08\xd8\x1f\x5c\xd5;\xea\x222\x95\
\xa9M\xe3\xdb\x88b\x1a\x05\xb3{1\xbb\x17]\xf6\xf2\
\xce\x14\xb6\xaem\xd3\xf6\x91M\xfb\xea\xcc\xd9\xe9\xed\xe4\
\xddUs\xe4\xbd\x13\x95RF\x84E\x8c\x85\xe0\x11\xb6\
\x0f\x8dW\xf7\xe1e(\xd4x-\x94\x11B\x22\xb0\xcd\
\x9e/\xf3\xca[\x00t\x0f\xbf\x93\xfb\xa8\xc0\xad=\xb8\
\xc2l!\xce\xe0\xc6\xf8\xe8\xfd\xa7\xf7\x931$X{\
}\xb6\xcd\x88\xe7E\xd6\x0b\x90\x1bU\x9bv\xaf\x0a\xd3\
F\xa3\xbe\x8f?\x9b0\xed\x15\xa5^\x05P#\xeb\x85\
c\xa9\xfd\x0el\xf2$\xeeLy\xbb\xf3\xb3|W\x9a\
\xe3\xaf\xf6~\x15\x10D\x10(\xd1h\x18\x0b\xcd\xb5-\
\xba\xcc\xab@\x1d\xbc\x0d+H\x1d\xbaF\xe3\x11\x84\xb1\
\x94|*\x83`\xc90G\xaf\x99 q,\x92\x05b\
\x84f!\xe1!\xa5o\x825\xc4,k\xe3\x95V^\
u\xf1\xa7rGM\xd6;\x80\x0b\x8c/\xff\xfd\xfd\x87\
\x93\x04rQ\xe4\x7fY\xf7e\x10au\x0ejc\x0f\
\xd0K\xb0\x9e\xd4K]\xe4\x00x\xad\xfc\xba\xac\xd5\xad\
\xe9f\xf53\x00\xbc\x8cf\xc3\x85\xb3\x7f\xd8\x9by\xd3\
\xd3\xb6\xce\x9c&w\x95\xbe\xba\xa8\xcb.(\xfa\xc3\x97\
U\xf5\xb1K\x12\xa0\xe8\xd1\xa6\xa5\xaf\xcc\xba\xcfy\xfa\
s\xec\x22\x1a\xda\x18\x9a\x8c\xce\xba\x5cF#\x06\xbd\xa4\
\xcd\xb6\x9d\xe1\xe9\xa4dH\xb3\x9c&\xd3\x8dEw\x03\
<9\xee\xa1\x94\xc2V\xd6\xad\x82W\xdb~\x05'\xc3\
\xc6:m\xdchJ\xfaua\xb2\xc0*h\x0aX1\
\xa8\xed\xe6\xb3)\xbc\xb7\x95q\xaa\xe9\x80\xa0d\xb0\xdc\
:\xe0\xd35\xfd\xa1\xd4\xe6\x9aa\xe2GW\xde\x94\xe8\
\xaa\xb5\xdd)m\x8f\xab\x80=6\x1e\xcb\x06\x0c\xe1H\
\xe5,\xe1\xcfxL\xec&,\x0ef\xf8&\xa0\xc4\xa0\
lw\xf6\xd8u\xb2\x0a\xb6\xaaj\xcd\xe3\xdd\xbeZ[\
w\xc7\x891I\x93$}l.\xe0\xb8\x84\x22\xc5\xb2\
[\xd9\x13+\xb4'\x13L\xba\x95<S'l\x10\xa7\
\xcf\xd8 \x9c=g\xab\xd5}Y\x97_\x8d\x9eG5\
\xe7=8\x07\xf7jX\xa9\x07\xe3\x86\x0b``\x8c\x83\
a\x0e\x8d\xfb\x87\x0a\xa63\xcc!\xa7\xbfl\x81\xc4\xf9\
\xabD\xc8\xd8\xe8^\x08g[\xeb\x9d\xfdb\xf2\x81L\
\x83x\x9aBN0OS\x19\xb34\x1e\xf5p3\x18\
($w\xf6\xd0\xe8s\xe5g[6\xf9\xc6\xdc\x99j\
\xd4\xc2\x092\xae\x82N|.F\x9dV0~\xe7\xd4\
C\xde\xc0c4j\xe7b\xf6\xaa\x84\xe6z\xba\x82\x07\
\x1c\xe4\xeal\xc0]\x83\x19\x1dy3\xf0DpL\x81\
+bd\xc2H\x0eA\xb1\x904f#\x19`\x18\x1c\
\xb3X\xb0\x98\x8e\xae0\x83D`\x96B|\xfab\x10\
\x19\xd90\xa5~x\x10C\xfe\xafa\xa4\xe0\x1bK\xce\
\xf8\x0c\xa3\x8c{\x0dx\x0d0\xee\x95\xdf]\xc0\xd8\x83\
\xd7\x97\xdb#\xe7\x0e\x95\xc9\xa1\xcf\xc6j=\x81\x97\x91\
\xee\xe7\x12\xbc'\x98m\x0e\xde?\x81\xacG\xe9)\x10\
/\xc20^\xc4\xe7J\xbb\xdd\xb6\xc6\xe7\xe3\xd5\x05\x88\
\xfd\x86\x04\xb4\x97\xa4\x00\xc3\x22\x138I$\xcf\x12\xf4\
\x0ee\x09@\x96\x12!\x17\x92\xe0D\x0aB%Jc\
\x9cQ\xc9\xb9XP*0gi\x86\xa8\x10pM0\
\xceA\x95\x00\xdb$\xe5g\xe3\xe8\x80\xca\x98|r\xcc\
m\x03\xedz\xebB8\xf0w\xca\x1f\x9c\x99\xaf\xd3\xf9\
i\xb0p\x1b\xc3+\x05\x1f1E\xf1b\x06\x13\xb2\xe9\
8\xfa\xc338\xf9\x86\x8b \xa5Y,\xc9\xd9E\x00\
\x93\xc4I,b\xf9=0\xf8\xc5\x84}B\xf5\xeb\x0c\
\xae\x91\x80\xa7\x0a\xceg\x1c/(\xcf0\x81QJT\
 Ap\x0c\xd8\x00[\xc1\xccD\xc2\x11\x938\xcdR\
\x92\xcaE\xc8\x00%&\xa4D\x12\xde\xc0\x94\x904\x06\
\x1d\xc5i\xca\xa7\xef\x8a3\x02\x87\xe9\xffIaA\x13\
i\xe8\x8fO\xe1\xf8[)<\xa9:\x0a3\x9c\x92X\
p\xfe\xfdS\xf8*d\xd7\xf8*\x16\x1c0!<\xe1\
\xc9?\xf15\x93\x8b\xac\xfb\x90\x03^\x88\x89\xaf\xc9\x22\
\x83\xd8\x14\x22\xc4\x15\xbe\xf2\xff\x8a\xaf\xcb\xee\xbf\x8f\xf5\
\xcd\xdf\xf0\xb6\xbc\x10\
\x00\x00\x08\xe6\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22p\
lus.svg\x22\x0a   inks\
cape:version=\x220.\
92.4 (unknown)\x22>\
\x0a  <metadata\x0a   \
  id=\x22metadata8\x22\
>\x0a    <rdf:RDF>\x0a\
      <cc:Work\x0a \
        rdf:abou\
t=\x22\x22>\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0a        <dc:t\
ype\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0a        \
<dc:title />\x0a   \
   </cc:Work>\x0a  \
  </rdf:RDF>\x0a  <\
/metadata>\x0a  <de\
fs\x0a     id=\x22defs\
6\x22 />\x0a  <sodipod\
i:namedview\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#666666\x22\x0a\
     borderopaci\
ty=\x221\x22\x0a     obje\
cttolerance=\x2210\x22\
\x0a     gridtolera\
nce=\x2210\x22\x0a     gu\
idetolerance=\x2210\
\x22\x0a     inkscape:\
pageopacity=\x220\x22\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0a   \
  inkscape:windo\
w-width=\x221863\x22\x0a \
    inkscape:win\
dow-height=\x221025\
\x22\x0a     id=\x22named\
view4\x22\x0a     show\
grid=\x22false\x22\x0a   \
  inkscape:zoom=\
\x221.7383042\x22\x0a    \
 inkscape:cx=\x22-2\
13.83542\x22\x0a     i\
nkscape:cy=\x22209.\
44504\x22\x0a     inks\
cape:window-x=\x225\
7\x22\x0a     inkscape\
:window-y=\x2227\x22\x0a \
    inkscape:win\
dow-maximized=\x221\
\x22\x0a     inkscape:\
current-layer=\x22s\
vg2\x22 />\x0a  <g\x0a   \
  id=\x22g831\x22\x0a    \
 style=\x22stroke:#\
37c8ab;stroke-li\
necap:round;stro\
ke-opacity:1\x22>\x0a \
   <path\x0a       \
sodipodi:nodetyp\
es=\x22cc\x22\x0a       i\
nkscape:connecto\
r-curvature=\x220\x22\x0a\
       id=\x22path8\
12\x22\x0a       d=\x22m \
95.091973,56.172\
243 0.09447,79.7\
95097\x22\x0a       st\
yle=\x22fill:none;f\
ill-rule:evenodd\
;stroke:#37c8ab;\
stroke-width:16;\
stroke-linecap:r\
ound;stroke-line\
join:miter;strok\
e-miterlimit:4;s\
troke-dasharray:\
none;stroke-opac\
ity:1\x22 />\x0a    <p\
ath\x0a       sodip\
odi:nodetypes=\x22c\
c\x22\x0a       inksca\
pe:connector-cur\
vature=\x220\x22\x0a     \
  id=\x22path812-3\x22\
\x0a       d=\x22m 134\
.96147,95.594487\
 -79.795108,0.09\
45\x22\x0a       style\
=\x22fill:none;fill\
-rule:evenodd;st\
roke:#37c8ab;str\
oke-width:16;str\
oke-linecap:roun\
d;stroke-linejoi\
n:miter;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-opacity\
:1\x22 />\x0a  </g>\x0a</\
svg>\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x08\
\x0b\x85Wg\
\x00g\
\x00e\x00a\x00r\x00.\x00s\x00v\x00g\
\x00\x08\
\x03gT'\
\x00p\
\x00l\x00o\x00t\x00.\x00s\x00v\x00g\
\x00\x15\
\x01uN\xa7\
\x00l\
\x00i\x00n\x00k\x00-\x00t\x00o\x00-\x00s\x00e\x00l\x00e\x00c\x00t\x00i\x00o\x00n\
\x00.\x00s\x00v\x00g\
\x00\x0e\
\x01'M\x07\
\x00c\
\x00l\x00e\x00a\x00r\x00_\x00r\x00u\x00n\x00s\x00.\x00s\x00v\x00g\
\x00\x0d\
\x02.\xca\x07\
\x00c\
\x00o\x00p\x00y\x002\x00d\x00o\x00w\x00n\x00.\x00s\x00v\x00g\
\x00\x0d\
\x01\xdc\x10\xc7\
\x00a\
\x00u\x00t\x00o\x00-\x00l\x00i\x00n\x00k\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x13\
\x0f-z\xc7\
\x00i\
\x00m\x00p\x00o\x00r\x00t\x00_\x00p\x00r\x00o\x00f\x00i\x00l\x00e\x00s\x00.\x00s\
\x00v\x00g\
\x00\x08\
\x06|W\x87\
\x00c\
\x00o\x00p\x00y\x00.\x00s\x00v\x00g\
\x00\x0f\
\x01\xe7\xeaG\
\x00l\
\x00i\x00n\x00k\x00-\x00t\x00o\x00-\x00a\x00l\x00l\x00.\x00s\x00v\x00g\
\x00\x0b\
\x0aS\xdfG\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x003\x00.\x00s\x00v\x00g\
\x00\x0c\
\x09\xa4,\xc7\
\x00m\
\x00u\x00l\x00t\x00i\x00p\x00l\x00y\x00.\x00s\x00v\x00g\
\x00\x0d\
\x01\xa0\xe8\x87\
\x00t\
\x00r\x00a\x00n\x00s\x00f\x00o\x00r\x00m\x00.\x00s\x00v\x00g\
\x00\x11\
\x03D\xe2\xc7\
\x00a\
\x00u\x00t\x00o\x00-\x00l\x00i\x00n\x00k\x00-\x00r\x00n\x00d\x00.\x00s\x00v\x00g\
\
\x00\x08\
\x03\xc6T'\
\x00p\
\x00l\x00u\x00s\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x0f\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00|\x00\x00\x00\x00\x00\x01\x00\x00\x1b\xee\
\x00\x00\x01\x96JM\xa6\xe9\
\x00\x00\x00L\x00\x01\x00\x00\x00\x01\x00\x00\x17M\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x01\x98\x00\x00\x00\x00\x00\x01\x00\x00m^\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00\xbe\x00\x00\x00\x00\x00\x01\x00\x000\x9a\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x01:\x00\x01\x00\x00\x00\x01\x00\x00V\xc1\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00\x9e\x00\x00\x00\x00\x00\x01\x00\x00%\x83\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x01\xb8\x00\x01\x00\x00\x00\x01\x00\x00v\xcb\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x006\x00\x00\x00\x00\x00\x01\x00\x00\x07v\
\x00\x00\x01\x96JM\xa6\xe9\
\x00\x00\x01\xe0\x00\x00\x00\x00\x00\x01\x00\x00{f\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x01$\x00\x00\x00\x00\x00\x01\x00\x00M\xd5\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x01z\x00\x00\x00\x00\x00\x01\x00\x00dp\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x01^\x00\x00\x00\x00\x00\x01\x00\x00[\x5c\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00\xde\x00\x00\x00\x00\x00\x01\x00\x00:\x93\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00\xf8\x00\x00\x00\x00\x00\x01\x00\x00B\xe2\
\x00\x00\x01\x88\xae\xf9[-\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
