# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.7.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x18\x0e\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   width=\x22\
512\x22\x0a   height=\x22\
512\x22\x0a   viewBox=\
\x220 0 512 512\x22\x0a  \
 id=\x22svg2\x22\x0a   ve\
rsion=\x221.1\x22\x0a   i\
nkscape:version=\
\x221.2.2 (b0a84865\
41, 2022-12-01)\x22\
\x0a   sodipodi:doc\
name=\x22VeraGrid_i\
con.svg\x22\x0a   inks\
cape:export-file\
name=\x22VeraGrid_i\
con.png\x22\x0a   inks\
cape:export-xdpi\
=\x2290\x22\x0a   inkscap\
e:export-ydpi=\x229\
0\x22\x0a   xmlns:inks\
cape=\x22http://www\
.inkscape.org/na\
mespaces/inkscap\
e\x22\x0a   xmlns:sodi\
podi=\x22http://sod\
ipodi.sourceforg\
e.net/DTD/sodipo\
di-0.dtd\x22\x0a   xml\
ns:xlink=\x22http:/\
/www.w3.org/1999\
/xlink\x22\x0a   xmlns\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:svg=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0a   xmlns:cc=\x22\
http://creativec\
ommons.org/ns#\x22\x0a\
   xmlns:dc=\x22htt\
p://purl.org/dc/\
elements/1.1/\x22>\x0a\
  <defs\x0a     id=\
\x22defs4\x22>\x0a    <li\
nearGradient\x0a   \
    inkscape:col\
lect=\x22always\x22\x0a  \
     id=\x22linearG\
radient3999\x22>\x0a  \
    <stop\x0a      \
   style=\x22stop-c\
olor:#3ecb73;sto\
p-opacity:1;\x22\x0a  \
       offset=\x220\
\x22\x0a         id=\x22s\
top3995\x22 />\x0a    \
  <stop\x0a        \
 style=\x22stop-col\
or:#2fbbe2;stop-\
opacity:1;\x22\x0a    \
     offset=\x221\x22\x0a\
         id=\x22sto\
p3997\x22 />\x0a    </\
linearGradient>\x0a\
    <linearGradi\
ent\x0a       inksc\
ape:collect=\x22alw\
ays\x22\x0a       xlin\
k:href=\x22#linearG\
radient3999\x22\x0a   \
    id=\x22linearGr\
adient4001\x22\x0a    \
   x1=\x2211.690481\
\x22\x0a       y1=\x22987\
.94413\x22\x0a       x\
2=\x22118.0807\x22\x0a   \
    y2=\x22987.9441\
3\x22\x0a       gradie\
ntUnits=\x22userSpa\
ceOnUse\x22 />\x0a  </\
defs>\x0a  <sodipod\
i:namedview\x0a    \
 id=\x22base\x22\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#666666\x22\x0a \
    borderopacit\
y=\x221.0\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pageshadow\
=\x222\x22\x0a     inksca\
pe:zoom=\x220.39774\
756\x22\x0a     inksca\
pe:cx=\x22-422.3784\
6\x22\x0a     inkscape\
:cy=\x2265.368094\x22\x0a\
     inkscape:do\
cument-units=\x22px\
\x22\x0a     inkscape:\
current-layer=\x22g\
4541\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 units=\x22px\x22\x0a    \
 inkscape:window\
-width=\x222509\x22\x0a  \
   inkscape:wind\
ow-height=\x221012\x22\
\x0a     inkscape:w\
indow-x=\x220\x22\x0a    \
 inkscape:window\
-y=\x220\x22\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0a     i\
nkscape:showpage\
shadow=\x222\x22\x0a     \
inkscape:pageche\
ckerboard=\x220\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22 \
/>\x0a  <metadata\x0a \
    id=\x22metadata\
7\x22>\x0a    <rdf:RDF\
>\x0a      <cc:Work\
\x0a         rdf:ab\
out=\x22\x22>\x0a        \
<dc:format>image\
/svg+xml</dc:for\
mat>\x0a        <dc\
:type\x0a          \
 rdf:resource=\x22h\
ttp://purl.org/d\
c/dcmitype/Still\
Image\x22 />\x0a      \
  <dc:title />\x0a \
     </cc:Work>\x0a\
    </rdf:RDF>\x0a \
 </metadata>\x0a  <\
g\x0a     inkscape:\
label=\x22Capa 1\x22\x0a \
    inkscape:gro\
upmode=\x22layer\x22\x0a \
    id=\x22layer1\x22\x0a\
     transform=\x22\
translate(0,-540\
.36216)\x22>\x0a    <g\
\x0a       id=\x22g863\
\x22\x0a       transfo\
rm=\x22matrix(4.091\
2642,0,0,4.09126\
42,-733.50723,-3\
116.5242)\x22\x0a     \
  style=\x22fill:#0\
66b75;stroke:#00\
5544;fill-opacit\
y:1\x22>\x0a      <g\x0a \
        id=\x22g454\
1\x22\x0a         tran\
sform=\x22translate\
(177.72284,-30.8\
51643)\x22\x0a        \
 style=\x22fill:#06\
6b75;fill-opacit\
y:1\x22>\x0a        <r\
ect\x0a           s\
tyle=\x22opacity:1;\
fill:url(#linear\
Gradient4001);fi\
ll-opacity:1;str\
oke:#ffffff;stro\
ke-width:3.42260\
671;stroke-linec\
ap:round;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne;stroke-opacit\
y:1\x22\x0a           \
id=\x22rect4862-9\x22\x0a\
           width\
=\x22102.96761\x22\x0a   \
        height=\x22\
102.96761\x22\x0a     \
      x=\x2213.4017\
84\x22\x0a           y\
=\x22936.46033\x22\x0a   \
        ry=\x2214.8\
91859\x22 />\x0a      \
  <path\x0a        \
   style=\x22fill:n\
one;fill-rule:ev\
enodd;stroke:#20\
5a70;stroke-widt\
h:2.55670834;str\
oke-linecap:roun\
d;stroke-linejoi\
n:miter;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-opacity\
:1;fill-opacity:\
1\x22\x0a           d=\
\x22m 13.799443,100\
6.1765 c 0,0 2.1\
90698,-46.77138 \
6.176144,-46.840\
38 4.125325,-0.0\
715 3.318087,55.\
85258 7.698377,5\
5.86228 3.245415\
,0.01 3.640897,-\
44.25398 7.14344\
1,-44.37053 2.46\
6569,-0.082 4.00\
8643,35.96363 7.\
308336,35.89873 \
2.319133,-0.046 \
4.554836,-28.554\
76 8.039476,-28.\
5991 2.501206,-0\
.0318 4.328651,2\
5.8757 7.501062,\
25.798 2.663764,\
-0.066 5.477277,\
-21.28662 8.1407\
98,-21.1928 2.31\
5079,0.0815 3.39\
4469,17.05166 6.\
247406,17.07392 \
2.183064,0.017 4\
.355591,-13.58 7\
.092777,-13.6579\
2 1.976158,-0.05\
65 2.727108,9.48\
279 4.812952,9.4\
304 1.46143,-0.0\
363 2.72769,-6.0\
4859 4.914286,-5\
.96179 1.540797,\
0.0613 2.53687,2\
.35577 4.053016,\
2.38478 1.977175\
,0.0383 3.900719\
,-0.78826 5.8768\
56,-0.86723 2.16\
432,-0.0862 4.32\
006,0.36128 6.48\
483,0.43356 1.75\
544,0.0584 5.268\
91,0 5.26891,0 l\
 5.72489,-0.0546\
\x22\x0a           id=\
\x22path4166-1\x22\x0a   \
        inkscape\
:connector-curva\
ture=\x220\x22\x0a       \
    sodipodi:nod\
etypes=\x22csssssss\
sssssaacc\x22 />\x0a  \
      <rect\x0a    \
       style=\x22fi\
ll:none;fill-opa\
city:1;stroke:#0\
66b75;stroke-wid\
th:3.42261;strok\
e-linecap:round;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22\x0a    \
       id=\x22rect4\
862-9-7\x22\x0a       \
    width=\x22102.9\
6761\x22\x0a          \
 height=\x22102.967\
61\x22\x0a           x\
=\x2213.401781\x22\x0a   \
        y=\x22936.4\
6033\x22\x0a          \
 ry=\x2214.891859\x22\x0a\
           rx=\x221\
4.891859\x22 />\x0a   \
   </g>\x0a    </g>\
\x0a    <rect\x0a     \
  style=\x22opacity\
:1;fill:#00aa88;\
fill-opacity:1;s\
troke:none;strok\
e-width:4;stroke\
-linecap:square;\
stroke-linejoin:\
bevel;stroke-mit\
erlimit:4;stroke\
-dasharray:none;\
stroke-dashoffse\
t:0;stroke-opaci\
ty:1;paint-order\
:stroke fill mar\
kers\x22\x0a       id=\
\x22rect865\x22\x0a      \
 width=\x2277.33803\
6\x22\x0a       height\
=\x2275.404579\x22\x0a   \
    x=\x22-562.6342\
2\x22\x0a       y=\x22306\
.05014\x22 />\x0a    <\
rect\x0a       styl\
e=\x22opacity:1;fil\
l:#165044;fill-o\
pacity:1;stroke:\
none;stroke-widt\
h:2.61818194;str\
oke-linecap:squa\
re;stroke-linejo\
in:bevel;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne;stroke-dashof\
fset:0;stroke-op\
acity:1;paint-or\
der:stroke fill \
markers\x22\x0a       \
id=\x22rect867\x22\x0a   \
    width=\x2270.86\
9766\x22\x0a       hei\
ght=\x2269.604233\x22\x0a\
       x=\x22-518.1\
6486\x22\x0a       y=\x22\
342.78571\x22 />\x0a  \
  <rect\x0a       s\
tyle=\x22opacity:1;\
fill:#00203f;fil\
l-opacity:0.9411\
7647;stroke:none\
;stroke-width:4;\
stroke-linecap:s\
quare;stroke-lin\
ejoin:bevel;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-das\
hoffset:0;stroke\
-opacity:1;paint\
-order:stroke fi\
ll markers\x22\x0a    \
   id=\x22rect865-6\
\x22\x0a       width=\x22\
77.338036\x22\x0a     \
  height=\x2275.404\
579\x22\x0a       x=\x22-\
569.66956\x22\x0a     \
  y=\x22460.5256\x22 /\
>\x0a    <rect\x0a    \
   style=\x22opacit\
y:1;fill:#adefd1\
;fill-opacity:0.\
94117647;stroke:\
none;stroke-widt\
h:2.61818194;str\
oke-linecap:squa\
re;stroke-linejo\
in:bevel;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne;stroke-dashof\
fset:0;stroke-op\
acity:1;paint-or\
der:stroke fill \
markers\x22\x0a       \
id=\x22rect867-7\x22\x0a \
      width=\x2270.\
869766\x22\x0a       h\
eight=\x2269.604233\
\x22\x0a       x=\x22-525\
.2002\x22\x0a       y=\
\x22497.26114\x22 />\x0a \
 </g>\x0a</svg>\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x11\
\x06M0G\
\x00V\
\x00e\x00r\x00a\x00G\x00r\x00i\x00d\x00_\x00i\x00c\x00o\x00n\x00.\x00s\x00v\x00g\
\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x01\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x98\xed\x01#\x84\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
