"""mrack library version."""

VERSION = "1.23.5"
