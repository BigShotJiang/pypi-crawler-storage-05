# rubin-nublado-client

rubin-nublado-client is a client for JupyterHub/JupyterLab within the
Rubin Science Platform (RSP).


