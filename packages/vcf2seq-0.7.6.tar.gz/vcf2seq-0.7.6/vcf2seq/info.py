

APPNAME   = "vcf2seq"
SHORTDESC = "Inputing a VCF file, it returns the genomic sequence at the specified length (31 by default)."
LICENCE   = "GPL3"
VERSION   = "0.7.6"
AUTHOR    = "Benoit Guibert"
AUTHOR_EMAIL = "benoit.guibert@free.fr"
