2025-08-21 Version: 3.1.0
- Support API GetEmonAlarmRecordStatisticsDistribute.


2025-06-12 Version: 3.0.3
- Update API InstallUserPlugins: add request parameters force.
- Update API ListInstance: add request parameters status.
- Update API UpdateInstanceSettings: add request parameters force.


2025-05-14 Version: 3.0.2
- Generated python 2017-06-13 for elasticsearch.

2025-05-13 Version: 3.0.1
- Update API DescribeInstance: add response parameters Body.Result.endTime.


2025-04-27 Version: 3.0.0
- Update API ListActionRecords: add response parameters Body.Result.$.actionName.
- Update API ListActionRecords: add response parameters Body.Result.$.actionParams.
- Update API ListActionRecords: add response parameters Body.Result.$.actionResultAccessList.
- Update API ListActionRecords: add response parameters Body.Result.$.endTime.
- Update API ListActionRecords: add response parameters Body.Result.$.instanceId.
- Update API ListActionRecords: add response parameters Body.Result.$.metaNow.
- Update API ListActionRecords: add response parameters Body.Result.$.metaOld.
- Update API ListActionRecords: add response parameters Body.Result.$.ownerId.
- Update API ListActionRecords: add response parameters Body.Result.$.process.
- Update API ListActionRecords: add response parameters Body.Result.$.recordDiff.
- Update API ListActionRecords: add response parameters Body.Result.$.recordIds.
- Update API ListActionRecords: add response parameters Body.Result.$.requestId.
- Update API ListActionRecords: add response parameters Body.Result.$.startTime.
- Update API ListActionRecords: add response parameters Body.Result.$.stateType.
- Update API ListActionRecords: add response parameters Body.Result.$.statusInfo.
- Update API ListActionRecords: add response parameters Body.Result.$.userId.
- Update API ListActionRecords: add response parameters Body.Result.$.userInfo.
- Update API ListActionRecords: add response parameters Body.Result.$.userType.
- Update API ListActionRecords: delete response parameters Body.Result.$.ActionName.
- Update API ListActionRecords: delete response parameters Body.Result.$.ActionParams.
- Update API ListActionRecords: delete response parameters Body.Result.$.ActionResultAccessList.
- Update API ListActionRecords: delete response parameters Body.Result.$.EndTime.
- Update API ListActionRecords: delete response parameters Body.Result.$.InstanceId.
- Update API ListActionRecords: delete response parameters Body.Result.$.MetaNow.
- Update API ListActionRecords: delete response parameters Body.Result.$.MetaOld.
- Update API ListActionRecords: delete response parameters Body.Result.$.OwnerId.
- Update API ListActionRecords: delete response parameters Body.Result.$.Process.
- Update API ListActionRecords: delete response parameters Body.Result.$.RecordDiff.
- Update API ListActionRecords: delete response parameters Body.Result.$.RecordIds.
- Update API ListActionRecords: delete response parameters Body.Result.$.RequestId.
- Update API ListActionRecords: delete response parameters Body.Result.$.StartTime.
- Update API ListActionRecords: delete response parameters Body.Result.$.StateType.
- Update API ListActionRecords: delete response parameters Body.Result.$.StatusInfo.
- Update API ListActionRecords: delete response parameters Body.Result.$.UserId.
- Update API ListActionRecords: delete response parameters Body.Result.$.UserInfo.
- Update API ListActionRecords: delete response parameters Body.Result.$.UserType.
- Update API ListInstance: add response parameters Body.Result.$.port.
- Update API ListInstance: add response parameters Body.Result.$.protocol.
- Update API UpdateInstanceSettings: add request parameters updateStrategy.


2025-01-02 Version: 2.0.11
- Update API UpgradeEngineVersion: add param updateStrategy.


2024-12-10 Version: 2.0.10
- Update API ListInstance: update response param.


2024-12-06 Version: 2.0.9
- Update API GetRegionConfiguration: update response param.


2024-11-21 Version: 2.0.8
- Update API GetRegionalInstanceConfig: update response param.
- Update API UpgradeEngineVersion: update param body.


2024-09-10 Version: 2.0.7
- Update API DescribeInstance: update response param.


2024-08-07 Version: 2.0.6
- Update API UpdatePipelineManagementConfig: update param body.


2024-07-31 Version: 2.0.5
- Update API UpgradeEngineVersion: update param body.


2024-07-22 Version: 2.0.4
- Update API CreateSnapshot: update param InstanceId.
- Update API CreateSnapshot: update param ClientToken.
- Update API UpdateLogstash: update param body.
- Update API UpdatePipelineManagementConfig: update param body.


2024-06-04 Version: 2.0.3
- Update API ListInstance: update response param.


2024-06-03 Version: 2.0.2
- Update API DescribeInstance: update response param.


2024-05-10 Version: 2.0.1
- Update API DescribeInstance: update response param.
- Update API ListInstance: update response param.


2024-04-23 Version: 2.0.0
- Support API DisableKibanaPvlNetwork.
- Support API EnableKibanaPvlNetwork.
- Support API GetRegionalInstanceConfig.
- Support API ListKibanaPvlNetwork.
- Support API UpdateKibanaPvlNetwork.
- Delete API CreateDataTasks.


2024-03-07 Version: 1.4.0
- Support API DisableKibanaPvlNetwork.
- Support API EnableKibanaPvlNetwork.
- Support API GetRegionalInstanceConfig.
- Support API ListKibanaPvlNetwork.
- Support API UpdateKibanaPvlNetwork.


2024-02-21 Version: 1.3.0
- Support API GetRegionalInstanceConfig.


2023-11-28 Version: 1.2.0
- Generated python 2017-06-13 for elasticsearch.

2023-03-06 Version: 1.1.5
- Improve API parameters.

2022-12-28 Version: 1.1.4
- Improve API parameters for API`DeleteDeprecatedTemplate` `CreateIndexTemplate` `CreateCollector`.

2022-12-16 Version: 1.1.3
- Additional API parameters.

2022-10-19 Version: 1.1.2
- Complete Request Body.

2022-09-27 Version: 1.1.1
- Supported next-api-aliyun-com.

2022-06-11 Version: 1.1.0
- Supported next-api-aliyun-com.

2022-03-25 Version: 1.0.15
- ModifyWhiteIpsInfo add param.

2022-01-21 Version: 1.0.14
- ShrinkNode and TransferNode add request body.

2022-01-18 Version: 1.0.13
- ModifyWhiteIps reqeust body.

2021-12-28 Version: 1.0.12
- Add UpdateComponentIndex.
- Add DescribeDeprecatedTemplate.
- Add CreateComponentIndex.
- Add DeleteComponentIndex.
- Add ListDeprecatedTemplates.
- Add DescribeComponentIndex.
- Add ListComponentIndices.

2021-11-26 Version: 1.0.11
- CreateVpcEndpoint change body format.
- UpdateBlackIps Offline.
- UpdateDescription format string.
- UpdateWhiteIps complete reqeustBody.

2021-11-17 Version: 1.0.10
-  Update apm interface parameter.

2021-11-16 Version: 1.0.9
-  Update apm interface parameter.

2021-11-16 Version: 1.0.8
-  Update apm interface parameter.

2021-11-16 Version: 1.0.7
-  Update apm interface parameter.

2021-11-11 Version: 1.0.6
-  Support elasticsearch apm interface.

2021-10-15 Version: 1.0.5
- AMP version.

2021-10-14 Version: 1.0.4
- UpdateDescription fix body format.

2021-10-08 Version: 1.0.3
- Fix CapacityPlan.

2021-10-08 Version: 1.0.2
- Add API CapacityPlan.

2021-09-16 Version: 1.0.1
- Support Openstore.

2021-09-09 Version: 1.0.0
- Elasticsearch OpenAPI Support TeaDSL.

