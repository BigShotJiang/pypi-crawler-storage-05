from typing import Literal


SECURITY_RISK_DESC = "The LLM's assessment of the safety risk of this action."
SECURITY_RISK_LITERAL = Literal["LOW", "MEDIUM", "HIGH", "UNKNOWN"]
