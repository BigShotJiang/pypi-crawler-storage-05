class LLMContextManager:
    """Context manager for messages we send to LLM."""

    def __init__(self) -> None:
        pass
