# Kanged from rgpycrumbs
def getstrform(pathobj):
    return str(pathobj.absolute())
