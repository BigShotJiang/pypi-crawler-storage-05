import pytest


@pytest.mark.django_db
class TestSpecificTasks:
    pass
