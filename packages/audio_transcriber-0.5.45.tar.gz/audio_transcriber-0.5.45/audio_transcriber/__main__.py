#!/usr/bin/python
# coding: utf-8
from audio_transcriber.audio_transcriber_mcp import main

if __name__ == "__main__":
    main()
