class MissingEntityConfigException(Exception):
    pass
