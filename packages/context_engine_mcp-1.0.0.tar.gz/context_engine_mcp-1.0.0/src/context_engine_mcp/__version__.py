"""Version information for context-engine-mcp."""

__version__ = "1.0.0"