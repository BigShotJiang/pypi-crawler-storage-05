"""
    Allow victron_ble2mqtt to be executable
    through `python -m victron_ble2mqtt`.
"""

from victron_ble2mqtt.cli_app import main


if __name__ == '__main__':
    main()
