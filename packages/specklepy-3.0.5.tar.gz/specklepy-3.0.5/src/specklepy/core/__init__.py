"""
This is the Core SDK module of `specklepy`.

This module should be kept in sync with the functionalities of our other SDKs especially
C# Core https://github.com/specklesystems/speckle-sharp/tree/main/Core/Core
"""
