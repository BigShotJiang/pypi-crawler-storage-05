"""Main module for the twill package."""

from . import shell

if __name__ == "__main__":
    shell.main()
