These are unit tests that can be executed using 'pytest',

      https://docs.pytest.org/

You can either run the whole test suite at once or run the test_*.py scripts
individually using pytest.  The server will only be started when necessary.
