"""just something to give visible buildbot differences - ignore me"""


def test():
    return
