"""
Test suite for MCP KQL Server

Author: Arjun Trivedi
Email: arjuntrivedi42@yahoo.com
"""
