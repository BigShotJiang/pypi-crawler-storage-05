/* This file is intentionally empty.
 * The CSS import is handled via the styleModule in package.json
 */