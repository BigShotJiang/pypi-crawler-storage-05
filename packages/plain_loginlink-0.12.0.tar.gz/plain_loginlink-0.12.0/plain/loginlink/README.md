# plain.loginlink

**Link-based authentication for Plain.**

- [Installation](#installation)

## Installation

Install the `plain.loginlink` package from [PyPI](https://pypi.org/project/plain.loginlink/):

```bash
uv add plain.loginlink
```
