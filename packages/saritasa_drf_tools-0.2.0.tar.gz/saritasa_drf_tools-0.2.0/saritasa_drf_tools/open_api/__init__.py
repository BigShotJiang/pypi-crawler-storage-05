from .extend_schema import ApiViewFix, fix_api_view_warning
from .serializers import DetailSerializer, OpenApiSerializer
