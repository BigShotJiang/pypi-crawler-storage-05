from setuptools import setup, find_packages

setup(
    name='mytestlib-1',
    version='1.0.0',
    url='https://pypi.org/manage/projects/',
    author='Yosuke Saka',
    author_email='yosuke.saka3416@gmail.com',
    description='My Test Library.',
    packages=find_packages()
)
