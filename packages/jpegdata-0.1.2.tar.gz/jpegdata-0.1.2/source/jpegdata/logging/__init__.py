import logging

logger = logging.getLogger("jpegdata")
