from pypcaptools.TrafficInfo.FlowInfo import FlowInfo
from pypcaptools.TrafficInfo.TraceInfo import TraceInfo
