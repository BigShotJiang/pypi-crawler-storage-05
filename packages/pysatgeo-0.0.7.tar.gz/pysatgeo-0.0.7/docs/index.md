# Welcome to pysatgeo


[![image](https://img.shields.io/pypi/v/pysatgeo.svg)](https://pypi.python.org/pypi/pysatgeo)


**Python package for satellite processing functions for raster and also vector**


-   Free software: MIT License
-   Documentation: <https://JPPereira93.github.io/pysatgeo>
    

## Features

-   TODO
