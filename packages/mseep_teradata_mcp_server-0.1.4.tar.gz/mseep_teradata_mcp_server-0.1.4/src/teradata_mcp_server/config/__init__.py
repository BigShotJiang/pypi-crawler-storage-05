"""Package configuration module for teradata-mcp-server.

This module contains packaged configuration files and default settings.
"""