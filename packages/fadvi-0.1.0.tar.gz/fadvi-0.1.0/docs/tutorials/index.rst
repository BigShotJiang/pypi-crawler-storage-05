Tutorials
=============================================

Learn how to use FADVI with these step-by-step tutorials.

.. toctree::
   :maxdepth: 1
   
   quickstart
   basic_usage
   advanced_usage
   spatial_and_single_cell

