Model Implementation
===================

.. automodule:: fadvi._fadvae
   :members:
   :undoc-members:
   :show-inheritance:

FADVAE Class
------------

.. autoclass:: fadvi._fadvae.FADVAE
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
