from dataclasses import dataclass


@dataclass
class Location:
    center_x: float
    center_y: float
    geom: str
