from .examples import hello_main

if __name__ == "__main__":
    hello_main()

