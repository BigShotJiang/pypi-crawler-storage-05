# @omlish-lite


GIT_DIFF_OMIT_MAGIC = '@omlish-git-diff-omit'
GIT_DIFF_OMIT_MAGIC_COMMENT = f'# {GIT_DIFF_OMIT_MAGIC}'
