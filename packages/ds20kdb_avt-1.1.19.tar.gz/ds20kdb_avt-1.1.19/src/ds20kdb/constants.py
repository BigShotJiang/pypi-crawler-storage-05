"""
Project constants.
"""

# retain the trailing slash, otherwise 'api' will be stripped off by
# urllib.parse.urljoin
BASE_URL = 'https://ds20kdbi.cloud.cnaf.infn.it/preprod/api/'

# vTile repair testing
TABLE_VTILE = 'vtile'
