# Search

Types:

```python
from perplexity.types import SearchCreateResponse
```

Methods:

- <code title="post /search">client.search.<a href="./src/perplexity/resources/search.py">create</a>(\*\*<a href="src/perplexity/types/search_create_params.py">params</a>) -> <a href="./src/perplexity/types/search_create_response.py">SearchCreateResponse</a></code>

# Content

Types:

```python
from perplexity.types import ContentCreateResponse
```

Methods:

- <code title="post /content">client.content.<a href="./src/perplexity/resources/content.py">create</a>(\*\*<a href="src/perplexity/types/content_create_params.py">params</a>) -> <a href="./src/perplexity/types/content_create_response.py">ContentCreateResponse</a></code>
