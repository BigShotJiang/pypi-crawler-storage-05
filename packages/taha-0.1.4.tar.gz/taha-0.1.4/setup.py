from setuptools import setup

setup(
    name='taha',
    version='0.1.4',
    py_modules=['taha'],
    author='T_programmer',
    description='It is a library for you',
    python_requires='>=3.6',
)
