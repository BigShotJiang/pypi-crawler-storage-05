from lumiere import app


def main():
    app.run(debug=True)  # pyright: ignore[reportUnknownMemberType]


if __name__ == "__main__":
    main()
