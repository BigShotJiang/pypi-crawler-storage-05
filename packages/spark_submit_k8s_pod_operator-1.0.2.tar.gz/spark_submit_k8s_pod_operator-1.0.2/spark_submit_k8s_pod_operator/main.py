def hello():
    print("This is a test Proof of Concept. Command line execution confirmed.")
