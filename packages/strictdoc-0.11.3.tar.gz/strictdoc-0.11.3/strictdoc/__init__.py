from strictdoc.core.environment import SDocRuntimeEnvironment

__version__ = "0.11.3"


environment = SDocRuntimeEnvironment(__file__)
