from abc import ABC

from spakky.core.error import AbstractSpakkyCoreError


class AbstractSpakkyInfrastructureError(AbstractSpakkyCoreError, ABC): ...
