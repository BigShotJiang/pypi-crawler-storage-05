from ninja import NinjaAPI


class IndustryApiEndpoints:

    tags = ["Industry"]

    def __init__(self, api: NinjaAPI):
        pass
