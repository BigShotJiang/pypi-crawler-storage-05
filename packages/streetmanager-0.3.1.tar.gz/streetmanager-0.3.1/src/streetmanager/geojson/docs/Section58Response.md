# Section58Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**FeatureCollectionType**](FeatureCollectionType.md) |  | 
**features** | [**list[Section58Feature]**](Section58Feature.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

