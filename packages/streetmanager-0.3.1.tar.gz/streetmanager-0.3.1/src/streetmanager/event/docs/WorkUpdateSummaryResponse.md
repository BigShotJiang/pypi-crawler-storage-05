# WorkUpdateSummaryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**work_reference_number** | **str** |  | 
**update_date_time** | **datetime** |  | 
**update_id** | **float** |  | 
**event_type** | [**AuditEventType**](AuditEventType.md) |  | 
**event_type_string** | **str** |  | 
**object_type** | [**AuditObjectTypeResponse**](AuditObjectTypeResponse.md) |  | 
**object_type_string** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

