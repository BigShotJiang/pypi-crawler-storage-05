# PermitSearchReportingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rows** | [**list[PermitSummaryResponse]**](PermitSummaryResponse.md) |  | 
**next_cursor** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

