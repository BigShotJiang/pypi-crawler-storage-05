# StreetsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**coordinates** | [**list[Coordinates]**](Coordinates.md) | Minimum size of 1 Maximum size of 10 Each element must be unique | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

