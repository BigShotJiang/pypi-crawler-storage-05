# PrimaryNoticeAuthority

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**swa_code** | **str** |  | 
**name** | **str** |  | 
**location_description** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

