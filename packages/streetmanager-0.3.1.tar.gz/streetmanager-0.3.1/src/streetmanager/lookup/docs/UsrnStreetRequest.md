# UsrnStreetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**usrns** | **list[float]** | Minimum size of 1 Maximum size of 25 Each element must be a minimum value of 100001 and a maximum value of 99999999 Each element must be unique Each element must be a whole number | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

