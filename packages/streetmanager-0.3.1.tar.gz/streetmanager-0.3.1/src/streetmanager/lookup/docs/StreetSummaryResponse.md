# StreetSummaryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**street_descriptor** | **str** |  | 
**area** | **str** |  | 
**town** | **str** |  | 
**usrn** | **float** |  | 
**administrative_area** | **str** |  | 
**street_centre_point** | [**GeoJSONCentrePoint**](GeoJSONCentrePoint.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

