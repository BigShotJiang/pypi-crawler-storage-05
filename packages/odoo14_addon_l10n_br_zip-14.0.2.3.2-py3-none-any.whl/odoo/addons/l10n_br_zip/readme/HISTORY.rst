14.0.2.0.0 (2023-09-28)
~~~~~~~~~~~~~~~~~~~~~~~

  * Biblioteca PyCEP-Correios foi renomeada para BrazilCEP.

14.0.1.0.0 (2022-10-25)
~~~~~~~~~~~~~~~~~~~~~~~

  * Migração para 14.0

12.0.2.0.0 (2019-06-17)
~~~~~~~~~~~~~~~~~~~~~~~

 * [REF] Incluida pesquisa e dependência da biblioteca PyCEP-Correios.

12.0.3.0.0 (2021-01-08)
~~~~~~~~~~~~~~~~~~~~~~~

  * Atualizada a biblioteca pycep-correios para a versão 5.0.0
  * [ADD] Adicionado a opção para selecionar o provedor do serviço de busca de CEP.
