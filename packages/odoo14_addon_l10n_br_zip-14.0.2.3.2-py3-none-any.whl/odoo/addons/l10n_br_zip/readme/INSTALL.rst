Este módulo depende do l10n_br_base e da biblioteca BrazilCEP ( https://github.com/mstuttgart/brazilcep  ).
