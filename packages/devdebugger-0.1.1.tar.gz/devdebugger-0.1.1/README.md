# my-library

A small debugging and profiling helper library for Python developers.

## Install

```bash
pip install DevDebugger
```

> The project is a work in progress.
> I am currently working on the documentation.