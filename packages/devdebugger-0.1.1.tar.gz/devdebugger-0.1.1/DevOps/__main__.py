if __name__ == "__main__":
    print("DevOps: Import this you dumb fuck")