"""Unit test package for index_calculator."""
