.. highlight:: shell

===========
New project
===========

For adding your own project you need to change three files.


.. code-block:: console

    $ cd index_calculator/tables
    $ cf_conversion.json
    $ projects.json
    $ xcalc.json


The easiest way is to copy an exsiting project like e.g. EOBS and edit it according to your needs.
