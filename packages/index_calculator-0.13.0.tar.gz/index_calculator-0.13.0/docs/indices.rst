.. currentmodule:: index_calculator


""""""""""""""""""""""""""
List of climate indicators
""""""""""""""""""""""""""

.. autosummary::
   :toctree: generated/

   _indices
