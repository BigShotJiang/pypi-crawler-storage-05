=====
Usage
=====

To use index_calculator in a project::

    import index_calculator
