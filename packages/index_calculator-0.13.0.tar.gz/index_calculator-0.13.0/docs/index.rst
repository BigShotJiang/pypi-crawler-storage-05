Welcome to index_calculator's documentation!
============================================

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Contents:

   readme
   installation
   usage
   notebooks
   indices
   newproject
   newindex
   contributing
   authors
   api
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
