=======
Credits
=======

Development Lead
----------------

* Ludwig Lierhammer <ludwig.lierhammer@dwd.de> `@ludwiglierhammer <https://github.com/ludwiglierhammer>`_

Contributors
------------

* Lars Buntemeyer <lars.buntemeyer@hereon.de> `@larsbuntemeyer <https://github.com/larsbuntemeyer>`_
* Katharina Bülow <katharina.buelow@hereon.de> `@KatharinaBuelow <https://github.com/KatharinaBuelow>`_
* Sonali Manimaran <sonali.manimaran@hereon.de> `@emsonali <https://github.com/emsonali>`_
* Susanne Pfeiffer <susanne.pfeiffer@hereon.de> `@SusannePfeiffer007 <https://github.com/SusannePfeifer007>`_
