def rev(text: str) -> str:
    """Returns the reversed string."""
    return text[::-1]

def titlecase(text: str) -> str:
    """Returns string in title case."""
    return text.title()
