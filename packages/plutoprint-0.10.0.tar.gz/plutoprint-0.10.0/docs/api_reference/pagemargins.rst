PageMargins
===========

.. currentmodule:: plutoprint

.. autoclass:: PageMargins
    :members:

    .. automethod:: __init__
    .. automethod:: __getitem__

.. autodata:: PAGE_MARGINS_NONE

.. autodata:: PAGE_MARGINS_NORMAL

.. autodata:: PAGE_MARGINS_NARROW

.. autodata:: PAGE_MARGINS_MODERATE

.. autodata:: PAGE_MARGINS_WIDE
