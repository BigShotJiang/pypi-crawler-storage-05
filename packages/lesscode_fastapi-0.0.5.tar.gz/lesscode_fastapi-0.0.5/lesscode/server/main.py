# from server.app import create_application
#
# # 创建应用实例
# app = create_application()
