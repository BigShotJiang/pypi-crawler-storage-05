# Lymia

Make a simple curses app with this easy to use wrapper.

> [!NOTE]
> This one's in an alpha stage.

## Features

TBA

### Issues & Contribution

TBA
