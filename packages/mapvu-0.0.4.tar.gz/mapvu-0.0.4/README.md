# mapvu


[![image](https://img.shields.io/pypi/v/mapvu.svg)](https://pypi.python.org/pypi/mapvu)
[![image](https://img.shields.io/conda/vn/conda-forge/mapvu.svg)](https://anaconda.org/conda-forge/mapvu)


**A python package for web map application to crate interactive mapping.**


-   Free software: MIT license
-   Documentation: https://gisatb.github.io/mapvu
    

## Features

-   TODO
