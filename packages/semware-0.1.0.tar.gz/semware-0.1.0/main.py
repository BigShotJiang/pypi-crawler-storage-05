def main():
    print("Hello from semware!")


if __name__ == "__main__":
    main()
