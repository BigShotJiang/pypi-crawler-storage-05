"""Data models for SemWare."""
