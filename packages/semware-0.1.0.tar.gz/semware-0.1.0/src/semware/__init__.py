"""SemWare: Semantic search API server using vector databases and ML embeddings."""

__version__ = "0.1.0"
