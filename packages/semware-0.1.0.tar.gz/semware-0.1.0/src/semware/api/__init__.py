"""API module for SemWare."""
