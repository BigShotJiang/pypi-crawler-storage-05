"""Utility functions for SemWare."""
