"""Tests for SemWare."""
