# pjdev-op

[![PyPI - Version](https://img.shields.io/pypi/v/pjdev-op.svg)](https://pypi.org/project/pjdev-op)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pjdev-op.svg)](https://pypi.org/project/pjdev-op)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pjdev-op
```

## License

`pjdev-op` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
