class TrackerError(Exception):
    """Base class for all tracker-related exceptions."""

    pass
