# `OpenAI Model Provider`

::: agents.voice.models.openai_model_provider
