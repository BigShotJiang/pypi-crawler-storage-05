"""
Examples demonstrating how to use models that provide reasoning content.
"""
