from .msg_create_vesting_account import MsgCreateVestingAccount

__all__ = [
    "MsgCreateVestingAccount",
]
