"""
The IO package contains utilities for input and output operations, such as loading and saving recordings to and from
file.
"""
