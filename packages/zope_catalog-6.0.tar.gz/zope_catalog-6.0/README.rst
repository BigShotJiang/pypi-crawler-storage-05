==============
 zope.catalog
==============

.. image:: https://img.shields.io/pypi/v/zope.catalog.svg
        :target: https://pypi.python.org/pypi/zope.catalog/
        :alt: Latest release

.. image:: https://img.shields.io/pypi/pyversions/zope.catalog.svg
        :target: https://pypi.org/project/zope.catalog/
        :alt: Supported Python versions

.. image:: https://github.com/zopefoundation/zope.catalog/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.catalog/actions/workflows/tests.yml

.. image:: https://coveralls.io/repos/github/zopefoundation/zope.catalog/badge.svg?branch=master
        :target: https://coveralls.io/github/zopefoundation/zope.catalog?branch=master

.. image:: https://readthedocs.org/projects/zopecatalog/badge/?version=latest
        :target: http://zopecatalog.readthedocs.org/en/latest/
        :alt: Documentation Status

Catalogs provide management of collections of related indexes with a basic
search algorithm.
