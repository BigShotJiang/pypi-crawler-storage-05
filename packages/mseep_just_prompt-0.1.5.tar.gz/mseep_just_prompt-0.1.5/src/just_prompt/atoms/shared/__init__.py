# Shared package - common utilities and data types
