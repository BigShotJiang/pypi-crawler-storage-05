Overview
========

Advanced i18n/l10n features useful in a CMS environment.

Copyright / Licenses
--------------------

The code in this distribution is copyright Plone Foundation and
licensed under the GPL version 2 only.

The national flags icon set included in this distribution is
copyright by Jakub Steiner (http://jimmac.musichall.cz/i.php?i=flags)
and we have been given permission to include it under the GPL license.

This distribution depends on the Unidecode Python code by Tomaz Solc
repackaged by Ben Bengart for setuptools. The code is a port of the
Perl module Text-Unidecode-0.04 by Sean M. Burke licensed under the
same terms as Perl itself.
