class AddAddress(str):
    """Add an address to the event filter"""


class RemoveAddress(str):
    """Remove an address to the event filter"""
