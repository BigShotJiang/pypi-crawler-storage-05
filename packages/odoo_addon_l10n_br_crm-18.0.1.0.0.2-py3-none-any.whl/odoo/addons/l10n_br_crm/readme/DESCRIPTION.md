Este módulo implementa campos utilizados na localização brasileira como
CNPJ, CPF, Inscrição Estadual e campos de endereço no objeto Prospecto e
também localiza estes campos na criação de parceiro a partir de um
prospecto.
