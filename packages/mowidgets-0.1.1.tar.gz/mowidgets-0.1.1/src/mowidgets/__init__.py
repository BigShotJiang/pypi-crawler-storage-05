from mowidgets._widget import widgetize

__all__ = ("widgetize",)
