"""Integration tests for Linearator."""
