"""Unit tests for Linearator."""
