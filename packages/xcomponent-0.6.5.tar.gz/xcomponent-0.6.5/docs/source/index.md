
```{include} ../../README.md
```

```{toctree}
:maxdepth: 1
:caption: Users Documentation:

user/getting_started
user/changelog
```

```{toctree}
:maxdepth: 1
:caption: Developers Documentation:

develop/index
```

## Indices and tables

* {ref}`genindex`
* {ref}`modindex`
* {ref}`search`
