# ipgs

Interactive ANIMATED progress bar for Jupyter notebook projects.

## Features
- Nested progress bars: epochs + batches
- Animated display in Jupyter/Colab
- Easy integration with PyTorch, TensorFlow, etc.
- No external dependencies except `ipywidgets`

## Installation

```bash
pip install ipgs
