
name = 'energy.meter_channel_instance_view'