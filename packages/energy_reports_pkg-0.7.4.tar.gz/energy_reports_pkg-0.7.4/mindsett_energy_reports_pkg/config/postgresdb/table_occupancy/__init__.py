
name = 'building_occupancy'
selected_columns = ["date", "occupancy"]