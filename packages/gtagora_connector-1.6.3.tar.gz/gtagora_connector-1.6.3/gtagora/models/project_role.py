from gtagora.models.base import BaseModel


class ProjectRole(BaseModel):

    BASE_URL = '/api/v2/projectrole/'
