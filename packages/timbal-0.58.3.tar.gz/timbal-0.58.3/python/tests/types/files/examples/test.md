| Name | Age | Score | Join Date | Status |
|------|-----|-------|-----------|---------|
| Alice Smith | 28 | 95.5 | 2023-01-15 | Active |
| Bob Johnson | 34 | 87.2 | 2023-03-22 | Inactive |
