"""Automated tests for the project."""
