from cadence.cli.entrypoint import root

root()