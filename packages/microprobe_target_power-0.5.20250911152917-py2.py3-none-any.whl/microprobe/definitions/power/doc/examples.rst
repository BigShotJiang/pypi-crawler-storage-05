   examples_power
