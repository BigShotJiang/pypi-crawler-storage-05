class InvalidBaudRateException(Exception):
    pass
class InvalidCOMPortException(Exception):
    pass
