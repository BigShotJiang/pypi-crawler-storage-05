## 0.1.0

* Initial release: Flet-Extended-Interactive-Viewer is a Flet control that provides multiple customization options for displaying two-dimensional content.

## 0.1.1
* FIX Zooming: Zooming now is applied on the middle point of the Interactive Viewer, when not at the corner.
* Added Animation: Added Animation for set_translation_data()

## 0.1.2
* Bug fix animation