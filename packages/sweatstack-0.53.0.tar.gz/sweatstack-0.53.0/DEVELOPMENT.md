# Development



## Running locally

Point your terminal to some other directory (to not clutter this one with `Untitled` files) and then run:

```bash
uvx --with-editable "path/to/sweatstack-python[jupyterlab]" jupyter lab
```

This will start a JupyterLab instance.