from .cli import cli as pyfcstmcli
