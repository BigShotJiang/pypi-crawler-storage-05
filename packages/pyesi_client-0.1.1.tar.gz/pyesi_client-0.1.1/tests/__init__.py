"""Tests for pyesi-client."""
