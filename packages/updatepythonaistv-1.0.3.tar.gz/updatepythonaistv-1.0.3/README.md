# Updatepythonaistv

📦 Công cụ hỗ trợ cập nhật & upload gói Python lên PyPI ngay trên Termux.

## 🚀 Cài đặt
```bash
pip install Updatepythonaistv
```