# Locales
EN_LOCALE = "en"

# Social network options
GITHUB_OPTION = ("GitHub", "github")
GITLAB_OPTION = ("GitLab", "gitlab")
BITBUCKET_OPTION = ("Bitbucket", "bitbucket")
LINKEDIN_OPTION = ("LinkedIn", "linkedin")
FACEBOOK_OPTION = ("Facebook", "facebook")
INSTAGRAM_OPTION = ("Instagram", "instagram")
X_OPTION = ("X", "x")
YOUTUBE_OPTION = ("YouTube", "youtube")
