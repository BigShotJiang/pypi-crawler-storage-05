
name = 'energy.kwh_price'