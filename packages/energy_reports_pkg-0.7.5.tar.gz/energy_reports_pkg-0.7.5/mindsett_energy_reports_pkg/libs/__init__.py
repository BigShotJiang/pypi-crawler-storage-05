import os.path, sys
file_path = os.path.realpath(__file__)
dir_path = os.path.dirname(file_path)
sys.path.append(dir_path)