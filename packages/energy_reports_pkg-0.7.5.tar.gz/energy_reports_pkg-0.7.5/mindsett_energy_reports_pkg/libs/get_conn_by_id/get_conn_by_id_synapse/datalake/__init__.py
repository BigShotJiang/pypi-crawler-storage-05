

account_name = f"dlcfmdsamindsettprod"
container_name= 'uploads'
file_path = 'energy_report_config/credentials.json'

# get the account key from synapse
