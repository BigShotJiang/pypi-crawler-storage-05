"""Main entry point for mcp-server-pacman."""

from mcp_server_pacman import main

if __name__ == "__main__":
    main()
