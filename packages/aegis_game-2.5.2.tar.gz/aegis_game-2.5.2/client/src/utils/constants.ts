export const ROUND_INTERVAL_DURATION = 200
export const TILE_SIZE = 50
export const TIMELINE_WIDTH = 300
export const THICKNESS = 0.04
export const MAP_MAX = 30
export const MAP_MIN = 3
