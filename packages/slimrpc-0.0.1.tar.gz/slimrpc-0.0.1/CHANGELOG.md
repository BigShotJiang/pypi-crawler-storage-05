# Changelog

## 0.0.1 (2025-09-09)


### Features

* update version of slima2a and slimrpc wheels ([#637](https://github.com/agntcy/slim/issues/637)) ([e6569cb](https://github.com/agntcy/slim/commit/e6569cba88afff65b7a736f7511d9ea2a57f7dc2))
