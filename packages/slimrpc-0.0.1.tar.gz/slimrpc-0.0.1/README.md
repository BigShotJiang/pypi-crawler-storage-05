# SRPC

GRPC is protobuf RPC over HTTP/2

SPRC is protobuf RPC over SLIM
