from flekspy.util.logger import get_logger

if __name__ == "__main__":
    logger = get_logger()
    logger.info("Running from CLI...")
