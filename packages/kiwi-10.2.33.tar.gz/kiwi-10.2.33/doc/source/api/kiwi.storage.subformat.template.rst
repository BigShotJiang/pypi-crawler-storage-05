kiwi.storage.subformat.template Package
=======================================

.. _db_kiwi_storage_subformat_template_submodules:

Submodules
----------

`kiwi.storage.subformat.template.vmware_settings` Module
--------------------------------------------------------

.. automodule:: kiwi.storage.subformat.template.vmware_settings
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.template.vagrant_config` Module
--------------------------------------------------------

.. automodule:: kiwi.storage.subformat.template.vagrant_config
    :members:
    :undoc-members:
    :show-inheritance:

`kiwi.storage.subformat.template.virtualbox_ovf` Module
--------------------------------------------------------

.. automodule:: kiwi.storage.subformat.template.virtualbox_ovf
    :members:
    :undoc-members:
    :show-inheritance:

.. _db_kiwi_storage_subformat_template_content:

Module contents
---------------

.. automodule:: kiwi.storage.subformat.template
    :members:
    :undoc-members:
    :show-inheritance:
