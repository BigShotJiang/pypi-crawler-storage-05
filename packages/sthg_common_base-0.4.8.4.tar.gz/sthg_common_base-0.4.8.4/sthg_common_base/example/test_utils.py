def test_util():
    return 123456789