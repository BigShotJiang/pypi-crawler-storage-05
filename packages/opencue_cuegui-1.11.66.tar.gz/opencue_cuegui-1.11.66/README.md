# CueGUI

Users run CueGUI to monitor and manage OpenCue jobs.

Admins run CueGUI to:

- Troubleshoot jobs.
- Assign render processors to jobs.
- Manage job priorities.

