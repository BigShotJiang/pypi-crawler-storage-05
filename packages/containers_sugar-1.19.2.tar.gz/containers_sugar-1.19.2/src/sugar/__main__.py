"""The definition of the action for `python -m` command."""

from __future__ import annotations

from sugar.cli import run_app

if __name__ == '__main__':
    run_app()
