"""Top-level package for sugar."""

__author__ = 'Ivan Ogasawara'
__email__ = 'ivan.ogasawara@gmail.com'
__version__ = '1.19.2'  # semantic-release
