from src.minix.core.entity import Entity

class RedisEntity(Entity):
    pass