from annofabapi.models import AdditionalDataDefinitionType, AnnotationTypeFieldMinWarnRule

AdditionalDataDefaultType = Union[bool, int, str]

AdditionalDataRestrictionCondition = dict[str, Any]

AnnotationSpecsOption = dict[str, Any]
AnnotationType = str
AnnotationTypeFieldValue = dict[str, Any]