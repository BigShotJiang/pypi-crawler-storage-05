from annofabapi.models import (
    CommentType,
    TaskPhase,
    CommentStatus
)
from typing import Any

CommentNode = dict[str, Any]