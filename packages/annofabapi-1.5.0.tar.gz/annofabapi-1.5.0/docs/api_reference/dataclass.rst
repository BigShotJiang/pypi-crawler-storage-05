annofabapi.dataclass module
===========================

annofabapi.dataclass.annotation module
--------------------------------------
.. automodule:: annofabapi.dataclass.annotation
    :members:

annofabapi.dataclass.annotation_specs module
--------------------------------------------
.. automodule:: annofabapi.dataclass.annotation_specs
    :members:

annofabapi.dataclass.input module
---------------------------------
.. automodule:: annofabapi.dataclass.input
    :members:


annofabapi.dataclass.job module
-------------------------------
.. automodule:: annofabapi.dataclass.job
    :members:

annofabapi.dataclass.organization module
----------------------------------------
.. automodule:: annofabapi.dataclass.organization
    :members:


annofabapi.dataclass.organization_member module
-----------------------------------------------
.. automodule:: annofabapi.dataclass.organization_member
    :members:


annofabapi.dataclass.project module
-----------------------------------
.. automodule:: annofabapi.dataclass.project
    :members:


annofabapi.dataclass.project_member module
------------------------------------------
.. automodule:: annofabapi.dataclass.project_member
    :members:


annofabapi.dataclass.supplementary module
-----------------------------------------
.. automodule:: annofabapi.dataclass.supplementary
    :members:


annofabapi.dataclass.task module
--------------------------------
.. automodule:: annofabapi.dataclass.task
    :members:

