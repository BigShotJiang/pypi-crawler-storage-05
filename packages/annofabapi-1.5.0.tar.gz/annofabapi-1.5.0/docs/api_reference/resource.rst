annofabapi.resource module
==========================



.. automodule:: annofabapi.resource
    :members:

