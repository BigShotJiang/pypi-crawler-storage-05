API reference
==================================================

.. toctree::
   :maxdepth: 2

   api
   api2
   wrapper
   resource
   parser
   plugin
   dataclass
   exceptions
   segmentation
   pydantic_models
   models
   util
   utils
   credentials
   

