annofabapi.wrapper module
=========================

.. autoclass:: annofabapi.Wrapper
    :inherited-members:

