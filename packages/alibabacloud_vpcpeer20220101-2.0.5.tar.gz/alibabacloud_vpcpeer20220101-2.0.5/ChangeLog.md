2025-02-10 Version: 2.0.4
- Update API CreateVpcPeerConnection: add param LinkType.
- Update API GetVpcPeerConnectionAttribute: update response param.
- Update API ListTagResources: update response param.
- Update API ListVpcPeerConnections: update response param.
- Update API ModifyVpcPeerConnection: add param LinkType.
- Update API TagResources: update response param.


2024-11-12 Version: 2.0.3
- Generated python 2022-01-01 for VpcPeer.

2024-03-12 Version: 2.0.2
- Generated python 2022-01-01 for VpcPeer.

2024-01-23 Version: 2.0.1
- Generated python 2022-01-01 for VpcPeer.

2024-01-23 Version: 2.0.1
- Generated python 2022-01-01 for VpcPeer.

2023-11-28 Version: 2.0.0
- Generated python 2022-01-01 for VpcPeer.

2023-08-17 Version: 1.1.0
- Generated python 2022-01-01 for VpcPeer.

2023-05-30 Version: 1.0.8
- Adapt timeout.
- Adapt rpc timeout.
- VpcPeer Support ResourceGroup.

2023-02-24 Version: 1.0.7
- VpcPeer Support Tag.

2022-08-09 Version: 1.0.6
- Publish.

2022-07-05 Version: 1.0.5
- Support bandwidth modification.

2022-05-12 Version: 1.0.4
- VpcPeer publish.

2022-04-24 Version: 1.0.3
- VpcPeer publish.

2022-04-24 Version: 1.0.2
- VpcPeer publish.

2022-04-24 Version: 1.0.1
- VpcPeer publish.

2022-04-14 Version: 1.0.0
- VpcPeer publish.

