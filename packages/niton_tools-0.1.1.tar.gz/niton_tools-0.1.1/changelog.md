# Changelog

## v0.1.1

### Changed
- Analyses are now "date" + "reading no" due to non-unique "reading no" values

## v0.1.0

### Added
- `StandardUI`: user interface for adding/updating standard measurements in SQLite database