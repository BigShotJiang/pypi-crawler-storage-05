// Statistics computation module - placeholder for future SIMD implementation
// For now, re-export existing stats logic from main lib

pub use crate::{calculate_numeric_stats, calculate_text_stats, ColumnStats};
