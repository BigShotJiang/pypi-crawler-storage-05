// Pattern detection module - placeholder for future GPU implementation
// For now, re-export existing pattern logic from main lib

pub use crate::{detect_patterns, Pattern};
