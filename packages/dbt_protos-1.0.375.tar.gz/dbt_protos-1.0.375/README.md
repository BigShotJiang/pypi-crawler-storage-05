# dbt public protos

Central public protos repository for use in dbt.

This repository and library are 100% generated.
