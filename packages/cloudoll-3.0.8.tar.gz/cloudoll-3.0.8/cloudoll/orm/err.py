from pymysql.err import OperationalError
from psycopg2.errors import DatabaseError
