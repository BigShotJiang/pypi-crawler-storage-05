"""Init file."""

from llama_index.readers.remote.base import (
    RemoteReader,
)

__all__ = ["RemoteReader"]
