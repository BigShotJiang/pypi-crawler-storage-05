"""For migrating results to a newer schema version."""

from .convert import migrate_result
