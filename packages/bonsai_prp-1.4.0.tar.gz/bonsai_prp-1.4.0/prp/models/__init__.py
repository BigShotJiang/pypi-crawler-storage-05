"""Data models"""

from .sample import PipelineResult
