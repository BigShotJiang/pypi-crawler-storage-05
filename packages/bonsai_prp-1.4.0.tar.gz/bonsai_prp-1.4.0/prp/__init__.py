"""Pipeline result processing application."""

from .__version__ import VERSION
