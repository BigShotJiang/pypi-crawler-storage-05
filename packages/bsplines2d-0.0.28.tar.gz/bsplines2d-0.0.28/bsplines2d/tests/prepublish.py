print('test import')
import bsplines2d as bs2
print('test version')
print(bs2.__version__)
