from . import ssas
from .report import LocalReport
from .static_files import layout

__all__ = ["LocalReport", "layout", "ssas"]
__version__ = "0.6.3"
