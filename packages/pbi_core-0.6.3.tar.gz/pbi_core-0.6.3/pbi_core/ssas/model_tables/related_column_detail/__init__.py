# Auto-generated to make this a Python package
from .related_column_detail import RelatedColumnDetail

__all__ = ["RelatedColumnDetail"]
