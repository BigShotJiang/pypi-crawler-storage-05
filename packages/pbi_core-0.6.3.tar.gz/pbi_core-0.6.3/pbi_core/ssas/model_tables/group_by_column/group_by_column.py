from pbi_core.ssas.model_tables.base.base_ssas_table import SsasTable


class GroupByColumn(SsasTable):
    """TBD.

    SSAS spec:
    """
