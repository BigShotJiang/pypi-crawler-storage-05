# Auto-generated to make this a Python package
from .object_translation import ObjectTranslation

__all__ = ["ObjectTranslation"]
