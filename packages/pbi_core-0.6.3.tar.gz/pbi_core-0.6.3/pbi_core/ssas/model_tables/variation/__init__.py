# Auto-generated to make this a Python package
from .variation import Variation

__all__ = ["Variation"]
