from enum import IntEnum


class MemberType(IntEnum):
    AUTO = 1
    USER = 2
    GROUP = 3
