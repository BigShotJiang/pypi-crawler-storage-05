# Auto-generated to make this a Python package
from .partition import Partition

__all__ = ["Partition"]
