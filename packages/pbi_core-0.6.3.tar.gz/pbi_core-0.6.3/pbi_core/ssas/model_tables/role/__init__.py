# Auto-generated to make this a Python package
from .role import Role

__all__ = ["Role"]
