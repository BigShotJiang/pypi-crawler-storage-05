from enum import IntEnum


class ProgressReportBeginColumns(IntEnum):
    pass


class ProgressReportEndColumns(IntEnum):
    pass


class ProgressReportCurrentColumns(IntEnum):
    pass


class ProgressReportErrorColumns(IntEnum):
    pass
