from .internationalization import get_static_elements, set_static_elements

__all__ = ["get_static_elements", "set_static_elements"]
