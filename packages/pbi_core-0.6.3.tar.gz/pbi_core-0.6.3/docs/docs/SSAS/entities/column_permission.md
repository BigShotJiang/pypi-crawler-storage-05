# Column Permission


::: pbi_core.ssas.model_tables.column_permission.ColumnPermission