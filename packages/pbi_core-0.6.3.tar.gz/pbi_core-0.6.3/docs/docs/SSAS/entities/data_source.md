# Data Source


::: pbi_core.ssas.model_tables.data_source.DataSource