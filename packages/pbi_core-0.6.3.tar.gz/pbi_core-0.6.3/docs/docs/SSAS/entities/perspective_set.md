# Perspective Set


::: pbi_core.ssas.model_tables.perspective_set.PerspectiveSet