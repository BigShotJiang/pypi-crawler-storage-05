# Detail Row Definition


::: pbi_core.ssas.model_tables.detail_row_definition.DetailRowDefinition