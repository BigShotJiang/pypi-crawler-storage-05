# Partition


::: pbi_core.ssas.model_tables.partition.Partition