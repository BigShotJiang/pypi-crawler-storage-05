# Linguistic Metadata


::: pbi_core.ssas.model_tables.linguistic_metadata.LinguisticMetadata