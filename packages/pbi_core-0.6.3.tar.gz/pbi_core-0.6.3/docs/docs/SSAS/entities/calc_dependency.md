# Calc Dependency

::: pbi_core.ssas.model_tables.calc_dependency.CalcDependency