```mermaid
---
title: LiteralExpression
---
graph 
LiteralExpression[<a href='/layout/erd/LiteralExpression'>LiteralExpression</a>]
LiteralSource[<a href='/layout/erd/LiteralSource'>LiteralSource</a>]
style LiteralSource stroke:#ff0000,stroke-width:1px
LiteralExpression ---> LiteralSource
```