```mermaid
---
title: GeoJsonExpression
---
graph 
GeoJsonExpression[<a href='/layout/erd/GeoJsonExpression'>GeoJsonExpression</a>]
_GeoJsonExpressionHelper[_GeoJsonExpressionHelper]
GeoJsonExpression --->|geoJson| _GeoJsonExpressionHelper
```