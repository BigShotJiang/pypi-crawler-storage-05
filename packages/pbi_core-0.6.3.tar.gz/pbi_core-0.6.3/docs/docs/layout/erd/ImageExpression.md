```mermaid
---
title: ImageExpression
---
graph 
ImageExpression[<a href='/layout/erd/ImageExpression'>ImageExpression</a>]
_ImageExpressionHelper[_ImageExpressionHelper]
ImageExpression --->|image| _ImageExpressionHelper
```