MatInverse is a code for multiphysics Topology optimization written in JAX

To install:

```bash

  pip install git+https://github.com/MatInverse/MatInverse.git@v1.0.5

```
