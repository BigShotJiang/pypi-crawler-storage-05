#!/bin/sh
# properties = {properties}
{exec_job}
