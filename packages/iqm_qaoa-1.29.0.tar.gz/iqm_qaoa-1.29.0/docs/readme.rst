.. _readme:
.. include:: ../README.rst