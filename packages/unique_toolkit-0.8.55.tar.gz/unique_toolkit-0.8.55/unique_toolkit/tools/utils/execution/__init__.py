"""Execution utilities for tools."""
