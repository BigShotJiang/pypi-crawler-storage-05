# Half.Sample

[![Build status](https://ci.appveyor.com/api/projects/status/04ox7guybqotu67d?svg=true)](https://ci.appveyor.com/project/Wingsgo/half-sample)

Sample, C++ Program in Half Application with Python Module

## Requirements

Python Requirements:

1. st
2. typing

Others:

1. C++11 environment
2. scons

You can also refer to the Travis-CI config file: `.travis.yml`, or Appveyor config file: `appveyor.yml`.

