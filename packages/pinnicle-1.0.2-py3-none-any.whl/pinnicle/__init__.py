from .parameter import *
from . import utils
from . import physics
from . import modeldata
from . import nn
from . import domain

from .pinn import PINN
