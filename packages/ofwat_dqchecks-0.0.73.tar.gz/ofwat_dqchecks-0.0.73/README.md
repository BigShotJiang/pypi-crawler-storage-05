# dqchecks
Data quality validation service code, used to check submitted Excel files against expectations

## Installation
```bash
pip install ofwat-dqchecks
```

## Examples
todo
