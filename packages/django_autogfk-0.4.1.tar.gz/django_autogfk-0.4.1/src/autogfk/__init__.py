default_app_config = "autogfk.apps.AutoGenericForeignKeyConfig"
__version__ = "0.4.1"
__all__ = ["fields"]