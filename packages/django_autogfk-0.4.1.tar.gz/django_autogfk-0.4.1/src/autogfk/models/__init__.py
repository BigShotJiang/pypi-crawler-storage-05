from .base import AutoGenericForeignKeyModel
from .polymorphic import AutoGenericForeignKeyPolymorphicModel

__all__ = ["AutoGenericForeignKeyModel", "AutoGenericForeignKeyPolymorphicModel"]