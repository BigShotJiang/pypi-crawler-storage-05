from llama_index.node_parser.topic.base import (
    TopicNodeParser,
)


__all__ = ["TopicNodeParser"]
