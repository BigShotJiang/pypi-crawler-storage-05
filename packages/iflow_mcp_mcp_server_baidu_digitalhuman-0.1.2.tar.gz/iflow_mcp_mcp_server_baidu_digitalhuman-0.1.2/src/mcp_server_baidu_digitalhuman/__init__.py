# __init__.py
"""
# MCP Server from Baidu Digital Human(XiLing)
# File: __init__.py
# Authors: digithuman
# Date: 2025/5/21 10:07
"""

__version__ = "0.1.2"

from mcp_server_baidu_digitalhuman.dhserver import main

__all__ = ["main"]