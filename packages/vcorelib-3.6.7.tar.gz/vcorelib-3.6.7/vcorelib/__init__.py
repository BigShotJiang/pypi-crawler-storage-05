# =====================================
# generator=datazen
# version=3.2.3
# hash=fbf1f5e60178e8d08a843511dbe58179
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "A collection of core Python utilities."
PKG_NAME = "vcorelib"
VERSION = "3.6.7"

# vcorelib-specific content.
DEFAULT_INDENT = 2
DEFAULT_ENCODING = "utf-8"
