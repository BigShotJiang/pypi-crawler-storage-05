__version__ = "0.6.0"

GLOBALS: dict = {
    "CONF_PATH": "conf.d/",
    "DATA_PATH": "results/",
    "DB_PATH": "results/",
    "DB_FILENAME": "kpat.ddb",
    "MAX_SUMMARY_REPORT_RESULTS": 100,
}
