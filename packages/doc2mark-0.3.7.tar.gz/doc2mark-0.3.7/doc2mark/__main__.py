"""Main entry point for doc2mark when run as a module."""

from doc2mark.cli import main

if __name__ == "__main__":
    main()