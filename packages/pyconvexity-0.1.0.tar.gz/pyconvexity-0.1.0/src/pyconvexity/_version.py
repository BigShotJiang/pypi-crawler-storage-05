# This file is automatically updated by GitHub Actions during release
__version__ = "0.1.0"  # Default version for local development
