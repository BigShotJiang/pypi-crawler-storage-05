# -*- coding: utf-8 -*-
# @version        : 1.0
# @Create Time    : 2025/5/9 19:21
# @File           : constants
# @IDE            : PyCharm
# @desc           : 常量定义

default_queue_name = 'arq:queue'
