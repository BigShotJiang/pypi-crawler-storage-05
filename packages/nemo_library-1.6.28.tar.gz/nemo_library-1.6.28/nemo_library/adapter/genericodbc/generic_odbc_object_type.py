from nemo_library.adapter.utils.structures import ETLBaseObjectType


class GenericODBCObjectType(ETLBaseObjectType):
    GENERIC = ("GENERIC", "0001")

