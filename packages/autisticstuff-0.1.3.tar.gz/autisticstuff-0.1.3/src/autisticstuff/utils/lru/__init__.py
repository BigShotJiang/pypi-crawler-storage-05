from .object import add_cached_handler_for_instance


__all__ = ["add_cached_handler_for_instance"]
