from enum import Enum


class Styles(Enum):
	CLASSIC = "classic"
	CIRCLE = "circle"
	FLUID = "fluid"
