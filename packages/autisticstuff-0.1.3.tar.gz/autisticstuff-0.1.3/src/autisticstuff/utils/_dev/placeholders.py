def _raise_ni_error():
	raise NotImplementedError
