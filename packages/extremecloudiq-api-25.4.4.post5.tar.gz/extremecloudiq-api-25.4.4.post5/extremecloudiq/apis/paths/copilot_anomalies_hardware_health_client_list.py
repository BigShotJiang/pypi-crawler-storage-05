from extremecloudiq.paths.copilot_anomalies_hardware_health_client_list.get import ApiForget


class CopilotAnomaliesHardwareHealthClientList(
    ApiForget,
):
    pass
