from extremecloudiq.paths.countries_country_alpha2_code_states.get import ApiForget


class CountriesCountryAlpha2CodeStates(
    ApiForget,
):
    pass
