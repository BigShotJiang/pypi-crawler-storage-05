from extremecloudiq.paths.ssids_id_mode_psk.put import ApiForput


class SsidsIdModePsk(
    ApiForput,
):
    pass
