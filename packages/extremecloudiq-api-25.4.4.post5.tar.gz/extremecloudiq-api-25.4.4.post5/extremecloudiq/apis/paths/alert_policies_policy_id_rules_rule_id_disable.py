from extremecloudiq.paths.alert_policies_policy_id_rules_rule_id_disable.post import ApiForpost


class AlertPoliciesPolicyIdRulesRuleIdDisable(
    ApiForpost,
):
    pass
