from extremecloudiq.paths.clients_usage.get import ApiForget


class ClientsUsage(
    ApiForget,
):
    pass
