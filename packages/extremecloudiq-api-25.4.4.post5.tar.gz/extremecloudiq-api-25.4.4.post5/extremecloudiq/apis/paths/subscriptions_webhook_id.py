from extremecloudiq.paths.subscriptions_webhook_id.put import ApiForput


class SubscriptionsWebhookId(
    ApiForput,
):
    pass
