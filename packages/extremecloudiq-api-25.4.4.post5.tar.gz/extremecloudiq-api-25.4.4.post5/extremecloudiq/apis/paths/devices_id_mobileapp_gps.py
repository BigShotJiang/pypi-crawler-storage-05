from extremecloudiq.paths.devices_id_mobileapp_gps.put import ApiForput


class DevicesIdMobileappGps(
    ApiForput,
):
    pass
