from extremecloudiq.paths.dashboard_wireless_device_health_reboot_summary.get import ApiForget


class DashboardWirelessDeviceHealthRebootSummary(
    ApiForget,
):
    pass
