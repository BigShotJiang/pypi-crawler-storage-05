from extremecloudiq.paths.radio_operating_modes_product_type.get import ApiForget


class RadioOperatingModesProductType(
    ApiForget,
):
    pass
