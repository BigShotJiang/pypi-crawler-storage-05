from extremecloudiq.paths.backup_history_delete.delete import ApiFordelete


class BackupHistoryDelete(
    ApiFordelete,
):
    pass
