from extremecloudiq.paths.copilot_connectivity_locations.get import ApiForget


class CopilotConnectivityLocations(
    ApiForget,
):
    pass
