from extremecloudiq.paths.ssids_advanced_settings_id.get import ApiForget
from extremecloudiq.paths.ssids_advanced_settings_id.put import ApiForput


class SsidsAdvancedSettingsId(
    ApiForget,
    ApiForput,
):
    pass
