from extremecloudiq.paths.radius_proxies_devices.get import ApiForget


class RadiusProxiesDevices(
    ApiForget,
):
    pass
