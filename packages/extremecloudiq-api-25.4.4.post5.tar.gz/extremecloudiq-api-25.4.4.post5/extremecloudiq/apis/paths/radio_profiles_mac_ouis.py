from extremecloudiq.paths.radio_profiles_mac_ouis.get import ApiForget
from extremecloudiq.paths.radio_profiles_mac_ouis.post import ApiForpost


class RadioProfilesMacOuis(
    ApiForget,
    ApiForpost,
):
    pass
