from extremecloudiq.paths.network_services_id.delete import ApiFordelete


class NetworkServicesId(
    ApiFordelete,
):
    pass
