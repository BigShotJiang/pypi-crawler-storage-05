from extremecloudiq.paths.devices_digital_twin.get import ApiForget


class DevicesDigitalTwin(
    ApiForget,
):
    pass
