from extremecloudiq.paths.endusers.get import ApiForget
from extremecloudiq.paths.endusers.post import ApiForpost


class Endusers(
    ApiForget,
    ApiForpost,
):
    pass
