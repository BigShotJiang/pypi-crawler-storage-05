from extremecloudiq.paths.acct_api_token_export.get import ApiForget


class AcctApiTokenExport(
    ApiForget,
):
    pass
