from extremecloudiq.paths.copilot_connectivity_wired_quality_index.get import ApiForget


class CopilotConnectivityWiredQualityIndex(
    ApiForget,
):
    pass
