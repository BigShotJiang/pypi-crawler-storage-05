from extremecloudiq.paths.afcserver_server_id.get import ApiForget


class AfcserverServerId(
    ApiForget,
):
    pass
