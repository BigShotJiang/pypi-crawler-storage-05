from extremecloudiq.paths.mac_firewall_policies_id_mac_firewall_rule_detach.post import ApiForpost


class MacFirewallPoliciesIdMacFirewallRuleDetach(
    ApiForpost,
):
    pass
