from extremecloudiq.paths.pcgs_key_based_network_policy_policy_id_port_assignments.get import ApiForget
from extremecloudiq.paths.pcgs_key_based_network_policy_policy_id_port_assignments.post import ApiForpost


class PcgsKeyBasedNetworkPolicyPolicyIdPortAssignments(
    ApiForget,
    ApiForpost,
):
    pass
