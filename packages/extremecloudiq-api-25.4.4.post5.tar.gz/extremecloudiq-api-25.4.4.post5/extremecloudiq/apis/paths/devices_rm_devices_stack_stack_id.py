from extremecloudiq.paths.devices_rm_devices_stack_stack_id.get import ApiForget


class DevicesRmDevicesStackStackId(
    ApiForget,
):
    pass
