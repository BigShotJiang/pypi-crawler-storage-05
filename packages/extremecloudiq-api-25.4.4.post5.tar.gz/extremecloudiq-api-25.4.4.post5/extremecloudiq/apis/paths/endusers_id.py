from extremecloudiq.paths.endusers_id.put import ApiForput
from extremecloudiq.paths.endusers_id.delete import ApiFordelete


class EndusersId(
    ApiForput,
    ApiFordelete,
):
    pass
