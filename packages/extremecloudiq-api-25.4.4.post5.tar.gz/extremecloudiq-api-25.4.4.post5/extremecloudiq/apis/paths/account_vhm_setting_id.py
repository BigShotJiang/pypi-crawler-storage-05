from extremecloudiq.paths.account_vhm_setting_id.put import ApiForput


class AccountVhmSettingId(
    ApiForput,
):
    pass
