from extremecloudiq.paths.copilot_connectivity_wireless_experience.get import ApiForget


class CopilotConnectivityWirelessExperience(
    ApiForget,
):
    pass
