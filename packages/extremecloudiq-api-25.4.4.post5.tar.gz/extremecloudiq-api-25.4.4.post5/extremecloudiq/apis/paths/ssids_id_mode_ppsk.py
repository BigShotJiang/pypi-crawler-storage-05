from extremecloudiq.paths.ssids_id_mode_ppsk.put import ApiForput


class SsidsIdModePpsk(
    ApiForput,
):
    pass
