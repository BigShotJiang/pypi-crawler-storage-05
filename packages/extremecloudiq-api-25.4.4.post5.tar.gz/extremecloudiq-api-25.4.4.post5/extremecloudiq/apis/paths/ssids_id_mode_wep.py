from extremecloudiq.paths.ssids_id_mode_wep.put import ApiForput


class SsidsIdModeWep(
    ApiForput,
):
    pass
