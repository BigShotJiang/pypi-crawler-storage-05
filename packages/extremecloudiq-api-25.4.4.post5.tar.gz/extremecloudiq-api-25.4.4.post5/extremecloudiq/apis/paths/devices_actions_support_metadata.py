from extremecloudiq.paths.devices_actions_support_metadata.post import ApiForpost


class DevicesActionsSupportMetadata(
    ApiForpost,
):
    pass
