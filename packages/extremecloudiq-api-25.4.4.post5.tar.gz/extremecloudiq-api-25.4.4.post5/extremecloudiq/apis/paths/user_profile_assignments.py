from extremecloudiq.paths.user_profile_assignments.get import ApiForget
from extremecloudiq.paths.user_profile_assignments.post import ApiForpost


class UserProfileAssignments(
    ApiForget,
    ApiForpost,
):
    pass
