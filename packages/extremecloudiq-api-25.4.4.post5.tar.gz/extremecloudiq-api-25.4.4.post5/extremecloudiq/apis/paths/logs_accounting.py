from extremecloudiq.paths.logs_accounting.get import ApiForget


class LogsAccounting(
    ApiForget,
):
    pass
