from extremecloudiq.paths.dashboard_assets.post import ApiForpost


class DashboardAssets(
    ApiForpost,
):
    pass
