from extremecloudiq.paths.devices_id_thread_commissioner_start.post import ApiForpost


class DevicesIdThreadCommissionerStart(
    ApiForpost,
):
    pass
