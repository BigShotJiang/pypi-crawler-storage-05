from extremecloudiq.paths.devices_check_ownership.post import ApiForpost


class DevicesCheckOwnership(
    ApiForpost,
):
    pass
