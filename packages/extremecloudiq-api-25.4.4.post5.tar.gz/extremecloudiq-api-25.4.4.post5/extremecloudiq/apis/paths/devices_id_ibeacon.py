from extremecloudiq.paths.devices_id_ibeacon.get import ApiForget


class DevicesIdIbeacon(
    ApiForget,
):
    pass
