from extremecloudiq.paths.devices_network_policy_query.post import ApiForpost


class DevicesNetworkPolicyQuery(
    ApiForpost,
):
    pass
