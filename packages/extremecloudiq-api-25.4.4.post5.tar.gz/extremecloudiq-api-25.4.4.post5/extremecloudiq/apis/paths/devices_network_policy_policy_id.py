from extremecloudiq.paths.devices_network_policy_policy_id.get import ApiForget


class DevicesNetworkPolicyPolicyId(
    ApiForget,
):
    pass
