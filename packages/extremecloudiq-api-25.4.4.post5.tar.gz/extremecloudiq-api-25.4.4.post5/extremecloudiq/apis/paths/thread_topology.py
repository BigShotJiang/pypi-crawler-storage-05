from extremecloudiq.paths.thread_topology.get import ApiForget


class ThreadTopology(
    ApiForget,
):
    pass
