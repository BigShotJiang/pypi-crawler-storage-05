from extremecloudiq.paths.network_services.get import ApiForget
from extremecloudiq.paths.network_services.post import ApiForpost


class NetworkServices(
    ApiForget,
    ApiForpost,
):
    pass
