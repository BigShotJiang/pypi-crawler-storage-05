from extremecloudiq.paths.network_scorecard_device_health_location_id.get import ApiForget


class NetworkScorecardDeviceHealthLocationId(
    ApiForget,
):
    pass
