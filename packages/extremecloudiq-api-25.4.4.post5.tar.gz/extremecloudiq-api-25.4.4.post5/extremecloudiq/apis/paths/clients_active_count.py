from extremecloudiq.paths.clients_active_count.get import ApiForget


class ClientsActiveCount(
    ApiForget,
):
    pass
