from extremecloudiq.paths.subscriptions_webhook.get import ApiForget
from extremecloudiq.paths.subscriptions_webhook.post import ApiForpost


class SubscriptionsWebhook(
    ApiForget,
    ApiForpost,
):
    pass
