from extremecloudiq.paths.clients_alias.put import ApiForput


class ClientsAlias(
    ApiForput,
):
    pass
