from extremecloudiq.paths.alerts.get import ApiForget


class Alerts(
    ApiForget,
):
    pass
