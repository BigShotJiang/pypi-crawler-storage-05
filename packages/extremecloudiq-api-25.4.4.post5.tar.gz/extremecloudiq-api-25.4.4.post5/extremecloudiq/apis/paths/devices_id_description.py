from extremecloudiq.paths.devices_id_description.put import ApiForput


class DevicesIdDescription(
    ApiForput,
):
    pass
