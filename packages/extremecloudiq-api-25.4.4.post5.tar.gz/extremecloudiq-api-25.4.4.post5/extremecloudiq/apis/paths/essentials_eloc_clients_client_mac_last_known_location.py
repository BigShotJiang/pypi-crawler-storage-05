from extremecloudiq.paths.essentials_eloc_clients_client_mac_last_known_location.get import ApiForget


class EssentialsElocClientsClientMacLastKnownLocation(
    ApiForget,
):
    pass
