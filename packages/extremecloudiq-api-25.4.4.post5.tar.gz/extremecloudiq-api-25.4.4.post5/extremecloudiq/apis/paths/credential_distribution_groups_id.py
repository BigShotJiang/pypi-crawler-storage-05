from extremecloudiq.paths.credential_distribution_groups_id.put import ApiForput


class CredentialDistributionGroupsId(
    ApiForput,
):
    pass
