from extremecloudiq.paths.locations_tree_devices.get import ApiForget


class LocationsTreeDevices(
    ApiForget,
):
    pass
