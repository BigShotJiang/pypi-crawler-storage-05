from extremecloudiq.paths.radius_proxies_id.get import ApiForget
from extremecloudiq.paths.radius_proxies_id.put import ApiForput
from extremecloudiq.paths.radius_proxies_id.delete import ApiFordelete


class RadiusProxiesId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
