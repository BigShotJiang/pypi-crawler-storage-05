from extremecloudiq.paths.ad_servers.get import ApiForget


class AdServers(
    ApiForget,
):
    pass
