from extremecloudiq.paths.devices_delete.post import ApiForpost


class DevicesDelete(
    ApiForpost,
):
    pass
