from extremecloudiq.paths.acct_api_token_delete.delete import ApiFordelete


class AcctApiTokenDelete(
    ApiFordelete,
):
    pass
