from extremecloudiq.paths.usergroups_unique.get import ApiForget


class UsergroupsUnique(
    ApiForget,
):
    pass
