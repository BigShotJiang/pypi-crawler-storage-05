from extremecloudiq.paths.dashboard_wired_device_health_memory_usage_issues.post import ApiForpost


class DashboardWiredDeviceHealthMemoryUsageIssues(
    ApiForpost,
):
    pass
