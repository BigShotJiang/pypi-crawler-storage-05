from extremecloudiq.paths.dashboard_wireless_device_health_export.post import ApiForpost


class DashboardWirelessDeviceHealthExport(
    ApiForpost,
):
    pass
