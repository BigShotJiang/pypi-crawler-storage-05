from extremecloudiq.paths.devices_unmanage.post import ApiForpost


class DevicesUnmanage(
    ApiForpost,
):
    pass
