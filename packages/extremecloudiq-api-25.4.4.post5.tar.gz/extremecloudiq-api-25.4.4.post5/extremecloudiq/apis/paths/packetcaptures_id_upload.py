from extremecloudiq.paths.packetcaptures_id_upload.post import ApiForpost


class PacketcapturesIdUpload(
    ApiForpost,
):
    pass
