from extremecloudiq.paths.iot_profiles.get import ApiForget
from extremecloudiq.paths.iot_profiles.post import ApiForpost


class IotProfiles(
    ApiForget,
    ApiForpost,
):
    pass
