from extremecloudiq.paths.copilot_connectivity_wired_experience.get import ApiForget


class CopilotConnectivityWiredExperience(
    ApiForget,
):
    pass
