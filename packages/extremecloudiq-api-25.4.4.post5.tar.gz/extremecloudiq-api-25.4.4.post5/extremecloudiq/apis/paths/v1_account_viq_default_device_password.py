from extremecloudiq.paths.v1_account_viq_default_device_password.put import ApiForput


class V1AccountViqDefaultDevicePassword(
    ApiForput,
):
    pass
