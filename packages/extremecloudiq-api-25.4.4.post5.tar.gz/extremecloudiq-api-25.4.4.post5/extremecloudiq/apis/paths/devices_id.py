from extremecloudiq.paths.devices_id.get import ApiForget
from extremecloudiq.paths.devices_id.delete import ApiFordelete


class DevicesId(
    ApiForget,
    ApiFordelete,
):
    pass
