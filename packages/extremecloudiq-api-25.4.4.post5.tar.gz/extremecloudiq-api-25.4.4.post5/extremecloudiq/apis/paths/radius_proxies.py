from extremecloudiq.paths.radius_proxies.get import ApiForget
from extremecloudiq.paths.radius_proxies.post import ApiForpost


class RadiusProxies(
    ApiForget,
    ApiForpost,
):
    pass
