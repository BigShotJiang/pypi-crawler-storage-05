from extremecloudiq.paths.devices_id_iot.get import ApiForget


class DevicesIdIot(
    ApiForget,
):
    pass
