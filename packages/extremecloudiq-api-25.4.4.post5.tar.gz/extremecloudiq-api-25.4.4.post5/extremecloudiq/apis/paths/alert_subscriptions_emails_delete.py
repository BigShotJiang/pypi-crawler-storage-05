from extremecloudiq.paths.alert_subscriptions_emails_delete.post import ApiForpost


class AlertSubscriptionsEmailsDelete(
    ApiForpost,
):
    pass
