from extremecloudiq.paths.hotspot_service_provider_profiles.get import ApiForget
from extremecloudiq.paths.hotspot_service_provider_profiles.post import ApiForpost


class HotspotServiceProviderProfiles(
    ApiForget,
    ApiForpost,
):
    pass
