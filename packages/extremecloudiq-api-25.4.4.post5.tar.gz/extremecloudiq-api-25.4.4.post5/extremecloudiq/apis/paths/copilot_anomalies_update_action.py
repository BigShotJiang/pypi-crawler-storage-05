from extremecloudiq.paths.copilot_anomalies_update_action.put import ApiForput


class CopilotAnomaliesUpdateAction(
    ApiForput,
):
    pass
