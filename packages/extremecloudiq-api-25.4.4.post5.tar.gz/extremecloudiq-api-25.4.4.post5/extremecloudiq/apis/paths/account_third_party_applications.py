from extremecloudiq.paths.account_third_party_applications.get import ApiForget


class AccountThirdPartyApplications(
    ApiForget,
):
    pass
