from extremecloudiq.paths.dashboard_wireless_usage_capacity_reports_id.get import ApiForget


class DashboardWirelessUsageCapacityReportsId(
    ApiForget,
):
    pass
