from extremecloudiq.paths.copilot_anomalies_poeflapping_lldp_cdp_info.get import ApiForget


class CopilotAnomaliesPoeflappingLldpCdpInfo(
    ApiForget,
):
    pass
