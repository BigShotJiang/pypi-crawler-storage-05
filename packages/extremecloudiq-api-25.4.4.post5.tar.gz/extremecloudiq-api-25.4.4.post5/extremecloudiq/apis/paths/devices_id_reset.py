from extremecloudiq.paths.devices_id_reset.post import ApiForpost


class DevicesIdReset(
    ApiForpost,
):
    pass
