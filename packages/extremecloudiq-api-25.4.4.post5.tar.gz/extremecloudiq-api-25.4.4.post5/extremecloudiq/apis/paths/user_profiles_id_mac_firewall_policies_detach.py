from extremecloudiq.paths.user_profiles_id_mac_firewall_policies_detach.post import ApiForpost


class UserProfilesIdMacFirewallPoliciesDetach(
    ApiForpost,
):
    pass
