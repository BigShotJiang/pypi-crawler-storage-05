from extremecloudiq.paths.radio_profiles_channel_selection_id.get import ApiForget
from extremecloudiq.paths.radio_profiles_channel_selection_id.put import ApiForput


class RadioProfilesChannelSelectionId(
    ApiForget,
    ApiForput,
):
    pass
