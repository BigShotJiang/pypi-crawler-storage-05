from extremecloudiq.paths.devices_id_ssid_status.get import ApiForget


class DevicesIdSsidStatus(
    ApiForget,
):
    pass
