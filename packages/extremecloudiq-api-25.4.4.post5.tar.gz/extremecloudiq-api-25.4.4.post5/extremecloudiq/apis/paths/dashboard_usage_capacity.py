from extremecloudiq.paths.dashboard_usage_capacity.post import ApiForpost


class DashboardUsageCapacity(
    ApiForpost,
):
    pass
