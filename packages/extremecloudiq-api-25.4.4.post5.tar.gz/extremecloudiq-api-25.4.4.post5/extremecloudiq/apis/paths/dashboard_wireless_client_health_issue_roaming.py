from extremecloudiq.paths.dashboard_wireless_client_health_issue_roaming.post import ApiForpost


class DashboardWirelessClientHealthIssueRoaming(
    ApiForpost,
):
    pass
