from extremecloudiq.paths.copilot_anomalies_report.get import ApiForget


class CopilotAnomaliesReport(
    ApiForget,
):
    pass
