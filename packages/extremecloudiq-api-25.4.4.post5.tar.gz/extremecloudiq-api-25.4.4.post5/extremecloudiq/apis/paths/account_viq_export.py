from extremecloudiq.paths.account_viq_export.post import ApiForpost


class AccountViqExport(
    ApiForpost,
):
    pass
