from extremecloudiq.paths.devices_radius_proxy_assign.put import ApiForput


class DevicesRadiusProxyAssign(
    ApiForput,
):
    pass
