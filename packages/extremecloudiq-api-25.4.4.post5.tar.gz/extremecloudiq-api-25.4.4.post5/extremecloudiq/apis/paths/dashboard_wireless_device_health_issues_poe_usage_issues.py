from extremecloudiq.paths.dashboard_wireless_device_health_issues_poe_usage_issues.post import ApiForpost


class DashboardWirelessDeviceHealthIssuesPoeUsageIssues(
    ApiForpost,
):
    pass
