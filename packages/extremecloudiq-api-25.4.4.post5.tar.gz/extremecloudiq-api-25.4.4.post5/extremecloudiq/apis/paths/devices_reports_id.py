from extremecloudiq.paths.devices_reports_id.get import ApiForget


class DevicesReportsId(
    ApiForget,
):
    pass
