from extremecloudiq.paths.dashboard_wireless_usage_capacity_grid.post import ApiForpost


class DashboardWirelessUsageCapacityGrid(
    ApiForpost,
):
    pass
