from extremecloudiq.paths.devices_ibeacon.put import ApiForput


class DevicesIbeacon(
    ApiForput,
):
    pass
