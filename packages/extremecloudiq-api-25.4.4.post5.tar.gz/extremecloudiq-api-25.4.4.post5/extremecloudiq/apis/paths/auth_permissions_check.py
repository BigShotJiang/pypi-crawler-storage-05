from extremecloudiq.paths.auth_permissions_check.post import ApiForpost


class AuthPermissionsCheck(
    ApiForpost,
):
    pass
