from extremecloudiq.paths.alert_subscriptions_servicenow_id.get import ApiForget
from extremecloudiq.paths.alert_subscriptions_servicenow_id.put import ApiForput
from extremecloudiq.paths.alert_subscriptions_servicenow_id.patch import ApiForpatch


class AlertSubscriptionsServicenowId(
    ApiForget,
    ApiForput,
    ApiForpatch,
):
    pass
