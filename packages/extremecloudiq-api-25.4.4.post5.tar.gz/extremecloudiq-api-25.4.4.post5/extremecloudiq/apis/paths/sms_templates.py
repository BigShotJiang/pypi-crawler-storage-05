from extremecloudiq.paths.sms_templates.get import ApiForget


class SmsTemplates(
    ApiForget,
):
    pass
