from extremecloudiq.paths.user_profiles_id_mac_firewall_policies_attach.post import ApiForpost


class UserProfilesIdMacFirewallPoliciesAttach(
    ApiForpost,
):
    pass
