from extremecloudiq.paths.copilot_connectivity_wireless_locations_quality_index.get import ApiForget


class CopilotConnectivityWirelessLocationsQualityIndex(
    ApiForget,
):
    pass
