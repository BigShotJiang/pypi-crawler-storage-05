from extremecloudiq.paths.user_profile_assignments_id.get import ApiForget
from extremecloudiq.paths.user_profile_assignments_id.delete import ApiFordelete


class UserProfileAssignmentsId(
    ApiForget,
    ApiFordelete,
):
    pass
