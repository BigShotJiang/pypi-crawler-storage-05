from extremecloudiq.paths.account_viq_reset.post import ApiForpost


class AccountViqReset(
    ApiForpost,
):
    pass
