from extremecloudiq.paths.clients_by_mac_client_mac.get import ApiForget
from extremecloudiq.paths.clients_by_mac_client_mac.delete import ApiFordelete


class ClientsByMacClientMac(
    ApiForget,
    ApiFordelete,
):
    pass
