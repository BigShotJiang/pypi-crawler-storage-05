from extremecloudiq.paths.alert_subscriptions_servicenow.get import ApiForget
from extremecloudiq.paths.alert_subscriptions_servicenow.post import ApiForpost


class AlertSubscriptionsServicenow(
    ApiForget,
    ApiForpost,
):
    pass
