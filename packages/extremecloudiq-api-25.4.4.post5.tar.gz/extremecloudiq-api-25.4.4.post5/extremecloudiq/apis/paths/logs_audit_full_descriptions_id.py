from extremecloudiq.paths.logs_audit_full_descriptions_id.get import ApiForget


class LogsAuditFullDescriptionsId(
    ApiForget,
):
    pass
