from extremecloudiq.paths.devices_client_monitor_revoke.post import ApiForpost


class DevicesClientMonitorRevoke(
    ApiForpost,
):
    pass
