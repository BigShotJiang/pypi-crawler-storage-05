from extremecloudiq.paths.copilot_anomalies_anomalies_by_category.get import ApiForget


class CopilotAnomaliesAnomaliesByCategory(
    ApiForget,
):
    pass
