from extremecloudiq.paths.locations_wall_type.get import ApiForget
from extremecloudiq.paths.locations_wall_type.post import ApiForpost


class LocationsWallType(
    ApiForget,
    ApiForpost,
):
    pass
