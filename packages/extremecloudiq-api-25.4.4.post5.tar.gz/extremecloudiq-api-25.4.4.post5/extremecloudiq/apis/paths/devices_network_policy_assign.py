from extremecloudiq.paths.devices_network_policy_assign.post import ApiForpost


class DevicesNetworkPolicyAssign(
    ApiForpost,
):
    pass
