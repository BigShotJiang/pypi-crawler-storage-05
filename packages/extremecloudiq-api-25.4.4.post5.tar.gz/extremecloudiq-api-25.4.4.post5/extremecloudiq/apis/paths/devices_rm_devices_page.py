from extremecloudiq.paths.devices_rm_devices_page.post import ApiForpost


class DevicesRmDevicesPage(
    ApiForpost,
):
    pass
