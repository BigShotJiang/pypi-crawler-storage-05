from extremecloudiq.paths.locations_floorplan.post import ApiForpost


class LocationsFloorplan(
    ApiForpost,
):
    pass
