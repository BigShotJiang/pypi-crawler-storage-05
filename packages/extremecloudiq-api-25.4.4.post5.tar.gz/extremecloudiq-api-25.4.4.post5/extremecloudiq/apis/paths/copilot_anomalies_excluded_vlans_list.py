from extremecloudiq.paths.copilot_anomalies_excluded_vlans_list.get import ApiForget


class CopilotAnomaliesExcludedVlansList(
    ApiForget,
):
    pass
