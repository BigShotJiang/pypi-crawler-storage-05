from extremecloudiq.paths.dashboard_device_types.get import ApiForget


class DashboardDeviceTypes(
    ApiForget,
):
    pass
