from extremecloudiq.paths.network_scorecard_wifi_health_location_id.get import ApiForget


class NetworkScorecardWifiHealthLocationId(
    ApiForget,
):
    pass
