from extremecloudiq.paths.dashboard_wired_client_health_port_congestion.post import ApiForpost


class DashboardWiredClientHealthPortCongestion(
    ApiForpost,
):
    pass
