from extremecloudiq.paths.dashboard_reports_id.get import ApiForget


class DashboardReportsId(
    ApiForget,
):
    pass
