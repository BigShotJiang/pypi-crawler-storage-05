from extremecloudiq.paths.dashboard_wired_client_health_ip_connectivity_issues.post import ApiForpost


class DashboardWiredClientHealthIpConnectivityIssues(
    ApiForpost,
):
    pass
