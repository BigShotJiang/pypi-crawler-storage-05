from extremecloudiq.paths.dashboard_wired_usage_capacity_grid.post import ApiForpost


class DashboardWiredUsageCapacityGrid(
    ApiForpost,
):
    pass
