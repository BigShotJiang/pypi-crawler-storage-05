from extremecloudiq.paths.dashboard_wired_client_health_traffic_anomalies.post import ApiForpost


class DashboardWiredClientHealthTrafficAnomalies(
    ApiForpost,
):
    pass
