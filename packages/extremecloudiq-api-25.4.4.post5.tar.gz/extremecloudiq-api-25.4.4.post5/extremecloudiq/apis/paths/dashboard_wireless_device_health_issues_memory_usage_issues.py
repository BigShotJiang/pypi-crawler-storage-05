from extremecloudiq.paths.dashboard_wireless_device_health_issues_memory_usage_issues.post import ApiForpost


class DashboardWirelessDeviceHealthIssuesMemoryUsageIssues(
    ApiForpost,
):
    pass
