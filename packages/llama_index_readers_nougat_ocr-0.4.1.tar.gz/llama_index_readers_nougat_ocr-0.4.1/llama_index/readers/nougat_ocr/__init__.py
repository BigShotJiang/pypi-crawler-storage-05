from llama_index.readers.nougat_ocr.base import PDFNougatOCR

__all__ = ["PDFNougatOCR"]
