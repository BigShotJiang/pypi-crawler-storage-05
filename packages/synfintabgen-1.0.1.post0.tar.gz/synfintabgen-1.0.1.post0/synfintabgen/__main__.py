from synfintabgen.execute_from_command_line import execute_from_command_line

if __name__ == "__main__":
    execute_from_command_line()
