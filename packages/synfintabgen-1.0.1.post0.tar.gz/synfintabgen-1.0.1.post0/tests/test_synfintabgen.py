import unittest


class TestSynFinTabGen(unittest.TestCase):
    pass
