"""
Package to evaluate a predicted segmentation.
"""

__version__ = "5.3.1"
