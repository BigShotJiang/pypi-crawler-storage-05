from nominal.cli import nom

if __name__ == "__main__":
    nom()
