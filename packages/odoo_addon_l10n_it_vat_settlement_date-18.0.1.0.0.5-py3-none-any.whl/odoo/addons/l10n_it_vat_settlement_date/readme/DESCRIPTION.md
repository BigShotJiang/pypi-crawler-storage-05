**Italiano**

Aggiunge la data competenza IVA per le fatture fornitori.

**English**

Add settlement date for bills.
