# LlamaIndex Index_Store Integration: Redis Index Store
