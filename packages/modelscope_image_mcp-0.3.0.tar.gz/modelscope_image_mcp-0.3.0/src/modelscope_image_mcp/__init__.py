"""ModelScope 图片生成 MCP Server"""
__version__ = "0.1.0"