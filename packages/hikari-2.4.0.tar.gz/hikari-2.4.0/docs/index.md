---
title: Home
description: hikari documentation
hide:
  - navigation
---

--8<-- "README.md"
