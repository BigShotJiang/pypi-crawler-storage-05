---
title: Changelog
description: Learn what the latest changes are!
hide:
  - navigation
---

!!! warning
    Major and minor releases also include the changes specified in prior development releases.

:: towncrier-draft

--8<-- "CHANGELOG.md"
