# Changelog fragments

This folder holds the fragments of the changelog to later build the final version with `towncrier`.

To preview the latest changelog, run `towncrier --draft`.
