# MapTasker

## Display the Tasker Project/Profile/Task/Scene hierarchy on a desktop based on Tasker's backup or exported XML file (e.g. backup.xml)

This is an application in support of [Tasker](https://tasker.joaoapps.com/) that is intended to run on a MAC/PC/Linux/Win11 desktop.

An older version, which requires Python version 3.10 rather than 3.11 or higher, is available as version 2.6.3...
    `pip install maptasker==2.6.3`

For further details, refer to [the project on Github.](https://github.com/mctinker/Map-Tasker)
