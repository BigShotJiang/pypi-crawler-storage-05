<!-- Copyright © SixtyFPS GmbH <info@slint.dev> ; SPDX-License-Identifier: MIT OR Apache-2.0 -->

# Changelog

## [0.1.5] - 2024-03-14

 - Warning fixes

## [0.1.4] - 2024-02-20

 - Warning fixes

## [0.1.3] - 2023-04-03

 - Upgraded syn to syn 2

## [0.1.2] - 2021-11-24

### Changed
 - Fixed `FieldOffsets` derive macro on non-pub structs when one of its pub field expose a private type
 - Added intra docs link in the generated documentation


## [0.1.1] - 2021-08-16

### Changed
 - Fixed a bunch of clippy warnings


## [0.1.0] - 2020-08-26 (1138c9dbedd13ba110e0953b0f501beb57a18309)
 - Initial release.
