<!-- Copyright © SixtyFPS GmbH <info@slint.dev> ; SPDX-License-Identifier: MIT OR Apache-2.0 -->

# const-field-offset crate

[![Crates.io](https://img.shields.io/crates/v/const-field-offset)](https://crates.io/crates/const-field-offset)
[![Docs.rs](https://docs.rs/const-field-offset/badge.svg)](https://docs.rs/const-field-offset)

This crate expose the FieldOffsets derive macro and the types it uses

Check the [crate documentation](https://docs.rs/const-field-offset) for more details.
