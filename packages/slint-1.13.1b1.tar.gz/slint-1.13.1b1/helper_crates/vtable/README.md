<!-- Copyright © SixtyFPS GmbH <info@slint.dev> ; SPDX-License-Identifier: MIT OR Apache-2.0 -->

# `vtable` crate

[![Crates.io](https://img.shields.io/crates/v/vtable)](https://crates.io/crates/vtable)
[![Docs.rs](https://docs.rs/vtable/badge.svg)](https://docs.rs/vtable)

A macro to create ffi-friendly virtual tables.

Check the [crate documentation](https://docs.rs/vtable) for more details.
