# Tests for streamlit-tetrascience-ui data app providers
