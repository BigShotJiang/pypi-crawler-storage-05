from streamlit_tetrascience_ui.py_components.organisms.scatter_graph import *
