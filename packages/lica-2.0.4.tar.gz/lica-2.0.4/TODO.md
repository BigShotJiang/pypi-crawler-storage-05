* Versioned database open
 - A in iterator class ??
* raw.loader.
- imagetyp heuristic
- Necessary copy() on load, if then stacked?
