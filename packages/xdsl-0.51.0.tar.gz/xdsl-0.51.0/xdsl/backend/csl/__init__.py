"""
CSL is the language used to program for the Cerebras Wafer Scale Engine (WSE) a wafer-parallel compute accelerator.

See external [documentation](https://sdk.cerebras.net/).
"""
