"""File-backed key provider."""

from .FileKeyProvider import FileKeyProvider

__all__ = ["FileKeyProvider"]
