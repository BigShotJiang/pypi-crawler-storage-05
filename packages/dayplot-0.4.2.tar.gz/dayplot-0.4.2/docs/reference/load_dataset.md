# Load dataset

`dayplot` provides a minimalist dataset with daily data, primarily for use in documentation.

<br>

::: dayplot.load_dataset