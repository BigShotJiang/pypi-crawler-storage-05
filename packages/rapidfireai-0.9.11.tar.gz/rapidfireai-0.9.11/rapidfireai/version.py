"""
Version information for RapidFire AI
"""

__version__ = "0.9.11"
__version_info__ = (0, 9, 11) 