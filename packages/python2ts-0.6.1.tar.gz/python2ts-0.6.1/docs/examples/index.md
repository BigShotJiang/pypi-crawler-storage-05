# Examples

This is a collection of examples that demonstrate how to use `py2ts` in real-world scenarios.

```{toctree}
---
maxdepth: 1
---

./flask_quart
```