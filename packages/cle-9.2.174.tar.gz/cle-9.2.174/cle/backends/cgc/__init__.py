from __future__ import annotations

from .backedcgc import BackedCGC
from .cgc import CGC

__all__ = ["CGC", "BackedCGC"]
