"""
Insurance analysis templates.
"""

from .risk_analysis import RiskAnalysisTemplate

__all__ = ['RiskAnalysisTemplate']