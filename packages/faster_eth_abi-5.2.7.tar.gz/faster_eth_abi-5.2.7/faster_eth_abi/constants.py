from typing import (
    Final,
)

TT256: Final = 2**256
TT256M1: Final = 2**256 - 1
TT255: Final = 2**255
