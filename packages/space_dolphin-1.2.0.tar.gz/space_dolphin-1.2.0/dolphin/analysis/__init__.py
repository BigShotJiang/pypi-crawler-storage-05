# -*- coding: utf-8 -*-

from .output import Output

__all__ = ["Output"]
