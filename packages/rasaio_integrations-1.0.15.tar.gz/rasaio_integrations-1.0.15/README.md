# rasa.io integrations

Python class to integrate rasa.io and another customer database