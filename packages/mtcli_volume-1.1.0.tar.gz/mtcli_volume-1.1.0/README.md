# mtcli-volume
  
Plugin mtcli para calcular e exibir o volume profile.
  
---
  
## Instalação
  
```bash
git clone git@github.com:vfranca/mtcli-volume.git
cd mtcli-volume
pip install .
```



