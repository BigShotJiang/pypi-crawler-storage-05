"""Tests for jupyter-server-docs-mcp package."""
