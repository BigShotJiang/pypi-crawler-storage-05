"""SQLBot: Database Query Bot with AI-powered natural language processing."""

__version__ = "0.2.0"
__author__ = "SQLBot Team"
__email__ = "team@qbot.dev"

from .repl import main

__all__ = ["main"]