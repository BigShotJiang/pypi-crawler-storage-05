from .sector_competitors import *
