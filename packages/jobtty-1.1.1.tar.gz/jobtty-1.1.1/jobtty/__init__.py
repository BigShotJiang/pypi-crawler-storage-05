"""
Jobtty.io - Terminal Job Board
🚀 Find your next role from the command line
"""

__version__ = "1.1.1"
__author__ = "Croscom Software"
__email__ = "konrad@croscomsoftware.com"