from __future__ import annotations

from .scale_wind_speed_log import scale_wind_speed_log

__all__ = [
    "scale_wind_speed_log",
]
