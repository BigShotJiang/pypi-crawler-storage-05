.. include:: ./readme.rst

Getting Started
===============

.. toctree::
   :maxdepth: 2

   installation

Usage
=====

.. toctree::
   :maxdepth: 2

   documentation/index

Contributing
============

.. toctree::
   :maxdepth: 2

   contributing
   authors


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
