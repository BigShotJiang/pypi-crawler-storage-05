dwind.resource
==============

.. automodule:: dwind.resource
   :members:

   .. rubric:: Classes

   .. autosummary::

      ResourcePotential
