dwind.config
============

.. automodule:: dwind.config
    :members:

    .. rubric:: Classes

    .. autosummary::

        ValuesMixin
        CRBModel
        Optimization
        Scenario
        Sector
        Technology
        Year
        Mapping
        Configuration
