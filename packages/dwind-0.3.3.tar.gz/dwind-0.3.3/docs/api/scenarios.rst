dwind.scenarios
===============

.. automodule:: dwind.scenarios
   :members:

   .. rubric:: Functions

   .. autosummary::

      config_cambium
      config_costs
      config_financial
      config_nem
      config_performance
