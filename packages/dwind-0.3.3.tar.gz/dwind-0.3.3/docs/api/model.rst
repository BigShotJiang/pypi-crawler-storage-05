dwind.model
===========

.. automodule:: dwind.model
   :members:


   .. rubric:: Classes

   .. autosummary::

      Agents
      Model
