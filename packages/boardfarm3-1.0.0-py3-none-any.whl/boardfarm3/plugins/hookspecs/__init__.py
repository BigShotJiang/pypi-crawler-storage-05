"""Boardfarm plugin hookspecs."""
