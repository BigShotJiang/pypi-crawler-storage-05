"""Boardfarm v3 base device shell prompts."""

DEFAULT_BASH_SHELL_PROMPT_PATTERN = "[\\w-]+@[\\w-]+:[\\w/~]+#"
LINUX_WAN_BASH_SHELL_PROMPT = "root@[\\w-]+:[\\w/~]+#"
KEA_PROVISIONER_SHELL_PROMPT = "[\\w-]+@[\\w-]+:[\\w/~]+#"
