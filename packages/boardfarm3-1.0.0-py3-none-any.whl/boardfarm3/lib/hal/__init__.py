"""Hardware abstraction layers for different CPE components."""
