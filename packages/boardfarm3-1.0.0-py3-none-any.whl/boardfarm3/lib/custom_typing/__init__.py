"""Boardfarm3 custom type hints package."""
