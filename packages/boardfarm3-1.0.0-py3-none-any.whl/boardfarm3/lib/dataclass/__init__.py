"""Boardfarm3 dataclasses.

These are used to store/load information required by usecases.
"""
