"""Use cases to interact with devices."""
