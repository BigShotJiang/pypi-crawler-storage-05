from zope.i18nmessageid import MessageFactory


_ = MessageFactory('testproj')

testmessage = _('Message from Python')
