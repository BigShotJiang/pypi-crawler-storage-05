This module adds a button on debit / payment orders to send an email to
each related partner with the details of their transactions.
