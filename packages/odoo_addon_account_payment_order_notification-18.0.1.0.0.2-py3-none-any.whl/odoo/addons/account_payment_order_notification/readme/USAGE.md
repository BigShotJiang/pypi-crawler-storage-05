1.  Go to *Invoicing \> Customers \> Invoices* and create one or more
    invoices linked to the payment mode.
2.  Go to *Invoicing \> Customers \> Invoices* select the invoices
    created and execute the action called "Post entries".
3.  Go to *Invoicing \> Customers \> Invoices* select the invoices
    created and execute the action called "Add to Payment/Debit Order"
    and create a payment order.
4.  Click on "Confirm Payments" button.
5.  Click on "Generate Payment File" button.
6.  Click on "File Successfully Uploaded" button.
7.  Click on "Send mails" button.
8.  Any involved partner with no email will appear with the column "To
    send" not checked.
9.  Click on "Confirm" button.
10. An email will have been sent to the selected partners.
11. A reminder note will have been created.
