To configure this module, you need to:

1.  Go to *Invoicing \> Configuration \> Payment Modes* and create a
    payment mode, if you wish.

2.  Go to *Invoicing \> Customers \> Customers* and create a new record as follows:  
    - Name: Test customer 1
    - Email: <customer1@test.com>

3.  Go to *Invoicing \> Customers \> Customers* and create a new record as follows:  
    - Name: Test customer 2
    - Email: (empty)
