"""Module for utility functions"""
