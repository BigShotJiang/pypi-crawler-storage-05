"""Learning vision for cells"""
