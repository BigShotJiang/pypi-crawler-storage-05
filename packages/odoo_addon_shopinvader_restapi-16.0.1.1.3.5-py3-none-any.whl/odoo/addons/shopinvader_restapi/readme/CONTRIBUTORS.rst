* Sebastien BEAU <sebastien.beau@akretion.com>
* Simone Orsi <simone.orsi@camptocamp.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Raphaël Reverdy <raphael.reverdy@akretion.com>
* Kevin Khao <kevin.khao@akretion.com>
* Quentin Groulard <quentin.groulard@acsone.eu>
