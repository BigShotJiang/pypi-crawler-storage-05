The development of this module has been financially supported by:

* Akretion
* Adaptoo
* Encresdubuit
* Abilis
* Camptocamp
* Cosanum
* ACSONE
