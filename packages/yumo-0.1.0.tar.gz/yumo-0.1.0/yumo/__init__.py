"""
yumo
"""

from yumo.__about__ import __application__, __version__

__all__ = [
    "__application__",
    "__version__",
]
