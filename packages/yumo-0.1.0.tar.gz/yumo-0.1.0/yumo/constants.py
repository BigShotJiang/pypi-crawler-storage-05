DATA_PREPROCESS_METHODS = ("identity", "log_e", "log_10")
CMAPS = ("rainbow", "viridis", "coolwarm", "jet", "turbo", "magma")
DENOISE_METHODS = ("gaussian", "nearest_and_gaussian", "nearest")
