from importlib.metadata import version as _version

STREAMLIT_EXTRAS_VERSION_STRING: str = _version("streamlit_extras")
