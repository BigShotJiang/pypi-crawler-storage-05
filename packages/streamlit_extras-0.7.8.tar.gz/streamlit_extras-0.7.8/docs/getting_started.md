As easy as...

```
pip install streamlit-extras
```