🪢 streamlit-extras is in fact... a Streamlit Component!

## What's a Streamlit component?

Components are third-party modules that extend what’s possible with Streamlit.

## Show me more!

Visit the [components gallery](https://streamlit.io/components) to discover even more components, and learn how to build your own using this great [blog post](https://blog.streamlit.io/how-to-build-your-own-streamlit-component/)
by Zachary.