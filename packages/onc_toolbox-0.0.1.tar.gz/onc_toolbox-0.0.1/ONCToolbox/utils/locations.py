


class BCFTerminal:
    class Tsawwassen:
        lat: float = 49.006621
        lon: float = -123.132309

    class DukePoint:
        lat: float = 49.162529
        lon: float = -123.891036

    class DepartureBay:
        lat: float = 49.193512
        lon: float = -123.954777

    class Gabriola:
        lat: float = 49.177846
        lon: float = -123.858655

    class NanaimoHarbor:
        lat: float = 49.166714
        lon: float = -123.930933

    class SwartzBay:
        lat: float = 48.689047
        lon: float = -123.410817

    class PortMcneil:
        lat: float = 50.592621
        lon: float = -127.085620

    class AlertBay:
        lat: float = 50.587972
        lon: float = -126.931313

    class Sointula:
        lat: float = 50.626701
        lon: float = -127.018700

    class HorseshoeBay:
        lat: float = 49.375791
        lon: float = -123.271643