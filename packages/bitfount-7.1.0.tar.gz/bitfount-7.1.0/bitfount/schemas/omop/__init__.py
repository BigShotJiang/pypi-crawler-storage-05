"""OMOP schemas.

The bitfount version and schema version in the schema metadata are not used upstream
anywhere but have nevertheless been set to the last version of bitfount/schema that
supported multitable schemas.
"""
