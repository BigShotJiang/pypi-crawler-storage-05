"""Symmetric and asymmetric encryption functions.

:::warning

This import location is deprecated and will be removed in a future version.

Please use the `bitfount.encryption.encryption` module instead.

:::
"""
