"""Protocols related to EHR interactions."""
