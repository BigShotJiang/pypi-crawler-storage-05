"""Protocols for remote/federated model training on data."""

from __future__ import annotations
