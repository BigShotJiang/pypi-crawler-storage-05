"""Packages and modules related to NextGen systems interactions."""
