from ...private_eye.heidelberg.e2e_parser import HeidelbergE2EParser
from ...private_eye.heidelberg.heidelberg_parser import HeidelbergParser
from ...private_eye.heidelberg.parser.segment.series_info import SeriesInfoSegment
