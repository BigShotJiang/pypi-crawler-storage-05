# Prisma SDK

A lightweight Python SDK to interact with the Prisma API.

## Installation

```bash
pip install prisma-sdk
