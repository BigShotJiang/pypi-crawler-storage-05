from pathlib import Path

SERVER_DIR = (Path(__file__).resolve().parent / "server").absolute()
TASKS_DIR = (Path(__file__).resolve().parent.parent / "tasks").absolute()
