import arguably


@arguably.command  # type: ignore
def project():
    """
    Commands to run on automation projects.
    """

    pass
