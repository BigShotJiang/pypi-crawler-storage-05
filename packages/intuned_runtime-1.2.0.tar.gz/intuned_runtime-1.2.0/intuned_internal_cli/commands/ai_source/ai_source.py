import arguably


@arguably.command  # type: ignore
def ai_source():
    """
    Commands to run on AI source projects.
    """

    pass
