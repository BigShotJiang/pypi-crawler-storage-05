"""API components for the bricks-and-graphs framework."""

from typing import Final

__all__: Final[list[str]] = []
