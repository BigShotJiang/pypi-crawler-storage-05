"""Tests for example code."""
