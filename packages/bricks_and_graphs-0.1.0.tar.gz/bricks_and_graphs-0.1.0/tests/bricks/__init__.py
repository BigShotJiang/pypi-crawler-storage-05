"""Tests for built-in bricks."""
