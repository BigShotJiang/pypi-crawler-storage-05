"""Tests for bricks-and-graphs."""
