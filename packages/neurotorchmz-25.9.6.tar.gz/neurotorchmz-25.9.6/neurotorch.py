# This file is the main entry point into NeurotorchMZ
#
# © Andreas Brilka 2024-2025
#

import neurotorchmz
neurotorchmz.start()