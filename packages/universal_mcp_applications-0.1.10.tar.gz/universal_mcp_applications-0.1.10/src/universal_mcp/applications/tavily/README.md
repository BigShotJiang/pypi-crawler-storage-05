# Tavily MCP Server

An MCP Server for the Tavily API.

## 🛠️ Tool List

This is automatically generated from OpenAPI schema for the Tavily API.


| Tool | Description |
|------|-------------|
| `search` | Performs a web search using Tavily's search API and returns either a direct answer or a summary of top results. |
