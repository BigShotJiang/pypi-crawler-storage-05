Bryce Harrington <bryce@canonical.com>
Athos Ribeiro <athos.ribeiro@canonical.com>
Christian Ehrhardt <christian.ehrhardt@canonical.com>
Andy P. Whitcroft <apw@shadowen.org>
Massimiliano Girardi <mp+443747@code.launchpad.net>
Simon Chopin <simon.chopin@canonical.com>
