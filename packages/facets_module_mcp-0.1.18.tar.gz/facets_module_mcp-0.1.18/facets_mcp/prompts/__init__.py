# This package contains prompts for module creation.
