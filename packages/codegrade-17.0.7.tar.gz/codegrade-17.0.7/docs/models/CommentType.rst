CommentType
===========

.. currentmodule:: codegrade.models.comment_type

.. class:: CommentType

**Options**

* ``normal``
* ``peer_feedback``
