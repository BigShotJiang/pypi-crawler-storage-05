LtiRoleSwitchingSetting
=======================

.. currentmodule:: codegrade.models.lti_role_switching_setting

.. autoclass:: LtiRoleSwitchingSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
