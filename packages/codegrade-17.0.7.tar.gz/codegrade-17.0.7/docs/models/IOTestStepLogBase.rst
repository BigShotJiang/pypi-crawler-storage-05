IOTestStepLogBase
=================

.. currentmodule:: codegrade.models.io_test_step_log_base

.. autoclass:: IOTestStepLogBase
   :members: state, created_at
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
