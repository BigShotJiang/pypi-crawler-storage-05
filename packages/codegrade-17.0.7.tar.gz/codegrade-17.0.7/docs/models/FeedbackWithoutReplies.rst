FeedbackWithoutReplies
======================

.. currentmodule:: codegrade.models.feedback_without_replies

.. autoclass:: FeedbackWithoutReplies
   :members: type, user, authors
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
