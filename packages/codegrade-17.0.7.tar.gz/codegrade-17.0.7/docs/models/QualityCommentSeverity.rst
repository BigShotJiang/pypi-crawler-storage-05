QualityCommentSeverity
======================

.. currentmodule:: codegrade.models.quality_comment_severity

.. class:: QualityCommentSeverity

**Options**

* ``info``
* ``warning``
* ``error``
* ``fatal``
