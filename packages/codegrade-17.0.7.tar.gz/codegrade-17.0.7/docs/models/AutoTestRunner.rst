AutoTestRunner
==============

.. currentmodule:: codegrade.models.auto_test_runner

.. autoclass:: AutoTestRunner
   :members: state
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
