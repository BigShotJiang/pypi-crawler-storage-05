CommentReplyType
================

.. currentmodule:: codegrade.models.comment_reply_type

.. class:: CommentReplyType

**Options**

* ``plain_text``
* ``markdown``
