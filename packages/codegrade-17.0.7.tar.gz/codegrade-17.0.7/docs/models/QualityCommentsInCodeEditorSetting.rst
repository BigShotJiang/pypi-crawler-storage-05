QualityCommentsInCodeEditorSetting
==================================

.. currentmodule:: codegrade.models.quality_comments_in_code_editor_setting

.. autoclass:: QualityCommentsInCodeEditorSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
