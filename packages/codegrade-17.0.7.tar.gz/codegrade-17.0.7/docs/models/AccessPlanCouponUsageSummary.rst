AccessPlanCouponUsageSummary
============================

.. currentmodule:: codegrade.models.access_plan_coupon_usage_summary

.. autoclass:: AccessPlanCouponUsageSummary
   :members: scope, plan
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
