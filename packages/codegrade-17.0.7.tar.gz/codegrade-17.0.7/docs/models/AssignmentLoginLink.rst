AssignmentLoginLink
===================

.. currentmodule:: codegrade.models.assignment_login_link

.. autoclass:: AssignmentLoginLink
   :members: id, assignment, user, time_to_start
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
