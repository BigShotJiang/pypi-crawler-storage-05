AnyNonRedactedAutoTestStepAsJSON
================================

.. currentmodule:: codegrade.models.any_non_redacted_auto_test_step_as_json

.. autoclass:: AnyNonRedactedAutoTestStepAsJSON
   :members: redacted
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
