BaseCouponWithCode
==================

.. currentmodule:: codegrade.models.base_coupon_with_code

.. autoclass:: BaseCouponWithCode
   :members: type, code
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
