CreateDivisionResult
====================

.. currentmodule:: codegrade.models.create_division_result

.. autoclass:: CreateDivisionResult
   :members: section, division
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
