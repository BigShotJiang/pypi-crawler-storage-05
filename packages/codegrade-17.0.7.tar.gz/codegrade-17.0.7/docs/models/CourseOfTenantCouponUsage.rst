CourseOfTenantCouponUsage
=========================

.. currentmodule:: codegrade.models.course_of_tenant_coupon_usage

.. autoclass:: CourseOfTenantCouponUsage
   :members: id, tenant_id, name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
