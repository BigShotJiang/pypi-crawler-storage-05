RubricItemInputAsJSON
=====================

.. currentmodule:: codegrade.models.rubric_item_input_as_json

.. autoclass:: RubricItemInputAsJSON
   :members: id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
