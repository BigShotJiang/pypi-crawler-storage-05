NotificationSettingOption
=========================

.. currentmodule:: codegrade.models.notification_setting_option

.. autoclass:: NotificationSettingOption
   :members: reason, explanation, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
