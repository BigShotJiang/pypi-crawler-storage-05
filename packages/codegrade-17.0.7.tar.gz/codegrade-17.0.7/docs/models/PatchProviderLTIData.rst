PatchProviderLTIData
====================

.. currentmodule:: codegrade.models.patch_provider_lti_data

.. autoclass:: PatchProviderLTIData
   :members: label
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
