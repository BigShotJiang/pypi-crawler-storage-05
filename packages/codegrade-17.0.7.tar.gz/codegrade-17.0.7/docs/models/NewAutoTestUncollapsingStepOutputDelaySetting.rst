NewAutoTestUncollapsingStepOutputDelaySetting
=============================================

.. currentmodule:: codegrade.models.new_auto_test_uncollapsing_step_output_delay_setting

.. autoclass:: NewAutoTestUncollapsingStepOutputDelaySetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
