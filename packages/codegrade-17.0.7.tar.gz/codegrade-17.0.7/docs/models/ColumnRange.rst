ColumnRange
===========

.. currentmodule:: codegrade.models.column_range

.. autoclass:: ColumnRange
   :members: start, end
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
