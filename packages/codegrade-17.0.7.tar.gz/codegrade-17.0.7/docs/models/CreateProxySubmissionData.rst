CreateProxySubmissionData
=========================

.. currentmodule:: codegrade.models.create_proxy_submission_data

.. autoclass:: CreateProxySubmissionData
   :members: allow_remote_resources, allow_remote_scripts, teacher_revision
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
