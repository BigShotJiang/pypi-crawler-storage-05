RubricAnalyticsDataRow
======================

.. currentmodule:: codegrade.models.rubric_analytics_data_row

.. autoclass:: RubricAnalyticsDataRow
   :members: item_id, multiplier
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
