CreateGroupGroupSetData
=======================

.. currentmodule:: codegrade.models.create_group_group_set_data

.. autoclass:: CreateGroupGroupSetData
   :members: member_ids, name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
