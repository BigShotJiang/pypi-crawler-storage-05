CodeQualityPenalties
====================

.. currentmodule:: codegrade.models.code_quality_penalties

.. autoclass:: CodeQualityPenalties
   :members: fatal, error, warning, info
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
