AutoTestUnitTestMessageSetting
==============================

.. currentmodule:: codegrade.models.auto_test_unit_test_message_setting

.. autoclass:: AutoTestUnitTestMessageSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
