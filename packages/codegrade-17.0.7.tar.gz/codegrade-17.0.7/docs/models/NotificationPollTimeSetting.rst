NotificationPollTimeSetting
===========================

.. currentmodule:: codegrade.models.notification_poll_time_setting

.. autoclass:: NotificationPollTimeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
