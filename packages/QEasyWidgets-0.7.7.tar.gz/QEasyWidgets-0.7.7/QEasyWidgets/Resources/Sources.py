# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.8.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x01\xf8\
P\
rogressBarBase {\
\x0d\x0a\x09text-align: c\
enter;\x0d\x0a    colo\
r: black;\x0d\x0a\x09back\
ground-color: rg\
ba(24, 24, 24, 6\
);\x0d\x0a    border: \
1.2px solid rgba\
(54, 45, 33, 12)\
;\x0d\x0a    border-ra\
dius: 3px;\x0d\x0a}\x0d\x0aP\
rogressBarBase[i\
sBorderless=true\
] {\x0d\x0a    padding\
: 1.2px;\x0d\x0a\x09borde\
r: none;\x0d\x0a}\x0d\x0aPro\
gressBarBase[isT\
ransparent=true]\
 {\x0d\x0a\x09background-\
color: transpare\
nt;\x0d\x0a}\x0d\x0a\x0d\x0aProgre\
ssBarBase::chunk\
 {\x0d\x0a\x09background-\
color: qlineargr\
adient(spread: p\
ad, x1:0, y1:0, \
x2:1, y2:0, stop\
:0 transparent, \
stop:1 rgba(120,\
 180, 240, 123))\
;\x0d\x0a    border: n\
one;\x0d\x0a}\
\x00\x00\x02K\
\x00\
\x00\x07\xcbx\xda\x95UM\x8f\xda0\x10=\x17\x89\xff\
\xe0#\xac`7\x1f\x80\xa8W\xbdp\xdaK+\xad\xc4\
\xad\xea\xc1\x89\xdd`\xad\xd7Nmg\x81V\xfc\xf7\xda\
q>\x1cB\x80%\xc2r\xec\x99\xe77\xe37\x93M\
\xa1\xb5\xe0\x1b\xa4\x08\xf87\x1e\x01\xf3K\x05\x13\x12\x02\
\x99%\x93\xc5r\x06\xe2x\x06\xa2p\xfa<\x1e}y\
z\xd0\xe4\xa0\xe7\x88\xd1\x8cC\x90\x12\xae\x89|~x\
2;\x09J\xdf2)\x0a\x8e\xe7\xad;\x9aD\x0b\xe3\
[\xfdW\x16\xc2\xe2\xe7\x08c\xca3\x08\x16\x8f\xeb\xfc\
\x00\xc2\xc8\x0c\xabjR\x99$Bbb@\xc2G\xbb\
\xa9\x04\xa3\xd8\x01.\x0dPM*\x8c\xa6\x1d\xf3y\x22\
L(\xef\x1d\x02\xbe\xfdb]\x06Q\x19K\x84i\xa1\
 \x88\x9bCE\xa1\x19\xe5\x04\x02.81k\xa7\xf1\
h\xd3$\xe7'U\x9b\xd2\x91\x11\xa5\xbeiY\x90_\
u\xbe\x9axJ\xb6\xed\x11\x83@[\x89\xb8\xca\x914\
\xf9k\x91.\xa4P\xb7v\xe7(p'>\x88\x1c\xf0\
\xeb\xa5\xdee\xaa\x0b\x90K\x13\x08\xc13\xe0\xad\xa5;\
\x92\xbe\x11\x5c\xc2\xfaX\xad\x0c,V|;\xeda\x14\
\x18\xcbu`\x8f/\x87U\x9f\x00\xa6\x0a%\xec\xc6i\
_\x83\xca\xd1>\xdf\x09/\x1c\xc0\x0c\xbc\x08\xc6\xc4\xde\
\xbd\xdd\x95\xbe\xfa\xde\xf7\x14\xeb]\xef\xae\xe6J\x1f\x99\
\xb9\xfaRj\xde\xf2\x90\x96\xaa,\x9c|R\xeeN\xba\
\xd4\xfc{\xba\x8e\x18\x85m\xa8-&x\xb5\xf3\x81\x00\
\xf7;\xaa\xc99\x0b\xe7\x01\xa1\xd9z\xbf\xa6\x8fN4\
\xcb\xb22*!\xcf\xb5\xc8\xeb\xbah\xd6\x18\xf9\xad\xa1\
-S\x7f\xd1\xdd|\xcfV\xd2l\xd7\x1a\xf7\x8b\xe12\
\xd9\xdb\x92v\xaa\xf2\x87\xe9U@E\x18Iu\xa5\xb0\
\xcfb\xda\xe7\x07\xfa\xa0\x19\xd2\xd4(\xb6\x15Z\xb7\x09\
\xda\xbc\x0c\xb5\xc0\xae\x00;\xad\x22\xe8\xb5\xba\xa0it\
\x97u[\xf7+\xe7y\xea\x93\xbb\x9a\xbf?\xb6\xb3!\
\x99Y\x14\x83;Q\xa6\xfc\x11\x86\x96\xd0\x0c\x1cBh\
B?\x96\xe3!\x82\xa6\xec\x8e\x91\x9d++\x84\xe0b\
E[\xfdW\x06\xa1Ox:\xc0\xcd\xef,\xf7V\xaa\
\x93\x5c\xdc\xfd\x00\x0cv\x96\xf3#M\x9f}\x11\x92\xfe\
\x15\x5c#\xe6\xda\xac\xcf\xe23\xa9\xf7d~\x17\x15\xfb\
\xbcn\x85`[\x9a\xdf\xfc\xa8\x96D\x06K\xfb\xack\
\x05\xd7z\xd6\xe9?}Y^\xd5\
\x00\x00\x01\x15\
Q\
Widget {\x0d\x0a    ba\
ckground-color: \
qlineargradient(\
spread: pad, x1:\
0, y1:0, x2:1, y\
2:0, stop:0 rgba\
(246, 246, 246, \
246), stop:1 rgb\
a(234, 234, 234,\
 246));\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0a\
QToolTip {\x0d\x0a    \
color: rgb(45, 3\
3, 21);\x0d\x0a    bac\
kground-color: w\
hite;\x0d\x0a\x09border-w\
idth: 0px;\x0d\x0a\x09bor\
der-style: solid\
;\x0d\x0a}\
\x00\x00\x01%\
C\
heckBoxBase {\x0d\x0a \
   background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0aCheckBoxBa\
se::indicator {\x0d\
\x0a    background-\
color: transpare\
nt;\x0d\x0a    border:\
 none;\x0d\x0a}\x0d\x0a\x0d\x0aChe\
ckBoxBase QLabel\
 {\x0d\x0a    color: b\
lack;\x0d\x0a    backg\
round-color: tra\
nsparent;\x0d\x0a    b\
order: none;\x0d\x0a}\x0d\
\x0aCheckBoxBase QL\
abel:disabled {\x0d\
\x0a    color: grey\
;\x0d\x0a}\
\x00\x00\x01\xcc\
T\
extBrowserBase {\
\x0d\x0a    color: rgb\
(45, 33, 21);\x0d\x0a\x09\
text-align: left\
;\x0d\x0a\x09selection-ba\
ckground-color: \
darkgrey;\x0d\x0a\x09back\
ground-color: tr\
ansparent;\x0d\x0a    \
padding: 1.2px;\x0d\
\x0a\x09border: none;\x0d\
\x0a\x09border-radius:\
 3px;\x0d\x0a}\x0d\x0aTextBr\
owserBase[isBord\
erless=false] {\x0d\
\x0a    padding: 0p\
x;\x0d\x0a    border: \
1.2px solid rgba\
(54, 45, 33, 123\
);\x0d\x0a}\x0d\x0aTextBrows\
erBase:hover {\x0d\x0a\
}\x0d\x0a\x0d\x0a\x0d\x0aQToolTip \
{\x0d\x0a    color: rg\
b(45, 33, 21);\x0d\x0a\
    background-c\
olor: white;\x0d\x0a\x09b\
order-width: 0px\
;\x0d\x0a\x09border-style\
: solid;\x0d\x0a}\
\x00\x00\x02E\
T\
oolBox {\x0d\x0a    ba\
ckground-color: \
transparent;\x0d\x0a  \
  padding: 0px;\x0d\
\x0a    border: non\
e;\x0d\x0a\x09border-radi\
us: 3px;\x0d\x0a}\x0d\x0a\x0d\x0aT\
oolPage {\x0d\x0a\x09back\
ground-color: tr\
ansparent;\x0d\x0a    \
border: none;\x0d\x0a}\
\x0d\x0a\x0d\x0aToolPage Fol\
der {\x0d\x0a    color\
: rgb(45, 33, 21\
);\x0d\x0a\x09text-align:\
 left;\x0d\x0a\x09backgro\
und-color: trans\
parent;\x0d\x0a\x09paddin\
g-top: 3px;\x0d\x0a\x09pa\
dding-left: 12px\
;\x0d\x0a\x09padding-bott\
om: 3px;\x0d\x0a\x09paddi\
ng-right: 6px;\x0d\x0a\
    border: none\
;\x0d\x0a}\x0d\x0aToolPage F\
older:hover {\x0d\x0a\x09\
background-color\
: rgba(54, 45, 3\
3, 12);\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0a\
QToolTip {\x0d\x0a    \
color: rgb(45, 3\
3, 21);\x0d\x0a    bac\
kground-color: w\
hite;\x0d\x0a\x09border-w\
idth: 0px;\x0d\x0a\x09bor\
der-style: solid\
;\x0d\x0a}\
\x00\x00\x01\xfa\
C\
hatWidgetBase {\x0d\
\x0a    background-\
color: transpare\
nt;\x0d\x0a    border:\
 none;\x0d\x0a\x09border-\
radius: 3px;\x0d\x0a}\x0d\
\x0aChatWidgetBase:\
hover {\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0a\
ChatWidgetBase Q\
Widget {\x0d\x0a    ba\
ckground-color: \
transparent;\x0d\x0a  \
  border: none;\x0d\
\x0a}\x0d\x0aChatWidgetBa\
se QWidget:hover\
 {\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aChatW\
idgetBase Messag\
eDisplay {\x0d\x0a    \
background-color\
: transparent;\x0d\x0a\
    padding: 12p\
x;\x0d\x0a}\x0d\x0aChatWidge\
tBase MessageDis\
play:hover {\x0d\x0a}\x0d\
\x0a\x0d\x0a\x0d\x0aQToolTip {\x0d\
\x0a    color: rgb(\
45, 33, 21);\x0d\x0a  \
  background-col\
or: white;\x0d\x0a\x09bor\
der-width: 0px;\x0d\
\x0a\x09border-style: \
solid;\x0d\x0a}\
\x00\x00\x02\x91\
L\
istBase {\x0d\x0a\x09/*te\
xt-align: center\
;*/\x0d\x0a\x09background\
-color: transpar\
ent;\x0d\x0a    paddin\
g: 1.2px;\x0d\x0a\x09bord\
er: none;\x0d\x0a\x09bord\
er-radius: 3px;\x0d\
\x0a    outline: no\
ne;\x0d\x0a}\x0d\x0aListBase\
[isBorderless=fa\
lse] {\x0d\x0a    padd\
ing: 0px;\x0d\x0a    b\
order: 1.2px sol\
id rgba(54, 45, \
33, 123);\x0d\x0a}\x0d\x0aLi\
stBase:hover {\x0d\x0a\
    border-color\
: rgba(54, 45, 3\
3, 210);\x0d\x0a}\x0d\x0a\x0d\x0aL\
istBase::item {\x0d\
\x0a    color: rgb(\
45, 33, 21);\x0d\x0a\x09b\
ackground-color:\
 transparent;\x0d\x0a \
   border: 2.4px\
 solid transpare\
nt;\x0d\x0a\x09padding: 2\
.4px;\x0d\x0a}\x0d\x0aListBa\
se::item:hover {\
\x0d\x0a\x09background-co\
lor: rgba(54, 45\
, 33, 12);\x0d\x0a}\x0d\x0aL\
istBase::item:se\
lected {\x0d\x0a\x09backg\
round-color: tra\
nsparent;\x0d\x0a\x09bord\
er-left-color: r\
gb(120, 180, 240\
);\x0d\x0a\x09/*padding-l\
eft: 1.2px;*/\x0d\x0a}\
\
\x00\x00\x03\xad\
L\
ineEditBase, Tex\
tEditBase {\x0d\x0a   \
 color: rgb(45, \
33, 21);\x0d\x0a\x09text-\
align: left;\x0d\x0a\x09s\
election-backgro\
und-color: darkg\
rey;\x0d\x0a\x09backgroun\
d-color: rgba(24\
, 24, 24, 6);\x0d\x0a \
   padding: 4.8p\
x 12px 6px 12px;\
\x0d\x0a    border: 1.\
2px solid rgba(5\
4, 45, 33, 12);\x0d\
\x0a    border-bott\
om: 1.2px solid \
rgba(54, 45, 33,\
 48);\x0d\x0a\x09border-r\
adius: 3px;\x0d\x0a   \
 outline: none;\x0d\
\x0a}\x0d\x0aLineEditBase\
[isBorderless=tr\
ue], TextEditBas\
e[isBorderless=t\
rue] {\x0d\x0a    padd\
ing: 1.2px;\x0d\x0a\x09bo\
rder: none;\x0d\x0a}\x0d\x0a\
LineEditBase[isT\
ransparent=true]\
, TextEditBase[i\
sTransparent=tru\
e] {\x0d\x0a\x09backgroun\
d-color: transpa\
rent;\x0d\x0a}\x0d\x0aLineEd\
itBase:hover, Te\
xtEditBase:hover\
 {\x0d\x0a\x09background-\
color: rgba(24, \
24, 24, 12);\x0d\x0a}\x0d\
\x0aLineEditBase:fo\
cus, TextEditBas\
e:focus {\x0d\x0a    b\
order-bottom-col\
or: rgba(120, 18\
0, 240, 246);\x0d\x0a}\
\x0d\x0aLineEditBase:d\
isabled, TextEdi\
tBase:disabled {\
\x0d\x0a\x09color: rgba(4\
5, 33, 21, 90);\x0d\
\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQToolTip\
 {\x0d\x0a    color: r\
gb(45, 33, 21);\x0d\
\x0a    background-\
color: white;\x0d\x0a\x09\
border-width: 0p\
x;\x0d\x0a\x09border-styl\
e: solid;\x0d\x0a}\
\x00\x00\x01I\
\x00\
\x00\x06\x01x\xda\xc5S[n\x830\x10\xfc.\x12w\
\xf0g\x22\x85\x8aW>\xea\x9c\x22\xea\x09\x0c\xb6\x8cU\
\x17#\x1b\xd2\xb4U\xee\xde-\xad\xa1\x09\xd8\xa5\x0f\xb5\
H \xb0vg\x98\xdd\x99\xfd\xad\x14\x94i\x5c)-\
\x9eT\xdd\x12\x89\x9e\xc3\x00\xc1U1\xc1\xab\x16\xa34\
o\x8e\xbb08\x85A\x18\xec\xdf\xab1\xd7J\x1d\x98\
\xa7+\xeb\x9b^O\x0aR\xdeAyW\xd3\xa8TR\
i\x8c4/\xc8*I\xb3\x0d\x1a\x1fi\x12\xafm\x83\
\xd2\xc0\x11iBEg,\xd2\xc9G\x8e\xa90\xa4\x90\
\x8c\xda\xbfX\xc6\x09\x8f\xf5D\x99\xe9\x8a\xa8!|N\
\xdb\x88\x8aQ!\xe1c\xe7\xd4\xec\x90\xf0\x81\xa7\x225\
\x95s,\x0f\x82\xb6\x15\x8c=\x1e\xd0.6q5\xab\
n\x95\xe60\xc5\xfe>\x1f$F\xc9u\xda\x1c\x91Q\
\xc0\xdcWn\xa1*\xdfnP\x969F\x9e\x8c\xdc\xf7\
DsQc\x14\xdd\x00D<Y\xc5D\x05\xbc\x1e\x98\
v\xef\xc1\xce\xcd\x0f\xd2hf\x8co\x9d\xcb`>\xb7\
\x05\xd7\xec\xd1\xaef\x84\x02\x05\xad(\xa7+\xf1$\xc1\
\xd1\xf2\x071\xb0\xcc\xbf\x19\x02B\xe9[\x08.e\xb9\
\x220\x95\xbb8\x01\xfea\x9f\xf9?\xfe?\xff\xc3I\
\x9f\x81y\xcf\x0d;\xf8\xbe\xfb\x07\x88\x9fx\xff\x0b^\
\xb0\xce\x7f\x01\xd5\xb4\xd1\xa5\
\x00\x00\x07\x0a\
C\
omboBoxBase {\x0d\x0a \
   color: rgb(45\
, 33, 21);\x0d\x0a\x09tex\
t-align: left;\x0d\x0a\
\x09selection-backg\
round-color: dar\
kgrey;\x0d\x0a\x09backgro\
und-color: rgba(\
24, 24, 24, 6);\x0d\
\x0a    padding: 4.\
8px 12px 6px 12p\
x;\x0d\x0a    border: \
1.2px solid rgba\
(54, 45, 33, 12)\
;\x0d\x0a    border-bo\
ttom: 1.2px soli\
d rgba(54, 45, 3\
3, 48);\x0d\x0a\x09border\
-radius: 3px;\x0d\x0a \
   outline: none\
;\x0d\x0a}\x0d\x0aComboBoxBa\
se[isBorderless=\
true] {\x0d\x0a    pad\
ding: 1.2px;\x0d\x0a\x09b\
order: none;\x0d\x0a}\x0d\
\x0aComboBoxBase[is\
Transparent=true\
] {\x0d\x0a\x09background\
-color: transpar\
ent;\x0d\x0a}\x0d\x0aComboBo\
xBase:hover {\x0d\x0a\x09\
background-color\
: rgba(24, 24, 2\
4, 12);\x0d\x0a}\x0d\x0aComb\
oBoxBase:focus {\
\x0d\x0a    border-bot\
tom-color: rgba(\
120, 180, 240, 2\
46);\x0d\x0a}\x0d\x0aComboBo\
xBase:disabled {\
\x0d\x0a\x09color: rgba(4\
5, 33, 21, 90);\x0d\
\x0a}\x0d\x0a\x0d\x0aComboBoxBa\
se::drop-down {\x0d\
\x0a\x09/*width: 12px;\
\x0d\x0a\x09height: 12px;\
*/\x0d\x0a\x09subcontrol-\
origin: padding;\
\x0d\x0a\x09subcontrol-po\
sition: right;\x0d\x0a\
\x09margin-right: 6\
px;\x0d\x0a\x09border: no\
ne;\x0d\x0a}\x0d\x0a\x0d\x0aComboB\
oxBase::down-arr\
ow {\x0d\x0a\x09border-im\
age: url(:/Icons\
/Icons/Light/Che\
vron-Down.svg);\x0d\
\x0a}\x0d\x0aComboBoxBase\
::down-arrow:on \
{\x0d\x0a\x09border-image\
: url(:/Icons/Ic\
ons/Light/Chevro\
n-Up.svg);\x0d\x0a}\x0d\x0a\x0d\
\x0a\x0d\x0aComboBoxBase \
QAbstractItemVie\
w {\x0d\x0a\x09background\
-color: white;\x0d\x0a\
\x09border: 1.2px s\
olid rgba(54, 45\
, 33, 123);\x0d\x0a\x09ou\
tline: none;\x0d\x0a}\x0d\
\x0aComboBoxBase QA\
bstractItemView[\
isBorderless=tru\
e] {\x0d\x0a    paddin\
g: 1.2px;\x0d\x0a\x09bord\
er: none;\x0d\x0a}\x0d\x0aCo\
mboBoxBase QAbst\
ractItemView[isT\
ransparent=true]\
 {\x0d\x0a\x09background-\
color: transpare\
nt;\x0d\x0a}\x0d\x0a\x0d\x0aComboB\
oxBase QAbstract\
ItemView::item {\
\x0d\x0a    color: rgb\
(45, 33, 21);\x0d\x0a\x09\
background-color\
: rgba(54, 45, 3\
3, 15);\x0d\x0a\x09paddin\
g: 3px 6px;\x0d\x0a\x09bo\
rder: none;\x0d\x0a}\x0d\x0a\
ComboBoxBase QAb\
stractItemView::\
item:hover {\x0d\x0a\x09b\
ackground-color:\
 rgba(123, 123, \
123, 123);\x0d\x0a}\x0d\x0aC\
omboBoxBase QAbs\
tractItemView::i\
tem:selected {\x0d\x0a\
\x09background-colo\
r: rgba(123, 123\
, 123, 123);\x0d\x0a}\x0d\
\x0a\x0d\x0a\x0d\x0aQToolTip {\x0d\
\x0a    color: rgb(\
45, 33, 21);\x0d\x0a  \
  background-col\
or: white;\x0d\x0a\x09bor\
der-width: 0px;\x0d\
\x0a\x09border-style: \
solid;\x0d\x0a}\
\x00\x00\x01\xd7\
G\
roupBoxBase {\x0d\x0a \
   color: rgb(45\
, 33, 21);\x0d\x0a\x09mar\
gin-top: 1.5ex;\x0d\
\x0a\x09background-col\
or: transparent;\
\x0d\x0a\x09border: 1.2px\
 solid transpare\
nt;\x0d\x0a\x09border-rad\
ius: 3px;\x0d\x0a}\x0d\x0a\x0d\x0a\
GroupBoxBase::ti\
tle {\x0d\x0a\x09subcontr\
ol-origin: margi\
n;\x0d\x0a\x09subcontrol-\
position: top le\
ft;\x0d\x0a\x09padding: 3\
px 9px 3px 6px;\x0d\
\x0a}\x0d\x0a\x0d\x0aGroupBoxBa\
se::indicator:ch\
ecked {\x0d\x0a\x09border\
-image: url(:/Ic\
ons/Icons/Light/\
Chevron-Down.svg\
);\x0d\x0a}\x0d\x0aGroupBoxB\
ase::indicator:u\
nchecked {\x0d\x0a\x09bor\
der-image: url(:\
/Icons/Icons/Lig\
ht/Chevron-Up.sv\
g);\x0d\x0a}\
\x00\x00\x00\xf0\
S\
crollAreaBase {\x0d\
\x0a\x09border: 0px so\
lid;\x0d\x0a\x09border-ra\
dius: 3px;\x0d\x0a}\x0d\x0aS\
crollAreaBase[is\
Borderless=true]\
 {\x0d\x0a    padding:\
 1.2px;\x0d\x0a\x09border\
: none;\x0d\x0a}\x0d\x0aScro\
llAreaBase[isTra\
nsparent=true] {\
\x0d\x0a\x09background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0aScrollArea\
Base:hover {\x0d\x0a}\
\x00\x00\x01\x1b\
L\
abelBase {\x0d\x0a    \
color: rgb(45, 3\
3, 21);\x0d\x0a    bac\
kground-color: t\
ransparent;\x0d\x0a   \
 padding: 0px;\x0d\x0a\
    border: none\
;\x0d\x0a\x09border-radiu\
s: 3px;\x0d\x0a}\x0d\x0aLabe\
lBase:hover {\x0d\x0a}\
\x0d\x0a\x0d\x0a\x0d\x0aQToolTip {\
\x0d\x0a    color: rgb\
(45, 33, 21);\x0d\x0a \
   background-co\
lor: white;\x0d\x0a\x09bo\
rder-width: 0px;\
\x0d\x0a\x09border-style:\
 solid;\x0d\x0a}\
\x00\x00\x02.\
Q\
TabWidget::tab-b\
ar {\x0d\x0a    alignm\
ent: left;\x0d\x0a}\x0d\x0a\x0d\
\x0a\x0d\x0aQTabBar::tab \
{\x0d\x0a    color: rg\
b(45, 33, 21);\x0d\x0a\
\x09/*text-align: c\
enter;*/\x0d\x0a\x09backg\
round-color: rgb\
a(24, 24, 24, 6)\
;\x0d\x0a    padding: \
2.4px 4.8px;\x0d\x0a  \
  border: 1.2px \
solid rgba(54, 4\
5, 33, 12);\x0d\x0a}\x0d\x0a\
QTabBar::tab[isB\
orderless=true] \
{\x0d\x0a    padding: \
3.6px 6.0px;\x0d\x0a\x09b\
order: none;\x0d\x0a}\x0d\
\x0aQTabBar::tab:ho\
ver {\x0d\x0a\x09backgrou\
nd-color: rgba(2\
4, 24, 24, 12);\x0d\
\x0a}\x0d\x0aQTabBar::tab\
:selected {\x0d\x0a\x09ba\
ckground-color: \
rgba(24, 24, 24,\
 18);\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQT\
abWidget::pane {\
\x0d\x0a\x09background: t\
ransparent;\x0d\x0a   \
 border: 1.2px s\
olid rgba(54, 45\
, 33, 12);\x0d\x0a}\
\x00\x00\x02\xb4\
Q\
TreeView {\x0d\x0a\x09/*f\
ont-size: 12px;\x0d\
\x0a\x09text-align: ce\
nter;*/\x0d\x0a\x09backgr\
ound-color: tran\
sparent;\x0d\x0a    ou\
tline: none;\x0d\x0a\x09b\
order: none;\x0d\x0a\x09b\
order-radius: 3p\
x;\x0d\x0a}\x0d\x0a\x0d\x0aQTreeVi\
ew::item {\x0d\x0a    \
color: rgb(45, 3\
3, 21);\x0d\x0a\x09backgr\
ound-color: tran\
sparent;\x0d\x0a\x09paddi\
ng: 3px;\x0d\x0a\x09borde\
r: none;\x0d\x0a\x09borde\
r-radius: 3px;\x0d\x0a\
}\x0d\x0aQTreeView::it\
em:hover {\x0d\x0a\x09bac\
kground-color: r\
gba(54, 45, 33, \
12);\x0d\x0a}\x0d\x0aQTreeVi\
ew::item:selecte\
d {\x0d\x0a}\x0d\x0a\x0d\x0aQTreeV\
iew::branch {\x0d\x0a \
   background-co\
lor: transparent\
;\x0d\x0a\x09border: none\
;\x0d\x0a}\x0d\x0aQTreeView:\
:branch:open:has\
-children {\x0d\x0a\x09im\
age: url(:/Icons\
/Icons/Light/Che\
vron-Down.svg);\x0d\
\x0a\x09padding: 3px;\x0d\
\x0a}\x0d\x0aQTreeView::b\
ranch:closed:has\
-children {\x0d\x0a\x09im\
age: url(:/Icons\
/Icons/Light/Che\
vron-Right.svg);\
\x0d\x0a\x09padding: 3px;\
\x0d\x0a}\
\x00\x00\x04\xd3\
M\
ediaPlayerBase {\
\x0d\x0a    padding: 4\
.8px 12px 6px 12\
px;\x0d\x0a}\x0d\x0aMediaPla\
yerBase[isBorder\
less=true] {\x0d\x0a  \
  padding: 1.2px\
;\x0d\x0a\x09border: none\
;\x0d\x0a}\x0d\x0aMediaPlaye\
rBase[isTranspar\
ent=true] {\x0d\x0a\x09ba\
ckground-color: \
transparent;\x0d\x0a}\x0d\
\x0a\x0d\x0aMediaPlayerBa\
se ButtonBase {\x0d\
\x0a    background-\
color: transpare\
nt;\x0d\x0a    border:\
 none;\x0d\x0a    bord\
er-radius: 12px;\
\x0d\x0a}\x0d\x0aMediaPlayer\
Base ButtonBase:\
hover {\x0d\x0a    bac\
kground-color: r\
gba(54, 45, 33, \
33);\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aMed\
iaPlayerBase QSl\
ider::groove:hor\
izontal {\x0d\x0a\x09heig\
ht: 1.2px;\x0d\x0a\x09bac\
kground-color: r\
gba(54, 45, 33, \
123);\x0d\x0a\x09border: \
none;\x0d\x0a\x09border-r\
adius: 6px;\x0d\x0a}\x0d\x0a\
MediaPlayerBase \
QSlider::groove:\
horizontal:hover\
 {\x0d\x0a\x09background-\
color: rgba(54, \
45, 33, 210);\x0d\x0a}\
\x0d\x0a\x0d\x0aMediaPlayerB\
ase QSlider::han\
dle:horizontal {\
\x0d\x0a\x09width: 12px;\x0d\
\x0a\x09height: 12px;\x0d\
\x0a\x09background-col\
or: rgba(54, 45,\
 33, 210);\x0d\x0a\x09mar\
gin-top: -6px;\x0d\x0a\
\x09margin-bottom: \
-6px;\x0d\x0a\x09border: \
1.2px solid tran\
sparent;\x0d\x0a\x09borde\
r-radius: 6px;\x0d\x0a\
}\x0d\x0aMediaPlayerBa\
se QSlider::hand\
le:horizontal:ho\
ver {\x0d\x0a\x09backgrou\
nd-color: rgba(4\
5, 33, 21, 234);\
\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aEmbedde\
dMediaPlayer {\x0d\x0a\
\x09background-colo\
r: transparent;\x0d\
\x0a    padding: 1.\
2px;\x0d\x0a\x09border: n\
one;\x0d\x0a}\x0d\x0aEmbedde\
dMediaPlayer: ho\
ver {\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQT\
oolTip {\x0d\x0a    co\
lor: rgb(45, 33,\
 21);\x0d\x0a    backg\
round-color: whi\
te;\x0d\x0a\x09border-wid\
th: 0px;\x0d\x0a\x09borde\
r-style: solid;\x0d\
\x0a}\
\x00\x00\x00\xf8\
M\
enuBase {\x0d\x0a    c\
olor: rgb(45, 33\
, 21);\x0d\x0a    back\
ground-color: rg\
ba(234, 234, 234\
, 246);\x0d\x0a    pad\
ding: 0px;\x0d\x0a    \
border: none;\x0d\x0a\x09\
border-radius: 3\
px;\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQToo\
lTip {\x0d\x0a    colo\
r: rgb(45, 33, 2\
1);\x0d\x0a    backgro\
und-color: white\
;\x0d\x0a    border: n\
one;\x0d\x0a}\
\x00\x00\x01\x05\
Q\
DockWidget {\x0d\x0a  \
  border: none;\x0d\
\x0a}\x0d\x0aQDockWidget[\
isBorderless=fal\
se] {\x0d\x0a    paddi\
ng: 0px;\x0d\x0a    bo\
rder: 1.2px soli\
d rgba(54, 45, 3\
3, 123);\x0d\x0a}\x0d\x0aQDo\
ckWidget[isTrans\
parent=true] {\x0d\x0a\
\x09background-colo\
r: transparent;\x0d\
\x0a}\x0d\x0a\x0d\x0aQDockWidge\
t::title {\x0d\x0a    \
text-align: left\
;\x0d\x0a}\
\x00\x00\x04\x0f\
Q\
HeaderView {\x0d\x0a  \
  background-col\
or: transparent;\
\x0d\x0a}\x0d\x0a\x0d\x0aQHeaderVi\
ew::section {\x0d\x0a \
   color: rgb(45\
, 33, 21);\x0d\x0a\x09/*t\
ext-align: left;\
*/\x0d\x0a\x09background-\
color: transpare\
nt;\x0d\x0a    padding\
: 2.4px 4.8px;\x0d\x0a\
    border: 1.2p\
x solid rgba(54,\
 45, 33, 123);\x0d\x0a\
}\x0d\x0aQHeaderView::\
section:horizont\
al {\x0d\x0a    border\
-top: none;\x0d\x0a   \
 border-left: no\
ne;\x0d\x0a}\x0d\x0aQHeaderV\
iew::section:ver\
tical {\x0d\x0a    bor\
der-top: none;\x0d\x0a\
}\x0d\x0a\x0d\x0a\x0d\x0aQTableVie\
w {\x0d\x0a\x09/*text-ali\
gn: left;*/\x0d\x0a\x09ba\
ckground-color: \
transparent;\x0d\x0a  \
  /*alternate-ba\
ckground-color: \
transparent;*/\x0d\x0a\
    selection-ba\
ckground-color: \
transparent;\x0d\x0a  \
  gridline-color\
: rgba(54, 45, 3\
3, 123);\x0d\x0a\x09borde\
r: 1.2px solid r\
gba(54, 45, 33, \
123);\x0d\x0a\x09border-r\
adius: 3px;\x0d\x0a   \
 outline: none;\x0d\
\x0a}\x0d\x0aQTableView[i\
sBorderless=true\
] {\x0d\x0a    padding\
: 1.2px;\x0d\x0a\x09borde\
r: none;\x0d\x0a}\x0d\x0a\x0d\x0aQ\
TableView::item \
{\x0d\x0a    color: rg\
b(45, 33, 21);\x0d\x0a\
    padding: 3px\
 6px;\x0d\x0a    borde\
r: 0px solid rgb\
a(54, 45, 33, 12\
3);\x0d\x0a\x09border-bot\
tom-width: 1.2px\
;\x0d\x0a}\x0d\x0aQTableView\
::item::selected\
 {\x0d\x0a\x09border-colo\
r: rgba(54, 45, \
33, 210);\x0d\x0a}\x0d\x0aQT\
ableView::item:!\
alternate:!selec\
ted {\x0d\x0a    \x0d\x0a}\
\x00\x00\x06Y\
S\
pinBoxBase, Doub\
leSpinBoxBase {\x0d\
\x0a    color: rgb(\
45, 33, 21);\x0d\x0a\x09t\
ext-align: left;\
\x0d\x0a\x09selection-bac\
kground-color: d\
arkgrey;\x0d\x0a\x09backg\
round-color: rgb\
a(24, 24, 24, 6)\
;\x0d\x0a    padding: \
4.8px 12px 6px 1\
2px;\x0d\x0a    border\
: 1.2px solid rg\
ba(54, 45, 33, 1\
2);\x0d\x0a    border-\
bottom: 1.2px so\
lid rgba(54, 45,\
 33, 48);\x0d\x0a\x09bord\
er-radius: 3px;\x0d\
\x0a    outline: no\
ne;\x0d\x0a}\x0d\x0aSpinBoxB\
ase[isBorderless\
=true] DoubleSpi\
nBoxBase[isBorde\
rless=true] {\x0d\x0a \
   padding: 1.2p\
x;\x0d\x0a\x09border: non\
e;\x0d\x0a}\x0d\x0aSpinBoxBa\
se[isTransparent\
=true] DoubleSpi\
nBoxBase[isBorde\
rless=true] {\x0d\x0a\x09\
background-color\
: transparent;\x0d\x0a\
}\x0d\x0aSpinBoxBase:h\
over, DoubleSpin\
BoxBase:hover {\x0d\
\x0a\x09background-col\
or: rgba(24, 24,\
 24, 12);\x0d\x0a}\x0d\x0aSp\
inBoxBase:focus,\
 DoubleSpinBoxBa\
se:focus {\x0d\x0a    \
border-bottom-co\
lor: rgba(120, 1\
80, 240, 246);\x0d\x0a\
}\x0d\x0aSpinBoxBase:d\
isabled, DoubleS\
pinBoxBase:disab\
led {\x0d\x0a\x09color: r\
gba(45, 33, 21, \
90);\x0d\x0a}\x0d\x0a\x0d\x0aSpinB\
oxBase::up-butto\
n, DoubleSpinBox\
Base::up-button \
{\x0d\x0a\x09/*width: 9px\
;\x0d\x0a\x09height: 9px;\
*/\x0d\x0a\x09subcontrol-\
origin: padding;\
\x0d\x0a\x09subcontrol-po\
sition: top righ\
t;\x0d\x0a\x09margin-righ\
t: 4.5px;\x0d\x0a\x09bord\
er-width: 0px;\x0d\x0a\
}\x0d\x0aSpinBoxBase::\
up-arrow, Double\
SpinBoxBase::up-\
arrow {\x0d\x0a\x09border\
-image: url(:/Ic\
ons/Icons/Light/\
Chevron-Up.svg);\
\x0d\x0a}\x0d\x0a\x0d\x0aSpinBoxBa\
se::down-button,\
 DoubleSpinBoxBa\
se::down-button \
{\x0d\x0a\x09/*width: 9px\
;\x0d\x0a\x09height: 9px;\
*/\x0d\x0a\x09subcontrol-\
origin: padding;\
\x0d\x0a\x09subcontrol-po\
sition: bottom r\
ight;\x0d\x0a\x09margin-r\
ight: 4.5px;\x0d\x0a\x09b\
order-width: 0px\
;\x0d\x0a}\x0d\x0aSpinBoxBas\
e::down-arrow, D\
oubleSpinBoxBase\
::down-arrow {\x0d\x0a\
\x09border-image: u\
rl(:/Icons/Icons\
/Light/Chevron-D\
own.svg);\x0d\x0a}\x0d\x0a\x0d\x0a\
\x0d\x0aQToolTip {\x0d\x0a  \
  color: rgb(45,\
 33, 21);\x0d\x0a    b\
ackground-color:\
 rgba(210, 222, \
234, 15);\x0d\x0a\x09bord\
er-width: 0px;\x0d\x0a\
\x09border-style: s\
olid;\x0d\x0a}\
\x00\x00\x01\xff\
P\
rogressBarBase {\
\x0d\x0a\x09text-align: c\
enter;\x0d\x0a    colo\
r: black;\x0d\x0a\x09back\
ground-color: rg\
ba(246, 246, 246\
, 18);\x0d\x0a    bord\
er: 1.2px solid \
rgba(210, 222, 2\
34, 12);\x0d\x0a    bo\
rder-radius: 3px\
;\x0d\x0a}\x0d\x0aProgressBa\
rBase[isBorderle\
ss=true] {\x0d\x0a    \
padding: 1.2px;\x0d\
\x0a\x09border: none;\x0d\
\x0a}\x0d\x0aProgressBarB\
ase[isTransparen\
t=true] {\x0d\x0a\x09back\
ground-color: tr\
ansparent;\x0d\x0a}\x0d\x0a\x0d\
\x0aProgressBarBase\
::chunk {\x0d\x0a\x09back\
ground-color: ql\
ineargradient(sp\
read: pad, x1:0,\
 y1:0, x2:1, y2:\
0, stop:0 transp\
arent, stop:1 rg\
ba(120, 180, 240\
, 123));\x0d\x0a    bo\
rder: none;\x0d\x0a}\
\x00\x00\x02P\
\x00\
\x00\x07\xedx\xda\x95UAo\xda0\x14>\x17\xa9\xff\
\xc1G\xa8\xa0M\x0cC\x9d\xab]8\xf5\xb2I\x95\xb8\
M;8\xb1\x17\xac\xbavf;-l\xe2\xbf\xef9\
\x09\x89C\x08P\x22Y\xc6\xf1\xfb\xfc\xf9\xbd\xef}Y\
\x15\xcei\xb5\xa2\x96\xa3\x7f\xb7#\x04\xbfTKm\x08\
2Y2\xc6q4E\x18c\x18\xe6\x8b\xc9\xd3\xed\xe8\
\xe6\xe1\xce\xf1\xad\x9bQ)2EP\xca\x95\xe3\xe6\xe9\
\xee\x01\xde$4}\xcd\x8c.\x14\x9b\xb5\x08t\x8c\x17\
K\x88n\x86\xf8\xd1\xc3\xf8cr\xca\x98P\x19A\x8b\
\xfb\xc7|\x8bb\x0c\xc3\xb2\x9e\xd4[\x12m\x18\x07\xa0\
\xf8\xde\xbf\xb4Z\x0aV\x83\x86\xbc\x00\x14O:\x11\xb3\
D\xc3\xa5\xde\xba<\xba!\x8b\x92\xc7M\xbd\xdfP&\
\x0aK\xd0\xbc9Z\x17N\x0a\xc5\x09RZqX\xdb\
\xdf\x8eVM\xa6~\x0a\xbb*\x03%\xb7\xf6\x9b3\x05\
\xffuH^s\xab\x92s{\xc4 \xd0\xdaPes\
j \x93-\xd2\x89d\xbav\xdf1\x0a\xd9\xe8wn\
\x06\xe2N\x15\x01\x97\xb5\xecb\xe4\x06\xee\xc2\xd9\x14\x05\
k\xe9\x86\xa7\xaf\x9c\x95\xc8gr\x19\xe3\xf9\xe5\xfc\xc7\
8\xf2\xd5\xf7\x81\x8brX\xf690ai\x22/\x1f\
\xf85\xaac\xfd\xf3\x9d\xab\xa2\xc2\x98\xa2g-\xa5\xfe\
\xa8\xfe]\x95\xc7\x83\x00>\x04s\x9b^\xd1f\xd6\xed\
$h\xa0T^\xb0\xdc\xa1\x16\xc5\xc0\xaa\xe1W\xe7b\
\x1f\xf2\xaa\xea\xd3e\x17\xd6\xec\x22(\xcc\x9a\x0b\xb7\xb0\
\xe8\xc5\xcf\x07\xae\x99HX:&RE\x10\x22\x1c\x7f\
;+\x97\xa3\xfa~){\xa5\x96\xf6\xcc\xe9\xfc\xd0)\
\xcd\x9a\xe4\xbf\x1d\xf1\xed\x1b.V*\xe8\xed5\x22\xdb\
\xb4\x9b\xfb\xedq\x9a\xefe\x91W\x0a\x0b\x87\xc9Y@\
\xcb%O]\xad\xb6\xcfb\xfa\xe7\x07}\x17\x19u\x02\
\xd4\xdb*\xaek\x90>/C\xf6\xd8Ub\xc7<\xa2\
\x9e\x05F\x8d\x01\x9e\x16\xf0\xc1\xc1\xaa\xc8}\x9f\xdc\xd9\
\xfc\xfd\xf1^GM\xe6Q\x00wl\xc1\x0d(#\x9e\
\xd0\x14mc\x02W\xdf\x95\xe3\x16\x13P\xe6\x0e\xfb\xb9\
\xf5B\x88Nv\xb7\xef\x82zC\x1c\x12\x9e\x0cp\x0b\
\x8d\xe6\xda\x96\xad$7\xef~\x18\x06]\xe6\xf8Hp\
\xdegm\xc4_\xad\x1c\x95\x95\xf1\x86,>\x93\xfa@\
\xe6WQ\xf1\xcf\xcbZk\xb9\x16\xf95\xdf\xdc\x92\xcb\
`\x83\x1f9Xt\xce\xbf\xf6\xff\x01W\x8ed\xed\
\x00\x00\x01\x12\
Q\
Widget {\x0d\x0a    ba\
ckground-color: \
qlineargradient(\
spread: pad, x1:\
0, y1:0, x2:1, y\
2:0, stop:0 rgba\
(36, 36, 36, 246\
), stop:1 rgba(2\
4, 24, 24, 246))\
;\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQToolT\
ip {\x0d\x0a    color:\
 rgb(210, 222, 2\
34);\x0d\x0a    backgr\
ound-color: blac\
k;\x0d\x0a\x09border-widt\
h: 0px;\x0d\x0a\x09border\
-style: solid;\x0d\x0a\
}\
\x00\x00\x01%\
C\
heckBoxBase {\x0d\x0a \
   background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0aCheckBoxBa\
se::indicator {\x0d\
\x0a    background-\
color: transpare\
nt;\x0d\x0a    border:\
 none;\x0d\x0a}\x0d\x0a\x0d\x0aChe\
ckBoxBase QLabel\
 {\x0d\x0a    color: w\
hite;\x0d\x0a    backg\
round-color: tra\
nsparent;\x0d\x0a    b\
order: none;\x0d\x0a}\x0d\
\x0aCheckBoxBase QL\
abel:disabled {\x0d\
\x0a    color: grey\
;\x0d\x0a}\
\x00\x00\x01\xd5\
T\
extBrowserBase {\
\x0d\x0a    color: rgb\
(210, 222, 234);\
\x0d\x0a\x09text-align: l\
eft;\x0d\x0a\x09selection\
-background-colo\
r: darkgrey;\x0d\x0a\x09b\
ackground-color:\
 transparent;\x0d\x0a \
   padding: 1.2p\
x;\x0d\x0a\x09border: non\
e;\x0d\x0a\x09border-radi\
us: 3px;\x0d\x0a}\x0d\x0aTex\
tBrowserBase[isB\
orderless=false]\
 {\x0d\x0a    padding:\
 0px;\x0d\x0a    borde\
r: 1.2px solid r\
gba(201, 210, 22\
2, 123);\x0d\x0a}\x0d\x0aTex\
tBrowserBase:hov\
er {\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQTo\
olTip {\x0d\x0a    col\
or: rgb(210, 222\
, 234);\x0d\x0a    bac\
kground-color: b\
lack;\x0d\x0a\x09border-w\
idth: 0px;\x0d\x0a\x09bor\
der-style: solid\
;\x0d\x0a}\
\x00\x00\x02N\
T\
oolBox {\x0d\x0a    ba\
ckground-color: \
transparent;\x0d\x0a  \
  padding: 0px;\x0d\
\x0a    border: non\
e;\x0d\x0a\x09border-radi\
us: 3px;\x0d\x0a}\x0d\x0a\x0d\x0aT\
oolPage {\x0d\x0a\x09back\
ground-color: tr\
ansparent;\x0d\x0a    \
border: none;\x0d\x0a}\
\x0d\x0a\x0d\x0aToolPage Fol\
der {\x0d\x0a    color\
: rgb(210, 222, \
234);\x0d\x0a\x09text-ali\
gn: left;\x0d\x0a\x09back\
ground-color: tr\
ansparent;\x0d\x0a\x09pad\
ding-top: 3px;\x0d\x0a\
\x09padding-left: 1\
2px;\x0d\x0a\x09padding-b\
ottom: 3px;\x0d\x0a\x09pa\
dding-right: 6px\
;\x0d\x0a    border: n\
one;\x0d\x0a}\x0d\x0aToolPag\
e Folder:hover {\
\x0d\x0a\x09background-co\
lor: rgba(201, 2\
10, 222, 12);\x0d\x0a}\
\x0d\x0a\x0d\x0a\x0d\x0aQToolTip {\
\x0d\x0a    color: rgb\
(210, 222, 234);\
\x0d\x0a    background\
-color: black;\x0d\x0a\
\x09border-width: 0\
px;\x0d\x0a\x09border-sty\
le: solid;\x0d\x0a}\
\x00\x00\x01\xfd\
C\
hatWidgetBase {\x0d\
\x0a    background-\
color: transpare\
nt;\x0d\x0a    border:\
 none;\x0d\x0a\x09border-\
radius: 3px;\x0d\x0a}\x0d\
\x0aChatWidgetBase:\
hover {\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0a\
ChatWidgetBase Q\
Widget {\x0d\x0a    ba\
ckground-color: \
transparent;\x0d\x0a  \
  border: none;\x0d\
\x0a}\x0d\x0aChatWidgetBa\
se QWidget:hover\
 {\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aChatW\
idgetBase Messag\
eDisplay {\x0d\x0a    \
background-color\
: transparent;\x0d\x0a\
    padding: 12p\
x;\x0d\x0a}\x0d\x0aChatWidge\
tBase MessageDis\
play:hover {\x0d\x0a}\x0d\
\x0a\x0d\x0a\x0d\x0aQToolTip {\x0d\
\x0a    color: rgb(\
210, 222, 234);\x0d\
\x0a    background-\
color: black;\x0d\x0a\x09\
border-width: 0p\
x;\x0d\x0a\x09border-styl\
e: solid;\x0d\x0a}\
\x00\x00\x02\x9d\
L\
istBase {\x0d\x0a\x09/*te\
xt-align: center\
;*/\x0d\x0a\x09background\
-color: transpar\
ent;\x0d\x0a    paddin\
g: 1.2px;\x0d\x0a\x09bord\
er: none;\x0d\x0a\x09bord\
er-radius: 3px;\x0d\
\x0a    outline: no\
ne;\x0d\x0a}\x0d\x0aListBase\
[isBorderless=fa\
lse] {\x0d\x0a    padd\
ing: 0px;\x0d\x0a    b\
order: 1.2px sol\
id rgba(201, 210\
, 222, 123);\x0d\x0a}\x0d\
\x0aListBase:hover \
{\x0d\x0a    border-co\
lor: rgba(201, 2\
10, 222, 210);\x0d\x0a\
}\x0d\x0a\x0d\x0aListBase::i\
tem {\x0d\x0a    color\
: rgb(210, 222, \
234);\x0d\x0a\x09backgrou\
nd-color: transp\
arent;\x0d\x0a    bord\
er: 2.4px solid \
transparent;\x0d\x0a\x09p\
adding: 2.4px;\x0d\x0a\
}\x0d\x0aListBase::ite\
m:hover {\x0d\x0a\x09back\
ground-color: rg\
ba(201, 210, 222\
, 33);\x0d\x0a}\x0d\x0aListB\
ase::item:select\
ed {\x0d\x0a\x09backgroun\
d-color: transpa\
rent;\x0d\x0a\x09border-l\
eft-color: rgb(1\
20, 180, 240);\x0d\x0a\
\x09/*padding-left:\
 1.2px;*/\x0d\x0a}\
\x00\x00\x03\xc6\
L\
ineEditBase, Tex\
tEditBase {\x0d\x0a   \
 color: rgb(210,\
 222, 234);\x0d\x0a\x09te\
xt-align: left;\x0d\
\x0a\x09selection-back\
ground-color: da\
rkgrey;\x0d\x0a    bac\
kground-color: r\
gba(246, 246, 24\
6, 18);\x0d\x0a    pad\
ding: 4.8px 12px\
 6px 12px;\x0d\x0a    \
border: 1.2px so\
lid rgba(210, 22\
2, 234, 12);\x0d\x0a  \
  border-bottom:\
 1.2px solid rgb\
a(210, 222, 234,\
 48);\x0d\x0a\x09border-r\
adius: 3px;\x0d\x0a   \
 outline: none;\x0d\
\x0a}\x0d\x0aLineEditBase\
[isBorderless=tr\
ue], TextEditBas\
e[isBorderless=t\
rue] {\x0d\x0a    padd\
ing: 1.2px;\x0d\x0a\x09bo\
rder: none;\x0d\x0a}\x0d\x0a\
LineEditBase[isT\
ransparent=true]\
, TextEditBase[i\
sTransparent=tru\
e] {\x0d\x0a\x09backgroun\
d-color: transpa\
rent;\x0d\x0a}\x0d\x0aLineEd\
itBase:hover, Te\
xtEditBase:hover\
 {\x0d\x0a\x09background-\
color: rgba(246,\
 246, 246, 24);\x0d\
\x0a}\x0d\x0aLineEditBase\
:focus, TextEdit\
Base:focus {\x0d\x0a  \
  border-bottom-\
color: rgba(120,\
 180, 240, 246);\
\x0d\x0a}\x0d\x0aLineEditBas\
e:disabled, Text\
EditBase:disable\
d {\x0d\x0a\x09color: rgb\
a(201, 210, 222,\
 90);\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQT\
oolTip {\x0d\x0a    co\
lor: rgb(210, 22\
2, 234);\x0d\x0a    ba\
ckground-color: \
black;\x0d\x0a\x09border-\
width: 0px;\x0d\x0a\x09bo\
rder-style: soli\
d;\x0d\x0a}\
\x00\x00\x01K\
\x00\
\x00\x06\x0dx\xda\xc5S\xd1N\x830\x14}\x96\x84\x7f\
\xe8\xe3\x96\x88\x81BL\xec\xbeb\xf1\x0b\x0amJ#\
R\xd2\xc265\xfbw\xaf\xdb\x0an\xd0\x8a\xd3(\x0f\
7\xa4\xb9=\xa7\xe7\x9e{\xd6\x8f\x95d\x5c\x93Ri\
\xf9\xaa\xea\x96V\xe8-\x0c\x10|%\x97\xa2l\x09\xc2\
Y\xb3[\x85\xc1>\x0c\xc2`}\xea&B+\xb5\xe1\
\x9e[\xe9\xe1\xd2\xc7IN\x8b'h\xefj\x16\x15\xaa\
R\x9a -r\xbaHpz\x8b\x86\x82\x93xi/\
(\x0d\x1c\x91\xa6Lv\xc6\x22\xed}\xe4\x84IC\xf3\
\x8a3\xfb\x8ay\x9cP\x96#e\xa6\xcb\xa3\x86\x8a)\
m\x03*A\xdbR\xb6|\xe5\xd4\xec\x90\xf0\x89\xa7\xa4\
5\xab\xa6X\xb6\x92\xb5%\x8c=\xee\xd1.\x9c\xb8\x99\
T\xb7\xc0\xd9=\x8c\xf1T\xcegIPr\x87\x9b\x1d\
2\x0a\xc8\x8f\xcdI\x0c}\x18CI3\xc7\xe0\x93\xe1\
\x05\xcfT\x0bY\x13\x14=\x00J<2d\xa4\x05~\
7\x5c\xbb\xdd\xb0\xd3\xf3\x834\x9a\x1b\xe33u\x1e\xcc\
\xd7\xcb!4\x7f\xb1\x06\x0dP\xa0\xa0\x95\xc5\xd8\x18O\
\x1e\x1cW\xfe \x0c\x96\xf97\xa3@\x19;F\xe1R\
\x96+\x08c\xb9\xb3s\xe0\x1f\xf6Y\x0a\xe2\xffN\x01\
\x9c\x1c\x920\xbdy\xbd\x13\xd7g\xa0\x87\xf8I\x02\xbe\
\xb1\x11v\xff\xdf\x01?\x9f\xd4\xd5\
\x00\x00\x07&\
C\
omboBoxBase {\x0d\x0a \
   color: rgb(21\
0, 222, 234);\x0d\x0a\x09\
text-align: left\
;\x0d\x0a\x09selection-ba\
ckground-color: \
darkgrey;\x0d\x0a\x09back\
ground-color: rg\
ba(246, 246, 246\
, 18);\x0d\x0a    padd\
ing: 4.8px 12px \
6px 12px;\x0d\x0a    b\
order: 1.2px sol\
id rgba(210, 222\
, 234, 12);\x0d\x0a   \
 border-bottom: \
1.2px solid rgba\
(210, 222, 234, \
48);\x0d\x0a\x09border-ra\
dius: 3px;\x0d\x0a    \
outline: none;\x0d\x0a\
}\x0d\x0aComboBoxBase[\
isBorderless=tru\
e] {\x0d\x0a    paddin\
g: 1.2px;\x0d\x0a\x09bord\
er: none;\x0d\x0a}\x0d\x0aCo\
mboBoxBase[isTra\
nsparent=true] {\
\x0d\x0a\x09background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0aComboBoxBa\
se:hover {\x0d\x0a\x09bac\
kground-color: r\
gba(246, 246, 24\
6, 24);\x0d\x0a}\x0d\x0aComb\
oBoxBase:focus {\
\x0d\x0a    border-bot\
tom-color: rgba(\
120, 180, 240, 2\
46);\x0d\x0a}\x0d\x0aComboBo\
xBase:disabled {\
\x0d\x0a\x09color: rgba(2\
10, 222, 234, 90\
);\x0d\x0a}\x0d\x0a\x0d\x0aComboBo\
xBase::drop-down\
 {\x0d\x0a\x09/*width: 12\
px;\x0d\x0a\x09height: 12\
px;*/\x0d\x0a\x09subcontr\
ol-origin: paddi\
ng;\x0d\x0a\x09subcontrol\
-position: right\
;\x0d\x0a\x09margin-right\
: 6px;\x0d\x0a\x09border:\
 none;\x0d\x0a}\x0d\x0a\x0d\x0aCom\
boBoxBase::down-\
arrow {\x0d\x0a\x09border\
-image: url(:/Ic\
ons/Icons/Dark/C\
hevron-Down.svg)\
;\x0d\x0a}\x0d\x0aComboBoxBa\
se::down-arrow:o\
n {\x0d\x0a\x09border-ima\
ge: url(:Icons/I\
cons/Dark/Chevro\
n-Up.svg);\x0d\x0a}\x0d\x0a\x0d\
\x0a\x0d\x0aComboBoxBase \
QAbstractItemVie\
w {\x0d\x0a\x09background\
-color: black;\x0d\x0a\
\x09border: 1.2px s\
olid rgba(201, 2\
10, 222, 123);\x0d\x0a\
\x09outline: none;\x0d\
\x0a}\x0d\x0aComboBoxBase\
 QAbstractItemVi\
ew[isBorderless=\
true] {\x0d\x0a    pad\
ding: 1.2px;\x0d\x0a\x09b\
order: none;\x0d\x0a}\x0d\
\x0aComboBoxBase QA\
bstractItemView[\
isTransparent=tr\
ue] {\x0d\x0a\x09backgrou\
nd-color: transp\
arent;\x0d\x0a}\x0d\x0a\x0d\x0aCom\
boBoxBase QAbstr\
actItemView::ite\
m {\x0d\x0a    color: \
rgb(210, 222, 23\
4);\x0d\x0a\x09background\
-color: rgba(210\
, 222, 234, 15);\
\x0d\x0a\x09padding: 3px \
6px;\x0d\x0a\x09border: n\
one;\x0d\x0a}\x0d\x0aComboBo\
xBase QAbstractI\
temView::item:ho\
ver {\x0d\x0a\x09backgrou\
nd-color: rgba(1\
23, 123, 123, 12\
3);\x0d\x0a}\x0d\x0aComboBox\
Base QAbstractIt\
emView::item:sel\
ected {\x0d\x0a\x09backgr\
ound-color: rgba\
(123, 123, 123, \
123);\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQT\
oolTip {\x0d\x0a    co\
lor: rgb(210, 22\
2, 234);\x0d\x0a    ba\
ckground-color: \
black;\x0d\x0a\x09border-\
width: 0px;\x0d\x0a\x09bo\
rder-style: soli\
d;\x0d\x0a}\
\x00\x00\x01\xd8\
G\
roupBoxBase {\x0d\x0a \
   color: rgb(21\
0, 222, 234);\x0d\x0a\x09\
margin-top: 1.5e\
x;\x0d\x0a\x09background-\
color: transpare\
nt;\x0d\x0a\x09border: 1.\
2px solid transp\
arent;\x0d\x0a\x09border-\
radius: 3px;\x0d\x0a}\x0d\
\x0a\x0d\x0aGroupBoxBase:\
:title {\x0d\x0a\x09subco\
ntrol-origin: ma\
rgin;\x0d\x0a\x09subcontr\
ol-position: top\
 left;\x0d\x0a\x09padding\
: 3px 9px 3px 6p\
x;\x0d\x0a}\x0d\x0a\x0d\x0aGroupBo\
xBase::indicator\
:checked {\x0d\x0a\x09bor\
der-image: url(:\
/Icons/Icons/Dar\
k/Chevron-Down.s\
vg);\x0d\x0a}\x0d\x0aGroupBo\
xBase::indicator\
:unchecked {\x0d\x0a\x09b\
order-image: url\
(:/Icons/Icons/D\
ark/Chevron-Up.s\
vg);\x0d\x0a}\
\x00\x00\x00\xf0\
S\
crollAreaBase {\x0d\
\x0a\x09border: 0px so\
lid;\x0d\x0a\x09border-ra\
dius: 3px;\x0d\x0a}\x0d\x0aS\
crollAreaBase[is\
Borderless=true]\
 {\x0d\x0a    padding:\
 1.2px;\x0d\x0a\x09border\
: none;\x0d\x0a}\x0d\x0aScro\
llAreaBase[isTra\
nsparent=true] {\
\x0d\x0a\x09background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0aScrollArea\
Base:hover {\x0d\x0a}\
\x00\x00\x01!\
L\
abelBase {\x0d\x0a    \
color: rgb(210, \
222, 234);\x0d\x0a    \
background-color\
: transparent;\x0d\x0a\
    padding: 0px\
;\x0d\x0a    border: n\
one;\x0d\x0a\x09border-ra\
dius: 3px;\x0d\x0a}\x0d\x0aL\
abelBase:hover {\
\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQToolTi\
p {\x0d\x0a    color: \
rgb(210, 222, 23\
4);\x0d\x0a    backgro\
und-color: black\
;\x0d\x0a\x09border-width\
: 0px;\x0d\x0a\x09border-\
style: solid;\x0d\x0a}\
\
\x00\x00\x02A\
Q\
TabWidget::tab-b\
ar {\x0d\x0a    alignm\
ent: left;\x0d\x0a}\x0d\x0a\x0d\
\x0a\x0d\x0aQTabBar::tab \
{\x0d\x0a    color: rg\
b(210, 222, 234)\
;\x0d\x0a\x09/*text-align\
: center;*/\x0d\x0a\x09ba\
ckground-color: \
rgba(246, 246, 2\
46, 18);\x0d\x0a    pa\
dding: 2.4px 4.8\
px;\x0d\x0a    border:\
 1.2px solid rgb\
a(210, 222, 234,\
 12);\x0d\x0a}\x0d\x0aQTabBa\
r::tab[isBorderl\
ess=true] {\x0d\x0a   \
 padding: 3.6px \
6.0px;\x0d\x0a\x09border:\
 none;\x0d\x0a}\x0d\x0aQTabB\
ar::tab:hover {\x0d\
\x0a\x09background-col\
or: rgba(246, 24\
6, 246, 24);\x0d\x0a}\x0d\
\x0aQTabBar::tab:se\
lected {\x0d\x0a\x09backg\
round-color: rgb\
a(246, 246, 246,\
 30);\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQT\
abWidget::pane {\
\x0d\x0a\x09background: t\
ransparent;\x0d\x0a   \
 border: 1.2px s\
olid rgba(210, 2\
22, 234, 12);\x0d\x0a}\
\
\x00\x00\x02\xb8\
Q\
TreeView {\x0d\x0a\x09/*f\
ont-size: 12px;\x0d\
\x0a\x09text-align: ce\
nter;*/\x0d\x0a\x09backgr\
ound-color: tran\
sparent;\x0d\x0a    ou\
tline: none;\x0d\x0a\x09b\
order: none;\x0d\x0a\x09b\
order-radius: 3p\
x;\x0d\x0a}\x0d\x0a\x0d\x0aQTreeVi\
ew::item {\x0d\x0a    \
color: rgb(210, \
222, 234);\x0d\x0a\x09bac\
kground-color: t\
ransparent;\x0d\x0a\x09pa\
dding: 3px;\x0d\x0a\x09bo\
rder: none;\x0d\x0a\x09bo\
rder-radius: 3px\
;\x0d\x0a}\x0d\x0aQTreeView:\
:item:hover {\x0d\x0a\x09\
background-color\
: rgba(201, 210,\
 222, 33);\x0d\x0a}\x0d\x0aQ\
TreeView::item:s\
elected {\x0d\x0a}\x0d\x0a\x0d\x0a\
QTreeView::branc\
h {\x0d\x0a    backgro\
und-color: trans\
parent;\x0d\x0a\x09border\
: none;\x0d\x0a}\x0d\x0aQTre\
eView::branch:op\
en:has-children \
{\x0d\x0a\x09image: url(:\
/Icons/Icons/Dar\
k/Chevron-Down.s\
vg);\x0d\x0a\x09padding: \
3px;\x0d\x0a}\x0d\x0aQTreeVi\
ew::branch:close\
d:has-children {\
\x0d\x0a\x09image: url(:/\
Icons/Icons/Dark\
/Chevron-Right.s\
vg);\x0d\x0a\x09padding: \
3px;\x0d\x0a}\
\x00\x00\x01w\
\x00\
\x00\x04\xe5x\xda\x95SMk\xc3 \x18>\xa7\xd0\xff\
\xe0q\x85\xa6$i)\xc3\xb2K`\xc7\xc2\xcaz\x1b\
;\x98*\x89\xccjP\xb3\xad\x1b\xfb\xef\xb3\xf9\xa86\
\x99,\xf5 \xf2\xa2\xcf\xd7\xeb\xbb%\x98\xa2'\x86N\
D\xa6H\x11\xf0=\x9d\x00\xb3J\x841\xe59\x04\xab\
\xc5}\xf9\x09\xe2\xc4l\xeb\xf6\xb0\x99N~\xa6\x93\xed\
\xf5\xc3\x17\xaaR!1\x91\x8c(\xf5\xa0eE^\x07\
X\xf1\xa2y\x1dd\xf5M\x08\xb8\xe0\xc4\x87\xb6\x97\x88\
\xab\x12I\xc2\xb5\x85\x0b2tx\xcb\xa5\xa88\x0e\x0f\
\x82\x09\x83\xa1\xed\xbd\x06j\x00\x06\xd2Jk\xc1]{\
\xff\xc1\xd4w\xaeE\xdaR(\x11\xa6\x95\x82\xfe0\x1c\
FX\x88w\x22\xfd\xbc2\xcf\xd0]\x12\xc5s\x90\xc4\
\x91\xd9\x92d\x0e\x96\xcbYge\x08\xbd{f\xf4\xac\
\x0b\x1a\x1c\x03m\xf0%\xfd\x12\x5c#V\x07T\x10\x9a\
\x17\xda\xcdz\x14e\x9c\xd4\x9c\xfd\xce\x04=\xc7k\x9f\
a\xbf*\x1b\xc0H)\xe64\xf3u\xf2BS \x8e\
\xd9\xc0\xfc\x07\xc5\xba\xb8\xf4\xc5fqS\x14-\x7fp\
D2\xa7<\xd4\xa2\x84 l\x8cw\xb5L\x98\xf6\x1e\
m\xb9K\xad\x0e\x1d(aD\xf6>\xd4\xedA\x0e\x1c\
\x8e\x08\xd2zX\xae\xea\xcd\xf9G\x8f\xc7\x8c`L\xb0\
C8j\xa2\xc6N\xf0\x1f\xf8\x10\x5c$\xb7\x22v{\
!\xd8\x9e\x96\xdd<X\xf5\xd7\xe2g\x1b\xdf\xbcd\xcc\
\x94\x9c@\xdb\x96G\xae\xacP\xe9\x93\x89\xaei\xc4Y\
\xdd/^|\x85\x9f\
\x00\x00\x00\xfb\
M\
enuBase {\x0d\x0a    c\
olor: rgb(210, 2\
22, 234);\x0d\x0a    b\
ackground-color:\
 rgba(60, 60, 60\
, 240);\x0d\x0a    pad\
ding: 0px;\x0d\x0a    \
border: none;\x0d\x0a\x09\
border-radius: 3\
px;\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQToo\
lTip {\x0d\x0a    colo\
r: rgb(210, 222,\
 234);\x0d\x0a    back\
ground-color: bl\
ack;\x0d\x0a    border\
: none;\x0d\x0a}\
\x00\x00\x01\x08\
Q\
DockWidget {\x0d\x0a  \
  border: none;\x0d\
\x0a}\x0d\x0aQDockWidget[\
isBorderless=fal\
se] {\x0d\x0a    paddi\
ng: 0px;\x0d\x0a    bo\
rder: 1.2px soli\
d rgba(201, 210,\
 222, 123);\x0d\x0a}\x0d\x0a\
QDockWidget[isTr\
ansparent=true] \
{\x0d\x0a\x09background-c\
olor: transparen\
t;\x0d\x0a}\x0d\x0a\x0d\x0aQDockWi\
dget::title {\x0d\x0a \
   text-align: l\
eft;\x0d\x0a}\
\x00\x00\x04$\
Q\
HeaderView {\x0d\x0a  \
  background-col\
or: transparent;\
\x0d\x0a}\x0d\x0a\x0d\x0aQHeaderVi\
ew::section {\x0d\x0a \
   color: rgb(21\
0, 222, 234);\x0d\x0a\x09\
/*text-align: le\
ft;*/\x0d\x0a\x09backgrou\
nd-color: transp\
arent;\x0d\x0a    padd\
ing: 2.4px 4.8px\
;\x0d\x0a    border: 1\
.2px solid rgba(\
201, 210, 222, 1\
23);\x0d\x0a}\x0d\x0aQHeader\
View::section:ho\
rizontal {\x0d\x0a    \
border-top: none\
;\x0d\x0a    border-le\
ft: none;\x0d\x0a}\x0d\x0aQH\
eaderView::secti\
on:vertical {\x0d\x0a \
   border-top: n\
one;\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQTa\
bleView {\x0d\x0a\x09/*te\
xt-align: left;*\
/\x0d\x0a\x09background-c\
olor: transparen\
t;\x0d\x0a    /*altern\
ate-background-c\
olor: transparen\
t;*/\x0d\x0a    select\
ion-background-c\
olor: transparen\
t;\x0d\x0a    gridline\
-color: rgba(201\
, 210, 222, 123)\
;\x0d\x0a\x09border: 1.2p\
x solid rgba(201\
, 210, 222, 123)\
;\x0d\x0a\x09border-radiu\
s: 3px;\x0d\x0a    out\
line: none;\x0d\x0a}\x0d\x0a\
QTableView[isBor\
derless=true] {\x0d\
\x0a    padding: 1.\
2px;\x0d\x0a\x09border: n\
one;\x0d\x0a}\x0d\x0a\x0d\x0aQTabl\
eView::item {\x0d\x0a \
   color: rgb(21\
0, 222, 234);\x0d\x0a \
   padding: 3px \
6px;\x0d\x0a    border\
: 0px solid rgba\
(201, 210, 222, \
123);\x0d\x0a\x09border-b\
ottom-width: 1.2\
px;\x0d\x0a}\x0d\x0aQTableVi\
ew::item::select\
ed {\x0d\x0a\x09border-co\
lor: rgba(201, 2\
10, 222, 210);\x0d\x0a\
}\x0d\x0aQTableView::i\
tem:!alternate:!\
selected {\x0d\x0a    \
\x0d\x0a}\
\x00\x00\x06[\
S\
pinBoxBase, Doub\
leSpinBoxBase {\x0d\
\x0a    color: rgb(\
210, 222, 234);\x0d\
\x0a\x09text-align: le\
ft;\x0d\x0a\x09selection-\
background-color\
: darkgrey;\x0d\x0a\x09ba\
ckground-color: \
rgba(246, 246, 2\
46, 18);\x0d\x0a    pa\
dding: 4.8px 12p\
x 6px 12px;\x0d\x0a   \
 border: 1.2px s\
olid rgba(201, 2\
10, 222, 12);\x0d\x0a \
   border-bottom\
: 1.2px solid rg\
ba(201, 210, 222\
, 48);\x0d\x0a\x09border-\
radius: 3px;\x0d\x0a  \
  outline: none;\
\x0d\x0a}\x0d\x0aSpinBoxBase\
[isBorderless=tr\
ue] DoubleSpinBo\
xBase[isBorderle\
ss=true] {\x0d\x0a    \
padding: 1.2px;\x0d\
\x0a\x09border: none;\x0d\
\x0a}\x0d\x0aSpinBoxBase[\
isTransparent=tr\
ue] DoubleSpinBo\
xBase[isBorderle\
ss=true] {\x0d\x0a\x09bac\
kground-color: t\
ransparent;\x0d\x0a}\x0d\x0a\
SpinBoxBase:hove\
r, DoubleSpinBox\
Base:hover {\x0d\x0a\x09b\
ackground-color:\
 rgba(246, 246, \
246, 24);\x0d\x0a}\x0d\x0aSp\
inBoxBase:focus,\
 DoubleSpinBoxBa\
se:focus {\x0d\x0a    \
border-bottom-co\
lor: rgba(120, 1\
80, 240, 246);\x0d\x0a\
}\x0d\x0aSpinBoxBase:d\
isabled, DoubleS\
pinBoxBase:disab\
led {\x0d\x0a\x09color: r\
gba(201, 210, 22\
2, 90);\x0d\x0a}\x0d\x0a\x0d\x0aSp\
inBoxBase::up-bu\
tton, DoubleSpin\
BoxBase::up-butt\
on {\x0d\x0a\x09/*width: \
9px;\x0d\x0a\x09height: 9\
px;*/\x0d\x0a\x09subcontr\
ol-origin: paddi\
ng;\x0d\x0a\x09subcontrol\
-position: top r\
ight;\x0d\x0a\x09margin-r\
ight: 4.5px;\x0d\x0a\x09b\
order-width: 0px\
;\x0d\x0a}\x0d\x0aSpinBoxBas\
e::up-arrow, Dou\
bleSpinBoxBase::\
up-arrow {\x0d\x0a\x09bor\
der-image: url(:\
/Icons/Icons/Dar\
k/Chevron-Up.svg\
);\x0d\x0a}\x0d\x0a\x0d\x0aSpinBox\
Base::down-butto\
n, DoubleSpinBox\
Base::down-butto\
n {\x0d\x0a\x09/*width: 9\
px;\x0d\x0a\x09height: 9p\
x;*/\x0d\x0a\x09subcontro\
l-origin: paddin\
g;\x0d\x0a\x09subcontrol-\
position: bottom\
 right;\x0d\x0a\x09margin\
-right: 4.5px;\x0d\x0a\
\x09border-width: 0\
px;\x0d\x0a}\x0d\x0aSpinBoxB\
ase::down-arrow,\
 DoubleSpinBoxBa\
se::down-arrow {\
\x0d\x0a\x09border-image:\
 url(:/Icons/Ico\
ns/Dark/Chevron-\
Down.svg);\x0d\x0a}\x0d\x0a\x0d\
\x0a\x0d\x0aQToolTip {\x0d\x0a \
   color: rgb(21\
0, 222, 234);\x0d\x0a \
   background-co\
lor: black;\x0d\x0a\x09bo\
rder-width: 0px;\
\x0d\x0a\x09border-style:\
 solid;\x0d\x0a}\
\x00\x00\x02!\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-fullscreen-exi\
t\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 d=\x22M5.5 0a.5.5 \
0 0 1 .5.5v4A1.5\
 1.5 0 0 1 4.5 6\
h-4a.5.5 0 0 1 0\
-1h4a.5.5 0 0 0 \
.5-.5v-4a.5.5 0 \
0 1 .5-.5m5 0a.5\
.5 0 0 1 .5.5v4a\
.5.5 0 0 0 .5.5h\
4a.5.5 0 0 1 0 1\
h-4A1.5 1.5 0 0 \
1 10 4.5v-4a.5.5\
 0 0 1 .5-.5M0 1\
0.5a.5.5 0 0 1 .\
5-.5h4A1.5 1.5 0\
 0 1 6 11.5v4a.5\
.5 0 0 1-1 0v-4a\
.5.5 0 0 0-.5-.5\
h-4a.5.5 0 0 1-.\
5-.5m10 1a1.5 1.\
5 0 0 1 1.5-1.5h\
4a.5.5 0 0 1 0 1\
h-4a.5.5 0 0 0-.\
5.5v4a.5.5 0 0 1\
-1 0z\x22/>\x0d\x0a</svg>\
\
\x00\x00\x01k\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-send\x22 viewBox=\
\x220 0 16 16\x22>\x0a  <\
path d=\x22M15.854.\
146a.5.5 0 0 1 .\
11.54l-5.819 14.\
547a.75.75 0 0 1\
-1.329.124l-3.17\
8-4.995L.643 7.1\
84a.75.75 0 0 1 \
.124-1.33L15.314\
.037a.5.5 0 0 1 \
.54.11ZM6.636 10\
.07l2.761 4.338L\
14.13 2.576zm6.7\
87-8.201L1.591 6\
.602l4.339 2.76z\
\x22/>\x0a</svg>\
\x00\x00\x012\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-compac\
t-right\x22 viewBox\
=\x220 0 16 16\x22>\x0d\x0a \
 <path fill-rule\
=\x22evenodd\x22 d=\x22M6\
.776 1.553a.5.5 \
0 0 1 .671.223l3\
 6a.5.5 0 0 1 0 \
.448l-3 6a.5.5 0\
 1 1-.894-.448L9\
.44 8 6.553 2.22\
4a.5.5 0 0 1 .22\
3-.671\x22/>\x0d\x0a</svg\
>\
\x00\x00\x01\x10\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-up\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0d\x0a  <path fill\
-rule=\x22evenodd\x22 \
d=\x22M7.646 4.646a\
.5.5 0 0 1 .708 \
0l6 6a.5.5 0 0 1\
-.708.708L8 5.70\
7l-5.646 5.647a.\
5.5 0 0 1-.708-.\
708z\x22/>\x0d\x0a</svg>\
\x00\x00\x01[\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-play-circle\x22 v\
iewBox=\x220 0 16 1\
6\x22>\x0d\x0a  <path d=\x22\
M8 15A7 7 0 1 1 \
8 1a7 7 0 0 1 0 \
14m0 1A8 8 0 1 0\
 8 0a8 8 0 0 0 0\
 16\x22/>\x0d\x0a  <path \
d=\x22M6.271 5.055a\
.5.5 0 0 1 .52.0\
38l3.5 2.5a.5.5 \
0 0 1 0 .814l-3.\
5 2.5A.5.5 0 0 1\
 6 10.5v-5a.5.5 \
0 0 1 .271-.445\x22\
/>\x0d\x0a</svg>\
\x00\x00\x02:\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-arrow-repeat\x22 \
viewBox=\x220 0 16 \
16\x22>\x0a  <path d=\x22\
M11.534 7h3.932a\
.25.25 0 0 1 .19\
2.41l-1.966 2.36\
a.25.25 0 0 1-.3\
84 0l-1.966-2.36\
a.25.25 0 0 1 .1\
92-.41m-11 2h3.9\
32a.25.25 0 0 0 \
.192-.41L2.692 6\
.23a.25.25 0 0 0\
-.384 0L.342 8.5\
9A.25.25 0 0 0 .\
534 9\x22/>\x0a  <path\
 fill-rule=\x22even\
odd\x22 d=\x22M8 3c-1.\
552 0-2.94.707-3\
.857 1.818a.5.5 \
0 1 1-.771-.636A\
6.002 6.002 0 0 \
1 13.917 7H12.9A\
5 5 0 0 0 8 3M3.\
1 9a5.002 5.002 \
0 0 0 8.757 2.18\
2.5.5 0 1 1 .771\
.636A6.002 6.002\
 0 0 1 2.083 9z\x22\
/>\x0a</svg>\
\x00\x00\x01%\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-left\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path fi\
ll-rule=\x22evenodd\
\x22 d=\x22M11.354 1.6\
46a.5.5 0 0 1 0 \
.708L5.707 8l5.6\
47 5.646a.5.5 0 \
0 1-.708.708l-6-\
6a.5.5 0 0 1 0-.\
708l6-6a.5.5 0 0\
 1 .708 0\x22/>\x0d\x0a</\
svg>\
\x00\x00\x019\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-x-lg\x22 viewBox=\
\x220 0 16 16\x22>\x0d\x0a  \
<path d=\x22M2.146 \
2.854a.5.5 0 1 1\
 .708-.708L8 7.2\
93l5.146-5.147a.\
5.5 0 0 1 .708.7\
08L8.707 8l5.147\
 5.146a.5.5 0 0 \
1-.708.708L8 8.7\
07l-5.146 5.147a\
.5.5 0 0 1-.708-\
.708L7.293 8z\x22/>\
\x0d\x0a</svg>\
\x00\x00\x03\x08\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-cloud-download\
\x22 viewBox=\x220 0 1\
6 16\x22>\x0d\x0a  <path \
d=\x22M4.406 1.342A\
5.53 5.53 0 0 1 \
8 0c2.69 0 4.923\
 2 5.166 4.579C1\
4.758 4.804 16 6\
.137 16 7.773 16\
 9.569 14.502 11\
 12.687 11H10a.5\
.5 0 0 1 0-1h2.6\
88C13.979 10 15 \
8.988 15 7.773c0\
-1.216-1.02-2.22\
8-2.313-2.228h-.\
5v-.5C12.188 2.8\
25 10.328 1 8 1a\
4.53 4.53 0 0 0-\
2.941 1.1c-.757.\
652-1.153 1.438-\
1.153 2.055v.448\
l-.445.049C2.064\
 4.805 1 5.952 1\
 7.318 1 8.785 2\
.23 10 3.781 10H\
6a.5.5 0 0 1 0 1\
H3.781C1.708 11 \
0 9.366 0 7.318c\
0-1.763 1.266-3.\
223 2.942-3.593.\
143-.863.698-1.7\
23 1.464-2.383\x22/\
>\x0d\x0a  <path d=\x22M7\
.646 15.854a.5.5\
 0 0 0 .708 0l3-\
3a.5.5 0 0 0-.70\
8-.708L8.5 14.29\
3V5.5a.5.5 0 0 0\
-1 0v8.793l-2.14\
6-2.147a.5.5 0 0\
 0-.708.708z\x22/>\x0d\
\x0a</svg>\
\x00\x00\x01\xee\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-clipboard\x22 vie\
wBox=\x220 0 16 16\x22\
>\x0d\x0a  <path d=\x22M4\
 1.5H3a2 2 0 0 0\
-2 2V14a2 2 0 0 \
0 2 2h10a2 2 0 0\
 0 2-2V3.5a2 2 0\
 0 0-2-2h-1v1h1a\
1 1 0 0 1 1 1V14\
a1 1 0 0 1-1 1H3\
a1 1 0 0 1-1-1V3\
.5a1 1 0 0 1 1-1\
h1z\x22/>\x0d\x0a  <path \
d=\x22M9.5 1a.5.5 0\
 0 1 .5.5v1a.5.5\
 0 0 1-.5.5h-3a.\
5.5 0 0 1-.5-.5v\
-1a.5.5 0 0 1 .5\
-.5zm-3-1A1.5 1.\
5 0 0 0 5 1.5v1A\
1.5 1.5 0 0 0 6.\
5 4h3A1.5 1.5 0 \
0 0 11 2.5v-1A1.\
5 1.5 0 0 0 9.5 \
0z\x22/>\x0d\x0a</svg>\
\x00\x00\x01&\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-down\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path fi\
ll-rule=\x22evenodd\
\x22 d=\x22M1.646 4.64\
6a.5.5 0 0 1 .70\
8 0L8 10.293l5.6\
46-5.647a.5.5 0 \
0 1 .708.708l-6 \
6a.5.5 0 0 1-.70\
8 0l-6-6a.5.5 0 \
0 1 0-.708\x22/>\x0d\x0a<\
/svg>\
\x00\x00\x02\x0b\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-window-stack\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path d=\
\x22M4.5 6a.5.5 0 1\
 0 0-1 .5.5 0 0 \
0 0 1M6 6a.5.5 0\
 1 0 0-1 .5.5 0 \
0 0 0 1m2-.5a.5.\
5 0 1 1-1 0 .5.5\
 0 0 1 1 0\x22/>\x0d\x0a \
 <path d=\x22M12 1a\
2 2 0 0 1 2 2 2 \
2 0 0 1 2 2v8a2 \
2 0 0 1-2 2H4a2 \
2 0 0 1-2-2 2 2 \
0 0 1-2-2V3a2 2 \
0 0 1 2-2zM2 12V\
5a2 2 0 0 1 2-2h\
9a1 1 0 0 0-1-1H\
2a1 1 0 0 0-1 1v\
8a1 1 0 0 0 1 1m\
1-4v5a1 1 0 0 0 \
1 1h10a1 1 0 0 0\
 1-1V8zm12-1V5a1\
 1 0 0 0-1-1H4a1\
 1 0 0 0-1 1v2z\x22\
/>\x0d\x0a</svg>\
\x00\x00\x01'\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-right\x22\
 viewBox=\x220 0 16\
 16\x22>\x0d\x0a  <path f\
ill-rule=\x22evenod\
d\x22 d=\x22M4.646 1.6\
46a.5.5 0 0 1 .7\
08 0l6 6a.5.5 0 \
0 1 0 .708l-6 6a\
.5.5 0 0 1-.708-\
.708L10.293 8 4.\
646 2.354a.5.5 0\
 0 1 0-.708\x22/>\x0d\x0a\
</svg>\
\x00\x00\x01L\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-stop-circle\x22 v\
iewBox=\x220 0 16 1\
6\x22>\x0a  <path d=\x22M\
8 15A7 7 0 1 1 8\
 1a7 7 0 0 1 0 1\
4m0 1A8 8 0 1 0 \
8 0a8 8 0 0 0 0 \
16\x22/>\x0a  <path d=\
\x22M5 6.5A1.5 1.5 \
0 0 1 6.5 5h3A1.\
5 1.5 0 0 1 11 6\
.5v3A1.5 1.5 0 0\
 1 9.5 11h-3A1.5\
 1.5 0 0 1 5 9.5\
z\x22/>\x0a</svg>\
\x00\x00\x02p\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-folder2-open\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path d=\
\x22M1 3.5A1.5 1.5 \
0 0 1 2.5 2h2.76\
4c.958 0 1.76.56\
 2.311 1.184C7.9\
85 3.648 8.48 4 \
9 4h4.5A1.5 1.5 \
0 0 1 15 5.5v.64\
c.57.265.94.876.\
856 1.546l-.64 5\
.124A2.5 2.5 0 0\
 1 12.733 15H3.2\
66a2.5 2.5 0 0 1\
-2.481-2.19l-.64\
-5.124A1.5 1.5 0\
 0 1 1 6.14zM2 6\
h12v-.5a.5.5 0 0\
 0-.5-.5H9c-.964\
 0-1.71-.629-2.1\
74-1.154C6.374 3\
.334 5.82 3 5.26\
4 3H2.5a.5.5 0 0\
 0-.5.5zm-.367 1\
a.5.5 0 0 0-.496\
.562l.64 5.124A1\
.5 1.5 0 0 0 3.2\
66 14h9.468a1.5 \
1.5 0 0 0 1.489-\
1.314l.64-5.124A\
.5.5 0 0 0 14.36\
7 7z\x22/>\x0d\x0a</svg>\
\x00\x00\x01_\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-pause-circle\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path d=\
\x22M8 15A7 7 0 1 1\
 8 1a7 7 0 0 1 0\
 14m0 1A8 8 0 1 \
0 8 0a8 8 0 0 0 \
0 16\x22/>\x0d\x0a  <path\
 d=\x22M5 6.25a1.25\
 1.25 0 1 1 2.5 \
0v3.5a1.25 1.25 \
0 1 1-2.5 0zm3.5\
 0a1.25 1.25 0 1\
 1 2.5 0v3.5a1.2\
5 1.25 0 1 1-2.5\
 0z\x22/>\x0d\x0a</svg>\
\x00\x00\x01.\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-compac\
t-left\x22 viewBox=\
\x220 0 16 16\x22>\x0d\x0a  \
<path fill-rule=\
\x22evenodd\x22 d=\x22M9.\
224 1.553a.5.5 0\
 0 1 .223.67L6.5\
6 8l2.888 5.776a\
.5.5 0 1 1-.894.\
448l-3-6a.5.5 0 \
0 1 0-.448l3-6a.\
5.5 0 0 1 .67-.2\
23\x22/>\x0d\x0a</svg>\
\x00\x00\x00\xe6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-dash-lg\x22 viewB\
ox=\x220 0 16 16\x22>\x0d\
\x0a  <path fill-ru\
le=\x22evenodd\x22 d=\x22\
M2 8a.5.5 0 0 1 \
.5-.5h11a.5.5 0 \
0 1 0 1h-11A.5.5\
 0 0 1 2 8\x22/>\x0d\x0a<\
/svg>\
\x00\x00\x01\x15\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-three-dots\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0d\x0a  <path d=\x22M\
3 9.5a1.5 1.5 0 \
1 1 0-3 1.5 1.5 \
0 0 1 0 3m5 0a1.\
5 1.5 0 1 1 0-3 \
1.5 1.5 0 0 1 0 \
3m5 0a1.5 1.5 0 \
1 1 0-3 1.5 1.5 \
0 0 1 0 3\x22/>\x0d\x0a</\
svg>\
\x00\x00\x02\x1d\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-fullscreen\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0d\x0a  <path d=\x22M\
1.5 1a.5.5 0 0 0\
-.5.5v4a.5.5 0 0\
 1-1 0v-4A1.5 1.\
5 0 0 1 1.5 0h4a\
.5.5 0 0 1 0 1zM\
10 .5a.5.5 0 0 1\
 .5-.5h4A1.5 1.5\
 0 0 1 16 1.5v4a\
.5.5 0 0 1-1 0v-\
4a.5.5 0 0 0-.5-\
.5h-4a.5.5 0 0 1\
-.5-.5M.5 10a.5.\
5 0 0 1 .5.5v4a.\
5.5 0 0 0 .5.5h4\
a.5.5 0 0 1 0 1h\
-4A1.5 1.5 0 0 1\
 0 14.5v-4a.5.5 \
0 0 1 .5-.5m15 0\
a.5.5 0 0 1 .5.5\
v4a1.5 1.5 0 0 1\
-1.5 1.5h-4a.5.5\
 0 0 1 0-1h4a.5.\
5 0 0 0 .5-.5v-4\
a.5.5 0 0 1 .5-.\
5\x22/>\x0d\x0a</svg>\
\x00\x00\x01`\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-arrow-clockwis\
e\x22 viewBox=\x220 0 \
16 16\x22>\x0a  <path \
fill-rule=\x22eveno\
dd\x22 d=\x22M8 3a5 5 \
0 1 0 4.546 2.91\
4.5.5 0 0 1 .908\
-.417A6 6 0 1 1 \
8 2z\x22/>\x0a  <path \
d=\x22M8 4.466V.534\
a.25.25 0 0 1 .4\
1-.192l2.36 1.96\
6c.12.1.12.284 0\
 .384L8.41 4.658\
A.25.25 0 0 1 8 \
4.466\x22/>\x0a</svg>\
\x00\x00\x01\x87\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-window-fullscr\
een\x22 viewBox=\x220 \
0 16 16\x22>\x0d\x0a  <pa\
th d=\x22M3 3.5a.5.\
5 0 1 1-1 0 .5.5\
 0 0 1 1 0m1.5 0\
a.5.5 0 1 1-1 0 \
.5.5 0 0 1 1 0m1\
 .5a.5.5 0 1 0 0\
-1 .5.5 0 0 0 0 \
1\x22/>\x0d\x0a  <path d=\
\x22M.5 1a.5.5 0 0 \
0-.5.5v13a.5.5 0\
 0 0 .5.5h15a.5.\
5 0 0 0 .5-.5v-1\
3a.5.5 0 0 0-.5-\
.5zM1 5V2h14v3zm\
0 1h14v8H1z\x22/>\x0d\x0a\
</svg>\
\x00\x00\x02$\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-fullscreen-\
exit\x22 viewBox=\x220\
 0 16 16\x22>\x0d\x0a  <p\
ath d=\x22M5.5 0a.5\
.5 0 0 1 .5.5v4A\
1.5 1.5 0 0 1 4.\
5 6h-4a.5.5 0 0 \
1 0-1h4a.5.5 0 0\
 0 .5-.5v-4a.5.5\
 0 0 1 .5-.5m5 0\
a.5.5 0 0 1 .5.5\
v4a.5.5 0 0 0 .5\
.5h4a.5.5 0 0 1 \
0 1h-4A1.5 1.5 0\
 0 1 10 4.5v-4a.\
5.5 0 0 1 .5-.5M\
0 10.5a.5.5 0 0 \
1 .5-.5h4A1.5 1.\
5 0 0 1 6 11.5v4\
a.5.5 0 0 1-1 0v\
-4a.5.5 0 0 0-.5\
-.5h-4a.5.5 0 0 \
1-.5-.5m10 1a1.5\
 1.5 0 0 1 1.5-1\
.5h4a.5.5 0 0 1 \
0 1h-4a.5.5 0 0 \
0-.5.5v4a.5.5 0 \
0 1-1 0z\x22/>\x0d\x0a</s\
vg>\
\x00\x00\x01n\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-send\x22 viewB\
ox=\x220 0 16 16\x22>\x0a\
  <path d=\x22M15.8\
54.146a.5.5 0 0 \
1 .11.54l-5.819 \
14.547a.75.75 0 \
0 1-1.329.124l-3\
.178-4.995L.643 \
7.184a.75.75 0 0\
 1 .124-1.33L15.\
314.037a.5.5 0 0\
 1 .54.11ZM6.636\
 10.07l2.761 4.3\
38L14.13 2.576zm\
6.787-8.201L1.59\
1 6.602l4.339 2.\
76z\x22/>\x0a</svg>\
\x00\x00\x015\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-com\
pact-right\x22 view\
Box=\x220 0 16 16\x22>\
\x0d\x0a  <path fill-r\
ule=\x22evenodd\x22 d=\
\x22M6.776 1.553a.5\
.5 0 0 1 .671.22\
3l3 6a.5.5 0 0 1\
 0 .448l-3 6a.5.\
5 0 1 1-.894-.44\
8L9.44 8 6.553 2\
.224a.5.5 0 0 1 \
.223-.671\x22/>\x0d\x0a</\
svg>\
\x00\x00\x01\x13\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-up\x22\
 viewBox=\x220 0 16\
 16\x22>\x0d\x0a  <path f\
ill-rule=\x22evenod\
d\x22 d=\x22M7.646 4.6\
46a.5.5 0 0 1 .7\
08 0l6 6a.5.5 0 \
0 1-.708.708L8 5\
.707l-5.646 5.64\
7a.5.5 0 0 1-.70\
8-.708z\x22/>\x0d\x0a</sv\
g>\
\x00\x00\x01^\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-play-circle\
\x22 viewBox=\x220 0 1\
6 16\x22>\x0d\x0a  <path \
d=\x22M8 15A7 7 0 1\
 1 8 1a7 7 0 0 1\
 0 14m0 1A8 8 0 \
1 0 8 0a8 8 0 0 \
0 0 16\x22/>\x0d\x0a  <pa\
th d=\x22M6.271 5.0\
55a.5.5 0 0 1 .5\
2.038l3.5 2.5a.5\
.5 0 0 1 0 .814l\
-3.5 2.5A.5.5 0 \
0 1 6 10.5v-5a.5\
.5 0 0 1 .271-.4\
45\x22/>\x0d\x0a</svg>\
\x00\x00\x02=\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-arrow-repea\
t\x22 viewBox=\x220 0 \
16 16\x22>\x0a  <path \
d=\x22M11.534 7h3.9\
32a.25.25 0 0 1 \
.192.41l-1.966 2\
.36a.25.25 0 0 1\
-.384 0l-1.966-2\
.36a.25.25 0 0 1\
 .192-.41m-11 2h\
3.932a.25.25 0 0\
 0 .192-.41L2.69\
2 6.23a.25.25 0 \
0 0-.384 0L.342 \
8.59A.25.25 0 0 \
0 .534 9\x22/>\x0a  <p\
ath fill-rule=\x22e\
venodd\x22 d=\x22M8 3c\
-1.552 0-2.94.70\
7-3.857 1.818a.5\
.5 0 1 1-.771-.6\
36A6.002 6.002 0\
 0 1 13.917 7H12\
.9A5 5 0 0 0 8 3\
M3.1 9a5.002 5.0\
02 0 0 0 8.757 2\
.182.5.5 0 1 1 .\
771.636A6.002 6.\
002 0 0 1 2.083 \
9z\x22/>\x0a</svg>\
\x00\x00\x01(\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-lef\
t\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 fill-rule=\x22even\
odd\x22 d=\x22M11.354 \
1.646a.5.5 0 0 1\
 0 .708L5.707 8l\
5.647 5.646a.5.5\
 0 0 1-.708.708l\
-6-6a.5.5 0 0 1 \
0-.708l6-6a.5.5 \
0 0 1 .708 0\x22/>\x0d\
\x0a</svg>\
\x00\x00\x01<\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-x-lg\x22 viewB\
ox=\x220 0 16 16\x22>\x0d\
\x0a  <path d=\x22M2.1\
46 2.854a.5.5 0 \
1 1 .708-.708L8 \
7.293l5.146-5.14\
7a.5.5 0 0 1 .70\
8.708L8.707 8l5.\
147 5.146a.5.5 0\
 0 1-.708.708L8 \
8.707l-5.146 5.1\
47a.5.5 0 0 1-.7\
08-.708L7.293 8z\
\x22/>\x0d\x0a</svg>\
\x00\x00\x03\x0b\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-cloud-downl\
oad\x22 viewBox=\x220 \
0 16 16\x22>\x0d\x0a  <pa\
th d=\x22M4.406 1.3\
42A5.53 5.53 0 0\
 1 8 0c2.69 0 4.\
923 2 5.166 4.57\
9C14.758 4.804 1\
6 6.137 16 7.773\
 16 9.569 14.502\
 11 12.687 11H10\
a.5.5 0 0 1 0-1h\
2.688C13.979 10 \
15 8.988 15 7.77\
3c0-1.216-1.02-2\
.228-2.313-2.228\
h-.5v-.5C12.188 \
2.825 10.328 1 8\
 1a4.53 4.53 0 0\
 0-2.941 1.1c-.7\
57.652-1.153 1.4\
38-1.153 2.055v.\
448l-.445.049C2.\
064 4.805 1 5.95\
2 1 7.318 1 8.78\
5 2.23 10 3.781 \
10H6a.5.5 0 0 1 \
0 1H3.781C1.708 \
11 0 9.366 0 7.3\
18c0-1.763 1.266\
-3.223 2.942-3.5\
93.143-.863.698-\
1.723 1.464-2.38\
3\x22/>\x0d\x0a  <path d=\
\x22M7.646 15.854a.\
5.5 0 0 0 .708 0\
l3-3a.5.5 0 0 0-\
.708-.708L8.5 14\
.293V5.5a.5.5 0 \
0 0-1 0v8.793l-2\
.146-2.147a.5.5 \
0 0 0-.708.708z\x22\
/>\x0d\x0a</svg>\
\x00\x00\x01\xf1\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-clipboard\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path d=\
\x22M4 1.5H3a2 2 0 \
0 0-2 2V14a2 2 0\
 0 0 2 2h10a2 2 \
0 0 0 2-2V3.5a2 \
2 0 0 0-2-2h-1v1\
h1a1 1 0 0 1 1 1\
V14a1 1 0 0 1-1 \
1H3a1 1 0 0 1-1-\
1V3.5a1 1 0 0 1 \
1-1h1z\x22/>\x0d\x0a  <pa\
th d=\x22M9.5 1a.5.\
5 0 0 1 .5.5v1a.\
5.5 0 0 1-.5.5h-\
3a.5.5 0 0 1-.5-\
.5v-1a.5.5 0 0 1\
 .5-.5zm-3-1A1.5\
 1.5 0 0 0 5 1.5\
v1A1.5 1.5 0 0 0\
 6.5 4h3A1.5 1.5\
 0 0 0 11 2.5v-1\
A1.5 1.5 0 0 0 9\
.5 0z\x22/>\x0d\x0a</svg>\
\
\x00\x00\x01)\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-dow\
n\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 fill-rule=\x22even\
odd\x22 d=\x22M1.646 4\
.646a.5.5 0 0 1 \
.708 0L8 10.293l\
5.646-5.647a.5.5\
 0 0 1 .708.708l\
-6 6a.5.5 0 0 1-\
.708 0l-6-6a.5.5\
 0 0 1 0-.708\x22/>\
\x0d\x0a</svg>\
\x00\x00\x02\x0e\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-window-stac\
k\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 d=\x22M4.5 6a.5.5 \
0 1 0 0-1 .5.5 0\
 0 0 0 1M6 6a.5.\
5 0 1 0 0-1 .5.5\
 0 0 0 0 1m2-.5a\
.5.5 0 1 1-1 0 .\
5.5 0 0 1 1 0\x22/>\
\x0d\x0a  <path d=\x22M12\
 1a2 2 0 0 1 2 2\
 2 2 0 0 1 2 2v8\
a2 2 0 0 1-2 2H4\
a2 2 0 0 1-2-2 2\
 2 0 0 1-2-2V3a2\
 2 0 0 1 2-2zM2 \
12V5a2 2 0 0 1 2\
-2h9a1 1 0 0 0-1\
-1H2a1 1 0 0 0-1\
 1v8a1 1 0 0 0 1\
 1m1-4v5a1 1 0 0\
 0 1 1h10a1 1 0 \
0 0 1-1V8zm12-1V\
5a1 1 0 0 0-1-1H\
4a1 1 0 0 0-1 1v\
2z\x22/>\x0d\x0a</svg>\
\x00\x00\x01*\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-rig\
ht\x22 viewBox=\x220 0\
 16 16\x22>\x0d\x0a  <pat\
h fill-rule=\x22eve\
nodd\x22 d=\x22M4.646 \
1.646a.5.5 0 0 1\
 .708 0l6 6a.5.5\
 0 0 1 0 .708l-6\
 6a.5.5 0 0 1-.7\
08-.708L10.293 8\
 4.646 2.354a.5.\
5 0 0 1 0-.708\x22/\
>\x0d\x0a</svg>\
\x00\x00\x01O\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-stop-circle\
\x22 viewBox=\x220 0 1\
6 16\x22>\x0a  <path d\
=\x22M8 15A7 7 0 1 \
1 8 1a7 7 0 0 1 \
0 14m0 1A8 8 0 1\
 0 8 0a8 8 0 0 0\
 0 16\x22/>\x0a  <path\
 d=\x22M5 6.5A1.5 1\
.5 0 0 1 6.5 5h3\
A1.5 1.5 0 0 1 1\
1 6.5v3A1.5 1.5 \
0 0 1 9.5 11h-3A\
1.5 1.5 0 0 1 5 \
9.5z\x22/>\x0a</svg>\
\x00\x00\x02s\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-folder2-ope\
n\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 d=\x22M1 3.5A1.5 1\
.5 0 0 1 2.5 2h2\
.764c.958 0 1.76\
.56 2.311 1.184C\
7.985 3.648 8.48\
 4 9 4h4.5A1.5 1\
.5 0 0 1 15 5.5v\
.64c.57.265.94.8\
76.856 1.546l-.6\
4 5.124A2.5 2.5 \
0 0 1 12.733 15H\
3.266a2.5 2.5 0 \
0 1-2.481-2.19l-\
.64-5.124A1.5 1.\
5 0 0 1 1 6.14zM\
2 6h12v-.5a.5.5 \
0 0 0-.5-.5H9c-.\
964 0-1.71-.629-\
2.174-1.154C6.37\
4 3.334 5.82 3 5\
.264 3H2.5a.5.5 \
0 0 0-.5.5zm-.36\
7 1a.5.5 0 0 0-.\
496.562l.64 5.12\
4A1.5 1.5 0 0 0 \
3.266 14h9.468a1\
.5 1.5 0 0 0 1.4\
89-1.314l.64-5.1\
24A.5.5 0 0 0 14\
.367 7z\x22/>\x0d\x0a</sv\
g>\
\x00\x00\x01b\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-pause-circl\
e\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 d=\x22M8 15A7 7 0 \
1 1 8 1a7 7 0 0 \
1 0 14m0 1A8 8 0\
 1 0 8 0a8 8 0 0\
 0 0 16\x22/>\x0d\x0a  <p\
ath d=\x22M5 6.25a1\
.25 1.25 0 1 1 2\
.5 0v3.5a1.25 1.\
25 0 1 1-2.5 0zm\
3.5 0a1.25 1.25 \
0 1 1 2.5 0v3.5a\
1.25 1.25 0 1 1-\
2.5 0z\x22/>\x0d\x0a</svg\
>\
\x00\x00\x011\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-com\
pact-left\x22 viewB\
ox=\x220 0 16 16\x22>\x0d\
\x0a  <path fill-ru\
le=\x22evenodd\x22 d=\x22\
M9.224 1.553a.5.\
5 0 0 1 .223.67L\
6.56 8l2.888 5.7\
76a.5.5 0 1 1-.8\
94.448l-3-6a.5.5\
 0 0 1 0-.448l3-\
6a.5.5 0 0 1 .67\
-.223\x22/>\x0d\x0a</svg>\
\
\x00\x00\x00\xe9\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-dash-lg\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0d\x0a  <path fill\
-rule=\x22evenodd\x22 \
d=\x22M2 8a.5.5 0 0\
 1 .5-.5h11a.5.5\
 0 0 1 0 1h-11A.\
5.5 0 0 1 2 8\x22/>\
\x0d\x0a</svg>\
\x00\x00\x01\x18\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-three-dots\x22\
 viewBox=\x220 0 16\
 16\x22>\x0d\x0a  <path d\
=\x22M3 9.5a1.5 1.5\
 0 1 1 0-3 1.5 1\
.5 0 0 1 0 3m5 0\
a1.5 1.5 0 1 1 0\
-3 1.5 1.5 0 0 1\
 0 3m5 0a1.5 1.5\
 0 1 1 0-3 1.5 1\
.5 0 0 1 0 3\x22/>\x0d\
\x0a</svg>\
\x00\x00\x02 \
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-fullscreen\x22\
 viewBox=\x220 0 16\
 16\x22>\x0d\x0a  <path d\
=\x22M1.5 1a.5.5 0 \
0 0-.5.5v4a.5.5 \
0 0 1-1 0v-4A1.5\
 1.5 0 0 1 1.5 0\
h4a.5.5 0 0 1 0 \
1zM10 .5a.5.5 0 \
0 1 .5-.5h4A1.5 \
1.5 0 0 1 16 1.5\
v4a.5.5 0 0 1-1 \
0v-4a.5.5 0 0 0-\
.5-.5h-4a.5.5 0 \
0 1-.5-.5M.5 10a\
.5.5 0 0 1 .5.5v\
4a.5.5 0 0 0 .5.\
5h4a.5.5 0 0 1 0\
 1h-4A1.5 1.5 0 \
0 1 0 14.5v-4a.5\
.5 0 0 1 .5-.5m1\
5 0a.5.5 0 0 1 .\
5.5v4a1.5 1.5 0 \
0 1-1.5 1.5h-4a.\
5.5 0 0 1 0-1h4a\
.5.5 0 0 0 .5-.5\
v-4a.5.5 0 0 1 .\
5-.5\x22/>\x0d\x0a</svg>\
\x00\x00\x01c\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-arrow-clock\
wise\x22 viewBox=\x220\
 0 16 16\x22>\x0a  <pa\
th fill-rule=\x22ev\
enodd\x22 d=\x22M8 3a5\
 5 0 1 0 4.546 2\
.914.5.5 0 0 1 .\
908-.417A6 6 0 1\
 1 8 2z\x22/>\x0a  <pa\
th d=\x22M8 4.466V.\
534a.25.25 0 0 1\
 .41-.192l2.36 1\
.966c.12.1.12.28\
4 0 .384L8.41 4.\
658A.25.25 0 0 1\
 8 4.466\x22/>\x0a</sv\
g>\
\x00\x00\x01\x8a\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-window-full\
screen\x22 viewBox=\
\x220 0 16 16\x22>\x0d\x0a  \
<path d=\x22M3 3.5a\
.5.5 0 1 1-1 0 .\
5.5 0 0 1 1 0m1.\
5 0a.5.5 0 1 1-1\
 0 .5.5 0 0 1 1 \
0m1 .5a.5.5 0 1 \
0 0-1 .5.5 0 0 0\
 0 1\x22/>\x0d\x0a  <path\
 d=\x22M.5 1a.5.5 0\
 0 0-.5.5v13a.5.\
5 0 0 0 .5.5h15a\
.5.5 0 0 0 .5-.5\
v-13a.5.5 0 0 0-\
.5-.5zM1 5V2h14v\
3zm0 1h14v8H1z\x22/\
>\x0d\x0a</svg>\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x03\
\x00\x00V\x83\
\x00Q\
\x00S\x00S\
\x00\x04\
\x00\x04\xa8\x8b\
\x00D\
\x00a\x00r\x00k\
\x00\x05\
\x00R\xfd\xf4\
\x00L\
\x00i\x00g\x00h\x00t\
\x00\x0f\
\x03U\x92\x03\
\x00P\
\x00r\x00o\x00g\x00r\x00e\x00s\x00s\x00B\x00a\x00r\x00.\x00q\x00s\x00s\
\x00\x0a\
\x0bha\xc3\
\x00B\
\x00u\x00t\x00t\x00o\x00n\x00.\x00q\x00s\x00s\
\x00\x07\
\x08\x85X#\
\x00B\
\x00a\x00r\x00.\x00q\x00s\x00s\
\x00\x0c\
\x00V+C\
\x00C\
\x00h\x00e\x00c\x00k\x00B\x00o\x00x\x00.\x00q\x00s\x00s\
\x00\x0b\
\x09Vuc\
\x00B\
\x00r\x00o\x00w\x00s\x00e\x00r\x00.\x00q\x00s\x00s\
\x00\x0b\
\x09\xdd\x94\xa3\
\x00T\
\x00o\x00o\x00l\x00B\x00o\x00x\x00.\x00q\x00s\x00s\
\x00\x0e\
\x00\xd4\xf5\x83\
\x00C\
\x00h\x00a\x00t\x00W\x00i\x00d\x00g\x00e\x00t\x00.\x00q\x00s\x00s\
\x00\x08\
\x00\xa7R\xc3\
\x00L\
\x00i\x00s\x00t\x00.\x00q\x00s\x00s\
\x00\x08\
\x0b\x07Q\xc3\
\x00E\
\x00d\x00i\x00t\x00.\x00q\x00s\x00s\
\x00\x0a\
\x0a\xce\x1dC\
\x00S\
\x00l\x00i\x00d\x00e\x00r\x00.\x00q\x00s\x00s\
\x00\x0c\
\x00'*\xc3\
\x00C\
\x00o\x00m\x00b\x00o\x00B\x00o\x00x\x00.\x00q\x00s\x00s\
\x00\x0c\
\x00\xb9\x80#\
\x00G\
\x00r\x00o\x00u\x00p\x00B\x00o\x00x\x00.\x00q\x00s\x00s\
\x00\x0e\
\x0d\xa0/\xc3\
\x00S\
\x00c\x00r\x00o\x00l\x00l\x00A\x00r\x00e\x00a\x00.\x00q\x00s\x00s\
\x00\x09\
\x08\xbf\xfcC\
\x00L\
\x00a\x00b\x00e\x00l\x00.\x00q\x00s\x00s\
\x00\x07\
\x0auX\x03\
\x00T\
\x00a\x00b\x00.\x00q\x00s\x00s\
\x00\x08\
\x08\xb8S\xc3\
\x00T\
\x00r\x00e\x00e\x00.\x00q\x00s\x00s\
\x00\x0a\
\x0f\xcf\xbd\xa3\
\x00P\
\x00l\x00a\x00y\x00e\x00r\x00.\x00q\x00s\x00s\
\x00\x08\
\x0cXR\xc3\
\x00M\
\x00e\x00n\x00u\x00.\x00q\x00s\x00s\
\x00\x0e\
\x06\x86\xf5#\
\x00D\
\x00o\x00c\x00k\x00W\x00i\x00d\x00g\x00e\x00t\x00.\x00q\x00s\x00s\
\x00\x09\
\x09(\xecC\
\x00T\
\x00a\x00b\x00l\x00e\x00.\x00q\x00s\x00s\
\x00\x0b\
\x09\xdf\xb8\xe3\
\x00S\
\x00p\x00i\x00n\x00B\x00o\x00x\x00.\x00q\x00s\x00s\
\x00\x13\
\x09{\x1d\x87\
\x00F\
\x00u\x00l\x00l\x00S\x00c\x00r\x00e\x00e\x00n\x00-\x00E\x00x\x00i\x00t\x00.\x00s\
\x00v\x00g\
\x00\x08\
\x0cGQ\xe7\
\x00S\
\x00e\x00n\x00d\x00.\x00s\x00v\x00g\
\x00\x18\
\x00 \x8b\xc7\
\x00C\
\x00o\x00m\x00p\x00a\x00c\x00t\x00C\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00R\x00i\
\x00g\x00h\x00t\x00.\x00s\x00v\x00g\
\x00\x0e\
\x0fXd\x87\
\x00C\
\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00U\x00p\x00.\x00s\x00v\x00g\
\x00\x08\
\x02\x8cP'\
\x00P\
\x00l\x00a\x00y\x00.\x00s\x00v\x00g\
\x00\x10\
\x06\xd0dG\
\x00A\
\x00r\x00r\x00o\x00w\x00-\x00R\x00e\x00p\x00e\x00a\x00t\x00.\x00s\x00v\x00g\
\x00\x10\
\x00\xe9\x05\xa7\
\x00C\
\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00L\x00e\x00f\x00t\x00.\x00s\x00v\x00g\
\x00\x05\
\x00[Z\xc7\
\x00X\
\x00.\x00s\x00v\x00g\
\x00\x0c\
\x0c\x1a\x90\xa7\
\x00D\
\x00o\x00w\x00n\x00l\x00o\x00a\x00d\x00.\x00s\x00v\x00g\
\x00\x0d\
\x0c\xe7\x89G\
\x00C\
\x00l\x00i\x00p\x00b\x00o\x00a\x00r\x00d\x00.\x00s\x00v\x00g\
\x00\x10\
\x0e\x1f\x02\x87\
\x00C\
\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00D\x00o\x00w\x00n\x00.\x00s\x00v\x00g\
\x00\x10\
\x01Y\x8e\xa7\
\x00W\
\x00i\x00n\x00d\x00o\x00w\x00-\x00S\x00t\x00a\x00c\x00k\x00.\x00s\x00v\x00g\
\x00\x11\
\x0e\x12\xb8G\
\x00C\
\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00R\x00i\x00g\x00h\x00t\x00.\x00s\x00v\x00g\
\
\x00\x08\
\x0bcQ\x87\
\x00S\
\x00t\x00o\x00p\x00.\x00s\x00v\x00g\
\x00\x10\
\x03\xa1m\x87\
\x00O\
\x00p\x00e\x00n\x00e\x00d\x00F\x00o\x00l\x00d\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x09\
\x0c\x98\xf7\xc7\
\x00P\
\x00a\x00u\x00s\x00e\x00.\x00s\x00v\x00g\
\x00\x17\
\x0c\x0a&\x87\
\x00C\
\x00o\x00m\x00p\x00a\x00c\x00t\x00C\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00L\x00e\
\x00f\x00t\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\x9bS\x87\
\x00D\
\x00a\x00s\x00h\x00.\x00s\x00v\x00g\
\x00\x0c\
\x03\x84:'\
\x00E\
\x00l\x00l\x00i\x00p\x00s\x00i\x00s\x00.\x00s\x00v\x00g\
\x00\x0e\
\x03\xe2|\xa7\
\x00F\
\x00u\x00l\x00l\x00S\x00c\x00r\x00e\x00e\x00n\x00.\x00s\x00v\x00g\
\x00\x13\
\x06\x9a\xb5'\
\x00A\
\x00r\x00r\x00o\x00w\x00-\x00C\x00l\x00o\x00c\x00k\x00w\x00i\x00s\x00e\x00.\x00s\
\x00v\x00g\
\x00\x15\
\x01;\x18\x87\
\x00W\
\x00i\x00n\x00d\x00o\x00w\x00-\x00F\x00u\x00l\x00l\x00S\x00c\x00r\x00e\x00e\x00n\
\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x01\x00\x00\x002\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x04\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x1c\x00\x02\x00\x00\x00\x16\x00\x00\x00\x1c\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00*\x00\x02\x00\x00\x00\x16\x00\x00\x00\x06\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x02\xb2\x00\x00\x00\x00\x00\x01\x00\x00k\xa6\
\x00\x00\x01\x93\x9btC\xc0\
\x00\x00\x03l\x00\x00\x00\x00\x00\x01\x00\x00r\xb6\
\x00\x00\x01\x8f\xa4\x14\xc0l\
\x00\x00\x03F\x00\x00\x00\x00\x00\x01\x00\x00q\x8d\
\x00\x00\x01\x93\x9bt\xa7\xfa\
\x00\x00\x058\x00\x00\x00\x00\x00\x01\x00\x00\x896\
\x00\x00\x01\x95\xf1LSQ\
\x00\x00\x03\xe0\x00\x00\x00\x00\x00\x01\x00\x00z\x1b\
\x00\x00\x01\x95\xf1L_,\
\x00\x00\x03\x0a\x00\x00\x00\x00\x00\x01\x00\x00m\xf0\
\x00\x00\x01\x8f\xa4 ;\x0f\
\x00\x00\x04\xcc\x00\x00\x00\x00\x00\x01\x00\x00\x84\x98\
\x00\x00\x01\x8f\xa4\x07\xf2\xfb\
\x00\x00\x04D\x00\x00\x00\x00\x00\x01\x00\x00~\xa5\
\x00\x00\x01\x8f\xa4\x07\xdd\xac\
\x00\x00\x04\xea\x00\x00\x00\x00\x00\x01\x00\x00\x85\xb1\
\x00\x00\x01\x8f\xa4\x07\xeb+\
\x00\x00\x05\x0c\x00\x00\x00\x00\x00\x01\x00\x00\x87\xd2\
\x00\x00\x01\x96R\xa5l\x93\
\x00\x00\x03 \x00\x00\x00\x00\x00\x01\x00\x00oO\
\x00\x00\x01\x96g]\xd1\xb2\
\x00\x00\x04\xb6\x00\x00\x00\x00\x00\x01\x00\x00\x83\xae\
\x00\x00\x01\x8f\xa4\x08\x035\
\x00\x00\x02p\x00\x00\x00\x00\x00\x01\x00\x00h\x12\
\x00\x00\x01\x8f\xa4\x07\xfa\xef\
\x00\x00\x04.\x00\x00\x00\x00\x00\x01\x00\x00}U\
\x00\x00\x01\x96g^\x16\xdb\
\x00\x00\x04\x82\x00\x00\x00\x00\x00\x01\x00\x00\x82|\
\x00\x00\x01\x93\x9btJ\xee\
\x00\x00\x03|\x00\x00\x00\x00\x00\x01\x00\x00s\xf3\
\x00\x00\x01\x93\x9bt;u\
\x00\x00\x02\x9c\x00\x00\x00\x00\x00\x01\x00\x00j7\
\x00\x00\x01\x96g^\x05\xf3\
\x00\x00\x04j\x00\x00\x00\x00\x00\x01\x00\x00\x81\x19\
\x00\x00\x01\x8f\xa4\x07\xd5]\
\x00\x00\x03\x9a\x00\x00\x00\x00\x00\x01\x00\x00v\xff\
\x00\x00\x01\x93\x9btTC\
\x00\x00\x04\x06\x00\x00\x00\x00\x00\x01\x00\x00|*\
\x00\x00\x01\x93\x9bti|\
\x00\x00\x03\xba\x00\x00\x00\x00\x00\x01\x00\x00x\xf1\
\x00\x00\x01\x93\x9btr\xae\
\x00\x00\x02\xe8\x00\x00\x00\x00\x00\x01\x00\x00l\xdc\
\x00\x00\x01\x93\x9bt`\x8c\
\x00\x00\x02\xb2\x00\x00\x00\x00\x00\x01\x00\x00\x8e[\
\x00\x00\x01\x93\x9bt\xb1.\
\x00\x00\x03l\x00\x00\x00\x00\x00\x01\x00\x00\x95z\
\x00\x00\x01\x8f\xa4\x08\x0b\x8c\
\x00\x00\x03F\x00\x00\x00\x00\x00\x01\x00\x00\x94N\
\x00\x00\x01\x93\x9bt\xd1b\
\x00\x00\x058\x00\x00\x00\x00\x00\x01\x00\x00\xac$\
\x00\x00\x01\x95\xf1L>=\
\x00\x00\x03\xe0\x00\x00\x00\x00\x00\x01\x00\x00\x9c\xeb\
\x00\x00\x01\x95\xf1LF\xbe\
\x00\x00\x03\x0a\x00\x00\x00\x00\x00\x01\x00\x00\x90\xab\
\x00\x00\x01\x8f\xa4 \x01M\
\x00\x00\x04\xcc\x00\x00\x00\x00\x00\x01\x00\x00\xa7}\
\x00\x00\x01\x8f\xa4 \x086\
\x00\x00\x04D\x00\x00\x00\x00\x00\x01\x00\x00\xa1~\
\x00\x00\x01\x8f\xa4\x14\xce\xc2\
\x00\x00\x04\xea\x00\x00\x00\x00\x00\x01\x00\x00\xa8\x99\
\x00\x00\x01\x8f\xa4 4\x84\
\x00\x00\x05\x0c\x00\x00\x00\x00\x00\x01\x00\x00\xaa\xbd\
\x00\x00\x01\x96R\xa6\x8d\x93\
\x00\x00\x03 \x00\x00\x00\x00\x00\x01\x00\x00\x92\x0d\
\x00\x00\x01\x96g^\x8d\xe6\
\x00\x00\x04\xb6\x00\x00\x00\x00\x00\x01\x00\x00\xa6\x90\
\x00\x00\x01\x8f\xa4 \x11q\
\x00\x00\x02p\x00\x00\x00\x00\x00\x01\x00\x00\x8a\xc1\
\x00\x00\x01\x8f\xa4\x08$U\
\x00\x00\x04.\x00\x00\x00\x00\x00\x01\x00\x00\xa0+\
\x00\x00\x01\x96g^y\x0f\
\x00\x00\x04\x82\x00\x00\x00\x00\x00\x01\x00\x00\xa5[\
\x00\x00\x01\x93\x9bt\x81\xf6\
\x00\x00\x03|\x00\x00\x00\x00\x00\x01\x00\x00\x96\xba\
\x00\x00\x01\x93\x9btz\x0b\
\x00\x00\x02\x9c\x00\x00\x00\x00\x00\x01\x00\x00\x8c\xe9\
\x00\x00\x01\x96g^\xa0*\
\x00\x00\x04j\x00\x00\x00\x00\x00\x01\x00\x00\xa3\xf5\
\x00\x00\x01\x8f\xa4\x14\xc8\x00\
\x00\x00\x03\x9a\x00\x00\x00\x00\x00\x01\x00\x00\x99\xc9\
\x00\x00\x01\x93\x9bt\x8b\x09\
\x00\x00\x04\x06\x00\x00\x00\x00\x00\x01\x00\x00\x9e\xfd\
\x00\x00\x01\x93\x9bt\x9bb\
\x00\x00\x03\xba\x00\x00\x00\x00\x00\x01\x00\x00\x9b\xbe\
\x00\x00\x01\x93\x9bt\xc8\xa3\
\x00\x00\x02\xe8\x00\x00\x00\x00\x00\x01\x00\x00\x8f\x94\
\x00\x00\x01\x93\x9bt\x93d\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x02\x00\x00\x003\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x1c\x00\x02\x00\x00\x00\x15\x00\x00\x00J\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00*\x00\x02\x00\x00\x00\x15\x00\x00\x005\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x01J\x00\x00\x00\x00\x00\x01\x00\x00\x147\
\x00\x00\x01\x98\xe9(\xc9@\
\x00\x00\x00\x8c\x00\x00\x00\x00\x00\x01\x00\x00\x05d\
\x00\x00\x01\x92\xe6\xf4\xad\x97\
\x00\x00\x01\x04\x00\x00\x00\x00\x00\x01\x00\x00\x0c\xa4\
\x00\x00\x01\x96R\xcai\xc8\
\x00\x00\x01h\x00\x00\x00\x00\x00\x01\x00\x00\x1bE\
\x00\x00\x01\x96h\x10\xa6&\
\x00\x00\x00\xe2\x00\x00\x00\x00\x00\x01\x00\x00\x0a\xa6\
\x00\x00\x01\x95\xa6V\x0f\x1b\
\x00\x00\x00:\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x92\xc3\x12\xf0\xf0\
\x00\x00\x02\x1a\x00\x00\x00\x00\x00\x01\x00\x00)\xf0\
\x00\x00\x01\x93\xb3\xb71\x15\
\x00\x00\x00x\x00\x00\x00\x00\x00\x01\x00\x00\x04K\
\x00\x00\x01\x92\x1e\x17 \xf4\
\x00\x00\x01\xd4\x00\x00\x00\x00\x00\x01\x00\x00!e\
\x00\x00\x01\x96g\xd0V\xba\
\x00\x00\x01\xa8\x00\x00\x00\x00\x00\x01\x00\x00\x1e\x14\
\x00\x00\x01\x92\x1e\x1a\x0e#\
\x00\x00\x02<\x00\x00\x00\x00\x00\x01\x00\x00*\xf9\
\x00\x00\x01\x96R\xccc\xfa\
\x00\x00\x00\xaa\x00\x00\x00\x00\x00\x01\x00\x00\x06\x8d\
\x00\x00\x01\x96R\xc9=\xe8\
\x00\x00\x00\xc6\x00\x00\x00\x00\x00\x01\x00\x00\x08]\
\x00\x00\x01\x933g\x98\xd5\
\x00\x00\x02T\x00\x00\x00\x00\x00\x01\x00\x00/\x0c\
\x00\x00\x01\x96h\x0d%\xca\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00\x1f3\
\x00\x00\x01\x92\x80P\xd6\x9c\
\x00\x00\x010\x00\x01\x00\x00\x00\x01\x00\x00\x12\xea\
\x00\x00\x01\x92\x8f[-=\
\x00\x00\x01\x1a\x00\x00\x00\x00\x00\x01\x00\x00\x0f9\
\x00\x00\x01\x96R\xc9\xc1\xc6\
\x00\x00\x00^\x00\x01\x00\x00\x00\x01\x00\x00\x01\xfc\
\x00\x00\x01\x92\xdb\x06\x8c\x92\
\x00\x00\x02\x04\x00\x00\x00\x00\x00\x01\x00\x00(\xf4\
\x00\x00\x01\x92\x1e\x1a)\xa6\
\x00\x00\x01\x86\x00\x00\x00\x00\x00\x01\x00\x00\x1d \
\x00\x00\x01\x95\xcf\x95jB\
\x00\x00\x01\xea\x00\x00\x00\x00\x00\x01\x00\x00$\x1d\
\x00\x00\x01\x96R\xcb\xa9\x9d\
\x00\x00\x01J\x00\x00\x00\x00\x00\x01\x00\x00I\xe5\
\x00\x00\x01\x98\xe9(}\xb4\
\x00\x00\x00\x8c\x00\x00\x00\x00\x00\x01\x00\x00:\xd6\
\x00\x00\x01\x92\xe6\xf4\xc1\xb4\
\x00\x00\x01\x04\x00\x00\x00\x00\x00\x01\x00\x00B+\
\x00\x00\x01\x96R\xcaG\xfd\
\x00\x00\x01h\x00\x00\x00\x00\x00\x01\x00\x00Q\x0f\
\x00\x00\x01\x96h\x0f\xffy\
\x00\x00\x00\xe2\x00\x00\x00\x00\x00\x01\x00\x00@*\
\x00\x00\x01\x95\xa6V\x99\xa8\
\x00\x00\x00:\x00\x00\x00\x00\x00\x01\x00\x005i\
\x00\x00\x01\x92\xc3\x12\x99\x84\
\x00\x00\x02\x1a\x00\x00\x00\x00\x00\x01\x00\x00\x5c\x7f\
\x00\x00\x01\x93\xb3\xb7\xf0\xad\
\x00\x00\x00x\x00\x00\x00\x00\x00\x01\x00\x009\xc0\
\x00\x00\x01\x92\x1e\x17 \xf4\
\x00\x00\x01\xd4\x00\x00\x00\x00\x00\x01\x00\x00WI\
\x00\x00\x01\x96h\x16\x92\xf9\
\x00\x00\x01\xa8\x00\x00\x00\x00\x00\x01\x00\x00S\xdf\
\x00\x00\x01\x92\x1e\x187M\
\x00\x00\x02<\x00\x00\x00\x00\x00\x01\x00\x00]\x8b\
\x00\x00\x01\x96R\xcc\x8ca\
\x00\x00\x00\xaa\x00\x00\x00\x00\x00\x01\x00\x00;\xff\
\x00\x00\x01\x96R\xc9\x5c\xb9\
\x00\x00\x00\xc6\x00\x00\x00\x00\x00\x01\x00\x00=\xd8\
\x00\x00\x01\x933h+\xca\
\x00\x00\x02T\x00\x00\x00\x00\x00\x01\x00\x00a\xb3\
\x00\x00\x01\x96h\x0e\xe9\x1b\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00U\x04\
\x00\x00\x01\x92\x80P\xd6\x9c\
\x00\x00\x010\x00\x01\x00\x00\x00\x01\x00\x00H\x96\
\x00\x00\x01\x92\x8f[->\
\x00\x00\x01\x1a\x00\x00\x00\x00\x00\x01\x00\x00D\xcc\
\x00\x00\x01\x96R\xc9\xee\x18\
\x00\x00\x00^\x00\x01\x00\x00\x00\x01\x00\x007l\
\x00\x00\x01\x92\xdb\x06]L\
\x00\x00\x02\x04\x00\x00\x00\x00\x00\x01\x00\x00[\x80\
\x00\x00\x01\x92\x1e\x18L\xbf\
\x00\x00\x01\x86\x00\x00\x00\x00\x00\x01\x00\x00R\xeb\
\x00\x00\x01\x95\xcf\x95\x9fY\
\x00\x00\x01\xea\x00\x01\x00\x00\x00\x01\x00\x00Z\x05\
\x00\x00\x01\x96R\xcb\xbf\xa5\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
