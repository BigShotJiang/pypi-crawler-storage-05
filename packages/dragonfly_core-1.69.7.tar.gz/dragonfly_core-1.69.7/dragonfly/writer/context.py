"""ContextShade Writer.

Note to developers:
Use this module to extend dragonfly's ContextShade writer for new extensions.
(eg. adding `rad` to this module adds the method `ContextShade.to.rad`)
"""
