# genomicshelper
A collection of script templates for Complex Trait Genomics analysis
