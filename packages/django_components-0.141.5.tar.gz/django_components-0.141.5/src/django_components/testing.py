# Public API for test-related functionality
# isort: off
from django_components.util.testing import djc_test

# isort: on

__all__ = [
    "djc_test",
]
