namespace kuzu {
namespace common {

const char* KUZU_VERSION = KUZU_CMAKE_VERSION;
}
} // namespace kuzu
