Kuzu is being developed publicly by Kùzu Inc., under an MIT license in this GitHub repo. We encourage everyone
to open issues and discuss topics only related to Kuzu. We also kindly ask everyone to be
respectful, polite and avoid any hurtful language in any form.
Kùzu Inc. is a startup based in Canada 🇨🇦, a land that is proud of their high standards
for politeness and where a person you bumped into on the road will likely
apologize to you even if it was your fault: so, again, we ask you to please be
kind and respectful to everyone on this GitHub.
If you prefer not to discuss something through open issues and discussions,
you can always reach us through [email](mailto:contact@kuzudb.com).
