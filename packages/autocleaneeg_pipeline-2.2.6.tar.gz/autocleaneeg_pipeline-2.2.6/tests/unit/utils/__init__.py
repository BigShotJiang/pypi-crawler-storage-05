"""Unit tests for AutoClean EEG utility modules."""
