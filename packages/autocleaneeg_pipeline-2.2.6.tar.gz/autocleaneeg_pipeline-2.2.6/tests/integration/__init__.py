"""Integration tests for AutoClean EEG."""
