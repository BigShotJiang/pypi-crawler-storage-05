"""AutoClean EEG test package."""
