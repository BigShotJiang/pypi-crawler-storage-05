# src/autoclean/plugins/eeg_plugins/__init__.py
"""EEG plugins for AutoClean.

This package contains plugins for handling different combinations
of EEG file formats and montage configurations.
"""

# Plugins will be automatically discovered by the plugin system
