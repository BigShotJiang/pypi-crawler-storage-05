if __name__ == "__main__":
    from manga_stitcher_recoskyler.cli import app
    app()
