#!/usr/bin/env python3

from styro.__main__ import app

app()
