from docing.core import *
from docing.tests import *

if __name__ == "__main__":
    main()
