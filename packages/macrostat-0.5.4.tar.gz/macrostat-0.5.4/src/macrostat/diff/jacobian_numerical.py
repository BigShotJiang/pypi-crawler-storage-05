from macrostat.diff import JacobianBase


class JacobianNumerical(JacobianBase):
    pass
