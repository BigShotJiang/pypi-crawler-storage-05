from macrostat.diff import JacobianBase


class JacobianAutodiff(JacobianBase):
    pass
