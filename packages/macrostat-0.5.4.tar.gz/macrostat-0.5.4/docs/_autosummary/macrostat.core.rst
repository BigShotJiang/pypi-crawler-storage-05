﻿Core Module
============

.. automodule:: macrostat.core
