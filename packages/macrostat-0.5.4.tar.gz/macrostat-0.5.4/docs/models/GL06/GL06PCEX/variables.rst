==================
Variables GL06PCEX
==================


The following table contains the default information for the variables of the GL06PCEX model.


.. csv-table::
	:file: variables.csv
	:header-rows: 1
