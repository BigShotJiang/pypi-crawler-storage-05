===================
Variables GL06PCEX2
===================


The following table contains the default information for the variables of the GL06PCEX2 model.


.. csv-table::
	:file: variables.csv
	:header-rows: 1
