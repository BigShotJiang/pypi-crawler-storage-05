===================
Variables GL06SIMEX
===================


The following table contains the default information for the variables of the GL06SIMEX model.


.. csv-table::
	:file: variables.csv
	:header-rows: 1
