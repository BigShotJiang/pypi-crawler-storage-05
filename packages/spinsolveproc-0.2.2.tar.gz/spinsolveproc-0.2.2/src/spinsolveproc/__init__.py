"""Top-level package for spinsolveproc."""

__author__ = """Raquel Serial"""
__email__ = "raquel.serial@tuhh.de"
__version__ = "0.2.2"
