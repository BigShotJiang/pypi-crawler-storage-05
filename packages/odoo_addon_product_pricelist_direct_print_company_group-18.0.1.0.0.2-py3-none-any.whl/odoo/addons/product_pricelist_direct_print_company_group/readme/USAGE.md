To use this feature, you have to:

1.  Go to Sales \> Products \> Print Price List
2.  On the page Customers select the partner related to the group.
3.  Press Print or Export.
