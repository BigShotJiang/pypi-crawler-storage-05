This module extends the functionality of product_pricelist_direct_print
to allow select the products sold to the grouped companies.
