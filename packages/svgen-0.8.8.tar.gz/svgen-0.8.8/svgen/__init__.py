# =====================================
# generator=datazen
# version=3.2.3
# hash=d7ef29596b2bc69d2f78eb6f58e41e51
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "A tool for working with scalable vector graphics."
PKG_NAME = "svgen"
VERSION = "0.8.8"
