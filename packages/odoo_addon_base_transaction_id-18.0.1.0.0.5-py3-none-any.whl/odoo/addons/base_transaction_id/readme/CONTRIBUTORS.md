- Yannick Vaucher \<yannick.vaucher@camptocamp.com\>

- Joël Grand-Guillaume \<joel.grandguillaume@camptocamp.com\>

- Alexandre Fayolle \<alexandre.fayolle@camptocamp.com\>

- Guewen Baconnier \<guewen.baconnier@camptocamp.com\>

- Lorenzo Battistini \<lorenzo.battistini@agilebg.com\>

- Iryna Vyshnevska \<i.vyshnevska@mobilunity.com\>

- Mykhailo Panarin \<m.panarin@mobilunity.com\>

- Simone Rubino \<simone.rubino@agilebg.com\>

- [Trobz](https://trobz.com):
  - Dzung Tran \<dungtd@trobz.com\>

- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia
