MOCK_TABLE_1_ID = "11730"
"""Identifier for mock-table-1."""
