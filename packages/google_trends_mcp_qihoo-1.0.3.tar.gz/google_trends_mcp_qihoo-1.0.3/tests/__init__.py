"""Google Trends MCP Server 测试包"""
