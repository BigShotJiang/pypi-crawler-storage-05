"""Google Trends MCP Server - 一个用于分析Google搜索趋势的MCP服务器"""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__description__ = "Google Trends MCP Server for analyzing search trends"
