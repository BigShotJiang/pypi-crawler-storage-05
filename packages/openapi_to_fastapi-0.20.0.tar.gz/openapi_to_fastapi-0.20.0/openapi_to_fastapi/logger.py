import logging

logger = logging.getLogger("openapi_to_fastapi")

logging.basicConfig()
