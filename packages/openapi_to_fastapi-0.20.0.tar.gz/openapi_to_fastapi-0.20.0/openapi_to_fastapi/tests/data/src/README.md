# README

This `src` folder contains source files from which some of the definitions have once
upon a time been generated using the
[ioxio-data-product-definition-tooling](https://github.com/ioxio-dataspace/ioxio-data-product-definition-tooling).

They might be used later as a base to update or change the definitions, but please note
that the definitions (`.json` files) might have been updated separately or the tooling
might have been updated and might not thus generate compatible definitions.
