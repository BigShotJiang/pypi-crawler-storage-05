============
ANTLeRinator
============

.. include:: ../README.rst
   :start-after: .. start included documentation
   :end-before: .. end included documentation


.. toctree::
   :caption: API Reference
   :maxdepth: 1

   antlerinator


.. toctree::
   :caption: CLI Reference
   :maxdepth: 1

   cli


.. toctree::
   :caption: Miscellaneous
   :maxdepth: 1

   relnotes
   license
