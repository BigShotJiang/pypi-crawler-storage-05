=============
CLI Reference
=============

.. describe:: antlerinator-download

.. runcmd:: python -m antlerinator --help
   :syntax: none
   :replace: "__main__.py/antlerinator-download"
