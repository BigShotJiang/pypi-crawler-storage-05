========================
Package ``antlerinator``
========================

.. automodule:: antlerinator
   :members:
   :imported-members:

.. data:: __antlr_version__
   :type: str

   Version of the antlr4 runtime package, if installed, ``None`` otherwise.
