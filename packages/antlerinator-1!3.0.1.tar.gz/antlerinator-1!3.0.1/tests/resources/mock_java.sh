#! /bin/bash
echo "$@" >mock_java_output.txt
