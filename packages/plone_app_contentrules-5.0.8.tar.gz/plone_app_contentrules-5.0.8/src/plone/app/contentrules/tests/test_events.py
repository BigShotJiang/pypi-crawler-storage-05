from plone.app.contentrules.tests.base import ContentRulesTestCase


class TestEvents(ContentRulesTestCase):
    def testEventHandlerExecutesRules(self):
        # XXX Test missing
        pass

    def testEventHandlerExecutesRulesOnlyOnce(self):
        # XXX Test missing
        pass
