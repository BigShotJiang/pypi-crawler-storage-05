Introduction
============

plone.app.contentrules provides Plone-specific conditions and actions, as well
as a user interface for plone.contentrules.

Compatibility with Plone versions
---------------------------------

The 3.x series is intended for usage with Plone 4.3 and up and features
the new content rules UI. Development of this package continues in the
``master`` branch.

For use with versions of Plone earlier than 4.3, use versions <= 2.2.1.
Development of maintenance versions can be found in the ``2.x`` branch.
