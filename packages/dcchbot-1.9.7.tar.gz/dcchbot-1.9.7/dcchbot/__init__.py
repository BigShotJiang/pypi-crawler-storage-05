#init
from .main import run
cu_ver = "1.9.7"
print(f"Discord chinese bot v.{cu_ver} ok")
print("by I_am_from_taiwan")
run()