.. _reference_guide_sec:

emicroml reference guide
========================

.. autosummary::
   :toctree: _autosummary
   :template: custom_module_template.rst
   :recursive:

   emicroml
