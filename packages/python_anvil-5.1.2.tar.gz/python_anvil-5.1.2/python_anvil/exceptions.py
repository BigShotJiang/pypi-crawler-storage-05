class AnvilException(BaseException):
    pass


class AnvilRequestException(AnvilException):
    pass
