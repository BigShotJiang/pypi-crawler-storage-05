"""Recorder module for video recording functionality."""

from .recorder import Recorder

__all__ = ["Recorder"]
