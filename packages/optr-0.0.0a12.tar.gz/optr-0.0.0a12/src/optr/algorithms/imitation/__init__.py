"""
Imitation learning algorithms
"""

from .imitation import Imitation

__all__ = ["Imitation"]
