__author__ = "Leo Cazenille"
__version__ = "0.10.7"

# MODELINE	"{{{1
# vim:expandtab:softtabstop=4:shiftwidth=4:fileencoding=utf-8
# vim:foldmethod=marker
