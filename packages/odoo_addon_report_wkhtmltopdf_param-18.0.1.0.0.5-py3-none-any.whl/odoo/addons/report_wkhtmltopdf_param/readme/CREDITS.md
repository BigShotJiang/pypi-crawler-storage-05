The migration of this module from 16.0 to 17.0 was financially supported
by Camptocamp