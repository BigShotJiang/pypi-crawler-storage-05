1.  Go to *Settings* and press 'Activate the developer mode (with
    assets)'
2.  Go to *Settings - Technical - Reports - Paper Format*
3.  Add additional parameters indicating the command argument name
    (remember to add prefix -- or -) and value.
