import json
import os
import io

from typing import Any, Dict, Union, List, Optional
from collections.abc import Sequence
from pathlib import Path
from upath import UPath

import numpy as np
from datetime import datetime
import pandas as pd
import pyarrow.parquet as pq
import pyarrow as pa
import pyarrow.ipc as ipc

from streaming.base.array import Array
from streaming.base.format import get_index_basename, reader_from_json
from streaming.base.spanner import Spanner
from streaming import Stream, StreamingDataset

import zstandard
from contextlib import contextmanager


class ZstdUtf8WriteFile:
    def __init__(self, filename, level=3):
        self.filename = filename
        self.level = level
        self.file = None

    def open(self):
        self.file = open(self.filename, "wb")
        self.compressor = zstandard.ZstdCompressor(level=self.level)
        self.writer = self.compressor.stream_writer(self.file)
        self.text_writer = io.TextIOWrapper(self.writer, encoding='utf-8')
        return self.text_writer

    def close(self):
        self.text_writer.flush()
        self.writer.flush(zstandard.FLUSH_FRAME)
        self.file.close()


@contextmanager
def zstd_utf8_read_open(filename, level=3):
    with open(filename, "rb") as f:
        decompressor = zstandard.ZstdDecompressor(max_window_size=2147483648)
        with decompressor.stream_reader(f) as stream_reader:
            yield io.TextIOWrapper(stream_reader, encoding='utf-8')


class Subset(Array):
    def __init__(self, dataset: Array, indices: Sequence[int]):
        self.dataset = dataset
        self.indices = indices

    @classmethod
    def shard(cls, dataset: Array, shard_id: int, num_shards: int):
        N = len(dataset)
        shard_indices = np.linspace(0, N, num_shards + 1)

        return cls(dataset, range(int(shard_indices[shard_id]), int(shard_indices[shard_id + 1])))

    def __len__(self) -> int:
        return len(self.indices)

    @property
    def size(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        return self.dataset[int(self.indices[int(idx)])]



def has_compressed_mds_files(path: UPath) -> bool:
    """Check if a UPath directory contains compressed MDS files (.mds.zstd or .mds.zst)."""
    if not path.is_dir():
        return False
    
    # Check if index.json exists
    index_file = path / get_index_basename()
    if not index_file.exists():
        return False
    
    # Check for compressed MDS files
    try:
        for file in path.iterdir():
            if file.suffix in ['.zstd', '.zst'] and '.mds' in file.name:
                return True
    except (OSError, AttributeError):
        # If we can't iterate (permissions, etc.), return False
        return False
    
    return False


def is_remote_path(path: UPath) -> bool:
    """Check if a UPath is a remote path (S3, GCS, etc.)."""
    return path.protocol in ('s3', 's3a', 'gs', 'gcs', 'http', 'https')



class RemoteDatasets(Array):
    def __init__(self, paths: List[Union[UPath, str]], local_cache_dir: Optional[str] = None):
        self.paths = paths
        self.local_cache_dir = local_cache_dir
        
        
        streams = [
            Stream(
                remote=str(path), 
                local=os.path.join(os.path.expanduser('~'), '.cache', 'streaming_datasets', str(hash(path))), 
                repeat=1.0,
            )
            for path in paths
        ]
        
        self.wrapped = StreamingDataset(
            streams=streams,
            shuffle=False,
        )

    def __len__(self) -> int:
        return len(self.wrapped)

    @property
    def size(self) -> int:
        return len(self.wrapped)

    def get_item(self, idx: int) -> Dict[str, Any]:
        return self.wrapped[idx]


class LocalDatasets(Array):
    def __init__(self, paths: List[Union[Path, str]]):
        self.shards = []
        for path in paths:
            filename = os.path.join(path, get_index_basename())  # pyright: ignore
            obj = json.load(open(filename))

            for info in obj['shards']:
                shard = reader_from_json(path, "", info)
                self.shards.append(shard)
        self.num_samples = sum([shard.samples for shard in self.shards])

        shard_sizes = np.array([x.samples for x in self.shards])
        self.spanner = Spanner(shard_sizes)

    def __len__(self) -> int:
        return self.num_samples

    @property
    def size(self) -> int:
        return self.num_samples

    def get_item(self, sample_id: int) -> Dict[str, Any]:
        shard_id, index_in_shard = self.spanner[sample_id]
        shard = self.shards[shard_id]
        return shard[index_in_shard]


class JsonlDataset(Array):
    def __init__(self, paths: List[Union[str, Path]]):
        self.paths = paths

        self.lines = []
        for path in paths:
            path = Path(path)
            if path.suffixes[-1] in [".zstd", ".zst"]:
                with zstd_utf8_read_open(path) as f:
                    self.lines.extend(f.readlines())
            else:
                with open(path) as f:
                    self.lines.extend(f.readlines())

    def __len__(self) -> int:
        return len(self.lines)

    @property
    def size(self) -> int:
        return len(self.lines)

    def get_item(self, idx: int) -> Dict[str, Any]:
        return json.loads(self.lines[idx])


class PyArrowDataset(Array):
    """PyArrow-based dataset that supports parquet and arrow files with local and S3 paths."""
    
    def __init__(self, paths: List[Union[UPath, str]]):
        
        self.paths = [UPath(path) for path in paths]
        self.pq = pq
        self.pa = pa
        self.ipc = ipc
        
        # Load all files and concatenate them
        self.tables = []
        for path in self.paths:
            path_str = str(path)
            
            if is_remote_path(path):
                # For remote paths (S3, GCS, etc.), use fsspec filesystem
                filesystem = path.fs
                
                # Determine file type and load accordingly
                if path_str.endswith('.parquet'):
                    table = pq.read_table(path_str, filesystem=filesystem)
                elif path_str.endswith('.arrow'):
                    # Read arrow file from remote filesystem
                    with filesystem.open(path_str, 'rb') as f:
                        reader = ipc.RecordBatchFileReader(f)
                        table = reader.read_all()
                else:
                    raise ValueError(f"Unsupported file format for path: {path_str}")
            else:
                # For local paths, read directly
                if path_str.endswith('.parquet'):
                    table = pq.read_table(path_str)
                elif path_str.endswith('.arrow'):
                    table = ipc.open_file(path_str).read_all()
                else:
                    raise ValueError(f"Unsupported file format for path: {path_str}")
                    
            self.tables.append(table)
        
        # Concatenate all tables
        if len(self.tables) > 1:
            self.table = pa.concat_tables(self.tables)
        else:
            self.table = self.tables[0]
        
        self.num_rows = self.table.num_rows

    def __len__(self) -> int:
        return self.num_rows

    @property
    def size(self) -> int:
        return self.num_rows

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        if idx >= self.num_rows:
            raise IndexError(f"Index {idx} out of range for dataset with {self.num_rows} rows")
        
        # Extract row as a dict
        row_slice = self.table.slice(idx, 1)
        row_dict = row_slice.to_pandas().iloc[0].to_dict()
        
        # Convert pandas/numpy types to Python native types
        result = {}
        for key, value in row_dict.items():
            if pd.isna(value):
                result[key] = None
            elif isinstance(value, np.number):
                result[key] = value.item()
            elif isinstance(value, np.ndarray):
                result[key] = value.tolist()
            else:
                result[key] = value
        
        return result

    def get_item(self, idx: int) -> Dict[str, Any]:
        return self.__getitem__(idx)



class NDArrayWriter:
    def __init__(self, columns, out, compression=None):
        self.columns = columns
        self.out = out

        self.buffers = {}

    def write(self, item):
        for column in self.columns:
            if column not in self.buffers:
                self.buffers[column] = []
            self.buffers[column].append(item[column])

    def finish(self):
        if self.buffers:
            parent_folder = os.path.dirname(self.out)
            if parent_folder:
                os.makedirs(parent_folder, exist_ok=True)
            for column, buffer in self.buffers.items():
                if column:
                    np.save(f"{self.out}__{column}.npy", np.array(buffer))
                else:
                    np.save(f"{self.out}.npy", np.array(buffer))




class DatetimeJsonEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return str(obj)
        if isinstance(obj, np.number):
            return obj.item()
        if isinstance(obj, np.ndarray):
            return obj.tolist()

        return super().default(obj)


class JsonlWriter:
    def __init__(self, columns, out, compression=None):
        self.columns = set(columns)
        self.out = out
        
        parent_folder = os.path.dirname(self.out)
        if parent_folder:
            os.makedirs(parent_folder, exist_ok=True)
        if compression is not None and compression.startswith("zst"):
            ext = compression.split(":")[0]
            level = int(compression.split(":")[1]) if ":" in compression else 3
            self.file_handle = ZstdUtf8WriteFile(f"{out}.jsonl.{ext}", level)
            self.file = self.file_handle.open()
        else:
            self.file_handle = open(f"{out}.jsonl", "w")
            self.file = self.file_handle

    def write(self, item):
        if not self.columns.issubset(item.keys()):
            print(f"Warning: Item {item} does not contain all columns: {self.columns - item.keys()}")
        self.file.write(json.dumps(item, cls=DatetimeJsonEncoder) + "\n")

    def finish(self):
        self.file_handle.close()
