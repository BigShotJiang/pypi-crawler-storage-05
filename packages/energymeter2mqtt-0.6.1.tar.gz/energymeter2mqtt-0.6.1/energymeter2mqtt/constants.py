from pathlib import Path

import energymeter2mqtt


CLI_EPILOG = 'Project Homepage: https://github.com/jedie/energymeter2mqtt'

SETTINGS_DIR_NAME = 'energymeter2mqtt'
SETTINGS_FILE_NAME = 'energymeter2mqtt'

BASE_PATH = Path(energymeter2mqtt.__file__).parent
