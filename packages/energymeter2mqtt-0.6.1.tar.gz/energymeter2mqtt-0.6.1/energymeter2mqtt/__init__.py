"""
    energymeter2mqtt
    Get values from modbus energy meter to MQTT / HomeAssistant
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.6.1'
__author__ = 'Jens Diemer <git@jensdiemer.de>'
