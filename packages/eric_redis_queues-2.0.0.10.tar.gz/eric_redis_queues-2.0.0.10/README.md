Redis support for eric-sse

*Installation*

pip install eric-redis-queues

*Related packages*

* https://pypi.org/project/eric-sse/ Base project

Documentation: https://laxertu.github.io/eric-redis-queues/
