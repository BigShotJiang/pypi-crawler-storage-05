"""HTML rendering for the report (template + cards)."""

