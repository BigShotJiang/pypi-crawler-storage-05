"""
About the package.
"""

__version__ = "0.6.5"  # no cov
