---
name: Language request
about: Request adding a new language
title: 'Add language'
labels: "enhancement, redcap"
assignees: gongcastro
type: feature
---

