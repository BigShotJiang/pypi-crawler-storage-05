Use this Command to build:

python setup.py sdist bdist_wheel # To build
pip install .\dist\matplotib-0.4-py3-none-any.whl # To install locally(version vary according to build)
