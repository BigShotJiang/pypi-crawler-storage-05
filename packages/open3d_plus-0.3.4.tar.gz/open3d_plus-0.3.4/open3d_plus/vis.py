import open3d as o3d
import numpy as np

import matplotlib.cm as cm

try:
    import torch

    if torch.cuda.is_available():
        USE_TORCH_CUDA = True
    else:
        print("[Open3dPlus]: torch cuda not available")
        USE_TORCH_CUDA = False
except:
    print("[Open3dPlus]: torch cuda not available")
    USE_TORCH_CUDA = False


def paint_pcd_by_axis(pcd: o3d.geometry.PointCloud, axis: int, var: float = 2):
    points = np.asarray(pcd.points)
    vals = points[:, axis]
    mean_val = np.mean(vals)
    var_val = np.sqrt(np.var(vals))
    min_val = mean_val - var * var_val
    max_val = mean_val + var * var_val
    norm_range = (vals - min_val) / (max_val - min_val)
    clip_norm_range = np.clip(norm_range, 0, 1)
    colors = cm.jet(clip_norm_range)[:, :3]
    pcd.colors = o3d.utility.Vector3dVector(colors)
    return pcd


def render_o3d_pointcloud(
    pcd: o3d.geometry.PointCloud,
    pinhole_camera_param: o3d.camera.PinholeCameraParameters,
    point_radius: int = 1,
    use_gpu: bool = False,
) -> np.ndarray:
    """render point cloud with numpy or torch

    Args:
        pcd (Union[np.ndarray, torch.Tensor, o3d.geometry]): point cloud in either np/torch/open3d format
        pinhole_camera_param (o3d.camera.PinholeCameraParameters): camera params
        point_radius(int, optional): render point size. Defaults to 1
        use_gpu (bool, optional): if use gpu. Defaults to False.

    Returns:
        np.ndarray: image in uint8 (H, W, C), BGR format
    """
    np_points = np.asarray(pcd.points)
    np_colors = np.asarray(pcd.colors)
    if use_gpu and USE_TORCH_CUDA:
        torch_points = torch.from_numpy(np_points).cuda()
        torch_colors = torch.from_numpy(np_colors).cuda()
        return render_pointcloud_torch(
            torch_points, torch_colors, pinhole_camera_param=pinhole_camera_param, point_radius=point_radius
        )
    else:
        return render_pointcloud_numpy(
            np_points, np_colors, pinhole_camera_param=pinhole_camera_param, point_radius=point_radius
        )


def project_to_2d_torch(fx, fy, cx, cy, points_3d):
    Z = points_3d[:, 2]
    x_normalized = points_3d[:, 0] / Z
    y_normalized = points_3d[:, 1] / Z
    u = (fx * x_normalized + cx).to(torch.int64)
    v = (fy * y_normalized + cy).to(torch.int64)
    return torch.column_stack((u, v))


def render_pointcloud_torch(
    points: torch.Tensor,
    colors: torch.Tensor,
    pinhole_camera_param: o3d.camera.PinholeCameraParameters,
    point_radius: int = 1,
) -> np.ndarray:
    """render point cloud with torch

    Args:
        points (torch.Tensor): points coords
        colors (torch.Tensor): colors of the points, [0 - 1], RGB
        pinhole_camera_param (o3d.camera.PinholeCameraParameters): _description_
        point_radius (int): point rendering radius

    Returns:
        np.ndarray: image in uint8 (H, W, C), BGR format
    """
    intrin = pinhole_camera_param.intrinsic
    vis = 255 * torch.ones((intrin.height, intrin.width, 3), dtype=torch.uint8).cuda()
    bgr_colors = (colors * 255).to(torch.uint8)[:, [2, 1, 0]]
    num_pts = points.shape[0]
    # transform points to camera frame
    camera_points = torch.matmul(
        torch.tensor(pinhole_camera_param.extrinsic).cuda(),
        torch.hstack((points, torch.ones((num_pts, 1), dtype=points.dtype).cuda())).T,
    ).T[:, :3]
    valid_mask = camera_points[:, 2] > 0
    valid_pts = camera_points[valid_mask]
    valid_colors = bgr_colors[valid_mask]
    dist_down_idxs = torch.flip(torch.argsort(torch.linalg.norm(valid_pts, axis=1)), [0])
    sorted_pts = valid_pts[dist_down_idxs]  # from longest to shortest
    sorted_colors = valid_colors[dist_down_idxs]
    fx, fy = intrin.get_focal_length()
    cx, cy = intrin.get_principal_point()
    uvs = project_to_2d_torch(fx, fy, cx, cy, sorted_pts)  # [n, 2]
    offsets = torch.arange(-point_radius, point_radius + 1)
    grid_size = 2 * point_radius + 1
    all_colors = torch.einsum("ij,k->ikj", sorted_colors, torch.ones(grid_size**2, dtype=torch.uint8).cuda()).reshape(
        -1, 3
    )
    meshgrids = torch.from_numpy(np.array(np.meshgrid(offsets, offsets)).T.reshape((-1, 2))).cuda()
    all_uvs = (
        torch.einsum("ij,k->ikj", uvs, torch.ones(grid_size**2, dtype=torch.int64).cuda()) + meshgrids
    ).reshape((-1, 2))
    valid_masd = (
        (all_uvs[:, 0] >= 0) & (all_uvs[:, 0] < intrin.width) & (all_uvs[:, 1] >= 0) & (all_uvs[:, 1] < intrin.height)
    )
    all_uvs = all_uvs[valid_masd]
    all_colors = all_colors[valid_masd]
    vis[all_uvs[:, 1], all_uvs[:, 0]] = all_colors
    return vis.cpu().numpy()


def project_to_2d_numpy(fx, fy, cx, cy, points_3d):
    Z = points_3d[:, 2]
    x_normalized = points_3d[:, 0] / Z
    y_normalized = points_3d[:, 1] / Z
    u = (fx * x_normalized + cx).astype(np.int64)
    v = (fy * y_normalized + cy).astype(np.int64)
    return np.column_stack((u, v))


def render_pointcloud_numpy(
    points: np.ndarray,
    colors: np.ndarray,
    pinhole_camera_param: o3d.camera.PinholeCameraParameters,
    point_radius: int = 1,
) -> np.ndarray:
    """render point cloud with numpy

    Args:
        points (np.ndarray): points coords
        colors (np.ndarray): colors of the points, [0 - 1], RGB
        pinhole_camera_param (o3d.camera.PinholeCameraParameters): _description_
        point_radius (int): point rendering radius

    Returns:
        np.ndarray: image in uint8 (H, W, C), BGR format
    """
    intrin = pinhole_camera_param.intrinsic
    vis = 255 * np.ones((intrin.height, intrin.width, 3), dtype=np.uint8)
    bgr_colors = (colors * 255).astype(np.uint8)[:, [2, 1, 0]]
    num_pts = points.shape[0]
    # transform points to camera frame
    camera_points = np.matmul(
        pinhole_camera_param.extrinsic, np.hstack((points, np.ones((num_pts, 1), dtype=points.dtype))).T
    ).T[:, :3]
    valid_mask = camera_points[:, 2] > 0
    valid_pts = camera_points[valid_mask]
    valid_colors = bgr_colors[valid_mask]
    dist_down_idxs = np.argsort(np.linalg.norm(valid_pts, axis=1))[::-1]
    sorted_pts = valid_pts[dist_down_idxs]  # from longest to shortest
    sorted_colors = valid_colors[dist_down_idxs]
    fx, fy = intrin.get_focal_length()
    cx, cy = intrin.get_principal_point()
    uvs = project_to_2d_numpy(fx, fy, cx, cy, sorted_pts)  # [n, 2]
    offsets = np.arange(-point_radius, point_radius + 1)
    grid_size = 2 * point_radius + 1
    all_colors = np.einsum("ij,k->ikj", sorted_colors, np.ones(grid_size**2, dtype=int)).reshape(-1, 3)
    all_uvs = (
        np.einsum("ij,k->ikj", uvs, np.ones(grid_size**2, dtype=int))
        + np.array(np.meshgrid(offsets, offsets)).T.reshape(-1, 2)
    ).reshape((-1, 2))
    valid_masd = (
        (all_uvs[:, 0] >= 0) & (all_uvs[:, 0] < intrin.width) & (all_uvs[:, 1] >= 0) & (all_uvs[:, 1] < intrin.height)
    )
    all_uvs = all_uvs[valid_masd]
    all_colors = all_colors[valid_masd]
    vis[all_uvs[:, 1], all_uvs[:, 0]] = all_colors
    return vis


def generate_views(axis: str, num_views: int, view_radius: float, view_height: float) -> np.ndarray:
    """generate camera extrinsic matrices

    Args:
        axis (str): surround direction
        num_views (int): number of views to generate
        view_radius (float): radius of the circle
        view_height (float): height of the circle

    Returns:
        np.ndarray: [n, 4, 4] of the extrinsics
    """
    Ts = np.zeros((num_views, 4, 4), dtype=np.float64)  # (n, 4, 4)
    Ts[:, 3, 3] = 1
    rot_angles = 2 * np.pi / num_views * (np.arange(num_views, dtype=np.float64) - 0.5)  # avoid sin(theta) == 0
    if axis in ["z+", "z-"]:
        if axis == "z+":
            trans_z = view_height * np.ones(num_views)
        else:
            trans_z = -view_height * np.ones(num_views)
        Ts[:, :3, 3] = np.vstack(
            (
                view_radius * np.cos(rot_angles),
                view_radius * np.sin(rot_angles),
                trans_z,
            )
        ).T  # (n, 3)
        proj = np.vstack(
            (
                np.cos(rot_angles),
                np.sin(rot_angles),
                np.zeros(num_views),
            )
        ).T  # (n, 3)
    elif axis in ["x+", "x-"]:
        if axis == "x+":
            trans_x = view_height * np.ones(num_views)
        else:
            trans_x = -view_height * np.ones(num_views)
        Ts[:, :3, 3] = np.vstack(
            (
                trans_x,
                view_radius * np.cos(rot_angles),
                view_radius * np.sin(rot_angles),
            )
        ).T  # (n, 3)
        proj = np.vstack(
            (
                np.zeros(num_views),
                np.cos(rot_angles),
                np.sin(rot_angles),
            )
        ).T  # (n, 3)
    elif axis in ["y+", "y-"]:
        if axis == "y+":
            trans_y = view_height * np.ones(num_views)
        else:
            trans_y = -view_height * np.ones(num_views)
        Ts[:, :3, 3] = np.vstack(
            (
                view_radius * np.cos(rot_angles),
                trans_y,
                view_radius * np.sin(rot_angles),
            )
        ).T  # (n, 3)
        proj = np.vstack(
            (
                np.cos(rot_angles),
                np.zeros(num_views),
                np.sin(rot_angles),
            )
        ).T  # (n, 3)
    Ts[:, :3, 2] = -Ts[:, :3, 3]  # rot_z (n, 3)
    Ts[:, :3, 2] = Ts[:, :3, 2] / np.sqrt(view_height**2 + view_radius**2)
    Ts[:, :3, 0] = np.cross(proj, Ts[:, :3, 2])
    Ts[:, :3, 0] = Ts[:, :3, 0] / np.tile(np.linalg.norm(Ts[:, :3, 0], axis=1), (3, 1)).T
    Ts[:, :3, 1] = np.cross(Ts[:, :3, 2], Ts[:, :3, 0])
    return Ts


def render_pcd_around_axis(
    pcd: o3d.geometry.PointCloud,
    intrinsic: o3d.camera.PinholeCameraIntrinsic,
    axis: str,
    var: float = 2,
    num_views: int = 120,
    view_angle: float = 30,
    use_gpu: bool = True,
    point_radius: int = 1,
):
    assert axis in ["x+", "x-", "y+", "y-", "z+", "z-"]
    points = np.asarray(pcd.points)
    view_angle_rad = view_angle / 180.0 * np.pi
    if axis in ["z-", "z+"]:
        dists = np.linalg.norm(points[:, [0, 1]], axis=1)
    elif axis in ["x-", "x+"]:
        dists = np.linalg.norm(points[:, [1, 2]], axis=1)
    elif axis in ["y-", "y+"]:
        dists = np.linalg.norm(points[:, [0, 2]], axis=1)
    mean_dist = np.mean(dists)
    stdvar_dist = np.sqrt(np.var(dists))
    view_radius = mean_dist + stdvar_dist * var
    view_height = view_radius * np.tan(view_angle_rad)
    Ts = generate_views(axis, num_views=num_views, view_radius=view_radius, view_height=view_height)
    pinhole_camera_param = o3d.camera.PinholeCameraParameters()
    pinhole_camera_param.intrinsic = intrinsic
    vis_list = []
    for i in range(len(Ts)):
        pinhole_camera_param.extrinsic = np.linalg.inv(Ts[i])
        vis = render_o3d_pointcloud(
            pcd, pinhole_camera_param=pinhole_camera_param, point_radius=point_radius, use_gpu=use_gpu
        )
        vis_list.append(vis)
    return vis_list
