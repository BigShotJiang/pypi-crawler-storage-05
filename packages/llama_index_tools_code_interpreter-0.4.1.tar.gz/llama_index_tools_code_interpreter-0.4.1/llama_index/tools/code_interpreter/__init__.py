"""init.py."""

from llama_index.tools.code_interpreter.base import (
    CodeInterpreterToolSpec,
)

__all__ = ["CodeInterpreterToolSpec"]
