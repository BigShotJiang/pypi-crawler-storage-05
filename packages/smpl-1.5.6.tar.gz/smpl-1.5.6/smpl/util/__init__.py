"""A collection of simplified utilities."""

from .util import *
