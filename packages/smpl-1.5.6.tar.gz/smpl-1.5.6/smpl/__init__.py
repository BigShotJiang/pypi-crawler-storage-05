"""A collection of simplified utilities."""

from ._version import version as __version__

package = "smpl"

__all__ = ["__version__", "package"]
