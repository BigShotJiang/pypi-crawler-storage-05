"""
A library that records transactions against a ledger, denominated in units of value.
"""
__version__ = "1.6.9"
