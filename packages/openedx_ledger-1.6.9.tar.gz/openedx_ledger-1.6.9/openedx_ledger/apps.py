"""
openedx_ledger Django application initialization.
"""
from django.apps import AppConfig


class EdxLedgerConfig(AppConfig):
    name = 'openedx_ledger'
