# `c_struct`

Python package to translate C struct to classes

