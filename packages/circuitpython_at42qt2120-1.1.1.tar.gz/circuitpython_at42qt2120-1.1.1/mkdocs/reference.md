# Reference

::: at42qt2120.AT42QT2120

----

::: at42qt2120.AT42QT2120Channel

----

::: at42qt2120
    options:
      heading: "Helper functions"
      toc_label: "Helper functions"
      members:
      - two_byte_int
      - bit_on
      - tuple_of_bits

----

::: at42qt2120
    options:
      heading: "Constants"
      toc_label: "Constants"
      members:
      - AT42QT2120_I2CADDR_DEFAULT
      - AT42QT2120_KEY_STATUS
      - AT42QT2120_RESET
      - AT42QT2120_DETECT_THRESHOLD_0
      - AT42QT2120_KEY_SIGNAL_0
