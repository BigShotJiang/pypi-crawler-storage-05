Example:

1) 
```python
from secret_generator import generate_secret

print(generate_secret(40))
```
2) 
```python
from secret_generator import run

run()
```
