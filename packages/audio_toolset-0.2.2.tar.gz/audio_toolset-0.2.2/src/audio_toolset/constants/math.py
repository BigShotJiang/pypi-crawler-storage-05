from numpy import pi

LOG_FLOOR = 1e-12

MS_TO_S = 1 / 1000
S_TO_MS = 1000

PI = pi
