.. _swh-lister:

.. include:: README.rst


Overview
--------

.. toctree::
   :maxdepth: 2
   :titlesonly:

   tutorial
   run_a_new_lister
   save_forge


Reference Documentation
-----------------------

.. toctree::
   :maxdepth: 2

   cli

.. only:: standalone_package_doc

   Indices and tables
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
