.. _swh-lister-cli:

Command-line interface
======================

.. click:: swh.lister.cli:lister
  :prog: swh lister
  :nested: full
