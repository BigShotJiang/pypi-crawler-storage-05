# heimdall-common

This crate is a collection of common utilities used by the Heimdall library. It is not intended to be used directly, but rather as a dependency of other Heimdall crates.
