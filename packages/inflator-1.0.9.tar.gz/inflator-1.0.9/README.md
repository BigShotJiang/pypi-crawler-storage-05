# inflator

> Inflate gobos.

###### Inflator is a package manager for goboscript

### [documentation](https://inflated-goboscript.github.io/inflator/)
### [pypi](https://pypi.org/project/inflator/)

## credits

banner image is partially from https://scratch.mit.edu/projects/317901726/remixtree/
goboscript is by aspizu
