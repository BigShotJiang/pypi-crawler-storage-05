# Test compliance with scikit-learn
# def test_compliance_gaussian_broadening():
#    # Arrange
#    transformer = GaussianBroadening()
#    # Act & Assert
#    check_estimator(transformer)
