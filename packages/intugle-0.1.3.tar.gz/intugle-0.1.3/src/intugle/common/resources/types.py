from enum import StrEnum


class NodeType(StrEnum):
    MODEL = "model"
    RELATIONSHIP = "relationship"
