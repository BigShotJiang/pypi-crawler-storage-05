item_tints =
{
  iron_rust = { 1.0, 0.95, 0.9, 1.0 },
  plastic = { 0.92, 0.92, 0.97, 1.0 },
  bluish_concrete = { 0.92, 0.92, 0.97, 1.0 },
  bluish_science = { 0.92, 0.97, 0.97, 1.0 },
  organic_green = { 0.92, 0.97, 0.92, 1.0 },
  yellowing_coal = { 0.85, 0.85, 0.70, 1.0 }, --strong tint for very dark black items
  ice_blue = { 0.9, 1.0, 1.0, 1.0 }
}
return item_tints
