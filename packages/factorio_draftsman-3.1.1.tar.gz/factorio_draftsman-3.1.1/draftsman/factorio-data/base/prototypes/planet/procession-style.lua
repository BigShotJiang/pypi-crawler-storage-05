local procession_style = {}
procession_style.default = 0
procession_style.pod_left = 1
procession_style.pod_right = 2
procession_style.rocket_left = 3
procession_style.rocket_right = 4
procession_style.platform_to_debug = 42
procession_style.pod_left_generic = 10
procession_style.pod_right_generic = 11
return procession_style
