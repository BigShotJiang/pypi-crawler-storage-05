data:extend(
{
  {
    type = "impact-category",
    name = "default"
  },
  {
    type = "impact-category",
    name = "wood"
  },
  {
    type = "impact-category",
    name = "tree"
  },
  {
    type = "impact-category",
    name = "metal"
  },
  {
    type = "impact-category",
    name = "metal-large"
  },
  {
    type = "impact-category",
    name = "organic"
  },
  {
    type = "impact-category",
    name = "glass"
  },
  {
    type = "impact-category",
    name = "stone"
  },
  {
    type = "deliver-category",
    name = "bullet"
  },
  {
    type = "deliver-category",
    name = "vehicle"
  }
})
