data:extend(
{
  {
    type = "remote-controller",
    name = "default",
    movement_speed = 1
  }
})
