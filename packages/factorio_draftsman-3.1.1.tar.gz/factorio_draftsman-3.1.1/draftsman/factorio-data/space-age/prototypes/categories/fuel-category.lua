data:extend(
{
  {
    type = "fuel-category",
    name = "food",
    fuel_value_type = {"description.food-energy-value"},
  },
  {
    type = "fuel-category",
    name = "nutrients",
    fuel_value_type = {"description.nutrients-energy-value"},
  },
  {
    type = "fuel-category",
    name = "fusion"
  }
}
)
