# API Interface Definitions

This repository contains interfaces that users of Statsig may want to use when writing custom solutions for working with our architectural solutions.
