# beautybook/__init__.py
from .core import BeautyBook
