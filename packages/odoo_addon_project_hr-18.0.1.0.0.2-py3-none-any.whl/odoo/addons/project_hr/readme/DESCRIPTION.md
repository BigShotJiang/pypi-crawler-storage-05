This is a technical module for adding some HR information to projects
and provide technical fields with HR information:

- Employee categories at project and task level.
- Employee linked to the user assigned to a task.
- Employee categories at user level.

These fields can be used later for extra features like task scheduling
or security restrictions.

It also provides some facilities on project management:

- Limit selection of assigned users according selected employee category
  at task level.
- Limit selection of employee categories at task level depending on the
  selected categories at project level. All are shown if no categories
  at project level.
