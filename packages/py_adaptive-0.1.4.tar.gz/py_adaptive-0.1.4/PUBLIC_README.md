## Py Adaptive

Py-adaptive is a Python package aimed to ease the integration and use of python
scripts with Adaptive. Adaptive is WebGIS solution developed and soled by
Avinet.

### Installation

Install via PyPI:

`$ pip install py-adaptive`
