from philologic.loadtime.Parser import XMLParser
