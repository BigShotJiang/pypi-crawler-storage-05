Contributors
============

* Rémy Hubscher <rhubscher@mozilla.com>
* Mathieu Leplatre <mathieu@mozilla.com>
* Gabriela Surita <gabsurita@gmail.com>
