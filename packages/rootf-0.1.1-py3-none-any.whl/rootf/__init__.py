__version__ = "0.1.1"

from .system_info import get_distro, get_ascii_art, get_system_info
