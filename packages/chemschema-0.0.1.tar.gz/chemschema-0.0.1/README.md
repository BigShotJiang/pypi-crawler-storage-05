# ChemSchema

[WIP]