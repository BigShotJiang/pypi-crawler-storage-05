import time

def task_end(task):
    task.end_time = time.time()