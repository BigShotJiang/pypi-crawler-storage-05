def task_response(model_response, task):
    task._response = model_response.output