from typing import List
from pydantic import BaseModel


class ObjectResponse(BaseModel):
    pass






