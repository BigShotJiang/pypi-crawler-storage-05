"""CLI package for Parameter Server."""

from .param_cli import main

__all__ = ["main"]
