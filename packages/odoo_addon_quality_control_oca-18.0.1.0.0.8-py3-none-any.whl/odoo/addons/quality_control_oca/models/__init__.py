# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import qc_trigger
from . import qc_trigger_line
from . import qc_test_category
from . import qc_test
from . import qc_inspection
from . import product_product
from . import product_template
from . import product_category
from . import qc_trigger_product_category_line
from . import qc_trigger_product_line
from . import qc_trigger_product_template_line
