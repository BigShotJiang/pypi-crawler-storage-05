This module provides a generic infrastructure for quality tests. The
idea is that it can be later reused for doing quality inspections on
production lots or any other area of the company.
