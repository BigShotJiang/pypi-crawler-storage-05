.. scri documentation master file, created by
   sphinx-quickstart on Sun Jun 14 12:29:47 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to scri's documentation!
================================

For a quick start, take a look at the `quick start section <README.html#quick-start>`_ of the README.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   README.md
   tutorial_abd
   tutorial_waveformmodes
   tutorial_bms
   tutorial_extrapolation
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
