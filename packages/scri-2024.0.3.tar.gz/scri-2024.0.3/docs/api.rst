***********
Package API
***********

.. autosummary::
   :toctree: _autosummary
   :recursive:

   scri
