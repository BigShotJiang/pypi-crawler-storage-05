from .base import NotionContentSchema

__all__ = ["NotionContentSchema"]
