from ._bootstrap import bootstrap_blocks

__all__ = [
    "bootstrap_blocks",
]
