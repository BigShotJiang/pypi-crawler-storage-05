Python technicalities
=====================

SageMath has various modules to provide access to low-level Python
internals.

.. toctree::
   :maxdepth: 1

   sage/cpython/atexit
   sage/cpython/string
   sage/cpython/debug
   sage/cpython/getattr
   sage/cpython/cython_metaclass
   sage/cpython/dict_del_by_value

.. include:: ../footer.txt
