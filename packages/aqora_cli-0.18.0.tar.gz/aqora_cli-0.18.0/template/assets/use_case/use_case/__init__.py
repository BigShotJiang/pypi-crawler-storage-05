from .use_case import Input, Output

__all__ = ["Input", "Output"]
