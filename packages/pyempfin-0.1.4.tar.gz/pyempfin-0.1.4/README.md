# pyempfin
Version: 0.1.4

Helper functions for empirical finance research using Python.
