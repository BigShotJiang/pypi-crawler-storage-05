=======
Credits
=======

The co-embedding in this tool is derived from `MUSE <https://github.com/AltschulerWu-Lab/MUSE>`__

Developers
----------------

* Leah Schaffer <lvschaffer@health.ucsd.edu>

* Christopher Churas <cchuras@ucsd.edu>

Contributors
------------

None yet. Why not be the first?

