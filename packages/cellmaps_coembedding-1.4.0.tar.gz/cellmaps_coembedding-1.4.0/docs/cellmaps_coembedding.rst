cellmaps\_coembedding package
=============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   cellmaps_coembedding.muse_sc

.. toctree::
   :maxdepth: 4

   cellmaps_coembedding.protein_gps

Submodules
----------

cellmaps\_coembedding.cellmaps\_coembeddingcmd module
-----------------------------------------------------

.. automodule:: cellmaps_coembedding.cellmaps_coembeddingcmd
   :members:
   :undoc-members:
   :show-inheritance:

cellmaps\_coembedding.exceptions module
---------------------------------------

.. automodule:: cellmaps_coembedding.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

cellmaps\_coembedding.runner module
-----------------------------------

.. automodule:: cellmaps_coembedding.runner
   :members:
   :undoc-members:
   :show-inheritance:

cellmaps\_coembedding.utils module
-----------------------------------

.. automodule:: cellmaps_coembedding.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: cellmaps_coembedding
   :members:
   :undoc-members:
   :show-inheritance:
