cellmaps\_coembedding.protein\_gps package
==========================================

Submodules
----------

cellmaps\_coembedding.protein\_gps.architecture module
------------------------------------------------------

.. automodule:: cellmaps_coembedding.protein_gps.architecture
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: cellmaps_coembedding.protein_gps
   :members:
   :undoc-members:
   :show-inheritance:
