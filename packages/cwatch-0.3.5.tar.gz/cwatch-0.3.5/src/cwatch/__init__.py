"""Call main."""

from .cw import main

if __name__ == "__main__":
    main()  # pragma: no cover
