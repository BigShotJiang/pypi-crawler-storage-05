"""
Configuration for Sphinx.
"""

extensions = [
    "sphinxcontrib.video",
    "sphinx_notion",
    "sphinx_toolbox.collapse",
]
