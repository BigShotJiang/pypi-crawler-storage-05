from setuptools import setup, find_packages

setup(
    name="VeryEasyAI",
    version="0.6.0",
    description="Uma biblioteca de IA super simples e fácil de usar",
    author="Enzo DEV",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
)
