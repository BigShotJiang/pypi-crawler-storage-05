# API Reference

::: ambr.exceptions
    options:
      show_source: false
