#!/usr/bin/env python

"""Tests for `modvis` package."""


import unittest

from modvis import modvis


class TestModvis(unittest.TestCase):
    """Tests for `modvis` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
