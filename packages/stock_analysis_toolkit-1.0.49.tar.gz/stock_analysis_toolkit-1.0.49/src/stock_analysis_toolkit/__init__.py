"""Stock Analysis Toolkit.

A comprehensive toolkit for stock market analysis and reporting.
"""

__version__ = "1.0.49"

# This file makes the src directory a Python package
