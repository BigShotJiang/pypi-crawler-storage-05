from .middleware import WafaHell

# agora a classe está disponível diretamente ao importar o pacote
