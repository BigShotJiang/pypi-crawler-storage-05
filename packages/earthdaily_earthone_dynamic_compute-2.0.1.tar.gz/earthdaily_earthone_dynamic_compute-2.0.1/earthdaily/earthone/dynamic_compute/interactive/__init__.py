from .map_ import MapApp

map = MapApp()
