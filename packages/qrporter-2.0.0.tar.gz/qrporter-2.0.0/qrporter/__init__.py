# qrporter/__init__.py
"""
QRPorter package init
"""
