__all__ = [
    'tabulate',
]


__version__ = '0.3.0'

from .api import tabulate
