var modulesResourcesUrl = "{% url 'core_parser_app_modules_resources' %}";
