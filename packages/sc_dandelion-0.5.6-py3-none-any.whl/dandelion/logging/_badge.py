from dandelion import __version__

print(__version__)
