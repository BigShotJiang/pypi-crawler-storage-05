## External modules

`nxviz` imported from https://github.com/zktuong/nxviz/tree/custom_color_mapping_circos_nodes_and_edges. Will remove it from here if the [PR](https://github.com/ericmjl/nxviz/pull/689) ever gets merged.
