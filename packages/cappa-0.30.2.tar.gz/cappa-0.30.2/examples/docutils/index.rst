.. cappa:: example.Foo
   :style: terminal
   :terminal-width: 0
