"""
Plugin for adding translation behavior to XBlocks.
"""

__version__ = "1.6.2"
