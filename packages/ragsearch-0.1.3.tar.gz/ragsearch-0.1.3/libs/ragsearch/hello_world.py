"""
This module contains a simple function to print 'Hello, world' to the console.
"""

def hello_world():
    """
        Prints 'Hello, world' to the console.
    """
    return "Hello, world"
