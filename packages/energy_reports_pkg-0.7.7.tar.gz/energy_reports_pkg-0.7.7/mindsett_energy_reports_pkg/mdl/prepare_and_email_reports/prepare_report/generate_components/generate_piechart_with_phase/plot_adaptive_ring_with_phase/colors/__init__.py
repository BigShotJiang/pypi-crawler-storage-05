

colors = ['#6DC2B3', 
          '#FF836A', 
          '#FED6D2', 
          '#9F9D9C', 
          '#B6E4E1', 
          '#FEF8C8', 
          '#CFCDCD', 
          '#9DE7BE', 
          '#f7baad', 
          '#b3fff2', 
          '#F7D8BA']

# backup/archive copy

cd = {"aquablue": '#6DC2B3',
      "tomato": '#FF836A',
      "peach": '#FED6D2',
      "darkgrey": '#9F9D9C',
      "cyan": '#B6E4E1',
      "potato": '#FEF8C8',
      "dimgray":'#696969',
      "Seafoam":'#87e0cf',
      "gainsboro":'#DCDCDC',
      "grey": '#808080',
      "brown": '#964B00',
      "black": '#000000'}