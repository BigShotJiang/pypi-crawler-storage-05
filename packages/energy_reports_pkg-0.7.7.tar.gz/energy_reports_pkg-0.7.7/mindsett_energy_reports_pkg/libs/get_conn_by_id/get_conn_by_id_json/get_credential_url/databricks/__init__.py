

# import os

# from pathlib import Path
# cache_directory = os.path.join(os.path.dirname(__file__), '_cache_/')

credential_urls = ['/dbfs/FileStore/shared_uploads/x.yang@cloudfmgroup.com/credentials/credentials.json']

# print('credential_url: ', credential_url)
