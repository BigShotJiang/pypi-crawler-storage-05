

import os

# from pathlib import Path
# cache_directory = os.path.join(os.path.dirname(__file__), '_cache_/')

# credential_url = os.path.join(os.path.dirname(__file__), 'credentials.json')

credential_urls = ['/Volumes/EXT SSD/Cloudfm Backup/Documents at Cloudfm/Accounts/credentials/credentials.json',
                   '/Volumes/macOS 1/Users/Shared/Cloudfm Backup/OneDrive - Cloudfm Integrated Services Ltd - Backup/KTP Project/Cloudfm/Accounts/credentials/credentials.json']

# '/dbfs/FileStore/shared_uploads/x.yang@cloudfmgroup.com/credentials_/credentials.json'