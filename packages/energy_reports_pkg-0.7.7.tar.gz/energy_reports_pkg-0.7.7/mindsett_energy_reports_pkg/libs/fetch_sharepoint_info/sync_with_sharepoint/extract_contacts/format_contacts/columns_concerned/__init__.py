

columns_concerned = ['last_update', 'building_id', 'item_name', 'group_name', 'board_id',
                                'hvac_board_id', 'publish', 'testing', 'industry', 'manager_name',
                                'currency', 'occupancy_available', 'asset_group', 'fillna_value',
                                'insight_statements', 'group_name_column_exchange',
                                'group_name_modification', 'pct_level_tobe_others', 'floor_sqm', 'pct_hide',
                                'conv_mwh_price', 'period_freq', 'mailing_list']