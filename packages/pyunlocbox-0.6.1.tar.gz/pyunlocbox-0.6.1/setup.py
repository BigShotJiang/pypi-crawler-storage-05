#!/usr/bin/env python

from setuptools import setup

# Modern Python packaging is primarily handled by pyproject.toml
# This setup.py is maintained for backwards compatibility

setup()
