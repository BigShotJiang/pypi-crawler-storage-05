=============
API reference
=============

.. automodule:: pyunlocbox

.. toctree::
    :hidden:

    functions
    solvers
    acceleration
    operators
