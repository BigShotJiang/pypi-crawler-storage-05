.. include:: ../README.rst

.. toctree::
   :hidden:

   Home <self>
   tutorials/index
   reference/index
   changelog
   contributing
   references
