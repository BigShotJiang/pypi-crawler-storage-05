"""
Needed to allow setuptools to build the project form pyproject.toml
For more info https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html
"""
from setuptools import setup

setup()
