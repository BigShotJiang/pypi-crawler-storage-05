class OuterReturn(Exception):
	pass
