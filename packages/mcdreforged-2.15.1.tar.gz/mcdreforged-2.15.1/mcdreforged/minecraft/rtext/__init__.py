"""
Advanced text component library for Minecraft

Credit: `Pandaria98 <https://github.com/Pandaria98>`__ 's `stext API <https://github.com/TISUnion/stext>`__ library
"""
