from __future__ import annotations
from srcmlcpp.cpp_types.scope.cpp_scope import CppScope

__all__ = ["CppScope"]
