"""
Basic code manipulation utilities, based on string processing.

Used by litgen and srcmlcpp
"""
from __future__ import annotations
