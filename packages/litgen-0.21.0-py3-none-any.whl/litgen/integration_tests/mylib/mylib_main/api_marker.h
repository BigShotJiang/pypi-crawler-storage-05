#pragma once

#ifndef MY_API
#define MY_API  // MY_API could typically be __declspec(dllexport | dllimport)
#endif
