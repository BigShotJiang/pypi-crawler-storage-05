from __future__ import annotations
from litgen.internal.adapt_function_params.apply_all_adapters import apply_all_adapters

__all__ = ["apply_all_adapters"]
