
from unicon.plugins.iosxe.cat9k.statemachine import IosXECat9kSingleRpStateMachine


class IosXEc9800SingleRpStateMachine(IosXECat9kSingleRpStateMachine):

    def create(self):
        super().create()
