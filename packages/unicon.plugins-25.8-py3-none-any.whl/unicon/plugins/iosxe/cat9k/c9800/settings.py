
from unicon.plugins.iosxe.cat9k.settings import IosXECat9kSettings


class IosXEc9800Settings(IosXECat9kSettings):

    def __init__(self):
        super().__init__()
