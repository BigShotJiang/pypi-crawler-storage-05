class StackException(Exception):
    ''' base class '''
    pass
