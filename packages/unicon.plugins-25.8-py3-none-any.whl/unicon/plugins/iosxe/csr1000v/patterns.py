__author__ = "Myles Dear <mdear@cisco.com>"

from unicon.plugins.iosxe.patterns import IosXEPatterns


class IosXECsr1000vPatterns(IosXEPatterns):
    def __init__(self):
        super().__init__()
