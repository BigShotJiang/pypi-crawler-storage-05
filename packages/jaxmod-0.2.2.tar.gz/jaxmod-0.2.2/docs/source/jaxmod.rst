jaxmod package
==============

Submodules
----------

jaxmod.constants module
-----------------------

.. automodule:: jaxmod.constants
   :members:
   :show-inheritance:
   :undoc-members:

jaxmod.type\_aliases module
---------------------------

.. automodule:: jaxmod.type_aliases
   :members:
   :show-inheritance:
   :undoc-members:

jaxmod.units module
-------------------

.. automodule:: jaxmod.units
   :members:
   :show-inheritance:
   :undoc-members:

jaxmod.utils module
-------------------

.. automodule:: jaxmod.utils
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: jaxmod
   :members:
   :show-inheritance:
   :undoc-members:
