from . import attributes

__all__ = [
    "attributes",
]
