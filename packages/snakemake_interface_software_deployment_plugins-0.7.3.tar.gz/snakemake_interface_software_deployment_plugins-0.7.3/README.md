# Stable interfaces and functionality for Snakemake software deployment plugins

This package provides a stable interface for interactions between Snakemake and its software deployment plugins.
It is still a work in progress, but completing it is the next big thing on our list.
