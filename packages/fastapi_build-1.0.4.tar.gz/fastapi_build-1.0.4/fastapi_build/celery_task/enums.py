# -- coding: utf-8 --
# @Time : 2024/5/15 18:30
# @Author : PinBar
# @File : enums.py
TASK_QUEUE = 'demo'