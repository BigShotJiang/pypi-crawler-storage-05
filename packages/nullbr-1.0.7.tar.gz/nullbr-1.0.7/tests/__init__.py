# Tests for nullbr
