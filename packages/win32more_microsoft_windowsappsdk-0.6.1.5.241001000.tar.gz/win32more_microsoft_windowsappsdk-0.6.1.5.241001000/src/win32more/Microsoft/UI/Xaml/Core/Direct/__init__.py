from __future__ import annotations
from win32more.winrt.prelude import *
import win32more.Microsoft.UI.Xaml.Core.Direct
XamlDirectContract: UInt32 = 65536


make_ready(__name__)
