#!/usr/bin/python
# coding: utf-8
from systems_manager.systems_manager_mcp import main

if __name__ == "__main__":
    main()
