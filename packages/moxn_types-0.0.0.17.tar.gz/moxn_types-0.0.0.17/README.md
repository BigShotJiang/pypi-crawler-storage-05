DTOs for moxn
