from HaramDetector import IsHaram

IsHaram("Play CS:GO")