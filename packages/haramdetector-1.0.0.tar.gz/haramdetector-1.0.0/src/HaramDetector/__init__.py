from .IsHaram import IsHaram

__all__ = ["IsHaram"]