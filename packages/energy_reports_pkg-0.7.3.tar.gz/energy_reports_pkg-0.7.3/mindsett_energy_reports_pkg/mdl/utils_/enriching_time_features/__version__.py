

__version__ = '0.0.2' # add feature for patching missing period
__version__ = '0.0.1' # initial version