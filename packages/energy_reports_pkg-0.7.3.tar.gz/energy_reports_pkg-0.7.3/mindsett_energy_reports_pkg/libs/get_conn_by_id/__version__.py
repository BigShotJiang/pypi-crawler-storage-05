
__version__ = '0.0.3' # can set multiple paths for local and databricks

# __version__ = '0.0.2' # being able to get conn from local, airflow, and databricks

# __version__ = '0.0.1' # require two functions for getting the conn

# __version__ = '0.0.0' # the basic way for getting conn only from airflow