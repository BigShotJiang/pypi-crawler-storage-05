from agno.os.routers.memory.memory import get_memory_router

__all__ = ["get_memory_router"]
