# Origin


## Enum

* `REV_ENG_MINUS_MALWARE` (value: `'RevEng-Malware'`)

* `REV_ENG_MINUS_LIBRARY` (value: `'RevEng-Library'`)

* `REV_ENG_MINUS_BENIGN` (value: `'RevEng-Benign'`)

* `REVENG` (value: `'RevEng'`)

* `REV_ENG_MINUS_HEURISTIC` (value: `'RevEng-Heuristic'`)

* `REV_ENG_MINUS_UNKNOWN` (value: `'RevEng-Unknown'`)

* `VIRUSTOTAL` (value: `'VirusTotal'`)

* `MALWAREBAZAAR` (value: `'MalwareBazaar'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


