Change Log
==========

1.0.0 (2021-01-10)
------------------
* Fix: Redis clients will now disconnect when the HTTP client disconnects
  from the server
* Minor docs improvements
* Switch from Travis CI to GitHub Actions

0.2.1 (2016-04-15)
------------------
* Packaging fix

0.2 (2016-04-15)
----------------
* Added docs and tests
* Published on PyPI

0.1 (2016-04-11)
----------------
Initial release
