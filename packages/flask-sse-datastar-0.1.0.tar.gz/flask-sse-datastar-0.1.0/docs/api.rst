API
===

.. autoclass:: flask_sse.Message
   :members: __init__, to_dict, __str__

.. autoclass:: flask_sse.ServerSentEventsBlueprint
   :members:

.. autodata:: flask_sse.sse
