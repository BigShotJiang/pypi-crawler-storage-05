import os


test_directory = os.path.dirname(os.path.realpath(__file__))
