# subtr-actor

Python bindings for the [subtr-actor](https://github.com/rlrml/subtr-actor) library.
