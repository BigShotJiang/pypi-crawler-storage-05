
"""
  Arabic, Armenian, Bengali, Canadian_Aboriginal, Cherokee, Cyrillic, Devanagari, Ethiopic,
       Fraktur, Georgian, Greek, Gujarati, Gurmukhi, HanS (Han simplified), HanS_vert (Han
       simplified, vertical), HanT (Han traditional), HanT_vert (Han traditional, vertical), Hangul,
       Hangul_vert (Hangul vertical), Hebrew, Japanese, Japanese_vert (Japanese vertical), Kannada,
       Khmer, Lao, Latin, Malayalam, Myanmar, Oriya (Odia), Sinhala, Syriac, Tamil, Telugu, Thaana,
       Thai, Tibetan, Vietnamese.

"""

def visible_font_for_language(lang):
    # TODO: or script?

    # TODO: make sure to keep xref count
    pass


lang2font = {
    ''
}
