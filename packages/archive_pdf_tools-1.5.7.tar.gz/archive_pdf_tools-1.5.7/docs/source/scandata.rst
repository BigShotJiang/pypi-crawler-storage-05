.. _scandata:

Scandata parsing
================


.. automodule:: internetarchivepdf.scandata
    :members:


