.. _pdfhacks:

PDF hacks
=========


.. automodule:: internetarchivepdf.pdfhacks
    :members:


