.. _recode:

PDF recoding
============


.. automodule:: internetarchivepdf.recode
    :members:


