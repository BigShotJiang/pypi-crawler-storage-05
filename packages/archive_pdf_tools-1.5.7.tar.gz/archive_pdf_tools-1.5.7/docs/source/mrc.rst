.. _mrc:

Mixed Raster Content encoding
=============================


.. automodule:: internetarchivepdf.mrc
    :members:


