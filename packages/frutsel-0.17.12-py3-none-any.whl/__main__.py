import frutsel

frutsel.command_line_interface()
