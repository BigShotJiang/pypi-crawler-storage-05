# prismatools


[![image](https://img.shields.io/pypi/v/prismatools.svg)](https://pypi.python.org/pypi/prismatools)
[![image](https://img.shields.io/conda/vn/conda-forge/prismatools.svg)](https://anaconda.org/conda-forge/prismatools)


**prismatools is an open-source Python package for reading, analyzing, and visualizing hyperspectral imagery from the PRISMA mission.**


-   Free software: MIT License
-   Documentation: https://gthlor.github.io/prismatools
    

## Features

-   TODO
