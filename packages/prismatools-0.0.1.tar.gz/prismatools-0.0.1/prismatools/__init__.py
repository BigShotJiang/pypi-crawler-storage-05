"""Top-level package for prismatools."""

__author__ = """Lorenzo Crecco"""
__email__ = "lorenzo.crecco@hotmail.com"
__version__ = "0.0.1"
