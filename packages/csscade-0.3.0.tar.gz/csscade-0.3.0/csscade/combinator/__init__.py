"""CSScade Combinator - Intelligent CSS class conflict detection and override generation."""

from .combinator import Combinator

__all__ = ['Combinator']