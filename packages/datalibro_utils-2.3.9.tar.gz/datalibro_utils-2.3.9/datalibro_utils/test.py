def test_adward():
    print('hello world')

def test_yida(a, b):
    return a+b