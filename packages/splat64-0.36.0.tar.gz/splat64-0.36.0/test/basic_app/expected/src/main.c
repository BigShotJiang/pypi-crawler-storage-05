#include "common.h"

INCLUDE_RODATA("test/basic_app/split/asm/nonmatchings/main", D_80000510);

INCLUDE_ASM("test/basic_app/split/asm/nonmatchings/main", func_80000400);

INCLUDE_ASM("test/basic_app/split/asm/nonmatchings/main", func_800004A0);
