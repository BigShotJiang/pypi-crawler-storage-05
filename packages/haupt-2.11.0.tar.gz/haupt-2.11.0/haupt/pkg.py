NAME = "haupt"
VERSION = "2.11.0"
DESC = (
    "Lineage metadata API, artifacts streams, sandbox, ML-API, and spaces for Polyaxon."
)
URL = "https://github.com/polyaxon/haupt"
AUTHOR = "Polyaxon, Inc."
EMAIL = "contact@polyaxon.com"
LICENSE = "AGPLv3"
