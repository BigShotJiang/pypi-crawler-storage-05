from haupt.common.options.option_manager import OptionManager

option_manager = OptionManager()
