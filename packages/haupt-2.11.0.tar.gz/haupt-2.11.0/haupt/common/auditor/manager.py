from haupt.common.events.event_manager import EventManager

event_manager = EventManager()
