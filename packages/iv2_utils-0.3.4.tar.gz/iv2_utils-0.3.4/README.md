# InternVideo2 Testing Utils

This package has some utils for IV2 Testing.