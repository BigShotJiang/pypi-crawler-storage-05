default_app_config = "pulp_smart_proxy.app.PulpSmartProxyPluginAppConfig"
