"""Tests that communicate with smart_proxy plugin via the v3 API."""
