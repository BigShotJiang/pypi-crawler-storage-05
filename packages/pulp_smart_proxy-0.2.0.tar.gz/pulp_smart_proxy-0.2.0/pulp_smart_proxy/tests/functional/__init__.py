"""Tests for smart_proxy plugin."""
