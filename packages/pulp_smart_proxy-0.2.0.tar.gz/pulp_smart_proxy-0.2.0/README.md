# pulp-smart-proxy

A Pulp plugin to support being a Foreman Smart Proxy.

For more information, please see the [documentation](docs/index.md) or the [Pulp project page](https://pulpproject.org/).


How to File an Issue
--------------------

File through this project's GitHub issues and appropriate labels.

> **WARNING** Is this security related? If so, please follow the [Security Disclosures](https://docs.pulpproject.org/pulpcore/bugs-features.html#security-bugs) procedure.
