"""Feature tests for complete wry workflows."""
