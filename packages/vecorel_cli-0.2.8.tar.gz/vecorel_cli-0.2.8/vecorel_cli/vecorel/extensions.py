ADMIN_DIVISION = "https://vecorel.org/administrative-division-extension/v0.1.0/schema.yaml"

GEOMETRY_METRICS = "https://vecorel.org/geometry-metrics-extension/v0.1.0/schema.yaml"
