
# symmora_math

Пример пакета с математическими функциями

Установка:
```bash
pip install symmora_math
