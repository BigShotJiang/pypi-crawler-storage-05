from .losses import BaseLoss, LeveneLoss, TTestLoss

__all__ = ["BaseLoss", "KSLoss", "TTestLoss", "LeveneLoss"]
