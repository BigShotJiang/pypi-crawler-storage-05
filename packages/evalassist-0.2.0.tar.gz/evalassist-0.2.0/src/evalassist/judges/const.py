DEFAULT_JUDGE_INFERENCE_PARAMS = {
    "temperature": 0,
}
