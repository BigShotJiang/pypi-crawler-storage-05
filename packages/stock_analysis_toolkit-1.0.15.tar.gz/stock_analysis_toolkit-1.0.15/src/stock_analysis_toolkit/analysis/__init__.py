"""
Analysis package for technical and fundamental stock analysis.
"""

# This file makes the analysis directory a Python package
