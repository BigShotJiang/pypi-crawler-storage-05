# The root of the entire project
from music_drummer.music_drummer import Drummer

# This is the version number of your code.  This will change each time you make
# a new release.  The most popular approach is to use Semantic Versioning,
# described at https://semver.org/
__version__ = "0.1.0"
