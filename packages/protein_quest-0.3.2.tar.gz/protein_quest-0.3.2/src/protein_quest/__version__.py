__version__ = "0.3.2"
"""The version of the package."""
