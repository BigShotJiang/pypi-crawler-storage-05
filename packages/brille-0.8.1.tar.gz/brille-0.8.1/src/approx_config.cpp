#include "approx_config.hpp"
using namespace brille::approx_float;
Config brille::approx_float::config{};

//Config &ConfigHolder::get() {
//  static Config instance{};
//  return instance;
//}
