Brillouin Zone
--------------

.. autoclass:: brille._brille.BrillouinZone
  :members:
