Lattices
--------

.. autofunction:: brille.Lattice

.. autoclass:: brille._brille.Bravais

.. autoclass:: brille._brille.Lattice
  :members:
