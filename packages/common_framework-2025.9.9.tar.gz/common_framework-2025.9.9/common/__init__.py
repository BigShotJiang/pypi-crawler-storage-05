# coding: utf-8
__all__ = []
__version__ = "2025.9.9"

default_app_config = "common.apps.CommonConfig"
