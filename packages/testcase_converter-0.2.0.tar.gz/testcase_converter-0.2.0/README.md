# Test Case Converter

Convert test cases between Excel and XMind formats.

## Installation
```bash
pip install testcase-converter
```

## New Features in v0.2.0

- Added remark field with fixed value "上传用例需要" after expected result
- Enhanced compatibility for both old and new Excel formats
- Improved error handling and logging

## Usage Examples

### As a CLI Tool:
```bash
# Excel to XMind
testcase-converter test_cases.xlsx

# XMind to Excel
testcase-converter test_cases.xmind

# 启用日志文件生成（使用简短参数 -l）
testcase-converter -l test_cases.xlsx

# 设置默认车型和优先级（使用简短参数 -v 和 -p）
testcase-converter -v "默认车型" -p "3" test_cases.xlsx

# 仅填充模式（使用简短参数 -f）
testcase-converter -f -v "OTA" -p "0" test_cases.xlsx

# 组合使用所有参数
testcase-converter -l -f -v "OTA" -p "0" test_cases.xmind
```

### As a Python Library:
```python
from testcase_converter import TestCaseConverter, ConversionType

# Auto-detect conversion type
converter = TestCaseConverter("input.xlsx")
converter.convert()

# Explicitly specify conversion type with new options
converter = TestCaseConverter(
    "input.xmind", 
    ConversionType.XMIND_TO_EXCEL,
    enable_logging=True,              # 启用日志文件生成
    default_vehicle_type="默认车型",      # 设置默认车型
    default_priority="3"              # 设置默认优先级
)

# 仅填充模式
converter = TestCaseConverter(
    "input.xlsx",
    ConversionType.FILL_ONLY,         # 设置为仅填充模式
    default_vehicle_type="OTA",       # 设置默认车型
    default_priority="0"              # 设置默认优先级
)
converter.convert()
```

### 命令行参数说明

| 长参数名 | 短参数名 | 说明 |
|---------|---------|------|
| `--enable-logging` | `-l` | 启用日志文件生成 |
| `--default-vehicle-type` | `-v` | 默认车型，用于填充空的车型字段 |
| `--default-priority` | `-p` | 默认优先级，用于填充空的优先级字段 |
| `--fill-only` | `-f` | 仅填充模式，不转换文件格式 |
| `--debug` | 无 | 启用调试模式 |

### Format Details

The converter now automatically adds a remark field with the fixed value "上传用例需要" after the expected result field in both XMind notes and Excel columns.

For Excel files:
- New format includes 8 columns: Module, Case Name, Precondition, Steps, Expected Result, Remark, Vehicle Type, Priority
- Backward compatibility maintained for 7-column format (remark will be added with default value)

For XMind files:
- Remark field is added to notes with format: 【备注】上传用例需要