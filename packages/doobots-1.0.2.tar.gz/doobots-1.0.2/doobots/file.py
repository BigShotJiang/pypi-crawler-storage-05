class File:
    def __init__(self, base64_str: str = "", fileName: str = ""):
        self.base64 = base64_str
        self.fileName = fileName
