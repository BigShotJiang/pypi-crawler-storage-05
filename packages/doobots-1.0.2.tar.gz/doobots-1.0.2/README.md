# DooBots - Python

Aqui ficam as classes helpers para facilitar o desenvolvimento de scripts Python a serem executados no DooBots.

## Executar os Testes

```shell
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
./run-tests.sh
```