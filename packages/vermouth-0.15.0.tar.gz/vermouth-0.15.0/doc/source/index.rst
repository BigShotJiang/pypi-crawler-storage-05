.. VerMoUTH documentation master file, created by
   sphinx-quickstart on Fri Jun 22 14:51:23 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to VerMoUTH's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   general_overview
   martinize2_workflow
   technical_background
   file_formats
   tutorials/index
   api/modules
   gromacs_variables


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

