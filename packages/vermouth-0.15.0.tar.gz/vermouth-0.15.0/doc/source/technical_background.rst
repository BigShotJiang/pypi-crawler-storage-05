Technical background
====================
Here we will provide some additional technical background about the chosen data
structures and graph algorithms.

.. toctree::
    processors
    data
    graph_algorithms