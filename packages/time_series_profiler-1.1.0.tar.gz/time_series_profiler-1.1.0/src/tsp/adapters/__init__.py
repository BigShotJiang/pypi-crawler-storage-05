from .pandas_adapter import wrap

__all__ = ["wrap"]
