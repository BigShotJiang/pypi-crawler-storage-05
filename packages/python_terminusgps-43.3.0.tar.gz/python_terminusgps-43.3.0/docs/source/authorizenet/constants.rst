Constants
=========

.. py:currentmodule:: terminusgps.authorizenet.constants

.. autodata:: ANET_XMLNS

.. autoclass:: AuthorizenetSubscriptionStatus
    :members:

.. autoclass:: AuthorizenetSubscriptionIntervalUnit
    :members:
