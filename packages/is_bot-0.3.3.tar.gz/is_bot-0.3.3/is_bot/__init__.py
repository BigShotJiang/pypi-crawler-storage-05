from ._is_bot import Bots

__version__ = '0.3.3'

__all__ = ('Bots',)
