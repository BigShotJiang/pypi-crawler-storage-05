==========================================
Stein Series (3.4.0 - 3.6.x) Release Notes
==========================================

.. release-notes::
   :branch: stable/stein
