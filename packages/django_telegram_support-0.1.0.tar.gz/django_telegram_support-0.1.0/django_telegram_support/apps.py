from django.apps import AppConfig

class TelegramSupportConfig(AppConfig):
    name = "django_telegram_support"
    verbose_name = "Telegram Support"