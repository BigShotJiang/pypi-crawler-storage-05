Registry
===================

.. automodule:: evolib.utils.registry
   :members:
   :undoc-members:
   :show-inheritance:
