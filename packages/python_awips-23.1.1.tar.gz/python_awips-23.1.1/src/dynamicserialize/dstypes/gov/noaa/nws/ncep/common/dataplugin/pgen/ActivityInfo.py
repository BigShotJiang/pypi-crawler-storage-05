
# File auto-generated against equivalent DynamicSerialize Java class

class ActivityInfo(object):

    def __init__(self):
        self.activityName = None
        self.activityType = None
        self.activitySubtype = None
        self.activityLabel = None
        self.site = None
        self.desk = None
        self.forecaster = None
        self.refTime = None
        self.mode = None
        self.status = None

    def getActivityName(self):
        return self.activityName

    def setActivityName(self, activityName):
        self.activityName = activityName

    def getActivityType(self):
        return self.activityType

    def setActivityType(self, activityType):
        self.activityType = activityType

    def getActivitySubtype(self):
        return self.activitySubtype

    def setActivitySubtype(self, activitySubtype):
        self.activitySubtype = activitySubtype

    def getActivityLabel(self):
        return self.activityLabel

    def setActivityLabel(self, activityLabel):
        self.activityLabel = activityLabel

    def getSite(self):
        return self.site

    def setSite(self, site):
        self.site = site

    def getDesk(self):
        return self.desk

    def setDesk(self, desk):
        self.desk = desk

    def getForecaster(self):
        return self.forecaster

    def setForecaster(self, forecaster):
        self.forecaster = forecaster

    def getRefTime(self):
        return self.refTime

    def setRefTime(self, refTime):
        self.refTime = refTime

    def getMode(self):
        return self.mode

    def setMode(self, mode):
        self.mode = mode

    def getStatus(self):
        return self.status

    def setStatus(self, status):
        self.status = status

