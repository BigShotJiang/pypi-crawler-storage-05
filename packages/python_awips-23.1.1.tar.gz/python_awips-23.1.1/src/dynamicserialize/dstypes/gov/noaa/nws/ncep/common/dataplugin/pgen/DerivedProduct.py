
# File auto-generated against equivalent DynamicSerialize Java class

class DerivedProduct(object):

    def __init__(self):
        self.name = None
        self.productType = None
        self.product = None

    def getName(self):
        return self.name

    def setName(self, name):
        self.name = name

    def getProductType(self):
        return self.productType

    def setProductType(self, productType):
        self.productType = productType

    def getProduct(self):
        return self.product

    def setProduct(self, product):
        self.product = product

