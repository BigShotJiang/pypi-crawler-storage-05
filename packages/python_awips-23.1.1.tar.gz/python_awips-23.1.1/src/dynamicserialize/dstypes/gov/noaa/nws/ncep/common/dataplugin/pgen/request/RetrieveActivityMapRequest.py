
# File auto-generated against equivalent DynamicSerialize Java class
# 
#      SOFTWARE HISTORY
# 
#     Date            Ticket#       Engineer       Description
#     ------------    ----------    -----------    --------------------------
#     May 05, 2016                  root           Generated

class RetrieveActivityMapRequest(object):

    def __init__(self):
        return
