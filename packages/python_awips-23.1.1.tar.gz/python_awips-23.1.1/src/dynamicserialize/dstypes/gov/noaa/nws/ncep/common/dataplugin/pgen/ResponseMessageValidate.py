
# File auto-generated against equivalent DynamicSerialize Java class

class ResponseMessageValidate(object):

    def __init__(self):
        self.result = None
        self.message = None
        self.fileType = None
        self.dataURI = None
        self.validTime = None

    def getResult(self):
        return self.result

    def setResult(self, result):
        self.result = result

    def getMessage(self):
        return self.message

    def setMessage(self, message):
        self.message = message

    def getFileType(self):
        return self.fileType

    def setFileType(self, fileType):
        self.fileType = fileType

    def getDataURI(self):
        return self.dataURI

    def setDataURI(self, dataURI):
        self.dataURI = dataURI

    def getValidTime(self):
        return self.validTime

    def setValidTime(self, validTime):
        self.validTime = validTime

