
# File auto-generated against equivalent DynamicSerialize Java class

class StoreDerivedProductRequest(object):

    def __init__(self):
        self.dataURI = None
        self.productList = None

    def getDataURI(self):
        return self.dataURI

    def setDataURI(self, dataURI):
        self.dataURI = dataURI

    def getProductList(self):
        return self.productList

    def setProductList(self, productList):
        self.productList = productList

