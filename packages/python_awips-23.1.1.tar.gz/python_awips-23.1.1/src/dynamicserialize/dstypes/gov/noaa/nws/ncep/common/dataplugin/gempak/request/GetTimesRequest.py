
# File auto-generated against equivalent DynamicSerialize Java class
# 
#      SOFTWARE HISTORY
# 
#     Date            Ticket#       Engineer       Description
#     ------------    ----------    -----------    --------------------------
#     Sep 16, 2016                  pmoyer         Generated

class GetTimesRequest(object):

    def __init__(self):
        self.pluginName = None
        self.timeField = None

    def getPluginName(self):
        return self.pluginName

    def setPluginName(self, pluginName):
        self.pluginName = pluginName

    def getTimeField(self):
        return self.timeField

    def setTimeField(self, timeField):
        self.timeField = timeField

