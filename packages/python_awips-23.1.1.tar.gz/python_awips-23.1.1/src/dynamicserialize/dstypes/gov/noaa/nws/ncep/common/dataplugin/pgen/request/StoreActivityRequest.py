
# File auto-generated against equivalent DynamicSerialize Java class

class StoreActivityRequest(object):

    def __init__(self):
        self.activityInfo = None
        self.activityXML = None

    def getActivityInfo(self):
        return self.activityInfo

    def setActivityInfo(self, activityInfo):
        self.activityInfo = activityInfo

    def getActivityXML(self):
        return self.activityXML

    def setActivityXML(self, activityXML):
        self.activityXML = activityXML

