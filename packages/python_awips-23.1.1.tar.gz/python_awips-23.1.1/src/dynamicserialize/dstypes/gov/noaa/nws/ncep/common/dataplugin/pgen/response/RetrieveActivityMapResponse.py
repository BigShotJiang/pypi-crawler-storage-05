
# File auto-generated against equivalent DynamicSerialize Java class
# 
#      SOFTWARE HISTORY
# 
#     Date            Ticket#       Engineer       Description
#     ------------    ----------    -----------    --------------------------
#     May 06, 2016                  root           Generated

class RetrieveActivityMapResponse(object):

    def __init__(self):
        self.data = None

    def getData(self):
        return self.data

    def setData(self, data):
        self.data = data

