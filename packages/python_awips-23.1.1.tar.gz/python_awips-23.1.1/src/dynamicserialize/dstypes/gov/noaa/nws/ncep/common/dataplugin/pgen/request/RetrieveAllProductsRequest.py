
# File auto-generated against equivalent DynamicSerialize Java class

class RetrieveAllProductsRequest(object):

    def __init__(self):
        self.dataURI = None

    def getDataURI(self):
        return self.dataURI

    def setDataURI(self, dataURI):
        self.dataURI = dataURI

