
# File auto-generated against equivalent DynamicSerialize Java class
# 
#      SOFTWARE HISTORY
# 
#     Date            Ticket#       Engineer       Description
#     ------------    ----------    -----------    --------------------------
#     Sep 16, 2016                  pmoyer         Generated

class GetGridDataRequest(object):

    def __init__(self):
        self.vcoord = None
        self.level2 = None
        self.modelId = None
        self.parm = None
        self.level1 = None
        self.reftime = None
        self.pluginName = None
        self.fcstsec = None

    def getVcoord(self):
        return self.vcoord

    def setVcoord(self, vcoord):
        self.vcoord = vcoord

    def getLevel2(self):
        return self.level2

    def setLevel2(self, level2):
        self.level2 = level2

    def getModelId(self):
        return self.modelId

    def setModelId(self, modelId):
        self.modelId = modelId

    def getParm(self):
        return self.parm

    def setParm(self, parm):
        self.parm = parm

    def getLevel1(self):
        return self.level1

    def setLevel1(self, level1):
        self.level1 = level1

    def getReftime(self):
        return self.reftime

    def setReftime(self, reftime):
        self.reftime = reftime

    def getPluginName(self):
        return self.pluginName

    def setPluginName(self, pluginName):
        self.pluginName = pluginName

    def getFcstsec(self):
        return self.fcstsec

    def setFcstsec(self, fcstsec):
        self.fcstsec = fcstsec

