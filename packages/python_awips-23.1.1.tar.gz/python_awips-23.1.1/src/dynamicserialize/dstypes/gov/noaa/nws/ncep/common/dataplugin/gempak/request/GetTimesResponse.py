
# File auto-generated against equivalent DynamicSerialize Java class
# 
#      SOFTWARE HISTORY
# 
#     Date            Ticket#       Engineer       Description
#     ------------    ----------    -----------    --------------------------
#     Sep 16, 2016                  pmoyer         Generated

class GetTimesResponse(object):

    def __init__(self):
        self.times = None

    def getTimes(self):
        return self.times

    def setTimes(self, times):
        self.times = times

