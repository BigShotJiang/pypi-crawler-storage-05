
# File auto-generated against equivalent DynamicSerialize Java class
# 
#      SOFTWARE HISTORY
# 
#     Date            Ticket#       Engineer       Description
#     ------------    ----------    -----------    --------------------------
#     May 06, 2016                  root           Generated

class ActivityMapData(object):

    def __init__(self):
        self.refTime = None
        self.activityLabel = None
        self.activitySubtype = None
        self.dataURI = None
        self.activityType = None
        self.activityName = None

    def getRefTime(self):
        return self.refTime

    def setRefTime(self, refTime):
        self.refTime = refTime

    def getActivityLabel(self):
        return self.activityLabel

    def setActivityLabel(self, activityLabel):
        self.activityLabel = activityLabel

    def getActivitySubtype(self):
        return self.activitySubtype

    def setActivitySubtype(self, activitySubtype):
        self.activitySubtype = activitySubtype

    def getDataURI(self):
        return self.dataURI

    def setDataURI(self, dataURI):
        self.dataURI = dataURI

    def getActivityType(self):
        return self.activityType

    def setActivityType(self, activityType):
        self.activityType = activityType

    def getActivityName(self):
        return self.activityName

    def setActivityName(self, activityName):
        self.activityName = activityName

