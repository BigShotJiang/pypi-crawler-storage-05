
# File auto-generated against equivalent DynamicSerialize Java class
# 
#      SOFTWARE HISTORY
# 
#     Date            Ticket#       Engineer       Description
#     ------------    ----------    -----------    --------------------------
#     Sep 16, 2016                  pmoyer         Generated

class GetGridNavRequest(object):

    def __init__(self):
        self.modelId = None
        self.pluginName = None

    def getModelId(self):
        return self.modelId

    def setModelId(self, modelId):
        self.modelId = modelId

    def getPluginName(self):
        return self.pluginName

    def setPluginName(self, pluginName):
        self.pluginName = pluginName

