
# File auto-generated against equivalent DynamicSerialize Java class

class RetrieveAtcfDeckRequest(object):

    def __init__(self):
        self.deckID = None

    def getDeckID(self):
        return self.deckID

    def setDeckID(self, deckID):
        self.deckID = deckID

