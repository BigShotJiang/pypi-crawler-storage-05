
# File auto-generated against equivalent DynamicSerialize Java class
# 
#      SOFTWARE HISTORY
# 
#     Date            Ticket#       Engineer       Description
#     ------------    ----------    -----------    --------------------------
#     Sep 16, 2016                  pmoyer         Generated

class UpperAirDataRequest(object):

    def __init__(self):
        self.refTime = None
        self.pluginName = None
        self.parmList = None
        self.stationId = None
        self.partNumber = None

    def getRefTime(self):
        return self.refTime

    def setRefTime(self, refTime):
        self.refTime = refTime

    def getPluginName(self):
        return self.pluginName

    def setPluginName(self, pluginName):
        self.pluginName = pluginName

    def getParmList(self):
        return self.parmList

    def setParmList(self, parmList):
        self.parmList = parmList

    def getStationId(self):
        return self.stationId

    def setStationId(self, stationId):
        self.stationId = stationId

    def getPartNumber(self):
        return self.partNumber

    def setPartNumber(self, partNumber):
        self.partNumber = partNumber

