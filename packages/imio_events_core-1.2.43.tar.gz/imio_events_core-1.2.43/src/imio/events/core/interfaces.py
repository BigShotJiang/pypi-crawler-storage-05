# -*- coding: utf-8 -*-

from zope.publisher.interfaces.browser import IDefaultBrowserLayer


class IImioEventsCoreLayer(IDefaultBrowserLayer):
    """Marker interface that defines a browser layer."""
