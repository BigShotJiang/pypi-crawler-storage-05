"""Chat Memory MCP Server

A Model Context Protocol server for managing chat memory with automatic summarization
and file sharing capabilities.
"""

__version__ = "0.1.0"