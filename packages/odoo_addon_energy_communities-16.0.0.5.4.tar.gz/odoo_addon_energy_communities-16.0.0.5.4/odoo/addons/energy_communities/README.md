# Energy Communities

Base addon for the basis operacion with energy communities

## Changelog

### 2025-05-21

- Added Readme
