from odoo.addons.component.core import Component


class ProductUtils(Component):
    _name = "product.utils"
    _usage = "product.utils"
    _apply_on = "product.template"
    _collection = "utils.backend"
