from . import multicompany_easy_creation
from . import create_users_wizard
from . import change_coordinator_wizard
