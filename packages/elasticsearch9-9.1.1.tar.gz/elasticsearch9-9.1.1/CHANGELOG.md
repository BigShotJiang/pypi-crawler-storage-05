See: https://www.elastic.co/guide/en/elasticsearch/client/python-api/current/release-notes.html
