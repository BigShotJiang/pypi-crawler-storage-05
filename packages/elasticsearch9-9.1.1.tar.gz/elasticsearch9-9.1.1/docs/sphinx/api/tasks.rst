.. _tasks:

Tasks
-----
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: TasksClient
   :members: