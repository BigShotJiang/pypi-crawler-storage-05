.. _search-application:

Search Applications
-------------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: SearchApplicationClient
   :members: