.. _sql:

SQL
---
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: SqlClient
   :members: