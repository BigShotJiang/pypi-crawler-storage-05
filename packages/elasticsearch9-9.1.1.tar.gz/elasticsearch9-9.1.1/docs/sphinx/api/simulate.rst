.. _simulate:

Simulate
--------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: SimulateClient
   :members:
