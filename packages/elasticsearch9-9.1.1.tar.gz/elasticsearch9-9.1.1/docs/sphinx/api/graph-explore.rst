.. _graph-explore:

Graph Explore
-------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: GraphClient
   :members: