.. _tls-ssl:

TLS/SSL
-------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: SslClient
   :members: