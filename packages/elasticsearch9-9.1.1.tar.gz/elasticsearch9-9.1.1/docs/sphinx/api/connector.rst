.. _connector:

Connector
---------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: ConnectorClient
   :members:
