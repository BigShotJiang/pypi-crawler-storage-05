.. _esql:

ES|QL
-----
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: EsqlClient
   :members: