.. _x-pack:

X-Pack
------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: XPackClient
   :members: