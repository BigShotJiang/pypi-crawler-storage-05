.. _index-lifecycle-management:

Index Lifecycle Management (ILM)
--------------------------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: IlmClient
   :members: