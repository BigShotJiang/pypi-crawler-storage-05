# AGT Server

A comprehensive tournament server for game theory lab competitions, supporting multiple game types including Rock Paper Scissors, Battle of the Sexes, Chicken, Prisoner's Dilemma, Lemonade Stand, Auctions, and more.

## Features

- **Multiple Game Types**: Support for 9+ different game theory scenarios
- **Real-time Dashboard**: Web-based monitoring and control interface
- **Tournament Management**: Automated player matching and scoring
- **Extensible Architecture**: Easy to add new games and agents
- **Command Line Tools**: Simple CLI for server and dashboard management
- **Python Package**: Easy to import and integrate into your projects

## Supported Games

- **RPS**: Rock Paper Scissors (2 players, 100 rounds)
- **BOS**: Battle of the Sexes (2 players, 100 rounds)
- **BOSII**: Battle of the Sexes II (2 players, 100 rounds)
- **Chicken**: Chicken Game (2 players, 100 rounds)
- **PD**: Prisoner's Dilemma (2 players, 100 rounds)
- **Lemonade**: Lemonade Stand (2 players, 100 rounds)
- **Auction**: Auction Game (2+ players, 100 rounds)
- **ADX2D**: Ad Exchange Two Day (2+ players, 100 rounds)
- **ADX1D**: Ad Exchange One Day (2+ players, 100 rounds)

## Quick Start

### Installation

#### From Source
```bash
git clone https://github.com/yourusername/agt-server.git
cd agt-server
pip install -e .
```

#### From PyPI (when published)
```bash
pip install agt-server
```

### Basic Usage

#### Command Line Interface

Start the server:
```bash
agt-server --game rps --port 8080
```

Start the dashboard:
```bash
agt-dashboard --port 8081 --server-port 8080
```

Start both together:
```bash
python -m agt_server.cli both --game rps
```

#### Python API

```python
import asyncio
from agt_server import AGTServer

# Create and configure server
config = {
    "game_type": "rps",
    "num_rounds": 100,
    "num_players": 2
}

server = AGTServer(config, host="0.0.0.0", port=8080)

# Run the server
asyncio.run(server.run())
```

#### Web Dashboard

Once running, access the dashboard at:
- **Dashboard**: http://localhost:8081
- **Server**: localhost:8080

## Detailed Usage

### Server Configuration

The server accepts various configuration options:

```python
config = {
    "game_type": "rps",           # Game to run
    "num_rounds": 100,            # Rounds per game
    "num_players": 2,             # Players per game
    "allowed_games": ["rps"],     # Restrict to specific games
    "verbose": False              # Enable debug output
}
```

### Command Line Options

#### agt-server
```bash
agt-server [OPTIONS]

Options:
  --host TEXT           Host to bind to [default: 0.0.0.0]
  --port INTEGER       Port to bind to [default: 8080]
  --game TEXT          Game type [default: rps]
  --num-rounds INTEGER Number of rounds [default: 100]
  --num-players INTEGER Number of players [default: 2]
  --verbose            Enable verbose logging
  --config PATH        Custom configuration file
  --help              Show this message and exit
```

#### agt-dashboard
```bash
agt-dashboard [OPTIONS]

Options:
  --port INTEGER       Dashboard port [default: 8081]
  --server-port INTEGER Server port [default: 8080]
  --host TEXT          Dashboard host [default: localhost]
  --server-host TEXT   Server host [default: localhost]
  --help              Show this message and exit
```

### Custom Configuration Files

Create a JSON configuration file:

```json
{
    "game_type": "lemonade",
    "num_rounds": 200,
    "num_players": 4,
    "verbose": true,
    "allowed_games": ["lemonade", "auction"]
}
```

Use it with:
```bash
agt-server --config my_config.json
```

## Development

### Project Structure
```
agt_server/
├── core/           # Game engine and core logic
├── server/         # Tournament server
├── dashboard/      # Web dashboard
├── cli.py         # Command line interface
├── __init__.py    # Package initialization
└── requirements.txt
```

### Running Tests
```bash
# Install development dependencies
pip install -e .[dev]

# Run tests
pytest tests/
```

### Building the Package
```bash
# Build source distribution
python setup.py sdist

# Build wheel
python setup.py bdist_wheel

# Install build tools
pip install build
python -m build
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

- **Documentation**: [Read the Docs](https://agt-server.readthedocs.io/)
- **Issues**: [GitHub Issues](https://github.com/yourusername/agt-server/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/agt-server/discussions)

## Acknowledgments

- Game theory research community
- Educational institutions using AGT for teaching
- Contributors and maintainers

