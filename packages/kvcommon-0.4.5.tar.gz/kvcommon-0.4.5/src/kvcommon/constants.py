from importlib.metadata import version

KVCOMMON_VERSION: str = version("kvcommon")
