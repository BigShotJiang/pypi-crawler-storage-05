from .voice_of_python import MultiLingualVoiceBot

__all__ = ["MultiLingualVoiceBot"]
__version__ = "0.1.0"