{
  "/drone0/mavros/global_position/rel_alt": ["_data"],
  "/drone0/mavros/global_position/global": ["_latitude", "_longitude", "_altitude"]
}