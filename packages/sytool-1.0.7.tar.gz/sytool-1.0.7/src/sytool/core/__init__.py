from .singleton import SingletonMeta
