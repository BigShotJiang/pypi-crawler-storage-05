from enum import Enum


class BridgeType(Enum):
    Client = "Client"
    SFTP = "SFTP"
