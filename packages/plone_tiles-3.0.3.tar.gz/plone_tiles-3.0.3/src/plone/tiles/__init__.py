from plone.tiles.tile import PersistentTile
from plone.tiles.tile import Tile


# Convenience imports

assert Tile, PersistentTile  # silence pyflakes
