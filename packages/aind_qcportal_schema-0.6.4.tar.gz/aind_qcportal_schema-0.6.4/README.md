# aind-qcportal-schema

Install with `pip install aind-qcportal-schema`

## Usage

This package includes classes that are expected by the [QC Portal](https://github.com/AllenNeuralDynamics/aind-qc-portal) for generating custom `QCMetric` value views. For example you can generate dropdowns with specific options, multi-select (checkbox) values with options, etc... 
