# sage_setup: distribution = sagemath-schemes
from sage.dynamics.arithmetic_dynamics.all import *
