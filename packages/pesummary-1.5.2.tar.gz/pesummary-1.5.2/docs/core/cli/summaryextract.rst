==============
summaryextract
==============

This :code:`summaryextract` executable is designed to extract a set of posterior
samples from a file containing more than one set of analyses, for instance a
PESummary metafile.

To see help for this executable please run:

.. code-block:: console

    $ summaryextract --help

.. program-output:: summaryextract --help
