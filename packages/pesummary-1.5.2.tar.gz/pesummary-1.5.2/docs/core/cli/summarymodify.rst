=============
summarymodify
=============

The `summarymodify` executable is designed to modify an existing PESummary
metafile from the command line. This may include modifying the label of the
stored analysis.

To see help for this executable please run:

.. code-block:: console

    $ summarymodify --help

.. program-output:: summarymodify --help
