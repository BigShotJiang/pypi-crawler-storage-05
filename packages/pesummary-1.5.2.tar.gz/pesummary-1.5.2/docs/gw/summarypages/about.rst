==============
The about page
==============

The `about page <https://pesummary.github.io/GW190412/html/About.html>`_ provides
the command line that was used to generate the webpages. This combined with
the `version page <version.html>`_ allows for complete reproducibility. We may
also export this command line to a shell script ready for running by clicking on
the export to bash button.
