========================
The comparison home page
========================

The `comparison home page <https://pesummary.github.io/GW190412/html/Comparison.html>`_
provides a comparison skymap (to see how the preferred source location changes
for the different analyses) and a mega table showing the
`KS <https://en.wikipedia.org/wiki/Kolmogorov–Smirnov_test>`_ and
`JS <https://en.wikipedia.org/wiki/Jensen–Shannon_divergence>`_ statistics for all]
marginalized 1d posterior distributions. Again, like the other tables on these
webpages, these may be exported to `csv` by clicking on the export to csv button.
