==================
The downloads page
==================

The `downloads page <https://pesummary.github.io/GW190412/html/Downloads.html>`_
allows the user to download all information that was used to first generate the
webpages.

We can download the `pesummary` metafile which contains all provided information
for all analyses. We may also download a dat file containing only the posterior
samples for a given analysis, the configuration file used to generate the samples,
a fits file containing the skymap and the psd and calibration information.
