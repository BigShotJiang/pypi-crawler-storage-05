============================
The standard pesummary names
============================

Below we describe what each of the parameters are that are stored in the
PESummary result file:

.. csv-table::
    :file: parameter_descriptions.csv
