# akari\_proto

[AKARI](https://github.com/AkariGroup/) を gRPC 経由で使うための protobuf 定義

詳細は[オンラインドキュメント](https://AkariGroup.github.io/docs)、および [akari_client](https://pypi.org/project/akari-client/) を参照してください。
