---
orphan: true
---

# Iowa

The source is an Excel file downloaded from [iowaworkforcedevelopment.gov](https://www.iowaworkforcedevelopment.gov/worker-adjustment-and-retraining-notification-act).
