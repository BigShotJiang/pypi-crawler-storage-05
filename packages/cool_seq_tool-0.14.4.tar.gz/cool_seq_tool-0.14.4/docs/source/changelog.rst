Changelog
---------

.. changelog::
    :changelog-url: https://coolseqtool.readthedocs.io/en/stable/#changelog
    :github: https://github.com/genomicmedlab/cool-seq-tool/releases/
    :pypi: https://pypi.org/project/cool-seq-tool/
