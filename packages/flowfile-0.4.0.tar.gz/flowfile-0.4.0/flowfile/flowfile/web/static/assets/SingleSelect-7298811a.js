import { _ as _sfc_main } from "./SingleSelect.vue_vue_type_script_setup_true_lang-43807bad.js";
import "./index-5ec791df.js";
export {
  _sfc_main as default
};
