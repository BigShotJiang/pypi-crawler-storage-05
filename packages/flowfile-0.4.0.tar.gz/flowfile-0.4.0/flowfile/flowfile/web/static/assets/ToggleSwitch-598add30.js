import { _ as _sfc_main } from "./ToggleSwitch.vue_vue_type_script_setup_true_lang-f620cd32.js";
import "./index-5ec791df.js";
export {
  _sfc_main as default
};
