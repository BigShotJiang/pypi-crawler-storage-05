import { _ as _sfc_main } from "./MultiSelect.vue_vue_type_script_setup_true_lang-2a7c8312.js";
import "./index-5ec791df.js";
export {
  _sfc_main as default
};
