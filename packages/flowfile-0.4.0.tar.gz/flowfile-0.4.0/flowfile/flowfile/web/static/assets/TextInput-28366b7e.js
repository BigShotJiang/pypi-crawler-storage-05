import { _ as _sfc_main } from "./TextInput.vue_vue_type_script_setup_true_lang-9cad14ba.js";
import "./index-5ec791df.js";
export {
  _sfc_main as default
};
