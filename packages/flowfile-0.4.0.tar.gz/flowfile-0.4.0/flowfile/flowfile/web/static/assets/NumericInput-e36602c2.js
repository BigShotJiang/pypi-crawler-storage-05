import { _ as _sfc_main } from "./NumericInput.vue_vue_type_script_setup_true_lang-211a1990.js";
import "./index-5ec791df.js";
export {
  _sfc_main as default
};
