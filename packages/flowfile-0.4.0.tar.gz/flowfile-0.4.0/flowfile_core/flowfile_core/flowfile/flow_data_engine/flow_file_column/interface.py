from typing import Literal

DataTypeGroup = Literal['numeric', 'str', 'date']
ReadableDataTypeGroup = Literal['Numeric', 'String', 'Date', 'Other', 'Boolean', 'Binary', 'Complex']
