__author__ = "Vanessa Sochat"
__copyright__ = "Copyright The ORAS Authors."
__license__ = "Apache-2.0"


# Fallback support so OrasClient still works
from .provider import Registry as OrasClient  # noqa
