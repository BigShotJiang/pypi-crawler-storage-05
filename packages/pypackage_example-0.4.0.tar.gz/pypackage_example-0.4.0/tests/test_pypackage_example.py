#!/usr/bin/env python

"""Tests for `pypackage_example` package."""


import unittest

from pypackage_example import pypackage_example


class TestPypackage_example(unittest.TestCase):
    """Tests for `pypackage_example` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
