
# pypackage_example module

::: pypackage_example.pypackage_example