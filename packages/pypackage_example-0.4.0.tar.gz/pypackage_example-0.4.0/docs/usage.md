# Usage

To use pypackage_example in a project:

```
import pypackage_example
```
