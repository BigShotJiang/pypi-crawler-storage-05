# common module

::: pypackage_example.common