# Welcome to pypackage_example


[![image](https://img.shields.io/pypi/v/pypackage_example.svg)](https://pypi.python.org/pypi/pypackage_example)


**Just an example of how to create a py package**


-   Free software: MIT License
-   Documentation: <https://gthlor.github.io/pypackage_example>


## Features

-   TODO
