"""Top-level package for pypackage_example."""

__author__ = """Lorenzo Crecco"""
__email__ = "lorenzo.crecco@hotmail.com"
__version__ = "0.4.0"

from .pypackage_example import *
