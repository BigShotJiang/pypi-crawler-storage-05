# pypackage_example


[![image](https://img.shields.io/pypi/v/pypackage_example.svg)](https://pypi.python.org/pypi/pypackage_example)
[![image](https://img.shields.io/conda/vn/conda-forge/pypackage_example.svg)](https://anaconda.org/conda-forge/pypackage_example)


**Just an example of how to create a py package**


-   Free software: MIT License
-   Documentation: https://gthlor.github.io/pypackage_example


## Features

-   TODO
