## Don't force install package in cmk-dev-install-site
<!--
type: bugfix
scope: all
affected: all
-->

remove the mandatory `-f` for `cmk-dev-install` when using
`cmk-dev-install-site`
