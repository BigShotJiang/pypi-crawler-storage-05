## replace netstat with ss
<!--
type: bugfix
scope: internal
affected: all
-->

netstat is deprecated, fresh installs do not have netstat
