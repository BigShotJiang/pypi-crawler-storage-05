## make sure omd-dev-site does not fail if no package is found
<!--
type: bugfix
scope: internal
affected: all
-->

failed in core logic
