## Add OMD config option cmk-dev-site
<!--
type: feature
scope: all
affected: all
-->

User can use `--omd-config` to add list of key-value for OMD config.
