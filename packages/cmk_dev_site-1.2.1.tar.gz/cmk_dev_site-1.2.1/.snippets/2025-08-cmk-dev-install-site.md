## Introduce `cmk-dev install-site`
<!--
type: feature
scope: all
affected: all
-->

`cmk-dev install-site` and its alias `cmk-dev is` is a shortcut wrapper around
`cmk-dev install` and `cmk-dev site`. It can be used to install the version and
create a site with one simple command.

This also introduce the `cmk-dev` command which has currently three
subcommands: `site`, `install`, `install-site`.
