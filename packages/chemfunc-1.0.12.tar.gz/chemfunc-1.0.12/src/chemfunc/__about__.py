"""Chem Func package metadata."""

__version__ = "1.0.12"
