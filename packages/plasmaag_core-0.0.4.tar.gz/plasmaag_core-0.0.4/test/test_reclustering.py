import unittest

# For CAMI dataset, compute comp, abundance, taxonomy, markers
# Subset to e.g. 5 genera plus a few unclassified contigs

# FASTA
# Comp
# Abundance
# Markers
# Taxonomy
# Latent
# Refined taxonomy


class TestKmeansReclustering(unittest.TestCase):
    pass
    # Make markers + lengths
    # Make taxonomy
    # Create latent

    # Initial clustering


class TestDBScanReclustering(unittest.TestCase):
    # It produces disjoint clusters, a subset of the input points
    pass
