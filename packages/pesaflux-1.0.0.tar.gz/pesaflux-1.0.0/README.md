# PesaFlux Python SDK

A modern, lightweight, and easy-to-use Python SDK for the [PesaFlux API](https://pesaflux.co.ke).

## Installation
```bash
pip install pesaflux
