# Linux & Darwin TUN/TAP wrapper for Python

This is a fork of https://github.com/montag451/pytun with partial Darwin support.
