def send_message(to: str, message: str) -> str:
    print(f"Sending '{message}' to {to}")