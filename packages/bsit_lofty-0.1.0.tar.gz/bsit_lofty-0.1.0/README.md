# BSIT Lofty

This project builds a module `lofty.py` which is a part of the BACnet Semantic
Interoperability Toolkit (BSIT) for constructing ASHRAE 223 models of HVAC
systems.

