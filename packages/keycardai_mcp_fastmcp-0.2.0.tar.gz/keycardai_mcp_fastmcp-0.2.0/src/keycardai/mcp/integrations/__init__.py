"""KeyCard AI MCP integrations package."""

from . import fastmcp

__all__ = ["fastmcp"]
