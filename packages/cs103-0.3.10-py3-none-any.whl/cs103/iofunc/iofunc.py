# Functional wrappers for file I/O

def file_close(file):
	return file.close()

def file_readline(file):
	return file.readline()

def file_write(file, contents):
	return file.write(contents)

