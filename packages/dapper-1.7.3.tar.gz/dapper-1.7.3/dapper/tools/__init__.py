"""If the only tool you have is a hammer, it's hard to eat spaghetti."""
