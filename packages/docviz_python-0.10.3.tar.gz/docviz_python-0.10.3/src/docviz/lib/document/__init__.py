from .class_ import Document

__all__ = ["Document"]
