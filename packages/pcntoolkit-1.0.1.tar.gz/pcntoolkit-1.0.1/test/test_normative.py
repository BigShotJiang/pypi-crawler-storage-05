# import pcntoolkit.normative as normative
# from test.fixtures.data_fixtures import *
# from test.fixtures.hbr_model_fixtures import *
# from test.fixtures.path_fixtures import *


# def test_fit(hbr_conf_dict):
#     hbr_conf_dict["func"] = "fit"
#     normative.fit(hbr_conf_dict)


# def test_predict(hbr_conf_dict):
#     hbr_conf_dict["func"] = "predict"
#     normative.predict(hbr_conf_dict)


# def test_fit_predict(hbr_conf_dict):
#     hbr_conf_dict["func"] = "estimate"
#     normative.fit_predict(hbr_conf_dict)


# # bash_command = "python /home/stijn/Projects/PCNtoolkit/pcntoolkit/normative.py /home/stijn/Projects/PCNtoolkit/test/resources/data/responses.csv -f estimate -a hbr -c /home/stijn/Projects/PCNtoolkit/test/resources/data/covariates.csv -t /home/stijn/Projects/PCNtoolkit/test/resources/data/covariates_test.csv -r /home/stijn/Projects/PCNtoolkit/test/resources/data/responses_test.csv trbefile=/home/stijn/Projects/PCNtoolkit/test/resources/data/batch_effects.csv tsbefile=/home/stijn/Projects/PCNtoolkit/test/resources/data/batch_effects_test.csv save_dir=/home/stijn/Projects/PCNtoolkit/test/resources/save_load_test log_dir=/home/stijn/Projects/PCNtoolkit/test/resources/log_test"
