from websocket import create_connection

#from level_tools.classes.types import ListClass, DictClass
#from level_tools.classes.level import Level

class LiveEditor(Level):
    
    pass