__all__ = ["color_id","color_prop","obj_id","lvl_id","prop_id","obj_groups"]

from gmdkit.mappings.color_ids import color_id
from gmdkit.mappings.object_ids import obj_id
from gmdkit.mappings.level_props import lvl_id
from gmdkit.mappings.object_props import prop_id
from gmdkit.mappings.color_props import  color_prop