from . import res_company
from . import res_partner
from . import document_mixin
from . import document
from . import document_related
from . import document_line
from . import res_config_settings
from . import ferroviario
from . import rodoviario
from . import aereo
from . import dutoviario
from . import aquaviario
from . import document_cargo_quantity_infos
from . import document_supplement
from . import document_transported_vehicles
from . import document_comment
from . import res_country
from . import document_type
from . import res_country_state
from . import res_city

spec_schema = "cte"
spec_version = "40"
