NOTE
----

The C++ code here

** only depends on <Python.h> **

and nothing else.

DO NOT ADD CODE WITH OTHER EXTERNAL DEPENDENCIES TO THIS DIRECTORY.

Read on:

pybind11_conduit_v1.h — Type-safe interoperability between different
                        independent Python/C++ bindings systems.
