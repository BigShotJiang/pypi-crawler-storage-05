"""Service implementations for KiCad Library Manager."""
