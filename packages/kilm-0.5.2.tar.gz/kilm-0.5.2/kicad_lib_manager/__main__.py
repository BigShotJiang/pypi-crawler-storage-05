"""
Entry point for running the package as a module
"""

from .main import app

if __name__ == "__main__":
    app()
