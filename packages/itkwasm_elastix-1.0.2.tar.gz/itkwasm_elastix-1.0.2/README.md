# itkwasm-elastix

[![PyPI version](https://badge.fury.io/py/itkwasm-elastix.svg)](https://badge.fury.io/py/itkwasm-elastix)

A toolbox for rigid and nonrigid registration of images.

[🕮 **Documentation** 📚](https://py.docs.elastix.wasm.itk.eth.limo/)

## Installation

```sh
pip install itkwasm-elastix
```
