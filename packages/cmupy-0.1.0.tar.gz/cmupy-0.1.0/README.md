# cmupy

A Python package for computational mathematics utilities with CLI support.

## Installation

```bash
pip install cmupy