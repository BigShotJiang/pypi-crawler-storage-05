[](){#CopickMeshMeta}
::: copick.models.CopickMeshMeta
    options:
        show_if_no_docstring: true
