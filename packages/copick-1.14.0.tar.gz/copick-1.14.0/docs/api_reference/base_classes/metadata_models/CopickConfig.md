[](){#CopickConfig}
::: copick.models.CopickConfig
    options:
        show_if_no_docstring: true
