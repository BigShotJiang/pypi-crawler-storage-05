[](){#PickableObject}
::: copick.models.PickableObject
    options:
        show_if_no_docstring: true
