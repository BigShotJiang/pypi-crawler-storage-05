[](){#CopickVoxelSpacingMeta}
::: copick.models.CopickVoxelSpacingMeta
    options:
        show_if_no_docstring: true
