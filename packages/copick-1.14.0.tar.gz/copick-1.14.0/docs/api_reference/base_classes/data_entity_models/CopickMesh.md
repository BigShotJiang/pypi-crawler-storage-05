 [](){#CopickMesh}
::: copick.models.CopickMesh
