"""Bitmap manipulation and operations."""

from bitmapy.bitmap import Bitmap

__all__ = ["Bitmap"]
