from cmdfuncs.core import *
from cmdfuncs.tests import *

if __name__ == "__main__":
    main()
