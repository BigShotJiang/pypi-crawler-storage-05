# This line of code will allow shorter imports
from fedartml.fl_interactive_plots import InteractivePlots
from fedartml.fl_split_as_federated_data import SplitAsFederatedData
