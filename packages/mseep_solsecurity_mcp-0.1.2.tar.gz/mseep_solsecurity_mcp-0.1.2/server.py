from mcp.server.fastmcp import FastMCP

# Initialize the MCP server
mcp = FastMCP("solsecurity_server")