# LlamaIndex Multi-Modal-Llms Integration: Azure Openai
