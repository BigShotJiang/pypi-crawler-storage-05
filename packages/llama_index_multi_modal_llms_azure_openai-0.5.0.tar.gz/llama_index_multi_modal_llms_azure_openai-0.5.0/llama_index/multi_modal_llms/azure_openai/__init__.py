from llama_index.multi_modal_llms.azure_openai.base import AzureOpenAIMultiModal

__all__ = ["AzureOpenAIMultiModal"]
