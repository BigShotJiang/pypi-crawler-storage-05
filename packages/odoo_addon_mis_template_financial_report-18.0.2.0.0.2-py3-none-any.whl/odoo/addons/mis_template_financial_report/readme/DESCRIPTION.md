This addon provides MIS builder templates to generate generic Profit &
Loss and Balance Sheet reports.
