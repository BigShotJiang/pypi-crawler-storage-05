ob_metaflow_stubs_version = "6.0.10.0"
