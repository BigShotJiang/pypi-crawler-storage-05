from .significant_edges import prune_edges

__all__ = ['prune_edges']