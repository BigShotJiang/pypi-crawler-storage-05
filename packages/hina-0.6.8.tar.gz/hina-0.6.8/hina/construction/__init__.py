from .network_construct import get_bipartite, get_tripartite

__all__ = ['get_bipartite', 'get_tripartite']