import logging

logger = logging.getLogger("exifdata")
