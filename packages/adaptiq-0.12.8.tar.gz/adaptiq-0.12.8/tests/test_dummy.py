def test_dummy():
    """A dummy test to verify the test setup works."""
    assert True
