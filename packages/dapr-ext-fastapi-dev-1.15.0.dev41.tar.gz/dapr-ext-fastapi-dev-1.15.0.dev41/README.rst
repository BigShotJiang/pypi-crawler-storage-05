dapr-ext-fastapi extension
==========================

|pypi|

.. |pypi| image:: https://badge.fury.io/py/dapr-ext-fastapi.svg
   :target: https://pypi.org/project/dapr-ext-fastapi/

This FastAPI extension is used for FastAPI http server.

Installation
------------

::

    pip install dapr-ext-fastapi

References
----------

* `Dapr <https://github.com/dapr/dapr>`_
* `Dapr Python-SDK <https://github.com/dapr/python-sdk>`_
