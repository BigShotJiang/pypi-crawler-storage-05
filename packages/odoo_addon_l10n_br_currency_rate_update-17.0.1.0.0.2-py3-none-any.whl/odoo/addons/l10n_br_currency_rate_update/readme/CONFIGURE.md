Para ativar o agendador para atualizar as cotações de moedas:

\# Vá em *Faturamento \> Configuração \> Configurações* \# Verifique se
a opção *Automatic Currency Rates (OCA)* esta selecionada

Para configurar os provedores de cotações de moedas:

\# Vá em *Faturamento \> Configuração \> Currency Rates Providers* \#
Crie e configure o provedor BCB (Banco Central do Brasil) \# Selecione
as moedas que deseja atualizar as cotações
