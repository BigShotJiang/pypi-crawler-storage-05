# green

## Module: {mod}`zmq.green`

```{eval-rst}
.. automodule:: zmq.green
```
