% AUTO-GENERATED FILE -- DO NOT EDIT!

# utils.jsonapi

## Module: {mod}`zmq.utils.jsonapi`

```{eval-rst}
.. automodule:: zmq.utils.jsonapi
```

```{currentmodule} zmq.utils.jsonapi
```

## Functions

```{eval-rst}
.. autofunction:: zmq.utils.jsonapi.dumps

```

```{eval-rst}
.. autofunction:: zmq.utils.jsonapi.loads
```
