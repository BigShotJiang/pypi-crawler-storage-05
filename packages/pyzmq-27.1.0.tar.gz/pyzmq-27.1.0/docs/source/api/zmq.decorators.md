# decorators

## Module: {mod}`zmq.decorators`

```{eval-rst}
.. automodule:: zmq.decorators
```

```{currentmodule} zmq.decorators
```

## Decorators

```{eval-rst}
.. autofunction:: zmq.decorators.context
```

```{eval-rst}
.. autofunction:: zmq.decorators.socket
```
