# eventloop.ioloop

## Module: {mod}`zmq.eventloop.ioloop`

```{currentmodule} zmq.eventloop.ioloop
```

```{eval-rst}
.. module:: zmq.eventloop.ioloop

```

This module is deprecated in pyzmq 17.
Use {py:mod}`tornado.ioloop`.
