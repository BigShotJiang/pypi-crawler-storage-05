% AUTO-GENERATED FILE -- DO NOT EDIT!

# eventloop.zmqstream

## Module: {mod}`zmq.eventloop.zmqstream`

```{eval-rst}
.. automodule:: zmq.eventloop.zmqstream
```

```{currentmodule} zmq.eventloop.zmqstream
```

## {class}`ZMQStream`

```{eval-rst}
.. autoclass:: ZMQStream
  :members:
  :undoc-members:
  :inherited-members:
```
