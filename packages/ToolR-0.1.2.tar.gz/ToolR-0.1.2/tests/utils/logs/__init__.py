"""Tests for logging utilities."""
