"""Tests for signature parsing utilities."""
