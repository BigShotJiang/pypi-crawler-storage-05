"""Classes which handle hardware communication and control"""
