=========
Licensing
=========

.. include:: ../LICENSE.rst
