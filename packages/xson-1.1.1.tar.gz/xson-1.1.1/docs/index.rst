====
XSON
====
*XML Encoding for JSON*

.. include:: ../README.rst
   :start-after: .. start included documentation
   :end-before: .. end included documentation


.. toctree::
   :caption: API Reference
   :maxdepth: 1

   xson


.. toctree::
   :caption: Miscellaneous
   :maxdepth: 1

   relnotes
   license
