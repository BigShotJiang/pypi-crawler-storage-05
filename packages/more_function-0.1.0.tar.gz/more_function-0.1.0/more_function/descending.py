def sort_desc(arr):
    """
    Sắp xếp 1 mảng giảm dần
    """
    return sorted(arr, reverse=True)