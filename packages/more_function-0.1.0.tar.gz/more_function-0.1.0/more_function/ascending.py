def sort_asc(arr):
    """
    Sắp xếp 1 mảng tăng dần
    """
    return sorted(arr)
