from .quadratic import solve_quadratic
from .ascending import sort_asc
from .descending import sort_desc
__all__ = ["quadratic", "descending", "ascending"]