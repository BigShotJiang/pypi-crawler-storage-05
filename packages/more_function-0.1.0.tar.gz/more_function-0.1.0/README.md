# Thư viện: more_function

1 thư viện nhỏ python có các hàm:

- `slove_quadratic(a, b, c)` : giải phương trình bậc 2 với các tham số a,b,c
- `sort_asc(arr)` : sắp xếp mảng theo chiều tăng dần
- `sort_desc(arr)` : sắp xếp mảng theo chiều giảm dần

## Tải và cài đặt
```bash
pip install more_function
