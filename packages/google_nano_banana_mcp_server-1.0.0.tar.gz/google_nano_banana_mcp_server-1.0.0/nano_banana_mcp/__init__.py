"""Nano Banana MCP Server - Gemini 图片生成和编辑服务器"""

__version__ = "1.0.0"
