# Module to interact with Keycloak access token and validation token
## Keycloak ported to confidential computing on [SCONE](https://scontain.com "SCONE")

### DO NOT USE IT IN PRODUCTION DIRECTLY!
proceed with caution and the best practices of software testing, troubleshooting, change management
