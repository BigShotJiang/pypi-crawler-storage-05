# functions for creating output files in the LangGraph framework.
# as per your needs, you can add more functions here to handle different types of output files.