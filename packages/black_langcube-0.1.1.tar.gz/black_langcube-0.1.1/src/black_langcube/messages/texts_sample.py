graph1_text1 = (
    "Zde je sada otázek:",
    
    "Here is a set questions:"
)

graph1_text2 = (
    "Po výběru...",
    
    "After selecting..."
)

graph2_text1 = (
    "Zde je seznam...",
    
    "Here is a list..."
)

graph2_text2 = (
    "Po výběru...",
    
    "After selecting..."
)

graph3_text1 = (
    "Přejete si vypracovat...",

    "Would you like to process..."
)

graph4_text_stop = (
    "Omlouváme se",

    "We apologize"
)

graph4_text_continue = (
    "Vypadá to, že...",

    "It seems that..."
)
graph5_text1 = (
    "Výsledky...",

    "The results..."
)

end_text1 = (
    "Proces byl ukončen",

    "The process was ended"
)