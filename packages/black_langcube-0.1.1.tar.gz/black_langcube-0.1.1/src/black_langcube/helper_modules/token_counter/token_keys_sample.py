graph1_token_keys = [
                        "foo",
                        "bar",
                        "baz"
                        "foo2",
                        "bar2",
                        "baz2"
                    ]

graph2_token_keys = [
                        "foo",
                        "bar",
                        "baz"
                    ]

graph3_token_keys = [
                        "translate_keywords_tokens"
                    ]

graph4_token_keys = [
                        "foo",
                        "bar",
                        "baz"
                    ]

graph5_token_keys = [
                        "foo",
                        "bar",
                        "baz"
                    ]