"""Cognitive system utilities and services."""
