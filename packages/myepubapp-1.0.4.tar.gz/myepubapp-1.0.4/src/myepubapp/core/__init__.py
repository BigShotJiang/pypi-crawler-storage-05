

"""
Core package containing the fundamental classes for EPUB generation.
"""


