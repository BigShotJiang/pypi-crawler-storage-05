rootProject.name = "SdkV2DisableCertificateValidation"
