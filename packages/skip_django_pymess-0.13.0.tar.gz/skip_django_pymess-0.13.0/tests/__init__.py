"""
Test package for django-pymess.
""" 