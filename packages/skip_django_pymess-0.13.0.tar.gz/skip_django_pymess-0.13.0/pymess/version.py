VERSION = (0, 13, 0)


def get_version():
    return '.'.join(map(str, VERSION))
