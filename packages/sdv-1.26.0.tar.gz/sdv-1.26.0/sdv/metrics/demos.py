"""Demos to try SDV Metrics.

This subpackage exists only to enable importing the sdmetrics demos as part of sdv.
"""

from sdmetrics.demos import *  # noqa
