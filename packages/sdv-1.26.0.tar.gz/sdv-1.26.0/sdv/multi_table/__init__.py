"""Synthesizers for Multi Table data."""

from sdv.multi_table.hma import HMASynthesizer

__all__ = ('HMASynthesizer',)
