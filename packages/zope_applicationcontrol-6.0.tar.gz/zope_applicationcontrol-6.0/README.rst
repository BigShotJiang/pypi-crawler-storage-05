``zope.applicationcontrol``
===========================

.. image:: https://github.com/zopefoundation/zope.applicationcontrol/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.applicationcontrol/actions/workflows/tests.yml

The application control instance can be generated upon startup of an
application built with the Zope Toolkit.

This package provides an API to retrieve runtime information. It also
provides a utility with methods for shutting down and restarting the
server.
