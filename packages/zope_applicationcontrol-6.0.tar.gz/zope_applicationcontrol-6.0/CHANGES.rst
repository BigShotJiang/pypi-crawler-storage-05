=========
 Changes
=========

6.0 (2025-09-12)
================

- Replace ``pkg_resources`` namespace with PEP 420 native namespace.


5.1 (2025-02-13)
================

- Add support for Python 3.12, 3.13.

- Drop support for Python 3.7, 3.8.


5.0 (2023-07-06)
================

- Add support for Python 3.11.

- Drop support for Python 2.7, 3.5, 3.6.


4.3 (2022-06-24)
================

- Drop support for Python 3.4.

- Add support for Python 3.8, 3.9, 3.10.


4.2.0 (2018-10-19)
==================

- Drop support for ``setup.py test``.

- Drop support for Python 3.3.

- Add support for Python 3.7.


4.1.0 (2017-05-03)
==================

- Add support for Python 3.5 and 3.6.

- Drop support for Python 3.2 and 2.6.


4.0.1 (2015-06-05)
==================

- Add support for Python 3.2 and PyPy3.


4.0.0 (2014-12-24)
==================

- Add support for PyPy.  (PyPy3 is pending release of a fix for:
  https://bitbucket.org/pypy/pypy/issue/1946)

- Add support for Python 3.4.

- Add support for testing on Travis.


4.0.0a1 (2013-02-22)
====================

- Add support for Python 3.3.

- Replace deprecated ``zope.interface.implements`` usage with equivalent
  ``zope.interface.implementer`` decorator.

- Drop support for Python 2.4 and 2.5.


3.5.5 (2010-01-09)
==================

- Initial release, extracted from ``zope.app.applicationcontrol``.
