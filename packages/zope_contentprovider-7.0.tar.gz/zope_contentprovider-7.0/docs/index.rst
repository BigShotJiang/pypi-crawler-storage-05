.. include:: ../README.rst


Documentation:

.. toctree::
   :maxdepth: 2

   motivation
   narr
   tales
   api_provider
   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
