from classiq.interface.enum_utils import StrEnum


class Endianness(StrEnum):
    LITTLE = "LITTLE"
    BIG = "BIG"
