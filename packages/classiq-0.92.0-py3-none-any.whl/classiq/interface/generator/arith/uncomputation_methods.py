from classiq.interface.enum_utils import StrEnum


class UncomputationMethods(StrEnum):
    naive = "naive"
    optimized = "optimized"
