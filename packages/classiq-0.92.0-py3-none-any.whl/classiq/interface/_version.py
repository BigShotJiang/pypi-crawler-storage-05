from packaging.version import Version

# This file was generated automatically
# Please don't track in version control (DONTTRACK)

SEMVER_VERSION = '0.92.0'
VERSION = str(Version(SEMVER_VERSION))
