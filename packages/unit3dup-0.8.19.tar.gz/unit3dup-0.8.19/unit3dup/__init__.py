from common.settings import Load

config_settings = Load.load_config()


