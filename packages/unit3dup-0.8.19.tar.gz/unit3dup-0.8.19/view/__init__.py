from view.custom_console import CustomConsole

custom_console = CustomConsole()