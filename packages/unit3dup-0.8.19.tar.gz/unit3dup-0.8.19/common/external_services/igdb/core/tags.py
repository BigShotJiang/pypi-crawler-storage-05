# -*- coding: utf-8 -*-
crew_patterns = [
    "NOGRP", "LIGHTFORCE", "SUXXORS", "KAOS", "GOG", "TENOKE", "I_KNOW", "RAZOR1911", "RUNE", "FITGIRL",
    "ELAMIGOS", "RAZORDOX", "RAZOR", "SKIDROW", "DINOBYTES", "TINYISO", "FCKDRM", "FLT","SKIDROW",
    "CPY", "RELOADED", "HIVE", "VACE", "CZW", "PHOENIX", "JAGUAR", "CRIMSON", "TURBO", "DUPLEX", "CODEX"
]

platform_patterns = ["IOS", "LIN", "MACOS", "NINTENDO", "OCULUS", "PC", "PS4", "PS5", "PSN", "PSVR", "STEAM",
                     "STEAMVR", "XBX", "XONE", "NSW"]

additions = ["build", "complete", "definitive", "dlc", "edition", "episode", "pack", "patch", "remake", "remaster",
             "season", "update", "ultimate", "version"]

