# -*- coding: utf-8 -*-
from dataclasses import dataclass

@dataclass
class Keyword:
    id: int
    name: str
