from common.settings import Load

config = Load().load_config().tracker_config
