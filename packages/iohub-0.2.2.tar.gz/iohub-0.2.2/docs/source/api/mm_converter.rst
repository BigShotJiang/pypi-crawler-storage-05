Convert TIFF to OME-Zarr
========================


.. note:: There is also a CLI command for conversion.
   Consult ``iohub convert --help`` for documentation.


.. currentmodule:: iohub.convert


.. autoclass:: TIFFConverter
   :members:
   :special-members: __call__
