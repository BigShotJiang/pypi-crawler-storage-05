Read Clear Control
~~~~~~~~~~~~~~~~~~

.. currentmodule:: iohub.clearcontrol

.. autoclass:: ClearControlFOV
    :members:
    :special-members: __getitem__
    :inherited-members:
