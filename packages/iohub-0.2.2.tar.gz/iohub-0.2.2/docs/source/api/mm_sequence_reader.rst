Read MM TIFF sequence
=====================

.. currentmodule:: iohub._deprecated.singlepagetiff

.. autoclass:: MicromanagerSequenceReader
    :members:
    :inherited-members:
