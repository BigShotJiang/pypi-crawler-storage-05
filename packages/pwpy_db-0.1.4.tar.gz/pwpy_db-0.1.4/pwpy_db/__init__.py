from .trino_connector import fetch_trino_data

__all__ = ["fetch_trino_data"]
