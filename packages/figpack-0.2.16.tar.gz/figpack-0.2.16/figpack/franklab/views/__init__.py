"""
Franklab views for figpack
"""

from .TrackAnimation import TrackAnimation

__all__ = [
    "TrackAnimation",
]
