"""
Franklab views for figpack
"""

from . import views
