# Output Classes

These classes represent the final rendered product of a composition.

::: pictex.BitmapImage
::: pictex.VectorImage
