::: pictex.Column
    options:
      show_root_heading: false
