::: pictex.Row
    options:
      show_root_heading: false
