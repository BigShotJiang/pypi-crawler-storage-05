# -*- coding: utf-8 -*-
"""Main package for electric-emission-cost (EEC)."""

__author__ = "WE3Lab"
__email__ = "fchapin@stanford.edu"
# Do not edit this string manually, always use bumpversion
# Details in CONTRIBUTING.md
__version__ = "0.0.5"


def get_module_version():
    return __version__
