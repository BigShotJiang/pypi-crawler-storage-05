.. contents::

.. WARNING::

  Site under construction!    
  Documentation incomplete :( 

.. _tutorial-metrics:

**********************************
Flexibility Metrics as Constraints
**********************************