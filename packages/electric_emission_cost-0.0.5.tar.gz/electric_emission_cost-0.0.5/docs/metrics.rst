.. contents::

.. _metrics:

*******
metrics
*******

This module consists of code that computes virtual battery metrics associated with energy flexible operation. 

.. automodule:: electric_emission_cost.metrics
   :members: