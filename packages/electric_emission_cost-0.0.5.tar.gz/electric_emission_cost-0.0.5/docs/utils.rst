.. contents::

.. _utils:

*****
utils
*****

This module consists of helpful utility functions

.. automodule:: electric_emission_cost.utils
   :members: