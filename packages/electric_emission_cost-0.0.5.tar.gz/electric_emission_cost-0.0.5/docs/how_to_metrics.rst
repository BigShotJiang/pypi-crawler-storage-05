.. contents::

.. WARNING::

  Site under construction!    
  Documentation incomplete :( 

.. _how-to-metrics:

******************************
How to Use Flexibility Metrics
******************************

