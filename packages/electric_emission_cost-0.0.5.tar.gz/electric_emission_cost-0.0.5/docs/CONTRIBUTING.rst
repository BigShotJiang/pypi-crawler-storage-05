.. contents::

.. _CONTRIBUTING:

.. include:: ../CONTRIBUTING.rst