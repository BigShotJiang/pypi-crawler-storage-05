"""
Version information for JaaS API Python SDK
"""

__version__ = "0.1.7"
__version_info__ = (0, 1, 7)
