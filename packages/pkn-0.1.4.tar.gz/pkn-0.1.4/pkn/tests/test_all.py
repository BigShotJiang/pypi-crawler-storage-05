from pkn import *  # noqa


def test_all():
    assert True
