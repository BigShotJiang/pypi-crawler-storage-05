From any account journal entries view:

- Accounting/Journal Entries/Journal Items

select all the lines that corresponds to both AR/AP operations from the
same partner. Click on *Action \> Compensate*. If the items don't
correspond to the same partner or they aren't AR/AP accounts, you will
get an error.

On contrary, a dialog box will be presented with the result of the
operation and a selection of the journal to register the operation. When
you click on the *Compensate* button, a journal entry is created with
the corresponding counterparts of the AR/AP operations.
