This module allows to compensate the balance of a receivable account
with the balance of a payable account for the same partner, creating a
journal item that reflects this operation.

**WARNING**: This operation can be forbidden in your country by the
accounting regulations, so you should check current laws before using
it. For example, in Spain, this is not allowed at first instance, unless
you document well the operation from both parties.
