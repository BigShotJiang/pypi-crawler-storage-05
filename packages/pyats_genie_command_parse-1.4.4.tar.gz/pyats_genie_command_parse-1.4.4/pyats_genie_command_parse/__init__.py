"""
init for pyats_genie_command_parse
"""

from pyats_genie_command_parse.pyats_genie_command_parse import GenieCommandParse
