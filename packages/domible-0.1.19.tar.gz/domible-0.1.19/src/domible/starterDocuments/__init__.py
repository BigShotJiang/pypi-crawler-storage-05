""" domible/src/domible/starterDocuments/__init__.py """

from domible.starterDocuments.basicDocuments import basic_head_empty_body

# end of file
