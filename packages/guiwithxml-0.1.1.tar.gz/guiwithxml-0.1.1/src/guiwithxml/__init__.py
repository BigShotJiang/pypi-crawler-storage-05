# Kullanıcı "from pyrendergui import Renderer" yazdığında
# renderer.py dosyasındaki Renderer sınıfına erişebilsin.
from .renderer import Renderer