# Generated file. To retain edits, remove this comment.

from itkwasm_elastix_wasi import elastix

from .common import test_input_path, test_output_path

def test_elastix():
    pass
