# Generated file. To retain edits, remove this comment.

from itkwasm_elastix_wasi import transformix

from .common import test_input_path, test_output_path

def test_transformix():
    pass
