"""Main entry point for the code-index-mcp package."""

from code_index_mcp.server import main

if __name__ == "__main__":
    main()
