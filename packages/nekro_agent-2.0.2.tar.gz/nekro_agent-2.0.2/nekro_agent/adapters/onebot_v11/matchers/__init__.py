from nekro_agent.core.logger import logger

from . import command, message, notice

logger.success("Matchers loaded successfully")
