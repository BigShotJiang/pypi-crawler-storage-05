"""Logger used throughout osef project"""
import logging

osef_logger = logging.getLogger("osef")
osef_logger.propagate = False
