default_app_config = 'django_rehive_extras.apps.DjangoExtraConfig'
