from django.apps import AppConfig


class DjangoExtraConfig(AppConfig):
    name = 'django_rehive_extras'
    verbose_name = "Django Extras"
