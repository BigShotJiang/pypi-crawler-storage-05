Text API
========

.. autoxpmconfig:: datamaestro_text.data.text.TextFolder
.. autoxpmconfig:: datamaestro_text.data.text.TextFile
.. autoxpmconfig:: datamaestro_text.data.text.TrainingText
