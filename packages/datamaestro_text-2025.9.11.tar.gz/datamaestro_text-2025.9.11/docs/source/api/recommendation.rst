Recommendation
==============


.. autoxpmconfig:: datamaestro_text.data.recommendation.RatedItems
.. autoxpmconfig:: datamaestro_text.data.recommendation.Movielens
