Embeddings
==========

.. autoxpmconfig:: datamaestro_text.data.embeddings.WordEmbeddings

.. autoxpmconfig:: datamaestro_text.data.embeddings.WordEmbeddingsText
