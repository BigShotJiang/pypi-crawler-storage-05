Datamaestro Text API
====================

.. toctree::

    text
    ir
    conversation
    embeddings
    recommendation
    nlp
