Information Retrieval Datasets
==============================

MS Marco
--------

.. dm:datasets:: com.microsoft.msmarco.passage text


TREC Adhoc
----------

.. dm:datasets:: gov.nist.trec.adhoc text
