Recommendation datasets
=======================

IMDB
----

.. dm:datasets:: edu.stanford.aclimdb text
