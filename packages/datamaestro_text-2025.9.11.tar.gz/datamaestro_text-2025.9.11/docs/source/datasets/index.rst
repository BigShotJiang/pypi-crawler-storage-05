Datamaestro Text Datasets
=========================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   text
   ir
   recommendation
   embeddings
   conversation
