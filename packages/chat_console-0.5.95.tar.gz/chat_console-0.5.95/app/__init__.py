"""
Chat CLI
A command-line interface for chatting with various LLM providers like ChatGPT and Claude.
"""

__version__ = "0.5.95"
