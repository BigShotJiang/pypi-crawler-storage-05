"""Whodat."""

from whodat.whodat import Whodat

__all__ = ["Whodat"]
