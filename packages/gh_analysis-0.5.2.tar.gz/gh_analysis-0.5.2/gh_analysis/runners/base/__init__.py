"""Base runners for github-issue-analysis."""
