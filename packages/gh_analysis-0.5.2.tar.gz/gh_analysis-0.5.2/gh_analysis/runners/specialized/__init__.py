"""Specialized agents for extracting specific types of information from GitHub issues."""
