# Task: [Task Name]

**Status:** planning

**Description:**
[Brief description of what needs to be implemented]

**Acceptance Criteria:**
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Tests pass
- [ ] Code quality checks pass

**Agent Notes:**
[Document progress, decisions, validation steps, and any information needed for handoff]

**Validation:**
[Specific commands or steps to verify the implementation works]