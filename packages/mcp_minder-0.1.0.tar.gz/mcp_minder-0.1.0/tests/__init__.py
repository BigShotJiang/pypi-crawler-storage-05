"""
MCP Minder 测试包
"""
