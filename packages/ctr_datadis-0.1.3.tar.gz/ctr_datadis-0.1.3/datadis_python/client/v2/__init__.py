"""
Cliente Datadis API v2 - Respuestas tipadas con Pydantic
"""

from .client import DatadisClientV2

__all__ = ["DatadisClientV2"]
