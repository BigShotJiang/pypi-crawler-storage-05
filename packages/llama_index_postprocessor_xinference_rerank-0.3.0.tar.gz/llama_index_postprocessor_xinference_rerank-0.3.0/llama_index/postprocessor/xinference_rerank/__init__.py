from llama_index.postprocessor.xinference_rerank.base import XinferenceRerank

__all__ = ["XinferenceRerank"]
