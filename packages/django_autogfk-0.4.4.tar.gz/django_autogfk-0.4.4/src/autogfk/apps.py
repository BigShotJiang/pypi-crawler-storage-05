from django.apps import AppConfig

class AutoGenericForeignKeyConfig(AppConfig):
    name = "autogfk"
    verbose_name = "Auto Generic ForeignKey"
