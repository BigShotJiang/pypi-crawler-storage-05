from llama_index.llms.openvino_genai.base import OpenVINOGenAILLM


__all__ = ["OpenVINOGenAILLM"]
