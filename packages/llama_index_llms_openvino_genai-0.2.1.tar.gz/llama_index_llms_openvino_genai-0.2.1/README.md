# LlamaIndex Llms Integration: Openvino-genai

## LLM Implementation example

https://docs.llamaindex.ai/en/stable/examples/llm/openvino-genai/
