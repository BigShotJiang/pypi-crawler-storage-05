CONTACT_LINK = "https://github.com/easydiffusion/torchruntime"

AMD = "1002"
NVIDIA = "10de"
INTEL = "8086"
