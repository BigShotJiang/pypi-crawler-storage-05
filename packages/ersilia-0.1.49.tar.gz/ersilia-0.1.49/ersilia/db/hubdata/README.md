# Database with easy RESTFul access

This database is meant to provide a RESTFul API to users.

* NoSQL database. As of now, DynamoDB is our favourite option.
