input_shape_single_text = [
    "Binding affinity of aminoglycoside to 16S ribosomal RNA A-site in Escherichia coli",
    "Cytotoxic activity against human ovarian cancer (1A9) cell line",
]
