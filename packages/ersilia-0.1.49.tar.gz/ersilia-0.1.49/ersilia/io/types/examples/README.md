# Examples

This folder contains examples of input types.

* `compound.tsv` contains small molecules available from the Drug Repurposing Hub, downloaded 20 October 2020.
* `protein.tsv` contains those proteins in the reference human proteome available from UniProt that are available in ChEMBL, downloaded 20 October 2020.
