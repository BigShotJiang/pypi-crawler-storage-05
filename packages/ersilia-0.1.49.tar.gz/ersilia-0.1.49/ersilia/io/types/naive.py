# ruff: noqa: D101, D102


class IO(object):
    def __init__(self):
        pass

    def parse(self, text):
        data = {"key": text, "input": text, "text": text}
        return data
