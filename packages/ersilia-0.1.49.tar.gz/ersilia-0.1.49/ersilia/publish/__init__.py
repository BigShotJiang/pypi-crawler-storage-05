# Publish variables

EOS_TEMPLATE_REPOSITORY = "eos-template"
