# Inner template files

This folder contains files that are copy-pasted at fetch time, such as the `pack.py` and the `service.py` files.

These are the files that are recognized by BentoML.