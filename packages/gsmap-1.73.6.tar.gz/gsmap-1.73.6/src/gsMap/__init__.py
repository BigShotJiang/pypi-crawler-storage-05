"""
Genetically informed spatial mapping of cells for complex traits
"""

__version__ = "1.73.6"
