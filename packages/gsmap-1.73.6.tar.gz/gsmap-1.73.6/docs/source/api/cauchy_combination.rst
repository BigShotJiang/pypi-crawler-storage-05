Step 5: cauchy_combination (optional)
=====================================

.. argparse::
   :module: gsMap.main
   :func: create_parser
   :prog: gsmap
   :path: run_cauchy_combination
