format_sumstats (tips)
==================================

.. argparse::
   :module: gsMap.main
   :func: create_parser
   :prog: gsmap
   :path: format_sumstats
