Step 1: find_latent_representation
==================================

.. argparse::
   :module: gsMap.main
   :func: create_parser
   :prog: gsmap
   :path: run_find_latent_representations
