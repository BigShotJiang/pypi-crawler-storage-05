Step 2: latent_to_gene
======================

.. argparse::
   :module: gsMap.main
   :func: create_parser
   :prog: gsmap
   :path: run_latent_to_gene
