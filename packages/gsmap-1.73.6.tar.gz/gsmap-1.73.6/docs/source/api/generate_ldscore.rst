Step 3: generate_ldscore
========================

.. argparse::
   :module: gsMap.main
   :func: create_parser
   :prog: gsmap
   :path: run_generate_ldscore
