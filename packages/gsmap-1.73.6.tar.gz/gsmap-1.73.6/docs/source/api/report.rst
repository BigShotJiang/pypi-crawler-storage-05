Step 6: gsMap report (optional)
===============================

.. argparse::
   :module: gsMap.main
   :func: create_parser
   :prog: gsmap
   :path: run_report
