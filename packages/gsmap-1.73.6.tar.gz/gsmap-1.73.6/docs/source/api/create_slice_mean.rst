Create Slice Mean
====================

.. argparse::
   :module: gsMap.main
   :func: create_parser
   :prog: gsmap
   :path: create_slice_mean
