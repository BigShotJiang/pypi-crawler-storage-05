quick_mode (run entire pipeline)
==================================

.. argparse::
   :module: gsMap.main
   :func: create_parser
   :prog: gsmap
   :path: quick_mode
