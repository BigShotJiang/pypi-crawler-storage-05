Release notes
=============

v1.70
------

First public release
