from unicorn_eval.adaptors.segmentation.baseline_segmentation_upsampling_3d.v1.main import (
    SegmentationUpsampling,
    SegmentationUpsampling3D,
)

__all__ = [
    "SegmentationUpsampling",
    "SegmentationUpsampling3D",
]
