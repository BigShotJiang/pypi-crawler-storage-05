from importlib.metadata import version

# Note: If this line of code fails, run: poetry install
__version__ = version('bi-etl')
