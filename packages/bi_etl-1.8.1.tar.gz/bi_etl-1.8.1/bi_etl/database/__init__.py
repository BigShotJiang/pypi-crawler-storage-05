#  Make DatabaseMetadata available with a shorter less redundant name
from bi_etl.database.database_metadata import DatabaseMetadata
