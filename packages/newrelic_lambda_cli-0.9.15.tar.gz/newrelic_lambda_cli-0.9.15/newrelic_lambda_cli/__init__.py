# -*- coding: utf-8 -*-
# encoding: utf-8

import os

os.environ["PYTHONIOENCODING"] = "utf-8"
os.environ["PYTHONLEGACYWINDOWSFSENCODING"] = "utf-8"
