"""RAISE SDK Code quality checker"""

from .main import code_check as start

__all__ = [
    "start",
]