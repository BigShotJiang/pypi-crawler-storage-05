# yamltools4jedi
YAML tools to facilitate reading and editing JEDI super YAML files.    

Check this [guide](https://github.com/hifiyaml/yamltools4jedi/wiki/yamltools4jedi-guide) for more details

# Installation
```
pip install yamltools4jedi
```
