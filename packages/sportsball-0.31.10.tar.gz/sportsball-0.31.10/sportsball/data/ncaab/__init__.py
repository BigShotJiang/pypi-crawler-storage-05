"""The ncaab data sportsball module."""

# ruff: noqa: F401
from .combined.ncaab_combined_league_model import \
    NCAABCombinedLeagueModel as NCAABLeagueModel
