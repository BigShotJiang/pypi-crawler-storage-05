from .file_prompts import setup_prompts

__all__ = ["setup_prompts"]
