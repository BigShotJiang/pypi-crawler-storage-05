Test data was derived from EMD-8249
https://www.ebi.ac.uk/pdbe/entry/emdb/EMD-8249
