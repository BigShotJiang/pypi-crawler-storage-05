NONSESSION_APPLOGS = "nonsession-applogs"
SAILFISH_DEFAULT_GRAPHQL_ENDPOINT = "https://api-service.sailfishqa.com/graphql/"
SAILFISH_TRACING_HEADER = "X-Sf3-Rid"
