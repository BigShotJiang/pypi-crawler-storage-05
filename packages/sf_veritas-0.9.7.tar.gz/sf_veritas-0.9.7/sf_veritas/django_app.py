from django.apps import AppConfig


class SFVeritasConfig(AppConfig):
    name = "sf_veritas"
