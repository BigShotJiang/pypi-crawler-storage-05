import importlib.metadata

PACKAGE_LIBRARY_TYPE = "PYTHON"
PACKAGE_NAME = "sf-veritas"

__version__ = importlib.metadata.version(PACKAGE_NAME)
