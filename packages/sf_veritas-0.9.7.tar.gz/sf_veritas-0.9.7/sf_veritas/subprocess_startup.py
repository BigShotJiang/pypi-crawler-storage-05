from sf_veritas import setup_interceptors

setup_interceptors()  # Set up the interceptors immediately
