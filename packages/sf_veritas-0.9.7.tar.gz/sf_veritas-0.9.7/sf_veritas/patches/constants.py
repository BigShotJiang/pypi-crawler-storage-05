supported_network_verbs = ("get", "post", "put", "patch", "delete", "head", "options")
