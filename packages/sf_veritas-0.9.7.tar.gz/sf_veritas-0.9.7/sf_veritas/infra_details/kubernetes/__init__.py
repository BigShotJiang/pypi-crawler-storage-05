from .get_details import get_details

__all__ = ["get_details"]
