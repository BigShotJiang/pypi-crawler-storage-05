# FastAPI OIDC JWKS

A FastAPI dependency used to verify a user's OAuth access token with JWKS.
