from django.forms import TextInput


class SimpleDateWidget(TextInput):
    pass
