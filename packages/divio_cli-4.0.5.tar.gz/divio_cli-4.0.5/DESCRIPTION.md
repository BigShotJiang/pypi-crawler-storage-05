The Divio CLI is a tool for interacting with Divio projects and the Divio cloud infrastructure.
    
It provides commands to set up projects locally, push and pull media and database content to
remote cloud projects, get and set environment variables, and so on.

How to get started with the Divio CLI: https://docs.divio.com/en/latest/how-to/local-cli/
