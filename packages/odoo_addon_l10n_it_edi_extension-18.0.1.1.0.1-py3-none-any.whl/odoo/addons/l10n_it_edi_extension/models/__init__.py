#  License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import res_partner
from . import res_company
from . import res_city_it_code
from . import l10n_it_edi_article_code
from . import l10n_it_edi_discount_rise_price
from . import l10n_it_edi_line_other_data
from . import l10n_it_edi_activity_progress
from . import l10n_it_edi_summary_data
from . import l10n_it_edi_line
from . import account_move_line
from . import account_move
from . import ir_attachment
from . import account_journal
