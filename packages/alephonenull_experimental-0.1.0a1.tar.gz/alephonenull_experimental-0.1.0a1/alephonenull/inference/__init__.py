# Inference-level protection module
