# Core detection and safety systems
