# Utilities and helper functions
