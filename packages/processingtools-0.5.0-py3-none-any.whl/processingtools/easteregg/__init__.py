from processingtools.easteregg.this import *
