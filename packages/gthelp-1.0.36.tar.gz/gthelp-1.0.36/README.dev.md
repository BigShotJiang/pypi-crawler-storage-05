# build
rm -rf dist && python -m build

# publish
python -m twine upload dist/* --verbose


# token
pypi-AgEIcHlwaS5vcmcCJDc4Y2JkOWZjLWI5ZmYtNGYwNy1iZTBiLTliZjgxZjk0YmJmMQACDlsxLFsiZ3RoZWxwIl1dAAIsWzIsWyI5MDMxMTgwYS1lMWJkLTQ0NjctYWJkZC02YTllMzAzMjQxZjUiXV0AAAYgH1pDSvIeAj3a82qBfBOtEHMOu30i5RNL9KG-vTHNdoA