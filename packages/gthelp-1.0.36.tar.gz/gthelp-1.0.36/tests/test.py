from gthelp import gthelp

gthelp.exec_helper()
