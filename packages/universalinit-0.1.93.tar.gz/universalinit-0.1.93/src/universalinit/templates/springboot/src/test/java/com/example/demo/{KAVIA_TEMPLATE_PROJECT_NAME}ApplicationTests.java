package com.example.{KAVIA_TEMPLATE_PROJECT_NAME};

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class {KAVIA_TEMPLATE_PROJECT_NAME}ApplicationTests {

	@Test
	void contextLoads() {
	}

}
