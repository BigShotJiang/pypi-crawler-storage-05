from . import test_insurance_sticker
