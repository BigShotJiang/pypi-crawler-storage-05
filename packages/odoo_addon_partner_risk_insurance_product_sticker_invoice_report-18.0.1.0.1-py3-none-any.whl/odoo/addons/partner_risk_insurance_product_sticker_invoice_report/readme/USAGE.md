To use this module, you need to:

1. Set default Sticker Positions on Invoice Settings > Show Product Stickers.
2. Go to Product Stickers and create a new one with an Insured Company.
3. Set the insured company on your partner on the Risk Control section.
4. Define a Insured state with Insured invoices check.
4. Now all insured invoices will have your Insured Product Sticker.
