
This module was developed because sometimes you want to reflect on your Invoices that some Insured company are insuring the invoice.
