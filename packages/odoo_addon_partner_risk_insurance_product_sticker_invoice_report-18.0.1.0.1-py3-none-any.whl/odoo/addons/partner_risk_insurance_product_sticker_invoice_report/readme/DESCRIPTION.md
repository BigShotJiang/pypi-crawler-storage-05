This module extends the functionality of Risk Insurance to support display Insurance company logos and to allow you to reflect on your invoices that those operations are insured.
