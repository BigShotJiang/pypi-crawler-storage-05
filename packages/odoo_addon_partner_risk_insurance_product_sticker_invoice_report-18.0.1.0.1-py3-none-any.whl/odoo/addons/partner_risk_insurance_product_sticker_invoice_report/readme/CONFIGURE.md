To configure this module, you need to:

1. Set default Sticker Positions on Invoice Settings > Show Product Stickers.
2. Enable Sales Credit Limit option on Invoice Settings > Invoicing > Customer Invoices.
3. Go to Settings > Technical > Database Structure > Product Stickers
4. Create a new sticker for your company and select a Credit Company or Create a new one
5. Go to a partner and setup to this Credit Company with an Insurance State with Insure Invoices
5. Create an Out Invoice and select Product Sticker position on Other Info tab > Invoices.
7. Print invoice to see your Insured logo.
8. Repeat the same process with another Partner without Insured invoices to see that is not shown.
