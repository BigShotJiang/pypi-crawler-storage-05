# MyPackage
A simple Python package with math and string utilities.
