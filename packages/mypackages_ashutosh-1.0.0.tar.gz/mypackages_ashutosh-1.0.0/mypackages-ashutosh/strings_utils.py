def greet(name):
    return f"Hello, {name}!"

def uppercase(text):
    return text.upper()
