# __init__.py
# This makes Python treat "mypackage" as a package