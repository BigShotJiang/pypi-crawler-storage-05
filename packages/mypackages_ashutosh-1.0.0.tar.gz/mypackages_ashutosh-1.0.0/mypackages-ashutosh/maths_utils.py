def add(a, b):
    return a + b

def square(n):
    return n * n
