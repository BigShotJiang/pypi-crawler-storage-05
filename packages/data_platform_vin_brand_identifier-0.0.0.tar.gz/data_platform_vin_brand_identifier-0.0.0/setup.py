from setuptools import setup

setup(
    name="data_platform_vin_brand_identifier",
    version="0.0.0",
)
