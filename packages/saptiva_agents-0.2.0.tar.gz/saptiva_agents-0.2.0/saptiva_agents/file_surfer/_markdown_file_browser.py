from autogen_ext.agents.file_surfer._markdown_file_browser import MarkdownFileBrowser


class MarkdownFileBrowser(MarkdownFileBrowser):
    pass