from autogen_ext.agents.web_surfer import PlaywrightController, MultimodalWebSurfer


class MultimodalWebSurfer(MultimodalWebSurfer):
    pass


class PlaywrightController(PlaywrightController):
    pass
