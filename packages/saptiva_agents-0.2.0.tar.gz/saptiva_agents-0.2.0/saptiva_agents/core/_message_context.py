from autogen_core import MessageContext


class MessageContext(MessageContext):
    pass