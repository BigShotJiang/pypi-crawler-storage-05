from .defaults import DEFAULT_TRAINING_CONFIG

__all__ = ["DEFAULT_TRAINING_CONFIG"]
