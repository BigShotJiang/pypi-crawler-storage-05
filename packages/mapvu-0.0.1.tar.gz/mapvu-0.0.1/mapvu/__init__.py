"""Top-level package for mapvu."""

__author__ = """Atul Bhardwaj"""
__email__ = 'atulmncfc@gmail.com'
__version__ = '0.0.1'
