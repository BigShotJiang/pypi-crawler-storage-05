from enum import Enum


class SeverityType(Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
