from .Mixingpump import Mixingpump

class Duomix (Mixingpump):
    """
    Duomix

    OPC-UA client class for m-tec Duo-Mix 3DCP+ machines (Mixingpump).
    Inherits from Mixingpump.
    """
    pass