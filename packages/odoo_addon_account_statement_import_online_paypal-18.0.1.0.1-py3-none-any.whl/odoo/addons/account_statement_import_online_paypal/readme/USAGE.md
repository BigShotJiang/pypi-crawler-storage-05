To pull historical bank statements:

1.  Go to *Invoicing \> Configuration \> Accounting \> Journals*.
2.  Open the Journal corresponding to the PayPal bank account.
3.  Click the *Pull Online Bank Statement* button.
4.  Configure a date interval and click *Pull*.
