"""
Test suite for text processing commands
"""