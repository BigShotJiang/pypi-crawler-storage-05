"""
Text processing commands for virtual shell
"""
