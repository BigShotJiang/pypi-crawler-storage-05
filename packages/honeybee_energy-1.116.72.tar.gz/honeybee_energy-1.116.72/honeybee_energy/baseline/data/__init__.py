"""Data that is used by the baseline subpackage."""
