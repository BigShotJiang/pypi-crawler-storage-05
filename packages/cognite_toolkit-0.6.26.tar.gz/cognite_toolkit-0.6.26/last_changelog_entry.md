## cdf 

### Added

- [alpha] Added a search configuration resource loader
SearchConfigLoader.

## templates

No changes.