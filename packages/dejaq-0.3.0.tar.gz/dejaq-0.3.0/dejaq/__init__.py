"""
.. include:: ../README.md
"""
__docformat__ = 'google'

from .queues import DejaQueue
from .parallel import Parallel