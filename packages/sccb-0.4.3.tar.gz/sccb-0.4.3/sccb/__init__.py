"""
SCCB - Shortcut Clipboard + Command Binder

A customizable CLI tool for managing command shortcuts and clipboard snippets.
"""

__version__ = "0.4.3"
__author__ = "Ajinkya Dhamdhere"
__email__ = "aj.dhamdhere@gmail.com"
