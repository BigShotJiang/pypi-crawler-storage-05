"""
GS1Grader core package
"""

__version__ = "1.0.1"
