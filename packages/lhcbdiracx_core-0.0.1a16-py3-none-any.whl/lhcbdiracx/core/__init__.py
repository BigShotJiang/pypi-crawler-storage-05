__all__ = ("config", "properties")
