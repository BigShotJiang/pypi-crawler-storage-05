"""Core utilities for parsing and processing align-system data."""

__version__ = "1.0.0"
