from mplabml.model_runner import ModelRunner


class SMLRunner(ModelRunner):
    """This class is deprecated in favor of model_runner"""

    pass
