class BaseRenderer(object):
    def render(self, value, end="\n"):
        print(value, end=end)
