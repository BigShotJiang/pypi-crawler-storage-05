# -- coding: utf-8 --
# Project: fiuaiclient
# Created Date: 2025 08 We
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI


class FiuaiGeneralError(Exception):
    pass


class FiuaiAuthError(Exception):
    pass

