from . import calc

class Norm:
    def __init__(self, name):
        self.name = name
    def sayHello(self):
        return "Hello " + self.name
