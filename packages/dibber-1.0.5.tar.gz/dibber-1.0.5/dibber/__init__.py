from dibber.main import cli

__all__ = ["cli"]
