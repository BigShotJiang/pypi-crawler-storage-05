"""Entry point for running litime_ble as a module."""

from .cli import main

if __name__ == "__main__":
    main()
