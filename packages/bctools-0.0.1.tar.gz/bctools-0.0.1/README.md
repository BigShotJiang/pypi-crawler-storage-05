# bctools

This is the documentation for the barcodes tools package.