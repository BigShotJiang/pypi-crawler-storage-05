# Everything is created by the DB object upon instantiation if it does not exists.
USE FTS3DB;
