"""
   DIRAC.DataManagementSystem.Client package
"""

#: Maximum number of characters for a filename, this should be the same as the FileName column of the DFC
MAX_FILENAME_LENGTH = 128
