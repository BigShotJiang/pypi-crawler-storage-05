"""
   DIRAC.Core.ClassAd package
"""
