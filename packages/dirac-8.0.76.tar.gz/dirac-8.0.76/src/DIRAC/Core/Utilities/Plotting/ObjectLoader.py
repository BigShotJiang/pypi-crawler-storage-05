"""
It is used to load classes from a specific system.
"""
from DIRAC.Core.Utilities.ObjectLoader import loadObjects
