Main contributors to the source code
------------------------------------
- Andrei Tsaregorodtsev <atsareg@in2p3.fr>
- Federico Stagni <federico.stagni@cern.ch>
- Christophe Haen <christophe.denis.haen@cern.ch>
- Chris Burr <chris.burr@cern.ch>
- Alexandre Boyer <Alexandre.frank.boyer@cern.ch>
- Philippe Charpentier <philippe.charpentier@cern.ch>
- Andre Sailer <andre.philippe.sailer@cern.ch>
- Simon Fayer <simon.fayer05@imperial.ac.uk>

DIRAC consortium members
------------------------
- CNRS - Centre National de la Recherche Scientifique (France)
- CERN - European Organisation for Nuclear Research (Switzerland)
- IHEP (China)
- UM (Montpellier, France)
- KEK (Japan)
- Imperial College (UK)
