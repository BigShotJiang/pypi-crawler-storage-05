# Axory SDK

Python SDK for AxoryAI's deepfake detection API.

## Installation

```bash
pip install axory
