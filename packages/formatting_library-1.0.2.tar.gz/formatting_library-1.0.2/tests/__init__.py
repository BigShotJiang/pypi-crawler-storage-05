"""
Tests for terminal_formatter package.

This package contains unit tests for all components of the terminal_formatter library.
"""