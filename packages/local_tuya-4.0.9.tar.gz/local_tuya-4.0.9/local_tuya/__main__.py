import asyncio

from local_tuya.manager import run

asyncio.run(run())
