"""
Word文档表格编辑MCP服务

提供Word文档表格编辑功能的MCP服务器
"""

__version__ = "1.0.0"
__author__ = "Word MCP Services"
__description__ = "Word文档表格编辑MCP服务 - 提供文档表格编辑相关功能"
