""" conananas model """
