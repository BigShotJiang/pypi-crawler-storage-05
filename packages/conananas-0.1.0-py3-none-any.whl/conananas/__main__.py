""" conananas main """
from conananas.application import start_application


if __name__ == "__main__":
    start_application()
