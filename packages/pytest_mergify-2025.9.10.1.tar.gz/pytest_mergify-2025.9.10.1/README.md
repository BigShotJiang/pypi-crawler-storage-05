# pytest-mergify

A **pytest** plugin that integrates seamlessly with **Mergify**, enabling
tracing of test executions.

More information at https://mergify.com
