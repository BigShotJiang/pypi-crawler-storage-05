(sec_citation)=

# Citing tscompare

If you use `tscompare` in your work, please cite the
[2025 bioRxiv paper](<https://www.biorxiv.org/content/10.1101/2024.11.30.626138v4>):

>  Halley Fritze, Nathaniel Pope, Jerome Kelleher, and Peter Ralph (2025),
> *A forest is more than its trees: haplotypes and ARGs*,
> bioRxiv 2024.11.30.626138v4. https://www.biorxiv.org/content/10.1101/2024.11.30.626138v4


