# tscompare

Utilities for comparing ARGs in tree sequence format;
at present this only contains tools described in;
[Fritze et al, "A forest is more than its trees: haplotypes and ancestral recombination graphs"](https://doi.org/10.1101/2024.11.30.626138);
in the future this might have more methods.


