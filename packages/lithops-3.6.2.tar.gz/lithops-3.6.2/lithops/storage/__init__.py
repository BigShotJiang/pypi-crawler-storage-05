from .storage import InternalStorage
from .storage import Storage

__all__ = [
    'InternalStorage',
    'Storage'
]
