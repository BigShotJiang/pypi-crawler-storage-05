from .oracle_oss import OCIObjectStorageBackend as StorageBackend

__all__ = ['StorageBackend']
