from .infinispan_hotrod import InfinispanHotrodBackend as StorageBackend

__all__ = ['StorageBackend']
