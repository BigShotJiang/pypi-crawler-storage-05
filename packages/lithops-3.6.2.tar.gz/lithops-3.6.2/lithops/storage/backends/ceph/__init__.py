from .ceph import CephStorageBackend as StorageBackend

__all__ = ['StorageBackend']
