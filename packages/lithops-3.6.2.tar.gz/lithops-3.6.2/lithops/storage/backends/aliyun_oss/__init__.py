from .aliyun_oss import AliyunObjectStorageServiceBackend as StorageBackend

__all__ = ['StorageBackend']
