from .openwhisk import OpenWhiskBackend as ServerlessBackend

__all__ = ['ServerlessBackend']
