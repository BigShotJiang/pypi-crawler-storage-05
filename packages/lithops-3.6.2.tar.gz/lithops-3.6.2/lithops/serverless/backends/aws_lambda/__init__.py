from .aws_lambda import AWSLambdaBackend as ServerlessBackend

__all__ = ['ServerlessBackend']
