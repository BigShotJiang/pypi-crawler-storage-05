"""Feature discovery utilities (SAE/RepE-lite)."""

from .sae import discover_features  # noqa: F401
