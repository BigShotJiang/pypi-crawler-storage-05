"""Simple static studio (no external deps)."""

from .server import launch_studio  # noqa: F401
