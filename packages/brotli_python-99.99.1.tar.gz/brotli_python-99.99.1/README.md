only for rnd
