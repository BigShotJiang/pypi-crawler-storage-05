import os

DEFAULT_DATA_PATH = os.path.dirname(__file__)
