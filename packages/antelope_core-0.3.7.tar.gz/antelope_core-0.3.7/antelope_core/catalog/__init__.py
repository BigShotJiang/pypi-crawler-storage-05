from .catalog import StaticCatalog
from .lc_catalog import LcCatalog

