from typing import TypeAlias

ColumnName: TypeAlias = str
PythonType: TypeAlias = str
RuleName: TypeAlias = str
