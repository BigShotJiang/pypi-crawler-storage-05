class PythonTypes:
    STRING = "string"
    INTEGER = "integer"
    DOUBLE = "float"
    FLOAT = "float"
    DECIMAL = "float"
    DATE = "date"
    TIMESTAMP = "timestamp"
    BOOLEAN = "boolean"
