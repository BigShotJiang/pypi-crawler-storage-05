SNOWFLAKE_CONN_PARAMS = {
        "credentials": {
        "account": "XYUWMIA-DL07627",
        "user": "RAMOSLENAMOS",
        "password": "Absolut4p6laa-"
    }
}

BIGQUERY_CONN_PARAMS = {
        "connection_string": "bigquery://test-calista/RH",
        "credentials_path": "bigquery_private_key.json",
}