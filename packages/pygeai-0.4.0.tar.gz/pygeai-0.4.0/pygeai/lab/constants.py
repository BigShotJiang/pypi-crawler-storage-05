VALID_SCOPES = ["builtin", "external", "api", "proxied"]
VALID_ACCESS_SCOPES = ["public", "private"]
VALID_REPORT_EVENTS = ["None", "All", "Start", "Finish", "Progress"]
