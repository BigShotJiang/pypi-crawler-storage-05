LIST_REASONING_STRATEGIES_V2 = "v2/reasoning-strategies"  # GET -> List reasoning strategies
CREATE_REASONING_STRATEGY_V2 = "v2/reasoning-strategies"  # POST -> Create reasoning strategies
UPDATE_REASONING_STRATEGY_V2 = "v2/reasoning-strategies/{reasoningStrategyId}"  # PUT -> Update reasoning strategies
UPSERT_REASONING_STRATEGY_V2 = "v2/reasoning-strategies/{reasoningStrategyId}/upsert"  # PUT -> Update reasoning strategies
GET_REASONING_STRATEGY_V2 = "v2/reasoning-strategies/{reasoningStrategyId}"  # GET -> Get reasoning strategies
