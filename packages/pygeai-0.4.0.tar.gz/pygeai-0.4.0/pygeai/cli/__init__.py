"""
GEAI - ClI
----------
Command line interface to interact with Globant Enterprise AI.
"""

__version__ = '0.4.0'

