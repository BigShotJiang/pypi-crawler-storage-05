__all__ = ["get_name"]

from .name import get_name
