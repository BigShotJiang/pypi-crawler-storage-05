from typing import TypeAlias

Component: TypeAlias = str

DEFAULT_COMPONENT = ""
