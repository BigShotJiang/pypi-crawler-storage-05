# LlamaIndex Embeddings Integration: Huggingface Optimum
