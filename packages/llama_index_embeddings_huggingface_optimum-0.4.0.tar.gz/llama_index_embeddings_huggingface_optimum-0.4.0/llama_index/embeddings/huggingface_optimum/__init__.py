from llama_index.embeddings.huggingface_optimum.base import OptimumEmbedding

__all__ = ["OptimumEmbedding"]
