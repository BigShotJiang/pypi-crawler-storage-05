from script import Script


class TestPruneLogs(Script):
    script_name = 'teuthology-prune-logs'
