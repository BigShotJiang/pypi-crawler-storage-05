from script import Script


class TestSuite(Script):
    script_name = 'teuthology-suite'
