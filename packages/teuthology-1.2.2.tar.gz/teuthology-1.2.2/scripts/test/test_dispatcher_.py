from script import Script


class TestDispatcher(Script):
    script_name = 'teuthology-dispatcher'
