from script import Script


class TestSchedule(Script):
    script_name = 'teuthology-schedule'
