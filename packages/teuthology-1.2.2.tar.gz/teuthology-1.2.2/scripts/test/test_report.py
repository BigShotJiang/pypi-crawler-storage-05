from script import Script


class TestReport(Script):
    script_name = 'teuthology-report'
