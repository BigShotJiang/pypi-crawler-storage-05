from script import Script


class TestResults(Script):
    script_name = 'teuthology-results'
