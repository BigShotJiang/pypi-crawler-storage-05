from script import Script


class TestLock(Script):
    script_name = 'teuthology-lock'
