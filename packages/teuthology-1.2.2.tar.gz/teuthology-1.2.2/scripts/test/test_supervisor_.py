from script import Script


class TestSupervisor(Script):
    script_name = 'teuthology-supervisor'
