from script import Script


class TestExporter(Script):
    script_name = 'teuthology-exporter'
