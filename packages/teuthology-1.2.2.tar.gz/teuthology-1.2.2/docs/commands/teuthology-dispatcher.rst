teuthology-dispatcher
=====================

.. program-output:: teuthology-dispatcher --help

trouble-shooting notes:
=======================

- Github unreachable kills dispatcher - The dispatcher might be killed when github becomes unreachable, e.g., https://tracker.ceph.com/issues/54366