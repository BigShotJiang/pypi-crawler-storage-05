teuthology-prune-logs
=====================

.. program-output:: teuthology-prune-logs --help
