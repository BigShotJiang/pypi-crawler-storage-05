teuthology-describe
===================

.. program-output:: teuthology-describe --help
