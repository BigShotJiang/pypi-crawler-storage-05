"""
Null task
"""
def task(ctx, config):
    """
    This task does nothing.

    For example::

        tasks:
        - nop:
    """
    pass
