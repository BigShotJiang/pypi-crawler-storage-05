===================================================
`Teuthology` -- The Ceph integration test framework
===================================================


Welcome! Teuthology's documentation is primarily hosted at `docs.ceph.com
<https://docs.ceph.com/projects/teuthology/>`__.

You can also look at docs `inside this repository <docs/>`__, but note that
GitHub's `RST <http://docutils.sourceforge.net/rst.html>`__ rendering is quite
limited. Mainly that means that links between documents will be broken.
