from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.app_error import AppError
from ...models.remote_cluster_info import RemoteClusterInfo
from ...types import Response


def _get_kwargs(
    remote_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": f"/api/v4/sharedchannels/remote_info/{remote_id}",
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[AppError, RemoteClusterInfo]]:
    if response.status_code == 200:
        response_200 = RemoteClusterInfo.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = AppError.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = AppError.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = AppError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = AppError.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[AppError, RemoteClusterInfo]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    remote_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[Union[AppError, RemoteClusterInfo]]:
    """Get remote cluster info by ID for user.

     Get remote cluster info based on remoteId.

    __Minimum server version__: 5.50

    ##### Permissions
    Must be authenticated and user must belong to at least one channel shared with the remote cluster.

    Args:
        remote_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[AppError, RemoteClusterInfo]]
    """

    kwargs = _get_kwargs(
        remote_id=remote_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    remote_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[Union[AppError, RemoteClusterInfo]]:
    """Get remote cluster info by ID for user.

     Get remote cluster info based on remoteId.

    __Minimum server version__: 5.50

    ##### Permissions
    Must be authenticated and user must belong to at least one channel shared with the remote cluster.

    Args:
        remote_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[AppError, RemoteClusterInfo]
    """

    return sync_detailed(
        remote_id=remote_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    remote_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[Union[AppError, RemoteClusterInfo]]:
    """Get remote cluster info by ID for user.

     Get remote cluster info based on remoteId.

    __Minimum server version__: 5.50

    ##### Permissions
    Must be authenticated and user must belong to at least one channel shared with the remote cluster.

    Args:
        remote_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[AppError, RemoteClusterInfo]]
    """

    kwargs = _get_kwargs(
        remote_id=remote_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    remote_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[Union[AppError, RemoteClusterInfo]]:
    """Get remote cluster info by ID for user.

     Get remote cluster info based on remoteId.

    __Minimum server version__: 5.50

    ##### Permissions
    Must be authenticated and user must belong to at least one channel shared with the remote cluster.

    Args:
        remote_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[AppError, RemoteClusterInfo]
    """

    return (
        await asyncio_detailed(
            remote_id=remote_id,
            client=client,
        )
    ).parsed
