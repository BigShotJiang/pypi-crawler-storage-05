# Documentation

The `greeter` component is responsible for providing a friendly greeting message.
Depending on the selected language, the greeting message may be translated accordingly.

For English:

```c
printf("Hello, World!\n");
```
