#include <stdio.h>
#include "greeter.h"

int main(int argc, char *argv[])
{
    printf("%s\n", get_greeting());
    return 0;
}
