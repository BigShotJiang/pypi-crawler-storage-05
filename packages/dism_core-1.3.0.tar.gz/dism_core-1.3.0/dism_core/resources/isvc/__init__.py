from .resource import InferenceServiceResource


__all__ = [
    "InferenceServiceResource",
]
