from .base import MLServerProperties


class LightGBMProperties(MLServerProperties): ...
