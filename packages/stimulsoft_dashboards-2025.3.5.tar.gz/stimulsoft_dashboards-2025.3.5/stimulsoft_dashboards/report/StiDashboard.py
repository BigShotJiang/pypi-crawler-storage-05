from stimulsoft_reports.report.StiReport import StiReport

class StiDashboard(StiReport):

### Constructor

    def __init__(self):
        super().__init__()
