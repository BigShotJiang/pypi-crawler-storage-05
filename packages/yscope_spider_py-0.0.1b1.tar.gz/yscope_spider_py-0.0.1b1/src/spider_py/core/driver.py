"""Spider core Driver module."""

from uuid import UUID

DriverId = UUID
