"""Unit tests for client module."""
