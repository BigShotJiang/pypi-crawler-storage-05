from setuptools import setup, find_packages

setup(
    name="roblox_messaging_place",
    version="0.1.0",
    description="A Python client for Roblox MessagingService scoped to a specific Place.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Catergems",
    author_email="supornthanaphat@gmail.com",
    url="https://github.com/supornthanaphat-web/messagingblox",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "requests>=2.28.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Games/Entertainment",
        "Topic :: Software Development :: Libraries",
    ]
)
