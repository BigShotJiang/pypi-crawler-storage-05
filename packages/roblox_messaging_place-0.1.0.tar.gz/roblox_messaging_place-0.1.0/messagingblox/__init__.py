"""
roblox_messaging_place
----------------------
A Python client for Roblox MessagingService scoped to a specific Place.
"""

from .messaging import MessagingClient

__all__ = ["MessagingClient"]
__version__ = "0.1.0"
