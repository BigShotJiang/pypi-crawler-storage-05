import requests
import json
from threading import Thread
from flask import Flask, request, jsonify

class MessagingClient:
    def __init__(self, api_key: str, universe_id: str, place_id: str):
        """
        Roblox MessagingService client for a specific place.

        :param api_key: Roblox Open Cloud API key
        :param universe_id: Roblox Universe ID
        :param place_id: Roblox Place ID (to scope topics)
        """
        self.api_key = api_key
        self.universe_id = universe_id
        self.place_id = place_id
        self.base_url = f"https://apis.roblox.com/messaging-service/v1/universes/{universe_id}/topics"

    def publish(self, topic: str, message: dict | str):
        """Publish a message scoped to this place."""
        if isinstance(message, dict):
            message = json.dumps(message)

        topic = f"place_{self.place_id}:{topic}"
        url = f"{self.base_url}/{topic}"
        headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json"
        }
        payload = {"message": message}

        resp = requests.post(url, headers=headers, json=payload)
        if resp.status_code == 200:
            return True
        else:
            raise Exception(f"Failed to publish: {resp.status_code} - {resp.text}")

    def subscribe(self, host="0.0.0.0", port=5000, callback=None):
        """
        Start a Flask server to receive messages from Roblox.

        :param host: Host for Flask server
        :param port: Port for Flask server
        :param callback: Function to call on each message
        """
        app = Flask(__name__)

        @app.route("/webhook", methods=["POST"])
        def webhook():
            data = request.json
            if callback:
                callback(data)
            return jsonify({"status": "ok"})

        # Run Flask in a separate thread so it doesn’t block
        Thread(target=lambda: app.run(host=host, port=port, debug=False, use_reloader=False)).start()
