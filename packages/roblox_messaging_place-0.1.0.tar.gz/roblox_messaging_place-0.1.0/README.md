# messagingblox
Published or subscribed using py

---

## Features
- Publish messages to a specific Roblox place.
- Subscribe to messages via Python Flask webhook.
- Easy place-scoped topic naming.

---

## Installation

```bash
pip install messagingblox
```
