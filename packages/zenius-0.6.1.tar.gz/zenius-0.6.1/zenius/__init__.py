"""API for zenius simfile downloads"""

__version__ = "0.1"
