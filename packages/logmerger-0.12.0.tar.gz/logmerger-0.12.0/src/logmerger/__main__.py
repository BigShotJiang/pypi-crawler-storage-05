from logmerger.logmerger import main

main()
