This module adds the group "Payments for invoices" and only users
belonging to this group will be able to see these buttons and menus:

- "Register payment" button on customer, supplier and corrective
  customer and supplier invoices.
- Action \> Register payment for lists.
- Menus "Customer payments" and "Supplier payments".
