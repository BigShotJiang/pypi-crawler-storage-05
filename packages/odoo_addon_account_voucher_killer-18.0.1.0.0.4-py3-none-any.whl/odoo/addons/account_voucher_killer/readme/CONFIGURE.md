To use this functionality go to "Settings \> Users" edit the user you
are going to grant visibility to and activate the "Payments for
Invoices" permission.

It is also possible to edit the "Payments for Invoices" group under
"Settings \> Groups" and add as many users as necessary.
