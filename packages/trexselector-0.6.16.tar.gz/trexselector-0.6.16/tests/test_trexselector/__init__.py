"""
Test package for trexselector.
""" 