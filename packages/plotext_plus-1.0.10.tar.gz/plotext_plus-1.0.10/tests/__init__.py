# Tests for plotext library
