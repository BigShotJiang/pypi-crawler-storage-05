export const LOCALE_STORAGE_KEY = 'locale-dingo';
