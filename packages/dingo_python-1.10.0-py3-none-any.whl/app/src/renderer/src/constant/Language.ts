export enum Language {
    ZH_CN = 'zh-CN',
    EN_US = 'en-US',
}
