export const isElectron = () => {
    return window.electronAPI !== undefined;
};
