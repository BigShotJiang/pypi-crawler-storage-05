from dingo.model.model import Model

Model.load_model()
