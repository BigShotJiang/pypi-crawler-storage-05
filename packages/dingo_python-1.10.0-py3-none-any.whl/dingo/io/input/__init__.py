from dingo.io.input.data import Data  # noqa E402.
