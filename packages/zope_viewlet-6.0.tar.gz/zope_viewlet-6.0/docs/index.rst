.. include:: ../README.rst


Documentation:

.. toctree::
   :maxdepth: 2

   narr.rst
   comm.rst
   zcml.rst

API Documentation:

.. toctree::
   :maxdepth: 2

   interfaces
   manager
   viewlet

.. toctree::
   :maxdepth: 2

   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
