from . import main


def app():
    main.main()
