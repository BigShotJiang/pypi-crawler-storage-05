version = '0.3.0'

# 因为日期格式问题，所以下面的版本号不能使用
# 主版本号 (Major Version): 较大的功能变化或结构调整
# 次版本号 (Minor Version): 较小的功能变化或一些新功能的添加
# 修订版本号 (Patch Version): bug 修复或非常小的变化
# 构建号 (Build Number): 1构建号 （Build Number）： 小的修复或改进，不会引入新的功能
