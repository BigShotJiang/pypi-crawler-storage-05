"""Unit test package for fast_snippets."""
