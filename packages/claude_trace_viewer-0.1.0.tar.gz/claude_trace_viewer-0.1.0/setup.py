#!/usr/bin/env python
"""Minimal setup.py for backward compatibility."""
from setuptools import setup

setup()