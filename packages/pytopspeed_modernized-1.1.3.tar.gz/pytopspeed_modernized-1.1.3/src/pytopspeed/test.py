from . import topread


if __name__ == "__main__":
    test = topread("C:\\Redcat\\POS\\tbl_dbconn.tps", '@dbc:')
    print()

    