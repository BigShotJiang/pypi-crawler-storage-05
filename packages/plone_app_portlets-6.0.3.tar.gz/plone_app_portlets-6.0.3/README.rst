Introduction
=============

plone.app.portlets provides a Plone-specific user interface for
plone.portlets, as well as a standard set of portlets that ship with Plone.


Compatibility
=============

plone.app.portlets 2.4.x is for Plone 4.3.
plone.app.portlets 2.5.x is for Plone 4.3 with plone.app.event (makes the calendar- and events-portlets use the p.a.event implementation)
plone.app.portlets 3.x is for Plone 5.0
plone.app.portlets 4.x is for Plone 5.1 and 5.2.
plone.app.portlets 5.x is for Plone 6.0.
