from zope.deferredimport import deprecated


deprecated(
    "Import from plone.app.event.portlets.portlet_calendar instead (will be removed in Plone 7)",
    Assignment="plone.app.event.portlets.portlet_calendar:Assignment",
)
