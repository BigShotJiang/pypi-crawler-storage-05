from nemo_library.adapter.utils.structures import ETLBaseObjectType


class GenericSQLObjectType(ETLBaseObjectType):
    GENERIC = ("GENERIC", "0001")

