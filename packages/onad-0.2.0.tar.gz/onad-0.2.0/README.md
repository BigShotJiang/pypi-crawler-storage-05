# onad
Online Anomaly Detection

## Work in progress!
Feel free to try and provide feedback.