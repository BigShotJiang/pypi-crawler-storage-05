# Relational algebra latex operators

PROJECT_OP = "\\pi"
RENAME_OP = "\\rho"
SELECT_OP = "\\sigma"
ASSIGN_OP = ":="

JOIN_OP = "\\times"
THETA_JOIN_OP = "\\times"
NATURAL_JOIN_OP = "\\bowtie"
FULL_OUTER_JOIN_OP = "\\fullouterjoin"
LEFT_OUTER_JOIN_OP = "\\leftouterjoin"
RIGHT_OUTER_JOIN_OP = "\\rightouterjoin"

DIFFERENCE_OP = "-"
UNION_OP = "\\cup"
INTERSECT_OP = "\\cap"
