class Message:
    pass


__all__ = ["Message"]