# What is this?

[![Release Workflow](https://github.com/NormanTUD/asanAI_python/actions/workflows/release.yml/badge.svg?event=push)](https://github.com/NormanTUD/asanAI_python/actions/workflows/release.yml)

The idea here is that this allows a generalized way of doing ML stuff from asanAI from within modules.
