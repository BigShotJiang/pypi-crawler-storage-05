import logging

# Create package logger
logger = logging.getLogger("opentak")
