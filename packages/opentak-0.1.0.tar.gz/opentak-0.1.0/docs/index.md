# Opentak

✨ 🎨 ✨


`tak` is a clustering and visualization solution for clustering and representing care pathways.  

## Getting started

Install package in your project:

```
poetry add opentak
```