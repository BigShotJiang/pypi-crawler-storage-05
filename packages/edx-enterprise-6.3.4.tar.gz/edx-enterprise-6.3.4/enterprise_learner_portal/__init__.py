"""
App for supporting the enterprise_learner_portal frontend.
"""
