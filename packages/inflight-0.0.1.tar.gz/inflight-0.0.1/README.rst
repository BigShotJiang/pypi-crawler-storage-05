A prototype WSGI/ASGI application server. Nothing to see here yet.
