import sys

import crp.main

sys.exit(crp.main.cli())  # pyright: ignore[reportAny]
