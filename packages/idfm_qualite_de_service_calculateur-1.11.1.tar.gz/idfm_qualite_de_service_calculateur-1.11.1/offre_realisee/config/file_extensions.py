class FileExtensions(str):
    parquet = ".parquet"
    csv = ".csv"
