class InputColumns:
    ligne = 'LIGNE'
    jour = 'JOUR'
    sens = 'SENS'
    arret = 'ARRET'
    is_terminus = 'IS_TERMINUS'
    heure_theorique = 'HEURE_THEORIQUE'
    heure_reelle = 'HEURE_REELLE'
    dsp = 'DSP'

    # column_types = {
    #     ligne: 'string',
    #     jour: 'datetime64',
    #     sens: 'string',
    #     arret: 'string',
    #     is_terminus: 'boolean',
    #     heure_theorique: 'datetime64',
    #     heure_reelle: 'datetime64'
    # }
