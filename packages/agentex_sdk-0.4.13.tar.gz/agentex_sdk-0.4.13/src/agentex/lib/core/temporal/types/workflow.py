from enum import Enum


class SignalName(str, Enum):
    RECEIVE_EVENT = "receive_event"
