# [Agentic] Other SDKs

This tutorial demonstrates how to use other SDKs in AgentEx agents to show the flexibility that agents are just code.

## Official Documentation

[040 Other SDKs Base Agentic](https://dev.agentex.scale.com/docs/tutorials/agentic/base/other_sdks/)