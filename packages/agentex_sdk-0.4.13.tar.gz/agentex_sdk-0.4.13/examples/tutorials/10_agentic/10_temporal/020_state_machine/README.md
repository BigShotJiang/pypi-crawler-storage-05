# [Agentic] State Machine with Temporal

This tutorial demonstrates how to use state machines to manage complex agentic workflows with Temporal in AgentEx agents.

## Official Documentation

[020 State Machine Temporal Agentic](https://dev.agentex.scale.com/docs/tutorials/agentic/temporal/state_machine/)