"""Test suite for embed-rerank API."""
