VERSION = (1, 1, '1')

__version__ = '.'.join(map(str, VERSION))


def version(): return __version__
