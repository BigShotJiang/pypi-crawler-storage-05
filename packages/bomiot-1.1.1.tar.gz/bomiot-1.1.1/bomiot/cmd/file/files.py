

# class FileClass:
#     def file_get(self, data):
#         print(data)