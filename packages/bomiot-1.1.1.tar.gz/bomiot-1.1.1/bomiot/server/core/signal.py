from django.dispatch import Signal


bomiot_signals = Signal()
bomiot_data_signals = Signal()
