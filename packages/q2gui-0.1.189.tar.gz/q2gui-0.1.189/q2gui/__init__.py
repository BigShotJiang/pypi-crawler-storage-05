from q2gui.version import __version__
