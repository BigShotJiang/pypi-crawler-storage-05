# rusmppyc/events.py

from .rusmppyc import Events  # type: ignore

__all__ = ["Events"]
