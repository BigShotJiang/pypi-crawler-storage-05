from zope.browserpage.viewpagetemplatefile import ViewPageTemplateFile


__all__ = [
    'ViewPageTemplateFile',
]
