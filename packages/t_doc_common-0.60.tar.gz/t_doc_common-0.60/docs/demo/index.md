% Copyright 2024 Remy Blank <remy@c-space.org>
% SPDX-License-Identifier: MIT

# Demo

```{toctree}
:maxdepth: 1
elements
diagram
math
quiz
poll
python
micropython
sql
html
crypto
```
