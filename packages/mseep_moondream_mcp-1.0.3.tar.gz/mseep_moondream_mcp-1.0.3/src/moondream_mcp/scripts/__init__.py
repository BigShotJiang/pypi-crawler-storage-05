"""
Scripts package for Moondream MCP.
"""
