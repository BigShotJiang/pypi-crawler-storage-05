To use this module, you need to:

* Create a sale order via website shop
* Check if the freight value displayed to the customer represents the correct calculated freight value
