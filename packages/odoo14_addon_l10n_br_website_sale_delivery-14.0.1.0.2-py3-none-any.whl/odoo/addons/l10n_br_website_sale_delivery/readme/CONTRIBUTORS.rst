* `Kmee <https://www.kmee.com.br>`__:

  * Diego Paradeda <diego.paradeda@kmee.com.br>
  * Gabriel Cardoso de Faria <gabriel.cardoso@kmee.com.br>

* `Escodoo <https://www.escodoo.com.br>`__:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>
