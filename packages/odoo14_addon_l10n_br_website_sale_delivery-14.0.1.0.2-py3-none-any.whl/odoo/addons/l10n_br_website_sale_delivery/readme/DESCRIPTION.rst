This module was written to extend the functionality of delivery to support the
adequacy of Brazilian delivery standards
and display the correct freight fields in website.
