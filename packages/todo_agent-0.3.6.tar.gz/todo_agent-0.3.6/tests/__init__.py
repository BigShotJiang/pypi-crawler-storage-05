"""
Test suite for todo.sh LLM agent.
"""
