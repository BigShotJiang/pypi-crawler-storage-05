"""Initialize the 'github-faker' project."""
