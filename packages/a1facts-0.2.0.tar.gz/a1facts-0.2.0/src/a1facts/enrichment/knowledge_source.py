class KnowledgeSource:
    def __init__(self, source_config: dict):
        pass
        
    def query(self, query_text: str):
        pass

    def __str__(self) -> str:
        pass
