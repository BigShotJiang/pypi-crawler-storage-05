class EntityNotFound(Exception):
    pass