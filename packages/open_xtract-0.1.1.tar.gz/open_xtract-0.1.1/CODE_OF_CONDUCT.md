# Code of Conduct

We follow the Contributor Covenant Code of Conduct, version 2.1.

In short: be respectful, inclusive, and constructive. Harassment and other
unacceptable behavior will not be tolerated.

For the full text, see the Contributor Covenant v2.1 at
`https://www.contributor-covenant.org/version/2/1/code_of_conduct/`.

Enforcement: If you experience or witness unacceptable behavior, please call it out.
