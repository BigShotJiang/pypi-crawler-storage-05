---
name: Feature request
about: Suggest an idea for this project
title: "[Feature]: "
labels: enhancement
assignees: ''
---

### Problem
What problem are you trying to solve?

### Proposal
Describe the solution you'd like.

### Alternatives
Describe alternatives you've considered.

### Additional context
Add any other context or screenshots about the feature request here.

