import pint

"""
Class Pint Unit Registry dasar untuk membuat Pint Object
Setiap instance Unit Registry hanya bisa dilakukan operasi perhitungan
dengan instance Unit Registry itu sendiri
"""
PintUreg = pint.UnitRegistry()
