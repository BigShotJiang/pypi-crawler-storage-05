from .maybank import Maybank

__all__ = ["Maybank"]
