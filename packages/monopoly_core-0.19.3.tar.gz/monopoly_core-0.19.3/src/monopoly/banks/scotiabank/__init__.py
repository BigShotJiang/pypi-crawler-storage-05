from .scotiabank import Scotiabank

__all__ = ["Scotiabank"]
