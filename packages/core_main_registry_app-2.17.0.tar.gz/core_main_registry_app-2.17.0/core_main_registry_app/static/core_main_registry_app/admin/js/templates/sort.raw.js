var saveGlobalTemplateOrderingUrl = "{% url 'core_main_app_rest_global_template_version_manager_ordering' %}";
