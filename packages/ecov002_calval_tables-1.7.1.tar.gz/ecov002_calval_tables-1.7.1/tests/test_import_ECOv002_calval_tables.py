def test_import_ECOv002_calval_tables():
    import ECOv002_calval_tables
