# This file is required to simplify running pytest.
#
# Build pyodbc into the project root by running: python setup.py build_ext --inplace
#
# Then run pytest from the root: pytest tests/postgresql_test.py
