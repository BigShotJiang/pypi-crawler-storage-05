# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .raw_message_stop_event import RawMessageStopEvent

__all__ = ["MessageStopEvent"]

MessageStopEvent = RawMessageStopEvent
"""The RawMessageStopEvent type should be used instead"""
