from zope.deprecation import moved


moved("plone.namedfile.storages.Zope2FileUploadStorable", "Version 7.0")
