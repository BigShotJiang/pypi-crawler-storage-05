from .dataset import LLMDataset, ResultDataset

__all__ = ['LLMDataset', 'ResultDataset']