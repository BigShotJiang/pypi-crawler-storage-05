class EvalError(RuntimeError):
    pass