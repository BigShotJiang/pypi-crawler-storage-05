"""
<description not available>
"""

# this file was auto-generated!


from openminds.base import LinkedMetadata
from openminds.properties import Property


class Periodical(LinkedMetadata):
    """
    <description not available>
    """

    type_ = "https://openminds.om-i.org/types/Periodical"
    context = {"@vocab": "https://openminds.om-i.org/props/"}
    schema_version = "latest"

    properties = [
        Property(
            "abbreviation",
            str,
            "abbreviation",
            formatting="text/plain",
            description="no description available",
            instructions="Enter the official (or most commonly used) abbreviation of the periodical (e.g., J. Physiol).",
        ),
        Property(
            "digital_identifier",
            "openminds.latest.core.ISSN",
            "digitalIdentifier",
            description="Digital handle to identify objects or legal persons.",
            instructions="Add the globally unique and persistent digital identifier of this periodical.",
        ),
        Property(
            "name",
            str,
            "name",
            formatting="text/plain",
            required=True,
            description="Word or phrase that constitutes the distinctive designation of the periodical.",
            instructions="Enter the name (or title) of this periodical (e.g., Journal of Physiology).",
        ),
    ]

    def __init__(self, id=None, abbreviation=None, digital_identifier=None, name=None):
        return super().__init__(
            id=id,
            abbreviation=abbreviation,
            digital_identifier=digital_identifier,
            name=name,
        )
