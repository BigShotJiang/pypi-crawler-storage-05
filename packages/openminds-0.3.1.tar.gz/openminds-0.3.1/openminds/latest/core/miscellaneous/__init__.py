from .comment import Comment
from .funding import Funding
from .quantitative_value import QuantitativeValue
from .quantitative_value_array import QuantitativeValueArray
from .quantitative_value_range import QuantitativeValueRange
from .research_product_group import ResearchProductGroup
from .web_resource import WebResource
