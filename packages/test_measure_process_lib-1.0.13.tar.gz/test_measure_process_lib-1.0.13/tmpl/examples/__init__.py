# Example code and functions
from .resistor_example import *