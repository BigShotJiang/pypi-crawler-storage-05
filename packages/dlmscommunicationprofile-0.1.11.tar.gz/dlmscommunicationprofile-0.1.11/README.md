# DLMSCommunicationProfile_prj
Communication profile part for DLMS
