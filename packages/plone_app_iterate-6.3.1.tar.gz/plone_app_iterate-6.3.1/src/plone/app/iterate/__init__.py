from zope.i18nmessageid import MessageFactory

import logging


PloneMessageFactory = MessageFactory("plone")
logger = logging.getLogger("plone.app.iterate")
