CheckinPermission = "iterate : Check in content"
CheckoutPermission = "iterate : Check out content"
