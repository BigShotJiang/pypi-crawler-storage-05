hcs-cli core component.

