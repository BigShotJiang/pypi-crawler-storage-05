"""
Things MCP Server - Model Context Protocol server for Things task management app.
"""

__version__ = "0.1.1"
