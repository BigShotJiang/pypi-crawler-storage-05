from tacocompression.compression import compress, decompress

