# pgmini-migrate

A minimal PostgreSQL migration tool using psycopg3.

## Install
```bash
pip install pgmini-migrate