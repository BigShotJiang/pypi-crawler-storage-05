**Your pull request has been merged and a preview build has been published!**

Build {{ .version }} is now available at TestPyPI: <https://test.pypi.org/project/modem-info/{{ .version }}>

To install, run: `pip install -i https://test.pypi.org/simple/ modem-info=={{ .version }}`

Note that not all dependencies can be resolved via TestPyPI.
