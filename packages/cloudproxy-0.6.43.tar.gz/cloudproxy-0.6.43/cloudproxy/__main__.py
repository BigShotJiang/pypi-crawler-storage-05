#!/usr/bin/env python
from cloudproxy.main import main # Changed 'start' to 'main'

if __name__ == "__main__":
    main() # Changed 'start' to 'main'