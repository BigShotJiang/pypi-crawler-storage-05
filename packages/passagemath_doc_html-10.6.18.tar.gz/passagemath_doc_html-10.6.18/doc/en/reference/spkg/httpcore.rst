.. _spkg_httpcore:

httpcore: Minimal low-level HTTP client
=======================================

Description
-----------

Minimal low-level HTTP client

License
-------

Upstream Contact
----------------

https://pypi.org/project/httpcore/



Type
----

standard


Dependencies
------------

- $(PYTHON)
- :ref:`spkg_certifi`
- :ref:`spkg_h11`
- :ref:`spkg_pip`

Version Information
-------------------

package-version.txt::

    1.0.9

version_requirements.txt::

    httpcore

Equivalent System Packages
--------------------------

(none known)
