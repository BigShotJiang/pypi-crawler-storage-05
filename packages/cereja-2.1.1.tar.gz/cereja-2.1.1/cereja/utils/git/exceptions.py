class GitCommandError(Exception):
    """Erro customizado para falhas ao executar comandos Git."""
    pass
