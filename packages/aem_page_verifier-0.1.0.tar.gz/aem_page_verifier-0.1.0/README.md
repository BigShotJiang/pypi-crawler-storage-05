# AEM Page Verifier

A Python tool to compare Adobe Experience Manager (AEM) publish pages with the author server, identifying missing (ghost) pages.

## Installation

```bash
pip install aem-page-verifier