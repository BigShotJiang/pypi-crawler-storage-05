"""
Namespace modules for WAHA

Contains all API endpoint namespaces organized by functionality.
"""
