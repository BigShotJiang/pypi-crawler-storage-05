## [unreleased]

### 🚀 Features

- Add export_to_excel and export_to_csv
## [1.6.0] - 2025-09-09

### 🚀 Features

- Add placeholder for number Dialogs

### ⚙️ Miscellaneous Tasks

- Update Version
## [1.5.0] - 2025-09-09

### 🚜 Refactor

- Move dialog to seperat files (#22)

### ⚙️ Miscellaneous Tasks

- Update Version
## [1.4.0] - 2025-08-27

### ⚙️ Miscellaneous Tasks

- Update Version
## [1.3.0] - 2025-08-21

### 🐛 Bug Fixes

- Implement `limit` differentiated between total limit and batch limit (#19)

### ⚙️ Miscellaneous Tasks

- Add links to `README.md` and `pyproject.toml` and correct some mistakes (#20)
- Update Version
## [1.2.0] - 2025-06-26

### ⚙️ Miscellaneous Tasks

- Update Version
## [1.1.0] - 2025-06-12

### 🚀 Features

- Add `reuse` for multiple dialog (#12)
- Provide `export_to_json()`-function in exporter (#14)
- Add types support for _open_file_dialog (#17)

### ⚙️ Miscellaneous Tasks

- Update Version
## [1.0.2.0] - 2025-03-05

### 🚀 Features

- Add Multiple Dialog (#11)
## [1.0.1.1] - 2025-01-23

### ⚙️ Miscellaneous Tasks

- Remove release.yml
## [1.0.1] - 2024-12-06

### ⚙️ Miscellaneous Tasks

- Add pipy-release.yml for automatic deployment to PyPi
- Add dynamic version to pyproject.toml
