#! /usr/bin/env python3

if __name__ == "__main__":
    from .entrypoint import main

    main()
