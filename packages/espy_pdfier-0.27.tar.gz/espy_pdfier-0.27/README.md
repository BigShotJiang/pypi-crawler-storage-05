## py-espdfier

### PY Package for ESSL to Generate Assets

- python3 setup.py sdist bdist_wheel
- twine upload dist/\*
