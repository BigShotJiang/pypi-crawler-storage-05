__version__ = '1.0.0'

# Default app config for the new headless_waf_builder package
default_app_config = 'headless_waf_builder.apps.HeadlessWafBuilderConfig'
