from .base_static_block import BaseStaticBlock
from .inline_form_block import InlineFormBlock
