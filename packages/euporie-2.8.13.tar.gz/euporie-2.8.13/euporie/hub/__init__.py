"""A multi-user hub euporie application."""
