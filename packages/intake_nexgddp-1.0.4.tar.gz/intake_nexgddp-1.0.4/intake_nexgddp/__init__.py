from .config_loader import ensure_visus_env
ensure_visus_env()