Viraj Choudhary's NLP Toolkit

Personal Python package developed for my university Natural Language Processing lab assignments.
It includes simple, reusable functions for:

Text preprocessing
Corpus analysis
Feature engineering

I originally built this toolkit to support my coursework, but I may extend it for other use cases over time. Who knows—it could even evolve into a major project. Big things start small.

More functions and modules will be added.