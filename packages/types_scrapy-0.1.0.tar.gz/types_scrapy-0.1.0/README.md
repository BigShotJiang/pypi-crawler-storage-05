# types-scrapy
Typing stubs for [Scrapy](https://scrapy.org).

## Installation
```bash
pip install types-scrapy

