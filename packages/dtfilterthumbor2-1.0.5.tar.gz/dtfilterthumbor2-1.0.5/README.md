# DantriFilter docs

Ảnh logo: ở đính kèm

Kích thước logo:

Chiều rộng bằng 12.5% (1/8) chiều rộng của ảnh

Chiều cao auto (keep ratio) theo chiều rộng của logo

Vị trí: cách góc dưới bên trái một khoảng bằng 1/2 chiều cao của logo tính theo cả chiều dọc và chiều ngang