.. _whatsnew:

***************
Release History
***************

This page documents the releases for sunraster

.. toctree::
   :maxdepth: 1

   changelog
