"""Time MCP Server - A Model Context Protocol server for time operations."""

__version__ = "1.0.0"