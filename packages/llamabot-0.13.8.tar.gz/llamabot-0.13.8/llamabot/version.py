"""Version information for llamabot."""

version = "0.13.8"
