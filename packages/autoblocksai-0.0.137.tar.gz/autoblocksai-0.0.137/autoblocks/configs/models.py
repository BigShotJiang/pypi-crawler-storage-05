from autoblocks._impl.configs.models import RemoteConfig

__all__ = [
    "RemoteConfig",
]
