class TypeException(Exception):
    pass

class PredicateNotFoundException(Exception):
    pass
