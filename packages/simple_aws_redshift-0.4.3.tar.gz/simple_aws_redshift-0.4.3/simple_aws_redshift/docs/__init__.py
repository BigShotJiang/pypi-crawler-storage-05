# -*- coding: utf-8 -*-

doc_data = dict()
