# FFcapcha

Thank you for installing FF.capcha. Our service is aimed at protecting telegram bots from suspicious requests and DDoS attacks. Documentation about the module and resource news -> https://t.me/ffcapcha

powered by Vnd.FF, pavyk, gilov

## Installation

```bash
pip install ffcapcha