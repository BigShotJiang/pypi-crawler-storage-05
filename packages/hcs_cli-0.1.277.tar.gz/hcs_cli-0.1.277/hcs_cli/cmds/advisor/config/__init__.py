"""
Copyright © 2025 Omnissa, LLC.
"""

from .advisor_config import *
