"""
IO support for Silixa HDF5 files.

Website: https://silixa.com/
"""

from .core import SilixaH5V1
