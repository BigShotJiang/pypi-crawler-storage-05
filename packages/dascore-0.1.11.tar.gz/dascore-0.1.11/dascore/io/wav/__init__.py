"""
Module for writing wave files to disk.
"""
from __future__ import annotations
from .core import WavIO
