"""
Sintela binary reader.
"""
from .core import SintelaBinaryV3
