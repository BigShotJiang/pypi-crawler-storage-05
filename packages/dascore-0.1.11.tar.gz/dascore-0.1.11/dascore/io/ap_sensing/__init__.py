"""
IO support for AP sensing interrogators.

Website: https://www.apsensing.com/
"""

from .core import APSensingV10
