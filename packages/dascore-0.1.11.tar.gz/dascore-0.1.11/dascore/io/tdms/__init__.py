"""
Module for reading and writing TDMS fiber data recorded by Silixa.
"""
from __future__ import annotations
from .core import TDMSFormatterV4713
