from plone.indexer.decorator import indexer  # noqa
