from .data_generators import (
    iris,
    jobs,
    marketing,
    stocks,
    tips,
    election,
    wind,
    gapminder,
    fish_market,
)
