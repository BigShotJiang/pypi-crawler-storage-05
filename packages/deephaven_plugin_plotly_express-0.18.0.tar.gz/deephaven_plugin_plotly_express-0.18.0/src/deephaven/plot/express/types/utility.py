import collections

FilterColumn = collections.namedtuple("FilterColumn", ["name", "type", "required"])
