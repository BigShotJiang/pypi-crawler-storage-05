
IFCONFIG_ME_PATTERN = r'(.+)'
CIP_CC_PATTERN = r'URL\s+?:\s+?http://www.cip.cc/(.+)'
TOOL_LU_PATTERN = r'<p>你的外网IP地址是：\s*?(.+)</p>'
IP_SB_PATTERN = r'(.+)'