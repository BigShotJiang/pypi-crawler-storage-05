import logging


logger = logging.getLogger("cucm_client")
