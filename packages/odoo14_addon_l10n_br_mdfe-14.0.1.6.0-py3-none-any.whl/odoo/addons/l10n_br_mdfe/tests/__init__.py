from . import test_mdfe_serialize
from . import test_mdfe_serialize_lc
from . import test_mdfe_serialize_sn
from . import test_mdfe_import
from . import test_mdfe_structure
from . import test_mdfe_res_partner
from . import test_mdfe_damdfe
from . import test_mdfe_document
