# -*- coding: utf-8 -*-
"""
Created on Sun Jun 29 14:06:04 2025

@author: maipa
"""

