"""Core module tests"""

__all__ = []
