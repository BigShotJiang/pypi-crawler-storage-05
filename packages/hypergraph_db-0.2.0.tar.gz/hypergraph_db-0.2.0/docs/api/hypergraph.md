# HypergraphDB Class

::: hyperdb.hypergraph.HypergraphDB
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      group_by_category: true
      show_category_heading: true
      show_if_no_docstring: true
