def foo():
    print('1')
    print('2')
    print('3')


def foo2():
    print('1')
    print('2')
    print('3')
