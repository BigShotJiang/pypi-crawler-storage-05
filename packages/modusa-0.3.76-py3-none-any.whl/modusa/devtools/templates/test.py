#!/usr/bin/env python3

from modusa import excp

#--------Meta Information----------
_class_name = "{class_name}"
_author_name = "{author_name}"
_author_email = "{author_email}"
_created_at = "{date_created}"
#----------------------------------