#include <stdio.h> /* FILE */


extern const char *NemVersionStrC ;    /* Current version of NEM software */

extern void PrintVersions( FILE* F ) ; /* Describes successive versions */
