/*\
Vers-mod  Date         Who Description
1.06-a    28-JUN-1998  MD  GetSpatialFunc instead of GetNeighImage, ...
\*/

#include "nem_typ.h"    /* NeighDataT */


int GetSpatialFunc  /* STS_OK or STS_E_FUNCARG */
    (
     TypeET          SpatialType,    /* I */
     GetNeighFT**    GetNeighFP      /* O */
    ) ;

