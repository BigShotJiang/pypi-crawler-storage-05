#ifndef nem_hlp_H
#define nem_hlp_H

#include <stdio.h>  /* FILE */

extern void PrintHelpGeneral( FILE* F ) ;

extern void PrintHelpOptions( FILE* F ) ;

extern void PrintHelpExamples( FILE* F ) ;

extern void PrintHelpFileIn( FILE* F ) ;

extern void PrintHelpFileOut( FILE* F ) ;

extern void PrintHelpVersions( FILE* F ) ;

#endif
