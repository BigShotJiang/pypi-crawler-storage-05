"""
NanoRepeat: quantification of Short Tandem Repeats (STRs) from long-read sequencing data
"""

__author__ = 'Li Fang and Kai Wang'
__credits__ = "Children's Hospital of Philadelphia"
