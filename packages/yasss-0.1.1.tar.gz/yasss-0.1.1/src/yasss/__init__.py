def hello() -> str:
    return "Hello from yasss! This is a placeholder"
