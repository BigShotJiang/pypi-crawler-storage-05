# yasss, yet another sample size software

or at least this is the idea
