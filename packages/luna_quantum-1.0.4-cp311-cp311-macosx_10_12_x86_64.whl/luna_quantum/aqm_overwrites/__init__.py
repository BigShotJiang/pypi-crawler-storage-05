from .model import Model

__all__ = ["Model"]
