from luna_quantum.util.pretty_base import PrettyBase


class UseCase(PrettyBase):
    """Base class for all UseCases."""

    name: str
