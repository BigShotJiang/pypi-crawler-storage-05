from pr_pro.workout_component import ExerciseGroup as EG  # noqa: F401
from pr_pro.workout_component import SingleExercise as SE  # noqa: F401
