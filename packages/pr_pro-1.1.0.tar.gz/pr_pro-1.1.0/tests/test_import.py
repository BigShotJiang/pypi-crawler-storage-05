def test_import():
    import pr_pro  # noqa: F401
