# The contributors to `ipyevents` are:

+ Odile Bénassy ([@zerline](https://github.com/zerline))
+ Pascal Bugnion ([@pbugnion](https://github.com/pbugnion))
+ Sylvain Corlay ([@SylvainCorlay](https://github.com/SylvainCorlay))
+ Matt Craig ([@mwcraig](https://github.com/mwcraig)), maintainer
+ Simon Gurcke ([@itssimon](https://github.com/itssimon))
+ Alex Kaszynski ([@akaszynski](https://github.com/akaszynski))
+ Prabhu Ramachandran ([@prabhuramachandran](https://github.com/prabhuramachandran))
+ Waldemar Reusch ([@lordvlad](https://github.com/lordvlad))
+ Thomas Robitaille ([@astrofrog](https://github.com/astrofrog))
+ Jeremy Tuloup ([@jtpio](https://github.com/jtpio))
+ Peter Williams ([@pkgw](https://github.com/pkgw))
