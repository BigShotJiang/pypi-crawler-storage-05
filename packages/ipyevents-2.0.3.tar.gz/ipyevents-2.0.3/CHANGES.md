# Version 0.7.0 (released 2019-10-05)

## New features

+ Add a `remove_callbacks` method to remove all callbacks more easily.

## Other

+ Increase minimum Python version to 3.6 (3.5 has reached end-of-life)
