# Code of conduct

Contributors to this repository are expected to follow the [Python Software Foundation Code of Conduct](https://www.python.org/psf/conduct/)in their interactions in pull requests, issues, and other interactions related to this package.
