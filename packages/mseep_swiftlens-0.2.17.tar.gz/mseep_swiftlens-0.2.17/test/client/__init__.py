"""
Tests for client-side dashboard functionality
"""
