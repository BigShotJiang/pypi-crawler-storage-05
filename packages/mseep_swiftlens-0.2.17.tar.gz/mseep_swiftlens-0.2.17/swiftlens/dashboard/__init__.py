"""
Dashboard package for Swift Context MCP Server
Provides web-based monitoring and logging functionality
"""

__all__ = ["logger", "web_server"]
