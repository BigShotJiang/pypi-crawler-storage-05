"""Package containing report handlers for different output formats."""
