"""Package initialization module for hashreport."""

from .version import __version__

__all__ = ["__version__"]
