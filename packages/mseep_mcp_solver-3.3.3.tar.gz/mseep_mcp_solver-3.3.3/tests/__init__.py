"""
MCP Solver Tests Package
"""
