In an L(2, 1)-coloring of a graph the vertices are assigned color numbers in such a way that adjacent vertices get labels that differ by at least two, and the vertices that are at a distance of two from each other get labels that differ by at least one.

Check whether the Peterson graph (5-cycle + pentagram + perfect matching) has an L(2,1) coloring with 9 colors. 