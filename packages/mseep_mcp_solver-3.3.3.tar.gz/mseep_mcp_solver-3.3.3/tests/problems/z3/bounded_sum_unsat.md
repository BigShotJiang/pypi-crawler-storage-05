Find an assignment of integers to variables a, b, c, d, and e that:

1. Each variable must be between 1 and 10 inclusive
2. All variables must have different values
3. The sum of all variables must be exactly 36
4. The product of a and b must be less than 20
5. The product of c, d, and e must be at least 200
6. Any two variables must sum to at least 11

or decide that this is impossible. 