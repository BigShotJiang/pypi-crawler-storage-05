# Cryptarithmetic Puzzle

Can you solve this cryptarithmetic puzzle using Z3?

```
  SEND
+ MORE
------
 MONEY
```

Each letter represents a unique digit (0-9). Find the digit assignment that makes this sum equation valid.

The leading digit of any number cannot be 0 (so S and M cannot be 0).
