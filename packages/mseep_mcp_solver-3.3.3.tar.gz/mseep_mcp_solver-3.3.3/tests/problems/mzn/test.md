Find values for two variables x and y that satisfy these conditions:

1. Both x and y must be integers between 1 and 10 (inclusive)
2. The sum of x and y must be less than or equal to 10 (x + y ≤ 10)
3. The product of x and y must be greater than or equal to 10 (x × y ≥ 10)

