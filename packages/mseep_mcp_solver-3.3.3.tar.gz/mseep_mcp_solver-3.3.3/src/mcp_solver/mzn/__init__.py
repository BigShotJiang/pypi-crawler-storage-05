"""
MiniZinc integration for MCP Solver.
"""

from .model_manager import MiniZincModelManager


__all__ = ["MiniZincModelManager"]
