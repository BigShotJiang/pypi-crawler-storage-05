"""
SubtranSlate - A tool for translating subtitle files.
"""

__version__ = "1.0.3"
