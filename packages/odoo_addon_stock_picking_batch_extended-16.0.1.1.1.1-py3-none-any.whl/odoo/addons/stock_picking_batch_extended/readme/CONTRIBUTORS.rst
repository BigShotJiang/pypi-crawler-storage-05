**picking_dispatch**

* Peter Langenberg <peter.langenberg@bubbles-it.be>
* Rudolf Schnapka <rs@techno-flex.de>
* Matthieu Dietrich <matthieu.dietrich@camptocamp.com>
* Romain Deheele <romain.deheele@camptocamp.com>
* Leonardo Pistone <leonardo.pistone@camptocamp.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Joël Grand-Guillaume <joel.grandguillaume@camptocamp.com>
* Cyril Gaudin <cyril.gaudin@camptocamp.com>
* Iryna Vyshnevska <i.vyshnevska@mobilunity.com>

**stock_batch_picking**

* `Camptocamp <https://www.camptocamp.com>`_:

  * Cyril Gaudin

* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden
  * Sergio Teruel
  * César A. Sánchez

* `Trobz <https://trobz.com>`_:

    * Son Ho <sonhd@trobz.com>
