metadata_default = {
    "name": "DefaultPiece",
    "dependency": {
        "dockerfile": None,
        "requirements_file": None
    },
    "tags": [],
    "style": {
        "node_label": "Piece",
        "node_type": "default",
        "node_style": {
            "backgroundColor": "#ebebeb"
        },
        "useIcon": True,
        "icon_class_name": "fa-solid fa-circle",
        "iconStyle": {
            "cursor": "pointer"
        }
    },
}