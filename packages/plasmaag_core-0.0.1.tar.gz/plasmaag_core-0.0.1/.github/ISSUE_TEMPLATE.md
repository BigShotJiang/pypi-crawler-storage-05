Thank you for making an issue.
If you are submitting a bug report, it will help us if you include the following information:

- Your version of Python and Vamb.
- The log file (called `log.txt`) from the output directory
- The full error message produced by Vamb, if any
