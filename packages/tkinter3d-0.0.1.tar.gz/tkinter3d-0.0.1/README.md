# tkinter3d
a tkinter extension for 3d displaying

# installation
windows:

py -m pip install tkinter3d

unix&mac:

python3 -m pip install tkinter3d