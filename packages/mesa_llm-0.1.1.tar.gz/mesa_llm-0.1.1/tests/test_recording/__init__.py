"""Tests for the mesa_llm recording module."""
