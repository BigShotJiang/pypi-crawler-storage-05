"""AFLW AFLWStats module."""
