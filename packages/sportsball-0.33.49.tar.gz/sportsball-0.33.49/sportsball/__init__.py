"""The main module for sportsball."""

# flake8: noqa
import cchardet  # type: ignore
import lxml  # noqa: ignore

__VERSION__ = "0.33.49"
