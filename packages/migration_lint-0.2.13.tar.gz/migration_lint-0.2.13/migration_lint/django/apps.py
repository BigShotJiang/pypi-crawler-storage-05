from django.apps import AppConfig


class MigrationLintDjangoConfig(AppConfig):
    name = "migration_lint.django"
    label = "migration_lint_django"
