# ParaO

This project is in active development.

Related conference contributions:
- [waluigi - Beyond luigi](https://indico.cern.ch/event/1375573/contributions/6089483/) @ PyHEP.dev 2024
- [Parametrizing workflows with ParaO and Luigi](https://indico.cern.ch/event/1488410/abstracts/191788/) @ ACAT 2025
