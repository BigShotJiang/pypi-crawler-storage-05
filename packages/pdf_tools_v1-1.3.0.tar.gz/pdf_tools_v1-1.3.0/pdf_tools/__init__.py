from .tools import extract_text, get_page_count

__version__ = "1.0.0"
