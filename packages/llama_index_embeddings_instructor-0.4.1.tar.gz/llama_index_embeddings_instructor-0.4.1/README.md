# LlamaIndex Embeddings Integration: Instructor
