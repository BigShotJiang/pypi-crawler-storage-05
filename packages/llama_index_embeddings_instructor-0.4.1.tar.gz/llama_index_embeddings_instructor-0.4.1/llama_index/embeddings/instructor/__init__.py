from llama_index.embeddings.instructor.base import InstructorEmbedding

__all__ = ["InstructorEmbedding"]
