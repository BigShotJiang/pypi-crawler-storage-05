from agentica.model.yi.chat import Yi
