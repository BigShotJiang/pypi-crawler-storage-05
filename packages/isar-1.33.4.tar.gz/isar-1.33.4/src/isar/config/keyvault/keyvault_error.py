class KeyvaultError(Exception):
    pass
