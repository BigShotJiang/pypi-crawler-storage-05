from dify_plugin.commands.generate_docs import generate_docs

__all__ = ["generate_docs"]
