# NANSEN 🧭

Load, analyze and clean GPX tracks in python !
