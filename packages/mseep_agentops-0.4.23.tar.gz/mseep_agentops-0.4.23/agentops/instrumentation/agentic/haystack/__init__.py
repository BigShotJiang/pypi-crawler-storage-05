from .instrumentor import HaystackInstrumentor  # noqa: F401
