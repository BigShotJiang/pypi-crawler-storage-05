---
name: 🤔 General Question
about: Ask a general question about our project
labels: General Question
---

<!-- Please search existing issues to avoid creating duplicates. -->

### Question

Describe the issue or question you have regarding our project. Please include any relevant details or context.

### Context

If applicable, share source code or context that might help us understand your question better.

