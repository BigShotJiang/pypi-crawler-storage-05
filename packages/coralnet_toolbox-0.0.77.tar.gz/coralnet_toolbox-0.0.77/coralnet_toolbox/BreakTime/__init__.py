# coralnet_toolbox/BreakTime/__init__.py

from .QtSnake import SnakeGame
from .QtBreakout import BreakoutGame

__all__ = ["SnakeGame", "BreakoutGame"]