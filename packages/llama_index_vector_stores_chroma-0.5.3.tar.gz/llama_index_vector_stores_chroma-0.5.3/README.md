# LlamaIndex Vector_Stores Integration: Chroma
