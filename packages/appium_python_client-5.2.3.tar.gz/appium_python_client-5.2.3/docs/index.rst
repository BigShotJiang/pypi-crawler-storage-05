.. Appium python client documentation master file, created by
   sphinx-quickstart on Mon Aug 11 09:34:52 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Appium python client documentation
==================================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 4
   :caption: Contents:

   webdriver
