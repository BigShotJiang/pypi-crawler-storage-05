""".. include:: ../../README.md"""  # noqa: D415
