

def test():
    return "Success"