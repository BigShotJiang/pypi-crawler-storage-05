import os
from setuptools import find_packages, setup

setup(
    name="stealthify",
    version="0.0.1",
    author="Arjun Shankar",
    author_email="arjun.sha2425@gmail.com",
    license="Apache-2.0",
    packages=find_packages(),
    long_description_content_type="text/markdown",
)