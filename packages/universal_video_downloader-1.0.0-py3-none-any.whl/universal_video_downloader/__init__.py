"""Universal Video Downloader Package"""
__version__ = "1.0.0"
__author__ = "Aarif5856"
__description__ = "Download videos and audio from multiple platforms"