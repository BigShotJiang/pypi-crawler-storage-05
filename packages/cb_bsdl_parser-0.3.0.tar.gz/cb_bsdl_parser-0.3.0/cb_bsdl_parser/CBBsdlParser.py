# Generated from CBBsdl.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,40,249,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,1,0,1,0,5,0,65,8,0,10,0,
        12,0,68,9,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,2,1,3,1,3,1,3,
        1,3,1,3,3,3,85,8,3,5,3,87,8,3,10,3,12,3,90,9,3,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,
        6,1,6,1,6,1,6,1,7,1,7,1,8,1,8,1,8,4,8,121,8,8,11,8,12,8,122,1,8,
        1,8,1,8,1,9,1,9,1,9,1,9,1,9,3,9,133,8,9,1,10,1,10,1,11,1,11,1,12,
        1,12,1,12,3,12,142,8,12,1,13,1,13,1,14,1,14,1,14,1,14,1,14,1,15,
        1,15,1,15,1,15,1,15,1,15,1,15,1,15,4,15,159,8,15,11,15,12,15,160,
        1,15,1,15,1,16,1,16,1,16,1,16,1,16,3,16,170,8,16,1,16,1,16,3,16,
        174,8,16,1,16,1,16,3,16,178,8,16,1,17,1,17,1,18,1,18,1,18,1,18,3,
        18,186,8,18,1,18,1,18,1,18,1,18,1,18,1,19,1,19,1,19,1,19,1,19,1,
        19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,20,1,20,1,21,1,21,1,
        21,1,21,5,21,213,8,21,10,21,12,21,216,9,21,1,22,1,22,1,23,1,23,3,
        23,222,8,23,1,24,1,24,1,25,1,25,1,26,1,26,1,26,1,26,1,26,1,26,3,
        26,234,8,26,1,27,4,27,237,8,27,11,27,12,27,238,1,27,1,27,1,28,1,
        28,1,29,1,29,1,30,1,30,1,30,0,0,31,0,2,4,6,8,10,12,14,16,18,20,22,
        24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,0,2,1,0,
        13,16,1,0,24,24,239,0,62,1,0,0,0,2,69,1,0,0,0,4,77,1,0,0,0,6,88,
        1,0,0,0,8,91,1,0,0,0,10,103,1,0,0,0,12,105,1,0,0,0,14,115,1,0,0,
        0,16,117,1,0,0,0,18,127,1,0,0,0,20,134,1,0,0,0,22,136,1,0,0,0,24,
        141,1,0,0,0,26,143,1,0,0,0,28,145,1,0,0,0,30,150,1,0,0,0,32,164,
        1,0,0,0,34,179,1,0,0,0,36,181,1,0,0,0,38,192,1,0,0,0,40,206,1,0,
        0,0,42,214,1,0,0,0,44,217,1,0,0,0,46,221,1,0,0,0,48,223,1,0,0,0,
        50,225,1,0,0,0,52,233,1,0,0,0,54,236,1,0,0,0,56,242,1,0,0,0,58,244,
        1,0,0,0,60,246,1,0,0,0,62,66,3,2,1,0,63,65,3,60,30,0,64,63,1,0,0,
        0,65,68,1,0,0,0,66,64,1,0,0,0,66,67,1,0,0,0,67,1,1,0,0,0,68,66,1,
        0,0,0,69,70,5,1,0,0,70,71,3,4,2,0,71,72,5,3,0,0,72,73,3,6,3,0,73,
        74,5,2,0,0,74,75,3,4,2,0,75,76,5,24,0,0,76,3,1,0,0,0,77,78,3,58,
        29,0,78,5,1,0,0,0,79,85,3,8,4,0,80,85,3,16,8,0,81,85,3,12,6,0,82,
        85,3,30,15,0,83,85,3,54,27,0,84,79,1,0,0,0,84,80,1,0,0,0,84,81,1,
        0,0,0,84,82,1,0,0,0,84,83,1,0,0,0,85,87,1,0,0,0,86,84,1,0,0,0,87,
        90,1,0,0,0,88,86,1,0,0,0,88,89,1,0,0,0,89,7,1,0,0,0,90,88,1,0,0,
        0,91,92,5,4,0,0,92,93,5,25,0,0,93,94,5,6,0,0,94,95,5,23,0,0,95,96,
        5,5,0,0,96,97,5,29,0,0,97,98,5,28,0,0,98,99,3,10,5,0,99,100,5,28,
        0,0,100,101,5,26,0,0,101,102,5,24,0,0,102,9,1,0,0,0,103,104,3,58,
        29,0,104,11,1,0,0,0,105,106,5,7,0,0,106,107,5,8,0,0,107,108,5,10,
        0,0,108,109,3,4,2,0,109,110,5,23,0,0,110,111,5,1,0,0,111,112,5,3,
        0,0,112,113,3,14,7,0,113,114,5,24,0,0,114,13,1,0,0,0,115,116,3,56,
        28,0,116,15,1,0,0,0,117,118,5,12,0,0,118,120,5,25,0,0,119,121,3,
        18,9,0,120,119,1,0,0,0,121,122,1,0,0,0,122,120,1,0,0,0,122,123,1,
        0,0,0,123,124,1,0,0,0,124,125,5,26,0,0,125,126,5,24,0,0,126,17,1,
        0,0,0,127,128,3,20,10,0,128,129,5,23,0,0,129,130,3,22,11,0,130,132,
        3,24,12,0,131,133,5,24,0,0,132,131,1,0,0,0,132,133,1,0,0,0,133,19,
        1,0,0,0,134,135,3,58,29,0,135,21,1,0,0,0,136,137,7,0,0,0,137,23,
        1,0,0,0,138,142,3,26,13,0,139,142,3,28,14,0,140,142,5,34,0,0,141,
        138,1,0,0,0,141,139,1,0,0,0,141,140,1,0,0,0,142,25,1,0,0,0,143,144,
        5,17,0,0,144,27,1,0,0,0,145,146,5,18,0,0,146,147,5,25,0,0,147,148,
        3,52,26,0,148,149,5,26,0,0,149,29,1,0,0,0,150,151,5,7,0,0,151,152,
        5,9,0,0,152,153,5,10,0,0,153,154,3,4,2,0,154,155,5,23,0,0,155,156,
        5,1,0,0,156,158,5,3,0,0,157,159,3,32,16,0,158,157,1,0,0,0,159,160,
        1,0,0,0,160,158,1,0,0,0,160,161,1,0,0,0,161,162,1,0,0,0,162,163,
        5,24,0,0,163,31,1,0,0,0,164,165,5,28,0,0,165,166,3,34,17,0,166,169,
        5,25,0,0,167,170,3,36,18,0,168,170,3,38,19,0,169,167,1,0,0,0,169,
        168,1,0,0,0,170,171,1,0,0,0,171,173,5,26,0,0,172,174,5,22,0,0,173,
        172,1,0,0,0,173,174,1,0,0,0,174,175,1,0,0,0,175,177,5,28,0,0,176,
        178,5,27,0,0,177,176,1,0,0,0,177,178,1,0,0,0,178,33,1,0,0,0,179,
        180,5,36,0,0,180,35,1,0,0,0,181,182,3,40,20,0,182,185,5,22,0,0,183,
        186,3,42,21,0,184,186,5,30,0,0,185,183,1,0,0,0,185,184,1,0,0,0,186,
        187,1,0,0,0,187,188,5,22,0,0,188,189,3,44,22,0,189,190,5,22,0,0,
        190,191,3,46,23,0,191,37,1,0,0,0,192,193,3,40,20,0,193,194,5,22,
        0,0,194,195,3,42,21,0,195,196,5,22,0,0,196,197,3,44,22,0,197,198,
        5,22,0,0,198,199,3,46,23,0,199,200,5,22,0,0,200,201,3,48,24,0,201,
        202,5,22,0,0,202,203,3,50,25,0,203,204,5,22,0,0,204,205,3,58,29,
        0,205,39,1,0,0,0,206,207,5,34,0,0,207,41,1,0,0,0,208,213,3,58,29,
        0,209,213,5,25,0,0,210,213,3,56,28,0,211,213,5,26,0,0,212,208,1,
        0,0,0,212,209,1,0,0,0,212,210,1,0,0,0,212,211,1,0,0,0,213,216,1,
        0,0,0,214,212,1,0,0,0,214,215,1,0,0,0,215,43,1,0,0,0,216,214,1,0,
        0,0,217,218,5,34,0,0,218,45,1,0,0,0,219,222,3,58,29,0,220,222,3,
        56,28,0,221,219,1,0,0,0,221,220,1,0,0,0,222,47,1,0,0,0,223,224,3,
        56,28,0,224,49,1,0,0,0,225,226,3,56,28,0,226,51,1,0,0,0,227,228,
        5,36,0,0,228,229,5,19,0,0,229,234,5,36,0,0,230,231,5,36,0,0,231,
        232,5,20,0,0,232,234,5,36,0,0,233,227,1,0,0,0,233,230,1,0,0,0,234,
        53,1,0,0,0,235,237,8,1,0,0,236,235,1,0,0,0,237,238,1,0,0,0,238,236,
        1,0,0,0,238,239,1,0,0,0,239,240,1,0,0,0,240,241,5,24,0,0,241,55,
        1,0,0,0,242,243,5,36,0,0,243,57,1,0,0,0,244,245,5,34,0,0,245,59,
        1,0,0,0,246,247,5,40,0,0,247,61,1,0,0,0,16,66,84,88,122,132,141,
        160,169,173,177,185,212,214,221,233,238
    ]

class CBBsdlParser ( Parser ):

    grammarFileName = "CBBsdl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'entity'", "'end'", "'is'", "'generic'", 
                     "'string'", "'PHYSICAL_PIN_MAP'", "'attribute'", "'BOUNDARY_LENGTH'", 
                     "'BOUNDARY_REGISTER'", "'of'", "'use'", "'port'", "'inout'", 
                     "'in'", "'out'", "'linkage'", "'bit'", "'bit_vector'", 
                     "'to'", "'downto'", "'.'", "','", "':'", "';'", "'('", 
                     "')'", "'&'", "'\"'", "':='", "'*'", "'_'", "'['", 
                     "']'" ]

    symbolicNames = [ "<INVALID>", "ENTITY", "END", "IS", "GENERIC", "STRING", 
                      "PHYSICAL_PIN_MAP", "ATTRIBUTE", "BS_LEN", "BS_REG", 
                      "OF", "USE", "PORT", "INOUT", "IN", "OUT", "LINKAGE", 
                      "BIT", "BIT_VECTOR", "TO", "DOWNTO", "DOT", "COMMA", 
                      "COLON", "SEMICOLON", "BRACKET_OPEN", "BRACKET_CLOSE", 
                      "AMPERSAND", "QUOTES", "EQUALS", "ASTERISK", "UNDERLINE", 
                      "SQUARE_OPEN", "SQUARE_CLOSE", "ID", "REAL_LITERAL", 
                      "INTEGER", "DIGIT", "EXPONENT", "WS", "COMMENT" ]

    RULE_bsdl = 0
    RULE_entity = 1
    RULE_entity_name = 2
    RULE_body = 3
    RULE_generic_phys_pin_map = 4
    RULE_phys_pin_map_name = 5
    RULE_attr_bsr_len = 6
    RULE_bsr_len = 7
    RULE_log_port_desc = 8
    RULE_port_def = 9
    RULE_port_name = 10
    RULE_port_function = 11
    RULE_port_type = 12
    RULE_bit = 13
    RULE_bit_vector = 14
    RULE_attr_bsr = 15
    RULE_bsr_def = 16
    RULE_data_cell = 17
    RULE_bsr_cell0 = 18
    RULE_bsr_cell1 = 19
    RULE_cell_type = 20
    RULE_cell_desc = 21
    RULE_cell_func = 22
    RULE_cell_val = 23
    RULE_ctrl_cell = 24
    RULE_disval = 25
    RULE_bit_range = 26
    RULE_undef_part = 27
    RULE_number = 28
    RULE_identifier = 29
    RULE_comment = 30

    ruleNames =  [ "bsdl", "entity", "entity_name", "body", "generic_phys_pin_map", 
                   "phys_pin_map_name", "attr_bsr_len", "bsr_len", "log_port_desc", 
                   "port_def", "port_name", "port_function", "port_type", 
                   "bit", "bit_vector", "attr_bsr", "bsr_def", "data_cell", 
                   "bsr_cell0", "bsr_cell1", "cell_type", "cell_desc", "cell_func", 
                   "cell_val", "ctrl_cell", "disval", "bit_range", "undef_part", 
                   "number", "identifier", "comment" ]

    EOF = Token.EOF
    ENTITY=1
    END=2
    IS=3
    GENERIC=4
    STRING=5
    PHYSICAL_PIN_MAP=6
    ATTRIBUTE=7
    BS_LEN=8
    BS_REG=9
    OF=10
    USE=11
    PORT=12
    INOUT=13
    IN=14
    OUT=15
    LINKAGE=16
    BIT=17
    BIT_VECTOR=18
    TO=19
    DOWNTO=20
    DOT=21
    COMMA=22
    COLON=23
    SEMICOLON=24
    BRACKET_OPEN=25
    BRACKET_CLOSE=26
    AMPERSAND=27
    QUOTES=28
    EQUALS=29
    ASTERISK=30
    UNDERLINE=31
    SQUARE_OPEN=32
    SQUARE_CLOSE=33
    ID=34
    REAL_LITERAL=35
    INTEGER=36
    DIGIT=37
    EXPONENT=38
    WS=39
    COMMENT=40

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class BsdlContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def entity(self):
            return self.getTypedRuleContext(CBBsdlParser.EntityContext,0)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.CommentContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.CommentContext,i)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_bsdl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBsdl" ):
                listener.enterBsdl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBsdl" ):
                listener.exitBsdl(self)




    def bsdl(self):

        localctx = CBBsdlParser.BsdlContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_bsdl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 62
            self.entity()
            self.state = 66
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==40:
                self.state = 63
                self.comment()
                self.state = 68
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EntityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ENTITY(self):
            return self.getToken(CBBsdlParser.ENTITY, 0)

        def entity_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Entity_nameContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Entity_nameContext,i)


        def IS(self):
            return self.getToken(CBBsdlParser.IS, 0)

        def body(self):
            return self.getTypedRuleContext(CBBsdlParser.BodyContext,0)


        def END(self):
            return self.getToken(CBBsdlParser.END, 0)

        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_entity

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEntity" ):
                listener.enterEntity(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEntity" ):
                listener.exitEntity(self)




    def entity(self):

        localctx = CBBsdlParser.EntityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_entity)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 69
            self.match(CBBsdlParser.ENTITY)
            self.state = 70
            self.entity_name()
            self.state = 71
            self.match(CBBsdlParser.IS)
            self.state = 72
            self.body()
            self.state = 73
            self.match(CBBsdlParser.END)
            self.state = 74
            self.entity_name()
            self.state = 75
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Entity_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_entity_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEntity_name" ):
                listener.enterEntity_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEntity_name" ):
                listener.exitEntity_name(self)




    def entity_name(self):

        localctx = CBBsdlParser.Entity_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_entity_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 77
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def generic_phys_pin_map(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Generic_phys_pin_mapContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Generic_phys_pin_mapContext,i)


        def log_port_desc(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Log_port_descContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Log_port_descContext,i)


        def attr_bsr_len(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Attr_bsr_lenContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Attr_bsr_lenContext,i)


        def attr_bsr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Attr_bsrContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Attr_bsrContext,i)


        def undef_part(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Undef_partContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Undef_partContext,i)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBody" ):
                listener.enterBody(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBody" ):
                listener.exitBody(self)




    def body(self):

        localctx = CBBsdlParser.BodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 88
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 84
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                    if la_ == 1:
                        self.state = 79
                        self.generic_phys_pin_map()
                        pass

                    elif la_ == 2:
                        self.state = 80
                        self.log_port_desc()
                        pass

                    elif la_ == 3:
                        self.state = 81
                        self.attr_bsr_len()
                        pass

                    elif la_ == 4:
                        self.state = 82
                        self.attr_bsr()
                        pass

                    elif la_ == 5:
                        self.state = 83
                        self.undef_part()
                        pass

             
                self.state = 90
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Generic_phys_pin_mapContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GENERIC(self):
            return self.getToken(CBBsdlParser.GENERIC, 0)

        def BRACKET_OPEN(self):
            return self.getToken(CBBsdlParser.BRACKET_OPEN, 0)

        def PHYSICAL_PIN_MAP(self):
            return self.getToken(CBBsdlParser.PHYSICAL_PIN_MAP, 0)

        def COLON(self):
            return self.getToken(CBBsdlParser.COLON, 0)

        def STRING(self):
            return self.getToken(CBBsdlParser.STRING, 0)

        def EQUALS(self):
            return self.getToken(CBBsdlParser.EQUALS, 0)

        def QUOTES(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.QUOTES)
            else:
                return self.getToken(CBBsdlParser.QUOTES, i)

        def phys_pin_map_name(self):
            return self.getTypedRuleContext(CBBsdlParser.Phys_pin_map_nameContext,0)


        def BRACKET_CLOSE(self):
            return self.getToken(CBBsdlParser.BRACKET_CLOSE, 0)

        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_generic_phys_pin_map

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGeneric_phys_pin_map" ):
                listener.enterGeneric_phys_pin_map(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGeneric_phys_pin_map" ):
                listener.exitGeneric_phys_pin_map(self)




    def generic_phys_pin_map(self):

        localctx = CBBsdlParser.Generic_phys_pin_mapContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_generic_phys_pin_map)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 91
            self.match(CBBsdlParser.GENERIC)
            self.state = 92
            self.match(CBBsdlParser.BRACKET_OPEN)
            self.state = 93
            self.match(CBBsdlParser.PHYSICAL_PIN_MAP)
            self.state = 94
            self.match(CBBsdlParser.COLON)
            self.state = 95
            self.match(CBBsdlParser.STRING)
            self.state = 96
            self.match(CBBsdlParser.EQUALS)
            self.state = 97
            self.match(CBBsdlParser.QUOTES)
            self.state = 98
            self.phys_pin_map_name()
            self.state = 99
            self.match(CBBsdlParser.QUOTES)
            self.state = 100
            self.match(CBBsdlParser.BRACKET_CLOSE)
            self.state = 101
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Phys_pin_map_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_phys_pin_map_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPhys_pin_map_name" ):
                listener.enterPhys_pin_map_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPhys_pin_map_name" ):
                listener.exitPhys_pin_map_name(self)




    def phys_pin_map_name(self):

        localctx = CBBsdlParser.Phys_pin_map_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_phys_pin_map_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 103
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Attr_bsr_lenContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATTRIBUTE(self):
            return self.getToken(CBBsdlParser.ATTRIBUTE, 0)

        def BS_LEN(self):
            return self.getToken(CBBsdlParser.BS_LEN, 0)

        def OF(self):
            return self.getToken(CBBsdlParser.OF, 0)

        def entity_name(self):
            return self.getTypedRuleContext(CBBsdlParser.Entity_nameContext,0)


        def COLON(self):
            return self.getToken(CBBsdlParser.COLON, 0)

        def ENTITY(self):
            return self.getToken(CBBsdlParser.ENTITY, 0)

        def IS(self):
            return self.getToken(CBBsdlParser.IS, 0)

        def bsr_len(self):
            return self.getTypedRuleContext(CBBsdlParser.Bsr_lenContext,0)


        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_attr_bsr_len

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttr_bsr_len" ):
                listener.enterAttr_bsr_len(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttr_bsr_len" ):
                listener.exitAttr_bsr_len(self)




    def attr_bsr_len(self):

        localctx = CBBsdlParser.Attr_bsr_lenContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_attr_bsr_len)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 105
            self.match(CBBsdlParser.ATTRIBUTE)
            self.state = 106
            self.match(CBBsdlParser.BS_LEN)
            self.state = 107
            self.match(CBBsdlParser.OF)
            self.state = 108
            self.entity_name()
            self.state = 109
            self.match(CBBsdlParser.COLON)
            self.state = 110
            self.match(CBBsdlParser.ENTITY)
            self.state = 111
            self.match(CBBsdlParser.IS)
            self.state = 112
            self.bsr_len()
            self.state = 113
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bsr_lenContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(CBBsdlParser.NumberContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_bsr_len

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBsr_len" ):
                listener.enterBsr_len(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBsr_len" ):
                listener.exitBsr_len(self)




    def bsr_len(self):

        localctx = CBBsdlParser.Bsr_lenContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_bsr_len)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 115
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Log_port_descContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PORT(self):
            return self.getToken(CBBsdlParser.PORT, 0)

        def BRACKET_OPEN(self):
            return self.getToken(CBBsdlParser.BRACKET_OPEN, 0)

        def BRACKET_CLOSE(self):
            return self.getToken(CBBsdlParser.BRACKET_CLOSE, 0)

        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def port_def(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Port_defContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Port_defContext,i)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_log_port_desc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLog_port_desc" ):
                listener.enterLog_port_desc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLog_port_desc" ):
                listener.exitLog_port_desc(self)




    def log_port_desc(self):

        localctx = CBBsdlParser.Log_port_descContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_log_port_desc)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self.match(CBBsdlParser.PORT)
            self.state = 118
            self.match(CBBsdlParser.BRACKET_OPEN)
            self.state = 120 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 119
                self.port_def()
                self.state = 122 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==34):
                    break

            self.state = 124
            self.match(CBBsdlParser.BRACKET_CLOSE)
            self.state = 125
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Port_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def port_name(self):
            return self.getTypedRuleContext(CBBsdlParser.Port_nameContext,0)


        def COLON(self):
            return self.getToken(CBBsdlParser.COLON, 0)

        def port_function(self):
            return self.getTypedRuleContext(CBBsdlParser.Port_functionContext,0)


        def port_type(self):
            return self.getTypedRuleContext(CBBsdlParser.Port_typeContext,0)


        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_port_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPort_def" ):
                listener.enterPort_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPort_def" ):
                listener.exitPort_def(self)




    def port_def(self):

        localctx = CBBsdlParser.Port_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_port_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 127
            self.port_name()
            self.state = 128
            self.match(CBBsdlParser.COLON)
            self.state = 129
            self.port_function()
            self.state = 130
            self.port_type()
            self.state = 132
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 131
                self.match(CBBsdlParser.SEMICOLON)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Port_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_port_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPort_name" ):
                listener.enterPort_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPort_name" ):
                listener.exitPort_name(self)




    def port_name(self):

        localctx = CBBsdlParser.Port_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_port_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 134
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Port_functionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INOUT(self):
            return self.getToken(CBBsdlParser.INOUT, 0)

        def IN(self):
            return self.getToken(CBBsdlParser.IN, 0)

        def OUT(self):
            return self.getToken(CBBsdlParser.OUT, 0)

        def LINKAGE(self):
            return self.getToken(CBBsdlParser.LINKAGE, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_port_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPort_function" ):
                listener.enterPort_function(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPort_function" ):
                listener.exitPort_function(self)




    def port_function(self):

        localctx = CBBsdlParser.Port_functionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_port_function)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 136
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 122880) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Port_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def bit(self):
            return self.getTypedRuleContext(CBBsdlParser.BitContext,0)


        def bit_vector(self):
            return self.getTypedRuleContext(CBBsdlParser.Bit_vectorContext,0)


        def ID(self):
            return self.getToken(CBBsdlParser.ID, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_port_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPort_type" ):
                listener.enterPort_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPort_type" ):
                listener.exitPort_type(self)




    def port_type(self):

        localctx = CBBsdlParser.Port_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_port_type)
        try:
            self.state = 141
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [17]:
                self.enterOuterAlt(localctx, 1)
                self.state = 138
                self.bit()
                pass
            elif token in [18]:
                self.enterOuterAlt(localctx, 2)
                self.state = 139
                self.bit_vector()
                pass
            elif token in [34]:
                self.enterOuterAlt(localctx, 3)
                self.state = 140
                self.match(CBBsdlParser.ID)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BitContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BIT(self):
            return self.getToken(CBBsdlParser.BIT, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_bit

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBit" ):
                listener.enterBit(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBit" ):
                listener.exitBit(self)




    def bit(self):

        localctx = CBBsdlParser.BitContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_bit)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 143
            self.match(CBBsdlParser.BIT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bit_vectorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BIT_VECTOR(self):
            return self.getToken(CBBsdlParser.BIT_VECTOR, 0)

        def BRACKET_OPEN(self):
            return self.getToken(CBBsdlParser.BRACKET_OPEN, 0)

        def bit_range(self):
            return self.getTypedRuleContext(CBBsdlParser.Bit_rangeContext,0)


        def BRACKET_CLOSE(self):
            return self.getToken(CBBsdlParser.BRACKET_CLOSE, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_bit_vector

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBit_vector" ):
                listener.enterBit_vector(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBit_vector" ):
                listener.exitBit_vector(self)




    def bit_vector(self):

        localctx = CBBsdlParser.Bit_vectorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_bit_vector)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 145
            self.match(CBBsdlParser.BIT_VECTOR)
            self.state = 146
            self.match(CBBsdlParser.BRACKET_OPEN)
            self.state = 147
            self.bit_range()
            self.state = 148
            self.match(CBBsdlParser.BRACKET_CLOSE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Attr_bsrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATTRIBUTE(self):
            return self.getToken(CBBsdlParser.ATTRIBUTE, 0)

        def BS_REG(self):
            return self.getToken(CBBsdlParser.BS_REG, 0)

        def OF(self):
            return self.getToken(CBBsdlParser.OF, 0)

        def entity_name(self):
            return self.getTypedRuleContext(CBBsdlParser.Entity_nameContext,0)


        def COLON(self):
            return self.getToken(CBBsdlParser.COLON, 0)

        def ENTITY(self):
            return self.getToken(CBBsdlParser.ENTITY, 0)

        def IS(self):
            return self.getToken(CBBsdlParser.IS, 0)

        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def bsr_def(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Bsr_defContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Bsr_defContext,i)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_attr_bsr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttr_bsr" ):
                listener.enterAttr_bsr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttr_bsr" ):
                listener.exitAttr_bsr(self)




    def attr_bsr(self):

        localctx = CBBsdlParser.Attr_bsrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_attr_bsr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            self.match(CBBsdlParser.ATTRIBUTE)
            self.state = 151
            self.match(CBBsdlParser.BS_REG)
            self.state = 152
            self.match(CBBsdlParser.OF)
            self.state = 153
            self.entity_name()
            self.state = 154
            self.match(CBBsdlParser.COLON)
            self.state = 155
            self.match(CBBsdlParser.ENTITY)
            self.state = 156
            self.match(CBBsdlParser.IS)
            self.state = 158 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 157
                self.bsr_def()
                self.state = 160 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==28):
                    break

            self.state = 162
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bsr_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTES(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.QUOTES)
            else:
                return self.getToken(CBBsdlParser.QUOTES, i)

        def data_cell(self):
            return self.getTypedRuleContext(CBBsdlParser.Data_cellContext,0)


        def BRACKET_OPEN(self):
            return self.getToken(CBBsdlParser.BRACKET_OPEN, 0)

        def BRACKET_CLOSE(self):
            return self.getToken(CBBsdlParser.BRACKET_CLOSE, 0)

        def bsr_cell0(self):
            return self.getTypedRuleContext(CBBsdlParser.Bsr_cell0Context,0)


        def bsr_cell1(self):
            return self.getTypedRuleContext(CBBsdlParser.Bsr_cell1Context,0)


        def COMMA(self):
            return self.getToken(CBBsdlParser.COMMA, 0)

        def AMPERSAND(self):
            return self.getToken(CBBsdlParser.AMPERSAND, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_bsr_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBsr_def" ):
                listener.enterBsr_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBsr_def" ):
                listener.exitBsr_def(self)




    def bsr_def(self):

        localctx = CBBsdlParser.Bsr_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_bsr_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 164
            self.match(CBBsdlParser.QUOTES)
            self.state = 165
            self.data_cell()
            self.state = 166
            self.match(CBBsdlParser.BRACKET_OPEN)
            self.state = 169
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                self.state = 167
                self.bsr_cell0()
                pass

            elif la_ == 2:
                self.state = 168
                self.bsr_cell1()
                pass


            self.state = 171
            self.match(CBBsdlParser.BRACKET_CLOSE)
            self.state = 173
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==22:
                self.state = 172
                self.match(CBBsdlParser.COMMA)


            self.state = 175
            self.match(CBBsdlParser.QUOTES)
            self.state = 177
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27:
                self.state = 176
                self.match(CBBsdlParser.AMPERSAND)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Data_cellContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self):
            return self.getToken(CBBsdlParser.INTEGER, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_data_cell

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterData_cell" ):
                listener.enterData_cell(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitData_cell" ):
                listener.exitData_cell(self)




    def data_cell(self):

        localctx = CBBsdlParser.Data_cellContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_data_cell)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 179
            self.match(CBBsdlParser.INTEGER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bsr_cell0Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def cell_type(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_typeContext,0)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.COMMA)
            else:
                return self.getToken(CBBsdlParser.COMMA, i)

        def cell_func(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_funcContext,0)


        def cell_val(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_valContext,0)


        def cell_desc(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_descContext,0)


        def ASTERISK(self):
            return self.getToken(CBBsdlParser.ASTERISK, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_bsr_cell0

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBsr_cell0" ):
                listener.enterBsr_cell0(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBsr_cell0" ):
                listener.exitBsr_cell0(self)




    def bsr_cell0(self):

        localctx = CBBsdlParser.Bsr_cell0Context(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_bsr_cell0)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 181
            self.cell_type()
            self.state = 182
            self.match(CBBsdlParser.COMMA)
            self.state = 185
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [22, 25, 26, 34, 36]:
                self.state = 183
                self.cell_desc()
                pass
            elif token in [30]:
                self.state = 184
                self.match(CBBsdlParser.ASTERISK)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 187
            self.match(CBBsdlParser.COMMA)
            self.state = 188
            self.cell_func()
            self.state = 189
            self.match(CBBsdlParser.COMMA)
            self.state = 190
            self.cell_val()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bsr_cell1Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def cell_type(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_typeContext,0)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.COMMA)
            else:
                return self.getToken(CBBsdlParser.COMMA, i)

        def cell_desc(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_descContext,0)


        def cell_func(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_funcContext,0)


        def cell_val(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_valContext,0)


        def ctrl_cell(self):
            return self.getTypedRuleContext(CBBsdlParser.Ctrl_cellContext,0)


        def disval(self):
            return self.getTypedRuleContext(CBBsdlParser.DisvalContext,0)


        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_bsr_cell1

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBsr_cell1" ):
                listener.enterBsr_cell1(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBsr_cell1" ):
                listener.exitBsr_cell1(self)




    def bsr_cell1(self):

        localctx = CBBsdlParser.Bsr_cell1Context(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_bsr_cell1)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 192
            self.cell_type()
            self.state = 193
            self.match(CBBsdlParser.COMMA)
            self.state = 194
            self.cell_desc()
            self.state = 195
            self.match(CBBsdlParser.COMMA)
            self.state = 196
            self.cell_func()
            self.state = 197
            self.match(CBBsdlParser.COMMA)
            self.state = 198
            self.cell_val()
            self.state = 199
            self.match(CBBsdlParser.COMMA)
            self.state = 200
            self.ctrl_cell()
            self.state = 201
            self.match(CBBsdlParser.COMMA)
            self.state = 202
            self.disval()
            self.state = 203
            self.match(CBBsdlParser.COMMA)
            self.state = 204
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cell_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(CBBsdlParser.ID, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_cell_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCell_type" ):
                listener.enterCell_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCell_type" ):
                listener.exitCell_type(self)




    def cell_type(self):

        localctx = CBBsdlParser.Cell_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_cell_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 206
            self.match(CBBsdlParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cell_descContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.IdentifierContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,i)


        def BRACKET_OPEN(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.BRACKET_OPEN)
            else:
                return self.getToken(CBBsdlParser.BRACKET_OPEN, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.NumberContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.NumberContext,i)


        def BRACKET_CLOSE(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.BRACKET_CLOSE)
            else:
                return self.getToken(CBBsdlParser.BRACKET_CLOSE, i)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_cell_desc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCell_desc" ):
                listener.enterCell_desc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCell_desc" ):
                listener.exitCell_desc(self)




    def cell_desc(self):

        localctx = CBBsdlParser.Cell_descContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_cell_desc)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 214
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 86000009216) != 0):
                self.state = 212
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [34]:
                    self.state = 208
                    self.identifier()
                    pass
                elif token in [25]:
                    self.state = 209
                    self.match(CBBsdlParser.BRACKET_OPEN)
                    pass
                elif token in [36]:
                    self.state = 210
                    self.number()
                    pass
                elif token in [26]:
                    self.state = 211
                    self.match(CBBsdlParser.BRACKET_CLOSE)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 216
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cell_funcContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(CBBsdlParser.ID, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_cell_func

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCell_func" ):
                listener.enterCell_func(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCell_func" ):
                listener.exitCell_func(self)




    def cell_func(self):

        localctx = CBBsdlParser.Cell_funcContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_cell_func)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 217
            self.match(CBBsdlParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cell_valContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def number(self):
            return self.getTypedRuleContext(CBBsdlParser.NumberContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_cell_val

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCell_val" ):
                listener.enterCell_val(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCell_val" ):
                listener.exitCell_val(self)




    def cell_val(self):

        localctx = CBBsdlParser.Cell_valContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_cell_val)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 221
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [34]:
                self.state = 219
                self.identifier()
                pass
            elif token in [36]:
                self.state = 220
                self.number()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ctrl_cellContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(CBBsdlParser.NumberContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_ctrl_cell

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCtrl_cell" ):
                listener.enterCtrl_cell(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCtrl_cell" ):
                listener.exitCtrl_cell(self)




    def ctrl_cell(self):

        localctx = CBBsdlParser.Ctrl_cellContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_ctrl_cell)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 223
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DisvalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(CBBsdlParser.NumberContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_disval

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDisval" ):
                listener.enterDisval(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDisval" ):
                listener.exitDisval(self)




    def disval(self):

        localctx = CBBsdlParser.DisvalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_disval)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 225
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bit_rangeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.INTEGER)
            else:
                return self.getToken(CBBsdlParser.INTEGER, i)

        def TO(self):
            return self.getToken(CBBsdlParser.TO, 0)

        def DOWNTO(self):
            return self.getToken(CBBsdlParser.DOWNTO, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_bit_range

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBit_range" ):
                listener.enterBit_range(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBit_range" ):
                listener.exitBit_range(self)




    def bit_range(self):

        localctx = CBBsdlParser.Bit_rangeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_bit_range)
        try:
            self.state = 233
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 227
                self.match(CBBsdlParser.INTEGER)
                self.state = 228
                self.match(CBBsdlParser.TO)
                self.state = 229
                self.match(CBBsdlParser.INTEGER)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 230
                self.match(CBBsdlParser.INTEGER)
                self.state = 231
                self.match(CBBsdlParser.DOWNTO)
                self.state = 232
                self.match(CBBsdlParser.INTEGER)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Undef_partContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SEMICOLON(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.SEMICOLON)
            else:
                return self.getToken(CBBsdlParser.SEMICOLON, i)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_undef_part

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUndef_part" ):
                listener.enterUndef_part(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUndef_part" ):
                listener.exitUndef_part(self)




    def undef_part(self):

        localctx = CBBsdlParser.Undef_partContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_undef_part)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 236 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 235
                _la = self._input.LA(1)
                if _la <= 0 or _la==24:
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 238 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 2199006478334) != 0)):
                    break

            self.state = 240
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self):
            return self.getToken(CBBsdlParser.INTEGER, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = CBBsdlParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_number)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 242
            self.match(CBBsdlParser.INTEGER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(CBBsdlParser.ID, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_identifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifier" ):
                listener.enterIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifier" ):
                listener.exitIdentifier(self)




    def identifier(self):

        localctx = CBBsdlParser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_identifier)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 244
            self.match(CBBsdlParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(CBBsdlParser.COMMENT, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)




    def comment(self):

        localctx = CBBsdlParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_comment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 246
            self.match(CBBsdlParser.COMMENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





