

install antlr4

sudo apt install antlr4
