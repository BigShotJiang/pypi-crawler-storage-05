__author__ = "Thomas Popp, Thomas@chriesibaum.com"
__copyright__ = "Copyright 2025, Chriesibaum GmbH"
__version__ = "0.3.0"