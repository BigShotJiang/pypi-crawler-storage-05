"""akron - Simple universal ORM (MVP)

Expose akron class and package version.
"""
from .orm import Akron

__all__ = ["akron"]
__version__ = "0.1.2"
