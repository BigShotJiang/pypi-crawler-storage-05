def thingy() -> None:
    print("biden blast")
