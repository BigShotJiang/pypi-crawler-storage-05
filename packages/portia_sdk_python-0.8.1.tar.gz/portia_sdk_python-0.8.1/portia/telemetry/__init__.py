"""Telemetry package for capturing anonymized usage data."""
