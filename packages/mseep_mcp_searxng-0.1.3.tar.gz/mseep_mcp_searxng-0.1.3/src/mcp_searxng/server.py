from mcp.server import Server

__all__ = ["server"]

server = Server("searxng")
