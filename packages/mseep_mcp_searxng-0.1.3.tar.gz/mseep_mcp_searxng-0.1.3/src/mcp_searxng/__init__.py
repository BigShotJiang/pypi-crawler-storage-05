import asyncio
from mcp_searxng.main import run

def main() -> None:
    asyncio.run(run())