"""Template files for CLI init commands."""
