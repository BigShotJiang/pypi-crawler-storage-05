from turbocore.xdebug.tools.receiver import main


if __name__ == "__main__":
    main()
