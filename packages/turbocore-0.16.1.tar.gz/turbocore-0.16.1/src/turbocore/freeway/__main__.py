from turbocore.freeway import main
import os

if __name__ == "__main__":
    main()
