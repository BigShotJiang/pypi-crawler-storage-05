# UploadFileType


## Enum

* `BINARY` (value: `'BINARY'`)

* `DEBUG` (value: `'DEBUG'`)

* `PACKED` (value: `'PACKED'`)

* `FIRMWARE` (value: `'FIRMWARE'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


