// This code is GPLed by Yan Shoshitaishvili

#ifndef __COMMON_H
#define __COMMON_H

extern int log_level;

void pyvex_debug(const char *, ...);
void pyvex_info(const char *, ...);
void pyvex_error(const char *, ...);

#endif
