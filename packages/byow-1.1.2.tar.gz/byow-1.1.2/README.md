# Bring your own Weight (BYOW)

This is a python framework that allows you to build LLM of your architecture using yaml and you can either train them from scratch or bring your own weight