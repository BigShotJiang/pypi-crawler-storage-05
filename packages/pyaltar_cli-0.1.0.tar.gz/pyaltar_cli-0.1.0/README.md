# Altar CLI

A CLI for managing Altar UI components to your project.