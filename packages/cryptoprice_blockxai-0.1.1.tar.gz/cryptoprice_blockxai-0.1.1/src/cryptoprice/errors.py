class CryptoPriceError(Exception):
    """Base exception for the cryptoprice SDK."""
    pass
