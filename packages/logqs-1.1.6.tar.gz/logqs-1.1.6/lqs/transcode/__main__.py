import fire

from lqs.transcode import Transcode


def main():
    fire.Fire(Transcode)


if __name__ == "__main__":
    main()
