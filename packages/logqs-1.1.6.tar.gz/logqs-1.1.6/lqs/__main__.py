import fire

from lqs import LogQS


def main():
    fire.Fire(LogQS)


if __name__ == "__main__":
    main()
