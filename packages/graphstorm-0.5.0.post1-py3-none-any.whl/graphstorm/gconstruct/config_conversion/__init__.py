"""
This module contains the classes to convert different specifications to GConstruct
"""

from .gsprocessing_converter import GSProcessingConfigConverter
