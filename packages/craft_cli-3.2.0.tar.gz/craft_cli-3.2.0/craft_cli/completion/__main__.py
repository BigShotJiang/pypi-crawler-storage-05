"""Bash completion script generation script."""

from .completion import main

main()
