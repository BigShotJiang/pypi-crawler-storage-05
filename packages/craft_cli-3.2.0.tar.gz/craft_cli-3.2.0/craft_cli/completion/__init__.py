"""Bash completion script generation module."""

from .completion import complete


__all__ = [
    "complete",
]
