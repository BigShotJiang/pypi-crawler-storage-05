.. _how-to-guides:

How-to guides
=============

.. toctree::
    :maxdepth: 1

    change-logfile
    change-return-code
    create-hidden-options
    raise-helpful-errors
    set-default-command
    unit-test-with-emitter
    use-global-args
    use-the-completion-module
    yield-terminal-control
