from agno.models.dashscope.dashscope import DashScope as Qwen

__all__ = [
    "Qwen",
]
