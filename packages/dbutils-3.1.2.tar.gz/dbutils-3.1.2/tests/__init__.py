"""The DBUtils tests package."""

# make sure the mock pg module is installed
from . import mock_pg as pg  # noqa: F401
