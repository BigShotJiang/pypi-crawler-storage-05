"""The DBUtils main package."""

__all__ = ["__version__"]

__version__ = "3.1.2"
