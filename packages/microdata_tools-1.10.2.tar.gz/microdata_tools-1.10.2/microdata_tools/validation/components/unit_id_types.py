from typing import Union

from microdata_tools.validation.exceptions import UnregisteredUnitTypeError
from microdata_tools.validation.model.metadata import UnitIdType, UnitType

# When updating this dictionary remember to also
# update the Metadata model with the
# same key value in the enum for unitType
UNIT_ID_TYPE_FOR_UNIT_TYPE = {
    UnitType.JOBB: UnitIdType.JOBBID_1,
    UnitType.KJORETOY: UnitIdType.KJORETOY_ID,
    UnitType.FAMILIE: UnitIdType.FNR,
    UnitType.FORETAK: UnitIdType.ORGNR,
    UnitType.HUSHOLDNING: UnitIdType.FNR,
    UnitType.KOMMUNE: None,
    UnitType.KURS: UnitIdType.KURSID,
    UnitType.PERSON: UnitIdType.FNR,
    UnitType.VIRKSOMHET: UnitIdType.ORGNR,
    UnitType.BK_HELSESTASJONSKONSULTASJON: None,
    UnitType.NPR_EPISODE: UnitIdType.NPR_EPISODE_ID,
    UnitType.NPR_SYKEHUSOPPHOLD: UnitIdType.NPR_SYKEHUSOPPHOLD_ID,
    UnitType.HKDIR_STUDIESOKNAD: UnitIdType.HKDIR_STUDIESOKNAD_ID,
    UnitType.HKDIR_HYU_OPPMELDING: UnitIdType.HKDIR_HYU_OPPMELDING_ID,
    UnitType.SOSTIL: UnitIdType.SOSTIL_ID,
    UnitType.TRAFIKKULYKKE: UnitIdType.TRAFIKKULYKKE_ID,
    UnitType.TRAFIKKULYKKE_PERSON: UnitIdType.TRAFIKKULYKKE_PERSON_ID,
    UnitType.MALEPUNKT: UnitIdType.MALEPUNKT_ID,
    UnitType.KRG_KREFTTILFELLE: UnitIdType.KRG_TILFELLEID,
    UnitType.FENGSLINGER_TILGANG: UnitIdType.FENGSLINGER_TILGANG_ID,
    UnitType.SOESKEN: UnitIdType.FNR,
    UnitType.BEDRIFT: UnitIdType.ORGNR,
}


def get(unit_type: UnitType) -> Union[UnitIdType, None]:
    try:
        return UNIT_ID_TYPE_FOR_UNIT_TYPE[unit_type]
    except KeyError as e:
        raise UnregisteredUnitTypeError(f"No such unit type: {str(e)}") from e
