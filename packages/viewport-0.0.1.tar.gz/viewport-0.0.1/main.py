def main():
    print("Hello from viewport!")


if __name__ == "__main__":
    main()
