from janito.performance_collector import PerformanceCollector

performance_collector = PerformanceCollector()
