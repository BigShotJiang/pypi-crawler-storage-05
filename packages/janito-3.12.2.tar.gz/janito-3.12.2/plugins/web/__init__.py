"""
Web Tools Plugin Package

Contains web scraping, browsing, and URL operations.
"""

__all__ = ["webtools"]
