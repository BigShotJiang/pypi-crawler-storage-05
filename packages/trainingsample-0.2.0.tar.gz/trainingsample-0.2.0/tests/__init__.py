"""Test suite for training_sample_rust package."""
