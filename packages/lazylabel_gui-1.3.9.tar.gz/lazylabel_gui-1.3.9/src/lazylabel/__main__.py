"""Allow LazyLabel to be run as a module with python -m lazylabel."""

from .main import main

if __name__ == "__main__":
    main()
