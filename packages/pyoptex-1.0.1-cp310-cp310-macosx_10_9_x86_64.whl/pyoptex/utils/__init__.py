from .factor import Factor
