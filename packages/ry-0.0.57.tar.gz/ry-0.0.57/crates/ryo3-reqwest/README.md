# `ryo3-reqwest`

Wrapper around the `reqwest` crate for Python.

**NOT YET IMPLEMENTED**

REF: <https://docs.rs/reqwest/latest/reqwest>/
