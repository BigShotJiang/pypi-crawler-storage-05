# `ryo3-unindent`

python + `unindent` crate.

`unindent`:

- [crates.io](https://crates.io/crates/unindent)
- [docs.rs](https://docs.rs/unindent)
