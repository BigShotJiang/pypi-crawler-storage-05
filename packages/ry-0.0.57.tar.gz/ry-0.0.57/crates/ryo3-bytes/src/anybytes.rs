//! TODO anybytes that auto converts to rust-bytes or py-bytes
