# SPDX-FileCopyrightText: 2023-present Chris O'Neill <chris@purplejay.io>
#
# SPDX-License-Identifier: MIT

from loguru import logger

logger.disable("pjdev_message_broker")
