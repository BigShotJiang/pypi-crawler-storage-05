============================
 Class-based event handlers
============================

.. automodule:: zope.event.classhandler
    :no-members:

.. autofunction:: handler(event_class, [handler])
