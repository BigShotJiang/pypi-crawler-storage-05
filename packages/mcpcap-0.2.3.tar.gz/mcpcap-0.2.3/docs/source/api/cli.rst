Command Line Interface
======================

The CLI module handles command-line argument parsing and application entry points.

CLI Module
----------

.. automodule:: mcpcap.cli
   :members:
   :undoc-members:
   :show-inheritance: