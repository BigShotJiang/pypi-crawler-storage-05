# Generated from CBBsdl.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,42,307,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,1,0,1,0,5,0,75,8,0,10,0,12,0,78,9,0,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,2,1,3,1,3,1,3,1,3,1,3,1,3,3,3,
        96,8,3,5,3,98,8,3,10,3,12,3,101,9,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,
        1,4,1,4,1,4,1,4,1,4,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,
        1,6,1,7,1,7,1,8,1,8,1,8,4,8,132,8,8,11,8,12,8,133,1,8,1,8,1,8,1,
        9,1,9,1,9,1,9,1,9,3,9,144,8,9,1,10,1,10,1,11,1,11,1,12,1,12,1,12,
        3,12,153,8,12,1,13,1,13,1,14,1,14,1,14,1,14,1,14,1,15,1,15,1,15,
        1,15,1,15,1,15,4,15,168,8,15,11,15,12,15,169,1,15,1,15,1,16,3,16,
        175,8,16,1,16,1,16,1,16,1,16,3,16,181,8,16,1,16,3,16,184,8,16,1,
        16,3,16,187,8,16,1,16,3,16,190,8,16,1,17,1,17,1,18,1,18,3,18,196,
        8,18,1,19,1,19,1,19,3,19,201,8,19,4,19,203,8,19,11,19,12,19,204,
        1,19,1,19,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,4,20,217,8,20,
        11,20,12,20,218,1,20,1,20,1,21,1,21,1,21,1,21,1,21,3,21,228,8,21,
        1,21,1,21,3,21,232,8,21,1,21,1,21,3,21,236,8,21,1,22,1,22,1,23,1,
        23,1,23,1,23,3,23,244,8,23,1,23,1,23,1,23,1,23,1,23,1,24,1,24,1,
        24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,25,1,
        25,1,26,1,26,1,26,1,26,5,26,271,8,26,10,26,12,26,274,9,26,1,27,1,
        27,1,28,1,28,3,28,280,8,28,1,29,1,29,1,30,1,30,1,31,1,31,1,31,1,
        31,1,31,1,31,3,31,292,8,31,1,32,4,32,295,8,32,11,32,12,32,296,1,
        32,1,32,1,33,1,33,1,34,1,34,1,35,1,35,1,35,0,0,36,0,2,4,6,8,10,12,
        14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,
        58,60,62,64,66,68,70,0,2,1,0,15,18,1,0,26,26,302,0,72,1,0,0,0,2,
        79,1,0,0,0,4,87,1,0,0,0,6,99,1,0,0,0,8,102,1,0,0,0,10,114,1,0,0,
        0,12,116,1,0,0,0,14,126,1,0,0,0,16,128,1,0,0,0,18,138,1,0,0,0,20,
        145,1,0,0,0,22,147,1,0,0,0,24,152,1,0,0,0,26,154,1,0,0,0,28,156,
        1,0,0,0,30,161,1,0,0,0,32,174,1,0,0,0,34,191,1,0,0,0,36,195,1,0,
        0,0,38,197,1,0,0,0,40,208,1,0,0,0,42,222,1,0,0,0,44,237,1,0,0,0,
        46,239,1,0,0,0,48,250,1,0,0,0,50,264,1,0,0,0,52,272,1,0,0,0,54,275,
        1,0,0,0,56,279,1,0,0,0,58,281,1,0,0,0,60,283,1,0,0,0,62,291,1,0,
        0,0,64,294,1,0,0,0,66,300,1,0,0,0,68,302,1,0,0,0,70,304,1,0,0,0,
        72,76,3,2,1,0,73,75,3,70,35,0,74,73,1,0,0,0,75,78,1,0,0,0,76,74,
        1,0,0,0,76,77,1,0,0,0,77,1,1,0,0,0,78,76,1,0,0,0,79,80,5,1,0,0,80,
        81,3,4,2,0,81,82,5,3,0,0,82,83,3,6,3,0,83,84,5,2,0,0,84,85,3,4,2,
        0,85,86,5,26,0,0,86,3,1,0,0,0,87,88,3,68,34,0,88,5,1,0,0,0,89,96,
        3,8,4,0,90,96,3,16,8,0,91,96,3,30,15,0,92,96,3,12,6,0,93,96,3,40,
        20,0,94,96,3,64,32,0,95,89,1,0,0,0,95,90,1,0,0,0,95,91,1,0,0,0,95,
        92,1,0,0,0,95,93,1,0,0,0,95,94,1,0,0,0,96,98,1,0,0,0,97,95,1,0,0,
        0,98,101,1,0,0,0,99,97,1,0,0,0,99,100,1,0,0,0,100,7,1,0,0,0,101,
        99,1,0,0,0,102,103,5,4,0,0,103,104,5,27,0,0,104,105,5,6,0,0,105,
        106,5,25,0,0,106,107,5,5,0,0,107,108,5,31,0,0,108,109,5,30,0,0,109,
        110,3,10,5,0,110,111,5,30,0,0,111,112,5,28,0,0,112,113,5,26,0,0,
        113,9,1,0,0,0,114,115,3,68,34,0,115,11,1,0,0,0,116,117,5,7,0,0,117,
        118,5,8,0,0,118,119,5,10,0,0,119,120,3,4,2,0,120,121,5,25,0,0,121,
        122,5,1,0,0,122,123,5,3,0,0,123,124,3,14,7,0,124,125,5,26,0,0,125,
        13,1,0,0,0,126,127,3,66,33,0,127,15,1,0,0,0,128,129,5,14,0,0,129,
        131,5,27,0,0,130,132,3,18,9,0,131,130,1,0,0,0,132,133,1,0,0,0,133,
        131,1,0,0,0,133,134,1,0,0,0,134,135,1,0,0,0,135,136,5,28,0,0,136,
        137,5,26,0,0,137,17,1,0,0,0,138,139,3,20,10,0,139,140,5,25,0,0,140,
        141,3,22,11,0,141,143,3,24,12,0,142,144,5,26,0,0,143,142,1,0,0,0,
        143,144,1,0,0,0,144,19,1,0,0,0,145,146,3,68,34,0,146,21,1,0,0,0,
        147,148,7,0,0,0,148,23,1,0,0,0,149,153,3,26,13,0,150,153,3,28,14,
        0,151,153,5,36,0,0,152,149,1,0,0,0,152,150,1,0,0,0,152,151,1,0,0,
        0,153,25,1,0,0,0,154,155,5,19,0,0,155,27,1,0,0,0,156,157,5,20,0,
        0,157,158,5,27,0,0,158,159,3,62,31,0,159,160,5,28,0,0,160,29,1,0,
        0,0,161,162,5,12,0,0,162,163,3,10,5,0,163,164,5,25,0,0,164,165,5,
        13,0,0,165,167,5,31,0,0,166,168,3,32,16,0,167,166,1,0,0,0,168,169,
        1,0,0,0,169,167,1,0,0,0,169,170,1,0,0,0,170,171,1,0,0,0,171,172,
        5,26,0,0,172,31,1,0,0,0,173,175,5,30,0,0,174,173,1,0,0,0,174,175,
        1,0,0,0,175,176,1,0,0,0,176,177,3,34,17,0,177,180,5,25,0,0,178,181,
        3,36,18,0,179,181,3,38,19,0,180,178,1,0,0,0,180,179,1,0,0,0,181,
        183,1,0,0,0,182,184,5,24,0,0,183,182,1,0,0,0,183,184,1,0,0,0,184,
        186,1,0,0,0,185,187,5,30,0,0,186,185,1,0,0,0,186,187,1,0,0,0,187,
        189,1,0,0,0,188,190,5,29,0,0,189,188,1,0,0,0,189,190,1,0,0,0,190,
        33,1,0,0,0,191,192,3,68,34,0,192,35,1,0,0,0,193,196,3,68,34,0,194,
        196,3,66,33,0,195,193,1,0,0,0,195,194,1,0,0,0,196,37,1,0,0,0,197,
        202,5,27,0,0,198,200,3,36,18,0,199,201,5,24,0,0,200,199,1,0,0,0,
        200,201,1,0,0,0,201,203,1,0,0,0,202,198,1,0,0,0,203,204,1,0,0,0,
        204,202,1,0,0,0,204,205,1,0,0,0,205,206,1,0,0,0,206,207,5,28,0,0,
        207,39,1,0,0,0,208,209,5,7,0,0,209,210,5,9,0,0,210,211,5,10,0,0,
        211,212,3,4,2,0,212,213,5,25,0,0,213,214,5,1,0,0,214,216,5,3,0,0,
        215,217,3,42,21,0,216,215,1,0,0,0,217,218,1,0,0,0,218,216,1,0,0,
        0,218,219,1,0,0,0,219,220,1,0,0,0,220,221,5,26,0,0,221,41,1,0,0,
        0,222,223,5,30,0,0,223,224,3,44,22,0,224,227,5,27,0,0,225,228,3,
        46,23,0,226,228,3,48,24,0,227,225,1,0,0,0,227,226,1,0,0,0,228,229,
        1,0,0,0,229,231,5,28,0,0,230,232,5,24,0,0,231,230,1,0,0,0,231,232,
        1,0,0,0,232,233,1,0,0,0,233,235,5,30,0,0,234,236,5,29,0,0,235,234,
        1,0,0,0,235,236,1,0,0,0,236,43,1,0,0,0,237,238,5,38,0,0,238,45,1,
        0,0,0,239,240,3,50,25,0,240,243,5,24,0,0,241,244,3,52,26,0,242,244,
        5,32,0,0,243,241,1,0,0,0,243,242,1,0,0,0,244,245,1,0,0,0,245,246,
        5,24,0,0,246,247,3,54,27,0,247,248,5,24,0,0,248,249,3,56,28,0,249,
        47,1,0,0,0,250,251,3,50,25,0,251,252,5,24,0,0,252,253,3,52,26,0,
        253,254,5,24,0,0,254,255,3,54,27,0,255,256,5,24,0,0,256,257,3,56,
        28,0,257,258,5,24,0,0,258,259,3,58,29,0,259,260,5,24,0,0,260,261,
        3,60,30,0,261,262,5,24,0,0,262,263,3,68,34,0,263,49,1,0,0,0,264,
        265,5,36,0,0,265,51,1,0,0,0,266,271,3,68,34,0,267,271,5,27,0,0,268,
        271,3,66,33,0,269,271,5,28,0,0,270,266,1,0,0,0,270,267,1,0,0,0,270,
        268,1,0,0,0,270,269,1,0,0,0,271,274,1,0,0,0,272,270,1,0,0,0,272,
        273,1,0,0,0,273,53,1,0,0,0,274,272,1,0,0,0,275,276,5,36,0,0,276,
        55,1,0,0,0,277,280,3,68,34,0,278,280,3,66,33,0,279,277,1,0,0,0,279,
        278,1,0,0,0,280,57,1,0,0,0,281,282,3,66,33,0,282,59,1,0,0,0,283,
        284,3,66,33,0,284,61,1,0,0,0,285,286,5,38,0,0,286,287,5,21,0,0,287,
        292,5,38,0,0,288,289,5,38,0,0,289,290,5,22,0,0,290,292,5,38,0,0,
        291,285,1,0,0,0,291,288,1,0,0,0,292,63,1,0,0,0,293,295,8,1,0,0,294,
        293,1,0,0,0,295,296,1,0,0,0,296,294,1,0,0,0,296,297,1,0,0,0,297,
        298,1,0,0,0,298,299,5,26,0,0,299,65,1,0,0,0,300,301,5,38,0,0,301,
        67,1,0,0,0,302,303,5,36,0,0,303,69,1,0,0,0,304,305,5,42,0,0,305,
        71,1,0,0,0,25,76,95,99,133,143,152,169,174,180,183,186,189,195,200,
        204,218,227,231,235,243,270,272,279,291,296
    ]

class CBBsdlParser ( Parser ):

    grammarFileName = "CBBsdl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'entity'", "'end'", "'is'", "'generic'", 
                     "'string'", "'PHYSICAL_PIN_MAP'", "'attribute'", "'BOUNDARY_LENGTH'", 
                     "'BOUNDARY_REGISTER'", "'of'", "'use'", "'constant'", 
                     "'PIN_MAP_STRING'", "'port'", "'inout'", "'in'", "'out'", 
                     "'linkage'", "'bit'", "'bit_vector'", "'to'", "'downto'", 
                     "'.'", "','", "':'", "';'", "'('", "')'", "'&'", "'\"'", 
                     "':='", "'*'", "'_'", "'['", "']'" ]

    symbolicNames = [ "<INVALID>", "ENTITY", "END", "IS", "GENERIC", "STRING", 
                      "PHYSICAL_PIN_MAP", "ATTRIBUTE", "BS_LEN", "BS_REG", 
                      "OF", "USE", "CONSTANT", "PIN_MAP_STRING", "PORT", 
                      "INOUT", "IN", "OUT", "LINKAGE", "BIT", "BIT_VECTOR", 
                      "TO", "DOWNTO", "DOT", "COMMA", "COLON", "SEMICOLON", 
                      "BRACKET_OPEN", "BRACKET_CLOSE", "AMPERSAND", "QUOTES", 
                      "EQUALS", "ASTERISK", "UNDERLINE", "SQUARE_OPEN", 
                      "SQUARE_CLOSE", "ID", "REAL_LITERAL", "INTEGER", "DIGIT", 
                      "EXPONENT", "WS", "COMMENT" ]

    RULE_bsdl = 0
    RULE_entity = 1
    RULE_entity_name = 2
    RULE_body = 3
    RULE_generic_phys_pin_map = 4
    RULE_phys_pin_map_name = 5
    RULE_attr_bsr_len = 6
    RULE_bsr_len = 7
    RULE_port_dec = 8
    RULE_port_def = 9
    RULE_port_name = 10
    RULE_port_function = 11
    RULE_port_type = 12
    RULE_bit = 13
    RULE_bit_vector = 14
    RULE_pin_map = 15
    RULE_pin_def = 16
    RULE_port = 17
    RULE_pin_num = 18
    RULE_pin_num_arr = 19
    RULE_attr_bsr = 20
    RULE_bsr_def = 21
    RULE_data_cell = 22
    RULE_bsr_cell0 = 23
    RULE_bsr_cell1 = 24
    RULE_cell_type = 25
    RULE_cell_desc = 26
    RULE_cell_func = 27
    RULE_cell_val = 28
    RULE_ctrl_cell = 29
    RULE_disval = 30
    RULE_bit_range = 31
    RULE_undef_part = 32
    RULE_number = 33
    RULE_identifier = 34
    RULE_comment = 35

    ruleNames =  [ "bsdl", "entity", "entity_name", "body", "generic_phys_pin_map", 
                   "phys_pin_map_name", "attr_bsr_len", "bsr_len", "port_dec", 
                   "port_def", "port_name", "port_function", "port_type", 
                   "bit", "bit_vector", "pin_map", "pin_def", "port", "pin_num", 
                   "pin_num_arr", "attr_bsr", "bsr_def", "data_cell", "bsr_cell0", 
                   "bsr_cell1", "cell_type", "cell_desc", "cell_func", "cell_val", 
                   "ctrl_cell", "disval", "bit_range", "undef_part", "number", 
                   "identifier", "comment" ]

    EOF = Token.EOF
    ENTITY=1
    END=2
    IS=3
    GENERIC=4
    STRING=5
    PHYSICAL_PIN_MAP=6
    ATTRIBUTE=7
    BS_LEN=8
    BS_REG=9
    OF=10
    USE=11
    CONSTANT=12
    PIN_MAP_STRING=13
    PORT=14
    INOUT=15
    IN=16
    OUT=17
    LINKAGE=18
    BIT=19
    BIT_VECTOR=20
    TO=21
    DOWNTO=22
    DOT=23
    COMMA=24
    COLON=25
    SEMICOLON=26
    BRACKET_OPEN=27
    BRACKET_CLOSE=28
    AMPERSAND=29
    QUOTES=30
    EQUALS=31
    ASTERISK=32
    UNDERLINE=33
    SQUARE_OPEN=34
    SQUARE_CLOSE=35
    ID=36
    REAL_LITERAL=37
    INTEGER=38
    DIGIT=39
    EXPONENT=40
    WS=41
    COMMENT=42

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class BsdlContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def entity(self):
            return self.getTypedRuleContext(CBBsdlParser.EntityContext,0)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.CommentContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.CommentContext,i)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_bsdl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBsdl" ):
                listener.enterBsdl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBsdl" ):
                listener.exitBsdl(self)




    def bsdl(self):

        localctx = CBBsdlParser.BsdlContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_bsdl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 72
            self.entity()
            self.state = 76
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==42:
                self.state = 73
                self.comment()
                self.state = 78
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EntityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ENTITY(self):
            return self.getToken(CBBsdlParser.ENTITY, 0)

        def entity_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Entity_nameContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Entity_nameContext,i)


        def IS(self):
            return self.getToken(CBBsdlParser.IS, 0)

        def body(self):
            return self.getTypedRuleContext(CBBsdlParser.BodyContext,0)


        def END(self):
            return self.getToken(CBBsdlParser.END, 0)

        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_entity

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEntity" ):
                listener.enterEntity(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEntity" ):
                listener.exitEntity(self)




    def entity(self):

        localctx = CBBsdlParser.EntityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_entity)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 79
            self.match(CBBsdlParser.ENTITY)
            self.state = 80
            self.entity_name()
            self.state = 81
            self.match(CBBsdlParser.IS)
            self.state = 82
            self.body()
            self.state = 83
            self.match(CBBsdlParser.END)
            self.state = 84
            self.entity_name()
            self.state = 85
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Entity_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_entity_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEntity_name" ):
                listener.enterEntity_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEntity_name" ):
                listener.exitEntity_name(self)




    def entity_name(self):

        localctx = CBBsdlParser.Entity_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_entity_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 87
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def generic_phys_pin_map(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Generic_phys_pin_mapContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Generic_phys_pin_mapContext,i)


        def port_dec(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Port_decContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Port_decContext,i)


        def pin_map(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Pin_mapContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Pin_mapContext,i)


        def attr_bsr_len(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Attr_bsr_lenContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Attr_bsr_lenContext,i)


        def attr_bsr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Attr_bsrContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Attr_bsrContext,i)


        def undef_part(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Undef_partContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Undef_partContext,i)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBody" ):
                listener.enterBody(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBody" ):
                listener.exitBody(self)




    def body(self):

        localctx = CBBsdlParser.BodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 95
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                    if la_ == 1:
                        self.state = 89
                        self.generic_phys_pin_map()
                        pass

                    elif la_ == 2:
                        self.state = 90
                        self.port_dec()
                        pass

                    elif la_ == 3:
                        self.state = 91
                        self.pin_map()
                        pass

                    elif la_ == 4:
                        self.state = 92
                        self.attr_bsr_len()
                        pass

                    elif la_ == 5:
                        self.state = 93
                        self.attr_bsr()
                        pass

                    elif la_ == 6:
                        self.state = 94
                        self.undef_part()
                        pass

             
                self.state = 101
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Generic_phys_pin_mapContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GENERIC(self):
            return self.getToken(CBBsdlParser.GENERIC, 0)

        def BRACKET_OPEN(self):
            return self.getToken(CBBsdlParser.BRACKET_OPEN, 0)

        def PHYSICAL_PIN_MAP(self):
            return self.getToken(CBBsdlParser.PHYSICAL_PIN_MAP, 0)

        def COLON(self):
            return self.getToken(CBBsdlParser.COLON, 0)

        def STRING(self):
            return self.getToken(CBBsdlParser.STRING, 0)

        def EQUALS(self):
            return self.getToken(CBBsdlParser.EQUALS, 0)

        def QUOTES(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.QUOTES)
            else:
                return self.getToken(CBBsdlParser.QUOTES, i)

        def phys_pin_map_name(self):
            return self.getTypedRuleContext(CBBsdlParser.Phys_pin_map_nameContext,0)


        def BRACKET_CLOSE(self):
            return self.getToken(CBBsdlParser.BRACKET_CLOSE, 0)

        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_generic_phys_pin_map

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGeneric_phys_pin_map" ):
                listener.enterGeneric_phys_pin_map(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGeneric_phys_pin_map" ):
                listener.exitGeneric_phys_pin_map(self)




    def generic_phys_pin_map(self):

        localctx = CBBsdlParser.Generic_phys_pin_mapContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_generic_phys_pin_map)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 102
            self.match(CBBsdlParser.GENERIC)
            self.state = 103
            self.match(CBBsdlParser.BRACKET_OPEN)
            self.state = 104
            self.match(CBBsdlParser.PHYSICAL_PIN_MAP)
            self.state = 105
            self.match(CBBsdlParser.COLON)
            self.state = 106
            self.match(CBBsdlParser.STRING)
            self.state = 107
            self.match(CBBsdlParser.EQUALS)
            self.state = 108
            self.match(CBBsdlParser.QUOTES)
            self.state = 109
            self.phys_pin_map_name()
            self.state = 110
            self.match(CBBsdlParser.QUOTES)
            self.state = 111
            self.match(CBBsdlParser.BRACKET_CLOSE)
            self.state = 112
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Phys_pin_map_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_phys_pin_map_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPhys_pin_map_name" ):
                listener.enterPhys_pin_map_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPhys_pin_map_name" ):
                listener.exitPhys_pin_map_name(self)




    def phys_pin_map_name(self):

        localctx = CBBsdlParser.Phys_pin_map_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_phys_pin_map_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 114
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Attr_bsr_lenContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATTRIBUTE(self):
            return self.getToken(CBBsdlParser.ATTRIBUTE, 0)

        def BS_LEN(self):
            return self.getToken(CBBsdlParser.BS_LEN, 0)

        def OF(self):
            return self.getToken(CBBsdlParser.OF, 0)

        def entity_name(self):
            return self.getTypedRuleContext(CBBsdlParser.Entity_nameContext,0)


        def COLON(self):
            return self.getToken(CBBsdlParser.COLON, 0)

        def ENTITY(self):
            return self.getToken(CBBsdlParser.ENTITY, 0)

        def IS(self):
            return self.getToken(CBBsdlParser.IS, 0)

        def bsr_len(self):
            return self.getTypedRuleContext(CBBsdlParser.Bsr_lenContext,0)


        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_attr_bsr_len

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttr_bsr_len" ):
                listener.enterAttr_bsr_len(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttr_bsr_len" ):
                listener.exitAttr_bsr_len(self)




    def attr_bsr_len(self):

        localctx = CBBsdlParser.Attr_bsr_lenContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_attr_bsr_len)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 116
            self.match(CBBsdlParser.ATTRIBUTE)
            self.state = 117
            self.match(CBBsdlParser.BS_LEN)
            self.state = 118
            self.match(CBBsdlParser.OF)
            self.state = 119
            self.entity_name()
            self.state = 120
            self.match(CBBsdlParser.COLON)
            self.state = 121
            self.match(CBBsdlParser.ENTITY)
            self.state = 122
            self.match(CBBsdlParser.IS)
            self.state = 123
            self.bsr_len()
            self.state = 124
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bsr_lenContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(CBBsdlParser.NumberContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_bsr_len

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBsr_len" ):
                listener.enterBsr_len(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBsr_len" ):
                listener.exitBsr_len(self)




    def bsr_len(self):

        localctx = CBBsdlParser.Bsr_lenContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_bsr_len)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Port_decContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PORT(self):
            return self.getToken(CBBsdlParser.PORT, 0)

        def BRACKET_OPEN(self):
            return self.getToken(CBBsdlParser.BRACKET_OPEN, 0)

        def BRACKET_CLOSE(self):
            return self.getToken(CBBsdlParser.BRACKET_CLOSE, 0)

        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def port_def(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Port_defContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Port_defContext,i)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_port_dec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPort_dec" ):
                listener.enterPort_dec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPort_dec" ):
                listener.exitPort_dec(self)




    def port_dec(self):

        localctx = CBBsdlParser.Port_decContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_port_dec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 128
            self.match(CBBsdlParser.PORT)
            self.state = 129
            self.match(CBBsdlParser.BRACKET_OPEN)
            self.state = 131 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 130
                self.port_def()
                self.state = 133 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==36):
                    break

            self.state = 135
            self.match(CBBsdlParser.BRACKET_CLOSE)
            self.state = 136
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Port_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def port_name(self):
            return self.getTypedRuleContext(CBBsdlParser.Port_nameContext,0)


        def COLON(self):
            return self.getToken(CBBsdlParser.COLON, 0)

        def port_function(self):
            return self.getTypedRuleContext(CBBsdlParser.Port_functionContext,0)


        def port_type(self):
            return self.getTypedRuleContext(CBBsdlParser.Port_typeContext,0)


        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_port_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPort_def" ):
                listener.enterPort_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPort_def" ):
                listener.exitPort_def(self)




    def port_def(self):

        localctx = CBBsdlParser.Port_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_port_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 138
            self.port_name()
            self.state = 139
            self.match(CBBsdlParser.COLON)
            self.state = 140
            self.port_function()
            self.state = 141
            self.port_type()
            self.state = 143
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==26:
                self.state = 142
                self.match(CBBsdlParser.SEMICOLON)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Port_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_port_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPort_name" ):
                listener.enterPort_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPort_name" ):
                listener.exitPort_name(self)




    def port_name(self):

        localctx = CBBsdlParser.Port_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_port_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 145
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Port_functionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INOUT(self):
            return self.getToken(CBBsdlParser.INOUT, 0)

        def IN(self):
            return self.getToken(CBBsdlParser.IN, 0)

        def OUT(self):
            return self.getToken(CBBsdlParser.OUT, 0)

        def LINKAGE(self):
            return self.getToken(CBBsdlParser.LINKAGE, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_port_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPort_function" ):
                listener.enterPort_function(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPort_function" ):
                listener.exitPort_function(self)




    def port_function(self):

        localctx = CBBsdlParser.Port_functionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_port_function)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 147
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 491520) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Port_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def bit(self):
            return self.getTypedRuleContext(CBBsdlParser.BitContext,0)


        def bit_vector(self):
            return self.getTypedRuleContext(CBBsdlParser.Bit_vectorContext,0)


        def ID(self):
            return self.getToken(CBBsdlParser.ID, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_port_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPort_type" ):
                listener.enterPort_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPort_type" ):
                listener.exitPort_type(self)




    def port_type(self):

        localctx = CBBsdlParser.Port_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_port_type)
        try:
            self.state = 152
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [19]:
                self.enterOuterAlt(localctx, 1)
                self.state = 149
                self.bit()
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 2)
                self.state = 150
                self.bit_vector()
                pass
            elif token in [36]:
                self.enterOuterAlt(localctx, 3)
                self.state = 151
                self.match(CBBsdlParser.ID)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BitContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BIT(self):
            return self.getToken(CBBsdlParser.BIT, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_bit

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBit" ):
                listener.enterBit(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBit" ):
                listener.exitBit(self)




    def bit(self):

        localctx = CBBsdlParser.BitContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_bit)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 154
            self.match(CBBsdlParser.BIT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bit_vectorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BIT_VECTOR(self):
            return self.getToken(CBBsdlParser.BIT_VECTOR, 0)

        def BRACKET_OPEN(self):
            return self.getToken(CBBsdlParser.BRACKET_OPEN, 0)

        def bit_range(self):
            return self.getTypedRuleContext(CBBsdlParser.Bit_rangeContext,0)


        def BRACKET_CLOSE(self):
            return self.getToken(CBBsdlParser.BRACKET_CLOSE, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_bit_vector

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBit_vector" ):
                listener.enterBit_vector(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBit_vector" ):
                listener.exitBit_vector(self)




    def bit_vector(self):

        localctx = CBBsdlParser.Bit_vectorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_bit_vector)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 156
            self.match(CBBsdlParser.BIT_VECTOR)
            self.state = 157
            self.match(CBBsdlParser.BRACKET_OPEN)
            self.state = 158
            self.bit_range()
            self.state = 159
            self.match(CBBsdlParser.BRACKET_CLOSE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pin_mapContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONSTANT(self):
            return self.getToken(CBBsdlParser.CONSTANT, 0)

        def phys_pin_map_name(self):
            return self.getTypedRuleContext(CBBsdlParser.Phys_pin_map_nameContext,0)


        def COLON(self):
            return self.getToken(CBBsdlParser.COLON, 0)

        def PIN_MAP_STRING(self):
            return self.getToken(CBBsdlParser.PIN_MAP_STRING, 0)

        def EQUALS(self):
            return self.getToken(CBBsdlParser.EQUALS, 0)

        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def pin_def(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Pin_defContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Pin_defContext,i)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_pin_map

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPin_map" ):
                listener.enterPin_map(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPin_map" ):
                listener.exitPin_map(self)




    def pin_map(self):

        localctx = CBBsdlParser.Pin_mapContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_pin_map)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 161
            self.match(CBBsdlParser.CONSTANT)
            self.state = 162
            self.phys_pin_map_name()
            self.state = 163
            self.match(CBBsdlParser.COLON)
            self.state = 164
            self.match(CBBsdlParser.PIN_MAP_STRING)
            self.state = 165
            self.match(CBBsdlParser.EQUALS)
            self.state = 167 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 166
                self.pin_def()
                self.state = 169 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==30 or _la==36):
                    break

            self.state = 171
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pin_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def port(self):
            return self.getTypedRuleContext(CBBsdlParser.PortContext,0)


        def COLON(self):
            return self.getToken(CBBsdlParser.COLON, 0)

        def pin_num(self):
            return self.getTypedRuleContext(CBBsdlParser.Pin_numContext,0)


        def pin_num_arr(self):
            return self.getTypedRuleContext(CBBsdlParser.Pin_num_arrContext,0)


        def QUOTES(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.QUOTES)
            else:
                return self.getToken(CBBsdlParser.QUOTES, i)

        def COMMA(self):
            return self.getToken(CBBsdlParser.COMMA, 0)

        def AMPERSAND(self):
            return self.getToken(CBBsdlParser.AMPERSAND, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_pin_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPin_def" ):
                listener.enterPin_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPin_def" ):
                listener.exitPin_def(self)




    def pin_def(self):

        localctx = CBBsdlParser.Pin_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_pin_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==30:
                self.state = 173
                self.match(CBBsdlParser.QUOTES)


            self.state = 176
            self.port()
            self.state = 177
            self.match(CBBsdlParser.COLON)
            self.state = 180
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [36, 38]:
                self.state = 178
                self.pin_num()
                pass
            elif token in [27]:
                self.state = 179
                self.pin_num_arr()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 183
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 182
                self.match(CBBsdlParser.COMMA)


            self.state = 186
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.state = 185
                self.match(CBBsdlParser.QUOTES)


            self.state = 189
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==29:
                self.state = 188
                self.match(CBBsdlParser.AMPERSAND)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PortContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_port

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPort" ):
                listener.enterPort(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPort" ):
                listener.exitPort(self)




    def port(self):

        localctx = CBBsdlParser.PortContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_port)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 191
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pin_numContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def number(self):
            return self.getTypedRuleContext(CBBsdlParser.NumberContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_pin_num

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPin_num" ):
                listener.enterPin_num(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPin_num" ):
                listener.exitPin_num(self)




    def pin_num(self):

        localctx = CBBsdlParser.Pin_numContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_pin_num)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 195
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [36]:
                self.state = 193
                self.identifier()
                pass
            elif token in [38]:
                self.state = 194
                self.number()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pin_num_arrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BRACKET_OPEN(self):
            return self.getToken(CBBsdlParser.BRACKET_OPEN, 0)

        def BRACKET_CLOSE(self):
            return self.getToken(CBBsdlParser.BRACKET_CLOSE, 0)

        def pin_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Pin_numContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Pin_numContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.COMMA)
            else:
                return self.getToken(CBBsdlParser.COMMA, i)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_pin_num_arr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPin_num_arr" ):
                listener.enterPin_num_arr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPin_num_arr" ):
                listener.exitPin_num_arr(self)




    def pin_num_arr(self):

        localctx = CBBsdlParser.Pin_num_arrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_pin_num_arr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 197
            self.match(CBBsdlParser.BRACKET_OPEN)
            self.state = 202 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 198
                self.pin_num()
                self.state = 200
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==24:
                    self.state = 199
                    self.match(CBBsdlParser.COMMA)


                self.state = 204 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==36 or _la==38):
                    break

            self.state = 206
            self.match(CBBsdlParser.BRACKET_CLOSE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Attr_bsrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATTRIBUTE(self):
            return self.getToken(CBBsdlParser.ATTRIBUTE, 0)

        def BS_REG(self):
            return self.getToken(CBBsdlParser.BS_REG, 0)

        def OF(self):
            return self.getToken(CBBsdlParser.OF, 0)

        def entity_name(self):
            return self.getTypedRuleContext(CBBsdlParser.Entity_nameContext,0)


        def COLON(self):
            return self.getToken(CBBsdlParser.COLON, 0)

        def ENTITY(self):
            return self.getToken(CBBsdlParser.ENTITY, 0)

        def IS(self):
            return self.getToken(CBBsdlParser.IS, 0)

        def SEMICOLON(self):
            return self.getToken(CBBsdlParser.SEMICOLON, 0)

        def bsr_def(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.Bsr_defContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.Bsr_defContext,i)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_attr_bsr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttr_bsr" ):
                listener.enterAttr_bsr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttr_bsr" ):
                listener.exitAttr_bsr(self)




    def attr_bsr(self):

        localctx = CBBsdlParser.Attr_bsrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_attr_bsr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 208
            self.match(CBBsdlParser.ATTRIBUTE)
            self.state = 209
            self.match(CBBsdlParser.BS_REG)
            self.state = 210
            self.match(CBBsdlParser.OF)
            self.state = 211
            self.entity_name()
            self.state = 212
            self.match(CBBsdlParser.COLON)
            self.state = 213
            self.match(CBBsdlParser.ENTITY)
            self.state = 214
            self.match(CBBsdlParser.IS)
            self.state = 216 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 215
                self.bsr_def()
                self.state = 218 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==30):
                    break

            self.state = 220
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bsr_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTES(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.QUOTES)
            else:
                return self.getToken(CBBsdlParser.QUOTES, i)

        def data_cell(self):
            return self.getTypedRuleContext(CBBsdlParser.Data_cellContext,0)


        def BRACKET_OPEN(self):
            return self.getToken(CBBsdlParser.BRACKET_OPEN, 0)

        def BRACKET_CLOSE(self):
            return self.getToken(CBBsdlParser.BRACKET_CLOSE, 0)

        def bsr_cell0(self):
            return self.getTypedRuleContext(CBBsdlParser.Bsr_cell0Context,0)


        def bsr_cell1(self):
            return self.getTypedRuleContext(CBBsdlParser.Bsr_cell1Context,0)


        def COMMA(self):
            return self.getToken(CBBsdlParser.COMMA, 0)

        def AMPERSAND(self):
            return self.getToken(CBBsdlParser.AMPERSAND, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_bsr_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBsr_def" ):
                listener.enterBsr_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBsr_def" ):
                listener.exitBsr_def(self)




    def bsr_def(self):

        localctx = CBBsdlParser.Bsr_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_bsr_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 222
            self.match(CBBsdlParser.QUOTES)
            self.state = 223
            self.data_cell()
            self.state = 224
            self.match(CBBsdlParser.BRACKET_OPEN)
            self.state = 227
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
            if la_ == 1:
                self.state = 225
                self.bsr_cell0()
                pass

            elif la_ == 2:
                self.state = 226
                self.bsr_cell1()
                pass


            self.state = 229
            self.match(CBBsdlParser.BRACKET_CLOSE)
            self.state = 231
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 230
                self.match(CBBsdlParser.COMMA)


            self.state = 233
            self.match(CBBsdlParser.QUOTES)
            self.state = 235
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==29:
                self.state = 234
                self.match(CBBsdlParser.AMPERSAND)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Data_cellContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self):
            return self.getToken(CBBsdlParser.INTEGER, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_data_cell

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterData_cell" ):
                listener.enterData_cell(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitData_cell" ):
                listener.exitData_cell(self)




    def data_cell(self):

        localctx = CBBsdlParser.Data_cellContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_data_cell)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 237
            self.match(CBBsdlParser.INTEGER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bsr_cell0Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def cell_type(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_typeContext,0)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.COMMA)
            else:
                return self.getToken(CBBsdlParser.COMMA, i)

        def cell_func(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_funcContext,0)


        def cell_val(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_valContext,0)


        def cell_desc(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_descContext,0)


        def ASTERISK(self):
            return self.getToken(CBBsdlParser.ASTERISK, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_bsr_cell0

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBsr_cell0" ):
                listener.enterBsr_cell0(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBsr_cell0" ):
                listener.exitBsr_cell0(self)




    def bsr_cell0(self):

        localctx = CBBsdlParser.Bsr_cell0Context(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_bsr_cell0)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 239
            self.cell_type()
            self.state = 240
            self.match(CBBsdlParser.COMMA)
            self.state = 243
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [24, 27, 28, 36, 38]:
                self.state = 241
                self.cell_desc()
                pass
            elif token in [32]:
                self.state = 242
                self.match(CBBsdlParser.ASTERISK)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 245
            self.match(CBBsdlParser.COMMA)
            self.state = 246
            self.cell_func()
            self.state = 247
            self.match(CBBsdlParser.COMMA)
            self.state = 248
            self.cell_val()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bsr_cell1Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def cell_type(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_typeContext,0)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.COMMA)
            else:
                return self.getToken(CBBsdlParser.COMMA, i)

        def cell_desc(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_descContext,0)


        def cell_func(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_funcContext,0)


        def cell_val(self):
            return self.getTypedRuleContext(CBBsdlParser.Cell_valContext,0)


        def ctrl_cell(self):
            return self.getTypedRuleContext(CBBsdlParser.Ctrl_cellContext,0)


        def disval(self):
            return self.getTypedRuleContext(CBBsdlParser.DisvalContext,0)


        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_bsr_cell1

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBsr_cell1" ):
                listener.enterBsr_cell1(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBsr_cell1" ):
                listener.exitBsr_cell1(self)




    def bsr_cell1(self):

        localctx = CBBsdlParser.Bsr_cell1Context(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_bsr_cell1)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 250
            self.cell_type()
            self.state = 251
            self.match(CBBsdlParser.COMMA)
            self.state = 252
            self.cell_desc()
            self.state = 253
            self.match(CBBsdlParser.COMMA)
            self.state = 254
            self.cell_func()
            self.state = 255
            self.match(CBBsdlParser.COMMA)
            self.state = 256
            self.cell_val()
            self.state = 257
            self.match(CBBsdlParser.COMMA)
            self.state = 258
            self.ctrl_cell()
            self.state = 259
            self.match(CBBsdlParser.COMMA)
            self.state = 260
            self.disval()
            self.state = 261
            self.match(CBBsdlParser.COMMA)
            self.state = 262
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cell_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(CBBsdlParser.ID, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_cell_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCell_type" ):
                listener.enterCell_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCell_type" ):
                listener.exitCell_type(self)




    def cell_type(self):

        localctx = CBBsdlParser.Cell_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_cell_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 264
            self.match(CBBsdlParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cell_descContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.IdentifierContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,i)


        def BRACKET_OPEN(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.BRACKET_OPEN)
            else:
                return self.getToken(CBBsdlParser.BRACKET_OPEN, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CBBsdlParser.NumberContext)
            else:
                return self.getTypedRuleContext(CBBsdlParser.NumberContext,i)


        def BRACKET_CLOSE(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.BRACKET_CLOSE)
            else:
                return self.getToken(CBBsdlParser.BRACKET_CLOSE, i)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_cell_desc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCell_desc" ):
                listener.enterCell_desc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCell_desc" ):
                listener.exitCell_desc(self)




    def cell_desc(self):

        localctx = CBBsdlParser.Cell_descContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_cell_desc)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 272
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 344000036864) != 0):
                self.state = 270
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [36]:
                    self.state = 266
                    self.identifier()
                    pass
                elif token in [27]:
                    self.state = 267
                    self.match(CBBsdlParser.BRACKET_OPEN)
                    pass
                elif token in [38]:
                    self.state = 268
                    self.number()
                    pass
                elif token in [28]:
                    self.state = 269
                    self.match(CBBsdlParser.BRACKET_CLOSE)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 274
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cell_funcContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(CBBsdlParser.ID, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_cell_func

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCell_func" ):
                listener.enterCell_func(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCell_func" ):
                listener.exitCell_func(self)




    def cell_func(self):

        localctx = CBBsdlParser.Cell_funcContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_cell_func)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 275
            self.match(CBBsdlParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cell_valContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(CBBsdlParser.IdentifierContext,0)


        def number(self):
            return self.getTypedRuleContext(CBBsdlParser.NumberContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_cell_val

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCell_val" ):
                listener.enterCell_val(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCell_val" ):
                listener.exitCell_val(self)




    def cell_val(self):

        localctx = CBBsdlParser.Cell_valContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_cell_val)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 279
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [36]:
                self.state = 277
                self.identifier()
                pass
            elif token in [38]:
                self.state = 278
                self.number()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ctrl_cellContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(CBBsdlParser.NumberContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_ctrl_cell

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCtrl_cell" ):
                listener.enterCtrl_cell(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCtrl_cell" ):
                listener.exitCtrl_cell(self)




    def ctrl_cell(self):

        localctx = CBBsdlParser.Ctrl_cellContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_ctrl_cell)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 281
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DisvalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(CBBsdlParser.NumberContext,0)


        def getRuleIndex(self):
            return CBBsdlParser.RULE_disval

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDisval" ):
                listener.enterDisval(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDisval" ):
                listener.exitDisval(self)




    def disval(self):

        localctx = CBBsdlParser.DisvalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_disval)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 283
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bit_rangeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.INTEGER)
            else:
                return self.getToken(CBBsdlParser.INTEGER, i)

        def TO(self):
            return self.getToken(CBBsdlParser.TO, 0)

        def DOWNTO(self):
            return self.getToken(CBBsdlParser.DOWNTO, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_bit_range

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBit_range" ):
                listener.enterBit_range(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBit_range" ):
                listener.exitBit_range(self)




    def bit_range(self):

        localctx = CBBsdlParser.Bit_rangeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_bit_range)
        try:
            self.state = 291
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,23,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 285
                self.match(CBBsdlParser.INTEGER)
                self.state = 286
                self.match(CBBsdlParser.TO)
                self.state = 287
                self.match(CBBsdlParser.INTEGER)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 288
                self.match(CBBsdlParser.INTEGER)
                self.state = 289
                self.match(CBBsdlParser.DOWNTO)
                self.state = 290
                self.match(CBBsdlParser.INTEGER)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Undef_partContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SEMICOLON(self, i:int=None):
            if i is None:
                return self.getTokens(CBBsdlParser.SEMICOLON)
            else:
                return self.getToken(CBBsdlParser.SEMICOLON, i)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_undef_part

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUndef_part" ):
                listener.enterUndef_part(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUndef_part" ):
                listener.exitUndef_part(self)




    def undef_part(self):

        localctx = CBBsdlParser.Undef_partContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_undef_part)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 294 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 293
                _la = self._input.LA(1)
                if _la <= 0 or _la==26:
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 296 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 8796025913342) != 0)):
                    break

            self.state = 298
            self.match(CBBsdlParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self):
            return self.getToken(CBBsdlParser.INTEGER, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = CBBsdlParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_number)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 300
            self.match(CBBsdlParser.INTEGER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(CBBsdlParser.ID, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_identifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifier" ):
                listener.enterIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifier" ):
                listener.exitIdentifier(self)




    def identifier(self):

        localctx = CBBsdlParser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_identifier)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 302
            self.match(CBBsdlParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(CBBsdlParser.COMMENT, 0)

        def getRuleIndex(self):
            return CBBsdlParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)




    def comment(self):

        localctx = CBBsdlParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_comment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 304
            self.match(CBBsdlParser.COMMENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





