.. _releases:

========
Releases
========

Refer to our `Github releases page <https://github.com/NorskRegnesentral/skchange/releases>`_
for the changelog associated with each new release.
