.. _anomaly_detection_guide:

=================
Anomaly detection
=================

.. toctree::
    :maxdepth: 1
    :hidden:

    intro
