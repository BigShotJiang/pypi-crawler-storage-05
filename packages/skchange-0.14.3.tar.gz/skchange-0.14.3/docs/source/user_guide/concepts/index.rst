.. _concepts_guide:

========
Concepts
========

This section describes the basic components of Skchange. Understanding them will help
you make the most of the library.

.. toctree::
    :maxdepth: 1
    :hidden:

    detectors
    interval_scores
