.. _interval_scores_guide:

================
Interval scores
================

.. toctree::
    :maxdepth: 1
    :hidden:

    costs
    change_scores
    savings
    local_anomaly_scores
