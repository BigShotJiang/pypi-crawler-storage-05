.. _penalties_guide:

=========
Penalties
=========

.. toctree::
    :maxdepth: 1
    :hidden:

    constant_penalties
    other_penalties
