.. _compose:

Composition
===========

.. currentmodule:: skchange.compose.penalised_score

.. autosummary::
    :toctree: auto_generated/
    :template: class.rst

    PenalisedScore
