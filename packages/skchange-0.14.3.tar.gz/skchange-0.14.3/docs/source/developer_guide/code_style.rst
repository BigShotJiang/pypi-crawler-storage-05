.. _code_style:

==========
Code style
==========
Under construction.

We aim to follow
`sktime <https://www.sktime.net/en/latest/developer_guide/coding_standards.html>`_
as closely as possible in terms of coding style.
