"""Tests for skchange module."""
