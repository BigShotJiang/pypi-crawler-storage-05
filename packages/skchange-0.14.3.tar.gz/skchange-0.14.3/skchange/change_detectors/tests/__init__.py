"""Test for changepoint detectors."""
