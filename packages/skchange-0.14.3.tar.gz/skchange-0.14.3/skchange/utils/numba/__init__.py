"""Numba utility functions."""

from ._soft_import import jit, njit, numba_available, prange
