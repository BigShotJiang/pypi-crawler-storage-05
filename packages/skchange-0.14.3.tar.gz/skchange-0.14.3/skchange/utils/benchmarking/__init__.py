"""Utility functions for benchmarking skchange code."""
