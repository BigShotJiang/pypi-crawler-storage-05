"""Composition for skchange scorers and detectors."""
