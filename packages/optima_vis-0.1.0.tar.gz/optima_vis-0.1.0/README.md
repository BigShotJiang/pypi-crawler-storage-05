_optima-vis_ - A visualization tool for neural network optimizers.
