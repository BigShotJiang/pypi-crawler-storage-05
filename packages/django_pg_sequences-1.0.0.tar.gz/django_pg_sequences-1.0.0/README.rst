django-sequence-pg
==================

Generate gapless sequences of integer values using PostgreSQL native sequences.

This package provides a Django app that leverages PostgreSQL's native CREATE SEQUENCE functionality for fast, consistent, and thread-safe sequence generation. Unlike table-based approaches, this implementation uses PostgreSQL's built-in sequence objects for optimal performance and guaranteed consistency.

Features
--------

- **PostgreSQL Native**: Uses CREATE SEQUENCE for optimal performance
- **Thread Safe**: Leverages PostgreSQL's ACID properties for concurrent access
- **Gapless**: Guarantees no gaps in sequence values
- **Django Integration**: Seamless integration with Django models and migrations
- **Simple API**: Easy-to-use functions for sequence management

Installation
------------

Install from PyPI::

    pip install django-sequence-pg

Add to your Django settings::

    INSTALLED_APPS = [
        ...
        'sequences',
        ...
    ]

Run migrations::

    python manage.py migrate sequences

Usage
-----

Basic usage::

    from sequences import get_next_value, get_current_value, reset_sequence

    # Get next value in sequence
    next_id = get_next_value('invoice_number')

    # Get current value without incrementing
    current_id = get_current_value('invoice_number')

    # Reset sequence to specific value
    reset_sequence('invoice_number', 1000)

Requirements
------------

- Django >= 4.2
- PostgreSQL >= 10.0
- psycopg2-binary >= 2.8.0

License
-------

BSD 3-Clause License
