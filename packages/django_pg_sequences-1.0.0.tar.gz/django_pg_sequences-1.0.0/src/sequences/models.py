from django.db import models


class SequenceRegistry(models.Model):
    """
    Registry to track created sequences for management purposes.
    
    This model doesn't store the actual sequence values (those are in PostgreSQL sequences),
    but helps with Django admin interface and sequence management.
    """
    name = models.CharField(max_length=100, primary_key=True)
    initial_value = models.BigIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Sequence"
        verbose_name_plural = "Sequences"
    
    def __str__(self):
        return f"Sequence({self.name})"
