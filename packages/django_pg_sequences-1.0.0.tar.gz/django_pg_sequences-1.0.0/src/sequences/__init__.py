from django.db import connections, router, transaction
from django.db.utils import DEFAULT_DB_ALIAS

__all__ = [
    'get_next_value',
    'get_last_value', 
    'get_next_values',
    'reset_sequence',
    'delete_sequence',
    'sequence_exists',
    'quote_ident',
    'Sequence',
]

SELECT = """
    SELECT last_value, is_called
    FROM {sequence_name}
"""

POSTGRESQL_CREATE_SEQUENCE = """
    CREATE SEQUENCE IF NOT EXISTS {sequence_name}
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
"""

POSTGRESQL_NEXTVAL = """
    SELECT nextval('{sequence_name}')
"""

POSTGRESQL_CURRVAL = """
    SELECT currval('{sequence_name}')
"""

POSTGRESQL_SETVAL = """
    SELECT setval('{sequence_name}', %s, true)
"""

POSTGRESQL_DROP_SEQUENCE = """
    DROP SEQUENCE IF EXISTS {sequence_name}
"""

POSTGRESQL_SEQUENCE_EXISTS = """
    SELECT EXISTS(
        SELECT 1 FROM information_schema.sequences 
        WHERE sequence_name = %s
    )
"""


def quote_ident(name):
    """Safely quote a PostgreSQL identifier for case-sensitivity."""
    return f'"{name}"'


def get_last_value(
    sequence_name="default",
    initial_value=1,
    reset_value=None,
    using=DEFAULT_DB_ALIAS,
):
    """
    Return the last value for a sequence without incrementing it.
    
    If the sequence doesn't exist, it will be created with initial_value.
    If reset_value is provided, the sequence will be reset to that value.
    """
    if reset_value is not None:
        reset_sequence(sequence_name, reset_value, using)
    
    _ensure_sequence_exists(sequence_name, initial_value, using)
    
    connection = connections[using]
    with connection.cursor() as cursor:
        try:
            cursor.execute(SELECT.format(sequence_name=quote_ident(sequence_name)))
            last_value, is_called = cursor.fetchone()
            return last_value if is_called else initial_value - 1
        except Exception:
            return initial_value - 1


def get_next_value(
    sequence_name="default",
    initial_value=1,
    reset_value=None,
    using=DEFAULT_DB_ALIAS,
):
    """
    Return the next value for a sequence and increment it.
    
    If the sequence doesn't exist, it will be created with initial_value.
    If reset_value is provided, the sequence will be reset to that value first.
    """
    if reset_value is not None:
        reset_sequence(sequence_name, reset_value, using)
    
    _ensure_sequence_exists(sequence_name, initial_value, using)
    
    connection = connections[using]
    with connection.cursor() as cursor:
        cursor.execute(POSTGRESQL_NEXTVAL.format(sequence_name=quote_ident(sequence_name)))
        return cursor.fetchone()[0]


def get_next_values(
    sequence_name="default",
    count=1,
    initial_value=1,
    reset_value=None,
    using=DEFAULT_DB_ALIAS,
):
    """
    Return a list of the next 'count' values for a sequence.
    
    This is more efficient than calling get_next_value() multiple times.
    """
    if count <= 0:
        return []
    
    if reset_value is not None:
        reset_sequence(sequence_name, reset_value, using)
    
    _ensure_sequence_exists(sequence_name, initial_value, using)
    
    connection = connections[using]
    with connection.cursor() as cursor:
        values = []
        quoted = quote_ident(sequence_name)
        for _ in range(count):
            cursor.execute(POSTGRESQL_NEXTVAL.format(sequence_name=quoted))
            values.append(cursor.fetchone()[0])
        return values


def reset_sequence(sequence_name="default", value=1, using=DEFAULT_DB_ALIAS):
    """
    Reset a sequence to a specific value.
    
    The next call to get_next_value() will return value + 1.
    """
    _ensure_sequence_exists(sequence_name, value, using)
    
    connection = connections[using]
    with connection.cursor() as cursor:
        cursor.execute(POSTGRESQL_SETVAL.format(sequence_name=quote_ident(sequence_name)), [value])


def delete_sequence(sequence_name="default", using=DEFAULT_DB_ALIAS):
    """
    Delete a sequence entirely.
    """
    connection = connections[using]
    with connection.cursor() as cursor:
        cursor.execute(POSTGRESQL_DROP_SEQUENCE.format(sequence_name=quote_ident(sequence_name)))


def sequence_exists(sequence_name="default", using=DEFAULT_DB_ALIAS):
    """
    Check if a PostgreSQL sequence exists.
    
    Args:
        sequence_name (str): Name of the sequence to check
        using (str): Database alias to use
        
    Returns:
        bool: True if sequence exists, False otherwise
    """
    connection = connections[using]
    with connection.cursor() as cursor:
        cursor.execute(POSTGRESQL_SEQUENCE_EXISTS, [sequence_name])
        return cursor.fetchone()[0]


def _ensure_sequence_exists(sequence_name, initial_value, using):
    """
    Ensure that a PostgreSQL sequence exists, creating it if necessary.
    """
    connection = connections[using]
    
    with connection.cursor() as cursor:
        cursor.execute(POSTGRESQL_SEQUENCE_EXISTS, [sequence_name])
        exists = cursor.fetchone()[0]
        
        if not exists:
            create_sql = POSTGRESQL_CREATE_SEQUENCE.format(sequence_name=quote_ident(sequence_name))
            if initial_value != 1:
                create_sql = create_sql.replace("START WITH 1", f"START WITH {initial_value}")
            cursor.execute(create_sql)


class Sequence:
    """
    A sequence object that provides a more object-oriented interface.
    """
    
    def __init__(self, name="default", initial_value=1, using=DEFAULT_DB_ALIAS):
        self.name = name
        self.initial_value = initial_value
        self.using = using
    
    def get_next_value(self, reset_value=None):
        """Get the next value in the sequence."""
        return get_next_value(
            sequence_name=self.name,
            initial_value=self.initial_value,
            reset_value=reset_value,
            using=self.using,
        )
    
    def get_last_value(self, reset_value=None):
        """Get the last value in the sequence without incrementing."""
        return get_last_value(
            sequence_name=self.name,
            initial_value=self.initial_value,
            reset_value=reset_value,
            using=self.using,
        )
    
    def get_next_values(self, count, reset_value=None):
        """Get multiple next values in the sequence."""
        return get_next_values(
            sequence_name=self.name,
            count=count,
            initial_value=self.initial_value,
            reset_value=reset_value,
            using=self.using,
        )
    
    def reset(self, value=None):
        """Reset the sequence to a specific value."""
        if value is None:
            value = self.initial_value
        reset_sequence(self.name, value, self.using)
    
    def delete(self):
        """Delete the sequence."""
        delete_sequence(self.name, self.using)
    
    def exists(self):
        """Check if the sequence exists."""
        return sequence_exists(self.name, self.using)
