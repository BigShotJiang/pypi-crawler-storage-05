from django.core.management.base import BaseCommand
from django.db import connections, DEFAULT_DB_ALIAS


class Command(BaseCommand):
    help = 'List all PostgreSQL sequences created by django-sequence-pg'

    def add_arguments(self, parser):
        parser.add_argument(
            '--database',
            default=DEFAULT_DB_ALIAS,
            help='Database to list sequences from',
        )

    def handle(self, *args, **options):
        connection = connections[options['database']]
        
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT s.sequence_name, s.start_value, pgc.last_value, s.minimum_value, s.maximum_value, s.increment
                FROM information_schema.sequences s
                LEFT JOIN pg_sequences pgc
                    ON s.sequence_name = pgc.sequencename
                WHERE s.sequence_schema = 'public'
                ORDER BY s.sequence_name
            """)
            
            sequences = cursor.fetchall()
            
            if not sequences:
                self.stdout.write(self.style.WARNING('No sequences found.'))
                return
            
            self.stdout.write(self.style.SUCCESS(f'Found {len(sequences)} sequences:'))
            self.stdout.write('')
            
            for seq in sequences:
                name, start, last_val, min_val, max_val, increment = seq
                self.stdout.write(f'  {name}:')
                self.stdout.write(f'    Start Value: {start}')
                self.stdout.write(f'    Current Value: {last_val}')
                self.stdout.write(f'    Min Value: {min_val}')
                self.stdout.write(f'    Max Value: {max_val}')
                self.stdout.write(f'    Increment Value: {increment}')
                self.stdout.write('')
