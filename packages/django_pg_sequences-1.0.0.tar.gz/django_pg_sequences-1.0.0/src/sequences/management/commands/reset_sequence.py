from django.core.management.base import BaseCommand, CommandError
from django.db import DEFAULT_DB_ALIAS
from sequences import reset_sequence


class Command(BaseCommand):
    help = 'Reset a PostgreSQL sequence to a specific value'

    def add_arguments(self, parser):
        parser.add_argument('sequence_name', help='Name of the sequence to reset')
        parser.add_argument('value', type=int, help='Value to reset the sequence to')
        parser.add_argument(
            '--database',
            default=DEFAULT_DB_ALIAS,
            help='Database to reset sequence in',
        )

    def handle(self, *args, **options):
        sequence_name = options['sequence_name']
        value = options['value']
        database = options['database']
        
        try:
            reset_sequence(sequence_name, value, database)
            self.stdout.write(
                self.style.SUCCESS(
                    f'Successfully reset sequence "{sequence_name}" to {value}'
                )
            )
        except Exception as e:
            raise CommandError(f'Failed to reset sequence: {e}')
