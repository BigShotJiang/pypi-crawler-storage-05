from django.contrib import admin
from .models import SequenceRegistry


@admin.register(SequenceRegistry)
class SequenceRegistryAdmin(admin.ModelAdmin):
    list_display = ('name', 'initial_value', 'created_at', 'updated_at')
    list_filter = ('created_at', 'updated_at')
    search_fields = ('name',)
    readonly_fields = ('created_at', 'updated_at')
