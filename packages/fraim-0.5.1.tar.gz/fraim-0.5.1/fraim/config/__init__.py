# SPDX-License-Identifier: MIT
# Copyright (c) 2025 Resourcely Inc.

# Configuration package

from .config import Config

__all__ = ["Config"]
