.. include:: ../src/zope/testrunner/tests/testrunner-discovery.rst
