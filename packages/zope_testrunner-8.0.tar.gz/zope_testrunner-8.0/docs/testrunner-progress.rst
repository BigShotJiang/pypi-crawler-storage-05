.. include:: ../src/zope/testrunner/tests/testrunner-progress.rst
