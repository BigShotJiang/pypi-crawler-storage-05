.. include:: ../src/zope/testrunner/tests/testrunner-simple.rst
