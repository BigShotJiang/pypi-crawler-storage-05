====================
 Command Line Usage
====================

This package provides a script, ``zope-testrunner``, that's available when
installed via pip. It can also be used as a Python module with the
``-m`` option.

.. command-output:: python -m zope.testrunner --help
