This is a sample doctest

    >>> x=1
    >>> x
    1

Blah blah blah

    >>> x
    1

Blah blah blah

    >>> x
    1

Blah blah blah

    >>> x
    1

are we in the right laters?

    >>> import samplelayers
    >>> layer == samplelayers.layer
    True
    >>> layerx == samplelayers.layerx
    True
