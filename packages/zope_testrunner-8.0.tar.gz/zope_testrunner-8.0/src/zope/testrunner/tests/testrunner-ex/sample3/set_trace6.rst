    >>> from sample3.sampletests_d import f
    >>> f()
