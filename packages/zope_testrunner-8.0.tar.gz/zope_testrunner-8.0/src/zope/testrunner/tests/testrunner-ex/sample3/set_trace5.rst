    >>> x = 1
    >>> if 1:
    ...     import pdb; pdb.set_trace()
    ...     y = x
