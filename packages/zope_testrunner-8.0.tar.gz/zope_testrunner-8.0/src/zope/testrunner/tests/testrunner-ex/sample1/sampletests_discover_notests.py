def test_function_that_would_never_be_run(self):
    self.assertTrue(True)
