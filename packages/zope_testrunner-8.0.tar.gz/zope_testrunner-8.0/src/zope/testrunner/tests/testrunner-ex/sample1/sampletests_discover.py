import unittest


class TestA(unittest.TestCase):
    def test_truth(self):
        self.assertTrue(True)
