from setuptools import setup, find_packages


setup(
    name="PersonalSignature-STT",
    version="0.1",
    author="Abinash Nath Pandey",
    author_email="example@gmail.com",
    description="This is a speech to text package created by Abinash Nath Pandey"
)

packages = find_packages(),

install_requirements = [
    "selenium",
    "webdriver_manager"
]

