from logger.logger import PluginLogger

log = PluginLogger()

__exports__ = ("log",)
