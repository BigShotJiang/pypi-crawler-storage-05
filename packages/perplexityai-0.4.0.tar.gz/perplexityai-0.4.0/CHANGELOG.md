# Changelog

## 0.4.0 (2025-09-07)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/ppl-ai/perplexity-py/compare/v0.3.0...v0.4.0)

### Features

* **api:** update from perform -&gt; create ([35d2c42](https://github.com/ppl-ai/perplexity-py/commit/35d2c42567e59d53b37be7d4699f80755c09ca30))


### Chores

* update SDK settings ([a5a9d00](https://github.com/ppl-ai/perplexity-py/commit/a5a9d0009d07b48cf9b5f4521705acdb6878c904))

## 0.3.0 (2025-09-07)

Full Changelog: [v0.2.1...v0.3.0](https://github.com/ppl-ai/perplexity-py/compare/v0.2.1...v0.3.0)

### Features

* **api:** update project name ([b9ab21e](https://github.com/ppl-ai/perplexity-py/commit/b9ab21e669afb28c61908dc222cc5a94ec1d6b8e))

## 0.2.1 (2025-09-07)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/ppl-ai/perplexity-py/compare/v0.2.0...v0.2.1)

### Chores

* remove custom code ([e275207](https://github.com/ppl-ai/perplexity-py/commit/e27520747d07452162ae76fddcc7064d3d7f4631))
* update SDK settings ([b4668b0](https://github.com/ppl-ai/perplexity-py/commit/b4668b0ab36992c7e097f4e134a8eb36a2de7395))

## 0.2.0 (2025-09-07)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/ppl-ai/perplexity-py/compare/v0.1.0...v0.2.0)

### Features

* **api:** initial updates ([dd0709d](https://github.com/ppl-ai/perplexity-py/commit/dd0709dcc9775ae935a6dad72bc826d2a61dd740))
* **api:** simplify name ([6794370](https://github.com/ppl-ai/perplexity-py/commit/679437027a8d0f3d930902d3410e366cd392beb8))

## 0.1.0 (2025-09-07)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/ppl-ai/perplexity-py/compare/v0.0.2...v0.1.0)

### Features

* **api:** initial updates ([dd0709d](https://github.com/ppl-ai/perplexity-py/commit/dd0709dcc9775ae935a6dad72bc826d2a61dd740))

## 0.0.2 (2025-09-07)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/ppl-ai/perplexity-py/compare/v0.0.1...v0.0.2)

### Chores

* sync repo ([b968b23](https://github.com/ppl-ai/perplexity-py/commit/b968b23fc9d25d7cd9e84d2796e33a3f56c60656))
* update SDK settings ([e3c15b6](https://github.com/ppl-ai/perplexity-py/commit/e3c15b6ab6392d0f7605c7ba7666cec2eb405f23))
* update SDK settings ([235c22f](https://github.com/ppl-ai/perplexity-py/commit/235c22f4bdd73b3dd5657bd1caadef4bac172fbe))
