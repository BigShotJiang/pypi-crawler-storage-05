
from setuptools import find_packages, setup
setup(
    name='datalake-schema-evolution',
    packages=find_packages(include=['datalake-schema-evolution']),
    version='0.0.1',
    description='x',
    author=
    'x',
)
