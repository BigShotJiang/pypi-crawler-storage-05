from setuptools import setup, find_packages

setup(
    name="ring_flash_attn",
    version="0.1",
    author="zhuzilin",
    url="https://github.com/zhuzilin/ring-flash-attention",
    packages=find_packages(),
)
