from typing import Final

CURRENT_MEMORY_USAGE: Final = "current_memory_usage"
END_TIME: Final = "end_time"
ERROR: Final = "error"
INDEX: Final = "index"
MAX_MEMORY_USAGE: Final = "max_memory_usage"
CPU_SECONDS: Final = "cpu_seconds"
NAME: Final = "name"
START_TIME: Final = "start_time"
STATUS: Final = "status"
STDERR: Final = "stderr"
STDOUT: Final = "stdout"
