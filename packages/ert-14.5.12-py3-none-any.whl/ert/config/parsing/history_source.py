from enum import StrEnum


class HistorySource(StrEnum):
    REFCASE_SIMULATED = "REFCASE_SIMULATED"
    REFCASE_HISTORY = "REFCASE_HISTORY"
