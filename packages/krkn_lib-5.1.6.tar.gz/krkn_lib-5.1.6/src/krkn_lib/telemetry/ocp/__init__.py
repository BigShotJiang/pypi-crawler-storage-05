from .krkn_telemetry_openshift import *  # NOQA
