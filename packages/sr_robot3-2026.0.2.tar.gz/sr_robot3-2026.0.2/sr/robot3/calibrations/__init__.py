"""
To override/extend the camera calibrations provided by the april_vision library,
add calibration files to this directory.
"""
