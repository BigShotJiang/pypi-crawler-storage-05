from edc_list_data.model_mixins import ListUuidModelMixin


class CauseOfDeath(ListUuidModelMixin):
    class Meta(ListUuidModelMixin.Meta):
        pass
