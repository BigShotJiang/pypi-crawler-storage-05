=============
Release Notes
=============

-----
0.1.0
-----

Released: 2025-07-01

Initial release, including:

*  ``cliutil``

*  ``errorutil``

*  ``fileutil``

*  ``outpututil``
