# azcex

- CEX = Centralized Crypto Exchange(中心化数字货币交易所)

## Install

```bash
pip install azcex

# or
uv add azcex
```

## Exchanges

> cn 🇨🇳

- ✅ [Binance](https://www.binance.com/)
- ❎ [OKX](https://www.okx.com/)
- ❎ [Bitget](https://www.bitget.com/)
- ❎ [Bybit](https://www.bybit.com/)
- ❎ [Huobi](https://www.huobi.com/)
- ❎ [Gate.io](https://www.gate.io/)

> us 🇺🇸

- ❎ [Coinbase](https://www.coinbase.com/)
- ❎ [Bitfinex](https://www.bitfinex.com/)
- ❎ [Kraken](https://www.kraken.com/)
- ❎ [Gemini](https://www.gemini.com/)
- ❎ [Bitstamp](https://www.bitstamp.net/)
- ✅ [Poloniex](https://www.poloniex.com/)
- ✅ [BitMEX](https://www.bitmex.com/)
- ✅ [FTX](https://ftx.com/)
- ✅ [KuCoin](https://www.kucoin.com/)
