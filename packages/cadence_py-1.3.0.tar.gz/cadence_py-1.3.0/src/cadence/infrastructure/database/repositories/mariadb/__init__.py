"""MariaDB repository implementations for the Cadence framework.

This module provides MariaDB-specific repository implementations.
Currently a placeholder for future MariaDB support.
"""

__all__ = []
