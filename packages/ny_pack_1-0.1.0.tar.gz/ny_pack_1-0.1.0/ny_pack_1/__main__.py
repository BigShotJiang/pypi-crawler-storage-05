from .print_me_func import print_me


def main():
    print_me()


if __name__ == "__main__":
    main()
