# Search

[Ucnhistory Index](../README.md#ucnhistory-index) / [Ucnhistory](./index.md#ucnhistory) / Search

> Auto-generated documentation for [ucnhistory.search](../../ucnhistory/search.py) module.

- [Search](#search)
  - [build_tables](#build_tables)
  - [search](#search)

## build_tables

[Show source in search.py:11](../../ucnhistory/search.py#L11)

#### Signature

```python
def build_tables(): ...
```



## search

[Show source in search.py:21](../../ucnhistory/search.py#L21)

Use the get tables and get columns feature to search for matching names

#### Signature

```python
def search(var): ...
```