# Module

[Ucnhistory Index](../README.md#ucnhistory-index) / [Ucnhistory](./index.md#ucnhistory) / Module

> Auto-generated documentation for [ucnhistory.__main__](../../ucnhistory/__main__.py) module.
- [Module](#module)
