# Ucnhistory

[Ucnhistory Index](../README.md#ucnhistory-index) / Ucnhistory

> Auto-generated documentation for [ucnhistory](../../ucnhistory/__init__.py) module.

- [Ucnhistory](#ucnhistory)
  - [main](#main)
  - [Modules](#modules)

## main

[Show source in __init__.py:7](../../ucnhistory/__init__.py#L7)

#### Signature

```python
def main(): ...
```



## Modules

- [Module](./module.md)
- [Search](./search.md)
- [ucnhistory](./ucnhistory.md)
- [Version](./version.md)