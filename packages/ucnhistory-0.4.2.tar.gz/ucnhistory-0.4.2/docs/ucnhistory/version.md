# Version

[Ucnhistory Index](../README.md#ucnhistory-index) / [Ucnhistory](./index.md#ucnhistory) / Version

> Auto-generated documentation for [ucnhistory.version](../../ucnhistory/version.py) module.
- [Version](#version)
