from .recipe_template_1 import TEMPLATE as TEMPLATE1
from .recipe_template_2 import TEMPLATE as TEMPLATE2
from .recipe_template_3 import TEMPLATE as TEMPLATE3
from .recipe_template_4 import TEMPLATE as TEMPLATE4

TEMPLATES = TEMPLATE1, TEMPLATE2, TEMPLATE3, TEMPLATE4
