TEMPLATE = '''# Cooking recipe, checkout Cook at https://github.com/serweryn617/cook

default_project = 'custom_shell'
executable = 'python3'  # Only for local builds

projects = {}

projects['custom_shell'] = [
    'print("Hello")',
]
'''
