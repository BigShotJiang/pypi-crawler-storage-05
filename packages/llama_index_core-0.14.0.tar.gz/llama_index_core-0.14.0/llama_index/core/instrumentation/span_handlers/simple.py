from llama_index_instrumentation.span_handlers.simple import SimpleSpanHandler  # noqa
