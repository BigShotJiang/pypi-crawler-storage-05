from llama_index_instrumentation.span.base import BaseSpan  # noqa
