select
    *
from {{ref('transactions_seed')}}
