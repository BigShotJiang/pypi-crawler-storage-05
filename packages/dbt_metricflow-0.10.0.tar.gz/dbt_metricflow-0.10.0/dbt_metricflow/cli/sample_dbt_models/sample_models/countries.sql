select
    *
from {{ref('countries_seed')}}
