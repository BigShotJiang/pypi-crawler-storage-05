from wauo.printer import printer
from wauo.spiders import *
