from wauo.spiders.response import SelectorResponse
from wauo.spiders.spiders import WauoSpider
