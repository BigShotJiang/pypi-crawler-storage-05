"""Subject specific panflute filters for parsing LaTeX documents."""
