"""Filter and example TeX file for the PartSolPartSol filter.

See the filter.py file for the use cases of this filter.
"""
