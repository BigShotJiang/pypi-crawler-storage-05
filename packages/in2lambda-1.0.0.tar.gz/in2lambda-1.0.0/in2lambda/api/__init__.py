"""Contains various classes used to define how TeX questions would be processed by Lambda Feedback."""
