# in2lambda

[![GitHub Workflow Status (with event)](https://img.shields.io/github/actions/workflow/status/lambda-feedback/in2lambda/test.yml?style=flat-square&logo=github&label=tests)](https://github.com/lambda-feedback/in2lambda/actions/workflows/test.yml)
[![GitHub Workflow Status (with event)](https://img.shields.io/github/actions/workflow/status/lambda-feedback/in2lambda/deploy-docs.yml?style=flat-square&logo=googledocs&logoColor=white&label=docs)](https://lambda-feedback.github.io/in2lambda/)

in2lambda is a Python command line tool and library that automagically uploads questions to [Lambda Feedback](https://lambdafeedback.com/).

Find out more in the [documentation](https://lambda-feedback.github.io/in2lambda/).

```
$ pip install in2lambda
```
