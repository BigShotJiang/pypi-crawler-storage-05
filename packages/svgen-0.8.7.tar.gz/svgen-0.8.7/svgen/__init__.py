# =====================================
# generator=datazen
# version=3.2.3
# hash=6dbd96511bfd47795bc38e1d4b666c69
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "A tool for working with scalable vector graphics."
PKG_NAME = "svgen"
VERSION = "0.8.7"
