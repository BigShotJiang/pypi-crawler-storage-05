ScientiFlow CLI Proprietary License

This software is the proprietary property of ScientiFlow. You may not copy, modify, or distribute this software or any part of it without express written permission from ScientiFlow.

Usage of the software is governed by this license and subject to the terms of any commercial agreements with ScientiFlow.

For commercial licensing requests, contact ScientiFlow at scientiflow@gmail.com.
