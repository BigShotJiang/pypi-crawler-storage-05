from vital_llm_reasoner.ensemble.member.ensemble_member import EnsembleMember


class KGraphQueryMember(EnsembleMember):
    pass

    # query for entities and top info on them
