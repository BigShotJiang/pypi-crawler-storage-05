from vital_llm_reasoner.ensemble.member.ensemble_member import EnsembleMember


class WikidataSearchMember(EnsembleMember):
    pass

    # search for an entity and get that entity plus top-line
    # info on that entity
