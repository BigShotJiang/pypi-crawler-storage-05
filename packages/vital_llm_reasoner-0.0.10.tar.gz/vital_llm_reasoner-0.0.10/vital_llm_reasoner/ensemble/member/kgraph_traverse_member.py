from vital_llm_reasoner.ensemble.member.ensemble_member import EnsembleMember


class KGraphTraverseMember(EnsembleMember):
    pass

    # given node identifier, traverse the knowledge graph
    # given frame types and/or relation types of interest
