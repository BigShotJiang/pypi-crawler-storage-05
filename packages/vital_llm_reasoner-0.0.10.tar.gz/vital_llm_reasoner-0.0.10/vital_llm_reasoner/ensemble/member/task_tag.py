
class TaskTag:
    def __init__(self, member_name: str):
        self.member_name = member_name

