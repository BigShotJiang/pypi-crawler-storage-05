from vital_llm_reasoner.ensemble.member.ensemble_member import EnsembleMember


class ReasoningMember(EnsembleMember):
      pass

