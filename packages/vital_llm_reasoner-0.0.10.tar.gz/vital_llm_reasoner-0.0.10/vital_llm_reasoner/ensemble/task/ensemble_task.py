
class EnsembleTask:
    pass

