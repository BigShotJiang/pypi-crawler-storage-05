

class EnsembleToolManager:
    pass

# instantiate tools
# provide access to ensemble members to tools

