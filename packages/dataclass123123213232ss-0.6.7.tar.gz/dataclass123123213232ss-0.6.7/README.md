# dataclass123123213232ss
Safe PoC dummy package demonstrating dependency confusion.
Claimed by cygut7.
