"""
Package containing external modules or packages required by NetPyNE

This subpackage contains external modules or packages required by NetPyNE which are either not available via pip or have been slightly modified.

"""
