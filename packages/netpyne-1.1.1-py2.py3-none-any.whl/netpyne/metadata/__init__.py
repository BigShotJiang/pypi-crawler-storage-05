"""
Package dealing with metadata

"""

from .metadata import metadata
