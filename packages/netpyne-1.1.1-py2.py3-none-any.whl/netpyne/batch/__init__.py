"""
Package for handling batches of simulations

"""

from .batch import Batch
