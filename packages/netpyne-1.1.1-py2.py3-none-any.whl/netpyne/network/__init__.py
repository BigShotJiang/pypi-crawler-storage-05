"""
Package for dealing with network models

"""

from .network import Network
from .pop import Pop
