from batchtk.runtk.runners import Runner, get_class
RS = get_class()
RS._reinstance = True# get appropriate Runner object for inheritance and comms
from netpyne.batchtools.runners import Runner_SimConfig
from netpyne.batchtools.comm import Comm
from batchtk.runtk import dispatchers
from netpyne.batchtools import submits
from batchtk import runtk
from netpyne.batchtools.analysis import Analyzer

comm = Comm()

dispatchers = dispatchers
submits = submits
runtk = runtk

from netpyne import specs # plan to deprecate this in future versions
specs = specs # use from netpyne import specs
#from ray import tune as space.comm
#list and lb ub

