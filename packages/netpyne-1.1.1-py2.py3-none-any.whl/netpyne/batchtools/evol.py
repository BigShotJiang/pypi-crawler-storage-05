import numpy
from cmaes import CMA

from netpyne.batchtools import specs, comm

# ---- Rosenbrock Function & Constant Definition ---- #
