# mmar-flame

Flexible LLM-Assisted Moderation Engine: https://arxiv.org/abs/2502.09175
Inference Only

## Installation

```bash
pip install mmar-flame
```
