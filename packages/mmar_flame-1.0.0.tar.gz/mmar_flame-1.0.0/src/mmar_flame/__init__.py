"""mmar-flame package.

Flexible and Fast Moderation Engine
"""

from .moderator import Moderator


__version__ = "1.0.0"

__all__ = [
    "Moderator"
]
