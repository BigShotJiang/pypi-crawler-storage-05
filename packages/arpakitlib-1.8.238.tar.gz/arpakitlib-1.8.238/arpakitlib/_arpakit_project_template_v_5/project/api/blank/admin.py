from project.api.blank.common import SimpleBlankAPI


class AdminBlankAPI(SimpleBlankAPI):
    pass
