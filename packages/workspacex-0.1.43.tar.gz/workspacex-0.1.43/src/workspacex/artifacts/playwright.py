from workspacex import Artifact


class PlaywrightArtifact(Artifact):
    pass