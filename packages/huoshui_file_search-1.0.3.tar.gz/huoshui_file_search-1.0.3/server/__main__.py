#!/usr/bin/env python3

from .main import main

def run():
    """Entry point for the package"""
    main()

if __name__ == "__main__":
    run()