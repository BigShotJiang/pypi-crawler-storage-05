def main():
    print("Hello from cartes-dictee!")


if __name__ == "__main__":
    main()
