from spetlr.exceptions.configurator_exceptions import (
    SpetlrConfiguratorInvalidSqlException,
)


class _UnpackAttemptFailed(SpetlrConfiguratorInvalidSqlException):
    pass
