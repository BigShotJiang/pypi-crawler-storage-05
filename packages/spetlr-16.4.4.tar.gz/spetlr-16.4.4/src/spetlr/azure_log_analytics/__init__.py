from .azure_log_analytics_handle import AzureLogAnalyticsHandle

__all__ = [
    AzureLogAnalyticsHandle,
]
