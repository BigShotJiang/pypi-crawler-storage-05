def main():
    raise Exception("Use standard pip install pre-commit for hooks")
