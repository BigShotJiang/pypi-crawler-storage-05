import importlib_metadata

__version__ = importlib_metadata.version("spetlr")
