from .singleton import Singleton  # noqa: F401
