from spetlr.exceptions import SpetlrException


class PowerBiException(SpetlrException):
    pass
