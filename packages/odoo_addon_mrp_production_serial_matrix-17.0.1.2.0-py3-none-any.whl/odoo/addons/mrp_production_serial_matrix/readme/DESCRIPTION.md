This module aims to ease the processing of Manufacturing Orders with the
following characteristics:

- The finished product is tracked by unique serial numbers.
- The quantity to be produced is more than one unit.
- Some of the components are tracked by serial numbers and/or lots.
