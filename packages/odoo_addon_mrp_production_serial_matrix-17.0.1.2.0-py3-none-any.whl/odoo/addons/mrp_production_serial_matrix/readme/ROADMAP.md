Currently, there are some limitations :

- Components tracked by lots will only have one column. This means that
  all the quantity needed of this component to manufacture a finished
  product unit ( serial number) will be consuming a single lot.
