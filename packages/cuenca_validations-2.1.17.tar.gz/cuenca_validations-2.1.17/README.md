# Cuenca - validations

[![test](https://github.com/cuenca-mx/cuenca-validations/workflows/test/badge.svg)](https://github.com/cuenca-mx/cuenca-validations/actions?query=workflow%3Atest)
[![codecov](https://codecov.io/gh/cuenca-mx/cuenca-validations/branch/master/graph/badge.svg)](https://codecov.io/gh/cuenca-mx/cuenca-validations)
[![PyPI](https://img.shields.io/pypi/v/cuenca-validations.svg)](https://pypi.org/project/cuenca-validations/)

Shared validations library across multiple Cuenca projects
