def main():
    print("Hello from substack-reader!")


if __name__ == "__main__":
    main()
