from .server import serve


def main():
    print("Starting Meta-Prompting MCP server...")
    serve()


if __name__ == "__main__":
    main()
