import sys

PY_VERSION = sys.version_info
