# Global variables

# bus types index used in matlab case files
PQ = 1
PV = 2
REF = 3
