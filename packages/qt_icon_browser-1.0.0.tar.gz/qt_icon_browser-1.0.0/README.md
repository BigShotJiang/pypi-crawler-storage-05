# qt_icon_browser

Displays all possible built-in (theme) icons.

### Copy code

Click any of the icons to copy the python code to create the icon to the clipboard.
