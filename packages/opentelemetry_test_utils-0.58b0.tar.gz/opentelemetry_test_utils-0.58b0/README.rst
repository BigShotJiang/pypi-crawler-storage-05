OpenTelemetry Test Utilities
============================

This package provides internal testing utilities for the OpenTelemetry Python project and provides no stability or quality guarantees.
Please do not use it for anything other than writing or running tests for the OpenTelemetry Python project (github.com/open-telemetry/opentelemetry-python).


References
----------
* `OpenTelemetry Project <https://opentelemetry.io/>`_
