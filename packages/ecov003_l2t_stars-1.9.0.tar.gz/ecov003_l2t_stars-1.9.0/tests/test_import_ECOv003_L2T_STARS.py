def test_import_ECOv003_L2T_STARS():
    import ECOv003_L2T_STARS
