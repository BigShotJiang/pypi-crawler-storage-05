This module allows the user to choose whether refunded quantities in
credit notes should be considered as quantities to be reinvoiced in the
related sales, thus deciding if they should be added or not to the
quantity to invoice of the related sales order line.
