When creating a credit note from an invoice, you can mark the checkbox
"Not reinvoice refunded quantity" to prevent the refunded quantities to
be deducted from the quantity invoiced of the related sales order lines.

Furthermore, after creating the credit note, you can mark the field
"Sale qty not to reinvoice" to decide the criteria to be used for each
specific invoice line.

Enabling the "Reinvoice credit note by default" flag in the Invoice
settings, will enable the "This credit note will be reinvoiced" flag on
Credit Notes by default.
