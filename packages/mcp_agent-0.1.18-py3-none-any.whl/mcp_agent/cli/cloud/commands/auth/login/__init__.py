"""MCP Agent Cloud login command."""

from .main import login

__all__ = ["login"]
