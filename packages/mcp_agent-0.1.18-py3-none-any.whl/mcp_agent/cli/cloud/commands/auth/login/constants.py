"""Constants for the MCP Agent CLI login command."""

# Default values
# TODO: Change to oauth2
DEFAULT_API_AUTH_PATH = "auth/signin?callbackUrl=%2Fapikeys%3Fcreate%3DMCP_AGENT_CLI"
