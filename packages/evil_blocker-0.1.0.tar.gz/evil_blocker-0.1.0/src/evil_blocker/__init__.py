def main() -> None:
    print("Hello from evil-blocker!")
