# new file
# Re-export for convenient import
from .result import TableResult

__all__ = ["TableResult"]
