"""
Utility functions for natural-pdf.
"""
