"""A Python package for dealing with Hebrew (Jewish) calendar dates.
"""


__version__ = '2.3.0'
