# AnisoCADO

[![Tests](https://github.com/AstarVienna/AnisoCADO/actions/workflows/tests.yml/badge.svg)](https://github.com/AstarVienna/AnisoCADO/actions/workflows/tests.yml)
[![Documentation Status](https://readthedocs.org/projects/anisocado/badge/?version=latest)](https://anisocado.readthedocs.io/en/latest/?badge=latest)
[![Poetry](https://img.shields.io/endpoint?url=https://python-poetry.org/badge/v0.json)](https://python-poetry.org/)
![dev version](https://img.shields.io/badge/dynamic/toml?url=https%3A%2F%2Fraw.githubusercontent.com%2FAstarVienna%2FAnisoCADO%2Fmain%2Fpyproject.toml&query=%24.project.version&label=dev%20version&color=teal)

[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
![GitHub Release Date](https://img.shields.io/github/release-date/AstarVienna/AnisoCADO)
[![PyPI - Version](https://img.shields.io/pypi/v/AnisoCADO)](https://pypi.org/project/AnisoCADO/)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/AnisoCADO)


A python package to generate off-axis PSFs for the SCAO mode for the ELT

Please note: this package is not yet finished yet! The code is fine, but the
documentation is lacking.

## Documentation

Apropos documentation. It can be found here:
[https://anisocado.readthedocs.io/en/latest/index.html](https://anisocado.readthedocs.io/en/latest/index.html)
