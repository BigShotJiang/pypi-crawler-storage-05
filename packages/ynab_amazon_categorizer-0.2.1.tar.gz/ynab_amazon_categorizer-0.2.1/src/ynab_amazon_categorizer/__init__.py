"""YNAB Amazon Categorizer - Automatically categorize Amazon transactions in YNAB."""

__version__ = "0.2.1"
__author__ = "dizzlkheinz"
__description__ = (
    "Automatically categorize Amazon transactions in YNAB with rich item information"
)
