Simple test case, with only a few rows each.

For convenience, ID numbers have the following layout:
- encounters start with 2
- patients start with 3
- instances start with 4
- providers start with 5