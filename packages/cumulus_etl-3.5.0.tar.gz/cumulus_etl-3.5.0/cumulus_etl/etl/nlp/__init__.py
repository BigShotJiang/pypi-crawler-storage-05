"""Subcommand to run NLP tasks"""

from .cli import run_nlp
