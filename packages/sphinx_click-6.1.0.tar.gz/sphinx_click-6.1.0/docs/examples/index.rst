Examples
========

.. toctree::
   :maxdepth: 1

   commands
   groups
   commandcollections
