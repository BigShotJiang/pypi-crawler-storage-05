Nested (full)
=============

.. click:: greet:greet
   :prog: greet
   :nested: full
