Commands
========

.. click:: greet:greet
   :prog: greet
   :commands: world
