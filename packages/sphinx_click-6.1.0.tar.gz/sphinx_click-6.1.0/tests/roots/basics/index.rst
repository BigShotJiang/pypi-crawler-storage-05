Basics
======

.. click:: greet:greet
   :prog: greet
