(installation)=

# Installation

Solverz officially supports Python>=3.10.

## Using PIP

The standard utility for installing Python packages is ``pip``.  You
can install Solverz in your system Python installation by executing
the following in a shell:

```shell
pip install Solverz
```
