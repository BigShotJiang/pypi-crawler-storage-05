(get-help)=

# Get Help

## Reporting issues

Please report the bugs [here](https://github.com/smallbunnies/Solverz/issues). 

When reporting issues please include as much detail as possible about your
operating system, Solverz version and python version. Whenever possible, please
also include a brief, self-contained code example that demonstrates the problem.

