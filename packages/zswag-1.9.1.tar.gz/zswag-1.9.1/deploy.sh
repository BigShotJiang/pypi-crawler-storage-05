#!/usr/bin/env bash
twine upload dist/*
