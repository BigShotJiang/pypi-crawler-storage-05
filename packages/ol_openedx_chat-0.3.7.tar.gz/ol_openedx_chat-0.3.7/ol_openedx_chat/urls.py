"""
URLs for ol_openedx_chat.
"""

urlpatterns = [  # type: ignore[var-annotated]
    # Fill in URL patterns and views here.
    # re_path(r'', TemplateView.as_view(template_name="ol_openedx_chat/base.html")),  # noqa: ERA001, E501
]
