{{ objname | escape | underline(line="=") }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}