.. _user_guide:

==========
User Guide
==========

.. toctree::
   :numbered:
   :maxdepth: 1

   unsupervised.rst
   multioutput.rst
   redundancy.rst
   ols_and_omp.rst
   narx.rst
   pruning.rst
