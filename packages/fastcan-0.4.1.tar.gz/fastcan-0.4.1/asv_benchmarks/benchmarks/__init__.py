"""Benchmark suite for fastcan using ASV"""
