import imagej

def start_imagej():
    return ij = imagej.init()

