## fputils: Utility classes for functional programming in Python

## Setup
Install fputils with pip:
```
pip install fputils 
```
