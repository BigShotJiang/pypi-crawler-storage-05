# coding: utf-8

from .main_window import MainWindow
from .__version__ import __version__
