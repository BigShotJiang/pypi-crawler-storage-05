"""Pipeline module for CANS framework training and evaluation."""

from .runner import CANSRunner

__all__ = ['CANSRunner']