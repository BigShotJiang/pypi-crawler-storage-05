from .cluster import Cluster


class ProjectedCluster(Cluster):
    x_coord: float
    y_coord: float
    level: int
