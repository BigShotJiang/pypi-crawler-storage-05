# Dimensionality Reduction

This page is under construction. It will contain detailed information about how Kura reduces dimensions for visualization.

In the meantime, you can refer to the [API documentation](../api/index.md) for technical details.