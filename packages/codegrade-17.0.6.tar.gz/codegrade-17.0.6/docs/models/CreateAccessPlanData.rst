CreateAccessPlanData
====================

.. currentmodule:: codegrade.models.create_access_plan_data

.. autoclass:: CreateAccessPlanData
   :members: tenant_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
