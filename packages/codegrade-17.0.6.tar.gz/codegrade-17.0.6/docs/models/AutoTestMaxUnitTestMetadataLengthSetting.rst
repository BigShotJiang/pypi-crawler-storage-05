AutoTestMaxUnitTestMetadataLengthSetting
========================================

.. currentmodule:: codegrade.models.auto_test_max_unit_test_metadata_length_setting

.. autoclass:: AutoTestMaxUnitTestMetadataLengthSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
