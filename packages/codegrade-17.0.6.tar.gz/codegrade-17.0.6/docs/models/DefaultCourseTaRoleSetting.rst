DefaultCourseTaRoleSetting
==========================

.. currentmodule:: codegrade.models.default_course_ta_role_setting

.. autoclass:: DefaultCourseTaRoleSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
