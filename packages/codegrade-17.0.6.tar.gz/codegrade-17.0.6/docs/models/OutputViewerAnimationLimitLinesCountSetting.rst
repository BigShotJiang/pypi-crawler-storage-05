OutputViewerAnimationLimitLinesCountSetting
===========================================

.. currentmodule:: codegrade.models.output_viewer_animation_limit_lines_count_setting

.. autoclass:: OutputViewerAnimationLimitLinesCountSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
