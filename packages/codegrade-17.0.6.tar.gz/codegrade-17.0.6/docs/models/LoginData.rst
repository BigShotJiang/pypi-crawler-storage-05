LoginData
=========

.. currentmodule:: codegrade.models.login_data

.. autoclass:: LoginData
   :members: username, tenant_id, password
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
