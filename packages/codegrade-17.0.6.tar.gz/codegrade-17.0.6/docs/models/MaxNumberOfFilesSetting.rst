MaxNumberOfFilesSetting
=======================

.. currentmodule:: codegrade.models.max_number_of_files_setting

.. autoclass:: MaxNumberOfFilesSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
