BaseAccessPlanData
==================

.. currentmodule:: codegrade.models.base_access_plan_data

.. autoclass:: BaseAccessPlanData
   :members: currency, amount, refund_period, tax_behavior, duration
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
