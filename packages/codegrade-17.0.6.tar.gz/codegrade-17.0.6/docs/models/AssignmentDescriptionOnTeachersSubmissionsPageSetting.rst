AssignmentDescriptionOnTeachersSubmissionsPageSetting
=====================================================

.. currentmodule:: codegrade.models.assignment_description_on_teachers_submissions_page_setting

.. autoclass:: AssignmentDescriptionOnTeachersSubmissionsPageSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
