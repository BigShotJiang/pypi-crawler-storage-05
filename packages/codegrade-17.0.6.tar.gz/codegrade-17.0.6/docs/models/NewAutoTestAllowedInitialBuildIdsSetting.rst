NewAutoTestAllowedInitialBuildIdsSetting
========================================

.. currentmodule:: codegrade.models.new_auto_test_allowed_initial_build_ids_setting

.. autoclass:: NewAutoTestAllowedInitialBuildIdsSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
