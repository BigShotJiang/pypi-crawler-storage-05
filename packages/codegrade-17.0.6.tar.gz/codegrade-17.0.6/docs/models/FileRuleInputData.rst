FileRuleInputData
=================

.. currentmodule:: codegrade.models.file_rule_input_data

.. autoclass:: FileRuleInputData
   :members: rule_type, file_type, name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
