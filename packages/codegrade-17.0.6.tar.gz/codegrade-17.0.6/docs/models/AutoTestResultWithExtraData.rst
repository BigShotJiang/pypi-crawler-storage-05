AutoTestResultWithExtraData
===========================

.. currentmodule:: codegrade.models.auto_test_result_with_extra_data

.. autoclass:: AutoTestResultWithExtraData
   :members: assignment_id, course_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
