CustomOutputLogBase
===================

.. currentmodule:: codegrade.models.custom_output_log_base

.. autoclass:: CustomOutputLogBase
   :members: stdout, stderr, exit_code, time_spend
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
