DeletionType
============

.. currentmodule:: codegrade.models.deletion_type

.. class:: DeletionType

**Options**

* ``empty_directory``
* ``denied_file``
* ``leading_directory``
