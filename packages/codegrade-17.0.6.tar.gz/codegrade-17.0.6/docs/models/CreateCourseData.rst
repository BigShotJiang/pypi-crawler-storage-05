CreateCourseData
================

.. currentmodule:: codegrade.models.create_course_data

.. autoclass:: CreateCourseData
   :members: name, tenant_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
