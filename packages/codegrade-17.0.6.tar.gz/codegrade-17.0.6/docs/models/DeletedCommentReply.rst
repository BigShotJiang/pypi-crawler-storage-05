DeletedCommentReply
===================

.. currentmodule:: codegrade.models.deleted_comment_reply

.. autoclass:: DeletedCommentReply
   :members: deleted
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
