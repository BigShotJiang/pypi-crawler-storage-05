JupyterNotebookRunningEnabledSetting
====================================

.. currentmodule:: codegrade.models.jupyter_notebook_running_enabled_setting

.. autoclass:: JupyterNotebookRunningEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
