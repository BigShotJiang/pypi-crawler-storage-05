LTI1p3ProviderData
==================

.. currentmodule:: codegrade.models.lti1p3_provider_data

.. autoclass:: LTI1p3ProviderData
   :members: tenant_id, iss, lms, lti_version, label
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
