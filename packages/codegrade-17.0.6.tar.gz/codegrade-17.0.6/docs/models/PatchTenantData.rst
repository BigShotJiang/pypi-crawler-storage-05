PatchTenantData
===============

.. currentmodule:: codegrade.models.patch_tenant_data

.. autoclass:: PatchTenantData
   :members: name, abbreviated_name, order_category, contract_start, is_hidden
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
