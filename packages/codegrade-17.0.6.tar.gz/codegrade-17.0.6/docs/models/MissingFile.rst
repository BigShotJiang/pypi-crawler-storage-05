MissingFile
===========

.. currentmodule:: codegrade.models.missing_file

.. autoclass:: MissingFile
   :members: file_type, name, rule_type
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
