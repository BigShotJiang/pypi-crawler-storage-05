CreateRepositoryGitProviderData
===============================

.. currentmodule:: codegrade.models.create_repository_git_provider_data

.. autoclass:: CreateRepositoryGitProviderData
   :members: name, assignment_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
