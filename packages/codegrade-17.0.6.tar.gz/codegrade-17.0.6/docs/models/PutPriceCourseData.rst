PutPriceCourseData
==================

.. currentmodule:: codegrade.models.put_price_course_data

.. autoclass:: PutPriceCourseData
   :members: currency, amount, refund_period, tax_behavior
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
