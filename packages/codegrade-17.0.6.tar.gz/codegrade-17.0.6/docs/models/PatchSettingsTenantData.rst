PatchSettingsTenantData
=======================

.. currentmodule:: codegrade.models.patch_settings_tenant_data

.. autoclass:: PatchSettingsTenantData
   :members: updates
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
