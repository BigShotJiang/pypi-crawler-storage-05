AllAutoTestResults
==================

.. currentmodule:: codegrade.models.all_auto_test_results

.. autoclass:: AllAutoTestResults
   :members: total_amount, results
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
