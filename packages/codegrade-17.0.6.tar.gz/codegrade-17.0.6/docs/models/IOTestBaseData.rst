IOTestBaseData
==============

.. currentmodule:: codegrade.models.io_test_base_data

.. autoclass:: IOTestBaseData
   :members: program, inputs
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
