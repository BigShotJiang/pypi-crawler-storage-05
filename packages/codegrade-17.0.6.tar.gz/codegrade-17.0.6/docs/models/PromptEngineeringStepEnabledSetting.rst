PromptEngineeringStepEnabledSetting
===================================

.. currentmodule:: codegrade.models.prompt_engineering_step_enabled_setting

.. autoclass:: PromptEngineeringStepEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
