CoursePurchase
==============

.. currentmodule:: codegrade.models.course_purchase

.. autoclass:: CoursePurchase
   :members: scope, purchased_item
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
