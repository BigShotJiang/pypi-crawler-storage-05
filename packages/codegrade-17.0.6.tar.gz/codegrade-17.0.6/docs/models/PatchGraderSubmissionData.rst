PatchGraderSubmissionData
=========================

.. currentmodule:: codegrade.models.patch_grader_submission_data

.. autoclass:: PatchGraderSubmissionData
   :members: user_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
