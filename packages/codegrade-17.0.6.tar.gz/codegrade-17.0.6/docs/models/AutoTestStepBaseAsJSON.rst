AutoTestStepBaseAsJSON
======================

.. currentmodule:: codegrade.models.auto_test_step_base_as_json

.. autoclass:: AutoTestStepBaseAsJSON
   :members: name, weight, hidden
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
