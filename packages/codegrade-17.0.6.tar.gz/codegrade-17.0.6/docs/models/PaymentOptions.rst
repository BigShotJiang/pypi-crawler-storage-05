PaymentOptions
==============

.. currentmodule:: codegrade.models.payment_options

.. autoclass:: PaymentOptions
   :members: course_purchase, access_plans
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
