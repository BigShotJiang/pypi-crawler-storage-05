EmailUsersCourseData
====================

.. currentmodule:: codegrade.models.email_users_course_data

.. autoclass:: EmailUsersCourseData
   :members: subject, body, email_all_users, users
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
