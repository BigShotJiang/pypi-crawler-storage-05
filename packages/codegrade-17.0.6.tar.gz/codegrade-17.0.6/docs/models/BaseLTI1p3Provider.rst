BaseLTI1p3Provider
==================

.. currentmodule:: codegrade.models.base_lti1p3_provider

.. autoclass:: BaseLTI1p3Provider
   :members: lms, capabilities, version, iss, presentation
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
