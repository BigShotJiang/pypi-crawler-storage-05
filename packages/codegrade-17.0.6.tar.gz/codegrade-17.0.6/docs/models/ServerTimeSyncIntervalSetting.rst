ServerTimeSyncIntervalSetting
=============================

.. currentmodule:: codegrade.models.server_time_sync_interval_setting

.. autoclass:: ServerTimeSyncIntervalSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
