HealthInformation
=================

.. currentmodule:: codegrade.models.health_information

.. autoclass:: HealthInformation
   :members: application, database, uploads, broker, mirror_uploads, temp_dir, tasks, auto_test, limiter, redis
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
