Course
======

.. currentmodule:: codegrade.models.course

.. autoclass:: Course
   :members: id, name, created_at, virtual, state, tenant_id, price
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
