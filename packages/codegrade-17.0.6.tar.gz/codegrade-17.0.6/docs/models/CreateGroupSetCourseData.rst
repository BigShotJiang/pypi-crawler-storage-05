CreateGroupSetCourseData
========================

.. currentmodule:: codegrade.models.create_group_set_course_data

.. autoclass:: CreateGroupSetCourseData
   :members: minimum_size, maximum_size, id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
