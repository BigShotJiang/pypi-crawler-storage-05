CopyAutoTestData
================

.. currentmodule:: codegrade.models.copy_auto_test_data

.. autoclass:: CopyAutoTestData
   :members: assignment_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
