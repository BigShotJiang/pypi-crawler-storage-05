"""DataFrame modules for bitvavo_client."""
