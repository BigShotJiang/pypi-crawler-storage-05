-------
Prompts
-------
.. mcpdocs:prompts:: everything
