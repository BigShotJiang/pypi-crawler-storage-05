------------------
Resource templates
------------------
.. mcpdocs:resource_templates:: everything
