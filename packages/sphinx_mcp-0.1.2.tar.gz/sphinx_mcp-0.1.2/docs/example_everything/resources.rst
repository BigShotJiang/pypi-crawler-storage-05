---------
Resources
---------
.. mcpdocs:resources:: everything
