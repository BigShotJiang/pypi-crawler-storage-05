-------
Prompts
-------
.. mcpdocs:prompts:: pymcp
