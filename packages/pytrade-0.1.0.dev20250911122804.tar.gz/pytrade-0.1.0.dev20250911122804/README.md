# Pytrade

A systematic trading framework.

To install in editable mode, run:

```
pip install -e . --config-settings editable_mode=compat
```

The `--config-settings editable_mode=compat` part is needed because we're using pyproject.toml rather than
setup.py.