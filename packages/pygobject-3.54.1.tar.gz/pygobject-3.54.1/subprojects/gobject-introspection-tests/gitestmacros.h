/*
SPDX-License-Identifier: GPL-2.0-or-later AND LGPL-2.0-or-later AND MIT
SPDX-FileCopyrightText: 2014 Chun-wei Fan
*/

#pragma once

#ifndef GI_TEST_EXTERN
#define GI_TEST_EXTERN extern
#endif
