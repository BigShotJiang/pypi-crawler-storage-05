Display Widgets
===============

Learn how to use the most basic elements to display things, like text, images,
icons or ongoing progress.

.. toctree::
   :maxdepth: 1
   :caption: Contents

   display-widgets/label
   display-widgets/image
   display-widgets/picture
   display-widgets/progressbar
   display-widgets/spinner
