const viewAllSetsGetUrl =
    "{% url 'core-admin:core_oaipmh_harvester_app_all_sets' %}";
const viewAllMetadataFormatsGetUrl  =
    "{% url 'core-admin:core_oaipmh_harvester_app_all_metadata_prefix' %}";