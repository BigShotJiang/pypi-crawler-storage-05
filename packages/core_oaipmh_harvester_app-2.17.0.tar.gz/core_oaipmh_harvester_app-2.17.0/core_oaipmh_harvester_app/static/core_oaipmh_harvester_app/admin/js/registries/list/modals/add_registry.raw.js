var addRegistryPostUrl = "{% url 'core-admin:core_oaipmh_harvester_app_add_registry' %}";
var indexRegistryUrl = "{% url 'core-admin:core_oaipmh_harvester_app_registries' %}";