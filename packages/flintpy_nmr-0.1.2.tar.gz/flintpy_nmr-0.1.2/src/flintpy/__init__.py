"""Top-level package for flintpy."""

__author__ = """Raquel Serial"""
__email__ = "raquelserial@gmail.com"
__version__ = "0.1.2"
