Integração e emissão da CF-e através do Ponto de Venda para
equipamentos SAT (SP) e MF-e (CE).
