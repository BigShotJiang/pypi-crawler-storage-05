Para configurar esse módulo você precisa configurar o Ponto de venda, prestando atenção nos seguintes campos:

  * Ativar a opção IoT Box e Brasil Fiscal;
  * A aba SAT configurar os detalhes do seu equipamento.
