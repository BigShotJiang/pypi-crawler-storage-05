Esse módulo depende:

* l10n_br_pos

Alem disso você vi precisar de um IOT BOX, podendo ser o da Odoo SA ou o Pywebdriver, com os respectivos drivers para CF-E:
  - Odoo SA: hw_sat, disponível em github.com/oca/l10n-brazil;
  - Pywebdriver disponível em:
    - https://github.com/kmee/pywebdriver/releases
