from enum import StrEnum


class CostCenters(StrEnum):
    ki: str = "ki"
    kth: str = "kth"
