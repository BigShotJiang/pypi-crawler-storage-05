"""
Database dependencies for use in API endpoint routes.

"""

from .core import get_db_connection as get_db_connection
