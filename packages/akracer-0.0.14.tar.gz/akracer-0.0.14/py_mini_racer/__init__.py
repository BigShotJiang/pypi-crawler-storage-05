from . import py_mini_racer

__author__ = 'Albert King'
__email__ = 'albertandking@gmail.com'
__version__ = '0.0.14'

MiniRacer = py_mini_racer.MiniRacer

__all__ = ['py_mini_racer', 'MiniRacer']
