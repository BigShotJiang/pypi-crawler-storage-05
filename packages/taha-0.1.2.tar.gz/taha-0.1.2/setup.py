from setuptools import setup

setup(
    name='taha',
    version='0.1.2',
    py_modules=['taha'],
    author='NS-TAHA1515',
    description='کتابخونه‌ی ساده برای تست نصب با pip',
    python_requires='>=3.6',
)
