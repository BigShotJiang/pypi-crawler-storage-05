# filepath: c:\Users\Andrey\Coding\ai-bash\setup.py
from setuptools import setup
setup()