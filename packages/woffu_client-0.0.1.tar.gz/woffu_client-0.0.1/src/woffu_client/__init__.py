from __future__ import annotations

from .woffu_api_client import WoffuAPIClient
from .stdrequests_session import Session, HTTPResponse