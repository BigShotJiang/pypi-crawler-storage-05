# BinStandard

An Simple Library With Fetch Bin info With binlist.net, Fully Asyncio With Uvloop Power.

## Install
```bash
pip install BinStandard

