__version__ = "0.1.0"
__author__ = "@Nactire"

from .client import BinClient
