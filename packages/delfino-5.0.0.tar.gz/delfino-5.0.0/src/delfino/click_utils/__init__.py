from delfino.click_utils.set_from_config import SetOptionFromConfigCallback

__all__ = ["SetOptionFromConfigCallback"]
