import click


@click.command()
def lint():
    pass


@click.command()
def build():
    pass
