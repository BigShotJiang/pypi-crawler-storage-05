import click


@click.command()
def typecheck():
    pass
