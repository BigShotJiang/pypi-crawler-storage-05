import click


@click.command()
def different_command():
    pass
