import click


@click.command()
def format():
    pass
