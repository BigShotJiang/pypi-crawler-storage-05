import click


@click.command()
def no_entry_point_command():
    pass
