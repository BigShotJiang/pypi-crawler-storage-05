from .vindaloo import VERSION, app
from .objects import *

__version__ = VERSION
