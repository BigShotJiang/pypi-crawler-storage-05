"""
    Exception module .
"""
