---
applyTo: '**'
---
Use this to configure your development environment
1. Activate Python Environment: `source .venv/bin/activate`
2. Use uv instead of direct pip
3. Run pytest using `uv run pytest tests`
