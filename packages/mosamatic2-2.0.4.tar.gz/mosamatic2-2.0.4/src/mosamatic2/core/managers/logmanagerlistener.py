class LogManagerListener:
    def new_message(self, message):
        raise NotImplementedError()