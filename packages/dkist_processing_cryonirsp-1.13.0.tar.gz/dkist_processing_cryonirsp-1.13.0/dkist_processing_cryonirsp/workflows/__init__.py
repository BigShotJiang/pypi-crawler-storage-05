"""Workflow package."""

from dkist_processing_cryonirsp.config import dkist_processing_cryonirsp_configurations
