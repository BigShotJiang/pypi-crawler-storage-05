# tlab

土持研内部共有プログラムパッケージ

# インストール
```bash
pip install tlab
```
もしくは
```bash
git clone https://github.com/tsuchimoc/tlab.git
pip install -e .
```

# 使い方
esa参照
https://tsuchimochi.esa.io/posts/160

