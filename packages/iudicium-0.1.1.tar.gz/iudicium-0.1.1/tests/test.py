"""Test that the test works."""


def test():
    """Test that the test works."""
    assert True
