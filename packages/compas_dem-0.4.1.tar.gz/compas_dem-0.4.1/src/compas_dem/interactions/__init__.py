from .contact import FrictionContact

__all__ = [
    "FrictionContact",
]
