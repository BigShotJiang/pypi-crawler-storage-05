"""Core module for the Eastmoney Trading Library."""
