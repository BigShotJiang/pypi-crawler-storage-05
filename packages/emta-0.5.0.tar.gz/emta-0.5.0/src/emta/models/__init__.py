"""Data models for the Eastmoney Trading Library."""
