"""Utility functions for the Eastmoney Trading Library."""
