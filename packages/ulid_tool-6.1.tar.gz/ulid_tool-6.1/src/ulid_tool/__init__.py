__version__ = "6.1"


SYSTEM_CHECKS: bool = True


