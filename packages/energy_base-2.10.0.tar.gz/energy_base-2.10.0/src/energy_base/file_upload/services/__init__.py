from .minio import minio_service

__all__ = [
    'minio_service',
]
