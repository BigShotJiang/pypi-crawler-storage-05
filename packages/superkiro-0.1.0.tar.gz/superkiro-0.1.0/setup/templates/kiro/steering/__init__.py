"""Steering templates for Kiro."""

