"""Kiro template package."""

