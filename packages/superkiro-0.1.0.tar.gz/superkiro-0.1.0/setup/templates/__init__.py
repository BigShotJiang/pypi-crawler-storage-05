"""Package for bundled templates (data files)."""

