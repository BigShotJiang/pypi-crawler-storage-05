# == __init__.py ==#

__title__ = 'github.io'
__authors__ = 'VarMonke', 'sudosnok'
__version__ = '0.0.1'
__license__ = 'MIT'
__copyright__ = 'Copyright (c) 2022-present VarMonke & sudosnok'
