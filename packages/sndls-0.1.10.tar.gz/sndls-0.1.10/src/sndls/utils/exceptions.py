
class FileExtensionError(Exception):
    pass


class FolderNotFoundError(Exception):
    pass


class ShapeError(Exception):
    pass
