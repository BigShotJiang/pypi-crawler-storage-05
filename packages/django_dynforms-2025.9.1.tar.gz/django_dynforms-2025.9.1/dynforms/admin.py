from django.contrib import admin

from dynforms import models

# Register your models here.
admin.site.register(models.FormType)

