"""
UI components for Omnimancer.

This package contains user interface components including
cancellation handlers and visual indicators.
"""
