# change_detection module

::: geoai.change_detection
