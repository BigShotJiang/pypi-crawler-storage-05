# detectron2 module

::: geoai.detectron2
