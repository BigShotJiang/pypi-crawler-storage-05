# segmentation module

::: geoai.segmentation
