# DINOv3 module

::: geoai.dinov3
