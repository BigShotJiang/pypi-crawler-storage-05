# segment module

::: geoai.segment
