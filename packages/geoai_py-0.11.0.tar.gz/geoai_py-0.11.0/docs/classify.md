# classify module

::: geoai.classify
