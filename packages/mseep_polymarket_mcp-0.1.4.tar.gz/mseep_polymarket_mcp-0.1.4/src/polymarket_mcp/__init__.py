"""
PolyMarket MCP Server
An MCP server implementation for interacting with the PolyMarket API.
"""

__version__ = "0.1.0"