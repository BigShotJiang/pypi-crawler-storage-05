__version__ = "0.6.1"  # 唯一维护的版本号
"""
1.python -m build
2.在Windows命令提示符中：
set PYTHONUTF8=1
twine upload dist/*

或者在PowerShell中：
$env:PYTHONUTF8=1
twine upload dist/*


1.django和fastapi的中间件
2.路由分发vs
3.堆栈分析
4.__slot__性能优化

"""