# SymmoraDemo

Простой демо-пакет для тестирования загрузки на PyPI.

Установка:
```bash
pip install symmorademo
