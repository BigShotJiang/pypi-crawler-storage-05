from .core import get_hello

__version__ = "0.6.0"

