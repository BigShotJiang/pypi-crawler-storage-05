def get_hello(gretting: str = "Symmora World" ) -> str:
    return f"{"*"*5} version 6 {"*"*3} : Hello, {gretting}!!!"

def symmora_add(a: int, b: int) -> int:
    return a + b

