"""Internal utilities for the Singer SDK."""
