"""Executable for fundamentals tap.

Run:

$ uv run python samples/aapl
"""

from __future__ import annotations

from . import Fundamentals

Fundamentals.cli()
