﻿singer_sdk.pagination.BaseOffsetPaginator
=========================================

.. currentmodule:: singer_sdk.pagination

.. autoclass:: BaseOffsetPaginator
    :members:
    :special-members: __init__, __call__