﻿singer_sdk.connectors.sql.SQLToJSONSchema
=========================================

.. currentmodule:: singer_sdk.connectors.sql

.. autoclass:: SQLToJSONSchema
    :members:
    :special-members: __init__, __call__