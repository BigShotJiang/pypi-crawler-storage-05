﻿singer_sdk.connectors.sql.JSONSchemaToSQL
=========================================

.. currentmodule:: singer_sdk.connectors.sql

.. autoclass:: JSONSchemaToSQL
    :members:
    :special-members: __init__, __call__