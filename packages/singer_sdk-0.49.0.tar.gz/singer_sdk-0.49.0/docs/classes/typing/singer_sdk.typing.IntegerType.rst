﻿singer_sdk.typing.IntegerType
=============================

.. currentmodule:: singer_sdk.typing

.. autoclass:: IntegerType
    :members:
    :special-members: __init__, __call__
    :inherited-members: JSONTypeHelper