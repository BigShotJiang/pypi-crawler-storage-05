﻿singer_sdk.typing.OneOf
=======================

.. currentmodule:: singer_sdk.typing

.. autoclass:: OneOf
    :members:
    :special-members: __init__, __call__