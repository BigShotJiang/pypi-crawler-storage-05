﻿singer_sdk.typing.ObjectType
============================

.. currentmodule:: singer_sdk.typing

.. autoclass:: ObjectType
    :members:
    :special-members: __init__, __call__