﻿singer_sdk.typing.RelativeJSONPointerType
=========================================

.. currentmodule:: singer_sdk.typing

.. autoclass:: RelativeJSONPointerType
    :members:
    :special-members: __init__, __call__