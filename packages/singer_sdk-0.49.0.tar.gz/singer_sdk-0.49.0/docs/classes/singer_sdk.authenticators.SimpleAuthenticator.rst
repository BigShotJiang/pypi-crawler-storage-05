﻿singer_sdk.authenticators.SimpleAuthenticator
=============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: SimpleAuthenticator
    :members:
    :special-members: __init__, __call__