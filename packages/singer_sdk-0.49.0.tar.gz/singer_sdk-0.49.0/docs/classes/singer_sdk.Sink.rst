﻿singer_sdk.Sink
===============

.. currentmodule:: singer_sdk

.. autoclass:: Sink
    :members:
    :special-members: __init__, __call__