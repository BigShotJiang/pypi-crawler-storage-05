﻿singer_sdk.exceptions.StreamMapConfigError
==========================================

.. currentmodule:: singer_sdk.exceptions

.. autoclass:: StreamMapConfigError
    :members:
    :special-members: __init__, __call__