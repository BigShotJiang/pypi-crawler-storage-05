"""Entry point for the tap."""

from __future__ import annotations

from . import TapBigQuery

TapBigQuery.cli()
