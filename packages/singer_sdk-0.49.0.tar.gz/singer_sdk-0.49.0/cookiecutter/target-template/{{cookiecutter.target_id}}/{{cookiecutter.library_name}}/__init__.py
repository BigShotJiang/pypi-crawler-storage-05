"""Target for {{ cookiecutter.destination_name }}."""
