"""SDK external system tests."""

from __future__ import annotations
