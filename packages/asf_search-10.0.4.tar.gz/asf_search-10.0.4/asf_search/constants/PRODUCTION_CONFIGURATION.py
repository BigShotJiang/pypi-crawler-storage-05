# NISAR Production Configurations
PRODUCTION = 'PR'
URGENT_RESPONSE = 'UR'
CUSTOM = 'OD'
