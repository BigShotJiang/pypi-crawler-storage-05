"""Provider secrets templates."""

