"""Resource package for CLI templates."""

