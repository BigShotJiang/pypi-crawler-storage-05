# testkit

#### 介绍

Pyside6的UI组件库

#### 安装教程

1. pip install mangokit

#### 使用说明

1.  