# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 其他
# @Time   : 2024-09-19 16:41
# @Author : 毛鹏
from .mango_credits import MangoCredits
from .mango_grips import MangoGrips
