# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 菜单
# @Time   : 2024-09-19 16:43
# @Author : 毛鹏
from .mango_menu.mango_menu import MangoMenu
from .mango_tabs import *
