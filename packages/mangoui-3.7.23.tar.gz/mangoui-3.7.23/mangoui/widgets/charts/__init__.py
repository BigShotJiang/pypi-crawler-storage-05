# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 图表
# @Time   : 2024-09-19 16:44
# @Author : 毛鹏
from .line import MangoLinePlot
from .pie import MangoPiePlot
