# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2024-08-28 16:33
# @Author : 毛鹏
from .component_center import ComponentPage
