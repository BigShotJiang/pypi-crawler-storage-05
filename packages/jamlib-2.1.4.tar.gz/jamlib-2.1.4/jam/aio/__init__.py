# -*- coding: utf-8 -*-

"""
Async jam version.
"""

from jam.aio.instance import Jam


__all__ = ["Jam"]
