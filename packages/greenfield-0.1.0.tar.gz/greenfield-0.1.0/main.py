def main():
    print("Hello from greenfield!")


if __name__ == "__main__":
    main()
