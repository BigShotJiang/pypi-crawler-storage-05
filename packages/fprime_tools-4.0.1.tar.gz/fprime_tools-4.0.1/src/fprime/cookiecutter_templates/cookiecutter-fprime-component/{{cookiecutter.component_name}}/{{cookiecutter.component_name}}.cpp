// ======================================================================
// \title  {{cookiecutter.component_name}}.cpp
// \brief  {{cookiecutter.component_short_description}} placeholder. Use fprime-util impl
// ======================================================================
