"""
(test) fprime-utils commands:

Tests the F prime util commands.
@author 0x48piraj
"""

import unittest


class CommandsTestCases(unittest.TestCase):
    def test_build_command(self):
        pass

    def test_check_command(self):
        pass

    def test_generate_command(self):
        pass

    def test_purge_command(self):
        pass

    def test_fpp_check_command(self):
        pass

    def test_visualize_command(self):
        pass

    def test_impl_command(self):
        pass

    def test_hash_to_file_command(self):
        pass

    def test_info_command(self):
        pass

    def test_new_command(self):
        pass

    def test_format_command(self):
        pass

    def test_version_check_command(self):
        pass


if __name__ == "__main__":
    unittest.main()
