# setup.py is kept to support legacy builds
# https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html
from setuptools import setup

# Configuration is in pyproject.toml
setup()
