# tirjapy

Python Base for Tirja Projects
