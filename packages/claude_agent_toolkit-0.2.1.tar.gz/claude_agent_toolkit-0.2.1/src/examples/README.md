# Claude Agent Toolkit Examples

This directory contains practical examples demonstrating the Claude Agent Toolkit framework capabilities. Each example is a complete, standalone project showing different aspects of building Claude Code agents with custom tools.

## Structure

This is a separate uv project that depends on the claude-agent-toolkit package from the parent directory. The examples are organized into focused demo projects:

```
examples/
   pyproject.toml          # Examples project configuration
   README.md               # This file
   calculator/             # Calculator demo
      tool.py            # Calculator Tool implementation
      prompt.py          # System prompts and templates
      main.py            # Agent orchestration
   weather/               # Weather demo
       weather.py         # Weather API integration (wttr.in)
       tool.py           # Weather Tool implementation
       prompt.py         # Weather-specific prompts
       main.py           # Agent orchestration
```

## Prerequisites

1. **Docker Desktop** - Must be running for agent execution
2. **Claude Code OAuth Token** - Required for agent authentication
3. **Python 3.12+** - With uv package manager
4. **Internet Connection** - For weather API (weather demo only)

## Setup

### 1. Get Your Claude Code Token
Visit [Claude Code](https://claude.ai/code) and get your OAuth token, then set it:

```bash
export CLAUDE_CODE_OAUTH_TOKEN='your-token-here'
```

### 2. Install Dependencies
From the examples directory:

```bash
# Install dependencies (claude-agent-toolkit will be installed from parent directory)
uv sync
```

### 3. Start Docker Desktop
Ensure Docker Desktop is running before executing any demos.

## Demo Projects

### Calculator Demo (`calculator/`)

A comprehensive mathematical assistant demonstrating:
- **Basic Operations**: Addition, subtraction, multiplication, division
- **Advanced Operations**: Power, square root
- **State Management**: Operation history, last result tracking
- **Professional Prompting**: Mathematical explanation and step-by-step solving

**Run the demo:**
```bash
cd calculator
python main.py                 # Run demonstration scenarios
python main.py --interactive   # Interactive calculator mode
```

**Features demonstrated:**
- Custom tool implementation with state management
- Multi-step mathematical problem solving
- History tracking and result persistence
- Professional mathematical assistant behavior

### Weather Demo (`weather/`)

A real-time weather assistant demonstrating:
- **Current Conditions**: Real-time weather data for any location
- **Forecasts**: Multi-day weather forecasts with hourly details
- **Comparisons**: Weather comparison between locations
- **State Management**: Favorites, query history
- **External API Integration**: wttr.in weather service

**Run the demo:**
```bash
cd weather
python main.py                 # Run demonstration scenarios
python main.py --interactive   # Interactive weather assistant mode
```

**Features demonstrated:**
- External API integration with async operations
- Complex data processing and interpretation
- Location management and favorites
- Travel planning and weather advice
- Professional weather assistant behavior

## Key Learning Points

### 1. Tool Implementation Pattern
Each demo shows the consistent pattern:
```python
from claude_agent_toolkit import BaseTool, tool

class MyTool(BaseTool):
    def __init__(self):
        super().__init__()
        # Explicit data management - no automatic state management
        self.my_data = []  # Manage your own data explicitly
    
    @tool(description="...")
    async def my_method(self, param: str) -> dict:
        # Tool logic
        return {"result": "data"}
```

### 2. Agent Orchestration
```python
from claude_agent_toolkit import Agent
from tool import MyTool

# Start tool and connect agent
tool = MyTool().run(workers=2)
agent = Agent()
agent.connect(tool)

# Run agent with prompt
result = await agent.run("System prompt + user request")
```

### 3. Professional Prompting
Both demos demonstrate:
- Comprehensive system prompts defining agent behavior
- Template-based response formatting
- Error handling and user guidance
- Context-aware conversation management

### 4. State Management
- Persistent state across tool calls
- History tracking and retrieval
- User preference management (favorites)
- State validation and cleanup

## Development Patterns

### Error Handling
```python
try:
    result = await weather_api.get_current_weather(location)
    if result.get("success"):
        # Handle success
    else:
        # Handle API errors gracefully
except Exception as e:
    # Handle unexpected errors
```

### Async Operations
```python
@tool(description="Async operation")
async def async_operation(self) -> dict:
    async with ExternalAPI() as api:
        result = await api.fetch_data()
        return result
```

### State Recording
```python
def _record_operation(self, operation, result):
    self.operation_count += 1
    self.history.append({
        "operation": operation,
        "result": result,
        "timestamp": datetime.now().isoformat()
    })
```

## Running Examples

Each demo can be run in two modes:

1. **Demo Mode** (default): Runs predefined scenarios showing capabilities
2. **Interactive Mode**: Allows user input for hands-on experimentation

Both modes validate OAuth token and Docker availability before execution.

## Troubleshooting

### Common Issues

1. **"Cannot connect to Docker"**
   - Solution: Start Docker Desktop and retry

2. **"CLAUDE_CODE_OAUTH_TOKEN not set"**
   - Solution: Export your token from Claude Code settings

3. **"Import claude_agent_toolkit could not be resolved"**
   - Solution: Run `uv sync` from the examples directory

4. **Weather API timeout**
   - Solution: Check internet connection; wttr.in may be temporarily unavailable

### Debug Mode
For detailed debugging information, modify the agent run calls to include debug output:
```python
result = await agent.run(prompt, debug=True)
```

## Extending Examples

These examples serve as templates for building your own Claude Code agents:

1. **Copy the structure** of either demo as a starting point
2. **Implement your tools** following the BaseTool pattern
3. **Create appropriate prompts** for your domain
4. **Add state management** as needed for your use case
5. **Test thoroughly** with both demo and interactive modes

Each demo is designed to be educational, practical, and extensible for real-world applications.