from .graphnn import graph_nn
from .calcoutputnn import calculate_output_nn
