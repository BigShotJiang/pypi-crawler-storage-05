.. include:: ../README.rst

.. toctree::
   :maxdepth: 2

   api


.. toctree::
   :maxdepth: 2

   changelog

Development
===========

zope.login is hosted at GitHub:

    https://github.com/zopefoundation/zope.login/



Project URLs
============

* https://pypi.python.org/pypi/zope.login       (PyPI entry and downloads)


====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
