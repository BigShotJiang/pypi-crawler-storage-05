"""Tests of :mod:`message_ix_models.model` and submodules."""
