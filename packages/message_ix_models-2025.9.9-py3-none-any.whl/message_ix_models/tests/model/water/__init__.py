"""Tests of :mod:`message_ix_models.model.water`."""
