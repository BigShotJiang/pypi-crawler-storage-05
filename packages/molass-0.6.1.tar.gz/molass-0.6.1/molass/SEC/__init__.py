"""
    SEC.__init__.py
"""