"""
    Geometric.__init__.py
"""