"""
    CurveModels.__init__.py
"""