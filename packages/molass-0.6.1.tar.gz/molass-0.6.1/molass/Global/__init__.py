"""
    Global.__init__.py
"""