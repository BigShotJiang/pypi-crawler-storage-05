from llama_index.embeddings.xinference.base import XinferenceEmbedding

__all__ = ["XinferenceEmbedding"]
