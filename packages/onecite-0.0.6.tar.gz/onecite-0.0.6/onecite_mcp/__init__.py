#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
OneCite MCP (Model Context Protocol) Server
MCP server implementation for AI assistant integration
"""

__version__ = "0.0.4"
__author__ = "OneCite Team"
