"""Qt Based visualizer for flowpipe based on NodeGraphQT."""
from .flowpipe_editor_widget import FlowpipeEditorWidget
