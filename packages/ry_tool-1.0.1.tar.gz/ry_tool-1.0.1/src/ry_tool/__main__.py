"""
Entry point for ry-next when run as a module.

Usage: python -m ry_next
"""
from .app import run

if __name__ == "__main__":
    run()