# easyfermi
The easiest way to analyze Fermi-LAT data.

# Requirements
It is required to install Miniconda 3 or Anaconda 3 before installing easyfemri
_easyFermi_ relies on _Fermitools_, _fermipy_, _emcee_, and _gammapy_. 

# Install
Please folow the GitHub tutorial for installation:
https://github.com/ranieremenezes/easyFermi


# YouTube tutorials

We have some usage tutorials on YouTube:

https://www.youtube.com/channel/UCeLCfEoWasUKky6CPNN_opQ


