# Realtime-HAT python package

* contain python bindings to control your Realtime-HAT https://github.com/InnoRoute/RealtimeHAT
* update with `sudo pip3 install --upgrade rt_hat_inr`

## Dokumentation
* clone https://github.com/InnoRoute/RT_HAT_python and have a look into the examples folder
* follow the tutorials on https://github.com/InnoRoute/RealtimeHAT/wiki
* see https://github.com/InnoRoute/RT_HAT_python/wiki/Realtime-HAT-python-package
