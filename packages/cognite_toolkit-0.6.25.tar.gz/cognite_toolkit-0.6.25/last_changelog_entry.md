## cdf 

### Fixed

- When deploying extraction pipeline configurations, Toolkit no longer
require `extractionPipelineAcl` that is all scoped.

## templates

No changes.