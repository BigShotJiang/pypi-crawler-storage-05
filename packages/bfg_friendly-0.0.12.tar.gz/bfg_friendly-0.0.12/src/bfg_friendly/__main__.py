"""Make the CLI runnable using python -m bfg_friendly."""

from .cli import app

app(prog_name="bfg-friendly")
