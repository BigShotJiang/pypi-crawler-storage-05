# -*- coding: utf-8 -*-
"""
CLI命令处理模块
"""

from .manual_commands import manual_command, add_manual_parser

__all__ = ['manual_command', 'add_manual_parser']