<!--
 ~ SPDX-FileCopyrightText: Copyright DB InfraGO AG and the capellambse-context-diagrams contributors
 ~ SPDX-License-Identifier: Apache-2.0
 -->

# Maintainers

The `capellambse-context-diagrams` Python bindings are maintained by the following people:

- [Ernst Würger](mailto:ernst.wuerger@deutschebahn.com)
