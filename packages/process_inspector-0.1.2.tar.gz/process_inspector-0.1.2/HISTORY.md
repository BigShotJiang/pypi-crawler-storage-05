# History

All notable changes to this project will be documented in this file. This project adheres to [Semantic Versioning](http://semver.org/).

## 0.1.0 (2025-09-11)

- First release

## 0.1.1 (2025-09-11)

- ADDED - more test coverage

## 0.1.2 (2025-09-11)

- ADDED - Service control (Windows Services or Linux/ Mac `supervisorctl` processes)
- ADDED - TeamViewer status and basic control (start, stop)
