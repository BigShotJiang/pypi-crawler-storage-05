from .gofile_uploader import async_main, main
