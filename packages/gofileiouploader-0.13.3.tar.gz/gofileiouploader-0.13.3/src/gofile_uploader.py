import asyncio

from gofile_uploader import async_main

if __name__ == "__main__":
    asyncio.run(async_main())
