# Copyright (c) 2016 Grant Patten
# Copyright (c) 2019 Adam Karpierz
# SPDX-License-Identifier: MIT

import sys
from ._pyc_wheel import main
sys.exit(main())
