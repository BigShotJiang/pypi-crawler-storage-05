"""
Minimal core functionality for RL Forever.
"""

def hello_rl_forever():
    """Simple greeting function."""
    return "Hello from RL Forever!"

# Simple constant
VERSION_INFO = "RL Forever - Simple and Forever!"