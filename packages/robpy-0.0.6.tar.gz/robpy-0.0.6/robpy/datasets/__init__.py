""" Module that contains convenience functions for loading commonly used datasets.
"""

from robpy.datasets.base import load_telephone, load_stars, load_animals, load_topgear, load_glass
