from robpy.regression.lts import FastLTSRegression
from robpy.regression.mm import MMRegression
from robpy.regression.s import SRegression
