"""Module containing all algorithms related to outlier detection.
"""

from robpy.outliers.ddc import DDC
