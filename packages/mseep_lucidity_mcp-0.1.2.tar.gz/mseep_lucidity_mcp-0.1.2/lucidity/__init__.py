"""Lucidity: AI-powered code analysis and review tool.

This package contains modules for code quality analysis,
issue detection, and AI-powered code review.
"""
