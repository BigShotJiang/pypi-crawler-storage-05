# Indie Infrastructure Initiative
A tool to allow small indie game development studios to setup and maintain complex server infrastructure with ease

Version 0.1.36
