from intugle.core.vector_store.qdrant import AsyncQdrantService

VectorStoreService = AsyncQdrantService