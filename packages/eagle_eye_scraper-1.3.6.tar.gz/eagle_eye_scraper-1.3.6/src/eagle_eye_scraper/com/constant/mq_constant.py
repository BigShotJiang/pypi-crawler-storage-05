from eagle_eye_scraper.com.config.env_config import CONFIG

SPIDER_DISPATCH_QUEUE = CONFIG.PROJECT_NAME + '-spider-dispatch-task'
