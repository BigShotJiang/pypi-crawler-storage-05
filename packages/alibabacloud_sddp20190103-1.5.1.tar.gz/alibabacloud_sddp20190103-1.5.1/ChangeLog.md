2025-09-09 Version: 1.5.0
- Support API DescribeAuditLogs.


2025-06-30 Version: 1.4.4
- Update API DescribeDataLimitSet: add request parameters RegionType.


2025-02-14 Version: 1.4.3
- Update API CreateRule: add param ModelRuleIds.
- Update API CreateRule: add param TemplateRuleIds.
- Update API DescribeColumns: update response param.
- Update API DescribeColumnsV2: add param EngineType.
- Update API DescribeColumnsV2: update response param.
- Update API DescribeDataObjectColumnDetail: update response param.
- Update API DescribeDataObjectColumnDetailV2: update response param.
- Update API DescribeRules: update response param.
- Update API ModifyRule: add param ModelRuleIds.
- Update API ModifyRule: add param TemplateRuleIds.


2025-01-13 Version: 1.4.2
- Update API CreateRule: add param ModelRuleIds.
- Update API CreateRule: add param TemplateRuleIds.
- Update API DescribeRules: update response param.
- Update API ModifyRule: add param ModelRuleIds.
- Update API ModifyRule: add param TemplateRuleIds.


2024-12-17 Version: 1.4.1
- Update API DescribeRules: add param CooperationChannel.
- Update API DescribeRules: add param Simplify.


2024-10-17 Version: 1.4.0
- Support API DescribeIdentifyTaskStatus.
- Update API DescribeInstances: update response param.
- Update API DescribeOssObjectDetailV2: update response param.


2024-08-19 Version: 1.3.0
- Support API ScanOssObjectV1.


2024-08-16 Version: 1.2.9
- Update API DescribeColumns: add param EngineType.
- Update API DescribeColumns: add param ModelTagId.
- Update API DescribeColumns: add param ProductId.
- Update API DescribeColumns: add param TemplateId.
- Update API DescribeColumns: add param TemplateRuleId.
- Update API DescribeColumns: update response param.
- Update API DescribeOssObjectDetailV2: add param BucketName.
- Update API DescribeOssObjectDetailV2: add param ObjectKey.
- Update API DescribeOssObjectDetailV2: add param ServiceRegionId.
- Update API DescribeOssObjectDetailV2: add param TemplateId.
- Update API DescribeOssObjects: update response param.
- Update API DescribeParentInstance: update response param.


2024-08-13 Version: 1.2.8
- Update API DescribeOssObjects: add param Marker.
- Update API DescribeOssObjects: update response param.


2024-08-09 Version: 1.2.7
- Update API DescribeDataLimits: update response param.


2024-07-22 Version: 1.2.6
- Update API CreateDataLimit: add param InstantlyScan.
- Update API DescribeDataObjects: update response param.


2024-07-02 Version: 1.2.5
- Update API CreateDataLimit: add param InstantlyScan.


2024-06-27 Version: 1.2.4
- Update API DescribeParentInstance: update response param.


2024-06-03 Version: 1.2.3
- Update API DescribeDataObjects: update response param.
- Update API DescribeOssObjects: update response param.
- Update API DescribeParentInstance: update param EngineType.


2024-04-22 Version: 1.2.2
- Update API DescribeEventDetail: update response param.


2024-04-18 Version: 1.2.1
- Update API DescribeDataLimits: add param MemberAccount.
- Update API DescribeDataLimits: update response param.
- Update API DescribeDataMaskingTasks: update response param.
- Update API DescribeDataObjects: add param MemberAccount.
- Update API DescribeDataObjects: update response param.
- Update API DescribeParentInstance: add param MemberAccount.
- Update API DescribeParentInstance: update response param.


2024-03-25 Version: 1.2.0
- Support API DescribeParentInstance.


2024-01-16 Version: 1.1.2
- Generated python 2019-01-03 for Sddp.

2023-12-27 Version: 1.1.1
- Generated python 2019-01-03 for Sddp.

2023-08-29 Version: 1.1.0
- Generated python 2019-01-03 for Sddp.

2023-07-07 Version: 1.0.11
- Add some api version2.

2023-06-30 Version: 1.0.10
- Add DescribeCategoryTemplateList api.
- Modify some api directory.

2023-06-29 Version: 1.0.9
- Add some public api.

2022-05-25 Version: 1.0.8
- SampleSize add.

2022-04-20 Version: 1.0.7
- CreateDataLimit add enable parameter .

2022-04-18 Version: 1.0.6
- Change DescribeEventDetail Data.

2021-12-29 Version: 1.0.5
- Make CreateSlrRole Public.
- Add ModifyReportTaskStatus Api.

2021-11-22 Version: 1.0.4
- Fix some apis.

2021-11-02 Version: 1.0.3
- Set DescribeCategoryTemplateRuleList public.

2021-10-14 Version: 1.0.2
- Generated python 2019-01-03 for Sddp.

2021-09-26 Version: 1.0.1
- AMP version.

2021-09-26 Version: 1.0.0
- AMP version.

