from yangke.base import fit_nd_function

