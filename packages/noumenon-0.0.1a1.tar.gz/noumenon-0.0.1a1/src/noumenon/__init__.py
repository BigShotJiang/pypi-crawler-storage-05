"""
Noumenon - A Python package for Noumenon
"""

__version__ = "0.0.1a1"

def hello():
    """Simple hello function for package testing."""
    return "Hello from Noumenon!"
