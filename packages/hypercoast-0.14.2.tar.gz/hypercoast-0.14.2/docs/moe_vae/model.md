# model module

::: hypercoast.moe_vae.model
