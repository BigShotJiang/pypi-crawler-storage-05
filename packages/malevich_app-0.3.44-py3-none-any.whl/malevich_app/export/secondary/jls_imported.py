imported = False
imported2 = False
imported3 = False
imported4 = False

# FIXME


def set_imported(imported_new: bool):
    global imported
    imported = imported_new


def set_imported2(imported_new: bool):
    global imported2
    imported2 = imported_new


def set_imported3(imported_new: bool):
    global imported3
    imported3 = imported_new


def set_imported4(imported_new: bool):
    global imported4
    imported4 = imported_new
