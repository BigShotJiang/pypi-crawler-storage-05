maturin build
pip install .