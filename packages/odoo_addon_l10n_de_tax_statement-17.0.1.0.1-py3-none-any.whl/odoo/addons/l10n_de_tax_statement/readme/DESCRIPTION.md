This module provides the *German VAT Statement*
(Umsatzsteuervoranmeldung). You can use the *German VAT Statement*
report to declare your taxes on www.elster.de.
