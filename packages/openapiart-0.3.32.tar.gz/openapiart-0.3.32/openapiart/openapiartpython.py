from .openapiartplugin import OpenApiArtPlugin


class OpenApiArtPython(OpenApiArtPlugin):
    def __init__(self):
        super(OpenApiArtPython, self).__init__()

    def pre_init(self):
        pass
