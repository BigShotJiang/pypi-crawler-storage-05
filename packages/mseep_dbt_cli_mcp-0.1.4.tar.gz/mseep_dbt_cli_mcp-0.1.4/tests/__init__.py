"""
Tests for the DBT CLI MCP Server.
"""