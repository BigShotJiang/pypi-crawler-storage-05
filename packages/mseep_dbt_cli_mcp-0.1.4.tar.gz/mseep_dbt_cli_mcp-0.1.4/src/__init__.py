"""
DBT CLI MCP Server - A Model Context Protocol server for dbt CLI.
"""

__version__ = "0.1.0"