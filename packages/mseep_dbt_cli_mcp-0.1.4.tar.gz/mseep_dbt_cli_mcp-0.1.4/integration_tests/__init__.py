"""
Integration tests for the dbt-cli-mcp package.

These tests verify the functionality of the package against a real dbt project.
"""