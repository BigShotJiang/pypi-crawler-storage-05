"""Shared constants for API providers."""

DATETIME_STRING_FORMAT = "%H:%M:%S %Y-%m-%d"
DEFAULT_RESOURCE_DEPLOYMENT = "http://localhost:8001/api"
