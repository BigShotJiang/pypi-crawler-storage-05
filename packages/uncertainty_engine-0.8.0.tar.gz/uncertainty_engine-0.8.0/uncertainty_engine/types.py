from typing import Callable

GetResourceToken = Callable[[], str]
"""
A function that returns a resource token.
"""
