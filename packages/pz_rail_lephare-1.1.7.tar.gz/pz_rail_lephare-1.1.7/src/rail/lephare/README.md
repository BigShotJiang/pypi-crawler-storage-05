This folder should contain any utility modules that are required for the RAIL
estimation stage to wrap the LePhare estimation algorithm.
