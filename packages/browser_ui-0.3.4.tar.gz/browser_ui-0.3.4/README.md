# Browser UI

Another way to build Python browser-based GUI applications.
This package is aimed to show your Python application's GUI in the browser.
