from .mcp_server import main

__all__ = ["main"]