from . import server


def main():
    server.main()


__all__ = ["main", "server"]
