"""Infrastructure enrichment module."""
