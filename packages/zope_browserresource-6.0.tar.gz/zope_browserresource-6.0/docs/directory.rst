==============================================================
 Directories of Resources: ``zope.browserresource.directory``
==============================================================

.. automodule:: zope.browserresource.directory
