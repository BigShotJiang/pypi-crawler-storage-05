===============================================
 File Resources: ``zope.browserresource.file``
===============================================

.. automodule:: zope.browserresource.file
