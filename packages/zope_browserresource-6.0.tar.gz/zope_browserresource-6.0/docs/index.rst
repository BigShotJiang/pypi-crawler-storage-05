.. include:: ../README.rst


Documentation:

.. toctree::
   :maxdepth: 2

   overview

API Documentation:

.. toctree::
   :maxdepth: 2

   interfaces
   resource
   file
   i18nfile
   directory
   resources
   zcml

.. toctree::
   :maxdepth: 2

   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
