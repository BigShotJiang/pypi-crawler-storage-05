==========================================================
 ZCML Directives: ``zope.browserresource.metadirectives``
==========================================================

.. automodule:: zope.browserresource.metadirectives
