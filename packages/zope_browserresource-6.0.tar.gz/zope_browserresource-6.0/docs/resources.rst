===================================================
 Resource View: ``zope.browserresource.resources``
===================================================

.. automodule:: zope.browserresource.resources
