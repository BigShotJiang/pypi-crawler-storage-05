============================================================
 Internationalized Files: ``zope.browserresource.i18nfile``
============================================================

.. automodule:: zope.browserresource.i18nfile
