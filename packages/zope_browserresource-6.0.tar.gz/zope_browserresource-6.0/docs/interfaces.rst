=================================================
 Interfaces: ``zope.browserresource.interfaces``
=================================================

.. automodule:: zope.browserresource.interfaces
