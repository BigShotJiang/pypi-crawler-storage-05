===================================================
 Basic Resource: ``zope.browserresource.resource``
===================================================

.. automodule:: zope.browserresource.resource
