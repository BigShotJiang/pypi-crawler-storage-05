# -*- coding: utf-8 -*-

import typing as T

T_PRINTER = T.Callable[[str], None]
