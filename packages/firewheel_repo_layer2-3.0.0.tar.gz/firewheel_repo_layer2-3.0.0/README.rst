.. _layer2_mc_repo:

*********************
firewheel-repo-layer2
*********************

This repository contains FIREWHEEL Model Components for enabling `layer-2 <https://en.wikipedia.org/wiki/Data_link_layer>`_ networking within an experiment.
