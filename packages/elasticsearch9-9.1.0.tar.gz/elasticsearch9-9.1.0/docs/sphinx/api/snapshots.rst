.. _snapshots:

Snapshots
---------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: SnapshotClient
   :members: