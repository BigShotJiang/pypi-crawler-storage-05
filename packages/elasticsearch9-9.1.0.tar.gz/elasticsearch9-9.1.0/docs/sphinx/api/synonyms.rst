.. _synonyms:

Synonyms
--------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: SynonymsClient
   :members: