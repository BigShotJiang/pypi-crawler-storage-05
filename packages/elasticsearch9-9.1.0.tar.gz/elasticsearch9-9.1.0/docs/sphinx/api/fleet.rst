.. _fleet:

Fleet
-----
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: FleetClient
   :members: