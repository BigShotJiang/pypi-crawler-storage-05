.. _nodes:

Nodes
-----
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: NodesClient
   :members: