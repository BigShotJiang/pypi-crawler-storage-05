.. _license:

License
-------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: LicenseClient
   :members: