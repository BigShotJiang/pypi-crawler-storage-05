.. _migration:

Migration
---------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: MigrationClient
   :members: