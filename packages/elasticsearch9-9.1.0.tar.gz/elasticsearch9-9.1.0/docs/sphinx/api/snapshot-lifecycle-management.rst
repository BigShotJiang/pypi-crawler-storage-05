.. _snapshot-lifecycle-management:

Snapshot Lifecycle Management (SLM)
-----------------------------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: SlmClient
   :members: