.. _text-structure:

Text Structure
--------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: TextStructureClient
   :members: