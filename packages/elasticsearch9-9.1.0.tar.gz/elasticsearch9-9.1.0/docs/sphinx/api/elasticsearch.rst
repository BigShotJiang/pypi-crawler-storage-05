.. _elasticsearch:

Elasticsearch
-------------

.. py:module:: elasticsearch

.. autoclass:: Elasticsearch
   :members:
