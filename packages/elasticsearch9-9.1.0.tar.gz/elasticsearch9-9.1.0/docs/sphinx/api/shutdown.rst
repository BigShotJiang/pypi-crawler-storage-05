.. _shutdown:

Shutdown
--------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: ShutdownClient
   :members: