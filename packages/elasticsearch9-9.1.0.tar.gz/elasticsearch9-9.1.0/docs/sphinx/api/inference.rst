.. _inference:

Inference
---------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: InferenceClient
   :members:
