.. _ingest-pipelines:

Ingest Pipelines
----------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: IngestClient
   :members: