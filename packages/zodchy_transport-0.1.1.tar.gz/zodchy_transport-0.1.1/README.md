# Zodchy transport

## Installation
```bash
pip install zodchy-transport
```
Also you have to install broker for faststeam. Ex:

```bash
pip install faststeam[rabbit]
```
