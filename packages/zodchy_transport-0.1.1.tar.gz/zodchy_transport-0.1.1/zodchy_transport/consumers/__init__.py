from .rabbitmq import RabbitMQConsumer

__all__ = ["RabbitMQConsumer"]