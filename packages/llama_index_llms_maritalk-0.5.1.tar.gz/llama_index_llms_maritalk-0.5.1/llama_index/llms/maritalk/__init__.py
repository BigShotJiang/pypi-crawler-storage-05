from llama_index.llms.maritalk.base import Maritalk


__all__ = ["Maritalk"]
