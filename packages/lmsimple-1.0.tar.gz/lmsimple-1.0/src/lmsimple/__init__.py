import asyncio

from lmsimple.core import start


def main() -> None:
    asyncio.run(start())
