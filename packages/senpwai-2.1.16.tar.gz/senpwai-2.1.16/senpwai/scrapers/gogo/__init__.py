from senpwai.scrapers.gogo.hls import *  # noqa F403
from senpwai.scrapers.gogo.main import *  # noqa F403
from senpwai.scrapers.gogo.constants import GOGO  # noqa F401
