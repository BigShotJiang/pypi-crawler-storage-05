from senpwai.scrapers.pahe.main import *  # noqa: F403
from senpwai.scrapers.pahe.constants import PAHE, MAX_SIMULTANEOUS_PART_DOWNLOADS  # noqa: F401
