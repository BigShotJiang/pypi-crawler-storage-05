from .domain_event import DomainEvent

__all__ = ('DomainEvent',)
