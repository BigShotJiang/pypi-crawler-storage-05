__version__ = '0.1.0'

from .models import DomainEvent

__all__ = ('DomainEvent',)
