"""
LogWatchdog GUI Package
=======================

Graphical user interface for LogWatchdog.
"""

__all__ = ["main"]
