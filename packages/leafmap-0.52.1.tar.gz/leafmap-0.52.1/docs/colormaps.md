# colormaps module

::: leafmap.colormaps
