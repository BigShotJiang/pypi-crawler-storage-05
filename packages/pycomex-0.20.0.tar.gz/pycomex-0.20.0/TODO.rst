TODO's
======

* Optional Neptune AI integration
* Add command line invocation
    * Add possibility to override the parameters
* Automatically template a analysis.py file
* Automatically template an annotations.rst file
    * Put the description into it and also pre formatted section which may contain additional author notes
* Possibility to dockerize / repeat a past experiment
    * for that I would have to attach dependency information to an experiment
