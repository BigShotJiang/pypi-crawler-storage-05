.. _examples:

Examples
========

All of these examples explain various features of ``pycomex``. It is recommended to visit them in order to
get the best overview.

.. toctree::

    examples/basic
    examples/analysis
