This module adds the following features:

- A smart button in form view of services to schedule meetings.
- Search events for specific services in calendar view.
