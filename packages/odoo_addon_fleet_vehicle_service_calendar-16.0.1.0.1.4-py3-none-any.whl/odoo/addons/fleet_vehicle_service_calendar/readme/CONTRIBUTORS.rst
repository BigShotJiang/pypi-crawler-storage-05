* `Druidoo <https://www.druidoo.io>`_:

  * Iván Todorovich <ivan.todorovich@druidoo.io>
  * Manuel Marquez <manuel.marquez@druidoo.io>

* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>
