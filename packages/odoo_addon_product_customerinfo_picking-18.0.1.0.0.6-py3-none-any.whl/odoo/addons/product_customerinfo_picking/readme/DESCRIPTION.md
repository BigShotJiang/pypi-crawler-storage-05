Based on product_customerinfo, this module loads in every
Stock move the customer code defined in the product.
