"""coco_api

A middleware rich backend framework for building APIs.
"""

__version__ = "0.0.1"

from .api import CocoAPI

__all__ = ["__version__", "CocoAPI"]
