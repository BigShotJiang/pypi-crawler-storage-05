"Tag cloud for django-taggit"

from __future__ import unicode_literals

__version__ = "0.4.0"

default_app_config = 'tagtools.apps.TagToolConfig'
