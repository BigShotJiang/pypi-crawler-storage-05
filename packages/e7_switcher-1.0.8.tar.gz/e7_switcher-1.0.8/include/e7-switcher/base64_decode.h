#pragma once

#include <string>
#include <vector>

std::vector<unsigned char> base64_decode(std::string const& s);
