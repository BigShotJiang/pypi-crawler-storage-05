#pragma once

#include <cstdint>

namespace e7_switcher {

int32_t java_bug_seconds_from_now();
uint32_t now_unix();

} // namespace e7_switcher
