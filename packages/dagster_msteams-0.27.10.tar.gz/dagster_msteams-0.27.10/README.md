# dagster-msteams

The docs for `dagster-msteams` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-msteams).
