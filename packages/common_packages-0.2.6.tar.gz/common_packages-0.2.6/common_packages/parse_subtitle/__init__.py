# [参考](https://github.com/cdown/srt)
# [参考](https://srt.readthedocs.io/en/latest/quickstart.html#compose-an-srt-from-python-objects)

# 1. 清理非标准字符
# 2. 使用srt解析
# 3. 清理每个字幕中的非标准字符
