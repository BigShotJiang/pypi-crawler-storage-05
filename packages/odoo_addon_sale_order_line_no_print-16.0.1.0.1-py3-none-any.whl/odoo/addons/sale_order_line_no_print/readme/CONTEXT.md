In some ocassions the salesman wants to hide some info that's no relevant for the
customer but that it's needed for other documents (delivery info, pack items, etc.) as
they don't want to disclose some strategic data to the competence.
