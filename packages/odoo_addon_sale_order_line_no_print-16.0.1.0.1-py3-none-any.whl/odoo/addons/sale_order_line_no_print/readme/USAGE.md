To hide sale lines from the report:

- Go to a sales order/quotation/invoice.
- In the lines, click on the column selector to reveal the *Display in report* column.
- Toggle it on or off depending on your will.
- Go to the portal view: you won't see those hidden lines.
