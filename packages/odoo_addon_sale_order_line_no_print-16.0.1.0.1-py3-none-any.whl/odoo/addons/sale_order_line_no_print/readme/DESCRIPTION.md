This module allows to hide some order lines from the reports and portal views
that the final customer has access to.
