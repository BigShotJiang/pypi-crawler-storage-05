najaeda visitors
================

Instance Visitor
----------------

Instance Visitor Overview
^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: najaeda.instance_visitor.Visitor
    :members:
    :undoc-members:
    :show-inheritance: