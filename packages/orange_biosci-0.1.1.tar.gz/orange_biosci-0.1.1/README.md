# BioSci for Orange Data Mining

For now, contains a widget for preprocessing GEO gene differential expression data.

## Installation

1. Make sure you have Orange Data Mining installed
2. Download this package
3. Run: `pip install orange-biosci`

## Usage

1. Open Orange Canvas
2. Find "BioSci" in the widget menu
3. Load your GEO data and connect to the widget