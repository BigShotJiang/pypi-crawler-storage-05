from __future__ import annotations

from .colbert import ColBERT

__all__ = ["ColBERT"]
