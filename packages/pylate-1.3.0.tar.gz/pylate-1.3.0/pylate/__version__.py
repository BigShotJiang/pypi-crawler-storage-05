from __future__ import annotations

VERSION = (1, 3, 0)

__version__ = ".".join(map(str, VERSION))
