# load_custom_dataset

Load a custom dataset.



## Parameters

- **path** (*'str'*)

    Path of the dataset.

- **split** (*'str'*) – defaults to `test`

    Split to load.
