# get_world_size

Returns the world size in a distributed training.
