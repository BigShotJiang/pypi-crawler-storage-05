# SimilarityFunction

Enum class for supported score functions. The following functions are supported: - ``SimilarityFunction.MAXSIM`` (``"MaxSim"``): Max similarity



## Parameters

- **values**
