# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2023 Julian Lapenna
# Copyright (C) 2025 Colin B. Macdonald

"""Finish app of the Plom Server."""
