# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2022 Edith Coates
# Copyright (C) 2022 Brennen Chiu
# Copyright (C) 2025 Colin B. Macdonald

"""The Plom Server BuildPaperPDF app."""
