# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2022, 2025 Colin B. Macdonald

"""Base app of the Plom Server."""
