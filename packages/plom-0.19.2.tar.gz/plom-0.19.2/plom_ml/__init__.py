# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025 Bryan Tanady
"""plom_ml is an AI/ML package for plom."""
