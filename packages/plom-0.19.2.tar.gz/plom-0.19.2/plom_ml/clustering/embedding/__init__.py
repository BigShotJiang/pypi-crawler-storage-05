# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025 Bryan Tanady
"""Embedder related modules.

Embedder is the component that generates features from certain raw inputs.
"""
