# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025 Bryan Tanady
"""Definition of all clustering models defined in plom_ml."""
