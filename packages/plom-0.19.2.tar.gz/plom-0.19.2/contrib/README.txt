Plom contributed scripts
========================

These are various scripts that people have written or found useful.

Caution: they have various degrees of reliability.

Some of these features may eventually find their way into the main Plom module.
