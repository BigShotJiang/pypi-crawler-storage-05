"""silica - A command line tool for creating workspaces for agents on top of piku."""

__version__ = "0.1.0"
