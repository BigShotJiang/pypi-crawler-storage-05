# Outerbounds platform package

This package installs client side packages for Outerbounds platform. See Outerbounds platform documentation and [Metaflow documentation](https://metaflow.org/) for more info on how to use it.
