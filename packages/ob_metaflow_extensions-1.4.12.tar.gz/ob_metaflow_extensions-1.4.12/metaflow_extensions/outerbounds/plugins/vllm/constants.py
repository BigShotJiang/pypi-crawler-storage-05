VLLM_SUFFIX = "mf.vllm"
