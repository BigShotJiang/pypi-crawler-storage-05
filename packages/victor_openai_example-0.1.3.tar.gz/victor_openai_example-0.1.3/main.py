def main():
    print("Hello from test-pypi!")


if __name__ == "__main__":
    main()
