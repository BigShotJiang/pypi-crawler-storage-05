import logging

log = logging.getLogger("socketdev")
log.addHandler(logging.NullHandler())