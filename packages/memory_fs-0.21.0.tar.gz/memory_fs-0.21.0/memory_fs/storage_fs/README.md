## Principles

- this section should have no dependency on file_* classes

## Questions:

- is "providers" the best name for the package that has Storage_FS__Memory.py, Storage_FS__Local_Disk.py, etc... 