"""CLI tests for rxiv-maker."""
