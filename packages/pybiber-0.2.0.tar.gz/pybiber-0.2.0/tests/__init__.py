"""
Test package for pybiber.

This test suite provides comprehensive testing for the pybiber package,
including unit tests, integration tests, and feature-specific tests
modeled after the R pseudobibeR package test structure.
"""
