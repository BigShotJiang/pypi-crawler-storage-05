########################
FuseSoC Reference Manual
########################

.. toctree::
   :maxdepth: 2
   :caption: Contents

   capi2.md
   migrations.rst
   glossary.rst
