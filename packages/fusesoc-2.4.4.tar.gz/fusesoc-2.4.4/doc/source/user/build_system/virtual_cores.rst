.. _ug_build_system_virtual_cores:

Virtual Cores: Provide a common interface
=========================================

.. todo::

   Document virtual cores.
