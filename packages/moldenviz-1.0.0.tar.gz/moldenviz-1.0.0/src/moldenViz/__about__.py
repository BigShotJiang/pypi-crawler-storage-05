"""Package metadata for moldenViz."""

__version__ = '1.0.0'
