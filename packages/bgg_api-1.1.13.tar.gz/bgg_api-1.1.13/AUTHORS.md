Project Authors
===============

This library is a continuation of previous work by:

### [philsstein](https://github.com/philsstein/)
*  2014 - 2015 as [libBGG](https://pypi.org/project/boardgamegeek/)

### [lcosmin](https://github.com/lcosmin/)
*  2014 - 2019 as [boardgamegeek](https://pypi.org/project/boardgamegeek2/)

### [SukiCZ](https://github.com/SukiCZ/)
*  2024 - present as [bgg-api](https://pypi.org/project/bgg-api/)
