# Settings

Some of pikepdf's global parameters can be tuned.

```{eval-rst}
.. autoapifunction:: pikepdf.settings.get_decimal_precision
```

```{eval-rst}
.. autoapifunction:: pikepdf.settings.set_decimal_precision
```

```{eval-rst}
.. autoapifunction:: pikepdf.settings.set_flate_compression_level
```
