__version__ = "3.8.0"
__array_api_version__ = "2024.12"
