Tutorials
=========

.. toctree::
   :caption: Index
   :maxdepth: 1

   tutorials/01.ndarray-basics
   tutorials/02.lazyarray-expressions
   tutorials/03.lazyarray-udf
   tutorials/04.reductions
   tutorials/05.persistent-reductions
   tutorials/06.remote_proxy
   tutorials/07.schunk-basics
   tutorials/08.schunk-slicing_and_beyond
   tutorials/09.ucodecs-ufilters
   tutorials/10.prefilters
