Operations with arrays
----------------------

.. toctree::
    :maxdepth: 1

    lazy_functions
    reduction_functions
    linear_algebra
