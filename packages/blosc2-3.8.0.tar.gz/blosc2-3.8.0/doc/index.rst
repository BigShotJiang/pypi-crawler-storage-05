.. include:: python-blosc2.rst
