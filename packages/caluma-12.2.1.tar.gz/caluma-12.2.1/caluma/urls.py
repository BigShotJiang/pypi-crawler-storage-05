from django.urls import include, path

urlpatterns = [path("", include("caluma.caluma_core.urls"))]
