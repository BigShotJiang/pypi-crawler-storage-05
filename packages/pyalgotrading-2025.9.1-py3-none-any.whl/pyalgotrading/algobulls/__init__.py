"""
Package for interacting with the [AlgoBulls](https://www.algobulls.com) backend
"""

from .connection import AlgoBullsConnection
