
class talib(object):
    """
    Dummy placeholder class. This is to facilitate coding in IDE like PyCharm/VSCode without the need to install the complete talib library.

    Once uploaded, this module will be replaced with the actual talib package - https://github.com/TA-Lib/ta-lib-python
    """
    pass