from constants import *


def check_order_placed_successfully(self, _order):
    """
    Dummy Function. 
    
    This method checks whether --
    -- order is not None
    -- broker_order_id exists for this order
    -- order status is not REJECTED
    
    Returns True if all of the above are True, else False.
    """
    pass


def check_order_complete_status(self, _order):
    """
    Dummy Function. 
    
    This method checks whether --
    -- order is not None
    -- broker_order_id exists for this order
    -- order status is COMPLETE

    Returns True if all of the above are True, else False
    """
    pass
