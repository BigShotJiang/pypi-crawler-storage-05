"""
Official Python Package for Algorithmic Trading APIs powered by AlgoBulls.

Links: [GitHub](https://github.com/algobulls/pyalgotrading) | [AlgoBulls](https://algobulls.com)
"""

from .talib.talib import talib
