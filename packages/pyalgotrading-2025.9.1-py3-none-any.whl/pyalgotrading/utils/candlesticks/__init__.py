"""
Handy functions for computing various candlesticks patterns from OHLC data
"""
