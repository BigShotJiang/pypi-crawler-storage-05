from typing import Literal

AuthorizationType = Literal[
    "assume",
    "client",
    "sso",
]