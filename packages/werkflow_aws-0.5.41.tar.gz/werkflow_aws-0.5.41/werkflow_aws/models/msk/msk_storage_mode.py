from typing import Literal


MSKStorageMode = Literal[
    "LOCAL",
    "TIERED",
]