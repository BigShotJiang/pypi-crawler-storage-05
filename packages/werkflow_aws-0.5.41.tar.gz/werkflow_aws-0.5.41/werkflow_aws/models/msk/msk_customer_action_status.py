from typing import Literal


MSKCustomerActionStatus = Literal[
    'CRITICAL_ACTION_REQUIRED',
    'ACTION_RECOMMENDED',
    'NONE',
]