from pydantic import StrictStr
from typing import Literal


MSKClusterBrokerAZDistribution = StrictStr | Literal['DEFAULT']