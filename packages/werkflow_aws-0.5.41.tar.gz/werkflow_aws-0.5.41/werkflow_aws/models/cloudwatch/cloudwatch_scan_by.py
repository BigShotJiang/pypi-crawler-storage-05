from typing import Literal

CloudWatchScanBy = Literal[
    "TimestampDescending",
    "TimestampAscending",
]
