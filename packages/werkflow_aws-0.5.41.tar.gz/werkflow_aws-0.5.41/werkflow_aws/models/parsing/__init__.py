from .key_conversion import (
    convert_key_to_boto3_arg as convert_key_to_boto3_arg,
    convert_key_to_boto3_arg_upper_matching as convert_key_to_boto3_arg_upper_matching,
    key_contains_patterns as key_contains_patterns
)
from .aws_config_role import AWSConfigRole as AWSConfigRole