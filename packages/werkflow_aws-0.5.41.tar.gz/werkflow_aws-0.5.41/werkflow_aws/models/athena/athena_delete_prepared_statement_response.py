from pydantic import BaseModel


class AthenaDeletePreparedStatementResponse(BaseModel):
    pass