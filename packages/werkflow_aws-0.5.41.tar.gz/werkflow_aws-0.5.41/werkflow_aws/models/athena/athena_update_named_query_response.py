from pydantic import BaseModel


class AthenaUpdateNamedQueryResponse(BaseModel):
    pass