from typing import Literal


AthenaQueryResultType = Literal[
    "DATA_MANIFEST",
    "DATA_ROWS",
]