from typing import TypedDict


class s3Tag(TypedDict):
    Key: str
    Value: str