# jpcli

jpcli is a library that converts the output of various Linux commands to JSON format.

## Installation

```sh
pip install jpcli

