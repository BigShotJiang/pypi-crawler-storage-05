"""Test generation modules for AI-Guard."""

from .testgen import main as generate_tests

__all__ = ["generate_tests"]
