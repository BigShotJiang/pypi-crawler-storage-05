"""Gate evaluation modules."""
