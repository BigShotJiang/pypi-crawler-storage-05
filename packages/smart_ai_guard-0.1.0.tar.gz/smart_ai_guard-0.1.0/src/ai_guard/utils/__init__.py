"""Utilities for AI-Guard."""
