# 2022-03-25 - Test Balancer Token

Deployment of the `TestBalancerToken`, for replicating the BAL token's access control scheme on testnets

## Useful Files

- [Base mainnet addresses](./output/base.json)
- [Fantom mainnet addresses](./output/fantom.json)
- [Goerli testnet addresses](./output/goerli.json)
- [Sepolia testnet addresses](./output/sepolia.json)
- [`TestBalancerToken` artifact](./artifact/TestBalancerToken.json)
