# 2022-04-20 - Smart Wallet Checker

Deployment of the `SmartWalletChecker`, responsible allowlisting select contracts to be able to mint veBAL.

## Useful Files

- [Ethereum mainnet addresses](./output/mainnet.json)
- [Goerli testnet addresses](./output/goerli.json)
- [Sepolia testnet addresses](./output/sepolia.json)
- [`SmartWalletChecker` artifact](./artifact/SmartWalletChecker.json)
