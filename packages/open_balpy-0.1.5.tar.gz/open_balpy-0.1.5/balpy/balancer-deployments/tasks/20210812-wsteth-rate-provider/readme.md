# 2021-08-12 - WstETH Rate Provider

Deployment of the `WstETHRateProvider`, for using wstETH in Meta Stable Pools.

## Useful Files

- [Ethereum mainnet addresses](./output/mainnet.json)
- [Goerli testnet addresses](./output/goerli.json)
- [`WstETHRateProvider` artifact](./artifact/WstETHRateProvider.json)
