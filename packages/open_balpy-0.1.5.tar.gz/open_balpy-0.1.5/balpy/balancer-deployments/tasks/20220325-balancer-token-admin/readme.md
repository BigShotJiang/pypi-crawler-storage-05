# 2022-03-25 - Balancer Token Admin

Deployment of the `BalancerTokenAdmin`, for enforcing a specified BAL emission rate onchain.

## Useful Files

- [Ethereum mainnet addresses](./output/mainnet.json)
- [Goerli testnet addresses](./output/goerli.json)
- [Sepolia testnet addresses](./output/sepolia.json)
- [`BalancerTokenAdmin` artifact](./artifact/BalancerTokenAdmin.json)
