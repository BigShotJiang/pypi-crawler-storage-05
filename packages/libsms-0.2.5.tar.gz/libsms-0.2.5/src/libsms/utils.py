def plog(funcname: str, obj: object) -> None:
    return print(f">> {funcname}:\n{obj}\n")
