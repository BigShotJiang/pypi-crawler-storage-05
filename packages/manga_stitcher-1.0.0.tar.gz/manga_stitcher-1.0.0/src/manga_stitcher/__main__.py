if __name__ == "__main__":
    from manga_stitcher.cli import app
    app()
