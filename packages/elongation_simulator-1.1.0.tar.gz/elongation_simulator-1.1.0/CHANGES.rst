Changes
-------

1.0.0 (unreleased)
~~~~~~~~~~~~~~~~~~
initial release