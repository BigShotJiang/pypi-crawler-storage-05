(Subject)

(Greeting)

(Goodwill Expression), (Our Introduction)

(Their Company Background)

(Their Company Challenges) (Our Solutions)

(Shoptalk Statement)

(Our Product Info)

(Our Product Effects)

(Confirmation Question)