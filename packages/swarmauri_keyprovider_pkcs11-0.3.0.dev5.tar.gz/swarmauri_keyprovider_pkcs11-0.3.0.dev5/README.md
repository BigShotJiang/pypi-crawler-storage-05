![Swamauri Logo](https://res.cloudinary.com/dbjmpekvl/image/upload/v1730099724/Swarmauri-logo-lockup-2048x757_hww01w.png)

# Swarmauri PKCS#11 Key Provider

Hardware-backed key provider using PKCS#11 devices.

## Installation

```bash
pip install swarmauri_keyprovider_pkcs11
```
