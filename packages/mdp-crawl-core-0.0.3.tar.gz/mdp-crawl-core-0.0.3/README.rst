pip uninstall mdp-crawl-core


注意：
mongo依赖版本：pymongo==4.7.3 and mongo version 7.0
如果需要使用旧版，切换到分支：mongo4

重点新增：
异步mongo，异步redis

pip install --upgrade mdp-crawl-core -i https://pypi.python.org/simple
pip show mdp-crawl-core
