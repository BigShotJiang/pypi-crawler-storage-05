<p align="center" style="padding: 0; margin: 0;">
    <img src="https://github.com/LorenzoPichetti/SbatchMan/blob/main/docs/images/SbatchManLogo.png" alt="SbatchManLogo" style="width: 6cm;">
<p>

# SbatchMan

A utility to create, launch, and monitor code experiments on SLURM, PBS, or local machines.

# Documentation

You can find a comprehensive documentation at [https://sbatchman.readthedocs.io/en/latest/](https://sbatchman.readthedocs.io/en/latest/)

PyPi project: [https://pypi.org/project/sbatchman/](https://pypi.org/project/sbatchman/)