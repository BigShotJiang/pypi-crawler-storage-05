
from promium.elements.input_field import InputField


class TextareaField(InputField):

    pass
