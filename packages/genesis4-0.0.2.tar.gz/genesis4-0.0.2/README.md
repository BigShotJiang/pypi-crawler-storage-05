# genesis4

A warpper for Genesis4 in accelerator physics, a simulation for FEL dynamics.

```shell
pip install genesis4
```

follow the guidance of Genesis4.

https://github.com/svenreiche/Genesis-1.3-Version4

