"""Constants for aiontfy."""

__version__ = "0.5.5"

MIN_PRIORITY = 1
MAX_PRIORITY = 5
