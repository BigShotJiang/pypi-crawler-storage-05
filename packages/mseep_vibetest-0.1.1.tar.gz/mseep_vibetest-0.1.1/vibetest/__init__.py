"""Web QA tool using Browser-Use agents for testing AI-generated websites."""

__version__ = "0.1.0" 