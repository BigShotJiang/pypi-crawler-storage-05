# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateDataImage:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'volume_id': 'str',
        'description': 'str',
        'tags': 'list[str]'
    }

    attribute_map = {
        'name': 'name',
        'volume_id': 'volume_id',
        'description': 'description',
        'tags': 'tags'
    }

    def __init__(self, name=None, volume_id=None, description=None, tags=None):
        r"""CreateDataImage

        The model defined in huaweicloud sdk

        :param name: 数据盘镜像名称。
        :type name: str
        :param volume_id: 数据盘ID。
        :type volume_id: str
        :param description: 数据盘描述。
        :type description: str
        :param tags: 数据盘镜像标签。
        :type tags: list[str]
        """
        
        

        self._name = None
        self._volume_id = None
        self._description = None
        self._tags = None
        self.discriminator = None

        self.name = name
        self.volume_id = volume_id
        if description is not None:
            self.description = description
        if tags is not None:
            self.tags = tags

    @property
    def name(self):
        r"""Gets the name of this CreateDataImage.

        数据盘镜像名称。

        :return: The name of this CreateDataImage.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this CreateDataImage.

        数据盘镜像名称。

        :param name: The name of this CreateDataImage.
        :type name: str
        """
        self._name = name

    @property
    def volume_id(self):
        r"""Gets the volume_id of this CreateDataImage.

        数据盘ID。

        :return: The volume_id of this CreateDataImage.
        :rtype: str
        """
        return self._volume_id

    @volume_id.setter
    def volume_id(self, volume_id):
        r"""Sets the volume_id of this CreateDataImage.

        数据盘ID。

        :param volume_id: The volume_id of this CreateDataImage.
        :type volume_id: str
        """
        self._volume_id = volume_id

    @property
    def description(self):
        r"""Gets the description of this CreateDataImage.

        数据盘描述。

        :return: The description of this CreateDataImage.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this CreateDataImage.

        数据盘描述。

        :param description: The description of this CreateDataImage.
        :type description: str
        """
        self._description = description

    @property
    def tags(self):
        r"""Gets the tags of this CreateDataImage.

        数据盘镜像标签。

        :return: The tags of this CreateDataImage.
        :rtype: list[str]
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this CreateDataImage.

        数据盘镜像标签。

        :param tags: The tags of this CreateDataImage.
        :type tags: list[str]
        """
        self._tags = tags

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateDataImage):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
