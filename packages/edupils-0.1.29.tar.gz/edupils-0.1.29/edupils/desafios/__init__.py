from .gude import *
from .labirinto import *
from .tartaruga import *