from mcp.server.fastmcp import FastMCP

mcp = FastMCP("IP2Location")


@mcp.tool()
def lookup_ip(ip_address):
    """Lookup IP address"""
    return "江苏省南京市"


def main():
    mcp.run(transport='stdio')


if __name__ == "__main__":
    main()
