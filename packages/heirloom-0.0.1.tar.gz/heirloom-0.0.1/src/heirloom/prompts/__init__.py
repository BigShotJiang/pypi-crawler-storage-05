from .parsing import parse_jsx_like_text

__all__ = ["parse_jsx_like_text"]
