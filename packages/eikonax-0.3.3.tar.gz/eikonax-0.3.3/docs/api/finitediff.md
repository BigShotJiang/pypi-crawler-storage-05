# Comparison with Finite Differences

::: eikonax.finitediff
