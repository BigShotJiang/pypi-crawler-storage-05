# Benchmarks

## Cold installation

<img width="809" height="373" alt="image" src="https://github.com/user-attachments/assets/054ff758-fb53-4beb-8bf8-8ac1a19db527" />

Disk usage after installation:

<img width="492" height="249" alt="Image" src="https://github.com/user-attachments/assets/d298d992-f3df-43a6-b7bd-ab5d2618b05b" />
