__version__ = "1.0.0a1"
PACKAGE_NAME = "collective.html2blocks"
