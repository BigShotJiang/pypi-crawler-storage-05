from llama_index.tools.salesforce.base import SalesforceToolSpec

__all__ = ["SalesforceToolSpec"]
