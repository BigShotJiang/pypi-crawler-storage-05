# (c) 2014 Kmee - Luis Felipe Mileo <mileo@kmee.com.br>
# (c) 2014 Kmee - Matheus Felix <matheus.felix@kmee.com.br>
# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import data_abstract
from . import l10n_br_hr_cbo
from . import hr_employee
from . import hr_job
from . import res_company
from . import res_partner
from . import hr_employee_dependent
from . import hr_civil_certificate_type
from . import hr_deficiency
from . import hr_dependent_type
from . import hr_educational_attainment
from . import hr_ethnicity
from . import hr_identity_type
