#!/usr/bin/env python3
"""
Entry point for five_tree_wood.ai module
"""

from .main import main

if __name__ == "__main__":
    main()
