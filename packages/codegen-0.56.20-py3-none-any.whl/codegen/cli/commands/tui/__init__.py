"""TUI command module."""
