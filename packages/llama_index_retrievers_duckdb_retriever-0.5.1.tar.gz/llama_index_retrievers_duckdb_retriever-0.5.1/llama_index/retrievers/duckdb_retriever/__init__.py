from llama_index.retrievers.duckdb_retriever.base import (
    DuckDBRetriever,
)

__all__ = ["DuckDBRetriever"]
