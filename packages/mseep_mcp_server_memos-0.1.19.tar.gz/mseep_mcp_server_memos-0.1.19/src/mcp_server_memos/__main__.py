# __main__.py

from mcp_server_memos import main

main()
