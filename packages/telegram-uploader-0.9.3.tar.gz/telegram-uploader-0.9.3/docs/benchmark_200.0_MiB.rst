==========  ===========  ===========  ===========  ===========  ==========
Parallel    Minimum      Maximum      Average      Median       Speed
==========  ===========  ===========  ===========  ===========  ==========
1 chunk     131.92 sec.  141.38 sec.  136.48 sec.  136.55 sec.  1.5 MiB/s
2 chunks    68.49 sec.   84.90 sec.   74.71 sec.   72.29 sec.   2.8 MiB/s
3 chunks    42.73 sec.   49.74 sec.   46.04 sec.   45.67 sec.   4.4 MiB/s
4 chunks    29.57 sec.   38.33 sec.   34.56 sec.   35.22 sec.   5.7 MiB/s
5 chunks    26.57 sec.   34.07 sec.   29.75 sec.   29.93 sec.   6.7 MiB/s
6 chunks    20.87 sec.   24.96 sec.   23.16 sec.   22.69 sec.   8.8 MiB/s
7 chunks    18.90 sec.   26.18 sec.   21.86 sec.   21.57 sec.   9.3 MiB/s
8 chunks    16.07 sec.   20.05 sec.   18.28 sec.   18.35 sec.   10.9 MiB/s
9 chunks    16.01 sec.   18.84 sec.   17.46 sec.   17.29 sec.   11.6 MiB/s
10 chunks   13.72 sec.   16.52 sec.   14.96 sec.   14.89 sec.   13.4 MiB/s
==========  ===========  ===========  ===========  ===========  ==========

* **Minimum time:** 13.72 sec. (14.6 MiB/s)
* **Maximum time:** 141.38 sec. (1.4 MiB/s)
* **Average time:** 41.73 sec. (4.8 MiB/s)
* **Median time:** 26.31 sec. (7.6 MiB/s)
