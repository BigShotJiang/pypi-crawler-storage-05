==========  ===========  ===========  ===========  ===========  ==========
Parallel    Minimum      Maximum      Average      Median       Speed
==========  ===========  ===========  ===========  ===========  ==========
1 chunk     420.82 sec.  451.54 sec.  437.80 sec.  440.59 sec.  4.6 MiB/s
2 chunks    212.98 sec.  231.35 sec.  223.42 sec.  225.71 sec.  9.1 MiB/s
3 chunks    147.93 sec.  166.37 sec.  156.28 sec.  156.64 sec.  13.1 MiB/s
4 chunks    112.07 sec.  124.13 sec.  116.48 sec.  115.49 sec.  17.7 MiB/s
5 chunks    87.51 sec.   95.32 sec.   91.69 sec.   92.30 sec.   22.2 MiB/s
6 chunks    72.52 sec.   82.02 sec.   75.89 sec.   74.44 sec.   27.5 MiB/s
7 chunks    60.66 sec.   66.30 sec.   63.74 sec.   64.86 sec.   31.6 MiB/s
8 chunks    51.64 sec.   55.25 sec.   53.63 sec.   53.89 sec.   38.0 MiB/s
9 chunks    47.51 sec.   52.94 sec.   49.36 sec.   48.63 sec.   42.1 MiB/s
10 chunks   40.69 sec.   44.31 sec.   42.49 sec.   42.30 sec.   48.4 MiB/s
==========  ===========  ===========  ===========  ===========  ==========

* **Minimum time:** 40.69 sec. (50.3 MiB/s)
* **Maximum time:** 451.54 sec. (4.5 MiB/s)
* **Average time:** 131.08 sec. (15.6 MiB/s)
* **Median time:** 83.37 sec. (24.6 MiB/s)
