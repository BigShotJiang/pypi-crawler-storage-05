==========  =========  =========  =========  =========  ==========
Parallel    Minimum    Maximum    Average    Median     Speed
==========  =========  =========  =========  =========  ==========
1 chunk     9.00 sec.  9.87 sec.  9.54 sec.  9.55 sec.  2.1 MiB/s
2 chunks    4.62 sec.  5.30 sec.  4.92 sec.  4.94 sec.  4.0 MiB/s
3 chunks    3.10 sec.  3.53 sec.  3.28 sec.  3.25 sec.  6.1 MiB/s
4 chunks    2.37 sec.  2.74 sec.  2.51 sec.  2.45 sec.  8.1 MiB/s
5 chunks    1.92 sec.  2.33 sec.  2.03 sec.  1.98 sec.  10.1 MiB/s
6 chunks    1.65 sec.  2.11 sec.  1.81 sec.  1.73 sec.  11.6 MiB/s
7 chunks    1.45 sec.  1.71 sec.  1.54 sec.  1.53 sec.  13.1 MiB/s
8 chunks    1.26 sec.  1.72 sec.  1.43 sec.  1.37 sec.  14.6 MiB/s
9 chunks    1.18 sec.  1.61 sec.  1.28 sec.  1.22 sec.  16.4 MiB/s
10 chunks   1.08 sec.  1.78 sec.  1.24 sec.  1.18 sec.  16.9 MiB/s
==========  =========  =========  =========  =========  ==========

* **Minimum time:** 1.08 sec. (18.5 MiB/s)
* **Maximum time:** 9.87 sec. (2.0 MiB/s)
* **Average time:** 2.96 sec. (6.8 MiB/s)
* **Median time:** 1.85 sec. (10.8 MiB/s)
