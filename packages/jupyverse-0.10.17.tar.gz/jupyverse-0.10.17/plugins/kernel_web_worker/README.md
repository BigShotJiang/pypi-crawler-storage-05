# fps-kernel-web-worker

An FPS plugin for the kernel web worker API, to be used with `microverse`.
