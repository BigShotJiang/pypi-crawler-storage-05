# fps-yjs

An FPS plugin for the Yjs API.
