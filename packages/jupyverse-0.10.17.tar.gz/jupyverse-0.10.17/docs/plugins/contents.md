`fps-contents` implements the `contents` API, i.e. everything related to reading/writing files, for the local file system.
