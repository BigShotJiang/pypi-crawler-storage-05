`fps-terminals` implements the terminals API, i.e. opening, closing and interacting with terminals.
