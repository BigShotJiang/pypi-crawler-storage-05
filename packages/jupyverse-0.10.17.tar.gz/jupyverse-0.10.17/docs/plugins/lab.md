`fps-lab` implements everything that is common to JupyterLab and Jupyter Notebook.
