`fps-resource-usage` implements the [resource usage](https://github.com/jupyter-server/jupyter-resource-usage) API, for monitoring memory and CPU usage.
