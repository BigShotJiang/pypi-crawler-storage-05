`fps-jupyterlab` implements the JupyterLab API.
