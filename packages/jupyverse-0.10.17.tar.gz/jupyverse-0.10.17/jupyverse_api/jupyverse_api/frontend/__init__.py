from jupyverse_api import Config


class FrontendConfig(Config):
    base_url: str = "/"
    collaborative: bool = False
