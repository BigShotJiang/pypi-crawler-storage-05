# ogd-common
Repository for commonly-shared components across OpenGameData projects, especially schemas and interfaces/outerfaces.
