from . import console 

if __name__ in ["__main__", "__mp_main__"]:        
    ws = console.argexec()     