*********************
Alma SRU helper |doc|
*********************

This python module is a tool to use Alma SRU. It manages the logs and the
backup of the records.

* Author: Raphaël Rey (raphael.rey@slsp.ch)
* Year: 2025
* Version: 3.0.3
* License: GNU General Public License v3.0
* `Documentation <https://almasru.readthedocs.io/en/latest/>`_

.. |doc| image:: https://readthedocs.org/projects/almapi-wrapper/badge/?version=latest
    :target: https://almasru.readthedocs.io/en/latest/
    :alt: Documentation Status