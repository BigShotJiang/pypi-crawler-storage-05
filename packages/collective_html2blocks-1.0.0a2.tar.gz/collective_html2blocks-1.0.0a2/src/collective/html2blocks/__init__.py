__version__ = "1.0.0a2"
PACKAGE_NAME = "collective.html2blocks"
