"""Command Line Interface for ``html2blocks``.

Package with implementation of each command available in the CLI.
"""
