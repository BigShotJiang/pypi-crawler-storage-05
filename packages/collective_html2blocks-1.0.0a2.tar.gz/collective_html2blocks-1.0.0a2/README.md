<h1 align="center">collective.html2blocks</h1>

<div align="center">

[![PyPI](https://img.shields.io/pypi/v/collective.html2blocks)](https://pypi.org/project/collective.html2blocks/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/collective.html2blocks)](https://pypi.org/project/collective.html2blocks/)
[![PyPI - Wheel](https://img.shields.io/pypi/wheel/collective.html2blocks)](https://pypi.org/project/collective.html2blocks/)
[![PyPI - License](https://img.shields.io/pypi/l/collective.html2blocks)](https://pypi.org/project/collective.html2blocks/)
[![PyPI - Status](https://img.shields.io/pypi/status/collective.html2blocks)](https://pypi.org/project/collective.html2blocks/)


[![CI](https://github.com/collective/collective.html2blocks/actions/workflows/ci.yml/badge.svg)](https://github.com/collective/collective.html2blocks/actions/workflows/ci.yml)

[![GitHub contributors](https://img.shields.io/github/contributors/collective/collective.html2blocks)](https://github.com/collective/collective.html2blocks)
[![GitHub Repo stars](https://img.shields.io/github/stars/collective/collective.html2blocks?style=social)](https://github.com/collective/collective.html2blocks)

</div>

**collective.html2blocks** helps with migrations from old Plone versions -- and other CMS -- to Volto.

Read the [documentation](https://collective.github.io/collective.html2blocks).
