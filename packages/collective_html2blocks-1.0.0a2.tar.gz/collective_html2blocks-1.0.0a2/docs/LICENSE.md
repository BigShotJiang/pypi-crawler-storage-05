collective.html2blocks Copyright 2025, Érico Andrei

The text and illustrations in this website are licensed by the Plone Foundation under a [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/) license. Plone and the Plone® logo are registered trademarks of the Plone Foundation, registered in the United States and other countries. For guidelines on the permitted uses of the Plone trademarks, see [https://plone.org/foundation/logo](https://plone.org/foundation/logo). All other trademarks are owned by their respective owners.
