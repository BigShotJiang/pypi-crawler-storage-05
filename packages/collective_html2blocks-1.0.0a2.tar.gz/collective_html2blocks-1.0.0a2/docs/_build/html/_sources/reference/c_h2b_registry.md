---
myst:
  html_meta:
    "description": "collective.html2blocks Reference"
    "property=og:description": "collective.html2blocks Reference"
    "property=og:title": "collective.html2blocks Reference"
    "keywords": "Plone, collective.html2blocks, reference"
---

# `collective.html2blocks.registry`

```{eval-rst}
.. automodule:: collective.html2blocks.registry
    :members:
```