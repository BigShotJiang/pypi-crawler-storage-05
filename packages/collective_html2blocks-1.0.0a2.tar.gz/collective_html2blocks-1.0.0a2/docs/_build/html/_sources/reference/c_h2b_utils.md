---
myst:
  html_meta:
    "description": "collective.html2blocks Reference"
    "property=og:description": "collective.html2blocks Reference"
    "property=og:title": "collective.html2blocks Reference"
    "keywords": "Plone, collective.html2blocks, reference"
---

# `collective.html2blocks.utils`
## `collective.html2blocks.utils.blocks`

```{eval-rst}
.. automodule:: collective.html2blocks.utils.blocks
    :members:
```

## `collective.html2blocks.utils.generator`

```{eval-rst}
.. automodule:: collective.html2blocks.utils.generator
    :members:
```

## `collective.html2blocks.utils.inline`

```{eval-rst}
.. automodule:: collective.html2blocks.utils.inline
    :members:
```

## `collective.html2blocks.utils.markup`

```{eval-rst}
.. automodule:: collective.html2blocks.utils.markup
    :members:
```

## `collective.html2blocks.utils.slate`

```{eval-rst}
.. automodule:: collective.html2blocks.utils.slate
    :members:
```
