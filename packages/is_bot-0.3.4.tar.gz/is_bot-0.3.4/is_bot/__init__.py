from ._is_bot import Bots

__version__ = '0.3.4'

__all__ = ('Bots',)
