# greenideas-dict
Example twaddle dictionaries for use with the greenideas package using its default grammar and formatting rulesets
