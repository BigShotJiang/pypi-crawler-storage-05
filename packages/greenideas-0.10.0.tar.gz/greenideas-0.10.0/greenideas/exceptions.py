class RuleNotFoundError(Exception):
    pass


class RelevantAttributesNotSpecified(Exception):
    pass


class InvalidGrammarRule(Exception):
    pass


class TwaddleConversionError(Exception):
    pass
