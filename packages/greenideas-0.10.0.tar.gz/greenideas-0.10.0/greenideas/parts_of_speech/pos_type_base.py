from enum import Enum


class POSType(Enum):
    pass
