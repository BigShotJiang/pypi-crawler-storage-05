"""
KiCad Library Manager - Library management utilities for KiCad
"""
