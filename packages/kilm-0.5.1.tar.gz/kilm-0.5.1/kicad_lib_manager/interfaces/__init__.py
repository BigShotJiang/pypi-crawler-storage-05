"""Service interfaces for KiCad Library Manager."""
