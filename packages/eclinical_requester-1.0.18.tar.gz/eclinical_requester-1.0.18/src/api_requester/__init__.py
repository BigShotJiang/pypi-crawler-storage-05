# !/usr/bin/python3
# -*- coding:utf-8 -*-
"""
@Author: xiaodong.li
@Time: 1/8/2025 3:52 PM
@Description: Description
@File: __init__.py.py
"""
__version__ = "1.0.18"
