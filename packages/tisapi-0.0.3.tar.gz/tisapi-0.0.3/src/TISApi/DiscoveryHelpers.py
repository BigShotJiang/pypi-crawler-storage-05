DEVICE_APPLIANCES = {
    (0x1B, 0xBA): {
        "name": "RCU-8OUT-8IN",
        "appliances": {"switch": 8},
    }
}
