from . import core, optim, utils
from .core import Modular
from .utils import set_compilation
from . import modules as m