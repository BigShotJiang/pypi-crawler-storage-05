CODEW_API_URL = "https://7176.codew.es"
