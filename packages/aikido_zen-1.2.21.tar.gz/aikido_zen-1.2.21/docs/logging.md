# Logging
Aikido by default uses the `INFO` logging level, if you want debug messages from aikido,
Set the `AIKIDO_DEBUG` environment variable. Like so :
```env
AIKIDO_DEBUG=True
```
