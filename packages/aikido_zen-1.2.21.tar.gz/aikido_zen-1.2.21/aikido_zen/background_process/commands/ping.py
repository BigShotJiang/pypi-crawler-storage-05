"""exports `process_ping`"""


def process_ping(connection_manager, data, queue=None):
    """when main process quits , or during testing etc"""
    return "Received"
