.. _vyos.helium118_mc:

##################
vyos.helium118
##################

This Model Component provides the VyOS Helium 1.1.8 image to a VM.

**Model Component Dependencies:**
    * :ref:`vyos_mc`

*****************
Available Objects
*****************

.. automodule:: vyos.helium118
    :members:
    :undoc-members:
    :special-members:
    :private-members:
    :show-inheritance:
    :exclude-members: __dict__,__weakref__,__module__
