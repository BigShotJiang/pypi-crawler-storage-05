def main():
    print("Hello from nano-banana!")


if __name__ == "__main__":
    main()
