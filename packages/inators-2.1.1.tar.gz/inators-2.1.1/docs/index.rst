=======
inators
=======

.. include:: ../README.rst
   :start-after: .. start included documentation
   :end-before: .. end included documentation


.. toctree::
   :caption: API Reference
   :maxdepth: 1

   inators.arg
   inators.imp
   inators.log
   inators.sphinx


.. toctree::
   :caption: Miscellaneous
   :maxdepth: 1

   relnotes
   license
