=========================
Module ``inators.sphinx``
=========================

.. automodule:: inators.sphinx


.. describe:: inators.sphinx.argdoc
.. automodule:: inators.sphinx.argdoc
