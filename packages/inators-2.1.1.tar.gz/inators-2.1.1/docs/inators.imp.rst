======================
Module ``inators.imp``
======================

.. automodule:: inators.imp
   :members:
