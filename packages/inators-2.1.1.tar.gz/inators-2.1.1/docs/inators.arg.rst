======================
Module ``inators.arg``
======================

.. automodule:: inators.arg
   :members:
   :imported-members:
