from vearne_akshare_mcp import cn, hk, us

if __name__ == "__main__":
    print(cn.calculate_value("601818"))
