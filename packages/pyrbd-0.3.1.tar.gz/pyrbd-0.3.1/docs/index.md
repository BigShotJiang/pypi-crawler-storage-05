# <img alt="pyRBDlogo" src=images/logo.svg width=50 align=top> pyRBD

--8<-- "README.md:3:-5"


<div><img src="examples/simple_RBD.svg" width=500/></div>
