class Uzbek:
    pass
