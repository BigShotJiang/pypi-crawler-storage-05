"""
Subpackage with internal utilities for `soupsavvy` package.
"""
