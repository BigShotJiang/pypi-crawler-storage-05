"""Module for package custom logging setup."""

import logging

NAME = "soupsavvy"
LOGGER = logging.getLogger(NAME)
