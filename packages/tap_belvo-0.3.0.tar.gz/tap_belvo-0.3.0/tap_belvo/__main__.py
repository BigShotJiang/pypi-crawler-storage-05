"""Tap executable."""

from __future__ import annotations

from tap_belvo.tap import TapBelvo

TapBelvo.cli()
