"""Python package for the tap-belvo CLI."""

from __future__ import annotations
