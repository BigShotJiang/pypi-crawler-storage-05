"""
Built-in plugins directory for Penguin core tools.

This directory contains plugins that provide core functionality
that was previously hard-coded in the ToolManager.
"""