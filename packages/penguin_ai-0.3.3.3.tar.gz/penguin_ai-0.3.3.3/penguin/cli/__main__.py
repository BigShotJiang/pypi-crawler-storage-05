"""Module entry for `python -m penguin.penguin.cli`."""
from penguin.penguin.cli.cli import app

if __name__ == "__main__":
    app()