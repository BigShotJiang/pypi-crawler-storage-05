from smol_html.smol_html import SmolHtmlCleaner

all = ["__version__", "SmolHtmlCleaner"]
__version__ = "0.1.0"
