from oarepo_runtime.services.service import SearchAllRecordsService


class DataService(SearchAllRecordsService):
    """DataRecord service."""
