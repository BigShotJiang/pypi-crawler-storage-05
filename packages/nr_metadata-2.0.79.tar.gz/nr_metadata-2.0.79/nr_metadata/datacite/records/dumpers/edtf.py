from oarepo_runtime.records.dumpers.edtf_interval import EDTFIntervalDumperExt


class DataciteEDTFIntervalDumperExt(EDTFIntervalDumperExt):
    """edtf interval dumper."""

    paths = []
