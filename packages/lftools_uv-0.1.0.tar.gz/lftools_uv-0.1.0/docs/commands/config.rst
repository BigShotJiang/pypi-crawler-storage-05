.. SPDX-FileCopyrightText: 2025 The Linux Foundation
..
.. SPDX-License-Identifier: EPL-1.0

******
config
******

.. program-output:: lftools-uv config --help

Commands
========



get
---

.. program-output:: lftools-uv config get --help

set
----

.. program-output:: lftools-uv config set --help
