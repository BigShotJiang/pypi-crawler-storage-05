"""Test code file without license header."""
