This module allows to link a lot/serial number to an asset. It is
usefull when you have asset that you manage in your stock.
