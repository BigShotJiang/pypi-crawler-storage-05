"""acforge cli - Configuration management for AI development workflows."""

__version__ = "3.1.1"
__author__ = "Ondrej (Ondra) Krajicek"
__email__ = "me@ondrejkrajicek.com"