figaro.load module
==================

.. automodule:: figaro.rate
   :members:
   :undoc-members:
   :show-inheritance:
