figaro.cosmology module
=======================

.. automodule:: figaro.cosmology
   :members:
   :undoc-members:
   :show-inheritance:
