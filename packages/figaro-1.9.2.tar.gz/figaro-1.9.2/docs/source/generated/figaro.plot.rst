﻿figaro.plot
===========

.. automodule:: figaro.plot

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      plot_1d_dist
      plot_median_cr
      plot_multidim
      plot_n_clusters_alpha
      pp_plot_cdf
      pp_plot_levels
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      PPPlot
   
   

   
   
   



