﻿figaro.utils
============

.. automodule:: figaro.utils

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      get_priors
      load_options
      make_single_gaussian_mixture
      recursive_grid
      rejection_sampler
      rvs_median
      save_options
   
   

   
   
   

   
   
   



