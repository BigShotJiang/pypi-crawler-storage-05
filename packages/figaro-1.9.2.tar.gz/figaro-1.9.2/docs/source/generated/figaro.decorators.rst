﻿figaro.decorators
=================

.. automodule:: figaro.decorators

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      antiprobit
      cartesian
      celestial
      from_probit
      probit
   
   

   
   
   

   
   
   



