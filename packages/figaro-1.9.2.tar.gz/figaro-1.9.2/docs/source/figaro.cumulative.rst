figaro.cumulative module
========================

.. automodule:: figaro.cumulative
   :members:
   :undoc-members:
   :show-inheritance:
