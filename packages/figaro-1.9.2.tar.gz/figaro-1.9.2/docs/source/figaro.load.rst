figaro.load module
==================

.. automodule:: figaro.load
   :members:
   :undoc-members:
   :show-inheritance:
