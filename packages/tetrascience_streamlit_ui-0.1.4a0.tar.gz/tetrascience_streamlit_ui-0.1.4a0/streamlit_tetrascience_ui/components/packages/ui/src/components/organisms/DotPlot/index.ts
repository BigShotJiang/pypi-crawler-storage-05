export { DotPlot } from "./DotPlot";
export type {
  DotPlotDataSeries,
  DotPlotProps,
  DotPlotVariant,
} from "./DotPlot";
