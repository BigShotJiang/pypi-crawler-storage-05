export { Icon, IconName } from "./Icon";
export type { IconProps, IconsProps } from "./Icon";
