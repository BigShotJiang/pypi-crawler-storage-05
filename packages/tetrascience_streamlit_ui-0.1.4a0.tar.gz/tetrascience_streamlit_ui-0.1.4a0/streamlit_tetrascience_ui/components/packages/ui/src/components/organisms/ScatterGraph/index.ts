export { ScatterGraph } from "./ScatterGraph";
export type {
  ScatterDataPoint,
  ScatterDataSeries,
  ScatterGraphProps,
} from "./ScatterGraph";
