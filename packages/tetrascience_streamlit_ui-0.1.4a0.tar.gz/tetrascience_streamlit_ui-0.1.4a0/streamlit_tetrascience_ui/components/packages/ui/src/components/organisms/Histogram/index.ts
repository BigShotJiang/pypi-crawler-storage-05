export { Histogram } from "./Histogram";
export type { HistogramDataSeries, HistogramProps } from "./Histogram";
