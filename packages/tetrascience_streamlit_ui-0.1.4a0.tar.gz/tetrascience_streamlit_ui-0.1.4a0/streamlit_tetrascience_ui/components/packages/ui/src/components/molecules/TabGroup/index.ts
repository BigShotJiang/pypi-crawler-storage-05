export { TabGroup } from "./TabGroup";
export type { TabGroupProps, TabItem } from "./TabGroup";
