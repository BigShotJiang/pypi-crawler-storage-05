export { Chromatogram } from "./Chromatogram";
export type { PeakData, ChromatogramProps } from "./Chromatogram";
