export { Tab } from "./Tab";
export type { TabProps, TabSize } from "./Tab";
