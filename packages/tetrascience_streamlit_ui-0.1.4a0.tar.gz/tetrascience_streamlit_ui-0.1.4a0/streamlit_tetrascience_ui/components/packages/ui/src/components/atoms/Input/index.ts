export { Input } from "./Input";
export type { InputProps, InputSize } from "./Input";
