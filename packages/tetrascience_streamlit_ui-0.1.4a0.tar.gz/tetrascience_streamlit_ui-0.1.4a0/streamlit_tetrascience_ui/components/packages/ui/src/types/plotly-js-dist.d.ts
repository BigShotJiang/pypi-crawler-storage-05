declare module "plotly.js-dist" {
  import * as Plotly from "plotly.js";
  export = Plotly;
}
