export { SupportiveText } from "./SupportiveText";
export type { SupportiveTextProps } from "./SupportiveText";
