export { Main } from "./Main";
export type { MainProps } from "./Main";
