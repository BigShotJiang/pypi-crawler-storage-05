export { Heatmap } from "./Heatmap";
export type { HeatmapProps } from "./Heatmap";
