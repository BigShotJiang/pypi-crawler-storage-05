import {
  Streamlit,
  withStreamlitConnection,
  ComponentProps,
} from "streamlit-component-lib"
import React, { useEffect, ReactElement } from "react"
import { Card, CardProps } from "tetrascience-ui"
import "tetrascience-ui/index.css"

/**
 * This is a React-based component template. The passed props are coming from the
 * Streamlit library. Your custom args can be accessed via the `args` props.
 */
function StCard({ args, disabled, theme }: ComponentProps<any>): ReactElement {
  const {
    name,
    children = "Card Content",
    title,
    variant = "default",
    size = "medium",
    className,
    fullWidth = false,
    ...cardProps
  } = args as {
    name?: string
    children?: React.ReactNode
    title?: React.ReactNode
    variant?: CardProps["variant"]
    size?: CardProps["size"]
    className?: string
    fullWidth?: boolean
  } & Partial<CardProps>

  // setFrameHeight should be called on first render and evertime the size might change (e.g. due to a DOM update).
  // Adding the theme here since it might effect the visual size of the component.
  useEffect(() => {
    Streamlit.setFrameHeight()
  }, [theme])

  // Merge card props
  const mergedCardProps = {
    title,
    variant,
    size,
    className,
    fullWidth,
    ...cardProps,
  }

  return <Card {...mergedCardProps}>{children}</Card>
}

export default withStreamlitConnection(StCard)
