FLAGS_MODULE: str = "app.flags"
