import math
from alive_progress import alive_bar, config_handler
from sys import stderr
from typing import TypeAlias
import ete4


cluster: TypeAlias = set[str]

## config for progress bar
config_handler.set_global(bar="bubbles", spinner="radioactive", file=stderr)


def rooted_cluster_affinity(t1: ete4.Tree, t2: ete4.Tree, disable_bar=False) -> float:
    t1_cmap = t1.get_cached_content(prop="name")
    tree_dist = 0
    with alive_bar(len(t1_cmap), disable=disable_bar) as bar:
        for i in t1.traverse("postorder"):
            dist = rooted_cdist(t1_cmap[i], t2)
            i.add_prop(
                "c_dist",
                dist / max(1, min(len(t1_cmap[i]) - 1, len(t1) - len(t1_cmap[i]))),
            )
            tree_dist += dist
            bar()
    return tree_dist


def rooted_cluster_support(t1: ete4.Tree, t2: ete4.Tree) -> float:
    t1_cmap = t1.get_cached_content(prop="name")
    tree_dist = 0
    with alive_bar(len(t1_cmap)) as bar:
        for i in t1.traverse("postorder"):
            dist = rooted_cdist(t1_cmap[i], t2) / len(t1_cmap[i])
            i.add_prop("c_dist", dist)
            tree_dist += dist
            bar()
    return tree_dist


def unrooted_cluster_affinity(t1, t2):
    t1_cmap = t1.get_cached_content(prop="name")
    t2_bipartitions = list(t2.edges())
    n = len(t1)
    tree_dist = 0
    with alive_bar(n) as bar:
        for i in t1.traverse("postorder"):
            if len(t1_cmap[i]) > 1 and len(t1_cmap[i])<n:
                mindist = math.inf
                for j in t2_bipartitions:
                    x = set([l.name for l in j[1]])
                    cdx = len(t1_cmap[i]^x)
                    cdist = min(cdx, n- cdx)
                    if cdist<0:
                        raise RuntimeError()
                    if cdist < mindist:
                        mindist = cdist
                i.add_prop("c_dist",mindist/max(1,min(len(t1_cmap[i])-1,n-len(t1_cmap[i]))))
                tree_dist += mindist
    return tree_dist

def unrooted_cdist(c, t2, n):
    mindist = math.inf
    maxdist = 0
    intersection_lookup = dict()
    t2lookup = t2.get_cached_content(prop="name")
    for i in t2.traverse("postorder"):
        intersection = 0
        if i.is_leaf:
            if i.name in c:
                intersection = 1
            else:
                intersection = 0
        else:
            for ch in i.children:
                intersection += intersection_lookup[ch.id]
        intersection_lookup[i.id] = intersection
        newdist = len(c) + len(t2lookup[i]) - 2 * intersection
        if mindist > newdist:
            mindist = newdist
        if maxdist < newdist and len(c) != n:
            maxdist = maxdist
    return min(mindist, n - maxdist)


"""
    rooted_cdist: Cluster -> Tree -> Int
"""


def rooted_cdist(c: cluster, t2: ete4.Tree) -> int:
    mindist = math.inf
    intersection_lookup = dict()
    t2lookup = t2.get_cached_content(prop="name")
    for i in t2.traverse("postorder"):
        intersection = 0
        if i.is_leaf:
            if i.name in c:
                intersection = 1
            else:
                intersection = 0
        else:
            for ch in i.children:
                intersection += intersection_lookup[ch.id]
        intersection_lookup[i.id] = intersection
        newdist = len(c) + len(t2lookup[i]) - 2 * intersection
        if mindist > newdist:
            mindist = newdist
    return mindist


def calculate_rooted_tau(t: ete4.Tree) -> int:
    tau = 0
    n = len(t)
    sizemap = dict()
    for i in t.traverse("postorder"):
        if i.is_leaf:
            s = 1
        else:
            s = 0
            for ch in i.children:
                s += sizemap[ch.id]
        sizemap[i.id] = s
        tau += min(s - 1, n - s)
    return tau


def calculate_rooted_phi(t: ete4.Tree) -> float:
    phi = 0
    n = len(t)
    sizemap = dict()
    for i in t.traverse("postorder"):
        if i.is_leaf:
            s = 1
        else:
            s = 0
            for ch in i.children:
                s += sizemap[ch.id]
        sizemap[i.id] = s
        phi += min(s - 1, n - s) / s
    return phi
