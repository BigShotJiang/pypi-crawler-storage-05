export const CHAT_STYLES = {
	padding: "0 16px", 
	maxWidth: "1280px",
	minWidth: "400px",
	margin: "0 auto",
	width: "100%"
};
