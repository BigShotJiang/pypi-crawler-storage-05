# Tests for serilog-python package
