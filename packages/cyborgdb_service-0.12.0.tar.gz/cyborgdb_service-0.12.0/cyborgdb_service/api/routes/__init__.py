# cyborgdb_service/api/routes/__init__.py
"""
Route handlers for the CyborgDB API.
"""