# cyborgdb_service/api/__init__.py
"""
API module for the CyborgDB service.
"""