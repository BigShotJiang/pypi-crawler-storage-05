
class ElementAttributes:
    def __init__(self):
        ...
    
