# build
rm -rf dist && python -m build

# publish
python -m twine upload dist/* --verbose


pypi-AgEIcHlwaS5vcmcCJGYyNWE3NDI4LTEyYzgtNGQ4Mi05Y2NkLTJiZDcwMWNiMTkwZQACDlsxLFsiZ3RoZWxwIl1dAAIsWzIsWyI5MDMxMTgwYS1lMWJkLTQ0NjctYWJkZC02YTllMzAzMjQxZjUiXV0AAAYgrV5pEgsrtT_vE3uio0xOHDvAAUSu_nGOuavWfABUbnM