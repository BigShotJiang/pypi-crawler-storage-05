# __init__.py

from multimodal_sdk.role.main import _Role