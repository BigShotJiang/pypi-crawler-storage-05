# apsig docs
- [apsig.draft](httpsig.md)
    - [apsig.draft.draftSigner](httpsig.md#apsigdraftdraftsigner)
    - [apsig.draft.draftVerifier](httpsig.md#apsigdraftdraftverifier)
- [apsig.proof](proof.md)
    - [apsig.proof.ProofSigner](proof.md#class-proofsigner)
    - [apsig.proof.ProofVerifier](proof.md#class-proofverifier)
- [apsig.LDSignature](ldsignature.md)