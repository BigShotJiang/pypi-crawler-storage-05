# `apsig.proof`
Document is migrated to [ap.amase.cc](http://ap.amase.cc/apsig/proof/).
