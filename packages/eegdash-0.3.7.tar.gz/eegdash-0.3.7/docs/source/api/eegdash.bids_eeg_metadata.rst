eegdash.bids\_eeg\_metadata module
==================================

.. automodule:: eegdash.bids_eeg_metadata
   :members:
   :show-inheritance:
   :undoc-members:
