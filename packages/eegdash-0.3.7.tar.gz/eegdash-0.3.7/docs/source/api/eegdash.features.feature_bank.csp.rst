eegdash.features.feature\_bank.csp module
=========================================

.. automodule:: eegdash.features.feature_bank.csp
   :members:
   :show-inheritance:
   :undoc-members:
