(dependencymanagement)=

# Dependency and version management.

(dependencies)=

## dependencies

```{eval-rst}
.. automodule:: dependencies
   :members:
```

(version)=

## version

```{eval-rst}
.. automodule:: version
   :members:
```
