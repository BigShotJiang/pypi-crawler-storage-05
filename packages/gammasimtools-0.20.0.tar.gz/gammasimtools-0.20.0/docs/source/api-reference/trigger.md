(trigger)=

# Trigger simulations.

## telescope_trigger_rates

(telescope_trigger_module)=

```{eval-rst}
.. automodule:: telescope_trigger_rates
   :members:
```
