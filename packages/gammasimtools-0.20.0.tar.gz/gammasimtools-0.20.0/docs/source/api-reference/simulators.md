(simulators)=

# Simulator

Base modules for calling external simulation software.

## simulator

(simulatormodule)=

```{eval-rst}
.. automodule:: simulator
   :members:
```
