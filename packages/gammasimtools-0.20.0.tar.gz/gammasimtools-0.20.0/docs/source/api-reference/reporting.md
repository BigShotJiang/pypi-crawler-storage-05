(reporting)=

# Reporting

The reporting modules read model parameter values and descriptions from the database and write to a report.


## docs_read_parameters

```{eval-rst}
.. automodule:: reporting.docs_read_parameters
   :members:
```


## docs_auto_report_generator

```{eval-rst}
.. automodule:: reporting.docs_auto_report_generator
   :members:
```
