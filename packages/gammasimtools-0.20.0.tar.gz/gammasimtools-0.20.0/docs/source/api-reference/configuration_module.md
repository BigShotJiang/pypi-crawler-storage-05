(configurationmodule)=

# Configuration

Reference documentation for the configuration of simtools applications.

(configurationconfigurator)=

## configurator

```{eval-rst}
.. automodule:: configuration.configurator
   :members:
```

(configurationcommandline-parser)=

## commandline_parser

```{eval-rst}
.. automodule:: configuration.commandline_parser
   :members:
```
