(io)=

# I/O

This module include I/O related functionality.

(iomodule)=

## io_handler

```{eval-rst}
.. automodule:: simtools.io.io_handler
   :members:
```

(io_ascii_handler)=

## ascii_handler

```{eval-rst}
.. automodule:: simtools.io.ascii_handler
   :members:
```

(io_table_handler)=

## table_handler

```{eval-rst}
.. automodule:: simtools.io.table_handler
   :members:
```

(iohdf5)=

## hdf5_handler

```{eval-rst}
.. automodule:: simtools.io.hdf5_handler
   :members:
```

(legacy-data-handler)=

## legacy_data_handler

```{eval-rst}
.. automodule:: simtools.io.legacy_data_handler
   :members:
```
