# Data Model

- Description of [simulation model parameters](model_parameters.md) through schema files
- description of simulation data format
- description of metadata

:::{warning}
Incomplete Documentation.
:::

```{toctree}
:hidden:
:maxdepth: 1
model_parameters.md
```
