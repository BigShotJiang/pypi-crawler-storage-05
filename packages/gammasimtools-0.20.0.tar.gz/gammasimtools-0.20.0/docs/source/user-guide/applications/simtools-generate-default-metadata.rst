
simtools-generate-default-metadata
==================================

.. automodule:: generate_default_metadata
   :members:
