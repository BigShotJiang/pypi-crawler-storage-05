.. _db_get_array_layouts_from_db:

simtools-db-get-array-layouts-from-db
=====================================

.. automodule:: db_get_array_layouts_from_db
   :members:
