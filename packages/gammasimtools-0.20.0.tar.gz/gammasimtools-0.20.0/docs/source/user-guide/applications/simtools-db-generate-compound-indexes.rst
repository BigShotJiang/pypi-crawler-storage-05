.. _db_generate_compound_indexes:

simtools-db-generate-compound-indexes
=====================================

.. automodule:: simtools.applications.db_generate_compound_indexes
   :members:
