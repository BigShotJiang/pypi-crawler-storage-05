
simtools-derive-trigger-rates
=============================

.. automodule:: derive_trigger_rates
   :members:
