
simtools-generate-array-config
==============================

.. automodule:: generate_array_config
   :members:
