simtools-calculate-incident-angles
==================================

.. automodule:: simtools.applications.calculate_incident_angles
    :members:
