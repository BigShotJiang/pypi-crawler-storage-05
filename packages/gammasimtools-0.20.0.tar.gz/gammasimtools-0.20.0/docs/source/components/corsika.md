# Air shower simulations with CORSIKA

- [CORSIKA 7](https://www.iap.kit.edu/corsika/): Simulates extensive air showers.
- [corsika-opt-patches](https://gitlab.cta-observatory.org/cta-computing/dpps/simpipe/corsika-opt-patches): Vectorized performance-optimized patches for Cherenkov light generation in propagation in CORSIKA.

```{warning}
Incomplete documentation - missing references
```
