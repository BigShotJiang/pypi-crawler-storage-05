# Collection of database scripts

This directory contains a collection of scripts that can be used to interact with the database:

* dump or copy databases
* generate a local copy of the model parameter database.

See the [database section](https://gammasim.github.io/simtools/user-guide/databases.html) in the documentation for more details.
