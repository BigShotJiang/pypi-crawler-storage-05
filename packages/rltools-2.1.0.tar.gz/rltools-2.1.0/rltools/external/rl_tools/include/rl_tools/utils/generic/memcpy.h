#include "../../version.h"
#if (defined(RL_TOOLS_DISABLE_INCLUDE_GUARDS) || !defined(RL_TOOLS_UTILS_GENERIC_MEMCPY_H)) && (RL_TOOLS_USE_THIS_VERSION == 1)
#pragma once
#define RL_TOOLS_UTILS_GENERIC_MEMCPY_H

RL_TOOLS_NAMESPACE_WRAPPER_START
//namespace rl_tools::utils{
//    template<typename T, typename ST>
//    void memcpy(T* source, const T* target, ST size) {
//        for(ST i = 0; i < size; i++) {
//            target[i] = source[i];
//        }
//    }
//}
RL_TOOLS_NAMESPACE_WRAPPER_END
#endif
