#include "dense/operations_cpu_mkl.h"
#include "gru/operations_generic.h"
