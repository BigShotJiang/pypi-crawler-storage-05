#include "dense/operations_generic.h"
#include "gru/operations_generic.h"
