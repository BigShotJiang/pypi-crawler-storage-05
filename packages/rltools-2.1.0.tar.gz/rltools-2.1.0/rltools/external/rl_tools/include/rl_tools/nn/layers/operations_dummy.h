#include "dense/operations_dummy.h"
