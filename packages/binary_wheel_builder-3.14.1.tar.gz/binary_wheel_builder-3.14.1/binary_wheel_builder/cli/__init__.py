"""
CLI interface for working with python files instead of writing native python code.

This only works for existing release sources, either provided by this package or another package exposing it as an API
"""
