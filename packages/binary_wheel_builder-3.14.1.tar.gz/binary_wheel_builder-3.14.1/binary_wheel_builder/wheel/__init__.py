"""
Wheel Format related util and functionality, primarily intended for internal use.
"""
