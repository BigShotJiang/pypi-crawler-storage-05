# Changelog

## [0.3.2](https://github.com/b-long/opentdf-python-sdk/compare/otdf-python-v0.3.1...otdf-python-v0.3.2) (2025-09-12)


### Bug Fixes

* fix release-please configuration ([#104](https://github.com/b-long/opentdf-python-sdk/issues/104)) ([3b1c949](https://github.com/b-long/opentdf-python-sdk/commit/3b1c949680b1c4e8ec5bae5d2dbb2f18dc53b559))

## [0.3.1](https://github.com/b-long/opentdf-python-sdk/compare/otdf-python-v0.3.0...otdf-python-v0.3.1) (2025-09-12)


### Bug Fixes

* testing improvements ([#102](https://github.com/b-long/opentdf-python-sdk/issues/102)) ([8e82361](https://github.com/b-long/opentdf-python-sdk/commit/8e8236190df157da8ab7fda0b6dfb9cd78bae3bf))

## [0.3.0](https://github.com/b-long/opentdf-python-sdk/compare/v0.2.20...otdf-python-v0.3.0) (2025-09-11)


### ⚠ BREAKING CHANGES

* rewrite in pure Python ([#62](https://github.com/b-long/opentdf-python-sdk/issues/62))

### Features

* configure release-please ([#74](https://github.com/b-long/opentdf-python-sdk/issues/74)) ([439becd](https://github.com/b-long/opentdf-python-sdk/commit/439becd82a5faf834a190516b64e21aa331c0176))
