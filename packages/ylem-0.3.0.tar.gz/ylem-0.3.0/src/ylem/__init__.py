from loguru import logger

from .cleaner import Cleaner

__all__ = ("Cleaner", "main")


def main() -> None: logger.info("Hello from ylem! This repo is not yet ready for use!")