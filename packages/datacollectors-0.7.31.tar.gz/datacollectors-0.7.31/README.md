# TCF datacollectors

Data collectors from energy data sources

## Installation

Run the following to install 
```
python -m pip install datacollectors
```

## Usage

```
import datacollectors

# connectors: Entsoe, ECB, Trading Economics, Energidataservice and ICE
```


