"""Base revision -- noop.

Revision ID: da7cd32b690d
Revises: 567bc23fd1ac
Create Date: 2019-11-22 11:02:06.180581

"""

# revision identifiers, used by Alembic.
revision = "da7cd32b690d"
down_revision = "567bc23fd1ac"
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
