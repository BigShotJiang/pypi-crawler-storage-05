__all__ = ["Profiler", "profile"]


from cdispyutils.profiling.profiler import Profiler, profile
