from llama_index.tools.cogniswitch.base import CogniswitchToolSpec

__all__ = [
    "CogniswitchToolSpec",
]
