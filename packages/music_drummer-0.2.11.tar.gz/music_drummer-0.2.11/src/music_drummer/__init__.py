# The root of the entire project
from music_drummer.music_drummer import Drummer

__version__ = "0.2.11"