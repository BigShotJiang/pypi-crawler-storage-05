__version__ = "0.2.10"

from starstack.particlesStar import ParticlesStarSet
