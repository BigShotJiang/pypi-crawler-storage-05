#
# Auto generated from POM project version.
# Please do not modify.
#
__version__="8.0.1"
__java_version__="8.0.1"
__scala_version__="2.12"
__delta_version__="3.3.2"
__hadoop_version__="3.3.4"
