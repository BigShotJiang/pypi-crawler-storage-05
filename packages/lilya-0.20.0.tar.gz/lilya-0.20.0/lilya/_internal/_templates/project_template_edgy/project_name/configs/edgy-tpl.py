from edgy import EdgySettings


class EdgyAppSettings(EdgySettings): ...
