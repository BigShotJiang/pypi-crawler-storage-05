#python
"""
Custom exceptions for the Okta client.
"""

class SAMLAssertionError(RuntimeError):
	pass