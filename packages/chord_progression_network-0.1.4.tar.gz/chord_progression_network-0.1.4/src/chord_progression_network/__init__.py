# The root of the entire project
from chord_progression_network.chord_progression_network import Generator

__version__ = "0.1.4"