from . import res_currency_rate_provider_BOI
