from __future__ import annotations

from .iam_provider import ElastiCacheIAMProvider

__all__ = ["ElastiCacheIAMProvider"]
