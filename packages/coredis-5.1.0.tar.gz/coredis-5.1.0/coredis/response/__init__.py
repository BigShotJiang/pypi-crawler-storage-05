"""
coredis.response
----------------
Types & callbacks to handle redis responses
"""
