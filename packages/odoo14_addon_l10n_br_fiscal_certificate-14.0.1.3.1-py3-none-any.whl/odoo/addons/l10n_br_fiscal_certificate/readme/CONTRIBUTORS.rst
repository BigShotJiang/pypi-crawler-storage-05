* `Akretion <https://www.akretion.com/pt-BR>`_:

  * Renato Lima <renato.lima@akretion.com.br>
  * Raphaël Valyi <raphael.valyi@akretion.com.br>

* `KMEE <https://www.kmee.com.br>`_:

  * Luis Felipe Mileo <mileo@kmee.com.br>
