from wnet import Distribution as Spectrum
from wnet import Distribution_1D as Spectrum_1D

