#! /usr/bin/env python
# -*- coding: utf-8 -*-

from .aligner import WNetAligner

def py_hello():
    print("Hello, World from WNetAlign (Python)!")