SELECT id
     , id + 1 AS incremented_id
FROM ${table_name}