---
hide:
    - footer
---
# {{ page.title }}

[TAGS]
