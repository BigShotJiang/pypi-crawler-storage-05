from judgeval.data.judgment_types import Tool as JudgmentTool


class Tool(JudgmentTool):
    pass
