## init
from llama_index.tools.graphql.base import (
    GraphQLToolSpec,
)

__all__ = ["GraphQLToolSpec"]
