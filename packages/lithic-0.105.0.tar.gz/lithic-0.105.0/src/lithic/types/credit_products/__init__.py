# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .extended_credit import ExtendedCredit as ExtendedCredit
from .prime_rate_create_params import PrimeRateCreateParams as PrimeRateCreateParams
from .prime_rate_retrieve_params import PrimeRateRetrieveParams as PrimeRateRetrieveParams
from .prime_rate_retrieve_response import PrimeRateRetrieveResponse as PrimeRateRetrieveResponse
