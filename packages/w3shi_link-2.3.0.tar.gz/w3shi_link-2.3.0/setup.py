from setuptools import setup

setup(
    name='w3shi_link',
    version='2.3.0',
    description='Dummy package for testing PyPI version',
    author='w3shi',
    packages=[],
)
