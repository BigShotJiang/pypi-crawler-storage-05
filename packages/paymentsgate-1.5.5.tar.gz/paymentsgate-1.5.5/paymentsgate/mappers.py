# def QuoteResponseMapper(self, request: , response: Response):
#     logging.debug(f"HTTP Request: {request}")
#     logging.debug(f"HTTP Response: {response}")
