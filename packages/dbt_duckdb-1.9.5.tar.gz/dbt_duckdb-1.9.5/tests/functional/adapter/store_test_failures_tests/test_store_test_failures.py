from dbt.tests.adapter.store_test_failures_tests.test_store_test_failures import (
    TestStoreTestFailures,
)


class DuckDBTestStoreTestFailures(TestStoreTestFailures):
    pass
