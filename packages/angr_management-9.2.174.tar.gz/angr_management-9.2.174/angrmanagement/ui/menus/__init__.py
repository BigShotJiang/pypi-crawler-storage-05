from __future__ import annotations

from .menu import Menu

__all__ = ("Menu",)
