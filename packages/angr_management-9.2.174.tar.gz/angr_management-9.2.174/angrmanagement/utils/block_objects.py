from __future__ import annotations


class FunctionHeader:
    __slots__ = (
        "name",
        "demangled_name",
        "prototype",
        "args",
    )

    def __init__(self, name: str, demangled_name: str | None, prototype=None, args=None) -> None:
        self.name = name
        self.demangled_name = demangled_name
        self.prototype = prototype
        self.args = args


class Variables:
    __slots__ = ["variables"]

    def __init__(self, variables) -> None:
        self.variables = variables


class PhiVariable(Variables):
    __slots__ = ["variable"]

    def __init__(self, variable, variables) -> None:
        super().__init__(variables)
        self.variable = variable


class Label:
    __slots__ = ["addr", "text"]

    def __init__(self, addr: int, text: str) -> None:
        self.addr = addr
        self.text = text
