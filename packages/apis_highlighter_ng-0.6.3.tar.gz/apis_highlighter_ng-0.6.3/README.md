# apis-highlighter-ng 

Highlighter APP for [APIS](https://github.com/acdh-oeaw/apis-core-rdf/) instances.
