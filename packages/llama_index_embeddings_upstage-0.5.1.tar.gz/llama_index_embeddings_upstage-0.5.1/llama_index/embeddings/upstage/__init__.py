from llama_index.embeddings.upstage.base import UpstageEmbedding


__all__ = ["UpstageEmbedding"]
