"""
File Manager REST API endpoints
"""

from .fileman import on_filemanager, on_file
from .upload import *
