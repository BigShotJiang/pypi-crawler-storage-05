from setuptools import setup, find_packages

# Attempt to read long_description from README.md if available
try:
    with open('README.md', 'r', encoding='utf-8') as f:
        long_description = f.read()
        long_description_content_type = 'text/markdown'
except FileNotFoundError:
    long_description = ''
    long_description_content_type = 'text/plain'

setup(
    name='pip_name_generator',
    version='2025.9.101132',
    author='Eugene Evstafev',
    author_email='hi@eugene.plus',
    description='pip_name_generator: minimal package with a single public function to generate setup.py content.',
    long_description=long_description,
    long_description_content_type=long_description_content_type,
    url='https://github.com/chigwell/pip_name_generator',
    packages=find_packages(),
    install_requires=[],
    classifiers=[
        'License :: OSI Approved :: MIT License',
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
    license='MIT',
    tests_require=['unittest'],
    test_suite='test',
)