# fastofreader

Rychlý demonstrační balíček s Cython rozšířením.

Autor: Tomas Vicar <tomasvicar@gmail.com>

## Instalace (vývoj)
```bash
pip install -e .
