from llama_index.readers.dashscope.base import DashScopeParse, ResultType

__all__ = ["DashScopeParse", "ResultType"]
