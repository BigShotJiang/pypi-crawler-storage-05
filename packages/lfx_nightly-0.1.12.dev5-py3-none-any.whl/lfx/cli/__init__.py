"""LFX CLI module for serving flows."""

from lfx.cli.commands import serve_command

__all__ = ["serve_command"]
