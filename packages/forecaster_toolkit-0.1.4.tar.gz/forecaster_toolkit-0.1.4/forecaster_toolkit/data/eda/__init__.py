from forecaster_toolkit.data.eda.bivariate_analysis import BivariateAnalysis
from forecaster_toolkit.data.eda.univariate_analysis import UnivariateAnalysis

__all__ = ["BivariateAnalysis", "UnivariateAnalysis"]
