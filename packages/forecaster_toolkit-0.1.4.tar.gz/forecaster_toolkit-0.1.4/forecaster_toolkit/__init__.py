"""Forecaster Toolkit - A Python library for time series forecasting."""

__version__ = "0.1.0"
