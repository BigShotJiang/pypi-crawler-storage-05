from .command import app

app()
