"""Test suite for tap-checkly."""

from __future__ import annotations
