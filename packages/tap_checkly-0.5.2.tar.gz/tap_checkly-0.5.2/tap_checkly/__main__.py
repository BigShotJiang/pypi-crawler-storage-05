"""Tap executable."""

from __future__ import annotations

from tap_checkly.tap import TapCheckly

TapCheckly.cli()
