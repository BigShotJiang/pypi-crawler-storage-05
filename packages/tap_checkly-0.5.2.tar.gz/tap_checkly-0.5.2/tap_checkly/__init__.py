"""Python package for the tap-checkly CLI."""

from __future__ import annotations
