from enum import Enum, auto


class ConnectionRole(Enum):
    SERVER = auto()
    CLIENT = auto()
