Essa biblioteca é desenvolvida e atualizada pelo time **CSC-CIA** da **Stone**

Utilizada no desenvolvimento dos RPAs, possui classes que são utilizadas com frequência

O intuito é não precisar desenvolver, novamente, funcionalidades que são utilizadas com frequência

Documentação mais detalhada: [GitHub com acesso restrito](https://github.com/stone-payments/cia-libs)
Contato: **cia@stone.com.br**