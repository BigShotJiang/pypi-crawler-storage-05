# CueSubmit

The OpenCue job submission GUI.

This is a Python-based QT app through which you can submit jobs to an OpenCue
deployment. It can run as a standalone application, or as a plugin in
applications that support PySide/qtpy integration, such as Autodesk's Maya or
the Foundry's Nuke.
