"""
Insurance domain knowledge.
"""

from .actuarial_knowledge import ActuarialDomainKnowledge

__all__ = ['ActuarialDomainKnowledge']