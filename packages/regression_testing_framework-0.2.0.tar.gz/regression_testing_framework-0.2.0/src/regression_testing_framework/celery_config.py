broker_url = "redis://localhost:6379/0"
result_backend = "db+sqlite:///results.db"
task_serializer = "json"
accept_content = ["json"]
timezone = "UTC"

