"""
API modules for the web interface.
"""