from django.apps import AppConfig


class NewsConfig(AppConfig):
    """
    App config for news app
    """

    name = "giant_news"
