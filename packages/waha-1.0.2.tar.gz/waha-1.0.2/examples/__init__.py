"""
Examples for WAHA

This package contains example scripts demonstrating various
features of WAHA.
"""
