"""Files package.

See https://github.com/BLSQ/openhexa/wiki/Writing-OpenHEXA-pipelines#using-file-parameters
"""

from .file import File

__all__ = ["File"]
