# SPDX-FileCopyrightText: 2021-2024 MTS PJSC
# SPDX-License-Identifier: Apache-2.0
from onetl.connection.file_connection.mixins.rename_dir_mixin import RenameDirMixin
