# SPDX-FileCopyrightText: 2021-2024 MTS PJSC
# SPDX-License-Identifier: Apache-2.0
from onetl.connection.db_connection.db_connection.connection import DBConnection
from onetl.connection.db_connection.db_connection.dialect import DBDialect
