# SPDX-FileCopyrightText: 2021-2024 MTS PJSC
# SPDX-License-Identifier: Apache-2.0
from onetl.connection.db_connection.mssql.connection import MSSQL, MSSQLExtra
from onetl.connection.db_connection.mssql.dialect import MSSQLDialect
