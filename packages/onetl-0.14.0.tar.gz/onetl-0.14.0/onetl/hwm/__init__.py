# SPDX-FileCopyrightText: 2021-2024 MTS PJSC
# SPDX-License-Identifier: Apache-2.0
from onetl.hwm.auto_hwm import AutoDetectHWM
from onetl.hwm.window import Edge, Window
