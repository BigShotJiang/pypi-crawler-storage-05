"""
Visualization functions based on matplotlib.
"""

from ._waterfall import waterfall

__all__ = ["waterfall"]
