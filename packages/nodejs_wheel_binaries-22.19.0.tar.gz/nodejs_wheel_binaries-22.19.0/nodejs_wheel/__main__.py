from __future__ import annotations

from .executable import _node_entry_point

if __name__ == "__main__":
    _node_entry_point()
