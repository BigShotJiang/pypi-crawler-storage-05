"""Wrapper module for the wrapper functions used in multiprocessing."""
