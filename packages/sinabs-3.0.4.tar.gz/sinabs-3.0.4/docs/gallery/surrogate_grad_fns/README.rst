Surrogate gradient functions
----------------------------