utils
=====

.. automodule:: sinabs.backend.dynapcnn.utils
    :members:
