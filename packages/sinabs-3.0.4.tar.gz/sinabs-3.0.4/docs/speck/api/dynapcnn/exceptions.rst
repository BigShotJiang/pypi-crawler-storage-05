exceptions
==========

.. autoclass:: sinabs.backend.dynapcnn.exceptions.MissingLayer
    :members:
    :undoc-members:
    
.. autoclass:: sinabs.backend.dynapcnn.exceptions.UnexpectedLayer
    :members:
    :undoc-members:

