dynapcnn_layer
==============


This module defines the ``DynapcnnLayer`` class that is used to reproduce the behavior of a layer on the dynapcnn chip.

.. automodule:: sinabs.backend.dynapcnn.dynapcnn_layer
    :members:
