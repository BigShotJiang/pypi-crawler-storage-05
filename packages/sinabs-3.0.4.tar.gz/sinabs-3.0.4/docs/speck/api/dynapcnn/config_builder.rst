config_builder
==============

.. autoclass:: sinabs.backend.dynapcnn.config_builder.ConfigBuilder
    :members:
    :undoc-members:
