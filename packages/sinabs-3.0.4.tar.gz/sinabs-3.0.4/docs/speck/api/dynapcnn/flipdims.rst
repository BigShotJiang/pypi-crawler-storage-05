flipdims
========

.. autoclass:: sinabs.backend.dynapcnn.flipdims.FlipDims
    :members:
    :undoc-members:
