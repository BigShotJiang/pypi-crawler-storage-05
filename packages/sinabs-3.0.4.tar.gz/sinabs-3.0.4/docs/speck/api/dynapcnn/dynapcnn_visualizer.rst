dynapcnn_visualizer
===================


DynapcnnVisualizer is a GUI module for testing and visualizing results of on-chip models in real-time and real-life conditions.

.. automodule:: sinabs.backend.dynapcnn.dynapcnn_visualizer
    :members:
    :undoc-members: