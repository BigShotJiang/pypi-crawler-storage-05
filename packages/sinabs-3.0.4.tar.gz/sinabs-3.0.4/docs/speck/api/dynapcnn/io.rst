io
==


This module contains methods to handle `samna` devices, IO and other convenience methods.

.. automodule:: sinabs.backend.dynapcnn.io
    :members:
