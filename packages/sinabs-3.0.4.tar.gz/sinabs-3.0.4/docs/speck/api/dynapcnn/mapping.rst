mapping
=======


This module contains methods to map a given network to the chip.

.. automodule:: sinabs.backend.dynapcnn.mapping
    :members:
