discretize
==========

This module defines methods for discretizing convoluitional torch layers and SINABS spiking layers.

.. automodule:: sinabs.backend.dynapcnn.discretize
    :members:
