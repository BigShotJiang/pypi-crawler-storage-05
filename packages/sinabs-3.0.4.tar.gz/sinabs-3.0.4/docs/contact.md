# **CONTACT US**

Are you using Sinabs to train your networks? Do you have access to SynSense hardware and need help figuring something out? Found a bug? It's normally easiest to reach SynSense developers on the [SynSense Discord](https://discord.gg/V6FHBZURkg) server. There we have dedicated channels regarding Sinabs and our hardware. 

If you don't have Discord, you can also start a discussion on [Github](https://github.com/synsense/sinabs/discussions)!