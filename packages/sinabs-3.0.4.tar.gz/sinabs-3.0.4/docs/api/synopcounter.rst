SynOpCounter
============

.. currentmodule:: sinabs.synopcounter

SNNAnalyzer
~~~~~~~~~~~~~~~

.. autoclass:: SNNAnalyzer
    :members:


SynOpCounter
~~~~~~~~~~~~

.. autoclass:: SynOpCounter
    :members:
