**API REFERENCE**
-----------------

.. toctree::
   network
   layers
   activation
   from_torch
   hooks
   synopcounter
   utils
   nir
   ../speck/api/dynapcnn/dynapcnn
