network
=======

.. autoclass:: sinabs.Network
    :members:



