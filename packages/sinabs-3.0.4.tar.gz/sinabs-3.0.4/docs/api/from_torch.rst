from_torch
==========

This module provides support for importing models into the sinabs from pytorch.


.. autofunction:: sinabs.from_torch.from_model
