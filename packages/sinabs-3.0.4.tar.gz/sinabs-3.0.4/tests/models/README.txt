This folder hosts all the model files
