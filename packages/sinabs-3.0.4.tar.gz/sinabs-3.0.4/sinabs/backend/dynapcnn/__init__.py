from .dynapcnn_network import (  # second one for compatibility purposes
    DynapcnnCompatibleNetwork,
    DynapcnnNetwork,
)
from .dynapcnn_visualizer import DynapcnnVisualizer
