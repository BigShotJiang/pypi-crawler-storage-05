# Code of Conduct

Until we have our own code of conduct, we are following NumFOCUS' Code of
Conduct:

https://numfocus.org/code-of-conduct
