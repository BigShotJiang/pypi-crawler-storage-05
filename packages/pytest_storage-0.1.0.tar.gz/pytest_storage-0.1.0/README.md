# pytest-artifacts

Pytest plugin to help store artifacts generated during test runs

