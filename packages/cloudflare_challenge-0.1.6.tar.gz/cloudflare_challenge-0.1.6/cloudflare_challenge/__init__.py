from __future__ import annotations

from .view import init_app  # noqa:

__all__ = ["init_app"]
