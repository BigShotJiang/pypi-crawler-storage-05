def test_import():
    import fastapi_router_viz as pkg
    assert hasattr(pkg, "__version__")
