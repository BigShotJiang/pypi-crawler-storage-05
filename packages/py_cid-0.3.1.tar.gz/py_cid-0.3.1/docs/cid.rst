cid package
===========

Submodules
----------

cid.cid module
--------------

.. automodule:: cid.cid
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: cid
   :members:
   :show-inheritance:
   :undoc-members:
