=======
Credits
=======

Development Lead
----------------

* Dhruv Baldawa <dhruv@dhruvb.com>

Maintainers
-----------

* Dhruv Baldawa <dhruv@dhruvb.com>
* acul71
* pacrob
* manusheel

Contributors
------------

* Filip Š
* Paul Robinson (pacrob)
* Stavros Korokithakis
* Steve Loeppky
* Volker Mische
