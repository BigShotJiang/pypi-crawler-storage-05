.. _c_exponential_moving_average_21d_close_split_adjusted_ref:

c_exponential_moving_average_21d_close_split_adjusted
=====================================================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_exponential_moving_average_21d_close_split_adjusted
   :no-index:
