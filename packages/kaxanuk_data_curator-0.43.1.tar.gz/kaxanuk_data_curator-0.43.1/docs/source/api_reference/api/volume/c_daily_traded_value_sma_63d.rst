.. _c_daily_traded_value_sma_63d_ref:

c_daily_traded_value_sma_63d
============================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_daily_traded_value_sma_63d
   :no-index:
