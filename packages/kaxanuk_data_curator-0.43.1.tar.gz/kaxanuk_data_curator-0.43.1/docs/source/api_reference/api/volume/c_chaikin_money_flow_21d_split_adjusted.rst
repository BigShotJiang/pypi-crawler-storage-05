.. _c_chaikin_money_flow_21d_split_adjusted_ref:

c_chaikin_money_flow_21d_split_adjusted
=======================================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_chaikin_money_flow_21d_split_adjusted
   :no-index:
