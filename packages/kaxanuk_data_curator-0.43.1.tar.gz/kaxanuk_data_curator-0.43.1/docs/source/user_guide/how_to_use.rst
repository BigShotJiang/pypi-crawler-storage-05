.. _How_to_use:

End User Manual
==================

These documents describe, in detail, how to operate Data Curator in various modes:

.. toctree::
   :maxdepth: 1

   zero_coder
   custom_calculator
   component_integrator
   developer_tester
