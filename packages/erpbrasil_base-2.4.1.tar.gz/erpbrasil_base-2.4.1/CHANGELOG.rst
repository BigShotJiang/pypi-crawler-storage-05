
Changelog
=========

0.0.0 (2019-06-07)
~~~~~~~~~~~~~~~~~~

* First release on PyPI.


1.2.0 (2020-07-04)
~~~~~~~~~~~~~~~~~~

* Estabilização da biblioteca


2.0.0 (2020-11-10)
~~~~~~~~~~~~~~~~~~

* Fim do suporte ao python2
* Estabilização dos testes


2.0.1 (2021-04-06)
~~~~~~~~~~~~~~~~~~

* Chave documento fiscal
