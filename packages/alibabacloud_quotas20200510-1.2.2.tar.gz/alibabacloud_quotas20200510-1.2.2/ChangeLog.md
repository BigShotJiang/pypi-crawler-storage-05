2024-08-30 Version: 1.2.1
- Update API GetQuotaApplication: update response param.
- Update API ListQuotaApplications: update response param.


2024-06-30 Version: 1.2.0
- Support API GetQuotaApplicationApproval.
- Support API RemindQuotaApplicationApproval.
- Update API GetProductQuota: update param Dimensions.
- Update API GetProductQuota: update response param.
- Update API ListAlarmHistories: add param AlarmId.
- Update API ListProductQuotaDimensions: update response param.
- Update API ListProductQuotas: update param Dimensions.
- Update API ListProductQuotas: update param KeyWord.
- Update API ListProductQuotas: update param MaxResults.
- Update API ListProductQuotas: update param NextToken.
- Update API ListProductQuotas: update param QuotaActionCode.
- Update API ListProductQuotas: update response param.


2024-01-12 Version: 1.1.4
- Generated python 2020-05-10 for quotas.

2023-12-13 Version: 1.1.3
- Generated python 2020-05-10 for quotas.

2023-11-23 Version: 1.1.2
- Generated python 2020-05-10 for quotas.

2023-09-22 Version: 1.1.1
- Generated python 2020-05-10 for quotas.

2023-09-14 Version: 1.1.0
- Generated python 2020-05-10 for quotas.

2023-01-06 Version: 1.0.5
- Quota category supported whiteListLabel.

2022-09-05 Version: 1.0.4
- Added quota template service.

2022-08-30 Version: 1.0.3
- Added thresholdType parameter to API related to quota alarm.

2021-03-30 Version: 1.0.1
- Generated python 2020-05-10 for quotas.

2020-12-30 Version: 1.0.0
- AMP Version Change.

