__all__ = ['actuator', 'base', 'datastream', 'features_of_interest', 'historical_location', 'location',
           'multi_datastream', 'observation', 'observedproperty', 'sensor', 'task', 'tasking_capability', 'thing']
