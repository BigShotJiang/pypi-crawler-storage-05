from telemoma.configs.base_config import teleop_config

teleop_config.arm_left_controller = 'oculus'
teleop_config.arm_right_controller = 'oculus'
teleop_config.base_controller = 'oculus'
teleop_config.torso_controller = 'oculus'
