from telemoma.configs.base_config import teleop_config

teleop_config.arm_left_controller = 'keyboard'
teleop_config.arm_right_controller = 'keyboard'
teleop_config.base_controller = 'keyboard'