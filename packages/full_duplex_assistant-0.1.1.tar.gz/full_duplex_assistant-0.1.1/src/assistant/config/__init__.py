import logging

from .log_config import setup_logger

setup_logger()
logger = logging.getLogger(__name__)
