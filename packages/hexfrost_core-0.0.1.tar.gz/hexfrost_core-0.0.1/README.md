# hexfrost-core

# About

This is the core library for the Hexfrost project, providing essential functionalities and tools for building and managing applications.