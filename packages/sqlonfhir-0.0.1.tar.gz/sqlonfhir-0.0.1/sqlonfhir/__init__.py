# Copyright © 2025, SAS Institute Inc., Cary, NC, USA. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

__version__ = "0.1-alpha"

from .sqlonfhir import eval as evaluate

__all__ = ["evaluate"]
