## cdf 

### Improved

- [alpha] Robustify the terminal output of `cdf purge instances`
- [alpha] The `cdf purge instances` now gives better error message if
you lack files access and want to unlink files.

## templates

No changes.