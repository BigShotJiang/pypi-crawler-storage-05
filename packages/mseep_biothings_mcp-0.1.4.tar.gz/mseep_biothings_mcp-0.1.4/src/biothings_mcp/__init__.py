def main() -> None:
    print("Hello from biothings-mcp!")
