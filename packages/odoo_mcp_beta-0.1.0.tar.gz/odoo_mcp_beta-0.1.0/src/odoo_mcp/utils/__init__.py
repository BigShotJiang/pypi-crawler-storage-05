"""
Utility functions for the Odoo MCP server
"""

from .logging import setup_logging

__all__ = ["setup_logging"]
