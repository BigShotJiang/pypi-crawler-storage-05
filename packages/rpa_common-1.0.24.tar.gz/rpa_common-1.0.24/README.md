# RPA-COMMON

## 本地开发

```
pip install -e .
```

## 生产安装

```
pip install rpa-common
```


# 虚拟环境
```
venv\Scripts\activate
```
