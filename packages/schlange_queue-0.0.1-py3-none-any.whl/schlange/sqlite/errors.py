class NoRowsError(Exception):
    pass
