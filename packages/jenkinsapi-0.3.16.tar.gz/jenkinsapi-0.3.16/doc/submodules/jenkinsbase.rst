Jenkinsbase
-----------

.. automodule:: jenkinsapi.jenkinsbase
   :members:
   :undoc-members:
   :show-inheritance:
