Fingerprint
-----------

.. automodule:: jenkinsapi.fingerprint
   :members:
   :undoc-members:
   :show-inheritance:
