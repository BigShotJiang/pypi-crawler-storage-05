Credentials and Credential
==========================

.. contents::
      :depth: 2
      :local:
      :backlinks: none
      :class: this-will-duplicate-information-and-it-is-still-useful-here

Credentials
-----------

.. automodule:: jenkinsapi.credentials
   :members:
   :undoc-members:
   :show-inheritance:

Credential
----------

.. automodule:: jenkinsapi.credential
   :members:
   :undoc-members:
   :show-inheritance:
