Result_set and result
=====================

.. contents::
      :depth: 2
      :local:
      :backlinks: none
      :class: this-will-duplicate-information-and-it-is-still-useful-here

Result
------

.. automodule:: jenkinsapi.result
   :members:
   :undoc-members:
   :show-inheritance:

Result_set
----------

.. automodule:: jenkinsapi.result_set
   :members:
   :undoc-members:
   :show-inheritance:
