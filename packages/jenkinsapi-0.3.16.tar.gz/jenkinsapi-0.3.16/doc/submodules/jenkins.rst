Jenkins
-------

.. automodule:: jenkinsapi.jenkins
   :members:
   :undoc-members:
   :show-inheritance:
