View and Views
==============

.. contents::
      :depth: 2
      :local:
      :backlinks: none
      :class: this-will-duplicate-information-and-it-is-still-useful-here

Views
-----

.. automodule:: jenkinsapi.views
   :members:
   :undoc-members:
   :show-inheritance:

View
----

.. automodule:: jenkinsapi.view
   :members:
   :undoc-members:
   :show-inheritance:
