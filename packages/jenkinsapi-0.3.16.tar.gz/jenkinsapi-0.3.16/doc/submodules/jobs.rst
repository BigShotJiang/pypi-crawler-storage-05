Jobs and job
============

.. contents::
      :depth: 2
      :local:
      :backlinks: none
      :class: this-will-duplicate-information-and-it-is-still-useful-here

Jobs
----

.. automodule:: jenkinsapi.jobs
   :members:
   :undoc-members:
   :show-inheritance:

Job
---

.. automodule:: jenkinsapi.job
   :members:
   :undoc-members:
   :show-inheritance:
