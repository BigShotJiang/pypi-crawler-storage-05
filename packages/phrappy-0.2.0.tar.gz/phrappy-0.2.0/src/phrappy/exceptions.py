class PhrappyError(Exception):
    pass


class NoPhraseTmsTokenError(PhrappyError):
    pass
