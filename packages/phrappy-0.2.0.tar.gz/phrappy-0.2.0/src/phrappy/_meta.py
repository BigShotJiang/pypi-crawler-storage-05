__version__ = "0.2.0"
homepage = "https://github.com/kuhnemann/phrappy"
