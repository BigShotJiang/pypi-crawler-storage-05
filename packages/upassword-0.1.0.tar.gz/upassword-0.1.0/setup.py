from setuptools import setup,find_packages

setup(
    name='Upassword',
    version='0.1.0',
    packages=find_packages(),
    author='ulomi',  
    description='An interesting light-weight password generator and validator',
)