# from .helikite import app  # noqa
from helikite.classes.cleaning import Cleaner  # noqa

__version__ = "1.1.3"
__appname__ = "helikite-data-processing"
__description__ = "Library to generate quicklooks and data quality checks on Helikite campaigns"
