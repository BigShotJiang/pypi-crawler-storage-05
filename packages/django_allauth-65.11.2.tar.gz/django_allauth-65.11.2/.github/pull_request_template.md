# 🛑 Stop

The project has been moved to https://codeberg.org/allauth/django-allauth.
Please submit your pull request there.
