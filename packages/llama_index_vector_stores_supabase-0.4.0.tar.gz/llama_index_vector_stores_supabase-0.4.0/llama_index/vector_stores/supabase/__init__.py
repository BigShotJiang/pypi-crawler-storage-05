from llama_index.vector_stores.supabase.base import SupabaseVectorStore

__all__ = ["SupabaseVectorStore"]
