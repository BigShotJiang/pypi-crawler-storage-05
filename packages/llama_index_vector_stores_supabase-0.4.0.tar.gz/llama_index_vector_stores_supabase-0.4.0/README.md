# LlamaIndex Vector_Stores Integration: Supabase
