(  foo  :=    5   )

any((lastNum := num) == 1 for num in [1, 2, 3])

[(lastNum := num) == 1 for num in [1, 2, 3]]

while f := x():
    pass

if f := x(): pass

f(y:=1)
f(x,  y   :=    1     )

_[_:=10]