def f():
    pass  ;  break  ;  continue  ;  return  ;  return  foo

    assert   foo   ,   bar  ;  a  +=  2  