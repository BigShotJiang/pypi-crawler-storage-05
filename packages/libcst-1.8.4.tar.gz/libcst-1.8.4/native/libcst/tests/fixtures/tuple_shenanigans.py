(1, 2)
(1, 2, 3)

# alright here we go.

()
(())
(((())), ())
( # evil >:)
  # evil >:(
) # ...
(1,)
( *  1 , *  2 ,)
*_ = (l,)
() = x
( ) = ( x,  )
(x) = (x)
( x , )  =  x
( x , *y , * z , ) = l
( x , *y , * z , ) = ( x , *y , * z , ) = ( x , *y , * z , x )
(
    x  ,  #  :)
    bar,  *
    baz
    ,
)   =\
(
    (let, *s, (  ) )  ,
    nest , them , ( * t , * u , * p , l , * e , s , )
)