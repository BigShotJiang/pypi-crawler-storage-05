_ = ""
_ = ''
_ = """"""
_ = ''''''

_ = 'a'   "string" 'that'   r"is" 'concatenated ' 

b"string "
b"and non f" rb'string'

(
    "parenthesized"
    "concatenated"
    """triple
    quoted
    """
    
)

_ = f"string"

f"string" "bonanza" f'starts' r"""here"""

_ = f"something {{**not** an expression}} {but(this._is)} {{and this isn't.}} end"

_(f"ok { expr = !r: aosidjhoi } end")

print(f"{self.ERASE_CURRENT_LINE}{self._human_seconds(elapsed_time)} {percent:.{self.pretty_precision}f}% complete, {self.estimate_completion(elapsed_time, finished, left)} estimated for {left} files to go...")

f"{"\n".join()}"

f"___{
    x
}___"

f"___{(
    x
)}___"

f'\{{\}}'
f"regexp_like(path, '.*\{file_type}$')"
f"\lfoo"

f"{_:{_:}{a}}"

f"foo {f"bar {x}"} baz"
f'some words {a+b:.3f} more words {c+d=} final words'
f"{'':*^{1:{1}}}"
f"{'':*^{1:{1:{1}}}}"
f"{f"{f"{f"{f"{f"{1+1}"}"}"}"}"}"


t'Nothing to see here, move along'
t"User {action}: {amount:.2f} {item}"
t"<p>HTML is code {too}</p>"
t"value={value!r}"
t"This wrinkles my brain {value:.{precision}f}"
_ = t"everything" + t" is {tstrings}"
