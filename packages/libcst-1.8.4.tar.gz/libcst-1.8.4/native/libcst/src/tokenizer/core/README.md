Files in this directory are a derivative of CPython's tokenizer, and are
therefore available under the PSF license.
