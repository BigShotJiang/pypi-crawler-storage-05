.. _libcst-experimental:

=================
Experimental APIs
=================

These APIs may change at any time (including in minor releases) with no notice. You 
probably shouldn't use them, but if you do, you should pin your application to an exact
release of LibCST to avoid breakages.

Reentrant Code Generation
-------------------------

.. autoclass:: libcst.metadata.ExperimentalReentrantCodegenProvider
.. autoclass:: libcst.metadata.CodegenPartial
