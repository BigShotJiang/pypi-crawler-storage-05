def test_imports():
    from deephyper.predictor import Predictor  # noqa: F401
    from deephyper.predictor import PredictorLoader  # noqa: F401
    from deephyper.predictor import PredictorFileLoader  # noqa: F401
