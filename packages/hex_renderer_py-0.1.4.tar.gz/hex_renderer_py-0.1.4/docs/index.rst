.. hex_renderer_python documentation master file, created by
   sphinx-quickstart on Wed Apr  3 14:04:59 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to hex_renderer_py's documentation!
===============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   autodoc/index
   notebooks/Palettes
   notebooks/PatternVariant
   notebooks/Grid



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
