=========
Reference
=========

.. toctree::
  :hidden:

  configuration
  fixtures/index
  functions
  markers/index
  decorators/index
  changelog

This section of the documentation provides descriptions of the individual parts provided by pytest-asyncio.
The reference section also provides a chronological list of changes for each release.
