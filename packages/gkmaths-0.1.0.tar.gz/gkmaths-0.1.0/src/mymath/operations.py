def multiply(a: int, b: int) -> int:
    """Multiply two integer numbers"""
    return a * b


def add(a: int, b: int) -> int:
    """Add two integer numbers"""
    return a + b
