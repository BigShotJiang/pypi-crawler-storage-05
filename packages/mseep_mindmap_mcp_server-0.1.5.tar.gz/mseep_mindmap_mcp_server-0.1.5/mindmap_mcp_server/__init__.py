"""MCP Server for converting Markdown to mindmaps."""

__version__ = "0.1.1"
