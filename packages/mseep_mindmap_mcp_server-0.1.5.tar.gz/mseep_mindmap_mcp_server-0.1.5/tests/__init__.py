"""Test package for mindmap-mcp-server."""
