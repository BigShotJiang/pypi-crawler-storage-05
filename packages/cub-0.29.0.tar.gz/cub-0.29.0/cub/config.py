api_url = 'https://id.lexipol.com/v1'
api_key = None
api_timeout = 15  # seconds
