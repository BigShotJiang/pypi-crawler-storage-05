#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : xx
# @Time         : 2024/11/15 09:19
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  : 

from meutils.pipe import *

# from meutils.apis
r = storage_to_cookie(
    "cookies.json"
)
