version = '1.4.1'
repo = 'https://github.com/makodevai/gpuq'
commit = 'f3cdbca78c72fec086c97052ad2694c785ffab3b (+2 untracked)'
has_repo = True
