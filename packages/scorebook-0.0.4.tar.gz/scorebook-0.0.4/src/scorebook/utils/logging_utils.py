"""Logging utilities for Scorebook evaluation framework."""
