from django.apps import AppConfig

class SandwichTagConfig(AppConfig):
    name = 'sandwich_tag'