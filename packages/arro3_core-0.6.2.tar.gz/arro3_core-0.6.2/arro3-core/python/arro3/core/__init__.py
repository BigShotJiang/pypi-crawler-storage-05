from ._core import *
from ._core import ___version

__version__: str = ___version()
