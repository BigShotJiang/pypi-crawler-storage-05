from __future__ import annotations

from .greedy import Greedy

__all__ = [
    "Greedy",
]
