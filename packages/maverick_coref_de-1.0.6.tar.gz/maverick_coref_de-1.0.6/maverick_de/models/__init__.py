from maverick_de.models import *
