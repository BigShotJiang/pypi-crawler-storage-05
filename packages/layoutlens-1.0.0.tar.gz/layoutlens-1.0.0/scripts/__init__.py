"""Scripts and utilities for LayoutLens framework."""

# This package contains scripts for benchmark generation and testing