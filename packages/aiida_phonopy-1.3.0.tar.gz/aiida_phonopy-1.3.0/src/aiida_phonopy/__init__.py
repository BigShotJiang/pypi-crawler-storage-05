# -*- coding: utf-8 -*-
"""The official AiiDA plugin for Phonopy."""
__version__ = '1.3.0'
