from __future__ import annotations

__version__ = "2.6.0"  # x-releaser-pleaser-version
