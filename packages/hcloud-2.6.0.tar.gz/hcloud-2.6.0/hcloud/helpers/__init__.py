from __future__ import annotations

from .labels import LabelValidator

__all__ = ["LabelValidator"]
