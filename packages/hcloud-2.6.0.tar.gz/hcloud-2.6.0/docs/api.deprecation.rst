Deprecation Info
==================

.. autoclass:: hcloud.deprecation.domain.DeprecationInfo
    :members:
