VolumesClient
==================


.. autoclass:: hcloud.volumes.client.VolumesClient
    :members:

.. autoclass:: hcloud.volumes.client.BoundVolume
    :members:

.. autoclass:: hcloud.volumes.domain.Volume
    :members:

.. autoclass:: hcloud.volumes.domain.CreateVolumeResponse
    :members:
