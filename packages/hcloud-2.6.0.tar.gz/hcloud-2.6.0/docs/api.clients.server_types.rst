ServerTypesClient
==================

.. autoclass:: hcloud.server_types.client.ServerTypesClient
    :members:

.. autoclass:: hcloud.server_types.client.BoundServerType
    :members:

.. autoclass:: hcloud.server_types.domain.ServerType
    :members:
