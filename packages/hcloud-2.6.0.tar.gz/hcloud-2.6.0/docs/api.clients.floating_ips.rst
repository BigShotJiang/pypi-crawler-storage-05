Floating IPsClient
==================


.. autoclass:: hcloud.floating_ips.client.FloatingIPsClient
    :members:

.. autoclass:: hcloud.floating_ips.client.BoundFloatingIP
    :members:

.. autoclass:: hcloud.floating_ips.domain.FloatingIP
    :members:

.. autoclass:: hcloud.floating_ips.domain.CreateFloatingIPResponse
    :members:
