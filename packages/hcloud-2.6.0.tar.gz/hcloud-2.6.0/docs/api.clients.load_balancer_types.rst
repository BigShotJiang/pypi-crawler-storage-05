LoadBalancerTypesClient
========================


.. autoclass:: hcloud.load_balancer_types.client.LoadBalancerTypesClient
    :members:

.. autoclass:: hcloud.load_balancer_types.domain.LoadBalancerType
    :members:
