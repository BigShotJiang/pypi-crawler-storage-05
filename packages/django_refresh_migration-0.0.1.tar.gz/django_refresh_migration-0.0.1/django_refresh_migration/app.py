from django.apps import AppConfig

class DjangoRefreshMigrationConfig(AppConfig):
    name = "django_refresh_migration"
    verbose_name = "Django Refresh Migration"
