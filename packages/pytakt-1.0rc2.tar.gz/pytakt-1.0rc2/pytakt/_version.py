__version__ = '1.0rc2'
