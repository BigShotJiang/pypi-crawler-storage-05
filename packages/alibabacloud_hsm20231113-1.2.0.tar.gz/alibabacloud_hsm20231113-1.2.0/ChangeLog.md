2025-07-23 Version: 1.1.2
- Update API GetCluster: add response parameters Body.Cluster.CertManaged.
- Update API GetCluster: add response parameters Body.Cluster.ClusterMode.
- Update API GetCluster: add response parameters Body.Cluster.EntityCertExpireTime.


2024-09-24 Version: 1.1.1
- Update API GetInstance: update response param.
- Update API ListInstances: add param TenantIsolationType.


2024-09-14 Version: 1.1.0
- Support API ConfigAuditLog.
- Support API ConfigBackupRemark.
- Support API ConfigBackupTask.
- Support API ConfigClusterCertificate.
- Support API ConfigClusterName.
- Support API ConfigClusterWhitelist.
- Support API ConfigImageRemark.
- Support API ConfigInstanceIpAddress.
- Support API ConfigInstanceRemark.
- Support API ConfigInstanceWhitelist.
- Support API CopyImage.
- Support API CreateCluster.
- Support API DeleteCluster.
- Support API DescribeRegions.
- Support API EnableBackup.
- Support API ExportImage.
- Support API GetAuditLogStatus.
- Support API GetBackup.
- Support API GetCluster.
- Support API GetImage.
- Support API GetInstance.
- Support API GetJob.
- Support API InitializeAuditLog.
- Support API InitializeCluster.
- Support API JoinCluster.
- Support API LeaveCluster.
- Support API ListBackups.
- Support API ListClusters.
- Support API ListImages.
- Support API ListInstances.
- Support API MoveResourceGroup.
- Support API PauseInstance.
- Support API QuickInitInstance.
- Support API ResetBackup.
- Support API ResetInstance.
- Support API RestoreInstance.
- Support API ResumeInstance.
- Support API SwitchClusterMaster.
- Support API SyncCluster.


2024-08-21 Version: 1.0.0
- Generated python 2023-11-13 for hsm.

