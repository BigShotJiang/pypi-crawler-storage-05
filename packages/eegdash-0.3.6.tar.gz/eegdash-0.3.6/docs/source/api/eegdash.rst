eegdash package
===============

.. automodule:: eegdash
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   eegdash.features

Submodules
----------

.. toctree::
   :maxdepth: 4

   eegdash.api
   eegdash.data_config
   eegdash.data_utils
   eegdash.dataset
   eegdash.mongodb
   eegdash.preprocessing
   eegdash.utils
