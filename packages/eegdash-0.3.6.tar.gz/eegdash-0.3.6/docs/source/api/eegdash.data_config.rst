eegdash.data\_config module
===========================

.. automodule:: eegdash.data_config
   :members:
   :show-inheritance:
   :undoc-members:
