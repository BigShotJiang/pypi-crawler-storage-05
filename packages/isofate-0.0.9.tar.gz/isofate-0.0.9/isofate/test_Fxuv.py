from isofate.isofunks import Fxuv

'''
Test script for Fxuv function
'''

# condition 1: 0 < time < t_pms
