class DingTalkAccess:
    def __init__(self, access_token=None, secret=None, *args, **kwargs) -> None:
        self.access_token = access_token
        self.secret = secret
