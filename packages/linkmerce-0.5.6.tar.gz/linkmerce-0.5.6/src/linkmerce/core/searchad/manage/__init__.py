from linkmerce.core.searchad.manage.common import SearchAdManager
