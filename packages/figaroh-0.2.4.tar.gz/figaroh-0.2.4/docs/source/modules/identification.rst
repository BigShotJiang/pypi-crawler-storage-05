Identification
=============

base_identification
------------------
.. automodule:: figaroh.identification.base_identification
   :members:
   :undoc-members:
   :show-inheritance:

identification_tools
------------------
.. automodule:: figaroh.identification.identification_tools
   :members:
   :undoc-members:
   :show-inheritance:
