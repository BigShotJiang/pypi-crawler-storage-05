from .func01 import factorial

__all__ = ["factorial"]
