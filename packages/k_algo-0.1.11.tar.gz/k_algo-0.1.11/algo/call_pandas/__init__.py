from .call_pandas import call_pandas

__all__ = ["call_pandas"]
