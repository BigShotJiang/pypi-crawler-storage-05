# algo/cext/__init__.py
from .fastsum import fast_sum

__all__ = ["fast_sum"]