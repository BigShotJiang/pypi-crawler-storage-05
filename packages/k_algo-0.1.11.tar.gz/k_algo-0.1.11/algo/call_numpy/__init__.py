from .call_numpy import call_numpy

__all__ = ["call_numpy"]
