from .func02 import fib

__all__ = ["fib"]
