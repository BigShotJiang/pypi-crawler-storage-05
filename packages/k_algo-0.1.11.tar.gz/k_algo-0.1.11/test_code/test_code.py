import algo
print("5! =", algo.factorial(5))
print("Fib(10) =", algo.fib(10))
print(algo.fast_sum([1, 2, 3.5]))   # -> 6.5
algo.call_numpy([1, 2, 3.5])
algo.call_pandas()