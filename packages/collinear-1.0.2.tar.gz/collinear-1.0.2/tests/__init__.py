"""Tests for Collinear Python SDK."""
