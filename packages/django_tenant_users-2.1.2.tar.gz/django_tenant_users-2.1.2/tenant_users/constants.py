INACTIVE_USER_ERROR_MESSAGE = "Inactive user can't be used to provision a tenant."

TENANT_DELETE_ERROR_MESSAGE = (
    "calling delete on tenant instance is not supported, call delete_tenant instead"
)

TENANT_CACHE_NAME = "_tenant_cache"
