# from .registration_old import registration_widget
from .registration import RegistrationWidget