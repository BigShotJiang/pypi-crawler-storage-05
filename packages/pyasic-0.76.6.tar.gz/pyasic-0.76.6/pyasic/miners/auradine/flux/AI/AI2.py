from pyasic.miners.backends import Auradine
from pyasic.miners.device.models import AuradineAI2500


class AuradineFluxAI2500(AuradineAI2500, Auradine):
    pass
