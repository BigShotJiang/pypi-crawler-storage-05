from pyasic.miners.backends import Auradine
from pyasic.miners.device.models import AuradineAD3500


class AuradineFluxAD3500(AuradineAD3500, Auradine):
    pass
