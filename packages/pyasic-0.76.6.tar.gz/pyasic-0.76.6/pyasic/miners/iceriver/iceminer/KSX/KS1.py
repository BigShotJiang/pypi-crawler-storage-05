from pyasic.miners.backends.iceriver import IceRiver
from pyasic.miners.device.models import KS1


class IceRiverKS1(IceRiver, KS1):
    pass
