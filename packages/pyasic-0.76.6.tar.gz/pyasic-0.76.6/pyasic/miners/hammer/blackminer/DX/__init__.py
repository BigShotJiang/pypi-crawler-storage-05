from .D10 import HammerD10
