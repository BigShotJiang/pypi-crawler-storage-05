from .LV07 import LuckyMinerLV07
from .LV08 import LuckyMinerLV08
