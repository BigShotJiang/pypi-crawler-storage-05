## Inter-repor / inter-project universal constants

The purpose of this sub-package is to provide portable constant libraries that can be used cross-project and cross repository