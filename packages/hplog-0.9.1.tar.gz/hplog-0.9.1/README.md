# HPLOG

## About HPLOG

HPLOG (short for High Performance Logging) enables the user to log their pydantic models in a mongo DB.

