Template
========

.. currentmodule:: pyjess


.. autoclass:: pyjess.TemplateAtom
   :special-members: __init__
   :members:

.. autoclass:: pyjess.Template
   :special-members: __init__, __getitem__, __len__
   :members:
