Molecule
========

.. currentmodule:: pyjess


.. autoclass:: pyjess.Atom
   :special-members: __init__
   :members:

.. autoclass:: pyjess.Molecule
   :special-members: __init__, __getitem__, __len__
   :members:
