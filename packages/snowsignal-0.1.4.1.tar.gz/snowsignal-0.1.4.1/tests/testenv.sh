pip install -e /snowsignal/
sleep infinity