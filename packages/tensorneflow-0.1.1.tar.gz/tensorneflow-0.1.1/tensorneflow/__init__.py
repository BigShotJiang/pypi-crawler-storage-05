"""
tensorneflow - A tensorflow utility library
"""

__version__ = "0.1.0"