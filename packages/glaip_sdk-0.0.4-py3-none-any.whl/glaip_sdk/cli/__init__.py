"""CLI package for AIP SDK.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from .main import main

__all__ = ["main"]
