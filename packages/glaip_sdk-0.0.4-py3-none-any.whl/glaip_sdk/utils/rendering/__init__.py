"""Rendering utilities package (formatting, models, steps, debug)."""
