
__all__ = (
    'MAC',
    'MACRange',
)

from genie.conf.base.utils import MAC, MACRange

