Welcome to emrpy's documentation!
==================================
**Version:** |release|

.. include:: getting-started.rst

.. toctree::
   :maxdepth: 2
   :caption: Contents

   getting-started
   basic-usage
   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
