﻿emrpy.telegrambot
=================

.. automodule:: emrpy.telegrambot


   .. rubric:: Classes

   .. autosummary::

      TelegramTradingBot
