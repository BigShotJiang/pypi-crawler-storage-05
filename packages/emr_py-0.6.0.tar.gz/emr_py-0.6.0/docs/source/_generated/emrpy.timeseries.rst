emrpy.timeseries
================

.. automodule:: emrpy.timeseries
