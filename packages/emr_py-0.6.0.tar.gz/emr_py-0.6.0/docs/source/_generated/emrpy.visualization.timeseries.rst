emrpy.visualization.timeseries
==============================

.. automodule:: emrpy.visualization.timeseries


   .. rubric:: Functions

   .. autosummary::

      plot_timeseries
