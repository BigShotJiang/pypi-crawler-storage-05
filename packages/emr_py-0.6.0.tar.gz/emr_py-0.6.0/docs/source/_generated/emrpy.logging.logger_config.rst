emrpy.logging.logger\_config
============================

.. automodule:: emrpy.logging.logger_config


   .. rubric:: Functions

   .. autosummary::

      configure
      get_logger
