﻿emrpy
=====

.. automodule:: emrpy


.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   data
   decorators
   finance
   gcp
   logging
   ml
   telegrambot
   timeseries
   trading
   visualization
