emrpy.ml.encoders
=================

.. automodule:: emrpy.ml.encoders


   .. rubric:: Functions

   .. autosummary::

      encode_cats_pandas
