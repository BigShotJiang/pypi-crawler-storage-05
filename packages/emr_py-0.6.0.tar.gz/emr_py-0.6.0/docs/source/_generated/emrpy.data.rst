﻿emrpy.data
==========

.. automodule:: emrpy.data


.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   loaders
