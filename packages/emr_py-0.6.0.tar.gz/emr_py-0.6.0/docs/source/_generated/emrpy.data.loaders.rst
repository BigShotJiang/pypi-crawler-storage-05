emrpy.data.loaders
==================

.. automodule:: emrpy.data.loaders


   .. rubric:: Functions

   .. autosummary::

      load_csv
      load_parquet
