﻿emrpy.decorators
================

.. automodule:: emrpy.decorators


   .. rubric:: Functions

   .. autosummary::

      timer
      timer_and_memory
