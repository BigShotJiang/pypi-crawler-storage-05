API Reference
=============

.. toctree::
   :maxdepth: 2
   :caption: Submodules

   _generated/emrpy.rst
   _generated/emrpy.data.rst
   _generated/emrpy.data.loaders.rst
   _generated/emrpy.decorators.rst
   _generated/emrpy.finance.rst
   _generated/emrpy.gcp.rst
   _generated/emrpy.logging.rst
   _generated/emrpy.logging.logger_config.rst
   _generated/emrpy.ml.rst
   _generated/emrpy.ml.encoders.rst
   _generated/emrpy.telegrambot.rst
   _generated/emrpy.timeseries.rst
   _generated/emrpy.trading.rst
   _generated/emrpy.visualization.rst
   _generated/emrpy.visualization.timeseries.rst
