# src/emrpy/logging/__init__.py
from .logger_config import configure, get_logger

__all__ = ["configure", "get_logger"]
