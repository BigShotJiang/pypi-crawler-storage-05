# src/emrpy/data/__init__.py
from .loaders import load_csv, load_parquet

__all__ = ["load_csv", "load_parquet"]
