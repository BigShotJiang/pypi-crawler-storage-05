# src/emrpy/ml/__init__.py
from .encoders import encode_cats_pandas

__all__ = ["encode_cats_pandas"]
