![Hackatime](https://hackatime-badge.hackclub.com/U08HC7N4JJW/koba)
![PyPI - Version](https://img.shields.io/pypi/v/koba)

# koba
Terminal Image Renderer, made in Python.
