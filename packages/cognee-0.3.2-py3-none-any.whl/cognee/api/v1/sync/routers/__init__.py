from .get_sync_router import get_sync_router

__all__ = ["get_sync_router"]
