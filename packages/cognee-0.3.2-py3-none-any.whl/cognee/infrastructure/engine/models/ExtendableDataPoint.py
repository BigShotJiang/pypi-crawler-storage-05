from .DataPoint import DataPoint


class ExtendableDataPoint(DataPoint):
    """
    Represent an extendable data point subclassing from DataPoint.
    """

    pass
