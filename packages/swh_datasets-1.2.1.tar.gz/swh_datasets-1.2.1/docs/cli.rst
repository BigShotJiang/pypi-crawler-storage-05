.. _swh-datasets-cli:

Command-line interface
======================

.. click:: swh.datasets.cli:datasets_cli_group
  :prog: swh datasets
  :show-nested:
