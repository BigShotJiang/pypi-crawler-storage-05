"""
Command-line interface for cuti.
"""

from .app import app

__all__ = ["app"]