=============
plone.memoize
=============

Documentation for the caching decorator package plone.memoize.

.. toctree::
    :maxdepth: 1

    ../plone/memoize/README
    ../plone/memoize/volatile
    ../plone/memoize/request
    ../plone/memoize/view
    ../plone/memoize/ram
    ../plone/memoize/forever
    ../plone/memoize/instance
    ../plone/memoize/compress

