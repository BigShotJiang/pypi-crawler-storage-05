"""Anthropic Model info Provider."""

from tokonomics.model_discovery.anthropic_provider.provider import AnthropicProvider


__all__ = ["AnthropicProvider"]
