from pathlib import Path

TESTS_DIR = Path(__file__).parent
