## 1.0.0b4 (2025-09-11)


### Bug fixes:

- Move phone before email in IContactInfo behavior, and add missing German translations. @davisagli [#6](https://github.com/collective/collective.contact_behaviors/issues/6)

## 1.0.0b3 (2025-09-08)


### Internal:

- Use native namespace. @ericof 

## 1.0.0b2 (2025-09-08)


### Bug fixes:

- Drop support to pkg_resources. @ericof 

## 1.0.0b1 (2025-09-08)


### Internal:

- Modernize packaging. @ericof [#4](https://github.com/collective/collective.contact_behaviors/issues/4)
