# Copyright 2022 Zurich Instruments AG
# SPDX-License-Identifier: Apache-2.0

# Backwards compatibility
from laboneq.data.experiment_results import (  # noqa: F401
    AcquiredResult,
    AcquiredResults,
)
