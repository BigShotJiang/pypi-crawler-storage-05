# E2b MCP Server

An MCP Server for the E2b API.

## 🛠️ Tool List

This is automatically generated from OpenAPI schema for the E2b API.


| Tool | Description |
|------|-------------|
| `execute_python_code` | Executes Python code in a sandbox environment and returns the formatted output |
