from .cosmic-flagger import *

__version__ = "0.1.0"
__author__ = 'Autumn Stephens'