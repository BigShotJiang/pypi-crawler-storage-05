"""
SickleScope Test Suite

This package contains all unit tests, integration tests, and test utilities
for the SickleScope genomics analysis package.
"""