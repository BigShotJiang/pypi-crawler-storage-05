# Model Server Package #
This model server package is a dependency of the Arch intelligent prompt gateway. It should not be used alone. Please refer to the [quickstart-guide](https://github.com/katanemo/arch?tab=readme-ov-file#quickstart) for more details on how to get start with Arch.
