class OutOfSupportWarning(UserWarning):
    """Custom warning to indicate that a value is out of the distribution support."""

    pass
