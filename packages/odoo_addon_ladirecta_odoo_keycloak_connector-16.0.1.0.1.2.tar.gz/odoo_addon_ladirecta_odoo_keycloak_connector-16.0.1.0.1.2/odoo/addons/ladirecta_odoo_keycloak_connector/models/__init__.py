from . import company
from . import contract_contract
from . import res_partner
