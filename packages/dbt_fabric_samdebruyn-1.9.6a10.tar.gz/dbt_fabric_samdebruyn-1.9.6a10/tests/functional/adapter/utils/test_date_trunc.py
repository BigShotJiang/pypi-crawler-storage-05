from dbt.tests.adapter.utils.test_date_trunc import BaseDateTrunc


class TestDateTruncFabric(BaseDateTrunc):
    pass
