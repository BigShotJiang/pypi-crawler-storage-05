from dbt.tests.adapter.utils.test_equals import BaseEquals


class TestEqualsFabric(BaseEquals):
    pass
