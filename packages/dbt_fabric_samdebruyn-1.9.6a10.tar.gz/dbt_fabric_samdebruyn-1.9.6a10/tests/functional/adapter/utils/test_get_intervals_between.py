from dbt.tests.adapter.utils.test_get_intervals_between import BaseGetIntervalsBetween


class TestGetIntervalsBetweenFabric(BaseGetIntervalsBetween):
    pass
