"""Exceptions."""


class OnboardException(Exception):
    """A failure occurred during the onboarding process."""
