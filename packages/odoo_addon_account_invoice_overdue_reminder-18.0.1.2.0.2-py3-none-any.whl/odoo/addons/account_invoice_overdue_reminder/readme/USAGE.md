Of course, before sending invoice reminders, you must import your bank
statements and process them, so that you are up-to-date on customer
payments.

Then, go to the menu *Invoicing \> Customers \> Overdue Invoice Remind*:
you will get the start screen where you can:

- filter the customers that you want to remind (filter by customer or by
  salesman),
- check that your bank journals are up-to-date,
- choose between the *one-by-one* and *mass* interfaces,
- customize some parameters.

Then follow the process until the end.

You can also start the invoice reminder wizard via the button *Overdue
Reminder* on an overdue invoice.
