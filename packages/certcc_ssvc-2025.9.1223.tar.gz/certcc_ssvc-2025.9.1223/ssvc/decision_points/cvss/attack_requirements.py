#!/usr/bin/env python
"""
CVSS Attack Requirements
"""
#  Copyright (c) 2023-2025 Carnegie Mellon University.
#  NO WARRANTY. THIS CARNEGIE MELLON UNIVERSITY AND SOFTWARE
#  ENGINEERING INSTITUTE MATERIAL IS FURNISHED ON AN "AS-IS" BASIS.
#  CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY KIND,
#  EITHER EXPRESSED OR IMPLIED, AS TO ANY MATTER INCLUDING, BUT
#  NOT LIMITED TO, WARRANTY OF FITNESS FOR PURPOSE OR
#  MERCHANTABILITY, EXCLUSIVITY, OR RESULTS OBTAINED FROM USE
#  OF THE MATERIAL. CARNEGIE MELLON UNIVERSITY DOES NOT MAKE
#  ANY WARRANTY OF ANY KIND WITH RESPECT TO FREEDOM FROM
#  PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.
#  Licensed under a MIT (SEI)-style license, please see LICENSE or contact
#  permission@sei.cmu.edu for full terms.
#  [DISTRIBUTION STATEMENT A] This material has been approved for
#  public release and unlimited distribution. Please see Copyright notice
#  for non-US Government use and distribution.
#  This Software includes and/or makes use of Third-Party Software each
#  subject to its own license.
#  DM24-0278

from ssvc.decision_points.base import DecisionPointValue
from ssvc.decision_points.cvss.base import CvssDecisionPoint
from ssvc.decision_points.helpers import print_versions_and_diffs

_AT_NONE = DecisionPointValue(
    name="None",
    key="N",
    definition="The successful attack does not depend on the deployment and execution conditions of the vulnerable "
    "system. The attacker can expect to be able to reach the vulnerability and execute the exploit under all or "
    "most instances of the vulnerability.",
)


_PRESENT = DecisionPointValue(
    name="Present",
    key="P",
    definition="The successful attack depends on the presence of specific deployment and execution conditions of "
    "the vulnerable system that enable the attack.",
)

ATTACK_REQUIREMENTS_1 = CvssDecisionPoint(
    name="Attack Requirements",
    key="AT",
    version="1.0.0",
    definition="This metric captures the prerequisite deployment and execution conditions or variables of the "
    "vulnerable system that enable the attack.",
    values=(
        _PRESENT,
        _AT_NONE,
    ),
)

VERSIONS = (ATTACK_REQUIREMENTS_1,)
LATEST = VERSIONS[-1]


def main():
    print_versions_and_diffs(VERSIONS)


if __name__ == "__main__":
    main()
