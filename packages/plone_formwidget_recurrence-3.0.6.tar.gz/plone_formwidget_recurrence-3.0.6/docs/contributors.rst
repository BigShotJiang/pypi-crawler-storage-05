Contributions by
----------------
Contributors, please add you name here! By doing this, you also state, that you
have signed the Plone Contributors Agreement [1][2]. Thanks!

- Lennart Regebro, regebro
- Rok Garbas, garbas
- Tom Gross, tomgross (Original Author)
- Johannes Raggam, thet
- Kai Lautaportti, dokai
- Denis Krienbühl, href
- David Erni, deiferni

To be confirmed:
- Roland Fasching <roland.fasching@gmail.com>
- Solgema <martronic@martronic.ch>
- Taito Horiuchi <taito.horiuchi@hexagonit.fi>
- Vilmos Somogyi <vsomogyi@gmail.com>
- Vincent Fretin <vincent.fretin@gmail.com>

[1] http://plone.org/foundation/contributors-agreement/contributors-agreement-explained
[2] http://plone.org/foundation/contributors-agreement/agreement.pdf/view
