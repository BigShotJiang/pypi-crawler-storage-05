from llama_index.embeddings.modelscope.base import ModelScopeEmbedding

__all__ = ["ModelScopeEmbedding"]
