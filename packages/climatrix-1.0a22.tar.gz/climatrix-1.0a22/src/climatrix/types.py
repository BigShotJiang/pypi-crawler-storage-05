Longitude = float
Latitude = float
