class InvalidBlendSQL(ValueError):
    pass


class IngredientException(ValueError):
    pass
