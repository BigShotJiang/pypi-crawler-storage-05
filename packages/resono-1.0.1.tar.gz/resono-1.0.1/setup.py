#!/usr/bin/env python3
"""
Fallback setup.py for older pip versions
Most configuration is in pyproject.toml
"""

from setuptools import setup

setup()