"""
Implementation of the BSB PlacementStrategy for cerebellar cortex reconstructions.
"""
