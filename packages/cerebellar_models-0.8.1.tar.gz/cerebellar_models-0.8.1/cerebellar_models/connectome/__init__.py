"""
Implementation of the BSB ConnectionStrategy for cerebellar cortex reconstructions.
"""
