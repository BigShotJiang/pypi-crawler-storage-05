# Generated file
# - do not overwrite
# - do not include in git
from collections import namedtuple

BuildInfo = namedtuple(
    'BuildInfo',
    ['version', 'built_at', 'sha', 'branch', 'tag'],
)

BUILD_INFO = BuildInfo(
    version='v4.22.3~f0b7f68',
    built_at='2025-09-12 06:55:31Z',
    sha='f0b7f68c1fde9f4e34416ba2c356472f6f75ab93',
    branch='HEAD',
    tag='v4.22.3',
)
