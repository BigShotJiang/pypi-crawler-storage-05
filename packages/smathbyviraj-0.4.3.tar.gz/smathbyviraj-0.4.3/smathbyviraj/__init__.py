from .smathbyvirajcode import divby, fctrl, fbnci, xnrt, euler_totient, baseconv

__version__ = '0.4.3'

def hello():
    return f'Welcome to smathbyviraj v{__version__}'
