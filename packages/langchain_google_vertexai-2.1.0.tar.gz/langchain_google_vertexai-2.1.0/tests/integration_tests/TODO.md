# Integration tests TODO

## Required
- [ ] TBD

## Optional
- [ ] Find a solution not to rely on the "REGION" env var's default value in test_vectorstores.py