"""Tests for agent adapters."""
