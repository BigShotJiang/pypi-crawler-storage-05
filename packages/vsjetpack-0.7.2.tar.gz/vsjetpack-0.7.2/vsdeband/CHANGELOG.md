# Changelog

This is a list of all the noteworthy changes made to vs-tools.

For a complete list of release tags and their corresponding changes,
see the [tags page](https://github.com/Jaded-Encoding-Thaumaturgy/vs-tools/tags).

---

## Latest

- Removed the unsupported `range` parameter passed to `FunctionUtil` in `F3kdb.deband`


## v1.2.1
...
