# vs-dehalo

Collection of dehaloing VapourSynth functions

## How to use

```py
from vsdehalo import fine_dehalo

src = ...

dehaloed = fine_dehalo(src)
```
