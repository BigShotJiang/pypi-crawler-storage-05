# Road trip _4tlantic test

Algo de información sobre algúnas rutas desde Santiago de Compostela.

## Rutas descritas:

- Santiago - Vigo
- Santiago - Lugo
- Santaigo - Ourense

## Instalación

Instalar el paquete usando `pip3`:

```python3
pip3 install hack_4_u
```
## Uso básico

### Listar todas las rutas

```python
from testing_hack4u import trip

for ciudad in viajes:
    print(ciudad)
```

### Obtener ruta por nombre de ciudad

```python
from testing_hack4u import buscar

buscar()
Ingresar ciudad buscada --> "ciudad"
```
