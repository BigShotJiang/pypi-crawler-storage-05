__version__ = '3.0.2'
commit_message = f'Fix documentation'
