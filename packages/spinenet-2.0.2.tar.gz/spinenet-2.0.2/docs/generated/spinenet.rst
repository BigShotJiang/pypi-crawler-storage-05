﻿spinenet
========

.. automodule:: spinenet

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      download_example_scan
      download_weights
   
   

   
   
   

   
   
   



