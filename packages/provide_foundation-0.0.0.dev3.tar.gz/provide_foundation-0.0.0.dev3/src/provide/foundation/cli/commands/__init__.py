"""Foundation CLI commands."""

# This module provides CLI commands for foundation utilities
