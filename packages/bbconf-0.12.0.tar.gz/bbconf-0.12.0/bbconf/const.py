PKG_NAME = "bbconf"


DRS_ACCESS_URL = "{server_url}/objects/{object_id}/access/{access_id}"
ZARR_TOKENIZED_FOLDER = "tokenized.zarr"

LICENSES_CSV_URL = "https://raw.githubusercontent.com/EBISPOT/DUO/master/duo.csv"
DEFAULT_LICENSE = "DUO:0000042"
