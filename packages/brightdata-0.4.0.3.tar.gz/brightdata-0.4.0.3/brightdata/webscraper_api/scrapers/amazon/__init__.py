# brightdata/scrapers/amazon/__init__.py
from .scraper import AmazonScraper   # ← adjust the filename if needed

__all__ = ["AmazonScraper"]
