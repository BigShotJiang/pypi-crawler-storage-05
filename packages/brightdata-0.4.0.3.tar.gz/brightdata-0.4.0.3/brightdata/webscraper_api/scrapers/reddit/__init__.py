# brightdata/scrapers/reddit/__init__.py
from .scraper import RedditScraper   # ← adjust the filename if needed

__all__ = ["RedditScraper"]
