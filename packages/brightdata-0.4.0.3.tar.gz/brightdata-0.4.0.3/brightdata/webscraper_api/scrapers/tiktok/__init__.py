# brightdata/scrapers/tiktok/__init__.py
from .scraper import TikTokScraper   # ← adjust the filename if needed

__all__ = ["TikTokScraper"]
