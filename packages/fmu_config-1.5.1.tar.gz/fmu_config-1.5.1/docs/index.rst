Welcome to fmu-config's documentation!
======================================


.. toctree::
   :maxdepth: 2

   installation
   yamlformat
   usage
   examples
   contributing



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
