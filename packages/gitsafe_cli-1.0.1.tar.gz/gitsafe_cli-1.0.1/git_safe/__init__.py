"""
git-safe: Effortless file encryption for your git repos—pattern-matched, secure, and keyfile-flexible.
"""

__version__ = "1.0.1"
