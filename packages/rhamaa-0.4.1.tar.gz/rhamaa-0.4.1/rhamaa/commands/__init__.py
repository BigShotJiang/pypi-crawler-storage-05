# Commands are now organized under cms namespace
# Import from rhamaa.commands.cms instead