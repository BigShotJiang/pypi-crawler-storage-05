#!/usr/bin/env python3
"""OCI Policy info commands"""
from .info import add_arguments, main
from . import search 