from .core import get_history


def plot_price(ticker:str,start:str,end:str):
    pass