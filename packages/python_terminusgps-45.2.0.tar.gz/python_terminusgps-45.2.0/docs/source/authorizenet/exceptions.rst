Exceptions
==========

.. autoexception:: terminusgps.authorizenet.controllers.AuthorizenetControllerExecutionError
