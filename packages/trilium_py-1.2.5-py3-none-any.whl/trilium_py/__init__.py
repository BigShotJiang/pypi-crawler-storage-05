"""An unofficial Python wrapper for the ETAPI of trilium
.. moduleauthor:: Nriver
"""

from .version import __version__


def main():
    pass
