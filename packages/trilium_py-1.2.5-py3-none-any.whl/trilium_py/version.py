"""Version information for trilium-py package.
This module contains a single variable, __version__, which is the version of the package.
This allows for a single source of truth for the package version.
"""

__version__ = '1.2.5'
