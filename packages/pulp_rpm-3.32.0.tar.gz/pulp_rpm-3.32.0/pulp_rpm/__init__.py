default_app_config = "pulp_rpm.app.PulpRpmPluginAppConfig"
