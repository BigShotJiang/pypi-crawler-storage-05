Sprouter License (Custom)

Copyright © 2025 Christopher Hirschauer

Permission is granted to any person obtaining a copy of this software (“the Software”) to use, run, and modify the Software for personal or internal purposes, subject to the following conditions:

Attribution
All copies or substantial portions of the Software must retain this copyright notice.

Non-Commercial Use
The Software may not be sold, sublicensed, or redistributed for commercial purposes without the express written consent of the copyright holder.

Derivative Works
You may modify the Software for your own use, but you may not publicly distribute modified versions without permission.

Ownership
All rights not expressly granted herein are reserved by the copyright holder. Use of the Software does not transfer ownership.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THE SOFTWARE.
