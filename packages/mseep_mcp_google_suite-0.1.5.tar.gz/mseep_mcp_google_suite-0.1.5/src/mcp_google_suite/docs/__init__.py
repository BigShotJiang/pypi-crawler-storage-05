"""Google Docs operations module."""

from mcp_google_suite.docs.service import DocsService


__all__ = ["DocsService"]
