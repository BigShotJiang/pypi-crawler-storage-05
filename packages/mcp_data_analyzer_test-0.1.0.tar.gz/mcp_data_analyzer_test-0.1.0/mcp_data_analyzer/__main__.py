from .core import serve

if __name__ == "__main__":
    import asyncio
    asyncio.run(serve())