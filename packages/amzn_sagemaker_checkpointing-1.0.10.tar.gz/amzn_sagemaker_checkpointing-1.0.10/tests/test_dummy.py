from amzn_sagemaker_checkpointing import __version__


def test_import():
    assert __version__ == "1.0"
