# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableSequence

import proto  # type: ignore

from google.ads.googleads.v19.enums.types import (
    targeting_dimension as gage_targeting_dimension,
)


__protobuf__ = proto.module(
    package="google.ads.googleads.v19.common",
    marshal="google.ads.googleads.v19",
    manifest={
        "TargetingSetting",
        "TargetRestriction",
        "TargetRestrictionOperation",
    },
)


class TargetingSetting(proto.Message):
    r"""Settings for the targeting-related features, at the campaign
    and ad group levels. For more details about the targeting
    setting, visit
    https://support.google.com/google-ads/answer/7365594

    Attributes:
        target_restrictions (MutableSequence[google.ads.googleads.v19.common.types.TargetRestriction]):
            The per-targeting-dimension setting to
            restrict the reach of your campaign or ad group.
        target_restriction_operations (MutableSequence[google.ads.googleads.v19.common.types.TargetRestrictionOperation]):
            The list of operations changing the target
            restrictions.
            Adding a target restriction with a targeting
            dimension that already exists causes the
            existing target restriction to be replaced with
            the new value.
    """

    target_restrictions: MutableSequence["TargetRestriction"] = (
        proto.RepeatedField(
            proto.MESSAGE,
            number=1,
            message="TargetRestriction",
        )
    )
    target_restriction_operations: MutableSequence[
        "TargetRestrictionOperation"
    ] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message="TargetRestrictionOperation",
    )


class TargetRestriction(proto.Message):
    r"""The list of per-targeting-dimension targeting settings.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        targeting_dimension (google.ads.googleads.v19.enums.types.TargetingDimensionEnum.TargetingDimension):
            The targeting dimension that these settings
            apply to.
        bid_only (bool):
            Indicates whether to restrict your ads to show only for the
            criteria you have selected for this targeting_dimension, or
            to target all values for this targeting_dimension and show
            ads based on your targeting in other TargetingDimensions. A
            value of ``true`` means that these criteria will only apply
            bid modifiers, and not affect targeting. A value of
            ``false`` means that these criteria will restrict targeting
            as well as applying bid modifiers.

            This field is a member of `oneof`_ ``_bid_only``.
    """

    targeting_dimension: (
        gage_targeting_dimension.TargetingDimensionEnum.TargetingDimension
    ) = proto.Field(
        proto.ENUM,
        number=1,
        enum=gage_targeting_dimension.TargetingDimensionEnum.TargetingDimension,
    )
    bid_only: bool = proto.Field(
        proto.BOOL,
        number=3,
        optional=True,
    )


class TargetRestrictionOperation(proto.Message):
    r"""Operation to be performed on a target restriction list in a
    mutate.

    Attributes:
        operator (google.ads.googleads.v19.common.types.TargetRestrictionOperation.Operator):
            Type of list operation to perform.
        value (google.ads.googleads.v19.common.types.TargetRestriction):
            The target restriction being added to or
            removed from the list.
    """

    class Operator(proto.Enum):
        r"""The operator.

        Values:
            UNSPECIFIED (0):
                Unspecified.
            UNKNOWN (1):
                Used for return value only. Represents value
                unknown in this version.
            ADD (2):
                Add the restriction to the existing
                restrictions.
            REMOVE (3):
                Remove the restriction from the existing
                restrictions.
        """

        UNSPECIFIED = 0
        UNKNOWN = 1
        ADD = 2
        REMOVE = 3

    operator: Operator = proto.Field(
        proto.ENUM,
        number=1,
        enum=Operator,
    )
    value: "TargetRestriction" = proto.Field(
        proto.MESSAGE,
        number=2,
        message="TargetRestriction",
    )


__all__ = tuple(sorted(__protobuf__.manifest))
