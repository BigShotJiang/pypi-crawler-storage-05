__all__ = [
    "__version__",
]

# Simple version marker; consider syncing with pyproject.toml if published
__version__ = "0.1.2"
