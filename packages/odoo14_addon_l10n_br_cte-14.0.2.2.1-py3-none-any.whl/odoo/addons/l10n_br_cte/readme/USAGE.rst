**Passo a Passo:**

1. **Criar uma Fatura:**
   - Defina o tipo de documento como **57 (CTe - Conhecimento de Transporte)**.

2. **Configurar o Parceiro da Fatura:**
   - Configure o parceiro responsável pelo pagamento do CTe e os parceiros como Rementente, Expedidor, Destinatário e Recebedor.

3. **Adicionar uma Linha na Aba Produtos:**
   - Adicione uma linha de fatura e selecione o produto Frete ou outro que esteja previamente configurado.

4. **Acesse os detalhes fiscais da fatura e informe os demais dados necessário para emissão do CT-e:**
   - Preencha os campos obrigatórios para emissão do CT-e.

5. **Valide o CT-e, verifique os dados do XML e envie para a SEFAZ:**
   - Após preencher todos os dados necessários, valide o CT-e e envie para a SEFAZ.
