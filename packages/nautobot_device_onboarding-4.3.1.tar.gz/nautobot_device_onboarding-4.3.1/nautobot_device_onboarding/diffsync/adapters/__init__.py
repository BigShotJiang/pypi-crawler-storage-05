"""Adapter classes for loading DiffSyncModels with data from a Network or Nautobot."""
