import enum
class ProcTypes(str, enum.Enum):
    qDrive = "qDrive"
    etiket_client = "etiket_client"
    dataQruiser = "dataQruiser"