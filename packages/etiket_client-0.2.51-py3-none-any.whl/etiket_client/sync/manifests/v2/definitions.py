QH_MANIFEST_FILE = '.QH_manifest.yaml'
QH_DATASET_INFO_FILE = '_QH_dataset_info.yaml'