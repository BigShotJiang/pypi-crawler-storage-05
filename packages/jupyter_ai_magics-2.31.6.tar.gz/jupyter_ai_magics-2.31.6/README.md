# @jupyter-ai/magics

This is a Python library `jupyter_ai_magics` that exposes the model providers
and defines the IPython magics.
