#!/usr/bin/env bash

set -e

# run pytest tests
pytest tests/unit