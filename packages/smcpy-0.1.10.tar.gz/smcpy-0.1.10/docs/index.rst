Welcome to SMCPy's documentation!
=================================
.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   example
   source_code

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
