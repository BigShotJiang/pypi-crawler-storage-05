# Copyright © 2025 Frederik “Freso” S. Olesen <https://freso.dk/>
# SPDX-License-Identifier: AGPL-3.0-or-later
"""blocklister."""
