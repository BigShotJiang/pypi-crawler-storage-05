"""
List of internal known words.
The words can be in lower case and will cover uppercase as well.
"""

KNOWN_WORDS = [
    "Demisto",
    "DbotScore",
    "Phishing",
    "playbook",
    "firewalls",
    "IOCs",
    "Emails",
    "Google",
    "uploads",
    "downloads",
    "timezone",
    "url",
    "xml",
    "isfetch",
    "entryid",
    "json",
    "upload",
    "download",
    "incidentid",
    "incidenttype",
    "Cortex",
    "XSOAR",
    "integrations",
]
