module.exports =  {
  "default": true,
  "whitespace" : false,
  "single-trailing-newline" : false,
  "no-trailing-punctuation" : false,
  "first-line-h1" : false,
  "heading-increment" : false,
  "line_length" : false,
  "no-duplicate-heading" : false,
  "ol-prefix" : false
}
