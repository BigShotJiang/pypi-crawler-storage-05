# __init__.py

from .mathbyaarushlohit import eigenkvalues, answereigenkvalues, credits

__all__ = ["eigenkvalues", "answereigenkvalues", "credits"]
