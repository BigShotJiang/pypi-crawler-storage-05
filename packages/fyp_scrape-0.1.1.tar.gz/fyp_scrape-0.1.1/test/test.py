from fyp_scrape import run_scraper

run_scraper()
