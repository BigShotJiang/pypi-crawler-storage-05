"""
Storage and caching systems for data persistence.

This package contains storage backends and caching mechanisms.
"""