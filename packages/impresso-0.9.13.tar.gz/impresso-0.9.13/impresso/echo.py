def echo(message: str):
    """Echo a message."""
    return f"Echo: {message}"
