.. image:: https://github.com/zopefoundation/zope.untrustedpython/actions/workflows/tests.yml/badge.svg
    :target: https://github.com/zopefoundation/zope.untrustedpython/actions/workflows/tests.yml
    :alt: CI Status
.. image:: https://readthedocs.org/projects/untrustedpython/badge/?version=latest
    :target: https://untrustedpython.readthedocs.io/en/latest/?badge=latest
    :alt: Documentation Status

Sandboxed environment for untrusted code / templates, using zope.security and
RestrictedPython
