## 12.0.1.0.0 (2019-11-18)

- \[MIG\] Migration to V12.

## 13.0.1.0.0 (2021-01-27)

- \[MIG\] Migration to V13.

## 14.0.1.0.0 (2021-01-29)

- \[MIG\] Migration to V14.

## 15.0.1.0.0 (2022-01-11)

- \[MIG\] Migration to V15.
- Define pdf watermark in company settings

## 16.0.1.0.0 (2023-03-13)

- \[MIG\] Migration to V16.

## 17.0.1.0.0 (2024-01-12)

- \[MIG\] Migration to V17.

## 18.0.1.0.0 (2025-01-06)

- \[MIG\] Migration to V18.
