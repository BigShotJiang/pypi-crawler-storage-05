This module was written to add watermarks (backgrounds) to PDF reports.
Because of the way wkhtmltopdf handles headers and footers in the
current versions, it is quite impossible to have a background for the
complete page using HTML and CSS. That is why this module inserts the
image at the PDF level.
