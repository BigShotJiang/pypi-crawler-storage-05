default_app_config = "autogfk.apps.AutoGenericForeignKeyConfig"
__version__ = "0.5.0"
__all__ = ["fields"]