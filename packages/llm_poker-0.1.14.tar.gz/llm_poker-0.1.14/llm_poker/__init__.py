# llm_poker/__init__.py
"""
Init for llm_poker package
"""

__version__ = "0.1.14"
