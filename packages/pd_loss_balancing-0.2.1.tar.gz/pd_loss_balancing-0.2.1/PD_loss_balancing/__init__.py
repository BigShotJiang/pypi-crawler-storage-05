__version__ = "0.2.1"

from .main import (
    FixedLossWeighter,
    PDLossWeighter,
    PLossWeighter,
    LinearTrajectoryTarget,
    ConstantTarget,
    RelativeTarget,
    Target,
)
