def main():
    print("Hello from qgis-mcp!")


if __name__ == "__main__":
    main()
