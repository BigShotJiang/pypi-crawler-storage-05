# MBU-rpa-core
Library for core functionalities in RPA processes
