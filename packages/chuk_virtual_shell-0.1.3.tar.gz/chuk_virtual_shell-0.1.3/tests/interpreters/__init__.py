"""
Test suite for script interpreters
"""