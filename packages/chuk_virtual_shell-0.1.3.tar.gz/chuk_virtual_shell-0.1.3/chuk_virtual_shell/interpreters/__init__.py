"""
Script interpreters for executing scripts within the virtual shell environment
"""
