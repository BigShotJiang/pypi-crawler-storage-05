# Amsatop

## What is this?

Library for building your own htop from scratch, using python.
Exclusively built for AMSA-25-26 subject at UdL.

## Check the docs

Documentation is available at [https://docs.amsa.lol](https://docs.amsa.lol/)
