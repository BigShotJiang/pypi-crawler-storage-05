# coding=utf-8
from typing import Optional

from pydantic import BaseModel, Field


#  创建应用
class SiteCreateParams(BaseModel):
    Status: str = Field(description="请求创建应用的状态，请求枚举仅接受2，6。 2：运行中 6：测试中")
    AppCategoryCode: str = Field(
        description="应用所属二级行业码，参考：https://bytedance.larkoffice.com/sheets/shtcncP14js8FCE9NK2MQo3dXPc?sheet=bpeEue&range=Mzoz")
    AppName: str = Field(description="创建应用的名称")
    PackageName: str = Field(description="创建应用对应的包名信息。 eg: package.com.test")
    DownloadURL: str = Field(description="创建应用对应的下载地址，或者对应的应用商店详情页地址")
    ApkSign: str = Field(description="创建应用对应的签名信息")


class SiteQueryParams(BaseModel):
    AppID: str = Field(description="应用ID，是否指定应用ID进行查询")
    Status: str = Field(description="应用状态 1审核中 2运行中 6测试中")


class CodeQueryParams(BaseModel):
    CodeID: Optional[int] = Field(default=0, description="代码位ID，可以指定代码位ID进行查询")
    Status: Optional[int] = Field(default=0, description="代码位状态，2表示运行中，6表示测试中")
    AppID: Optional[int] = Field(default=0, description="所属应用ID，一个应用下可以有多个代码位")
    Page: Optional[int] = Field(default=1, description="分页页码，默认1，表示第一页")
    PageSize: Optional[int] = Field(default=10, description="每页返回的数量，默认10，最大100")


class CodeCreateParams(BaseModel):
    AppID: int = Field(description="创建代码位所属的应用ID")
    AdSlotType: int = Field(
        description="代码位样式，1:信息流广告 2：banner广告 3：开屏广告 4：插屏 5：激励视频 6：全屏广告 7：draw信息流 8：贴片广告 9：新插屏广告")
    AdSlotName: str = Field(description="代码位名称")
    UseMedication: str = Field(description="创建代码位是否是聚合代码位，枚举值：0：非聚合代码位 1：聚合代码位")
    BiddingType: int = Field(description="代码位竞价方式，0：标准竞价 1：服务端竞价 2：客户端竞价")
    RenderType: int = Field(description="渲染方式，1：模版渲染 2：自渲染")
    AdRolloutSize: int = Field(description="广告投放，1：新全屏 2：新插屏 3：优选")
    Orientation: int = Field(description="屏幕方向，1：垂直 2：水平")
    SkipDuration: int = Field(description="激励视频可跳过时间")


#  查询报表
class DataAPI(BaseModel):
    date: str = Field(description="穿山甲广告数据对应的日期，格式为yyyy-mm-dd")


category = {
    "121707": "综合资讯",
    "121704": "体育资讯",
    "121709": "政府资讯",
    "121710": "门户资讯",
    "121708": "其他",
    "121602": "智能家居",
    "121601": "智能穿戴",
    "121606": "其他",
    "121501": "电子政务",
    "121502": "其他",
    "121405": "在线阅读",
    "121402": "手机动漫",
    "121406": "其他",
    "121206": "在线音乐",
    "121203": "音乐播放器",
    "121208": "有声听书",
    "121204": "音乐乐器",
    "121201": "网络K歌",
    "121205": "音乐识别",
    "121207": "其他",
    "121003": "图片美化",
    "121001": "拍照摄影",
    "121004": "相册图库",
    "121002": "图片分享",
    "121005": "其他",
    "120909": "长视频",
    "120905": "视频播放器",
    "120903": "横版短视频",
    "120911": "竖版短视频",
    "120906": "视频工具",
    "120908": "直播",
    "120910": "其他",
    "120812": "运营商服务",
    "120809": "美食菜谱",
    "120810": "求职招聘",
    "120803": "本地生活",
    "120813": "其他",
    "120703": "社区论坛",
    "120702": "即时通讯",
    "120701": "互动交友",
    "120708": "其他",
    "120604": "记账理财",
    "120612": "网赚平台",
    "120607": "现金借贷",
    "120608": "消费金融",
    "120613": "其他",
    "120603": "股票交易",
    "120609": "虚拟货币",
    "120605": "网络彩票",
    "120606": "网上银行",
    "120611": "综合理财",
    "120610": "支付结算",
    "120602": "保险服务",
    "120601": "P2P理财",
    "120505": "学前教育",
    "120508": "其他",
    "120501": "K12",
    "120504": "教育工具",
    "120503": "高等教育",
    "120506": "语言学习",
    "120502": "词典翻译",
    "120507": "职业教育",
    "120405": "运动健身",
    "120402": "健康管理",
    "120413": "其他",
    "120404": "医疗美容",
    "120403": "丽人美妆",
    "120409": "女性健康",
    "120407": "医药服务",
    "120408": "挂号问诊",
    "120305": "电商",
    "120301": "导购比价",
    "120306": "其他",
    "120303": "闲置交易",
    "120302": "微店服务",
    "121123": "清理安全",
    "121116": "WiFi",
    "121111": "天气服务",
    "121133": "其他",
    "121128": "手机铃声",
    "121102": "通讯辅助",
    "121118": "浏览器",
    "121124": "应用商店",
    "121113": "万年历",
    "121127": "壁纸桌面",
    "121122": "文件管理",
    "121119": "输入法",
    "121101": "电子邮件",
    "121106": "辅助工具",
    "121104": "电话短信",
    "121114": "星座运势",
    "120201": "地图导航",
    "120218": "其他",
    "120203": "出行工具",
    "120202": "出行服务",
    "120211": "旅行服务",
    "120212": "车主服务",
    "120104": "效率办公",
    "120106": "其他",
    "120102": "笔记文档",
    "121315": "游戏大厅",
    "121317": "硬核 - 射击",
    "121318": "硬核 - 赛车",
    "121319": "硬核 - 角色扮演",
    "121320": "硬核 - 策略"
}
