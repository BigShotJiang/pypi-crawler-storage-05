kInheritanceSourceTrait = "inheritance_source"
