# pycid-dev Package

# Setup

pip install build
pip install twine

Work in progress API for CID

edit the setup.cfg
run build.sh
run upload.sh
