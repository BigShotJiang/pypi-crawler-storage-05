export const rasaRadii = {
  none: '0',
  small: '0.25rem',
  normal: '0.5rem',
  large: '1rem',
  larger: '1.25rem',
  full: '9999px',
}
export type RasaRadii = typeof rasaRadii
