from testit_python_commons.models.link_type import LinkType

__all__ = [
    'LinkType'
]
