Usage
=====

Check the Authorizenet API documentation for expected attributes in each response.

TODO
