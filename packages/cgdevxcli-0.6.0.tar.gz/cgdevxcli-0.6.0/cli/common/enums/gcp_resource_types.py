from enum import Enum


class GcpResourceType(Enum):
    PROJECT = "project"
    BUCKET = "bucket"
