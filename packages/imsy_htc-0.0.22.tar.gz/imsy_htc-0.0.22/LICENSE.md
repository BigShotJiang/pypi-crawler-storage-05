# License

&copy; 2022 Division of Intelligent Medical Systems, DKFZ

If not stated otherwise, this work (including the source code and the accompanying material) is licensed under [MIT](LICENSES/MIT.txt).
