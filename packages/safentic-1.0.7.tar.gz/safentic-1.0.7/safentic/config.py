BASE_API_PATH = "https://safentic-api.onrender.com/"
API_KEY_ENDPOINT = "auth/validate"
