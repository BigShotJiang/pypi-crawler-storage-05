from dataclasses import dataclass


@dataclass
class GifProperties:
    name: str = "_optimizer_animation"
    length: int = 10
