This package define interfaces of container components, and provides
sample container implementations such as a BTreeContainer and
OrderedContainer.
