class DataModel:
    def __init__(self, data_type: str, data_id: int):
        self.data_type = data_type
        self.data_id = data_id
