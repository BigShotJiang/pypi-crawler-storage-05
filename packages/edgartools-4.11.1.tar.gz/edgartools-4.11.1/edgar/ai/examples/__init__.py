"""
EdgarTools AI examples.

This package contains example scripts demonstrating AI capabilities.
"""