"""MCP Prompt Tester - A server for testing LLM prompts with different providers."""

__version__ = "0.1.0" 