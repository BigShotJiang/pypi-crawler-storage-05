"""Entry point for running the package directly."""

import sys

from .server import main

sys.exit(main()) 