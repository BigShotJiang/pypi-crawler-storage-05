# =====================================
# generator=datazen
# version=3.2.3
# hash=57d97050b2a832983524d8749c66786c
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "A tool for working with scalable vector graphics."
PKG_NAME = "svgen"
VERSION = "0.8.6"
