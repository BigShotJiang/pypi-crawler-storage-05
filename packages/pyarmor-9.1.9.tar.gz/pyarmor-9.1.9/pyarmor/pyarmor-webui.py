from webui.server import main
main()
