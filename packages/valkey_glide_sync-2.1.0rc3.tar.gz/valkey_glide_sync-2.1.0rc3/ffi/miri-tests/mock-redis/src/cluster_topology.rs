// Copyright Valkey GLIDE Project Contributors - SPDX Identifier: Apache-2.0

pub fn get_slot(_key: &[u8]) -> u16 {
    0
}
