# znumbers

Zadeh ta’riflagan **Z-sonlar (Z-numbers)** uchun Python kutubxona. 
Z-number arifmetikasi (TFN bilan).  
Bu kutubxona yordamida Z-sonlar ustida qo‘shish, ayirish, ko‘paytirish va bo‘lish amallarini bajarish mumkin.
z sonlarni mana shu formatda kiritish kerak
Example
Z1 = ZNumber(TFN(2,3,4), TFN(0.7,0.8,0.9))
Z2 = ZNumber(TFN(1,2,3), TFN(0.6,0.7,0.8))