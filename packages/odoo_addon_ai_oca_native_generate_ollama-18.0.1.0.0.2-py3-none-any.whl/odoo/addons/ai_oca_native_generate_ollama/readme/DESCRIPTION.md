This module replaces the integration of AI from Odoo to ChatGPT through Odoo by a locally controlled system.
