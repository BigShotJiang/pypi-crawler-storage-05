To configure this module, you need to create 2 parameters:

- *ai_oca_native_generate_ollama.connection*: Connection to your ollama
- *ai_oca_native_generate_ollama.model*: Model to use

Alternatively, you can add headers by using the parameter *ai_oca_native_generate_ollama.headers".
It expects a dictionary.
