Without this module, Odoo is providing an AI solution that sends the data to Odoo and Odoo to ChatGPT.
There are strong concerns on this topic about Data Protection.

For this reason, we defined a module that allows to integrate with your Ollama instance.

Also, it can be an example of how to set other configurations, like a direct connection to ChatGPT or other AI providers.