# Perplexity MCP Server

An MCP Server for the Perplexity API.

## 🛠️ Tool List

This is automatically generated from OpenAPI schema for the Perplexity API.


| Tool | Description |
|------|-------------|
| `chat` | Initiates a chat completion request to generate AI responses using various models with customizable parameters. |
