from .Token import token_patterns
from .part_of_speech import get_pos, pos_patterns
