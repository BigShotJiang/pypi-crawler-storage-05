.. _servers_client:

Compute Client Usage
====================

.. automodule:: tempest.lib.services.compute.servers_client
   :members:
