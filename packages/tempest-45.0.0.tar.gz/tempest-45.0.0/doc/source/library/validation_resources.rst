.. _validation_resources:

Validation Resources
====================

-------------------------------
The validation_resources module
-------------------------------

.. automodule:: tempest.lib.common.validation_resources
   :members:
