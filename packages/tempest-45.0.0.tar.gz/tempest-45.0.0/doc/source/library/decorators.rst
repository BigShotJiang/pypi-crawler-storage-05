.. _decorators:

Decorators Usage Guide
======================

---------------------
The decorators module
---------------------

.. automodule:: tempest.lib.decorators
   :members:


