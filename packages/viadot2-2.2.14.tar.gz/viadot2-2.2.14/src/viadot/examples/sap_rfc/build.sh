# Add --build-arg NO_PROXY=$no_proxy etc. as needed
docker build --no-cache . -t viadot:sap_rfc
