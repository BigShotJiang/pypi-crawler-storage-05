"""Signals, used to control pipeline behavior."""


class SKIP(Exception):  # noqa: N818
    pass
