::: viadot.orchestration.prefect.tasks.azure_sql_to_df

::: viadot.orchestration.prefect.tasks.adls_upload

::: viadot.orchestration.prefect.tasks.bcp

::: viadot.orchestration.prefect.tasks.clone_repo

::: viadot.orchestration.prefect.tasks.bigquery_to_df

::: viadot.orchestration.prefect.tasks.business_core.business_core_to_df

::: viadot.orchestration.prefect.tasks.cloud_for_customers_to_df

::: viadot.orchestration.prefect.tasks.create_sql_server_table

::: viadot.orchestration.prefect.tasks.customer_gauge_to_df

::: viadot.orchestration.prefect.tasks.dbt_task

::: viadot.orchestration.prefect.tasks.df_to_adls

::: viadot.orchestration.prefect.tasks.df_to_databricks

::: viadot.orchestration.prefect.tasks.df_to_minio

::: viadot.orchestration.prefect.tasks.df_to_redshift_spectrum

::: viadot.orchestration.prefect.tasks.duckdb_query

::: viadot.orchestration.prefect.tasks.epicor_to_df

::: viadot.orchestration.prefect.tasks.eurostat_to_df

::: viadot.orchestration.prefect.tasks.exchange_rates_to_df

::: viadot.orchestration.prefect.tasks.genesys_to_df

::: viadot.orchestration.prefect.tasks.hubspot_to_df

::: viadot.orchestration.prefect.tasks.luma_ingest_task

::: viadot.orchestration.prefect.tasks.mediatool_to_df

::: viadot.orchestration.prefect.tasks.mindful_to_df

::: viadot.orchestration.prefect.tasks.outlook_to_df

::: viadot.orchestration.prefect.tasks.s3_upload_file

::: viadot.orchestration.prefect.tasks.salesforce_to_df

::: viadot.orchestration.prefect.tasks.sap_bw_to_df

::: viadot.orchestration.prefect.tasks.sap_rfc_to_df

::: viadot.orchestration.prefect.tasks.sftp_list

::: viadot.orchestration.prefect.tasks.sftp_to_df

::: viadot.orchestration.prefect.tasks.sharepoint_download_file

::: viadot.orchestration.prefect.tasks.sharepoint_to_df

::: viadot.orchestration.prefect.tasks.sql_server_query

::: viadot.orchestration.prefect.tasks.sql_server_to_df

::: viadot.orchestration.prefect.tasks.vid_club_to_df

::: viadot.orchestration.prefect.tasks.supermetrics_to_df
