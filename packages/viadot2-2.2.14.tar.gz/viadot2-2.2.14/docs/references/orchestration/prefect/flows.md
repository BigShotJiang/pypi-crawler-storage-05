::: viadot.orchestration.prefect.flows.azure_sql_to_adls

::: viadot.orchestration.prefect.flows.bigquery_to_adls

::: viadot.orchestration.prefect.flows.business_core_to_parquet

::: viadot.orchestration.prefect.flows.cloud_for_customers_to_adls

::: viadot.orchestration.prefect.flows.cloud_for_customers_to_databricks

::: viadot.orchestration.prefect.flows.customer_gauge_to_adls

::: viadot.orchestration.prefect.flows.duckdb_to_parquet

::: viadot.orchestration.prefect.flows.duckdb_to_sql_server

::: viadot.orchestration.prefect.flows.duckdb_transform

::: viadot.orchestration.prefect.flows.epicor_to_parquet

::: viadot.orchestration.prefect.flows.eurostat_to_adls

::: viadot.orchestration.prefect.flows.exchange_rates_to_adls

::: viadot.orchestration.prefect.flows.exchange_rates_to_databricks

::: viadot.orchestration.prefect.flows.exchange_rates_api_to_redshift_spectrum

::: viadot.orchestration.prefect.flows.genesys_to_adls

::: viadot.orchestration.prefect.flows.hubspot_to_adls

::: viadot.orchestration.prefect.flows.mediatool_to_adls

::: viadot.orchestration.prefect.flows.mindful_to_adls

::: viadot.orchestration.prefect.flows.outlook_to_adls

::: viadot.orchestration.prefect.flows.salesforce_to_adls

::: viadot.orchestration.prefect.flows.sap_bw_to_adls

::: viadot.orchestration.prefect.flows.sap_to_parquet

::: viadot.orchestration.prefect.flows.sap_to_redshift_spectrum

::: viadot.orchestration.prefect.flows.sftp_to_adls

::: viadot.orchestration.prefect.flows.sharepoint_to_adls

::: viadot.orchestration.prefect.flows.sharepoint_to_databricks

::: viadot.orchestration.prefect.flows.sharepoint_to_redshift_spectrum

::: viadot.orchestration.prefect.flows.sharepoint_to_s3

::: viadot.orchestration.prefect.flows.sql_server_to_minio

::: viadot.orchestration.prefect.flows.sql_server_to_parquet

::: viadot.orchestration.prefect.flows.sql_server_transform

::: viadot.orchestration.prefect.flows.supermetrics_to_adls

::: viadot.orchestration.prefect.flows.transform

::: viadot.orchestration.prefect.flows.transform_and_catalog

::: viadot.orchestration.prefect.flows.vid_club_to_adls
