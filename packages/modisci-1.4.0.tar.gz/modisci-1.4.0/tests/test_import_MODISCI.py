def test_import_MODISCI():
    import MODISCI
