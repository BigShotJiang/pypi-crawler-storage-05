# Simplify adding classifiers to a pyproject.toml

Usage:

```
# Add individual classifiers via autocomplete
uvx add-classifiers add
# Automatically add suggested classifiers based on pyproject content
# Currently supports requires-python and django
uvx add-classifiers suggest
```
