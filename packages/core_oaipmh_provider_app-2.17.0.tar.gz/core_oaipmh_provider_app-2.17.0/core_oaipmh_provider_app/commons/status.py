""" Status
"""

ACTIVE = "Active"
DELETED = "Deleted"
