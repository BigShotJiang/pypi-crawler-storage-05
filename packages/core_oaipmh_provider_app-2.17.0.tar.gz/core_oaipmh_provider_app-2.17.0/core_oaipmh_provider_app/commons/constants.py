""" Constants for the core_oaipmh_provider_app package
"""

MAX_INSERT_RETRIES = 100
""" :py:class:`int`: Maximum retries when inserting objects.
"""
