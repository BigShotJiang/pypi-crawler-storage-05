""" Run the Init app
"""

default_app_config = "core_oaipmh_provider_app.apps.ProviderAppConfig"
