"""
Init command modules for ThothCTL.
"""

# Import subcommands to make them available
from . import project
from . import env
from . import space
