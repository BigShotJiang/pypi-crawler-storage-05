python -m build
pip install .
twine upload dist/*