from enum import StrEnum, auto


class CQScope(StrEnum):
    TRANSACTION = auto()
