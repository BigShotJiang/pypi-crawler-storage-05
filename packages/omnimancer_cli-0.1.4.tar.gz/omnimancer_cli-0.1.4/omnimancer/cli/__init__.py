"""
CLI module for Omnimancer.

This module contains the command-line interface components including
command parsing, interactive interface, and output formatting.
"""

__all__ = []
