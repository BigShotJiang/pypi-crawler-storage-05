class OrionisIntegrityException(Exception):
    pass

class OrionisRuntimeError(RuntimeError):
    pass

class OrionisTypeError(TypeError):
    pass

class OrionisValueError(ValueError):
    pass