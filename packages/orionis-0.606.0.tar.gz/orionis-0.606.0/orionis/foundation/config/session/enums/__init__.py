from .same_site_policy import SameSitePolicy

__all__ = [
    "SameSitePolicy"
]