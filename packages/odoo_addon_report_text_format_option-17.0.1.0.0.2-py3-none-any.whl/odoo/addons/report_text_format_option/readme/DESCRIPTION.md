This is a technical module designed to add encoding fields to the
ir.actions.report model and is applied to Text type reports.
