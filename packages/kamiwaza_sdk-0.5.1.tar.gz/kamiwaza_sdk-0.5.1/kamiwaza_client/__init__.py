# kamiwaza_client/__init__.py
from .client import KamiwazaClient

__version__ = "0.5.1"