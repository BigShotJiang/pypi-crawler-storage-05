# BrimView-widgets
This python package create some [Panel](https://panel.holoviz.org/index.html) widgets which are used by [BrimView](https://github.com/prevedel-lab/BrimView).

The widgets can also be used independently by any Panel app wishinng to work with [brim files](https://github.com/prevedel-lab/brimfile). 