#!/usr/bin/env bash

echo 'Hello craft-parts!'
