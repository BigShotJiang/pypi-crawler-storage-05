
.. include:: /common/craft-parts/reference/parts_steps.rst

.. step_execution_environment:
.. include:: /common/craft-parts/reference/step_execution_environment.rst

.. include:: /common/craft-parts/reference/step_output_directories.rst

.. include:: /common/craft-parts/reference/partition_specific_output_directory_variables.rst
