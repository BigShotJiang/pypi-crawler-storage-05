.. _reference:

Reference
=========

.. toctree::
   :maxdepth: 1

   actions
   exceptions
   infos
   lifecycle_manager
   /common/craft-parts/reference/part_properties
   parts_steps
   plugins
   reference
   changelog

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
