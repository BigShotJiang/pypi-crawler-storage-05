package org.starcraft.subsubmod;

public class Speaker {
  public static String hello() {
    return "Hello!";
  }
}
