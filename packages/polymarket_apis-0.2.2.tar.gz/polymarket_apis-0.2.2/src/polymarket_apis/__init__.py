def hello() -> str:
    return "Hello from polymarket-apis!"
