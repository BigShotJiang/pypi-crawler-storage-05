#!/usr/bin/env python
# -*- coding: utf-8 -*-

from torchoutil.nn.modules._mixins import EModule  # noqa: F401
from torchoutil.nn.modules._mixins import EModule as Module  # noqa: F401
