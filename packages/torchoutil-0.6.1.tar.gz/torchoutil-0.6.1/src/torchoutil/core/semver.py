#!/usr/bin/env python
# -*- coding: utf-8 -*-

# For backward compatibility only
from torchoutil.pyoutil.semver import Version  # noqa: F401
