#!/usr/bin/env python
# -*- coding: utf-8 -*-

# backward compatibility
from torchoutil.extras.hdf import (  # noqa: F401
    pack_to_hdf,
    HDFDataset,
)
