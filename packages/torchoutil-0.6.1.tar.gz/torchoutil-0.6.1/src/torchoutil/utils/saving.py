#!/usr/bin/env python
# -*- coding: utf-8 -*-

# backward compatibility
from torchoutil.serialization import *  # noqa: F401, F403
