#!/usr/bin/env python
# -*- coding: utf-8 -*-

from torchoutil.extras.yaml import (  # noqa: F401
    IgnoreTagLoader,
    SafeLoader,
    dump_yaml,
    load_yaml,
    to_yaml,
)
