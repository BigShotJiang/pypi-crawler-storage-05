#!/usr/bin/env python
# -*- coding: utf-8 -*-

from torchoutil.extras.numpy.saving import dump_numpy, load_numpy  # noqa: F401
