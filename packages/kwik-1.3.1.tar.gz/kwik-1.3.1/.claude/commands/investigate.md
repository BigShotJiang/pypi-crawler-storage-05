Investigate if #$ARGUMENTS are indeed used in the codebase.
If they are not used, suggest removing them.
If they are weakly used, suggest refactoring, improving their usage, or to remove them.
If they are strongly used, suggest keeping them as is, and suggest improvements if applicable.
Whether they are used or not, make a plan for suggested next steps.
think