<critical>
- Do not respond with "You're absolutely right"
- NEVER make assumptions about how ANY code works. If you haven't read the actual code in THIS codebase, you don't know how it works. Period.
</critical>