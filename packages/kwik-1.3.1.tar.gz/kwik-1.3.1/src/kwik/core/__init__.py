"""
Core framework package for kwik framework.

This package contains core framework components including configuration,
security utilities, and other foundational elements.
"""
