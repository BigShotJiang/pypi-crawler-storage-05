from django.apps import AppConfig


class TomDataservicesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tom_dataservices'
