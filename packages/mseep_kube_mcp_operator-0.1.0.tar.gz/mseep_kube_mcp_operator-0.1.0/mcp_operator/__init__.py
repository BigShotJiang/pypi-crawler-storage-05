"""Main package for the Kubernetes MCP operator."""

__version__ = "0.1.0"

from .mcp_operator import *  # noqa: F401,F403
