PLUGIN_TITLE = 'Прокси-сервер альянса'
PLUGIN_NAME = 'scst_proxy'
default_app_config = f'{PLUGIN_NAME}.apps.ScStProxySettings'