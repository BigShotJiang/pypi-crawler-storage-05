"""ChunkHound API package - provides CLI and server interfaces."""

__version__ = "1.1.0"

__all__: list[str] = []
