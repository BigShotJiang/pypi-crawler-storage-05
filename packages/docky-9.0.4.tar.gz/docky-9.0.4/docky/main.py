# coding: utf-8

from .cmd.base import Docky
__version__ = Docky.VERSION

def main():
    Docky.run()
