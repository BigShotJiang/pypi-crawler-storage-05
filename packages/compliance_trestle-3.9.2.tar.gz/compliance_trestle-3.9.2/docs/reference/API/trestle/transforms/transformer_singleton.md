---
title: trestle.transforms.transformer_singleton
description: Documentation for trestle.transforms.transformer_singleton module
---

::: trestle.transforms.transformer_singleton
handler: python
