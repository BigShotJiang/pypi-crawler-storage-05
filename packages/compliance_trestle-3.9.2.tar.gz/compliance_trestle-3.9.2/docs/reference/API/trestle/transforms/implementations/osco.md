---
title: trestle.transforms.implementations.osco
description: Documentation for trestle.transforms.implementations.osco module
---

::: trestle.transforms.implementations.osco
handler: python
