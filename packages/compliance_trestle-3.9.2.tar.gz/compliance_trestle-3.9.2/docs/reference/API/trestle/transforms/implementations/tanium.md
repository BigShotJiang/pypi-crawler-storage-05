---
title: trestle.transforms.implementations.tanium
description: Documentation for trestle.transforms.implementations.tanium module
---

::: trestle.transforms.implementations.tanium
handler: python
