---
title: trestle.core.object_factory
description: Documentation for trestle.core.object_factory module
---

::: trestle.core.object_factory
handler: python
