---
title: trestle.core.commands.author.prof
description: Documentation for trestle.core.commands.author.prof module
---

::: trestle.core.commands.author.prof
handler: python
