---
title: trestle.core.jinja.filters
description: Documentation for trestle.core.jinja.filters module
---

::: trestle.core.jinja.filters
handler: python
