---
title: trestle.core.commands.author.docs
description: Documentation for trestle.core.commands.author.docs module
---

::: trestle.core.commands.author.docs
handler: python
