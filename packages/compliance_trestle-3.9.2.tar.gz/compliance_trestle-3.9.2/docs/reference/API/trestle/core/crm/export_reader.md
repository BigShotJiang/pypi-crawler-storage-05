---
title: trestle.core.crm.export_reader
description: Documentation for trestle.core.crm.export_reader module
---

::: trestle.core.crm.export_reader
handler: python
