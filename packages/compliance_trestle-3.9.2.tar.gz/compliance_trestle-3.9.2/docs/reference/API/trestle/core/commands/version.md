---
title: trestle.core.commands.version
description: Documentation for trestle.core.commands.version module
---

::: trestle.core.commands.version
handler: python
