---
title: trestle.core.commands.merge
description: Documentation for trestle.core.commands.merge module
---

::: trestle.core.commands.merge
handler: python
