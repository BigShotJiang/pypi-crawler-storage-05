---
title: trestle.core.resolver.prune
description: Documentation for trestle.core.resolver.prune module
---

::: trestle.core.resolver.prune
handler: python
