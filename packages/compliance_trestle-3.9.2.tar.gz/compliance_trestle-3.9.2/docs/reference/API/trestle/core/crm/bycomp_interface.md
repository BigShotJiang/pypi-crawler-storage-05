---
title: trestle.core.crm.bycomp_interface
description: Documentation for trestle.core.crm.bycomp_interface module
---

::: trestle.core.crm.bycomp_interface
handler: python
