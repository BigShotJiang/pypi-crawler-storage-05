---
title: trestle.core.catalog.catalog_merger
description: Documentation for trestle.core.catalog.catalog_merger module
---

::: trestle.core.catalog.catalog_merger
handler: python
