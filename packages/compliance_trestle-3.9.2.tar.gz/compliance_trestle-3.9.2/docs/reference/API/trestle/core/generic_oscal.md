---
title: trestle.core.generic_oscal
description: Documentation for trestle.core.generic_oscal module
---

::: trestle.core.generic_oscal
handler: python
