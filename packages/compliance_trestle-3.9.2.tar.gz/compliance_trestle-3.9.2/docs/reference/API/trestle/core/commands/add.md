---
title: trestle.core.commands.add
description: Documentation for trestle.core.commands.add module
---

::: trestle.core.commands.add
handler: python
