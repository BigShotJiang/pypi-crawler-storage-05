---
title: trestle.core.base_model
description: Documentation for trestle.core.base_model module
---

::: trestle.core.base_model
handler: python
