---
title: trestle.core.commands.author.consts
description: Documentation for trestle.core.commands.author.consts module
---

::: trestle.core.commands.author.consts
handler: python
