---
title: trestle.core.jinja.base
description: Documentation for trestle.core.jinja.base module
---

::: trestle.core.jinja.base
handler: python
