---
title: trestle.core.commands.author.common
description: Documentation for trestle.core.commands.author.common module
---

::: trestle.core.commands.author.common
handler: python
