---
title: trestle.core.commands.remove
description: Documentation for trestle.core.commands.remove module
---

::: trestle.core.commands.remove
handler: python
