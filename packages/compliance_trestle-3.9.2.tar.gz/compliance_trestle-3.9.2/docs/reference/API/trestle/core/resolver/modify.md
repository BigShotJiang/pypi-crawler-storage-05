---
title: trestle.core.resolver.modify
description: Documentation for trestle.core.resolver.modify module
---

::: trestle.core.resolver.modify
handler: python
