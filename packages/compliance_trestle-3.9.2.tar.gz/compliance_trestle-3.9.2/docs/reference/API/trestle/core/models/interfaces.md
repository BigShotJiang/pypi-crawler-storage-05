---
title: trestle.core.models.interfaces
description: Documentation for trestle.core.models.interfaces module
---

::: trestle.core.models.interfaces
handler: python
