---
title: trestle.core.markdown.markdown_api
description: Documentation for trestle.core.markdown.markdown_api module
---

::: trestle.core.markdown.markdown_api
handler: python
