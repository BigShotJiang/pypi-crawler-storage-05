---
title: trestle.core.commands.author.folders
description: Documentation for trestle.core.commands.author.folders module
---

::: trestle.core.commands.author.folders
handler: python
