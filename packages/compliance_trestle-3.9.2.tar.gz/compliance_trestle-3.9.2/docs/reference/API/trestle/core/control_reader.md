---
title: trestle.core.control_reader
description: Documentation for trestle.core.control_reader module
---

::: trestle.core.control_reader
handler: python
