---
title: trestle.core.commands.author.ssp
description: Documentation for trestle.core.commands.author.ssp module
---

::: trestle.core.commands.author.ssp
handler: python
