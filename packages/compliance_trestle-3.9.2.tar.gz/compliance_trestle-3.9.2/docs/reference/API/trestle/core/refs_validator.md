---
title: trestle.core.refs_validator
description: Documentation for trestle.core.refs_validator module
---

::: trestle.core.refs_validator
handler: python
