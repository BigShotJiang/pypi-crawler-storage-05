---
title: trestle.core.models.file_content_type
description: Documentation for trestle.core.models.file_content_type module
---

::: trestle.core.models.file_content_type
handler: python
