---
title: trestle.core.commands.init
description: Documentation for trestle.core.commands.init module
---

::: trestle.core.commands.init
handler: python
