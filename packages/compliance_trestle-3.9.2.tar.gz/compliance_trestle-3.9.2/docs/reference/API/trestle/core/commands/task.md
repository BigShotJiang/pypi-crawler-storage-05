---
title: trestle.core.commands.task
description: Documentation for trestle.core.commands.task module
---

::: trestle.core.commands.task
handler: python
