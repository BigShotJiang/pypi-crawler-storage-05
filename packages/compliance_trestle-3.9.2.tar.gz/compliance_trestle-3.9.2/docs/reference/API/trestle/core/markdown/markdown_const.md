---
title: trestle.core.markdown.markdown_const
description: Documentation for trestle.core.markdown.markdown_const module
---

::: trestle.core.markdown.markdown_const
handler: python
