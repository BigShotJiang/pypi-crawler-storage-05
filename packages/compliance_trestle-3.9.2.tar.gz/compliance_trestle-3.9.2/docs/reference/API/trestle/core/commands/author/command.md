---
title: trestle.core.commands.author.command
description: Documentation for trestle.core.commands.author.command module
---

::: trestle.core.commands.author.command
handler: python
