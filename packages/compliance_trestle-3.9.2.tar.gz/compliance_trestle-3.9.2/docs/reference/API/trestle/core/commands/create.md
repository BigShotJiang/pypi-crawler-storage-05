---
title: trestle.core.commands.create
description: Documentation for trestle.core.commands.create module
---

::: trestle.core.commands.create
handler: python
