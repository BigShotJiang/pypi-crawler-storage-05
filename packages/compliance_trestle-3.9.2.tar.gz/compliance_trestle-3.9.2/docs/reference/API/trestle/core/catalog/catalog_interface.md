---
title: trestle.core.catalog.catalog_interface
description: Documentation for trestle.core.catalog.catalog_interface module
---

::: trestle.core.catalog.catalog_interface
handler: python
