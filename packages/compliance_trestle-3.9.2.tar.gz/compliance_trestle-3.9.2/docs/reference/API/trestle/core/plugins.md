---
title: trestle.core.plugins
description: Documentation for trestle.core.plugins module
---

::: trestle.core.plugins
handler: python
