---
title: trestle.core.duplicates_validator
description: Documentation for trestle.core.duplicates_validator module
---

::: trestle.core.duplicates_validator
handler: python
