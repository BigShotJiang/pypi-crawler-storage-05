---
title: trestle.core.profile_resolver
description: Documentation for trestle.core.profile_resolver module
---

::: trestle.core.profile_resolver
handler: python
