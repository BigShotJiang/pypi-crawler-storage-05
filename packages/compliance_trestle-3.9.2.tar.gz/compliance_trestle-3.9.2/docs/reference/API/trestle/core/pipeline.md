---
title: trestle.core.pipeline
description: Documentation for trestle.core.pipeline module
---

::: trestle.core.pipeline
handler: python
