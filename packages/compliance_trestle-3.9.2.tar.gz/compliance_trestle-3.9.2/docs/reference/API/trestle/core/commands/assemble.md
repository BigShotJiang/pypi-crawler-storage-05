---
title: trestle.core.commands.assemble
description: Documentation for trestle.core.commands.assemble module
---

::: trestle.core.commands.assemble
handler: python
