---
title: trestle.core.jinja.ext
description: Documentation for trestle.core.jinja.ext module
---

::: trestle.core.jinja.ext
handler: python
