---
title: trestle.core.commands.author.headers
description: Documentation for trestle.core.commands.author.headers module
---

::: trestle.core.commands.author.headers
handler: python
