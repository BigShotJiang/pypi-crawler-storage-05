---
title: trestle.core.commands.author.jinja
description: Documentation for trestle.core.commands.author.jinja module
---

::: trestle.core.commands.author.jinja
handler: python
