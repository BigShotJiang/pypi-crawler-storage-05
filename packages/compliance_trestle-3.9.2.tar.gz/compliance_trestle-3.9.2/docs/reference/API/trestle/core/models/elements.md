---
title: trestle.core.models.elements
description: Documentation for trestle.core.models.elements module
---

::: trestle.core.models.elements
handler: python
