---
title: trestle.core.crm.ssp_inheritance_api
description: Documentation for trestle.core.crm.ssp_inheritance_api module
---

::: trestle.core.crm.ssp_inheritance_api
handler: python
