---
title: trestle.core.catalog.catalog_writer
description: Documentation for trestle.core.catalog.catalog_writer module
---

::: trestle.core.catalog.catalog_writer
handler: python
