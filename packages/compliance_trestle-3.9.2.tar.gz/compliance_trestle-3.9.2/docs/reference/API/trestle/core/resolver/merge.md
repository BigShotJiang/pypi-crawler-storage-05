---
title: trestle.core.resolver.merge
description: Documentation for trestle.core.resolver.merge module
---

::: trestle.core.resolver.merge
handler: python
