---
title: trestle.core.trestle_base_model
description: Documentation for trestle.core.trestle_base_model module
---

::: trestle.core.trestle_base_model
handler: python
