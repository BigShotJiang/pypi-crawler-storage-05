---
title: trestle.core.commands.split
description: Documentation for trestle.core.commands.split module
---

::: trestle.core.commands.split
handler: python
