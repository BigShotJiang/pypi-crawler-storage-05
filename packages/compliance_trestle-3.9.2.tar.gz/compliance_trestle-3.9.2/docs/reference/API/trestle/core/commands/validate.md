---
title: trestle.core.commands.validate
description: Documentation for trestle.core.commands.validate module
---

::: trestle.core.commands.validate
handler: python
