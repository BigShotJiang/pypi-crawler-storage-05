---
title: trestle.core.commands.author.versioning.template_versioning
description: Documentation for trestle.core.commands.author.versioning.template_versioning module
---

::: trestle.core.commands.author.versioning.template_versioning
handler: python
