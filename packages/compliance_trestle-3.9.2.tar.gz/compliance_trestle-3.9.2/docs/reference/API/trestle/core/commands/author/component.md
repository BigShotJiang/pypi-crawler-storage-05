---
title: trestle.core.commands.author.component
description: Documentation for trestle.core.commands.author.component module
---

::: trestle.core.commands.author.component
handler: python
