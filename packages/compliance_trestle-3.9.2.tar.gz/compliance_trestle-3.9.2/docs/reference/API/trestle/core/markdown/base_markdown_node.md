---
title: trestle.core.markdown.base_markdown_node
description: Documentation for trestle.core.markdown.base_markdown_node module
---

::: trestle.core.markdown.base_markdown_node
handler: python
