---
title: trestle.core.crm.leveraged_statements
description: Documentation for trestle.core.crm.leveraged_statements module
---

::: trestle.core.crm.leveraged_statements
handler: python
