---
title: trestle.core.catalog.catalog_reader
description: Documentation for trestle.core.catalog.catalog_reader module
---

::: trestle.core.catalog.catalog_reader
handler: python
