---
title: trestle.core.crm.export_writer
description: Documentation for trestle.core.crm.export_writer module
---

::: trestle.core.crm.export_writer
handler: python
