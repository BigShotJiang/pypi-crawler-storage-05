---
title: trestle.core.commands.author.catalog
description: Documentation for trestle.core.commands.author.catalog module
---

::: trestle.core.commands.author.catalog
handler: python
