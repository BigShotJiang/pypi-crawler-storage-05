---
title: trestle.core.commands.describe
description: Documentation for trestle.core.commands.describe module
---

::: trestle.core.commands.describe
handler: python
