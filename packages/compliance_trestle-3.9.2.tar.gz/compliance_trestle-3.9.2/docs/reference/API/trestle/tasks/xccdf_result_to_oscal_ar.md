---
title: trestle.tasks.xccdf_result_to_oscal_ar
description: Documentation for trestle.tasks.xccdf_result_to_oscal_ar module
---

::: trestle.tasks.xccdf_result_to_oscal_ar
handler: python
