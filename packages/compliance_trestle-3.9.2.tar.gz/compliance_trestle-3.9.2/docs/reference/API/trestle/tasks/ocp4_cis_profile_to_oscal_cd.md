---
title: trestle.tasks.ocp4_cis_profile_to_oscal_cd
description: Documentation for trestle.tasks.ocp4_cis_profile_to_oscal_cd module
---

::: trestle.tasks.ocp4_cis_profile_to_oscal_cd
handler: python
