---
title: trestle.tasks.csv_to_oscal_cd
description: Documentation for trestle.tasks.csv_to_oscal_cd module
---

::: trestle.tasks.csv_to_oscal_cd
handler: python
