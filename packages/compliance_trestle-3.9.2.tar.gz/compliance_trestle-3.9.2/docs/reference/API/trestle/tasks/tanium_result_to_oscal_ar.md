---
title: trestle.tasks.tanium_result_to_oscal_ar
description: Documentation for trestle.tasks.tanium_result_to_oscal_ar module
---

::: trestle.tasks.tanium_result_to_oscal_ar
handler: python
