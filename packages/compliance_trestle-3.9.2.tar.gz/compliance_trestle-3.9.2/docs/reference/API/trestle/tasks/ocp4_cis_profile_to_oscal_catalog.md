---
title: trestle.tasks.ocp4_cis_profile_to_oscal_catalog
description: Documentation for trestle.tasks.ocp4_cis_profile_to_oscal_catalog module
---

::: trestle.tasks.ocp4_cis_profile_to_oscal_catalog
handler: python
