---
title: trestle.tasks.xlsx_to_oscal_cd
description: Documentation for trestle.tasks.xlsx_to_oscal_cd module
---

::: trestle.tasks.xlsx_to_oscal_cd
handler: python
