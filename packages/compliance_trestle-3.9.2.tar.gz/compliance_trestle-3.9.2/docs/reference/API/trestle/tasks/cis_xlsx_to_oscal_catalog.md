---
title: trestle.tasks.cis_xlsx_to_oscal_catalog
description: Documentation for trestle.tasks.cis_xlsx_to_oscal_catalog module
---

::: trestle.tasks.cis_xlsx_to_oscal_catalog
handler: python
