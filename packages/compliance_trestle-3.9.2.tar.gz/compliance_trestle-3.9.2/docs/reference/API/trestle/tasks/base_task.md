---
title: trestle.tasks.base_task
description: Documentation for trestle.tasks.base_task module
---

::: trestle.tasks.base_task
handler: python
