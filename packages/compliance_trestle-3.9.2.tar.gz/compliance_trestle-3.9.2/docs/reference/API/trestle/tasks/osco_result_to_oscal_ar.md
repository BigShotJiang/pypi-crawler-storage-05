---
title: trestle.tasks.osco_result_to_oscal_ar
description: Documentation for trestle.tasks.osco_result_to_oscal_ar module
---

::: trestle.tasks.osco_result_to_oscal_ar
handler: python
