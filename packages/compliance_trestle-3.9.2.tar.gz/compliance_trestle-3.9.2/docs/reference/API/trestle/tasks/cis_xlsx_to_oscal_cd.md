---
title: trestle.tasks.cis_xlsx_to_oscal_cd
description: Documentation for trestle.tasks.cis_xlsx_to_oscal_cd module
---

::: trestle.tasks.cis_xlsx_to_oscal_cd
handler: python
