---
title: trestle.common.err
description: Documentation for trestle.common.err module
---

::: trestle.common.err
handler: python
