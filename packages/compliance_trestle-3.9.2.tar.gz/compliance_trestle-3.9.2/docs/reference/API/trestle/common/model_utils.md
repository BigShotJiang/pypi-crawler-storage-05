---
title: trestle.common.model_utils
description: Documentation for trestle.common.model_utils module
---

::: trestle.common.model_utils
handler: python
