---
title: trestle.common.type_utils
description: Documentation for trestle.common.type_utils module
---

::: trestle.common.type_utils
handler: python
