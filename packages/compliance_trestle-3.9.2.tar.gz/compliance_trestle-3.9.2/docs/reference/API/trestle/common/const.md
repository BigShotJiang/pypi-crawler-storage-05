---
title: trestle.common.const
description: Documentation for trestle.common.const module
---

::: trestle.common.const
handler: python
