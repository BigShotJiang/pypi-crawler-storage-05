---
title: trestle.common.trash
description: Documentation for trestle.common.trash module
---

::: trestle.common.trash
handler: python
