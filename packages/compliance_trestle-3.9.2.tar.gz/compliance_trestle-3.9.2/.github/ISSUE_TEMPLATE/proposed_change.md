---
about: Propose a change to the trestle project
assignees: ''
labels: ''
name: Proposed change
title: ''
---

## Issue description / feature objectives

## Caveats / Assumptions

## Completion Criteria
