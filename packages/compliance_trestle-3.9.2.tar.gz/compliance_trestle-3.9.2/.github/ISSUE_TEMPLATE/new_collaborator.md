---
about: Request collaborator access
assignees: ''
labels: ''
name: New Collaborator
title: ''
---

I would like collaborator (write) access to this repository.

- [ ] I have read the [contributing guidelines][contributing]
- [ ] I understand the responsibilities of a collaborator are to:
  - help review contributions to the compliance-trestle tool
  - help make & test releases
  - help promote the project

[contributing]: https://github.com/oscal-compass/compliance-trestle/blob/main/CONTRIBUTING.md
