Trestle was designed and open sourced by a team based at [IBM Research](https://www.research.ibm.com/) and others around the world.  The list includes:

Alejandro Jose Leiva Palomo [AleJo2995](https://github.com/AleJo2995)

Christopher Butler [butler54](https://github.com/butler54)

Lou Degenaro [degenaro](https://github.com/degenaro)

Jennifer Power [jpower432](https://github.com/jpower432)

Manjiree Gadgil [mrgadgil](https://github.com/mrgadgil)

Vikas Agarwal [vikas-agarwal76](https://github.com/vikas-agarwal76)
