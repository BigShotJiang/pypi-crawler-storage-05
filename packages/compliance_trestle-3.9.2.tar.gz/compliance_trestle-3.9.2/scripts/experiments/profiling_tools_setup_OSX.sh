#!/usr/bin/env bash
# run from the root of compliance trestle

# This setup is only for OSX - milage will vary on other platforms

pip install gprof2dot
pip install snakeviz
brew install graphviz
