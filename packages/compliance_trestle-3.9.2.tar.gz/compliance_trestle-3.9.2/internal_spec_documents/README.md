# Specifications

This directory is used for storing `trestle specs`. Trestle specs are architectural documents which span across multiple
issues / stories. They are not intended to be end-user documentation, rather, documentation for trestle developers.

This folder will not be part of the documentation website.
