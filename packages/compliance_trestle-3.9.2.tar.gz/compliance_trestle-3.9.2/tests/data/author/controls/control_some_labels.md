# xy-1 - \[My Group Title\]  Fancy Control

## Control statement
The organisation:
- \[y\]Does Foo
- Does Bar
- Does More
  - \[abc12\]This more
  - More more
- Does Great

