---
this: is okay
this is really bad

--- 
# markdown stuff goes here.