---
authors: tmp
owner: tmp
valid:
  from:
  to:
x-trestle-template-type: b
x-trestle-template-version: 1.1.1
---

# Network architectures

## External interconnections

## Corporate interconnections

## Out of scope interconnections
