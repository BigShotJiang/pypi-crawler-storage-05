---
authors: tmp
owner: tmp
valid:
  from:
  to:
x-trestle-template-type: b
x-trestle-template-version: 1.0.0
---

# Network architecture

## External interconnections

## Corporate interconnections

## Out of scope interconnections
