---
authors: tmp
owner: tmp
valid:
  from: null
  to: null
x-trestle-template-type: a
x-trestle-template-version: 2.0.0
---
# System architecture

## Overview

## Security model
