---
authors: tmp
owner: tmp
valid:
  from:
  to:
---

# Network architecture

## External interconnections

## Corporate interconnections

## Out of scope interconnections
