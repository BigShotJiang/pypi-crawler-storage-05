---
authors: tmp
owner: tmp
valid:
  from:
  to:
x-trestle-template-type: network
---

# Network architecture

## External interconnections

## Corporate interconnections

## Out of scope interconnections
