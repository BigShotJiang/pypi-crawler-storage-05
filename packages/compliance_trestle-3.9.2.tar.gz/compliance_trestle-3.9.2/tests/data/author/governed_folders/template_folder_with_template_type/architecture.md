---
authors: tmp
owner: tmp
valid:
  from: null
  to: null
x-trestle-template-type: architecture
---
# System architecture

## Overview

## Security model
