---
authors:
  - Tim
  - Jane
  - Sally
owner: Joe
valid:
  from: 2020-01-01
  to: 2099-12-31
---

# { Security Capability Name } Defect Checks
## 1. Facts Data Model
### Sub-Capability: { _insert name of subcapability_}
## 2. Defect Checks
### Sub-capability: { _insert sub-capability name_}
#### { _insert defect check name_}
##### Assessment Criteria
###### Inputs
###### Rules
####### { Rule Name}
######## Type
######## Rationale Statement
######## Impact Statement
######## Implementation Description
######## Audit Procedure(s)
######## Remediation Procedure(s)
######## Parameters
###### Additional Outputs
##### Assessment Objectives