# Network architecture

## External interconnections

## Corporate interconnections

## Out of scope interconnections
