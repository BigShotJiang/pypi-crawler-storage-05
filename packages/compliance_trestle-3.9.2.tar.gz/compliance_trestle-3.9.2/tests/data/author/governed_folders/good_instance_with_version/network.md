---
authors: tmp
owner: tmp
valid:
  from:
  to:
x-trestle-template-version: 0.0.1
---

# Network architecture

## External interconnections

## Corporate interconnections

## Out of scope interconnections
