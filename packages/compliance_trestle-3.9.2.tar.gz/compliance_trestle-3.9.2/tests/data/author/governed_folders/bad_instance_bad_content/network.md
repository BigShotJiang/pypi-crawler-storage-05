---
authors:
  - Tim
  - Jane
  - Sally
owner: Joe
valid:
  from: 2020-01-01
  to: 2099-12-31
---

# Network architecture

Lots of stuff about the network overall including some diagrams.

## External interconnections

Here I put a table which describes the connections beyond my audit boundary with 3rd parties.

## Corporate interconnections

Here I describe interconnections into corporate systems.

## Out of scope interconnections

Here I describe interconnections that are out of scope because they occur outside of the current audit boundary.

# Here is something that should not be here.
