# Governed Document

required:

# This is my content

This file is a pro-forma template.

# This is another heading

## this is a required sub-heading

## Governed_Section
**Content Type:**  Foo
**Author(s):**  Bah
**Executive Owner:**  Stuff
**Executive Approver:**   John Doe (approved)
**Version:** 1.0.1

Some text here, the key:value text above should remain the same

# Another_Governed_Section
Some other text here
**Content:**  Foo
**Executive Owner:**  Stuff
**Technical Approver:**   John Doe (approved)
**Version:** 1.0.1


## Governed_Section
This section has the same name as section above
**Financial Approver:** Mr.Smith
**Version:** 1.0.1
Not governed text