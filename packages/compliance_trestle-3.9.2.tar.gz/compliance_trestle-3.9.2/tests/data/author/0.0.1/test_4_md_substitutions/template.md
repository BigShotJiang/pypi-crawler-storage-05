---
yaml: header
some_key: some value
---

# {Substitute me}

## Required {substitute}

### {substitute me} header

#### Complex {substitute} header {sub} with substitutions

##### Required header 5

# Required header 1

# Required header 2

## Required sub-header 1

## Required sub-header 2

# Required header 3
