# Markdown document

![Image One](img1.png)
![Image Two](img2.png)
[link](url)
![malformed image][malformed.png]
!(malformed image)[malformed.png]
Table: informational table
Table: another informational table
table: lowercase table
A sentence that ends with table:
A sentence with Table: in it
