# Markdown document

![Figure 1 - Image One](img1.png)
![Figure 2 - Image Two](img2.png)
[link](url)
![malformed image][malformed.png]
!(malformed image)[malformed.png]
Table: Table 1 - informational table
Table: Table 2 - another informational table
Table: Table 3 - lowercase table
A sentence that ends with table:
A sentence with Table: in it
