{% md_datestamp newline=false%}{% md_datestamp newline=true%}

# Heading
