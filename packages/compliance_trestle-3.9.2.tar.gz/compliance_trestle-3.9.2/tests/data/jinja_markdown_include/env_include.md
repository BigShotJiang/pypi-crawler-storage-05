# A markdown file with jinja objects.


# This should pull content in only if the var is correct
# this is the end result nesting file

# Header we want

Get this stuff.

## my nested header

Content under my headers. It worked!

# Content we don't want.

Don't want this stuff
