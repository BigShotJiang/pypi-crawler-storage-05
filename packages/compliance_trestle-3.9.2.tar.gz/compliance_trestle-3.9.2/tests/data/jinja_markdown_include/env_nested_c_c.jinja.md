# A markdown file with jinja objects.


# This should pull content in only if the var is correct
{% md_clean_include 'nested_c.jinja.md' %}