from __future__ import annotations

import pytest


@pytest.mark.xfail(reason="Implement it")
def test_parse_and_validate_scope():
    raise AssertionError()
