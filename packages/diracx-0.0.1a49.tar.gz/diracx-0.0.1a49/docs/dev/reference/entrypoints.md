#TODO

list of entrypoints and what they are
