(make all the ops bulk, point to the explanations)
