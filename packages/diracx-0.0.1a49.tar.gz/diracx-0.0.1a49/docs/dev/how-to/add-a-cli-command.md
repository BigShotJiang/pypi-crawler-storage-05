# How to add a CLI command?

TODO
