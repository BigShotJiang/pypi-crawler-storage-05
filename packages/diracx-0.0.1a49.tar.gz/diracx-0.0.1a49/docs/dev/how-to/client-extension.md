# Client extensions

TODO: Explain how to generate an extended client and automate the process for each DiracX release.
