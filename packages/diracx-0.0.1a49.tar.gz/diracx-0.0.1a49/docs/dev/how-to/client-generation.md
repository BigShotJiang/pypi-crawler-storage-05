TODO:
The best up-to-date documentation lies in the `client-generation` CI job in the main workflow.
