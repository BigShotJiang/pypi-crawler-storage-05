TODO:

decoding a token
finding a token file
meaning of properties, policies
