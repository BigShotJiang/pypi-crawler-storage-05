"""CLI interface for n8n-lint."""

from .main import app

__all__ = ["app"]
