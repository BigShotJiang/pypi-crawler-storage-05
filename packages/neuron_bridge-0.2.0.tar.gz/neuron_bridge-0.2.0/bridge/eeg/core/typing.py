import numpy as np
from numpy.typing import NDArray

EEGArray = NDArray[np.float64]
