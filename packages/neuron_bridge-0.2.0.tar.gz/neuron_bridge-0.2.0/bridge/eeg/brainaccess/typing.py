Cap = dict[int, str]
