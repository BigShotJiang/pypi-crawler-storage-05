
::: pbi_pyadomd.Connection
