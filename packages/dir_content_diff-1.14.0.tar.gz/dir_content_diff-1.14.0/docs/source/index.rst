.. include:: README_processed.md
   :parser: myst_parser.sphinx_


.. toctree::
   :hidden:
   :maxdepth: 2

   Home <self>
   api_ref
   changelog
   contributing
