=============================
 HTTP: ``zope.session.http``
=============================

.. testsetup::

    from zope.session.http import *

.. automodule:: zope.session.http
