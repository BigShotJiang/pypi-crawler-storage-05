===========================================
 Session Storage: ``zope.session.session``
===========================================

.. testsetup::

    from zope.session.session import *

.. testcleanup::

    import transaction
    transaction.abort()

.. automodule:: zope.session.session
   :special-members:
