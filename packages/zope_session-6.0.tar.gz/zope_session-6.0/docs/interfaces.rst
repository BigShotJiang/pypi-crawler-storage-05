=========================================
 Interfaces: ``zope.session.interfaces``
=========================================

.. automodule:: zope.session.interfaces
