.. include:: ../README.rst


Documentation:

.. toctree::
   :maxdepth: 2

   design
   api

API Documentation:

.. toctree::
   :maxdepth: 2

   interfaces
   session
   http

.. toctree::
   :maxdepth: 2

   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
