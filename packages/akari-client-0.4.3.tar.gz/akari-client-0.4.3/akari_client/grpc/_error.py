from akari_proto.grpc.error import RPCErrorSerializer

serializer = RPCErrorSerializer()
# TODO: Register AkariError classes
