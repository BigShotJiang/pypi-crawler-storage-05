from .report import Report
from .figures import Table, ConfusionMatrix, Doughnut, FigOptions, Bar, Hbar, Line, Pie, Scatter
