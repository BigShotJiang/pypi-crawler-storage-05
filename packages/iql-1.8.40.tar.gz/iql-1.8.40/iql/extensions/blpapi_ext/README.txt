# Notes

Requires blpapi to be installed. See 
[Bloomberg Downloads](https://www.bloomberg.com/professional/support/api-library/)
for specifics.

At time of writing this, the instructions say: `pip install --index-url=https://bcms.bloomberg.com/pip/simple blpap
i`

Requires a live Terminal session