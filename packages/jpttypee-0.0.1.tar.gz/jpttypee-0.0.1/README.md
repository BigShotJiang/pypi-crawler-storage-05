# jpt_typee

Python driver for JPT TypeE laser (serial control).

## Installation

```bash
pip install JPTTypeE