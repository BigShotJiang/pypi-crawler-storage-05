# Security Policy For Workbench
We're dedicated to providing the best experience for our users and clients. As part of that we take any security issue or vulnerability seriously.

## Reporting a Vulnerability
If you find an issue with any of the Workbench code or package dependencies please send us an email to
[workbench@supercowpowers.com](mailto:workbench@supercowpowers.com). We may contact you for follow on details as we're creating tickets or unit tests.
