.. acknowledge Acknowledgement


Acknowledgement
===============

If you would like to acknowledge the use of pynbody in your work, we recommend
a statement something like:

*We made use of pynbody (https://github.com/pynbody/pynbody) in our analysis
for this paper.*
