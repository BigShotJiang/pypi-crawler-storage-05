"""
This is a placeholder package intentionally published to PyPI to prevent
dependency confusion attacks. It contains no functional code.
"""

__version__ = "0.0.1"
