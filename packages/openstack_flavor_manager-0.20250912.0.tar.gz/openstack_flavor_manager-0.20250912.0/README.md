# Openstack flavor manager

[![PyPi version](https://badgen.net/pypi/v/openstack-flavor-manager/)](https://pypi.org/project/openstack-flavor-manager/)
[![PyPi license](https://badgen.net/pypi/license/openstack-flavor-manager/)](https://pypi.org/project/openstack-flavor-manager/)
[![Documentation](https://img.shields.io/static/v1?label=&message=documentation&color=blue)](https://osism.tech/docs/guides/operations-guide/openstack/tools/flavor-manager)

Easily create OpenStack flavors based on standardised YAML files
