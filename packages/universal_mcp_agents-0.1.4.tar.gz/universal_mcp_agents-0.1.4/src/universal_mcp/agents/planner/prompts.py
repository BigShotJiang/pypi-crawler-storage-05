# Prompts for the planner agent
