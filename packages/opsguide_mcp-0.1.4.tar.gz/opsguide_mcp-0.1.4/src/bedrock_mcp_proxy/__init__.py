"""Bedrock MCP Proxy - MCP Server proxy for Amazon Bedrock AgentCore Runtime."""

__version__ = "0.1.0"
__author__ = "Ekky Armandi"
__email__ = "me@ekky.dev"
