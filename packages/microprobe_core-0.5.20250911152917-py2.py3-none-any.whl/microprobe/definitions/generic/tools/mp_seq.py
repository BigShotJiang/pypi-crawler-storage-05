#!/usr/bin/env python
# Copyright 2011-2021 IBM Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
File: mp_seq

This script implements the tool that generates a variety of sequences from
the input isntructions provided
"""

# Futures
from __future__ import absolute_import, print_function

# Built-in modules
import argparse
import hashlib
import itertools
import multiprocessing as mp
import os
import sys
from typing import Any, List, Tuple

# Own modules
from microprobe import MICROPROBE_RC
from microprobe.code import get_wrapper
from microprobe.exceptions import MicroprobeException, MicroprobeValueError
from microprobe.target import Target, import_definition
from microprobe.target.isa.instruction import InstructionType
from microprobe.utils.cmdline import (
    CLI,
    existing_dir,
    float_type,
    int_type,
    new_file,
    parse_instruction_list,
    print_error,
    print_info,
)
from microprobe.utils.logger import get_logger
from microprobe.utils.misc import findfiles, iter_flatten, move_file
from microprobe.utils.policy import find_policy
from microprobe.utils.typeguard_decorator import typeguard_testsuite

# Constants
LOG = get_logger(__name__)
_DIRCONTENTS = []
_BALANCE_EXECUTION = False


# Functions
def _get_wrapper(name: str):
    try:
        return get_wrapper(name)
    except MicroprobeValueError as exc:
        raise MicroprobeException(
            "Wrapper '%s' not available. Check if you have the wrappers "
            "of the target installed or set up an appropriate "
            "MICROPROBEWRAPPERS environment variable. Original error was: %s"
            % (name, str(exc))
        )


@typeguard_testsuite
def _generic_policy_wrapper(
    all_arguments: Tuple[List[InstructionType], str, str, Target, Any]
):

    instructions, outputdir, outputname, target, kwargs = all_arguments

    outputfile = os.path.join(outputdir, "%DIRTREE%", outputname)
    outputfile = outputfile.replace(
        "%DIRTREE%", os.path.join(*[instr.name for instr in instructions])
    )

    if kwargs["shortnames"]:
        outputfile = outputfile.replace(
            "%INSTR%",
            "mp_seq_%s"
            % hashlib.sha1(
                "_".join(instr.name for instr in instructions).encode()
            ).hexdigest(),
        )
    else:
        outputfile = outputfile.replace(
            "%INSTR%", "_".join(instr.name for instr in instructions)
        )

    if "ignore_errors" not in kwargs:
        kwargs["ignore_errors"] = False

    extension = ""
    if target.name.endswith("linux_gcc"):

        wrapper_name = "CInfGen"
        wrapper_class = _get_wrapper(wrapper_name)
        wrapper = wrapper_class(reset=kwargs["reset"])
        extension = "c"

    elif target.name.endswith("cronus"):

        wrapper_name = "Cronus"
        wrapper_class = _get_wrapper(wrapper_name)
        wrapper = wrapper_class(
            reset=kwargs["reset"], endless=kwargs["endless"]
        )
        extension = "bin"

    elif target.name.endswith("mesa"):

        wrapper_name = "Tst"
        extension = "tst"
        wrapper_class = _get_wrapper(wrapper_name)
        wrapper = wrapper_class(
            os.path.basename(outputfile.replace("%EXT%", extension)),
            endless=kwargs["endless"],
            reset=kwargs["reset"],
        )

    elif target.name.endswith("riscv64_test_p"):

        wrapper_name = "RiscvTestsP"
        extension = "S"
        wrapper_class = _get_wrapper(wrapper_name)
        wrapper = wrapper_class(
            endless=kwargs["endless"], reset=kwargs["reset"]
        )

    elif target.name.endswith("riscv64_bp3"):

        wrapper_name = "RiscvBP3"
        extension = "S"
        wrapper_class = _get_wrapper(wrapper_name)
        wrapper = wrapper_class(
            endless=kwargs["endless"], reset=kwargs["reset"]
        )

    elif target.environment.default_wrapper:

        wrapper_name = target.environment.default_wrapper
        wrapper_class = _get_wrapper(wrapper_name)
        wrapper = wrapper_class(
            endless=kwargs["endless"], reset=kwargs["reset"]
        )

        outputfile = outputfile.replace(".%EXT%", "")
        outputfile = wrapper.outputname(outputfile)

    else:
        raise NotImplementedError(f"Unsupported configuration '{target.name}'")

    if MICROPROBE_RC["debugwrapper"]:
        extension = "s"

    outputfile = outputfile.replace("%EXT%", extension)

    if kwargs["skip"] and outputfile in _DIRCONTENTS:
        print_info(f"{outputfile} already exists!")
        return

    if (
        kwargs["skip"]
        and f"{outputfile}.gz" in _DIRCONTENTS
        and kwargs["compress"]
    ):
        print_info(f"{outputfile}.gz already exists!")
        return

    if kwargs["skip"] and os.path.isfile(outputfile):
        print_info(f"{outputfile} already exists!")
        return

    if (
        kwargs["skip"]
        and os.path.isfile(f"{outputfile}.gz")
        and kwargs["compress"]
    ):
        print_info(f"{outputfile} already exists!")
        return

    extra_arguments = {}
    extra_arguments["instructions"] = instructions
    extra_arguments["benchmark_size"] = kwargs["benchmark_size"]
    extra_arguments["dependency_distance"] = kwargs["dependency_distance"]
    extra_arguments["force_switch"] = kwargs["force_switch"]
    extra_arguments["endless"] = kwargs["endless"]

    if wrapper.outputname(outputfile) != outputfile:
        print_error(
            "Fix outputname '%s' to have a proper extension. E.g. '%s'"
            % (outputfile, wrapper.outputname(outputfile))
        )
        exit(-1)

    for instr in instructions:
        if instr.unsupported:
            print_info(f"{instr.name} not supported!")
            return

    policy = find_policy(target.name, "seq")

    if not os.path.exists(os.path.dirname(outputfile)):
        os.makedirs(os.path.dirname(outputfile))

    outputfile = new_file(wrapper.outputname(outputfile), internal=True)

    synth = policy.apply(target, wrapper, **extra_arguments)

    if not kwargs["ignore_errors"]:
        print_info(f"Generating {outputfile}...")
        bench = synth.synthesize()
    else:
        if os.path.exists(f"{outputfile}.fail"):
            print_error(f"{outputfile} failed before. Skip.")
            return

        try:
            print_info(f"Generating {outputfile}...")
            bench = synth.synthesize()
        except (MicroprobeException, AssertionError, AttributeError) as exc:
            with open(f"{outputfile}.fail", "a"):
                os.utime(f"{outputfile}.fail", None)

            print_error(f"{exc}")
            print_error("Generation failed and ignore error flag set")
            return

    synth.save(outputfile, bench=bench)

    print_info(f"{outputfile} generated!")

    if kwargs["compress"]:
        move_file(outputfile, f"{outputfile}.gz")
        print_info(f"{outputfile} compressed to {outputfile}.gz")

    return


# Main
@typeguard_testsuite
def main():
    """
    Program main
    """
    args = sys.argv[1:]
    cmdline = CLI(
        "Microprobe seq tool",
        default_config_file="mp_seq.cfg",
        force_required=["target"],
    )

    groupname = "SEQ arguments"
    cmdline.add_group(
        groupname, "Command arguments related to Sequence generation"
    )

    cmdline.add_option(
        "seq-output-dir",
        "D",
        None,
        "Output directory name",
        group=groupname,
        opt_type=existing_dir,
        required=True,
    )

    cmdline.add_option(
        "instruction-slots",
        "is",
        4,
        "Number of instructions slots in the sequence. E.g. '-is 4' will "
        "generate sequences of length 4.",
        group=groupname,
        opt_type=int_type(1, 999999999999),
    )

    cmdline.add_option(
        "instruction-groups",
        "ig",
        None,
        "Comma separated list of instruction candidates per group. E.g. "
        "-ins ins1,ins2 ins3,ins4. Defines two groups of instruction "
        "candidates: group 1: ins1,ins2 and group 2: ins3,ins4.",
        group=groupname,
        opt_type=str,
        action="append",
        nargs="+",
    )

    cmdline.add_option(
        "instruction-map",
        "im",
        None,
        "Comma separated list specifying groups instruction candidate groups "
        "to be used on each instruction slot. The list length should match "
        "the number of instruction slots defined.  A -1 value means all groups"
        " can be used for that slot. E.g. -im 1 2,3 will generate sequences "
        "containing in slot 1 instructions from group 1, and in slot 2 "
        "instructions from groups 2 and 3.",
        group=groupname,
        opt_type=str,
        required=False,
        action="append",
        nargs="+",
    )

    cmdline.add_option(
        "base-seq",
        "bs",
        None,
        "Comma separated list specifying the base instruction sequence",
        group=groupname,
        opt_type=str,
        required=False,
    )

    cmdline.add_option(
        "group-max",
        "gM",
        None,
        "Comma separated list specifying the maximum number of instructions "
        " of each group to be used. E.g. -gM 1,3 will generate sequences "
        "containing at most 1 instruction of group 1 and 3 instructions of "
        "group 2. A -1 value means no maximum. The list length should match "
        "the number of instruction groups defined.",
        group=groupname,
        opt_type=str,
        required=False,
        action="append",
        nargs="+",
    )

    cmdline.add_option(
        "group-min",
        "gm",
        None,
        "Comma separated list specifying the minimum number of instructions "
        " of each group to be used. E.g. -gm 1,3 will generate sequences "
        "containing at least 1 instruction of group 1 and 3 instructions of "
        "group 2. A -1 value means no minimum. The list length should match "
        "the number of instruction groups defined.",
        group=groupname,
        opt_type=str,
        required=False,
        action="append",
        nargs="+",
    )

    cmdline.add_option(
        "benchmark-size",
        "B",
        4096,
        "Size in instructions of the microbenchmark."
        " If more instruction are needed, nested loops are "
        "automatically generated",
        group=groupname,
        opt_type=int_type(1, 999999999999),
    )

    cmdline.add_option(
        "dependency-distance",
        "dd",
        0,
        "Average dependency distance between instructions. A value"
        " below 1 means not dependency between instructions. A value of "
        "1 means a chain of dependent instructions.",
        group=groupname,
        opt_type=float_type(0, 999999999999),
    )

    cmdline.add_flag(
        "force-switch",
        "fs",
        "Force data switching in all instructions, fail if not supported.",
        group=groupname,
    )

    cmdline.add_flag(
        "endless",
        "e",
        "Some backends allow the control to wrap the sequence generated in an"
        " endless loop. Depending on the target specified, this flag will "
        "force to generate sequences in an endless loop (some targets "
        " might ignore it)",
        group=groupname,
    )

    cmdline.add_flag(
        "reset",
        "R",
        "Reset the register contents on each loop iteration",
        group=groupname,
    )

    cmdline.add_flag(
        "parallel",
        "p",
        "Generate benchmarks in parallel",
        group=groupname,
    )

    cmdline.add_option(
        "batch-number",
        "bn",
        1,
        "Batch number to generate. Check --num-batches option for more "
        "details",
        group=groupname,
        opt_type=int_type(1, 10000),
    )

    cmdline.add_option(
        "num-batches",
        "nb",
        1,
        "Number of batches. The number of microbenchmark to generate "
        "is divided by this number, and the number the batch number "
        "specified using -bn option is generated. This is useful to "
        "split the generation of many test cases in various batches.",
        group=groupname,
        opt_type=int_type(1, 10000),
    )

    cmdline.add_flag(
        "skip",
        "s",
        "Skip benchmarks already generated",
        group=groupname,
    )

    cmdline.add_flag(
        "ignore-errors",
        "ie",
        "Ignore error during code generation (continue in case of "
        "an error in a particular parameter combination)",
        group=groupname,
    )

    cmdline.add_flag(
        "combinations",
        "combinations",
        "Only generate combinations of the given instructions",
        group=groupname,
    )

    cmdline.add_flag(
        "shortnames",
        "sn",
        "Use short output names",
        group=groupname,
    )

    cmdline.add_flag(
        "compress",
        "CC",
        "Compress output files",
        group=groupname,
    )

    cmdline.add_flag(
        "count",
        "N",
        "Only count the number of sequence to generate. Do not generate "
        "anything",
        group=groupname,
    )

    print_info("Processing input arguments...")

    cmdline.main(args, _main)


@typeguard_testsuite
def _generate_sequences(
    slots: int,
    instruction_groups,
    instruction_map,
    group_max: List[int],
    group_min: List[int],
    base_seq: List[InstructionType],
    combinations: bool,
):

    instr_names = []
    instr_objs = []
    print_info("")
    print_info("Groups defined:")
    for idx, igroup in enumerate(instruction_groups):
        print_info(
            "\tGroup %d:\t Instructions: %s"
            % ((idx + 1), ",".join([instr.name for instr in igroup]))
        )
        for instr in igroup:
            instr_names.append(instr.name + "_GRP%05d" % (idx + 1))
            if instr not in instr_objs:
                instr_objs.append(instr)

    slot_dsrc = []
    for elem in range(0, slots):
        allowed_groups = instruction_map[elem]
        allowed_instructions = []
        for group in allowed_groups:
            allowed_instructions += [
                iname
                for iname in instr_names
                if iname.endswith("_GRP%05d" % group)
            ]

        descriptor = [
            ["%d" % group for group in allowed_groups],
            allowed_instructions,
        ]

        slot_dsrc.append(descriptor)

    print_info("")
    print_info("Sequence definition:")
    print_info(f"\tSequence Length: {slots}")
    for idx, slot in enumerate(slot_dsrc):
        print_info(
            "\t\tSlot %s:\tAllowed groups: %s"
            "\tAllowed instructions: %s"
            % (idx + 1, ",".join(slot[0]), ",".join(slot[1]))
        )

    print_info("\tGroup constraints per sequence:")
    for idx, igroup in enumerate(instruction_groups):
        print_info(
            f"\t\tGroup {idx + 1}:\tMin instr: {group_min[idx]}"
            f"\tMax intr: {group_max[idx]}"
        )
    print_info("")

    seen = set()

    for seq in itertools.product(*[descr[1] for descr in slot_dsrc]):
        valid = True
        for idx, igroup in enumerate(instruction_groups):
            count = len(
                [
                    instr
                    for instr in seq
                    if instr.endswith("_GRP%05d" % (idx + 1))
                ]
            )

            if count < group_min[idx]:
                valid = False
                break

            if count > group_max[idx]:
                valid = False
                break

        if valid:
            sequence = []
            for instrname in seq:
                for idx in range(0, len(instruction_groups)):
                    instrname = instrname.replace("_GRP%05d" % (idx + 1), "")
                sequence += [
                    instr_obj
                    for instr_obj in instr_objs
                    if instr_obj.name == instrname
                ]
            if combinations:
                # Only generate combinations, not permutations
                if tuple(sorted(sequence)) in seen:
                    continue
                else:
                    seen.add(tuple(sorted(sequence)))

            yield base_seq + sequence


@typeguard_testsuite
def _main(arguments):
    """
    Program main, after processing the command line arguments

    :param arguments: Dictionary with command line arguments and values
    :type arguments: :class:`dict`
    """
    print_info("Arguments processed!")

    print_info("Checking input arguments for consistency...")

    if arguments["num_batches"] < arguments["batch_number"]:
        print_error(
            "Batch number should be within the number" " of batches specified"
        )
        exit(-1)

    slots = arguments["instruction_slots"]

    instruction_groups = list(
        iter_flatten(arguments.get("instruction_groups", []))
    )
    check_group_length_func = int_type(1, len(instruction_groups))
    check_slots_length_func = int_type(0, slots)

    instruction_map = arguments.get("instruction_map", None)
    if instruction_map is None:
        instruction_map = ["-1"] * slots
    else:
        instruction_map = list(iter_flatten(instruction_map))

    if len(instruction_map) != slots:
        print_error(f"Instruction map: {instruction_map}")
        print_error(f"Instruction map incorrect. Length should be: {slots}")
        exit(-1)

    new_map = []
    for gmap in instruction_map:
        ngmap = []

        if gmap == "-1":
            ngmap = list(range(1, len(instruction_groups) + 1))
            new_map.append(ngmap)
            continue

        for cmap in gmap.split(","):
            try:
                ngmap.append(check_group_length_func(cmap))
            except argparse.ArgumentTypeError as exc:
                print_error("Instruction map incorrect")
                print_error(exc)
                exit(-1)
        new_map.append(ngmap)

    instruction_map = new_map

    group_max = arguments.get("group_max", None)
    if group_max is None:
        group_max = ["-1"] * len(instruction_groups)
    else:
        group_max = list(iter_flatten(group_max))

    if len(group_max) != len(instruction_groups):
        print_error(f"Group max: {group_max}")
        print_error(
            "Group max incorrect. Length should be: %s"
            % len(instruction_groups)
        )
        exit(-1)

    new_map = []
    for gmap in group_max:

        if gmap == "-1":
            new_map.append(slots)
            continue

        try:
            new_map.append(check_slots_length_func(gmap))
        except argparse.ArgumentTypeError as exc:
            print_error("Group max incorrect")
            print_error(exc)
            exit(-1)

    group_max = new_map

    group_min = arguments.get("group_min", None)
    if group_min is None:
        group_min = ["-1"] * len(instruction_groups)
    else:
        group_min = list(iter_flatten(group_min))

    if len(group_min) != len(instruction_groups):
        print_error(f"Group min: {group_min}")
        print_error(
            "Group min incorrect. Length should be: %s"
            % len(instruction_groups)
        )
        exit(-1)

    new_map = []
    for gmap in group_min:

        if gmap == "-1":
            new_map.append(0)
            continue

        try:
            new_map.append(check_slots_length_func(gmap))
        except argparse.ArgumentTypeError as exc:
            print_error("Group min incorrect")
            print_error(exc)
            exit(-1)

    group_min = new_map

    print_info("Importing target definition...")
    target = import_definition(arguments.pop("target"))

    policy = find_policy(target.name, "seq")

    if policy is None:
        print_error("Target does not implement the default SEQ policy")
        exit(-1)

    instruction_groups = [
        parse_instruction_list(target, group) for group in instruction_groups
    ]

    base_seq = []
    if "base_seq" in arguments:
        base_seq = parse_instruction_list(target, arguments["base_seq"])

    combinations = "combinations" in arguments

    sequences = [base_seq]
    if len(instruction_groups) > 0:
        sequences = _generate_sequences(
            slots,
            instruction_groups,
            instruction_map,
            group_max,
            group_min,
            base_seq,
            combinations,
        )

    sequences = [seq for seq in sequences if seq]
    if not sequences:
        print_error("No instruction sequences defined. Check parameters.")
        exit(1)

    if "count" in arguments:
        print_info(
            "Total number of sequences defined: %s" % len(list(sequences))
        )
        exit(0)

    outputdir = arguments["seq_output_dir"]

    if _BALANCE_EXECUTION:
        global _DIRCONTENTS  # pylint: disable=global-statement
        _DIRCONTENTS = set(findfiles([outputdir], ""))

    outputname = "%INSTR%.%EXT%"

    if "reset" not in arguments:
        arguments["reset"] = False

    if "skip" not in arguments:
        arguments["skip"] = False

    if "force_switch" not in arguments:
        arguments["force_switch"] = False

    if "endless" not in arguments:
        arguments["endless"] = False

    if "shortnames" not in arguments:
        arguments["shortnames"] = False

    if "compress" not in arguments:
        arguments["compress"] = False

    # process batches
    print_info(f"Num sequences defined: {len(sequences)}")
    print_info("Number of batches: %d " % arguments["num_batches"])
    print_info("Batch number: %d " % arguments["batch_number"])

    size = len(sequences) // arguments["num_batches"]
    size = size + 1

    sequences = sequences[
        (arguments["batch_number"] - 1)
        * size: arguments["batch_number"]
        * size
    ]

    if "parallel" not in arguments:
        print_info("Start sequential generation. Use parallel flag to speed")
        print_info("up the benchmark generation.")
        for sequence in sequences:
            _generic_policy_wrapper(
                (sequence, outputdir, outputname, target, arguments)
            )

    else:
        print_info(
            "Start parallel generation. Threads: %s" % MICROPROBE_RC["cpus"]
        )
        pool = mp.Pool(processes=MICROPROBE_RC["cpus"])
        pool.map(
            _generic_policy_wrapper,
            [
                (sequence, outputdir, outputname, target, arguments)
                for sequence in sequences
            ],
        )


if __name__ == "__main__":  # run main if executed from the command line
    # and the main method exists

    if callable(locals().get("main")):
        main()
        exit(0)
