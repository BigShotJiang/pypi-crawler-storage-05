#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Created on Fri Jan 05 2024 23:11:55 by codeskyblue
"""

class BaseException(Exception):
    pass

class DownloadError(BaseException):
    pass

class FatalError(BaseException):
    pass