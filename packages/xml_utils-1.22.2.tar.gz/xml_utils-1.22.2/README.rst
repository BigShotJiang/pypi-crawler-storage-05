=========
Xml Utils
=========

XML utils for the curator core project.

Quick start
===========

1. Add "xml_utils" to your INSTALLED_APPS setting
-------------------------------------------------

.. code:: python

    INSTALLED_APPS = [
      ...
      'xml_utils',
    ]
