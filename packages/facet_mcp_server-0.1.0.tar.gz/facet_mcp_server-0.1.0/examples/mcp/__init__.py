"""
MCP Server Usage Examples

Demonstrates how AI agents can use FACET MCP Server tools
for various data processing and validation tasks.
"""
