"""
MCP Server Configuration

Provides configuration management for FACET MCP Server,
including server settings, tool configurations, and performance tuning.
"""
