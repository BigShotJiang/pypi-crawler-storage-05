"""
MCP Protocol Implementation

Defines message formats and transport layer for MCP communication.
Provides both JSON-RPC and gRPC transport options.
"""
