# asw_mather

asw_mather is a simple math helper library written in Python.  
It provides utility functions and classes to perform basic math operations.

## Installation
```bash
pip install asw_mathers
