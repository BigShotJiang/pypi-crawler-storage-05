# circle.py
import math

def circle_area(radius):
    return math.pi * radius ** 2

# rectangle.py
def rectangle_area(length, width):
    return length * width

class ahmtr:
    def __init__(self):
        self.name = 'ahmed'
