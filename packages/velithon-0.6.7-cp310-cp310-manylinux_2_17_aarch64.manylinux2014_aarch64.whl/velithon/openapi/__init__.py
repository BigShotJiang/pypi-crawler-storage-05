from .docs import swagger_generate  # noqa: D104

__all__ = [
    'swagger_generate',
]
