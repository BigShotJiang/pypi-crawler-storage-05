//! zizmor's JSON output formats.

pub(crate) mod v1;
