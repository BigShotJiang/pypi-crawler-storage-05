```bash
cd third_party/msit/msit
# 2. 安装 msit 包
pip install .
# 3. 通过以下命令，查看组件名，根据业务需求安装相应的组件
msit install -h
# 4. 如果需要安装llm：
msit install surgeon
```