<pre>
  ___     ___ __   __   ______                                          _    _ ___  ___ _____
 / _ \   /   |\ \ / /   | ___ \                                        | |  | ||  \/  |/  ___|
/ /_\ \ / /| | \ V /    | |_/ /  ___   __ _   __ _  ___  _   _  ___    | |  | || .  . |\ `--.
|  _  |/ /_| | /   \    |  __/  / _ \ / _` | / _` |/ __|| | | |/ __|   | |/\| || |\/| | `--. \
| | | |\___  |/ /^\ \   | |    |  __/| (_| || (_| |\__ \| |_| |\__ \   \  /\  /| |  | |/\__/ /
\_| |_/    |_/\/   \/   \_|     \___| \__, | \__,_||___/ \__,_||___/    \/  \/ \_|  |_/\____/
                                       __/ |
                                      |___/
</pre>

<p align="left">
    <img src="https://img.shields.io/pypi/l/a4x-pegasus-wms.svg?logo=apache&color=blue&label=Licence"/>
    <img src="https://img.shields.io/pypi/v/a4x-pegasus-wms.svg?label=Latest"/>
    <img src="https://img.shields.io/pypi/pyversions/a4x-pegasus-wms.svg?logo=python"/>
    <img src="https://img.shields.io/pypi/dm/a4x-pegasus-wms?logo=pypi&color=green&label=PyPI%20Downloads"/>
    <img src="https://img.shields.io/badge/Code%20Style-black-blue"/>
    <img src="https://img.shields.io/github/contributors-anon/pegasus-isi/a4x-pegasus-wms?color=green&label=Contributors"/>
</p>

# References

- [Pegasus Workflow Management System](https://pegasus.isi.edu)

# Funding

A4X Pegasus WMS is funded by National Science Foundation (NSF) under awards [2331152](https://www.nsf.gov/awardsearch/showAward?AWD_ID=2331152), [2331153](https://www.nsf.gov/awardsearch/showAward?AWD_ID=2331153).
