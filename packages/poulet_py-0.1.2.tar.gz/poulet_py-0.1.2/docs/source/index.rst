Welcome to Poulet Py documentation
==================================

.. raw:: html

   <div class="welcome-content">
     <p>Your project description goes here.</p>
     <p>Get started by exploring the navigation bar above.</p>
   </div>

.. toctree::
   :hidden:
   
   getting_started/index
   api/index
   .. user_guide
   .. development
   .. release_notes

