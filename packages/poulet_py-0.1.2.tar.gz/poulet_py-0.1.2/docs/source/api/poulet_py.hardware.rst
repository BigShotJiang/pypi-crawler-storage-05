poulet\_py.hardware package
===========================

.. automodule:: poulet_py.hardware
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   poulet_py.hardware.camera
   poulet_py.hardware.stimulator
