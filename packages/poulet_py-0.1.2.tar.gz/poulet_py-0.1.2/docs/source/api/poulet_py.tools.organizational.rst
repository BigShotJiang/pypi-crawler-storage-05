poulet\_py.tools.organizational module
======================================

.. automodule:: poulet_py.tools.organizational
   :members:
   :show-inheritance:
   :undoc-members:
