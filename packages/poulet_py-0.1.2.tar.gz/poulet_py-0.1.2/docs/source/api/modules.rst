API reference
=============

.. toctree::
   :maxdepth: 4

   poulet_py
