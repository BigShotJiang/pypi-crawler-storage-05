API reference
=============

.. toctree::
   :maxdepth: 2

   poulet_py