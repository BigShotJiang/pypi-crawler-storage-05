poulet\_py.hardware.camera.basler module
========================================

.. automodule:: poulet_py.hardware.camera.basler
   :members:
   :show-inheritance:
   :undoc-members:
