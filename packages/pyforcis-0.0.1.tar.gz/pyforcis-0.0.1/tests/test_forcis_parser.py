import pytest
pytest.skip('forcis_parser removed in minimal build', allow_module_level=True)