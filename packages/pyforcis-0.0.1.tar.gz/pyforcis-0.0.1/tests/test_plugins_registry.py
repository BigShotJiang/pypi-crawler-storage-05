import pytest
pytest.skip('plugins removed in minimal build', allow_module_level=True)