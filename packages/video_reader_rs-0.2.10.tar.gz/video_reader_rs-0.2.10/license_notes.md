# License Notes

While video_reader-rs itself is MIT-licensed, some FFmpeg binaries with (L)GPL
licenses are distributed with the Python wheels. As a result, FFmpeg's GPL
licenses are included here for completeness.

For more information about FFmpeg licensing, see the general
[LICENSE.md](https://git.launchpad.net/ubuntu/+source/ffmpeg/tree/LICENSE.md)
file, or the
[copyright](https://git.launchpad.net/ubuntu/+source/ffmpeg/tree/debian/copyright)
file for details about the Ubuntu/Debian-specific FFmpeg licensing implications.
