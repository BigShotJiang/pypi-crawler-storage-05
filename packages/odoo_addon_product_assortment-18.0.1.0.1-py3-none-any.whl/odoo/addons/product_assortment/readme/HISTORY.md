## 10.0.1.0.0 (2018-08-27)

- \[10.0\]\[ADD\] productassortment

## 12.0.1.0.0 (2019-06-03)

- \[12.0\]\[MIG\] productassortment

## 14.0.1.0.0 (2019-06-03)

- \[14.0\]\[MIG\] productassortment

## 16.0.1.0.0 (2022-09-15)

- \[16.0\]\[MIG\] productassortment
