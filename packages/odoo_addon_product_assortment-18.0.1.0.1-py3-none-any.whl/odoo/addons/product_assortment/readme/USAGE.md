To use this module, you need to:

1.  Enter the menu through Product Assortment Icon
2.  Create a new filter where you can define your domain and add allowed
    and restricted products
