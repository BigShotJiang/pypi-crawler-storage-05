# SatNOGS DB API Client

SatNOGS DB is a transmitter suggestions and crowd-sourcing app.

This is the API client.

## License

[![license](https://img.shields.io/badge/license-AGPL%203.0-6672D8.svg)](LICENSE)
[![Libre Space Foundation](https://img.shields.io/badge/%C2%A9%202014--2021-Libre%20Space%20Foundation-6672D8.svg)](https://librespacefoundation.org/)
