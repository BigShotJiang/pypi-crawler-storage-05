import os,sys
import time

import socketio
import threading
import struct
Uninitialized = type("Uninitialized", (), {})()

def pp():
   x=b=c=q=x=t=Uninitialized
   print(x,b,c,q,x,t)
                         
if __name__ == '__main__':
   pp()
   
        