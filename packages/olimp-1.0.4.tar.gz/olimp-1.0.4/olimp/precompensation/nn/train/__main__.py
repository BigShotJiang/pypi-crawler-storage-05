from .train import main

main()
