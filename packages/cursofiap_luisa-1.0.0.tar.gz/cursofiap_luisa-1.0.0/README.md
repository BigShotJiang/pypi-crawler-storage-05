# Curso FIAP
A simples library to demonstrate my knowledge

# Commands 
pip install setuptools wheel twine

## Licença
Distribuído sob a licença MIT