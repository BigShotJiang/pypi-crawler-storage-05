RDA python package to manage RDA ICOADS datasets.

To dynamically generate a PDF readme fitting for each data subset,
a Linux commandline utility program, wkhtmltopdf, must be installed (via
https://wkhtmltopdf.org/index.html).
