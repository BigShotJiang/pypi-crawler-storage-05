"""
Entry point for the TBR Deal Finder package when run in the flet app distro.
"""
from tbr_deal_finder.gui.main import main

if __name__ == "__main__":
    main()