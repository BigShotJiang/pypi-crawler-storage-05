from pathlib import Path

__VERSION__ = "0.3.2"

QUERY_PATH = Path(__file__).parent.joinpath("queries")
