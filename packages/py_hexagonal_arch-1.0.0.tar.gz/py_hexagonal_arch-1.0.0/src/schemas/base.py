"""
Base Schema module
"""

from sqlalchemy.ext.declarative import declarative_base


BaseSchema = declarative_base()