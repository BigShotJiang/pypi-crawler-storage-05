.. This file is made to explain Instrument Uncertainty. 



