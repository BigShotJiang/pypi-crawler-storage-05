from mindee.product.fr.health_card.health_card_v1 import HealthCardV1
from mindee.product.fr.health_card.health_card_v1_document import (
    HealthCardV1Document,
)
