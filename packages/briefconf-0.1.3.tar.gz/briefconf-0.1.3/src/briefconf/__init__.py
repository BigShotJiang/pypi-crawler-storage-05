
from .config_handle import BriefConfig

__all__ = ["BriefConfig"]
