"""
amap_route_planner - 一个基于高德API的MCP路线规划服务器。
"""

__version__ = "0.1.0"
# 不再暴露 draw_route，也无需 __all__
