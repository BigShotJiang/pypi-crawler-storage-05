from abc import ABC


class Strategy(ABC): ...


__all__ = [
    "Strategy"
]
