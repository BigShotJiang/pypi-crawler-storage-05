# this is a placeholder for poetry-dynamic-versioning (see pyproject.toml)
__version__ = "0.3.2"
