"""MCP Agent Cloud logout command."""

from .main import logout

__all__ = ["logout"]
