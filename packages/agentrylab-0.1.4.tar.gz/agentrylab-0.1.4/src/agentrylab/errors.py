# Typed exceptions
class AgentryLabError(Exception):
    pass
