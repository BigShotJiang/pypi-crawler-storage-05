# Minimal custom tool example
