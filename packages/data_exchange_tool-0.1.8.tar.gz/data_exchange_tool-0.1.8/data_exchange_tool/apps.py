from django.apps import AppConfig


class ModelDataExchangeToolConfig(AppConfig):
    name = "data_exchange_tool"
