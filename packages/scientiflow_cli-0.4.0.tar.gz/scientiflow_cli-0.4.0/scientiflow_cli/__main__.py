from scientiflow_cli.main import main


main()