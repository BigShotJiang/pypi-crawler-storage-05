## [2.0.5] - 2025-09-09

### Added
- Add changelog.md
- Add uv and release workflow
- Add uv and release workflow

### Changed
- Switch build to uv by @tnijboer in [#18](https://github.com/clearskies-py/clearskies/pull/18)
- Reuse readme.md
- Switch build to uv by @cmancone
- Workflows by @cmancone in [#17](https://github.com/clearskies-py/clearskies/pull/17)
- Merge pull request #14 from clearskies-py/docs-switch by @cmancone in [#14](https://github.com/clearskies-py/clearskies/pull/14)
- R2G? by @cmancone
- Moving along by @cmancone
- Bug fix for error message by @cmancone

### Fixed
- Allow list for json default and setable by @cmancone in [#16](https://github.com/clearskies-py/clearskies/pull/16)
- Set default and setable for json column to any config
- Allow list for json default and setable
- Right include for readme
- Docs missing folder
- Pyproject.toml
- Set input/output schema to type[Schema] by @cmancone in [#15](https://github.com/clearskies-py/clearskies/pull/15)
- Set input/output schema to type[Schema]

### Removed
- Remove dupes by @cmancone

