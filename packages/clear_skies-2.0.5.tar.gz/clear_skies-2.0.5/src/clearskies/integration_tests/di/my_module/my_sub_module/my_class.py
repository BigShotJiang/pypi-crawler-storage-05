class MyClass:
    count = 5
