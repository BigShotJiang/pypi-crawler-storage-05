from .my_class import MyClass
