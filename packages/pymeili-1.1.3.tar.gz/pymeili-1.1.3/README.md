### INTRODUCTION
> pymeili.為美麗而生 [remake edition]

pymeili is a module to beautify your python plot with more simple way. the design idea is from Navigraph aeronautical chart.

### INSTALLATION & USAGE
For more information, please visit our hosted github webpage: https://github.com/VVVICTORZHOU/pymeili_resource
