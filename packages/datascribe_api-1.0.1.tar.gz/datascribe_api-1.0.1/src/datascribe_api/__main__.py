"""Main entry point for the DataScribe CLI application."""

from datascribe_api.cli import app

app(prog_name="datascribe-cli")
