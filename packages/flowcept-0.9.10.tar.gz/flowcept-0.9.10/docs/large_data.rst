# Handling Large Data

As a provenance-based tool, Flowcept leverages provenance data (typically seen as metadata) to keep track of data, including large datasets or data files, workflows, and ML models.

There are various ways to handle large data in Flowcept

## Sending large blob data as messages

### Sending as files

Importance of MimeType and the custom_metadata for files 

## Managing blob data

## Managing PyTorch models





