"""Streamlit Subpackage."""

PAGE_TITLE = "Flowcept Agent Chat"
DEFAULT_AGENT_NAME = "FlowceptAgent"
AI = "🤖"
