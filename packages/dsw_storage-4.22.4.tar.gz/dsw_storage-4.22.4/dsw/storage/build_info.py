# Generated file
# - do not overwrite
# - do not include in git
from collections import namedtuple

BuildInfo = namedtuple(
    'BuildInfo',
    ['version', 'built_at', 'sha', 'branch', 'tag'],
)

BUILD_INFO = BuildInfo(
    version='v4.22.4~9faf20e',
    built_at='2025-09-12 07:54:40Z',
    sha='9faf20e8fb281e1353c37ef220da1e6a09e3004a',
    branch='HEAD',
    tag='v4.22.4',
)
