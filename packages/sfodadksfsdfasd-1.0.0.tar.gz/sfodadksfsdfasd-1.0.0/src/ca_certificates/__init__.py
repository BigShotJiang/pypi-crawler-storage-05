__version__ = "1.0.0"

def info():
    return "This is a dummy sfodadksfsdfasd package for PyPI."
