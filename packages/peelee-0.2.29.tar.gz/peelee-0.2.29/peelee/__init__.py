from peelee.peelee import Palette

all = Palette