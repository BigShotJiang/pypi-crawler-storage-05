"""
.. include:: ../../README.md
   :start-line: 1
"""

from .config import AuthenticationConfiguration as AuthenticationConfiguration
