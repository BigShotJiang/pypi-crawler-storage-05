from .checker import check_spf, SPFCheck, SPFResult

__all__ = [
    "check_spf",
    "SPFCheck",
    "SPFResult",
]
