class SPFCheckerError(Exception):
    """Base errror."""


class Permerror(Exception):
    pass


class Temperror(Exception):
    pass
