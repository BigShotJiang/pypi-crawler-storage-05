***************************
Bases
***************************

Abstract Base
======================

.. autoclass:: craft_providers.Base
   :show-inheritance:
   :members:

Buildd Base
========================

.. autoclass:: craft_providers.bases.BuilddBase
   :show-inheritance:
   :members:
