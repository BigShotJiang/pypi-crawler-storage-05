***************************
Executors
***************************

Abstract Executor
======================

.. autoclass:: craft_providers.Executor
   :show-inheritance:
   :members:

LXD Executor
========================

.. autoclass:: craft_providers.lxd.LXDInstance
   :show-inheritance:
   :members:

Multipass Executor
========================

.. autoclass:: craft_providers.multipass.MultipassInstance
   :show-inheritance:
   :members:
