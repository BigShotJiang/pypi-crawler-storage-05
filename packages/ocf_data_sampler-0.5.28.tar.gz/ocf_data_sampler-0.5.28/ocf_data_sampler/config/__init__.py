"""Configuration model"""

from ocf_data_sampler.config.model import Configuration, InputData
from ocf_data_sampler.config.save import save_yaml_configuration
from ocf_data_sampler.config.load import load_yaml_configuration