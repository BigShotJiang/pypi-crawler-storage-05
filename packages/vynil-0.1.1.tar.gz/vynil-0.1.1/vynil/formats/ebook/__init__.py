from .ebook import Ebook

__all__ = ["Ebook"]
