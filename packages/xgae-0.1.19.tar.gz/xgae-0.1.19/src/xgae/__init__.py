if __name__ == "__main__":
    from xgae.engine_cli_app import main

    main()