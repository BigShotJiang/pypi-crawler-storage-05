from .advanced_settings import AdvancedSettingsView  # noqa
from .copy import CopyFormView  # noqa
from .submission_delete import SubmissionDeleteView  # noqa
from .submission_list import SubmissionListView  # noqa
