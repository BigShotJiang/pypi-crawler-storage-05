from __future__ import annotations

__version__ = "1.0.1"
__title__ = __project__ = "Visflow"
