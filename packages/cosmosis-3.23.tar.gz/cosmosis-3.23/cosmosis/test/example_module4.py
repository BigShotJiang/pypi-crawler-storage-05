import numpy as np

def setup(options):
    return {}

def execute(block, config):
    p3 = block['parameters', 'p3']
    # do nothing except read
    return 0
