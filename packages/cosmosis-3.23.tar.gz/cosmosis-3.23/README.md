Documentation
=============

You can find full documentation, including installation instructions, at https://cosmosis.readthedocs.io

For GitHub Copilot coding agents, see [`.github/copilot-instructions.md`](.github/copilot-instructions.md) for comprehensive setup and usage instructions.
