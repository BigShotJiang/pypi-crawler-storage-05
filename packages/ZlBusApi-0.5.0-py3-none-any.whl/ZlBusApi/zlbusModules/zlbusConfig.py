# 将 C 预定义宏直接映射为 Python 常量，保持原注释
UHL_LEVEL_EN = 1   # /* 高级指令-用户设置 */
UDG_LEVEL_EN = 1   # /* Dongle指令-用户设置 */
FDG_LEVEL_EN = 1   # /* Dongle指令-厂家设置 */
