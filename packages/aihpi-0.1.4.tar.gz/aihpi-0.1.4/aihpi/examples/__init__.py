"""Usage examples for aihpi."""

# Examples are importable but not exposed in __all__ 
# Users should import specific example functions they need