from .fandom_scraper import scrape_fandom
from .witcher_instruct_gather import instructions_into_conv

__all__ = ["scrape_fandom", "instructions_into_conv"]
