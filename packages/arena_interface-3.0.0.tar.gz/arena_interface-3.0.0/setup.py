"""Python interface to the Reiser lab ArenaController."""
# This file is generated automatically from metadata
# File edits may be overwritten!
from setuptools import setup


if __name__ == '__main__':
    setup()
