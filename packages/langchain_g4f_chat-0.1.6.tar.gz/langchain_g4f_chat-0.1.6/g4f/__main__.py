from g4f11.cli import main

if __name__ == "__main__":
    main()