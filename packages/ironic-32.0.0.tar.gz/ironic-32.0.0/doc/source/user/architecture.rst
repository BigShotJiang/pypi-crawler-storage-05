================================
Understanding Bare Metal service
================================

This page has moved.

As part of the Ironic documentation improvements, this content has
been consolidated. You can now find the updated content in the
:doc:`Overview of Ironic </install/get_started>` section.

