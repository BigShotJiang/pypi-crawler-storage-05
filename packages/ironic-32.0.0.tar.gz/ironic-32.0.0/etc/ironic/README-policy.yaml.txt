To generate the sample policy.yaml file, run the following command from the top
level of the repo:

    tox -egenpolicy

For a pre-generated example of the latest policy.yaml, see:

    https://docs.openstack.org/ironic/latest/configuration/sample-policy.html
