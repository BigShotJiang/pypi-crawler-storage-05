"""Input and Output package responsible for the behaviour of reading and writing."""
