"""Package to define data quality processes available in the lakehouse engine."""
