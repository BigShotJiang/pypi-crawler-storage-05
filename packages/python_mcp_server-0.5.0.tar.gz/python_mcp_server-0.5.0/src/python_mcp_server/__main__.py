from .server import main as cli


if __name__ == "__main__":  # pragma: no cover
    cli()
