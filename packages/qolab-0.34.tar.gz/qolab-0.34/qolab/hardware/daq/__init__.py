"""DAQ classes."""

from .labjack_ue9 import LabJackUE9

__all__ = ["LabJackUE9"]
