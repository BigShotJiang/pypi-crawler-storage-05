
from setuptools import setup

setup(
    name="wpdwf",
    version="0.0.1",
    packages=["wpdwf"]
    )
