__version__ = "2025.5.0"

from ribasim_api.ribasim_api import RibasimApi

__all__ = ["RibasimApi"]
