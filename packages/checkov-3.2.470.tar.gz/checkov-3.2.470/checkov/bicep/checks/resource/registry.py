from checkov.bicep.checks.resource.base_registry import Registry

registry = Registry()
