This project follows [Django's Code of Conduct](https://www.djangoproject.com/conduct/).
