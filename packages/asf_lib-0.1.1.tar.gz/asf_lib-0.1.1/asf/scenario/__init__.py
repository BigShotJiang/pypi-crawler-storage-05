from asf.scenario.aslib_reader import read_aslib_scenario

__all__ = ["read_aslib_scenario"]
