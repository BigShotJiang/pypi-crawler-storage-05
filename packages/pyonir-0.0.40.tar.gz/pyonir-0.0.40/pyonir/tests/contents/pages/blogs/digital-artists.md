title: The Digital artist in the Modern era
author: ChatGPT
entries: $dir/pages/blogs
===
Modern digital artists are creative visionaries who leverage advanced technology and software to produce compelling art in a variety of styles and mediums.