agent_mode=True
prompt_engineering=True
max_steps=30
hide_tools_order=False
default_bible="NET"
max_semantic_matches=15