# virajchoudhary_nlp/preprocessing.py

import string
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk import pos_tag

# download these once
# import nltk
# nltk.download('punkt')
# nltk.download('stopwords')
# nltk.download('wordnet')
# nltk.download('averaged_perceptron_tagger')

def to_lowercase(text):
    """Converts a string to lowercase."""
    return text.lower()

def remove_punctuation(text):
    """Removes punctuation from a string."""
    return text.translate(str.maketrans('', '', string.punctuation))

def tokenize_words(text):
    """Tokenizes a string into words."""
    return word_tokenize(text)

def remove_stopwords(tokens):
    """Removes English stopwords from a list of tokens."""
    stop_words = set(stopwords.words('english'))
    return [word for word in tokens if word.lower() not in stop_words]

def stem_words(tokens):
    """Stems a list of tokens using PorterStemmer."""
    stemmer = PorterStemmer()
    return [stemmer.stem(word) for word in tokens]

def lemmatize_words(tokens):
    """Lemmatizes a list of tokens using WordNetLemmatizer."""
    lemmatizer = WordNetLemmatizer()
    return [lemmatizer.lemmatize(word) for word in tokens]

def get_pos_tags(tokens):
    """Gets Part-of-Speech tags for a list of tokens."""
    return pos_tag(tokens)
