# virajchoudhary_nlp/features.py

from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
import pandas as pd

def bow_vectorize(corpus):
    """
    Converts a corpus of text documents into a Bag-of-Words feature matrix.

    Args:
        corpus (list of str): A list of text documents.

    Returns:
        pandas.DataFrame: A DataFrame representing the BoW matrix.
        list: The vocabulary of features.
    """
    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(corpus)
    feature_names = vectorizer.get_feature_names_out()
    df = pd.DataFrame(X.toarray(), columns=feature_names)
    return df, feature_names

def tfidf_vectorize(corpus):
    """
    Converts a corpus of text documents into a TF-IDF feature matrix.

    Args:
        corpus (list of str): A list of text documents.

    Returns:
        pandas.DataFrame: A DataFrame representing the TF-IDF matrix.
        list: The vocabulary of features.
    """
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(corpus)
    feature_names = vectorizer.get_feature_names_out()
    df = pd.DataFrame(X.toarray(), columns=feature_names)
    return df, feature_names
