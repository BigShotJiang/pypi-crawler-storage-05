# setup.py

import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="virajchoudhary-nlp-kit", 
    version="0.0.1",
    author="Viraj Choudhary",
    author_email="virajc188@gmail.com",
    description="A personal toolkit for NLP lab experiments.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/virajchoudhary/nlp_toolkit",
    packages=setuptools.find_packages(),
    install_requires=[
        'nltk',
        'scikit-learn',
        'pandas',
        'requests',
        'beautifulsoup4',
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
