"""Make the CLI runnable using python -m ultrasphere_harmonics."""

from .cli import app

app(prog_name="ultrasphere-harmonics")
