This module creates the link between the purchase requisition and dropshipping applications.

It sets the shipping address and picking type on purchase orders created from purchase agreements,
and links them with the originating sale order.