import pytest
pytest.skip('predicates removed in minimal build', allow_module_level=True)