from enum import Enum


class EmbeddingProviderType(Enum):
    FASTEMBED = "fastembed"
    VOYAGE_AI = "voyageai"
