class ZenithTradeError(Exception):
    """Base class for all Zenith Trade client errors."""
    pass