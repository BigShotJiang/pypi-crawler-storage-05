from dataclasses import dataclass

@dataclass
class Brand:
    id: int
    description: str