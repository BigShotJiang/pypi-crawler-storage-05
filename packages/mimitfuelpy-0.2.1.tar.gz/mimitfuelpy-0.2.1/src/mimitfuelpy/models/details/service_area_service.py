from dataclasses import dataclass

@dataclass
class ServiceAreaService:
    id: int
    description: str