from dataclasses import dataclass

@dataclass
class Town:
    id: str
    description: str