from dataclasses import dataclass

@dataclass
class Province:
    id: str
    description: str