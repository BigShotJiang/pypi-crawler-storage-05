from dataclasses import dataclass

@dataclass
class PointMap:
    lat: float
    lng: float