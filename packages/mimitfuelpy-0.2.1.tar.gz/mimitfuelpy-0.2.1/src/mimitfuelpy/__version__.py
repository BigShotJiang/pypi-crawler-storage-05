"""Version information for mimitfuelpy."""

__version__ = "0.2.1"
__author__ = "fpetranzan"
__email__ = "contact-me@fpetranzan.me"