::: xmllib.general_functions
