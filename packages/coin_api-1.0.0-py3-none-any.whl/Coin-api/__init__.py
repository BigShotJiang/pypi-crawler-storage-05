"""
Coin API Package

A Python package for getting cryptocurrency prices from CoinMarketCap.
"""

from .COIN_API import coin

__version__ = "1.0.0"
__author__ = "faizan code"
__email__ = "thetriquetrathetriquetradeveloper@gmail.com"

__all__ = ["coin"]