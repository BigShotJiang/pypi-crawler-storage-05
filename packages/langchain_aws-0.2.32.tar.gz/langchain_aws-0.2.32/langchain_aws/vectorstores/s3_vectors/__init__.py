from .base import AmazonS3Vectors

__all__ = [
    "AmazonS3Vectors",
]
