"""
Loki log query service for LogMCP server
"""

import requests
from datetime import datetime, timedelta
from typing import Dict, Any, List, Union, Optional

from ..config import config
from ..logger import logger


class LokiService:
    """Loki log query service class"""

    def __init__(self):
        self.gateway_url = None
        self.timeout = 30
        self.default_limit = 1000
        self.is_initialized = False

    def initialize(self):
        """Initialize Loki service configuration"""
        try:
            self.gateway_url = config.get_loki_gateway_url()
            self.timeout = config.get('loki_timeout', 30)
            self.default_limit = config.get('loki_default_limit', 1000)
            self.is_initialized = True
            
            logger.info(f"Loki service initialized, gateway URL: {self.gateway_url}")
            
        except Exception as e:
            logger.error_with_traceback("Failed to initialize Loki service", e)
            raise

    def _ensure_initialized(self):
        """Ensure service is initialized"""
        if not self.is_initialized:
            self.initialize()

    def _parse_keywords_input(self, keywords: Union[str, List[str]]) -> List[str]:
        """Parse keywords input into list"""
        if isinstance(keywords, str):
            # Split by comma and strip whitespace
            return [kw.strip() for kw in keywords.split(',') if kw.strip()]
        elif isinstance(keywords, list):
            return [str(kw).strip() for kw in keywords if str(kw).strip()]
        else:
            return []

    def _build_loki_query(self, namespace: str, service_name: str, keywords: List[str]) -> str:
        """Build Loki LogQL query"""
        # Base query with namespace and service filters
        base_query = f'{{namespace="{namespace}", app="{service_name}"}}'
        
        # Add keyword filters
        if keywords:
            keyword_filters = []
            for keyword in keywords:
                # Escape special characters in keywords
                escaped_keyword = keyword.replace('"', '\\"')
                keyword_filters.append(f'|~ "(?i){escaped_keyword}"')
            
            query = base_query + ''.join(keyword_filters)
        else:
            query = base_query
            
        return query

    def _format_query_result(self, result: Dict[str, Any], env: str, 
                           keywords: List[str], start_time: datetime, 
                           end_time: datetime) -> str:
        """Format Loki query result for display"""
        try:
            if result.get('status') != 'success':
                return f"Query failed: {result.get('error', 'Unknown error')}"
            
            data = result.get('data', {})
            result_type = data.get('resultType', '')
            results = data.get('result', [])
            
            if not results:
                return f"No logs found for keywords: {', '.join(keywords)} in environment: {env}"
            
            # Format results
            formatted_lines = []
            formatted_lines.append(f"=== Loki Query Results ===")
            formatted_lines.append(f"Environment: {env}")
            formatted_lines.append(f"Keywords: {', '.join(keywords)}")
            formatted_lines.append(f"Time Range: {start_time.strftime('%Y-%m-%d %H:%M:%S')} - {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
            formatted_lines.append(f"Result Type: {result_type}")
            formatted_lines.append(f"Total Streams: {len(results)}")
            formatted_lines.append("")
            
            total_entries = 0
            for stream in results:
                stream_labels = stream.get('stream', {})
                values = stream.get('values', [])
                total_entries += len(values)
                
                if values:
                    formatted_lines.append(f"--- Stream: {stream_labels} ---")
                    for timestamp, log_line in values[:10]:  # Show first 10 entries per stream
                        # Convert nanosecond timestamp to readable format
                        try:
                            ts = int(timestamp) / 1_000_000_000
                            dt = datetime.fromtimestamp(ts)
                            formatted_lines.append(f"[{dt.strftime('%Y-%m-%d %H:%M:%S')}] {log_line}")
                        except (ValueError, OSError):
                            formatted_lines.append(f"[{timestamp}] {log_line}")
                    
                    if len(values) > 10:
                        formatted_lines.append(f"... and {len(values) - 10} more entries")
                    formatted_lines.append("")
            
            formatted_lines.append(f"=== Summary ===")
            formatted_lines.append(f"Total Log Entries: {total_entries}")
            
            return '\n'.join(formatted_lines)
            
        except Exception as e:
            logger.error_with_traceback("Error formatting query result", e)
            return f"Error formatting result: {str(e)}"

    def query_keyword_logs(self, env: str, keywords: Union[str, List[str]],
                          service_name: Optional[str] = None,
                          namespace: Optional[str] = None,
                          limit: Optional[int] = None) -> str:
        """
        Query logs containing keywords (last 30 days)

        Args:
            env: Environment name (test/dev/prod)
            keywords: Search keywords (string or list)
            service_name: Service name, defaults to zkme-token
            namespace: Namespace, defaults to environment-based inference
            limit: Result limit, defaults to 1000

        Returns:
            Formatted log query result
        """
        try:
            # Calculate time 30 days ago
            end_time = datetime.now()
            start_time = end_time - timedelta(days=30)

            return self.query_range_logs(
                env=env,
                start_time=start_time,
                end_time=end_time,
                keywords=keywords,
                service_name=service_name,
                namespace=namespace,
                limit=limit
            )

        except Exception as e:
            logger.error_with_traceback("Loki keyword query error", e)
            return f"Query failed: {str(e)}"

    def query_range_logs(self, env: str, start_time: datetime, end_time: datetime,
                        keywords: Union[str, List[str]], service_name: Optional[str] = None,
                        namespace: Optional[str] = None,
                        limit: Optional[int] = None) -> str:
        """
        Query logs containing keywords within specified time range

        Args:
            env: Environment name
            start_time: Start time
            end_time: End time
            keywords: Search keywords (string or list)
            service_name: Service name
            namespace: Namespace
            limit: Result limit

        Returns:
            Formatted log query result
        """
        try:
            # Parameter processing
            if not service_name:
                service_name = config.get('default_service', 'zkme-token')
            if not namespace:
                namespace = config.get_env_namespace(env)
            if not limit:
                limit = self.default_limit

            # Parse keywords
            keywords_list = self._parse_keywords_input(keywords)
            if not keywords_list:
                return "Error: Keywords cannot be empty"

            # Build Loki query statement
            query = self._build_loki_query(namespace, service_name, keywords_list)

            # Build query parameters
            params = {
                'query': query,
                'start': start_time.strftime('%Y-%m-%dT%H:%M:%SZ'),
                'end': end_time.strftime('%Y-%m-%dT%H:%M:%SZ'),
                'limit': str(limit)
            }

            # Execute query
            result = self._execute_loki_query(params)

            # Format result
            return self._format_query_result(result, env, keywords_list, start_time, end_time)

        except Exception as e:
            logger.error_with_traceback("Loki range query error", e)
            return f"Query failed: {str(e)}"

    def query_range_logs_by_dates(self, env: str, start_date: str, end_date: str,
                                 keywords: Union[str, List[str]], service_name: Optional[str] = None,
                                 namespace: Optional[str] = None,
                                 limit: Optional[int] = None) -> str:
        """
        Query logs by date strings (convenient for MCP calls)

        Args:
            env: Environment name
            start_date: Start date (YYYYMMDD format)
            end_date: End date (YYYYMMDD format)
            keywords: Search keywords (string or list)
            service_name: Service name
            namespace: Namespace
            limit: Result limit

        Returns:
            Formatted log query result
        """
        try:
            # Parse date strings
            start_time = datetime.strptime(start_date, '%Y%m%d')
            end_time = datetime.strptime(end_date, '%Y%m%d')
            # Set end time to 23:59:59 of that day
            end_time = end_time.replace(hour=23, minute=59, second=59)

            return self.query_range_logs(
                env=env,
                start_time=start_time,
                end_time=end_time,
                keywords=keywords,
                service_name=service_name,
                namespace=namespace,
                limit=limit
            )

        except ValueError as e:
            return f"Date format error: {str(e)}, please use YYYYMMDD format"
        except Exception as e:
            logger.error_with_traceback("Loki date query error", e)
            return f"Query failed: {str(e)}"

    def _execute_loki_query(self, params: Dict[str, str]) -> Dict[str, Any]:
        """
        Execute Loki HTTP API query

        Args:
            params: Query parameters

        Returns:
            Loki API response result
        """
        try:
            # Ensure service is initialized
            self._ensure_initialized()

            # Build query URL
            url = f"{self.gateway_url}/loki/api/v1/query_range"

            logger.info(f"Executing Loki query: {url}")
            logger.debug(f"Query parameters: {params}")

            # Send HTTP request
            response = requests.get(
                url,
                params=params,
                timeout=self.timeout,
                headers={'Content-Type': 'application/json'}
            )

            # Check response status
            response.raise_for_status()

            # Parse JSON response
            result = response.json()

            logger.info(f"Loki query successful, status: {result.get('status')}")
            return result

        except requests.exceptions.RequestException as e:
            logger.error_with_traceback("Loki HTTP request error", e)
            return {
                'status': 'error',
                'error': f'HTTP request failed: {str(e)}'
            }
        except Exception as e:
            logger.error_with_traceback("Loki query execution error", e)
            return {
                'status': 'error',
                'error': f'Query execution failed: {str(e)}'
            }


# Global Loki service instance
loki_service = LokiService()
