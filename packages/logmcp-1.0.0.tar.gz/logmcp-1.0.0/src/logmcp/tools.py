"""
MCP tools implementation for LogMCP server
"""

from typing import Optional
from fastmcp import FastMCP, Context

from .services import loki_service
from .logger import logger


def register_tools(mcp: FastMCP) -> None:
    """Register MCP tools with the FastMCP server"""
    
    @mcp.tool()
    async def loki_keyword_query(
        env: str,
        keywords: str,
        service_name: Optional[str] = "zkme-token",
        namespace: Optional[str] = None,
        limit: Optional[int] = 1000,
        ctx: Optional[Context] = None
    ) -> str:
        """
        Query logs containing keywords through Loki (last 30 days)
        
        Args:
            env: Environment name (e.g.: test, dev, prod)
            keywords: Search keywords (comma-separated for multiple keywords)
            service_name: Service name (optional, defaults to zkme-token)
            namespace: Loki namespace (optional, defaults to environment-based inference)
            limit: Result limit (optional, defaults to 1000)
            ctx: MCP context (automatically injected)
            
        Returns:
            Formatted log query result
        """
        try:
            if ctx:
                await ctx.info(f"Starting Loki keyword query for env: {env}, keywords: {keywords}")
            
            logger.info(f"MCP loki_keyword_query called: env={env}, keywords={keywords}, service={service_name}")
            
            # Validate required parameters
            if not env:
                error_msg = "Environment parameter is required"
                if ctx:
                    await ctx.error(error_msg)
                return error_msg
                
            if not keywords:
                error_msg = "Keywords parameter is required"
                if ctx:
                    await ctx.error(error_msg)
                return error_msg
            
            # Execute query
            result = loki_service.query_keyword_logs(
                env=env,
                keywords=keywords,
                service_name=service_name,
                namespace=namespace,
                limit=limit
            )
            
            if ctx:
                await ctx.info(f"Loki keyword query completed successfully")
            
            return result
            
        except Exception as e:
            error_msg = f"Loki keyword query failed: {str(e)}"
            logger.error_with_traceback("MCP Loki keyword query error", e)
            if ctx:
                await ctx.error(error_msg)
            return error_msg
    
    @mcp.tool()
    async def loki_range_query(
        env: str,
        start_date: str,
        end_date: str,
        keywords: str,
        service_name: Optional[str] = "zkme-token",
        namespace: Optional[str] = None,
        limit: Optional[int] = 1000,
        ctx: Optional[Context] = None
    ) -> str:
        """
        Query logs containing keywords within specified time range through Loki
        
        Args:
            env: Environment name (e.g.: test, dev, prod)
            start_date: Start date (YYYYMMDD format)
            end_date: End date (YYYYMMDD format)
            keywords: Search keywords (comma-separated for multiple keywords)
            service_name: Service name (optional, defaults to zkme-token)
            namespace: Loki namespace (optional, defaults to environment-based inference)
            limit: Result limit (optional, defaults to 1000)
            ctx: MCP context (automatically injected)
            
        Returns:
            Formatted log query result
        """
        try:
            if ctx:
                await ctx.info(f"Starting Loki range query for env: {env}, dates: {start_date}-{end_date}")
            
            logger.info(f"MCP loki_range_query called: env={env}, start={start_date}, end={end_date}, keywords={keywords}")
            
            # Validate required parameters
            if not env:
                error_msg = "Environment parameter is required"
                if ctx:
                    await ctx.error(error_msg)
                return error_msg
                
            if not start_date or not end_date:
                error_msg = "Start date and end date parameters are required"
                if ctx:
                    await ctx.error(error_msg)
                return error_msg
                
            if not keywords:
                error_msg = "Keywords parameter is required"
                if ctx:
                    await ctx.error(error_msg)
                return error_msg
            
            # Execute query
            result = loki_service.query_range_logs_by_dates(
                env=env,
                start_date=start_date,
                end_date=end_date,
                keywords=keywords,
                service_name=service_name,
                namespace=namespace,
                limit=limit
            )
            
            if ctx:
                await ctx.info(f"Loki range query completed successfully")
            
            return result
            
        except Exception as e:
            error_msg = f"Loki range query failed: {str(e)}"
            logger.error_with_traceback("MCP Loki range query error", e)
            if ctx:
                await ctx.error(error_msg)
            return error_msg

    logger.info("MCP tools registered successfully")
