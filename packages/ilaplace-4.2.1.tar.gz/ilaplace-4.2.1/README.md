# iLaplace: A Simple Interface for Powerful Math

**iLaplace** is a lightweight Python wrapper around advanced symbolic and numerical math tools (sympy, numpy & mpmath) that provides a clean and intuitive interface for computing inverse Laplace transforms using Talbot's method.

I created this library to simplify the process of using the inverse Laplace transform, aiming to provide a MATLAB-like experience within Python. This means the output of my code in Python will be compared against a sample calculation in MathWorks MATLAB.

## Why This Library?

  * `mpmath` is powerful but raw and low-level.
  * `sympy` gives symbolic transforms, but not numerical answers.
  * Combining them can be verbose and repetitive.

In short: **You focus on the math, we handle the machinery.**

-----

This library contains two main functions for performing inverse Laplace transform calculations:

1.  `inverse_laplace(F, t)`
2.  `inverse_laplace_fu(F)`

Examples for each function and their corresponding MATLAB outputs are provided below.

## MATLAB vs. Python Comparison

Here is a sample calculation in MATLAB and its equivalent in Python using this library.

### 1st Example

**MATLAB Example**

```matlab
syms s t
X = (s+3)/((s+1)^2 + (s^2+9));
V = vpa(ilaplace(X, s, t));
t0   = 5.2643;
Volt = double(subs(V, t, t0));
disp(Volt)
```

The output in MATLAB is `-0.020100091042301`.

**Python Equivalent with iLaplace**

```python
import iLaplace as il
import sympy as sp
t, s = sp.symbols('t s')
X = (s+3)/((s+1)**2 + (s**2+9))
t0 = 5.2643
Answer = il.inverse_laplace(X, t0)
print(Answer)
```

And the output is `-0.020100091042300372`.

### 2nd Example

**MATLAB Example**

```matlab
syms s t
format long
X = 3 / (s^2 + 3^2);
V = vpa(ilaplace(X, s, t));
t0   = 5.2643;
Volt = double(subs(V, t, t0));
disp(Volt)
```

And the output in MATLAB is `-0.084834643101466`.

**Python Equivalent**

```python
import iLaplace as il
import sympy as sp
import numpy as np
s, t = sp.symbols('s t')
t0 = 5.2643
X = (3) / ((s**2) +  (3**2))
Answer = il.inverse_laplace(X, t0)
print(Answer)
```

The output is `-0.08483425637752962`.

### 3rd Example

**MATLAB Example**

```matlab
syms s t
X = (s + 3) / ((s + 3)^2 + 25) ...
    + 1 / (s + 2)^3 ...
    + log((s + 10) / s);  
V = vpa(ilaplace(X, s, t));
t0   = 5.2643;
Volt = double(subs(V, t, t0));
disp(Volt)
```

And the output in MATLAB is `0.190329629407706`.

**Python Equivalent**

```python
import iLaplace as il
import sympy as sp
t, s = sp.symbols('t s')
t0 = 5.2643
X = ((s + 3) / ((s + 3)**2 + 25)
             + 1 / (s + 2)**3
             + sp.log((s + 10) / s))
Answer = il.inverse_laplace(X, t0)
print(Answer)
```

The output is `0.19032962256026703`.

### 4th Example

**MATLAB Example**

```matlab
syms s t
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
X1 = (s + 3) / ((s + 3)^2 + 25) ...
    + 1 / (s + 2)^3 ...
    + log((s + 10) / s);
X2 = (s+3)/((s+1)^2 + (s^2+9));
X3 = 3 / (s^2 + 3^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
X = X1 + X2 + X3;
V = vpa(ilaplace(X, s, t));
t0   = 5.2643;
Volt = double(subs(V, t, t0));
disp(Volt)
```

And the output in MATLAB is `0.085394895263940`.

**Python Equivalent**

```python
import iLaplace as il
import sympy as sp
t, s = sp.symbols('t s')
t0 = 5.2643
#######################################
X1 = ((s + 3) / ((s + 3)**2 + 25)
             + 1 / (s + 2)**3
             + sp.log((s + 10) / s))
X2 = (s+3)/((s+1)**2 + (s**2+9))
X3 = (3) / ((s**2) +  (3**2))
#######################################
X = X1 + X2 + X3
Answer = il.inverse_laplace(X, t0)
print(Answer)
```

The output is `0.08539527514043704`.

-----

## Usage of `inverse_laplace_fu`

Here is an example of using the `inverse_laplace_fu` function in iLaplace:

**Python Example**

```python
import iLaplace as il
import sympy as sp
import math

t, s = sp.symbols('t s')
X = (s+3)/((s+1)**2 + (s**2+9))
Answer = il.inverse_laplace_fu(X)
print(Answer)

def f(t):
    return (5*math.sqrt(19)*math.exp(-t/2)*math.sin(math.sqrt(19)*t/2)/38 + math.exp(-t/2)*math.cos(math.sqrt(19)*t/2)/2)*sp.Heaviside(t)

def g(t):
    return 0.5*math.exp(-0.5*t)*(math.cos(2.1794494717703367761184909919298*t) + 1.1470786693528088295360478904894*math.sin(2.1794494717703367761184909919298*t))

number = 1
d = f(number) - g(number)
print(d)
```

**Output will be:**

```
-0.020100091042300372
(5*sqrt(19)*exp(-t/2)*sin(sqrt(19)*t/2)/38 + exp(-t/2)*cos(sqrt(19)*t/2)/2)*Heaviside(t)
2.77555756156289e-17
```

-----

## License and Attributions

This project is licensed under the **MIT License**.

It internally utilizes components from the following libraries:

  * `mpmath`
  * `sympy`

All third-party libraries retain their original licenses and attributions.