from ._core import _initialize
_initialize()