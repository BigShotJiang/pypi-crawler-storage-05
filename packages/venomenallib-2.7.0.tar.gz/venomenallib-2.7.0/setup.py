from setuptools import setup

setup(
    name="venomenallib",
    version="2.7.0",
    packages=["venomenallib"],
    package_data={"venomenallib": ["*.so"]},
    description="Advanced data processing utilities",
    install_requires=["requests"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)