.. include:: ../README.rst

.. toctree::
   :maxdepth: 2

   narr
   api


.. toctree::
   :maxdepth: 2

   changelog

Development
===========

zope.principalannotation is hosted at GitHub:

    https://github.com/zopefoundation/zope.principalannotation/



Project URLs
============

* https://pypi.python.org/pypi/zope.principalannotation       (PyPI entry and downloads)


====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
