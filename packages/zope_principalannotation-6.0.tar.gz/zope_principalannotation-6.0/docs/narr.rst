.. include:: ../src/zope/principalannotation/README.rst
