=====
 API
=====

Interfaces
==========

.. automodule:: zope.principalannotation.interfaces

Utility and Adapters
====================

.. automodule:: zope.principalannotation.utility
