ipecharts.option.visualmapitems.continuous module
=================================================

.. automodule:: ipecharts.option.visualmapitems.continuous
   :members:
   :show-inheritance:
   :undoc-members:
