ipecharts.option.seriesitems.candlestick module
===============================================

.. automodule:: ipecharts.option.seriesitems.candlestick
   :members:
   :show-inheritance:
   :undoc-members:
