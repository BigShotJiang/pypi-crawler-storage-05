ipecharts.option.seriesitems.graphgl module
===========================================

.. automodule:: ipecharts.option.seriesitems.graphgl
   :members:
   :show-inheritance:
   :undoc-members:
