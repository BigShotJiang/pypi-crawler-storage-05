ipecharts.option.seriesitems.heatmap module
===========================================

.. automodule:: ipecharts.option.seriesitems.heatmap
   :members:
   :show-inheritance:
   :undoc-members:
