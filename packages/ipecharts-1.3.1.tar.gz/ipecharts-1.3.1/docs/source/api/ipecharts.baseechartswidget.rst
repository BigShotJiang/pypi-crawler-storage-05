ipecharts.baseechartswidget module
==================================

.. automodule:: ipecharts.baseechartswidget
   :members:
   :show-inheritance:
   :undoc-members:
