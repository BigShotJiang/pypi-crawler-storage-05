ipecharts.option.seriesitems.gauge module
=========================================

.. automodule:: ipecharts.option.seriesitems.gauge
   :members:
   :show-inheritance:
   :undoc-members:
