ipecharts.option.seriesitems.bar3d module
=========================================

.. automodule:: ipecharts.option.seriesitems.bar3d
   :members:
   :show-inheritance:
   :undoc-members:
