ipecharts.option.seriesitems.custom module
==========================================

.. automodule:: ipecharts.option.seriesitems.custom
   :members:
   :show-inheritance:
   :undoc-members:
