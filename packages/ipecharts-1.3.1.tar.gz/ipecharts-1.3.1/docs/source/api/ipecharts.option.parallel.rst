ipecharts.option.parallel module
================================

.. automodule:: ipecharts.option.parallel
   :members:
   :show-inheritance:
   :undoc-members:
