ipecharts.option.seriesitems.seriesparallel module
==================================================

.. automodule:: ipecharts.option.seriesitems.seriesparallel
   :members:
   :show-inheritance:
   :undoc-members:
