ipecharts.echarts module
========================

.. automodule:: ipecharts.echarts
   :members:
   :show-inheritance:
   :undoc-members:
