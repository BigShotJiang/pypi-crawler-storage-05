ipecharts.option.series module
==============================

.. automodule:: ipecharts.option.series
   :members:
   :show-inheritance:
   :undoc-members:
