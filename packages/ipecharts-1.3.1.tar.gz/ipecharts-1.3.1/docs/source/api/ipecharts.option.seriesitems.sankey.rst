ipecharts.option.seriesitems.sankey module
==========================================

.. automodule:: ipecharts.option.seriesitems.sankey
   :members:
   :show-inheritance:
   :undoc-members:
