ipecharts.option.seriesitems.funnel module
==========================================

.. automodule:: ipecharts.option.seriesitems.funnel
   :members:
   :show-inheritance:
   :undoc-members:
