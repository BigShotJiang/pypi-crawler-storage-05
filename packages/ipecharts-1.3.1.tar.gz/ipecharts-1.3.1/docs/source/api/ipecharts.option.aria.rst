ipecharts.option.aria module
============================

.. automodule:: ipecharts.option.aria
   :members:
   :show-inheritance:
   :undoc-members:
