ipecharts.option.seriesitems.bar module
=======================================

.. automodule:: ipecharts.option.seriesitems.bar
   :members:
   :show-inheritance:
   :undoc-members:
