ipecharts.option.mediaitems.mediaitem module
============================================

.. automodule:: ipecharts.option.mediaitems.mediaitem
   :members:
   :show-inheritance:
   :undoc-members:
