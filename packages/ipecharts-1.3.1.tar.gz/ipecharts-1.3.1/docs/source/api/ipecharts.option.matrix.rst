ipecharts.option.matrix module
==============================

.. automodule:: ipecharts.option.matrix
   :members:
   :show-inheritance:
   :undoc-members:
