ipecharts.option.dataset module
===============================

.. automodule:: ipecharts.option.dataset
   :members:
   :show-inheritance:
   :undoc-members:
