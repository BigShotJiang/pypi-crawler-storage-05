ipecharts.option.basewidget module
==================================

.. automodule:: ipecharts.option.basewidget
   :members:
   :show-inheritance:
   :undoc-members:
