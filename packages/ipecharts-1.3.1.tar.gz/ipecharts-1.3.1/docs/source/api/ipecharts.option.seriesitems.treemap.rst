ipecharts.option.seriesitems.treemap module
===========================================

.. automodule:: ipecharts.option.seriesitems.treemap
   :members:
   :show-inheritance:
   :undoc-members:
