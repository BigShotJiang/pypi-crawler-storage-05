ipecharts.option.seriesitems.polygons3d module
==============================================

.. automodule:: ipecharts.option.seriesitems.polygons3d
   :members:
   :show-inheritance:
   :undoc-members:
