ipecharts.option.yaxis module
=============================

.. automodule:: ipecharts.option.yaxis
   :members:
   :show-inheritance:
   :undoc-members:
