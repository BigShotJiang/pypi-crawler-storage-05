ipecharts.option.seriesitems package
====================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   ipecharts.option.seriesitems.bar
   ipecharts.option.seriesitems.bar3d
   ipecharts.option.seriesitems.boxplot
   ipecharts.option.seriesitems.candlestick
   ipecharts.option.seriesitems.custom
   ipecharts.option.seriesitems.effectscatter
   ipecharts.option.seriesitems.flowgl
   ipecharts.option.seriesitems.funnel
   ipecharts.option.seriesitems.gauge
   ipecharts.option.seriesitems.graph
   ipecharts.option.seriesitems.graphgl
   ipecharts.option.seriesitems.heatmap
   ipecharts.option.seriesitems.line
   ipecharts.option.seriesitems.line3d
   ipecharts.option.seriesitems.lines
   ipecharts.option.seriesitems.lines3d
   ipecharts.option.seriesitems.map
   ipecharts.option.seriesitems.map3d
   ipecharts.option.seriesitems.pictorialbar
   ipecharts.option.seriesitems.pie
   ipecharts.option.seriesitems.polygons3d
   ipecharts.option.seriesitems.sankey
   ipecharts.option.seriesitems.scatter
   ipecharts.option.seriesitems.scatter3d
   ipecharts.option.seriesitems.scattergl
   ipecharts.option.seriesitems.seriesparallel
   ipecharts.option.seriesitems.seriesradar
   ipecharts.option.seriesitems.sunburst
   ipecharts.option.seriesitems.surface
   ipecharts.option.seriesitems.themeriver
   ipecharts.option.seriesitems.tree
   ipecharts.option.seriesitems.treemap

Module contents
---------------

.. automodule:: ipecharts.option.seriesitems
   :members:
   :show-inheritance:
   :undoc-members:
