ipecharts.basewidget module
===========================

.. automodule:: ipecharts.basewidget
   :members:
   :show-inheritance:
   :undoc-members:
