ipecharts.option.stateanimation module
======================================

.. automodule:: ipecharts.option.stateanimation
   :members:
   :show-inheritance:
   :undoc-members:
