ipecharts.option.seriesitems.lines3d module
===========================================

.. automodule:: ipecharts.option.seriesitems.lines3d
   :members:
   :show-inheritance:
   :undoc-members:
