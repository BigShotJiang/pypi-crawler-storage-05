# History

## 0.1.2 (2025-09-11)

* Removed unnecessary dependency
* Made get_applied_migrations public

## 0.1.1 (2025-09-10)

* Added new stamp feature.

## 0.1.0 (2025-09-10)

* First release on PyPI.
