if __name__ == "__main__":
    raise SystemExit("tiny_migrations is a library — run it via your app, not directly.")
