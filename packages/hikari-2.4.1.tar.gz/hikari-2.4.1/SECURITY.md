# Reporting Security Vulnerabilities

**We urge you not to file a bug report in this GitHub repository since they are open for anyone to see**

Instead, we encourage you to reach out to the maintainer team so we can assess the problem and later disclose it
responsibly.

If you believe you have found a security-related bug, please contact [davfsa](mailto:davfsa@gmail.com).
