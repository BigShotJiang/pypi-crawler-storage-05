# Copyright (c) 2020 Nekokatt
# Copyright (c) 2021-present davfsa
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
"""Test twemoji mapping.

A CI-used script that tests all the Twemoji URLs generated
by Discord emojis are actually legitimate URLs, since Discord
does not map these on a 1-to-1 basis.
"""

from __future__ import annotations

import json
import os
import pathlib
import shutil
import subprocess
import sys
import time
import traceback
import urllib.error
import urllib.request

sys.path.append("..")


from hikari import emojis

IN_CI = bool(os.getenv("CI"))
TWEMOJI_REPO_BASE_URL = "https://github.com/discord/twemoji.git"
DISCORD_EMOJI_MAPPING_URL = "https://emzi0767.mzgit.io/discord-emoji/discordEmojiMap-canary.min.json"

try:
    tempdir = pathlib.Path(sys.argv[1])
except IndexError:
    print("Argument 1 must be the path to the temporary directory")
    sys.exit(2)

git = shutil.which("git")

if not git:
    print("Git not detected, please ensure it is installed properly before continuing")
    sys.exit(3)

start = time.perf_counter()

print("Fetching emoji mapping")
try:
    with urllib.request.urlopen(DISCORD_EMOJI_MAPPING_URL, timeout=30) as request:  # noqa: S310
        mapping = json.loads(request.read())["emojiDefinitions"]
except urllib.error.URLError:
    if not IN_CI:
        raise

    print(f"Failed to retrieve emoji mapping: {traceback.format_exc()}")
    sys.exit(0)

has_items = next(tempdir.iterdir(), False)
if has_items:
    print("Updating twemoji collection")
    subprocess.check_call(f"{git} pull", shell=True, cwd=tempdir)
else:
    print("Cloning twemoji collection")
    subprocess.check_call(f"{git} clone {TWEMOJI_REPO_BASE_URL} {tempdir} --depth=1", shell=True)

assets_path = tempdir / "assets" / "72x72"

invalid_emojis: list[str] = []
total = len(mapping)
for i, emoji in enumerate(mapping, start=1):
    name = emoji["primaryName"]
    emoji_surrogates = emoji["surrogates"]
    hikari_emoji = emojis.UnicodeEmoji.parse(emoji_surrogates)
    line_repr = f"{i}/{total} {name} {' '.join(map(hex, map(ord, emoji_surrogates)))} {hikari_emoji.url}"

    if (assets_path / hikari_emoji.filename).exists():
        print(f"[  OK  ] {line_repr}")
    else:
        invalid_emojis.append(line_repr)
        print(f"[ FAIL ] {line_repr}")

print()
print("Results")
print("-------")
print(f"Valid emojis: {total - len(invalid_emojis)}")
print(f"Invalid emojis: {len(invalid_emojis)}")

for line_repr in invalid_emojis:
    print(f"  {line_repr}")

print(f"Took {time.perf_counter() - start} seconds")

if invalid_emojis or total == 0:
    sys.exit(1)
