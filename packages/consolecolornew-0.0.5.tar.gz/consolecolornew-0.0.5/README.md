# Console color #

## What is this? ##
my simple project can change color of console output