# Running a release.

To run a release, you only need to create a new release in Github, the tag will be picked
up by the pipeline, update the pyproject version via commit and release it to pypi.