from .listofdicts import listofdicts

__all__ = ['listofdicts']
