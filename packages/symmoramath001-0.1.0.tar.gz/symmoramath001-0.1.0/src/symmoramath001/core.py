def symmora_add(a, b):
    return a + b

def symmora_multiply(a, b):
    return a * b

def symmora_power(a, b):
    return a ** b

