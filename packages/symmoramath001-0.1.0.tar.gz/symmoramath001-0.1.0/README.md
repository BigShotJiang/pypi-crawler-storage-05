# symmoramath001

Пример пакета с математическими функциями

Установка:
```bash
pip install symmoramath001
