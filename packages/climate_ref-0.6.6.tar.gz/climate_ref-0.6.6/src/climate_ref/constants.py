"""
Constants used by the REF
"""

CONFIG_FILENAME = "ref.toml"
"""
Default name of the configuration file
"""
