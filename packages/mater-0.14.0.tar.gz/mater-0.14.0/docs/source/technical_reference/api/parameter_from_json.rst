.. _parameter_from_json:

===============================
mater.Mater.parameter_from_json
===============================

.. automethod:: mater.model.Mater.parameter_from_json