.. _run:

===============
mater.Mater.run
===============

.. automethod:: mater.model.Mater.run

.. autoclass:: mater._variable_classes.Parameter