.. _set_run_name:

=========================
mater.Mater.set_run_name
=========================

.. automethod:: mater.model.Mater.set_run_name