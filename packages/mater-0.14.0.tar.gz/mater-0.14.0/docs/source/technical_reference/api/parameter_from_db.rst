.. _parameter_from_db:

=============================
mater.Mater.parameter_from_db
=============================

.. automethod:: mater.model.Mater.parameter_from_db