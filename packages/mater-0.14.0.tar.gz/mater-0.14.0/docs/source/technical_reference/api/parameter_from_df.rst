.. _parameter_from_df:

=============================
mater.Mater.parameter_from_df
=============================

.. automethod:: mater.model.Mater.parameter_from_df