# MCHP - GPIP - CTL

Command-line tool to control USB-Serial Board
