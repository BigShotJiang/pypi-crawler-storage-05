# SPDX-License-Identifier: MIT
"""Base configuration classes."""


class BaseConfig:
    """Abstract base class for all configuration classes."""
