# sage_setup: distribution = sagemath-cliquer
# delvewheel: patch

from sage.all__sagemath_graphs import *
