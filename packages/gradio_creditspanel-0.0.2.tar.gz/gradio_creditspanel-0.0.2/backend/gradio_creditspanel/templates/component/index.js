var Ql = Object.defineProperty;
var In = (o) => {
  throw TypeError(o);
};
var Jl = (o, e, t) => e in o ? Ql(o, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : o[e] = t;
var P = (o, e, t) => Jl(o, typeof e != "symbol" ? e + "" : e, t), eo = (o, e, t) => e.has(o) || In("Cannot " + t);
var Rn = (o, e, t) => e.has(o) ? In("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(o) : e.set(o, t);
var qt = (o, e, t) => (eo(o, e, "access private method"), t);
const {
  SvelteComponent: to,
  append_hydration: sn,
  assign: no,
  attr: Y,
  binding_callbacks: io,
  children: mt,
  claim_element: _l,
  claim_space: cl,
  claim_svg_element: en,
  create_slot: lo,
  detach: Ee,
  element: dl,
  empty: Ln,
  get_all_dirty_from_scope: oo,
  get_slot_changes: ao,
  get_spread_update: ro,
  init: so,
  insert_hydration: $t,
  listen: uo,
  noop: _o,
  safe_not_equal: co,
  set_dynamic_element_data: On,
  set_style: z,
  space: hl,
  svg_element: tn,
  toggle_class: U,
  transition_in: fl,
  transition_out: pl,
  update_slot_base: ho
} = window.__gradio__svelte__internal;
function Pn(o) {
  let e, t, n, i, a;
  return {
    c() {
      e = tn("svg"), t = tn("line"), n = tn("line"), this.h();
    },
    l(l) {
      e = en(l, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var r = mt(e);
      t = en(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), mt(t).forEach(Ee), n = en(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), mt(n).forEach(Ee), r.forEach(Ee), this.h();
    },
    h() {
      Y(t, "x1", "1"), Y(t, "y1", "9"), Y(t, "x2", "9"), Y(t, "y2", "1"), Y(t, "stroke", "gray"), Y(t, "stroke-width", "0.5"), Y(n, "x1", "5"), Y(n, "y1", "9"), Y(n, "x2", "9"), Y(n, "y2", "5"), Y(n, "stroke", "gray"), Y(n, "stroke-width", "0.5"), Y(e, "class", "resize-handle svelte-239wnu"), Y(e, "xmlns", "http://www.w3.org/2000/svg"), Y(e, "viewBox", "0 0 10 10");
    },
    m(l, r) {
      $t(l, e, r), sn(e, t), sn(e, n), i || (a = uo(
        e,
        "mousedown",
        /*resize*/
        o[27]
      ), i = !0);
    },
    p: _o,
    d(l) {
      l && Ee(e), i = !1, a();
    }
  };
}
function fo(o) {
  var c;
  let e, t, n, i, a;
  const l = (
    /*#slots*/
    o[31].default
  ), r = lo(
    l,
    o,
    /*$$scope*/
    o[30],
    null
  );
  let s = (
    /*resizable*/
    o[19] && Pn(o)
  ), u = [
    { "data-testid": (
      /*test_id*/
      o[11]
    ) },
    { id: (
      /*elem_id*/
      o[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((c = o[7]) == null ? void 0 : c.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      o[20] ? "rtl" : "ltr"
    }
  ], _ = {};
  for (let d = 0; d < u.length; d += 1)
    _ = no(_, u[d]);
  return {
    c() {
      e = dl(
        /*tag*/
        o[25]
      ), r && r.c(), t = hl(), s && s.c(), this.h();
    },
    l(d) {
      e = _l(
        d,
        /*tag*/
        (o[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var f = mt(e);
      r && r.l(f), t = cl(f), s && s.l(f), f.forEach(Ee), this.h();
    },
    h() {
      On(
        /*tag*/
        o[25]
      )(e, _), U(
        e,
        "hidden",
        /*visible*/
        o[14] === !1
      ), U(
        e,
        "padded",
        /*padding*/
        o[10]
      ), U(
        e,
        "flex",
        /*flex*/
        o[1]
      ), U(
        e,
        "border_focus",
        /*border_mode*/
        o[9] === "focus"
      ), U(
        e,
        "border_contrast",
        /*border_mode*/
        o[9] === "contrast"
      ), U(e, "hide-container", !/*explicit_call*/
      o[12] && !/*container*/
      o[13]), U(
        e,
        "fullscreen",
        /*fullscreen*/
        o[0]
      ), U(
        e,
        "animating",
        /*fullscreen*/
        o[0] && /*preexpansionBoundingRect*/
        o[24] !== null
      ), U(
        e,
        "auto-margin",
        /*scale*/
        o[17] === null
      ), z(
        e,
        "height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*height*/
            o[2]
          )
        )
      ), z(
        e,
        "min-height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*min_height*/
            o[3]
          )
        )
      ), z(
        e,
        "max-height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*max_height*/
            o[4]
          )
        )
      ), z(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].top}px` : "0px"
      ), z(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].left}px` : "0px"
      ), z(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].width}px` : "0px"
      ), z(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].height}px` : "0px"
      ), z(
        e,
        "width",
        /*fullscreen*/
        o[0] ? void 0 : typeof /*width*/
        o[5] == "number" ? `calc(min(${/*width*/
        o[5]}px, 100%))` : (
          /*get_dimension*/
          o[26](
            /*width*/
            o[5]
          )
        )
      ), z(
        e,
        "border-style",
        /*variant*/
        o[8]
      ), z(
        e,
        "overflow",
        /*allow_overflow*/
        o[15] ? (
          /*overflow_behavior*/
          o[16]
        ) : "hidden"
      ), z(
        e,
        "flex-grow",
        /*scale*/
        o[17]
      ), z(e, "min-width", `calc(min(${/*min_width*/
      o[18]}px, 100%))`), z(e, "border-width", "var(--block-border-width)");
    },
    m(d, f) {
      $t(d, e, f), r && r.m(e, null), sn(e, t), s && s.m(e, null), o[32](e), a = !0;
    },
    p(d, f) {
      var g;
      r && r.p && (!a || f[0] & /*$$scope*/
      1073741824) && ho(
        r,
        l,
        d,
        /*$$scope*/
        d[30],
        a ? ao(
          l,
          /*$$scope*/
          d[30],
          f,
          null
        ) : oo(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, f) : (s = Pn(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), On(
        /*tag*/
        d[25]
      )(e, _ = ro(u, [
        (!a || f[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!a || f[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!a || f[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((g = d[7]) == null ? void 0 : g.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!a || f[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: i }
      ])), U(
        e,
        "hidden",
        /*visible*/
        d[14] === !1
      ), U(
        e,
        "padded",
        /*padding*/
        d[10]
      ), U(
        e,
        "flex",
        /*flex*/
        d[1]
      ), U(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), U(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), U(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), U(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), U(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), U(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), f[0] & /*fullscreen, height*/
      5 && z(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), f[0] & /*fullscreen, min_height*/
      9 && z(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), f[0] & /*fullscreen, max_height*/
      17 && z(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), f[0] & /*fullscreen, width*/
      33 && z(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), f[0] & /*variant*/
      256 && z(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), f[0] & /*allow_overflow, overflow_behavior*/
      98304 && z(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), f[0] & /*scale*/
      131072 && z(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), f[0] & /*min_width*/
      262144 && z(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      a || (fl(r, d), a = !0);
    },
    o(d) {
      pl(r, d), a = !1;
    },
    d(d) {
      d && Ee(e), r && r.d(d), s && s.d(), o[32](null);
    }
  };
}
function Mn(o) {
  let e;
  return {
    c() {
      e = dl("div"), this.h();
    },
    l(t) {
      e = _l(t, "DIV", { class: !0 }), mt(e).forEach(Ee), this.h();
    },
    h() {
      Y(e, "class", "placeholder svelte-239wnu"), z(
        e,
        "height",
        /*placeholder_height*/
        o[22] + "px"
      ), z(
        e,
        "width",
        /*placeholder_width*/
        o[23] + "px"
      );
    },
    m(t, n) {
      $t(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && z(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && z(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && Ee(e);
    }
  };
}
function po(o) {
  let e, t, n, i = (
    /*tag*/
    o[25] && fo(o)
  ), a = (
    /*fullscreen*/
    o[0] && Mn(o)
  );
  return {
    c() {
      i && i.c(), e = hl(), a && a.c(), t = Ln();
    },
    l(l) {
      i && i.l(l), e = cl(l), a && a.l(l), t = Ln();
    },
    m(l, r) {
      i && i.m(l, r), $t(l, e, r), a && a.m(l, r), $t(l, t, r), n = !0;
    },
    p(l, r) {
      /*tag*/
      l[25] && i.p(l, r), /*fullscreen*/
      l[0] ? a ? a.p(l, r) : (a = Mn(l), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    i(l) {
      n || (fl(i, l), n = !0);
    },
    o(l) {
      pl(i, l), n = !1;
    },
    d(l) {
      l && (Ee(e), Ee(t)), i && i.d(l), a && a.d(l);
    }
  };
}
function mo(o, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { height: a = void 0 } = e, { min_height: l = void 0 } = e, { max_height: r = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: _ = [] } = e, { variant: c = "solid" } = e, { border_mode: d = "base" } = e, { padding: f = !0 } = e, { type: g = "normal" } = e, { test_id: m = void 0 } = e, { explicit_call: v = !1 } = e, { container: F = !0 } = e, { visible: p = !0 } = e, { allow_overflow: h = !0 } = e, { overflow_behavior: b = "auto" } = e, { scale: y = null } = e, { min_width: D = 0 } = e, { flex: $ = !1 } = e, { resizable: S = !1 } = e, { rtl: k = !1 } = e, { fullscreen: q = !1 } = e, C = q, O, Xe = g === "fieldset" ? "fieldset" : "div", ne = 0, Fe = 0, te = null;
  function Me(w) {
    q && w.key === "Escape" && t(0, q = !1);
  }
  const V = (w) => {
    if (w !== void 0) {
      if (typeof w == "number")
        return w + "px";
      if (typeof w == "string")
        return w;
    }
  }, J = (w) => {
    let Z = w.clientY;
    const it = (E) => {
      const lt = E.clientY - Z;
      Z = E.clientY, t(21, O.style.height = `${O.offsetHeight + lt}px`, O);
    }, ie = () => {
      window.removeEventListener("mousemove", it), window.removeEventListener("mouseup", ie);
    };
    window.addEventListener("mousemove", it), window.addEventListener("mouseup", ie);
  };
  function pe(w) {
    io[w ? "unshift" : "push"](() => {
      O = w, t(21, O);
    });
  }
  return o.$$set = (w) => {
    "height" in w && t(2, a = w.height), "min_height" in w && t(3, l = w.min_height), "max_height" in w && t(4, r = w.max_height), "width" in w && t(5, s = w.width), "elem_id" in w && t(6, u = w.elem_id), "elem_classes" in w && t(7, _ = w.elem_classes), "variant" in w && t(8, c = w.variant), "border_mode" in w && t(9, d = w.border_mode), "padding" in w && t(10, f = w.padding), "type" in w && t(28, g = w.type), "test_id" in w && t(11, m = w.test_id), "explicit_call" in w && t(12, v = w.explicit_call), "container" in w && t(13, F = w.container), "visible" in w && t(14, p = w.visible), "allow_overflow" in w && t(15, h = w.allow_overflow), "overflow_behavior" in w && t(16, b = w.overflow_behavior), "scale" in w && t(17, y = w.scale), "min_width" in w && t(18, D = w.min_width), "flex" in w && t(1, $ = w.flex), "resizable" in w && t(19, S = w.resizable), "rtl" in w && t(20, k = w.rtl), "fullscreen" in w && t(0, q = w.fullscreen), "$$scope" in w && t(30, i = w.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && q !== C && (t(29, C = q), q ? (t(24, te = O.getBoundingClientRect()), t(22, ne = O.offsetHeight), t(23, Fe = O.offsetWidth), window.addEventListener("keydown", Me)) : (t(24, te = null), window.removeEventListener("keydown", Me))), o.$$.dirty[0] & /*visible*/
    16384 && (p || t(1, $ = !1));
  }, [
    q,
    $,
    a,
    l,
    r,
    s,
    u,
    _,
    c,
    d,
    f,
    m,
    v,
    F,
    p,
    h,
    b,
    y,
    D,
    S,
    k,
    O,
    ne,
    Fe,
    te,
    Xe,
    V,
    J,
    g,
    C,
    i,
    n,
    pe
  ];
}
class go extends to {
  constructor(e) {
    super(), so(
      this,
      e,
      mo,
      po,
      co,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Fn() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let nt = Fn();
function ml(o) {
  nt = o;
}
const gl = /[&<>"']/, vo = new RegExp(gl.source, "g"), vl = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, bo = new RegExp(vl.source, "g"), Do = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Nn = (o) => Do[o];
function oe(o, e) {
  if (e) {
    if (gl.test(o))
      return o.replace(vo, Nn);
  } else if (vl.test(o))
    return o.replace(bo, Nn);
  return o;
}
const yo = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function $o(o) {
  return o.replace(yo, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const wo = /(^|[^\[])\^/g;
function R(o, e) {
  let t = typeof o == "string" ? o : o.source;
  e = e || "";
  const n = {
    replace: (i, a) => {
      let l = typeof a == "string" ? a : a.source;
      return l = l.replace(wo, "$1"), t = t.replace(i, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function jn(o) {
  try {
    o = encodeURI(o).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return o;
}
const gt = { exec: () => null };
function Hn(o, e) {
  const t = o.replace(/\|/g, (a, l, r) => {
    let s = !1, u = l;
    for (; --u >= 0 && r[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(/\\\|/g, "|");
  return n;
}
function Tt(o, e, t) {
  const n = o.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && o.charAt(n - i - 1) === e; )
    i++;
  return o.slice(0, n - i);
}
function Fo(o, e) {
  if (o.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < o.length; n++)
    if (o[n] === "\\")
      n++;
    else if (o[n] === e[0])
      t++;
    else if (o[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Vn(o, e, t, n) {
  const i = e.href, a = e.title ? oe(e.title) : null, l = o[1].replace(/\\([\[\]])/g, "$1");
  if (o[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const r = {
      type: "link",
      raw: t,
      href: i,
      title: a,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, r;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: a,
    text: oe(l)
  };
}
function ko(o, e) {
  const t = o.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((i) => {
    const a = i.match(/^\s+/);
    if (a === null)
      return i;
    const [l] = a;
    return l.length >= n.length ? i.slice(n.length) : i;
  }).join(`
`);
}
class Vt {
  // set by the lexer
  constructor(e) {
    P(this, "options");
    P(this, "rules");
    // set by the lexer
    P(this, "lexer");
    this.options = e || nt;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : Tt(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], i = ko(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const i = Tt(n, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (n = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = Tt(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const a = this.lexer.blockTokens(n);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: a,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const i = n.length > 1, a = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = i ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = i ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let r = "", s = "", u = !1;
      for (; e; ) {
        let _ = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        r = t[0], e = e.substring(r.length);
        let c = t[2].split(`
`, 1)[0].replace(/^\t+/, (F) => " ".repeat(3 * F.length)), d = e.split(`
`, 1)[0], f = 0;
        this.options.pedantic ? (f = 2, s = c.trimStart()) : (f = t[2].search(/[^ ]/), f = f > 4 ? 1 : f, s = c.slice(f), f += t[1].length);
        let g = !1;
        if (!c && /^ *$/.test(d) && (r += d + `
`, e = e.substring(d.length + 1), _ = !0), !_) {
          const F = new RegExp(`^ {0,${Math.min(3, f - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), p = new RegExp(`^ {0,${Math.min(3, f - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), h = new RegExp(`^ {0,${Math.min(3, f - 1)}}(?:\`\`\`|~~~)`), b = new RegExp(`^ {0,${Math.min(3, f - 1)}}#`);
          for (; e; ) {
            const y = e.split(`
`, 1)[0];
            if (d = y, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), h.test(d) || b.test(d) || F.test(d) || p.test(e))
              break;
            if (d.search(/[^ ]/) >= f || !d.trim())
              s += `
` + d.slice(f);
            else {
              if (g || c.search(/[^ ]/) >= 4 || h.test(c) || b.test(c) || p.test(c))
                break;
              s += `
` + d;
            }
            !g && !d.trim() && (g = !0), r += y + `
`, e = e.substring(y.length + 1), c = d.slice(f);
          }
        }
        a.loose || (u ? a.loose = !0 : /\n *\n *$/.test(r) && (u = !0));
        let m = null, v;
        this.options.gfm && (m = /^\[[ xX]\] /.exec(s), m && (v = m[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), a.items.push({
          type: "list_item",
          raw: r,
          task: !!m,
          checked: v,
          loose: !1,
          text: s,
          tokens: []
        }), a.raw += r;
      }
      a.items[a.items.length - 1].raw = r.trimEnd(), a.items[a.items.length - 1].text = s.trimEnd(), a.raw = a.raw.trimEnd();
      for (let _ = 0; _ < a.items.length; _++)
        if (this.lexer.state.top = !1, a.items[_].tokens = this.lexer.blockTokens(a.items[_].text, []), !a.loose) {
          const c = a.items[_].tokens.filter((f) => f.type === "space"), d = c.length > 0 && c.some((f) => /\n.*\n/.test(f.raw));
          a.loose = d;
        }
      if (a.loose)
        for (let _ = 0; _ < a.items.length; _++)
          a.items[_].loose = !0;
      return a;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: i,
        title: a
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Hn(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), a = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === i.length) {
      for (const r of i)
        /^ *-+: *$/.test(r) ? l.align.push("right") : /^ *:-+: *$/.test(r) ? l.align.push("center") : /^ *:-+ *$/.test(r) ? l.align.push("left") : l.align.push(null);
      for (const r of n)
        l.header.push({
          text: r,
          tokens: this.lexer.inline(r)
        });
      for (const r of a)
        l.rows.push(Hn(r, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: oe(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = Tt(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = Fo(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let i = t[2], a = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        l && (i = l[1], a = l[3]);
      } else
        a = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(n) ? i = i.slice(1) : i = i.slice(1, -1)), Vn(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: a && a.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const i = (n[2] || n[1]).replace(/\s+/g, " "), a = t[i.toLowerCase()];
      if (!a) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return Vn(n, a, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...i[0]].length - 1;
      let r, s, u = l, _ = 0;
      const c = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (c.lastIndex = 0, t = t.slice(-1 * e.length + l); (i = c.exec(t)) != null; ) {
        if (r = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !r)
          continue;
        if (s = [...r].length, i[3] || i[4]) {
          u += s;
          continue;
        } else if ((i[5] || i[6]) && l % 3 && !((l + s) % 3)) {
          _ += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + _);
        const d = [...i[0]][0].length, f = e.slice(0, l + i.index + d + s);
        if (Math.min(l, s) % 2) {
          const m = f.slice(1, -1);
          return {
            type: "em",
            raw: f,
            text: m,
            tokens: this.lexer.inlineTokens(m)
          };
        }
        const g = f.slice(2, -2);
        return {
          type: "strong",
          raw: f,
          text: g,
          tokens: this.lexer.inlineTokens(g)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(n), a = /^ /.test(n) && / $/.test(n);
      return i && a && (n = n.substring(1, n.length - 1)), n = oe(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, i;
      return t[2] === "@" ? (n = oe(t[1]), i = "mailto:" + n) : (n = oe(t[1]), i = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, a;
      if (t[2] === "@")
        i = oe(t[0]), a = "mailto:" + i;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        i = oe(t[0]), t[1] === "www." ? a = "http://" + t[0] : a = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: a,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = oe(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Co = /^(?: *(?:\n|$))+/, Eo = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Ao = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Et = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, So = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, bl = /(?:[*+-]|\d{1,9}[.)])/, Dl = R(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, bl).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), kn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Bo = /^[^\n]+/, Cn = /(?!\s*\])(?:\\.|[^\[\]\\])+/, qo = R(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Cn).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), To = R(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, bl).getRegex(), Xt = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", En = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, xo = R("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", En).replace("tag", Xt).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), yl = R(kn).replace("hr", Et).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Xt).getRegex(), zo = R(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", yl).getRegex(), An = {
  blockquote: zo,
  code: Eo,
  def: qo,
  fences: Ao,
  heading: So,
  hr: Et,
  html: xo,
  lheading: Dl,
  list: To,
  newline: Co,
  paragraph: yl,
  table: gt,
  text: Bo
}, Un = R("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Et).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Xt).getRegex(), Io = {
  ...An,
  table: Un,
  paragraph: R(kn).replace("hr", Et).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Un).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Xt).getRegex()
}, Ro = {
  ...An,
  html: R(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", En).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: gt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: R(kn).replace("hr", Et).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Dl).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, $l = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Lo = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, wl = /^( {2,}|\\)\n(?!\s*$)/, Oo = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, At = "\\p{P}\\p{S}", Po = R(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, At).getRegex(), Mo = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, No = R(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, At).getRegex(), jo = R("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, At).getRegex(), Ho = R("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, At).getRegex(), Vo = R(/\\([punct])/, "gu").replace(/punct/g, At).getRegex(), Uo = R(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Go = R(En).replace("(?:-->|$)", "-->").getRegex(), Zo = R("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Go).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Ut = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Xo = R(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Ut).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Fl = R(/^!?\[(label)\]\[(ref)\]/).replace("label", Ut).replace("ref", Cn).getRegex(), kl = R(/^!?\[(ref)\](?:\[\])?/).replace("ref", Cn).getRegex(), Yo = R("reflink|nolink(?!\\()", "g").replace("reflink", Fl).replace("nolink", kl).getRegex(), Sn = {
  _backpedal: gt,
  // only used for GFM url
  anyPunctuation: Vo,
  autolink: Uo,
  blockSkip: Mo,
  br: wl,
  code: Lo,
  del: gt,
  emStrongLDelim: No,
  emStrongRDelimAst: jo,
  emStrongRDelimUnd: Ho,
  escape: $l,
  link: Xo,
  nolink: kl,
  punctuation: Po,
  reflink: Fl,
  reflinkSearch: Yo,
  tag: Zo,
  text: Oo,
  url: gt
}, Wo = {
  ...Sn,
  link: R(/^!?\[(label)\]\((.*?)\)/).replace("label", Ut).getRegex(),
  reflink: R(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Ut).getRegex()
}, un = {
  ...Sn,
  escape: R($l).replace("])", "~|])").getRegex(),
  url: R(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Ko = {
  ...un,
  br: R(wl).replace("{2,}", "*").getRegex(),
  text: R(un.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, xt = {
  normal: An,
  gfm: Io,
  pedantic: Ro
}, dt = {
  normal: Sn,
  gfm: un,
  breaks: Ko,
  pedantic: Wo
};
class Ae {
  constructor(e) {
    P(this, "tokens");
    P(this, "options");
    P(this, "state");
    P(this, "tokenizer");
    P(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || nt, this.options.tokenizer = this.options.tokenizer || new Vt(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: xt.normal,
      inline: dt.normal
    };
    this.options.pedantic ? (t.block = xt.pedantic, t.inline = dt.pedantic) : this.options.gfm && (t.block = xt.gfm, this.options.breaks ? t.inline = dt.breaks : t.inline = dt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: xt,
      inline: dt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Ae(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Ae(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (r, s, u) => s + "    ".repeat(u.length));
    let n, i, a, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((r) => (n = r.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startBlock) {
          let r = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((_) => {
            u = _.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (r = Math.min(r, u));
          }), r < 1 / 0 && r >= 0 && (a = e.substring(0, r + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(a))) {
          i = t[t.length - 1], l && i.type === "paragraph" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n), l = a.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (e) {
          const r = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(r);
            break;
          } else
            throw new Error(r);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, i, a, l = e, r, s, u;
    if (this.tokens.links) {
      const _ = Object.keys(this.tokens.links);
      if (_.length > 0)
        for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          _.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (r = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, r.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((_) => (n = _.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startInline) {
          let _ = 1 / 0;
          const c = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((f) => {
            d = f.call({ lexer: this }, c), typeof d == "number" && d >= 0 && (_ = Math.min(_, d));
          }), _ < 1 / 0 && _ >= 0 && (a = e.substring(0, _ + 1));
        }
        if (n = this.tokenizer.inlineText(a)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const _ = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(_);
            break;
          } else
            throw new Error(_);
        }
      }
    return t;
  }
}
class Gt {
  constructor(e) {
    P(this, "options");
    this.options = e || nt;
  }
  code(e, t, n) {
    var a;
    const i = (a = (t || "").match(/^\S*/)) == null ? void 0 : a[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + oe(i) + '">' + (n ? e : oe(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : oe(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const i = t ? "ol" : "ul", a = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + i + a + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const i = jn(e);
    if (i === null)
      return n;
    e = i;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + t + '"'), a += ">" + n + "</a>", a;
  }
  image(e, t, n) {
    const i = jn(e);
    if (i === null)
      return n;
    e = i;
    let a = `<img src="${e}" alt="${n}"`;
    return t && (a += ` title="${t}"`), a += ">", a;
  }
  text(e) {
    return e;
  }
}
class Bn {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Se {
  constructor(e) {
    P(this, "options");
    P(this, "renderer");
    P(this, "textRenderer");
    this.options = e || nt, this.options.renderer = this.options.renderer || new Gt(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Bn();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Se(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Se(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const a = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const l = a, r = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (r !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += r || "";
          continue;
        }
      }
      switch (a.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = a;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, $o(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = a;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = a;
          let r = "", s = "";
          for (let _ = 0; _ < l.header.length; _++)
            s += this.renderer.tablecell(this.parseInline(l.header[_].tokens), { header: !0, align: l.align[_] });
          r += this.renderer.tablerow(s);
          let u = "";
          for (let _ = 0; _ < l.rows.length; _++) {
            const c = l.rows[_];
            s = "";
            for (let d = 0; d < c.length; d++)
              s += this.renderer.tablecell(this.parseInline(c[d].tokens), { header: !1, align: l.align[d] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(r, u);
          continue;
        }
        case "blockquote": {
          const l = a, r = this.parse(l.tokens);
          n += this.renderer.blockquote(r);
          continue;
        }
        case "list": {
          const l = a, r = l.ordered, s = l.start, u = l.loose;
          let _ = "";
          for (let c = 0; c < l.items.length; c++) {
            const d = l.items[c], f = d.checked, g = d.task;
            let m = "";
            if (d.task) {
              const v = this.renderer.checkbox(!!f);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = v + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = v + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: v + " "
              }) : m += v + " ";
            }
            m += this.parse(d.tokens, u), _ += this.renderer.listitem(m, g, !!f);
          }
          n += this.renderer.list(_, r, s);
          continue;
        }
        case "html": {
          const l = a;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = a;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = a, r = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            l = e[++i], r += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(r) : r;
          continue;
        }
        default: {
          const l = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const a = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const l = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          n += l || "";
          continue;
        }
      }
      switch (a.type) {
        case "escape": {
          const l = a;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = a;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = a;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = a;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = a;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = a;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = a;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = a;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = a;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class vt {
  constructor(e) {
    P(this, "options");
    this.options = e || nt;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
P(vt, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var tt, _n, Cl;
class Qo {
  constructor(...e) {
    Rn(this, tt);
    P(this, "defaults", Fn());
    P(this, "options", this.setOptions);
    P(this, "parse", qt(this, tt, _n).call(this, Ae.lex, Se.parse));
    P(this, "parseInline", qt(this, tt, _n).call(this, Ae.lexInline, Se.parseInline));
    P(this, "Parser", Se);
    P(this, "Renderer", Gt);
    P(this, "TextRenderer", Bn);
    P(this, "Lexer", Ae);
    P(this, "Tokenizer", Vt);
    P(this, "Hooks", vt);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, a;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const r = l;
          for (const s of r.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of r.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const r = l;
          n = n.concat(this.walkTokens(r.items, t));
          break;
        }
        default: {
          const r = l;
          (a = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && a[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((s) => {
            const u = r[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const i = { ...n };
      if (i.async = this.defaults.async || i.async || !1, n.extensions && (n.extensions.forEach((a) => {
        if (!a.name)
          throw new Error("extension name required");
        if ("renderer" in a) {
          const l = t.renderers[a.name];
          l ? t.renderers[a.name] = function(...r) {
            let s = a.renderer.apply(this, r);
            return s === !1 && (s = l.apply(this, r)), s;
          } : t.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[a.level];
          l ? l.unshift(a.tokenizer) : t[a.level] = [a.tokenizer], a.start && (a.level === "block" ? t.startBlock ? t.startBlock.push(a.start) : t.startBlock = [a.start] : a.level === "inline" && (t.startInline ? t.startInline.push(a.start) : t.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (t.childTokens[a.name] = a.childTokens);
      }), i.extensions = t), n.renderer) {
        const a = this.defaults.renderer || new Gt(this.defaults);
        for (const l in n.renderer) {
          if (!(l in a))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.renderer[r], u = a[r];
          a[r] = (..._) => {
            let c = s.apply(a, _);
            return c === !1 && (c = u.apply(a, _)), c || "";
          };
        }
        i.renderer = a;
      }
      if (n.tokenizer) {
        const a = this.defaults.tokenizer || new Vt(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in a))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const r = l, s = n.tokenizer[r], u = a[r];
          a[r] = (..._) => {
            let c = s.apply(a, _);
            return c === !1 && (c = u.apply(a, _)), c;
          };
        }
        i.tokenizer = a;
      }
      if (n.hooks) {
        const a = this.defaults.hooks || new vt();
        for (const l in n.hooks) {
          if (!(l in a))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.hooks[r], u = a[r];
          vt.passThroughHooks.has(l) ? a[r] = (_) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(a, _)).then((d) => u.call(a, d));
            const c = s.call(a, _);
            return u.call(a, c);
          } : a[r] = (..._) => {
            let c = s.apply(a, _);
            return c === !1 && (c = u.apply(a, _)), c;
          };
        }
        i.hooks = a;
      }
      if (n.walkTokens) {
        const a = this.defaults.walkTokens, l = n.walkTokens;
        i.walkTokens = function(r) {
          let s = [];
          return s.push(l.call(this, r)), a && (s = s.concat(a.call(this, r))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Ae.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Se.parse(e, t ?? this.defaults);
  }
}
tt = new WeakSet(), _n = function(e, t) {
  return (n, i) => {
    const a = { ...i }, l = { ...this.defaults, ...a };
    this.defaults.async === !0 && a.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const r = qt(this, tt, Cl).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return r(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return r(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(r);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let s = e(n, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return r(s);
    }
  };
}, Cl = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + oe(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const et = new Qo();
function I(o, e) {
  return et.parse(o, e);
}
I.options = I.setOptions = function(o) {
  return et.setOptions(o), I.defaults = et.defaults, ml(I.defaults), I;
};
I.getDefaults = Fn;
I.defaults = nt;
I.use = function(...o) {
  return et.use(...o), I.defaults = et.defaults, ml(I.defaults), I;
};
I.walkTokens = function(o, e) {
  return et.walkTokens(o, e);
};
I.parseInline = et.parseInline;
I.Parser = Se;
I.parser = Se.parse;
I.Renderer = Gt;
I.TextRenderer = Bn;
I.Lexer = Ae;
I.lexer = Ae.lex;
I.Tokenizer = Vt;
I.Hooks = vt;
I.parse = I;
I.options;
I.setOptions;
I.use;
I.walkTokens;
I.parseInline;
Se.parse;
Ae.lex;
const Jo = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, ea = Object.hasOwnProperty;
class El {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let i = ta(e, t === !0);
    const a = i;
    for (; ea.call(n.occurrences, i); )
      n.occurrences[a]++, i = a + "-" + n.occurrences[a];
    return n.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function ta(o, e) {
  return typeof o != "string" ? "" : (e || (o = o.toLowerCase()), o.replace(Jo, "").replace(/ /g, "-"));
}
new El();
var Gn = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, na = { exports: {} };
(function(o) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, a = 0, l = {}, r = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function p(h) {
          return h instanceof s ? new s(h.type, p(h.content), h.alias) : Array.isArray(h) ? h.map(p) : h.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(p) {
          return Object.prototype.toString.call(p).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(p) {
          return p.__id || Object.defineProperty(p, "__id", { value: ++a }), p.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function p(h, b) {
          b = b || {};
          var y, D;
          switch (r.util.type(h)) {
            case "Object":
              if (D = r.util.objId(h), b[D])
                return b[D];
              y = /** @type {Record<string, any>} */
              {}, b[D] = y;
              for (var $ in h)
                h.hasOwnProperty($) && (y[$] = p(h[$], b));
              return (
                /** @type {any} */
                y
              );
            case "Array":
              return D = r.util.objId(h), b[D] ? b[D] : (y = [], b[D] = y, /** @type {Array} */
              /** @type {any} */
              h.forEach(function(S, k) {
                y[k] = p(S, b);
              }), /** @type {any} */
              y);
            default:
              return h;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(p) {
          for (; p; ) {
            var h = i.exec(p.className);
            if (h)
              return h[1].toLowerCase();
            p = p.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(p, h) {
          p.className = p.className.replace(RegExp(i, "gi"), ""), p.classList.add("language-" + h);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (y) {
            var p = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(y.stack) || [])[1];
            if (p) {
              var h = document.getElementsByTagName("script");
              for (var b in h)
                if (h[b].src == p)
                  return h[b];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(p, h, b) {
          for (var y = "no-" + h; p; ) {
            var D = p.classList;
            if (D.contains(h))
              return !0;
            if (D.contains(y))
              return !1;
            p = p.parentElement;
          }
          return !!b;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(p, h) {
          var b = r.util.clone(r.languages[p]);
          for (var y in h)
            b[y] = h[y];
          return b;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(p, h, b, y) {
          y = y || /** @type {any} */
          r.languages;
          var D = y[p], $ = {};
          for (var S in D)
            if (D.hasOwnProperty(S)) {
              if (S == h)
                for (var k in b)
                  b.hasOwnProperty(k) && ($[k] = b[k]);
              b.hasOwnProperty(S) || ($[S] = D[S]);
            }
          var q = y[p];
          return y[p] = $, r.languages.DFS(r.languages, function(C, O) {
            O === q && C != p && (this[C] = $);
          }), $;
        },
        // Traverse a language definition with Depth First Search
        DFS: function p(h, b, y, D) {
          D = D || {};
          var $ = r.util.objId;
          for (var S in h)
            if (h.hasOwnProperty(S)) {
              b.call(h, S, h[S], y || S);
              var k = h[S], q = r.util.type(k);
              q === "Object" && !D[$(k)] ? (D[$(k)] = !0, p(k, b, null, D)) : q === "Array" && !D[$(k)] && (D[$(k)] = !0, p(k, b, S, D));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(p, h) {
        r.highlightAllUnder(document, p, h);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(p, h, b) {
        var y = {
          callback: b,
          container: p,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        r.hooks.run("before-highlightall", y), y.elements = Array.prototype.slice.apply(y.container.querySelectorAll(y.selector)), r.hooks.run("before-all-elements-highlight", y);
        for (var D = 0, $; $ = y.elements[D++]; )
          r.highlightElement($, h === !0, y.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(p, h, b) {
        var y = r.util.getLanguage(p), D = r.languages[y];
        r.util.setLanguage(p, y);
        var $ = p.parentElement;
        $ && $.nodeName.toLowerCase() === "pre" && r.util.setLanguage($, y);
        var S = p.textContent, k = {
          element: p,
          language: y,
          grammar: D,
          code: S
        };
        function q(O) {
          k.highlightedCode = O, r.hooks.run("before-insert", k), k.element.innerHTML = k.highlightedCode, r.hooks.run("after-highlight", k), r.hooks.run("complete", k), b && b.call(k.element);
        }
        if (r.hooks.run("before-sanity-check", k), $ = k.element.parentElement, $ && $.nodeName.toLowerCase() === "pre" && !$.hasAttribute("tabindex") && $.setAttribute("tabindex", "0"), !k.code) {
          r.hooks.run("complete", k), b && b.call(k.element);
          return;
        }
        if (r.hooks.run("before-highlight", k), !k.grammar) {
          q(r.util.encode(k.code));
          return;
        }
        if (h && n.Worker) {
          var C = new Worker(r.filename);
          C.onmessage = function(O) {
            q(O.data);
          }, C.postMessage(JSON.stringify({
            language: k.language,
            code: k.code,
            immediateClose: !0
          }));
        } else
          q(r.highlight(k.code, k.grammar, k.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(p, h, b) {
        var y = {
          code: p,
          grammar: h,
          language: b
        };
        if (r.hooks.run("before-tokenize", y), !y.grammar)
          throw new Error('The language "' + y.language + '" has no grammar.');
        return y.tokens = r.tokenize(y.code, y.grammar), r.hooks.run("after-tokenize", y), s.stringify(r.util.encode(y.tokens), y.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(p, h) {
        var b = h.rest;
        if (b) {
          for (var y in b)
            h[y] = b[y];
          delete h.rest;
        }
        var D = new c();
        return d(D, D.head, p), _(p, D, h, D.head, 0), g(D);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(p, h) {
          var b = r.hooks.all;
          b[p] = b[p] || [], b[p].push(h);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(p, h) {
          var b = r.hooks.all[p];
          if (!(!b || !b.length))
            for (var y = 0, D; D = b[y++]; )
              D(h);
        }
      },
      Token: s
    };
    n.Prism = r;
    function s(p, h, b, y) {
      this.type = p, this.content = h, this.alias = b, this.length = (y || "").length | 0;
    }
    s.stringify = function p(h, b) {
      if (typeof h == "string")
        return h;
      if (Array.isArray(h)) {
        var y = "";
        return h.forEach(function(q) {
          y += p(q, b);
        }), y;
      }
      var D = {
        type: h.type,
        content: p(h.content, b),
        tag: "span",
        classes: ["token", h.type],
        attributes: {},
        language: b
      }, $ = h.alias;
      $ && (Array.isArray($) ? Array.prototype.push.apply(D.classes, $) : D.classes.push($)), r.hooks.run("wrap", D);
      var S = "";
      for (var k in D.attributes)
        S += " " + k + '="' + (D.attributes[k] || "").replace(/"/g, "&quot;") + '"';
      return "<" + D.tag + ' class="' + D.classes.join(" ") + '"' + S + ">" + D.content + "</" + D.tag + ">";
    };
    function u(p, h, b, y) {
      p.lastIndex = h;
      var D = p.exec(b);
      if (D && y && D[1]) {
        var $ = D[1].length;
        D.index += $, D[0] = D[0].slice($);
      }
      return D;
    }
    function _(p, h, b, y, D, $) {
      for (var S in b)
        if (!(!b.hasOwnProperty(S) || !b[S])) {
          var k = b[S];
          k = Array.isArray(k) ? k : [k];
          for (var q = 0; q < k.length; ++q) {
            if ($ && $.cause == S + "," + q)
              return;
            var C = k[q], O = C.inside, Xe = !!C.lookbehind, ne = !!C.greedy, Fe = C.alias;
            if (ne && !C.pattern.global) {
              var te = C.pattern.toString().match(/[imsuy]*$/)[0];
              C.pattern = RegExp(C.pattern.source, te + "g");
            }
            for (var Me = C.pattern || C, V = y.next, J = D; V !== h.tail && !($ && J >= $.reach); J += V.value.length, V = V.next) {
              var pe = V.value;
              if (h.length > p.length)
                return;
              if (!(pe instanceof s)) {
                var w = 1, Z;
                if (ne) {
                  if (Z = u(Me, J, p, Xe), !Z || Z.index >= p.length)
                    break;
                  var lt = Z.index, it = Z.index + Z[0].length, ie = J;
                  for (ie += V.value.length; lt >= ie; )
                    V = V.next, ie += V.value.length;
                  if (ie -= V.value.length, J = ie, V.value instanceof s)
                    continue;
                  for (var E = V; E !== h.tail && (ie < it || typeof E.value == "string"); E = E.next)
                    w++, ie += E.value.length;
                  w--, pe = p.slice(J, ie), Z.index -= J;
                } else if (Z = u(Me, 0, pe, Xe), !Z)
                  continue;
                var lt = Z.index, St = Z[0], Kt = pe.slice(0, lt), zn = pe.slice(lt + St.length), Qt = J + pe.length;
                $ && Qt > $.reach && ($.reach = Qt);
                var Bt = V.prev;
                Kt && (Bt = d(h, Bt, Kt), J += Kt.length), f(h, Bt, w);
                var Kl = new s(S, O ? r.tokenize(St, O) : St, Fe, St);
                if (V = d(h, Bt, Kl), zn && d(h, V, zn), w > 1) {
                  var Jt = {
                    cause: S + "," + q,
                    reach: Qt
                  };
                  _(p, h, b, V.prev, J, Jt), $ && Jt.reach > $.reach && ($.reach = Jt.reach);
                }
              }
            }
          }
        }
    }
    function c() {
      var p = { value: null, prev: null, next: null }, h = { value: null, prev: p, next: null };
      p.next = h, this.head = p, this.tail = h, this.length = 0;
    }
    function d(p, h, b) {
      var y = h.next, D = { value: b, prev: h, next: y };
      return h.next = D, y.prev = D, p.length++, D;
    }
    function f(p, h, b) {
      for (var y = h.next, D = 0; D < b && y !== p.tail; D++)
        y = y.next;
      h.next = y, y.prev = h, p.length -= D;
    }
    function g(p) {
      for (var h = [], b = p.head.next; b !== p.tail; )
        h.push(b.value), b = b.next;
      return h;
    }
    if (!n.document)
      return n.addEventListener && (r.disableWorkerMessageHandler || n.addEventListener("message", function(p) {
        var h = JSON.parse(p.data), b = h.language, y = h.code, D = h.immediateClose;
        n.postMessage(r.highlight(y, r.languages[b], b)), D && n.close();
      }, !1)), r;
    var m = r.util.currentScript();
    m && (r.filename = m.src, m.hasAttribute("data-manual") && (r.manual = !0));
    function v() {
      r.manual || r.highlightAll();
    }
    if (!r.manual) {
      var F = document.readyState;
      F === "loading" || F === "interactive" && m && m.defer ? document.addEventListener("DOMContentLoaded", v) : window.requestAnimationFrame ? window.requestAnimationFrame(v) : window.setTimeout(v, 16);
    }
    return r;
  }(e);
  o.exports && (o.exports = t), typeof Gn < "u" && (Gn.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, a) {
      var l = {};
      l["language-" + a] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[a]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var r = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      r["language-" + a] = {
        pattern: /[\s\S]+/,
        inside: t.languages[a]
      };
      var s = {};
      s[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: r
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var a = n.languages.markup;
    a && (a.tag.addInlined("style", "css"), a.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", i = function(m, v) {
      return "✖ Error " + m + " while fetching file: " + v;
    }, a = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, r = "data-src-status", s = "loading", u = "loaded", _ = "failed", c = "pre[data-src]:not([" + r + '="' + u + '"]):not([' + r + '="' + s + '"])';
    function d(m, v, F) {
      var p = new XMLHttpRequest();
      p.open("GET", m, !0), p.onreadystatechange = function() {
        p.readyState == 4 && (p.status < 400 && p.responseText ? v(p.responseText) : p.status >= 400 ? F(i(p.status, p.statusText)) : F(a));
      }, p.send(null);
    }
    function f(m) {
      var v = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(m || "");
      if (v) {
        var F = Number(v[1]), p = v[2], h = v[3];
        return p ? h ? [F, Number(h)] : [F, void 0] : [F, F];
      }
    }
    t.hooks.add("before-highlightall", function(m) {
      m.selector += ", " + c;
    }), t.hooks.add("before-sanity-check", function(m) {
      var v = (
        /** @type {HTMLPreElement} */
        m.element
      );
      if (v.matches(c)) {
        m.code = "", v.setAttribute(r, s);
        var F = v.appendChild(document.createElement("CODE"));
        F.textContent = n;
        var p = v.getAttribute("data-src"), h = m.language;
        if (h === "none") {
          var b = (/\.(\w+)$/.exec(p) || [, "none"])[1];
          h = l[b] || b;
        }
        t.util.setLanguage(F, h), t.util.setLanguage(v, h);
        var y = t.plugins.autoloader;
        y && y.loadLanguages(h), d(
          p,
          function(D) {
            v.setAttribute(r, u);
            var $ = f(v.getAttribute("data-range"));
            if ($) {
              var S = D.split(/\r\n?|\n/g), k = $[0], q = $[1] == null ? S.length : $[1];
              k < 0 && (k += S.length), k = Math.max(0, Math.min(k - 1, S.length)), q < 0 && (q += S.length), q = Math.max(0, Math.min(q, S.length)), D = S.slice(k, q).join(`
`), v.hasAttribute("data-start") || v.setAttribute("data-start", String(k + 1));
            }
            F.textContent = D, t.highlightElement(F);
          },
          function(D) {
            v.setAttribute(r, _), F.textContent = D;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(v) {
        for (var F = (v || document).querySelectorAll(c), p = 0, h; h = F[p++]; )
          t.highlightElement(h);
      }
    };
    var g = !1;
    t.fileHighlight = function() {
      g || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), g = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(na);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(o) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  o.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, o.languages.tex = o.languages.latex, o.languages.context = o.languages.latex;
})(Prism);
(function(o) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  o.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = o.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], a = n.variable[1].inside, l = 0; l < i.length; l++)
    a[i[l]] = o.languages.bash[i[l]];
  o.languages.sh = o.languages.bash, o.languages.shell = o.languages.bash;
})(Prism);
new El();
const ia = (o) => {
  const e = {};
  for (let t = 0, n = o.length; t < n; t++) {
    const i = o[t];
    for (const a in i)
      e[a] ? e[a] = e[a].concat(i[a]) : e[a] = i[a];
  }
  return e;
}, la = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], oa = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], aa = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
ia([
  Object.fromEntries(la.map((o) => [o, ["*"]])),
  Object.fromEntries(oa.map((o) => [o, ["svg:*"]])),
  Object.fromEntries(aa.map((o) => [o, ["math:*"]]))
]);
const {
  HtmlTagHydration: Bs,
  SvelteComponent: qs,
  attr: Ts,
  binding_callbacks: xs,
  children: zs,
  claim_element: Is,
  claim_html_tag: Rs,
  detach: Ls,
  element: Os,
  init: Ps,
  insert_hydration: Ms,
  noop: Ns,
  safe_not_equal: js,
  toggle_class: Hs
} = window.__gradio__svelte__internal, { afterUpdate: Vs, tick: Us, onMount: Gs } = window.__gradio__svelte__internal, {
  SvelteComponent: Zs,
  attr: Xs,
  children: Ys,
  claim_component: Ws,
  claim_element: Ks,
  create_component: Qs,
  destroy_component: Js,
  detach: eu,
  element: tu,
  init: nu,
  insert_hydration: iu,
  mount_component: lu,
  safe_not_equal: ou,
  transition_in: au,
  transition_out: ru
} = window.__gradio__svelte__internal, {
  SvelteComponent: su,
  attr: uu,
  check_outros: _u,
  children: cu,
  claim_component: du,
  claim_element: hu,
  claim_space: fu,
  create_component: pu,
  create_slot: mu,
  destroy_component: gu,
  detach: vu,
  element: bu,
  empty: Du,
  get_all_dirty_from_scope: yu,
  get_slot_changes: $u,
  group_outros: wu,
  init: Fu,
  insert_hydration: ku,
  mount_component: Cu,
  safe_not_equal: Eu,
  space: Au,
  toggle_class: Su,
  transition_in: Bu,
  transition_out: qu,
  update_slot_base: Tu
} = window.__gradio__svelte__internal, {
  SvelteComponent: xu,
  append_hydration: zu,
  attr: Iu,
  children: Ru,
  claim_component: Lu,
  claim_element: Ou,
  claim_space: Pu,
  claim_text: Mu,
  create_component: Nu,
  destroy_component: ju,
  detach: Hu,
  element: Vu,
  init: Uu,
  insert_hydration: Gu,
  mount_component: Zu,
  safe_not_equal: Xu,
  set_data: Yu,
  space: Wu,
  text: Ku,
  toggle_class: Qu,
  transition_in: Ju,
  transition_out: e_
} = window.__gradio__svelte__internal, {
  SvelteComponent: ra,
  append_hydration: jt,
  attr: ze,
  bubble: sa,
  check_outros: ua,
  children: cn,
  claim_component: _a,
  claim_element: dn,
  claim_space: Zn,
  claim_text: ca,
  construct_svelte_component: Xn,
  create_component: Yn,
  create_slot: da,
  destroy_component: Wn,
  detach: bt,
  element: hn,
  get_all_dirty_from_scope: ha,
  get_slot_changes: fa,
  group_outros: pa,
  init: ma,
  insert_hydration: Al,
  listen: ga,
  mount_component: Kn,
  safe_not_equal: va,
  set_data: ba,
  set_style: zt,
  space: Qn,
  text: Da,
  toggle_class: X,
  transition_in: nn,
  transition_out: ln,
  update_slot_base: ya
} = window.__gradio__svelte__internal;
function Jn(o) {
  let e, t;
  return {
    c() {
      e = hn("span"), t = Da(
        /*label*/
        o[1]
      ), this.h();
    },
    l(n) {
      e = dn(n, "SPAN", { class: !0 });
      var i = cn(e);
      t = ca(
        i,
        /*label*/
        o[1]
      ), i.forEach(bt), this.h();
    },
    h() {
      ze(e, "class", "svelte-qgco6m");
    },
    m(n, i) {
      Al(n, e, i), jt(e, t);
    },
    p(n, i) {
      i & /*label*/
      2 && ba(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && bt(e);
    }
  };
}
function $a(o) {
  let e, t, n, i, a, l, r, s, u = (
    /*show_label*/
    o[2] && Jn(o)
  );
  var _ = (
    /*Icon*/
    o[0]
  );
  function c(g, m) {
    return {};
  }
  _ && (i = Xn(_, c()));
  const d = (
    /*#slots*/
    o[14].default
  ), f = da(
    d,
    o,
    /*$$scope*/
    o[13],
    null
  );
  return {
    c() {
      e = hn("button"), u && u.c(), t = Qn(), n = hn("div"), i && Yn(i.$$.fragment), a = Qn(), f && f.c(), this.h();
    },
    l(g) {
      e = dn(g, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var m = cn(e);
      u && u.l(m), t = Zn(m), n = dn(m, "DIV", { class: !0 });
      var v = cn(n);
      i && _a(i.$$.fragment, v), a = Zn(v), f && f.l(v), v.forEach(bt), m.forEach(bt), this.h();
    },
    h() {
      ze(n, "class", "svelte-qgco6m"), X(
        n,
        "x-small",
        /*size*/
        o[4] === "x-small"
      ), X(
        n,
        "small",
        /*size*/
        o[4] === "small"
      ), X(
        n,
        "large",
        /*size*/
        o[4] === "large"
      ), X(
        n,
        "medium",
        /*size*/
        o[4] === "medium"
      ), e.disabled = /*disabled*/
      o[7], ze(
        e,
        "aria-label",
        /*label*/
        o[1]
      ), ze(
        e,
        "aria-haspopup",
        /*hasPopup*/
        o[8]
      ), ze(
        e,
        "title",
        /*label*/
        o[1]
      ), ze(e, "class", "svelte-qgco6m"), X(
        e,
        "pending",
        /*pending*/
        o[3]
      ), X(
        e,
        "padded",
        /*padded*/
        o[5]
      ), X(
        e,
        "highlight",
        /*highlight*/
        o[6]
      ), X(
        e,
        "transparent",
        /*transparent*/
        o[9]
      ), zt(e, "color", !/*disabled*/
      o[7] && /*_color*/
      o[11] ? (
        /*_color*/
        o[11]
      ) : "var(--block-label-text-color)"), zt(e, "--bg-color", /*disabled*/
      o[7] ? "auto" : (
        /*background*/
        o[10]
      ));
    },
    m(g, m) {
      Al(g, e, m), u && u.m(e, null), jt(e, t), jt(e, n), i && Kn(i, n, null), jt(n, a), f && f.m(n, null), l = !0, r || (s = ga(
        e,
        "click",
        /*click_handler*/
        o[15]
      ), r = !0);
    },
    p(g, [m]) {
      if (/*show_label*/
      g[2] ? u ? u.p(g, m) : (u = Jn(g), u.c(), u.m(e, t)) : u && (u.d(1), u = null), m & /*Icon*/
      1 && _ !== (_ = /*Icon*/
      g[0])) {
        if (i) {
          pa();
          const v = i;
          ln(v.$$.fragment, 1, 0, () => {
            Wn(v, 1);
          }), ua();
        }
        _ ? (i = Xn(_, c()), Yn(i.$$.fragment), nn(i.$$.fragment, 1), Kn(i, n, a)) : i = null;
      }
      f && f.p && (!l || m & /*$$scope*/
      8192) && ya(
        f,
        d,
        g,
        /*$$scope*/
        g[13],
        l ? fa(
          d,
          /*$$scope*/
          g[13],
          m,
          null
        ) : ha(
          /*$$scope*/
          g[13]
        ),
        null
      ), (!l || m & /*size*/
      16) && X(
        n,
        "x-small",
        /*size*/
        g[4] === "x-small"
      ), (!l || m & /*size*/
      16) && X(
        n,
        "small",
        /*size*/
        g[4] === "small"
      ), (!l || m & /*size*/
      16) && X(
        n,
        "large",
        /*size*/
        g[4] === "large"
      ), (!l || m & /*size*/
      16) && X(
        n,
        "medium",
        /*size*/
        g[4] === "medium"
      ), (!l || m & /*disabled*/
      128) && (e.disabled = /*disabled*/
      g[7]), (!l || m & /*label*/
      2) && ze(
        e,
        "aria-label",
        /*label*/
        g[1]
      ), (!l || m & /*hasPopup*/
      256) && ze(
        e,
        "aria-haspopup",
        /*hasPopup*/
        g[8]
      ), (!l || m & /*label*/
      2) && ze(
        e,
        "title",
        /*label*/
        g[1]
      ), (!l || m & /*pending*/
      8) && X(
        e,
        "pending",
        /*pending*/
        g[3]
      ), (!l || m & /*padded*/
      32) && X(
        e,
        "padded",
        /*padded*/
        g[5]
      ), (!l || m & /*highlight*/
      64) && X(
        e,
        "highlight",
        /*highlight*/
        g[6]
      ), (!l || m & /*transparent*/
      512) && X(
        e,
        "transparent",
        /*transparent*/
        g[9]
      ), m & /*disabled, _color*/
      2176 && zt(e, "color", !/*disabled*/
      g[7] && /*_color*/
      g[11] ? (
        /*_color*/
        g[11]
      ) : "var(--block-label-text-color)"), m & /*disabled, background*/
      1152 && zt(e, "--bg-color", /*disabled*/
      g[7] ? "auto" : (
        /*background*/
        g[10]
      ));
    },
    i(g) {
      l || (i && nn(i.$$.fragment, g), nn(f, g), l = !0);
    },
    o(g) {
      i && ln(i.$$.fragment, g), ln(f, g), l = !1;
    },
    d(g) {
      g && bt(e), u && u.d(), i && Wn(i), f && f.d(g), r = !1, s();
    }
  };
}
function wa(o, e, t) {
  let n, { $$slots: i = {}, $$scope: a } = e, { Icon: l } = e, { label: r = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: _ = "small" } = e, { padded: c = !0 } = e, { highlight: d = !1 } = e, { disabled: f = !1 } = e, { hasPopup: g = !1 } = e, { color: m = "var(--block-label-text-color)" } = e, { transparent: v = !1 } = e, { background: F = "var(--block-background-fill)" } = e;
  function p(h) {
    sa.call(this, o, h);
  }
  return o.$$set = (h) => {
    "Icon" in h && t(0, l = h.Icon), "label" in h && t(1, r = h.label), "show_label" in h && t(2, s = h.show_label), "pending" in h && t(3, u = h.pending), "size" in h && t(4, _ = h.size), "padded" in h && t(5, c = h.padded), "highlight" in h && t(6, d = h.highlight), "disabled" in h && t(7, f = h.disabled), "hasPopup" in h && t(8, g = h.hasPopup), "color" in h && t(12, m = h.color), "transparent" in h && t(9, v = h.transparent), "background" in h && t(10, F = h.background), "$$scope" in h && t(13, a = h.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty & /*highlight, color*/
    4160 && t(11, n = d ? "var(--color-accent)" : m);
  }, [
    l,
    r,
    s,
    u,
    _,
    c,
    d,
    f,
    g,
    v,
    F,
    n,
    m,
    a,
    i,
    p
  ];
}
class Fa extends ra {
  constructor(e) {
    super(), ma(this, e, wa, $a, va, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: t_,
  append_hydration: n_,
  attr: i_,
  binding_callbacks: l_,
  children: o_,
  claim_element: a_,
  create_slot: r_,
  detach: s_,
  element: u_,
  get_all_dirty_from_scope: __,
  get_slot_changes: c_,
  init: d_,
  insert_hydration: h_,
  safe_not_equal: f_,
  toggle_class: p_,
  transition_in: m_,
  transition_out: g_,
  update_slot_base: v_
} = window.__gradio__svelte__internal, {
  SvelteComponent: b_,
  append_hydration: D_,
  attr: y_,
  children: $_,
  claim_svg_element: w_,
  detach: F_,
  init: k_,
  insert_hydration: C_,
  noop: E_,
  safe_not_equal: A_,
  svg_element: S_
} = window.__gradio__svelte__internal, {
  SvelteComponent: B_,
  append_hydration: q_,
  attr: T_,
  children: x_,
  claim_svg_element: z_,
  detach: I_,
  init: R_,
  insert_hydration: L_,
  noop: O_,
  safe_not_equal: P_,
  svg_element: M_
} = window.__gradio__svelte__internal, {
  SvelteComponent: N_,
  append_hydration: j_,
  attr: H_,
  children: V_,
  claim_svg_element: U_,
  detach: G_,
  init: Z_,
  insert_hydration: X_,
  noop: Y_,
  safe_not_equal: W_,
  svg_element: K_
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q_,
  append_hydration: J_,
  attr: ec,
  children: tc,
  claim_svg_element: nc,
  detach: ic,
  init: lc,
  insert_hydration: oc,
  noop: ac,
  safe_not_equal: rc,
  svg_element: sc
} = window.__gradio__svelte__internal, {
  SvelteComponent: uc,
  append_hydration: _c,
  attr: cc,
  children: dc,
  claim_svg_element: hc,
  detach: fc,
  init: pc,
  insert_hydration: mc,
  noop: gc,
  safe_not_equal: vc,
  svg_element: bc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dc,
  append_hydration: yc,
  attr: $c,
  children: wc,
  claim_svg_element: Fc,
  detach: kc,
  init: Cc,
  insert_hydration: Ec,
  noop: Ac,
  safe_not_equal: Sc,
  svg_element: Bc
} = window.__gradio__svelte__internal, {
  SvelteComponent: qc,
  append_hydration: Tc,
  attr: xc,
  children: zc,
  claim_svg_element: Ic,
  detach: Rc,
  init: Lc,
  insert_hydration: Oc,
  noop: Pc,
  safe_not_equal: Mc,
  svg_element: Nc
} = window.__gradio__svelte__internal, {
  SvelteComponent: jc,
  append_hydration: Hc,
  attr: Vc,
  children: Uc,
  claim_svg_element: Gc,
  detach: Zc,
  init: Xc,
  insert_hydration: Yc,
  noop: Wc,
  safe_not_equal: Kc,
  svg_element: Qc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jc,
  append_hydration: ed,
  attr: td,
  children: nd,
  claim_svg_element: id,
  detach: ld,
  init: od,
  insert_hydration: ad,
  noop: rd,
  safe_not_equal: sd,
  svg_element: ud
} = window.__gradio__svelte__internal, {
  SvelteComponent: _d,
  append_hydration: cd,
  attr: dd,
  children: hd,
  claim_svg_element: fd,
  detach: pd,
  init: md,
  insert_hydration: gd,
  noop: vd,
  safe_not_equal: bd,
  svg_element: Dd
} = window.__gradio__svelte__internal, {
  SvelteComponent: yd,
  append_hydration: $d,
  attr: wd,
  children: Fd,
  claim_svg_element: kd,
  detach: Cd,
  init: Ed,
  insert_hydration: Ad,
  noop: Sd,
  safe_not_equal: Bd,
  svg_element: qd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Td,
  append_hydration: xd,
  attr: zd,
  children: Id,
  claim_svg_element: Rd,
  detach: Ld,
  init: Od,
  insert_hydration: Pd,
  noop: Md,
  safe_not_equal: Nd,
  svg_element: jd
} = window.__gradio__svelte__internal, {
  SvelteComponent: ka,
  append_hydration: on,
  attr: me,
  children: It,
  claim_svg_element: Rt,
  detach: ht,
  init: Ca,
  insert_hydration: Ea,
  noop: an,
  safe_not_equal: Aa,
  set_style: ke,
  svg_element: Lt
} = window.__gradio__svelte__internal;
function Sa(o) {
  let e, t, n, i;
  return {
    c() {
      e = Lt("svg"), t = Lt("g"), n = Lt("path"), i = Lt("path"), this.h();
    },
    l(a) {
      e = Rt(a, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = It(e);
      t = Rt(l, "g", { transform: !0 });
      var r = It(t);
      n = Rt(r, "path", { d: !0, style: !0 }), It(n).forEach(ht), r.forEach(ht), i = Rt(l, "path", { d: !0, style: !0 }), It(i).forEach(ht), l.forEach(ht), this.h();
    },
    h() {
      me(n, "d", "M18,6L6.087,17.913"), ke(n, "fill", "none"), ke(n, "fill-rule", "nonzero"), ke(n, "stroke-width", "2px"), me(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), me(i, "d", "M4.364,4.364L19.636,19.636"), ke(i, "fill", "none"), ke(i, "fill-rule", "nonzero"), ke(i, "stroke-width", "2px"), me(e, "width", "100%"), me(e, "height", "100%"), me(e, "viewBox", "0 0 24 24"), me(e, "version", "1.1"), me(e, "xmlns", "http://www.w3.org/2000/svg"), me(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), me(e, "xml:space", "preserve"), me(e, "stroke", "currentColor"), ke(e, "fill-rule", "evenodd"), ke(e, "clip-rule", "evenodd"), ke(e, "stroke-linecap", "round"), ke(e, "stroke-linejoin", "round");
    },
    m(a, l) {
      Ea(a, e, l), on(e, t), on(t, n), on(e, i);
    },
    p: an,
    i: an,
    o: an,
    d(a) {
      a && ht(e);
    }
  };
}
class Ba extends ka {
  constructor(e) {
    super(), Ca(this, e, null, Sa, Aa, {});
  }
}
const {
  SvelteComponent: Hd,
  append_hydration: Vd,
  attr: Ud,
  children: Gd,
  claim_svg_element: Zd,
  detach: Xd,
  init: Yd,
  insert_hydration: Wd,
  noop: Kd,
  safe_not_equal: Qd,
  svg_element: Jd
} = window.__gradio__svelte__internal, {
  SvelteComponent: eh,
  append_hydration: th,
  attr: nh,
  children: ih,
  claim_svg_element: lh,
  detach: oh,
  init: ah,
  insert_hydration: rh,
  noop: sh,
  safe_not_equal: uh,
  svg_element: _h
} = window.__gradio__svelte__internal, {
  SvelteComponent: ch,
  append_hydration: dh,
  attr: hh,
  children: fh,
  claim_svg_element: ph,
  detach: mh,
  init: gh,
  insert_hydration: vh,
  noop: bh,
  safe_not_equal: Dh,
  svg_element: yh
} = window.__gradio__svelte__internal, {
  SvelteComponent: $h,
  append_hydration: wh,
  attr: Fh,
  children: kh,
  claim_svg_element: Ch,
  detach: Eh,
  init: Ah,
  insert_hydration: Sh,
  noop: Bh,
  safe_not_equal: qh,
  svg_element: Th
} = window.__gradio__svelte__internal, {
  SvelteComponent: xh,
  append_hydration: zh,
  attr: Ih,
  children: Rh,
  claim_svg_element: Lh,
  detach: Oh,
  init: Ph,
  insert_hydration: Mh,
  noop: Nh,
  safe_not_equal: jh,
  svg_element: Hh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vh,
  append_hydration: Uh,
  attr: Gh,
  children: Zh,
  claim_svg_element: Xh,
  detach: Yh,
  init: Wh,
  insert_hydration: Kh,
  noop: Qh,
  safe_not_equal: Jh,
  svg_element: ef
} = window.__gradio__svelte__internal, {
  SvelteComponent: tf,
  append_hydration: nf,
  attr: lf,
  children: of,
  claim_svg_element: af,
  detach: rf,
  init: sf,
  insert_hydration: uf,
  noop: _f,
  safe_not_equal: cf,
  svg_element: df
} = window.__gradio__svelte__internal, {
  SvelteComponent: hf,
  append_hydration: ff,
  attr: pf,
  children: mf,
  claim_svg_element: gf,
  detach: vf,
  init: bf,
  insert_hydration: Df,
  noop: yf,
  safe_not_equal: $f,
  svg_element: wf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ff,
  append_hydration: kf,
  attr: Cf,
  children: Ef,
  claim_svg_element: Af,
  detach: Sf,
  init: Bf,
  insert_hydration: qf,
  noop: Tf,
  safe_not_equal: xf,
  svg_element: zf
} = window.__gradio__svelte__internal, {
  SvelteComponent: If,
  append_hydration: Rf,
  attr: Lf,
  children: Of,
  claim_svg_element: Pf,
  detach: Mf,
  init: Nf,
  insert_hydration: jf,
  noop: Hf,
  safe_not_equal: Vf,
  svg_element: Uf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gf,
  append_hydration: Zf,
  attr: Xf,
  children: Yf,
  claim_svg_element: Wf,
  detach: Kf,
  init: Qf,
  insert_hydration: Jf,
  noop: ep,
  safe_not_equal: tp,
  svg_element: np
} = window.__gradio__svelte__internal, {
  SvelteComponent: ip,
  append_hydration: lp,
  attr: op,
  children: ap,
  claim_svg_element: rp,
  detach: sp,
  init: up,
  insert_hydration: _p,
  noop: cp,
  safe_not_equal: dp,
  svg_element: hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: fp,
  append_hydration: pp,
  attr: mp,
  children: gp,
  claim_svg_element: vp,
  detach: bp,
  init: Dp,
  insert_hydration: yp,
  noop: $p,
  safe_not_equal: wp,
  svg_element: Fp
} = window.__gradio__svelte__internal, {
  SvelteComponent: kp,
  append_hydration: Cp,
  attr: Ep,
  children: Ap,
  claim_svg_element: Sp,
  detach: Bp,
  init: qp,
  insert_hydration: Tp,
  noop: xp,
  safe_not_equal: zp,
  svg_element: Ip
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rp,
  append_hydration: Lp,
  attr: Op,
  children: Pp,
  claim_svg_element: Mp,
  detach: Np,
  init: jp,
  insert_hydration: Hp,
  noop: Vp,
  safe_not_equal: Up,
  svg_element: Gp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zp,
  append_hydration: Xp,
  attr: Yp,
  children: Wp,
  claim_svg_element: Kp,
  detach: Qp,
  init: Jp,
  insert_hydration: em,
  noop: tm,
  safe_not_equal: nm,
  svg_element: im
} = window.__gradio__svelte__internal, {
  SvelteComponent: lm,
  append_hydration: om,
  attr: am,
  children: rm,
  claim_svg_element: sm,
  detach: um,
  init: _m,
  insert_hydration: cm,
  noop: dm,
  safe_not_equal: hm,
  svg_element: fm
} = window.__gradio__svelte__internal, {
  SvelteComponent: pm,
  append_hydration: mm,
  attr: gm,
  children: vm,
  claim_svg_element: bm,
  detach: Dm,
  init: ym,
  insert_hydration: $m,
  noop: wm,
  safe_not_equal: Fm,
  svg_element: km
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cm,
  append_hydration: Em,
  attr: Am,
  children: Sm,
  claim_svg_element: Bm,
  detach: qm,
  init: Tm,
  insert_hydration: xm,
  noop: zm,
  safe_not_equal: Im,
  svg_element: Rm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lm,
  append_hydration: Om,
  attr: Pm,
  children: Mm,
  claim_svg_element: Nm,
  detach: jm,
  init: Hm,
  insert_hydration: Vm,
  noop: Um,
  safe_not_equal: Gm,
  svg_element: Zm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xm,
  append_hydration: Ym,
  attr: Wm,
  children: Km,
  claim_svg_element: Qm,
  detach: Jm,
  init: eg,
  insert_hydration: tg,
  noop: ng,
  safe_not_equal: ig,
  svg_element: lg
} = window.__gradio__svelte__internal, {
  SvelteComponent: og,
  append_hydration: ag,
  attr: rg,
  children: sg,
  claim_svg_element: ug,
  detach: _g,
  init: cg,
  insert_hydration: dg,
  noop: hg,
  safe_not_equal: fg,
  svg_element: pg
} = window.__gradio__svelte__internal, {
  SvelteComponent: mg,
  append_hydration: gg,
  attr: vg,
  children: bg,
  claim_svg_element: Dg,
  detach: yg,
  init: $g,
  insert_hydration: wg,
  noop: Fg,
  safe_not_equal: kg,
  svg_element: Cg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Eg,
  append_hydration: Ag,
  attr: Sg,
  children: Bg,
  claim_svg_element: qg,
  detach: Tg,
  init: xg,
  insert_hydration: zg,
  noop: Ig,
  safe_not_equal: Rg,
  svg_element: Lg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Og,
  append_hydration: Pg,
  attr: Mg,
  children: Ng,
  claim_svg_element: jg,
  detach: Hg,
  init: Vg,
  insert_hydration: Ug,
  noop: Gg,
  safe_not_equal: Zg,
  svg_element: Xg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yg,
  append_hydration: Wg,
  attr: Kg,
  children: Qg,
  claim_svg_element: Jg,
  detach: e0,
  init: t0,
  insert_hydration: n0,
  noop: i0,
  safe_not_equal: l0,
  svg_element: o0
} = window.__gradio__svelte__internal, {
  SvelteComponent: a0,
  append_hydration: r0,
  attr: s0,
  children: u0,
  claim_svg_element: _0,
  detach: c0,
  init: d0,
  insert_hydration: h0,
  noop: f0,
  safe_not_equal: p0,
  svg_element: m0
} = window.__gradio__svelte__internal, {
  SvelteComponent: g0,
  append_hydration: v0,
  attr: b0,
  children: D0,
  claim_svg_element: y0,
  detach: $0,
  init: w0,
  insert_hydration: F0,
  noop: k0,
  safe_not_equal: C0,
  svg_element: E0
} = window.__gradio__svelte__internal, {
  SvelteComponent: A0,
  append_hydration: S0,
  attr: B0,
  children: q0,
  claim_svg_element: T0,
  detach: x0,
  init: z0,
  insert_hydration: I0,
  noop: R0,
  safe_not_equal: L0,
  svg_element: O0
} = window.__gradio__svelte__internal, {
  SvelteComponent: P0,
  append_hydration: M0,
  attr: N0,
  children: j0,
  claim_svg_element: H0,
  detach: V0,
  init: U0,
  insert_hydration: G0,
  noop: Z0,
  safe_not_equal: X0,
  svg_element: Y0
} = window.__gradio__svelte__internal, {
  SvelteComponent: W0,
  append_hydration: K0,
  attr: Q0,
  children: J0,
  claim_svg_element: e1,
  detach: t1,
  init: n1,
  insert_hydration: i1,
  noop: l1,
  safe_not_equal: o1,
  svg_element: a1
} = window.__gradio__svelte__internal, {
  SvelteComponent: r1,
  append_hydration: s1,
  attr: u1,
  children: _1,
  claim_svg_element: c1,
  detach: d1,
  init: h1,
  insert_hydration: f1,
  noop: p1,
  safe_not_equal: m1,
  svg_element: g1
} = window.__gradio__svelte__internal, {
  SvelteComponent: v1,
  append_hydration: b1,
  attr: D1,
  children: y1,
  claim_svg_element: $1,
  detach: w1,
  init: F1,
  insert_hydration: k1,
  noop: C1,
  safe_not_equal: E1,
  svg_element: A1
} = window.__gradio__svelte__internal, {
  SvelteComponent: S1,
  append_hydration: B1,
  attr: q1,
  children: T1,
  claim_svg_element: x1,
  detach: z1,
  init: I1,
  insert_hydration: R1,
  noop: L1,
  safe_not_equal: O1,
  set_style: P1,
  svg_element: M1
} = window.__gradio__svelte__internal, {
  SvelteComponent: N1,
  append_hydration: j1,
  attr: H1,
  children: V1,
  claim_svg_element: U1,
  detach: G1,
  init: Z1,
  insert_hydration: X1,
  noop: Y1,
  safe_not_equal: W1,
  svg_element: K1
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q1,
  append_hydration: J1,
  attr: ev,
  children: tv,
  claim_svg_element: nv,
  detach: iv,
  init: lv,
  insert_hydration: ov,
  noop: av,
  safe_not_equal: rv,
  svg_element: sv
} = window.__gradio__svelte__internal, {
  SvelteComponent: uv,
  append_hydration: _v,
  attr: cv,
  children: dv,
  claim_svg_element: hv,
  detach: fv,
  init: pv,
  insert_hydration: mv,
  noop: gv,
  safe_not_equal: vv,
  svg_element: bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dv,
  append_hydration: yv,
  attr: $v,
  children: wv,
  claim_svg_element: Fv,
  detach: kv,
  init: Cv,
  insert_hydration: Ev,
  noop: Av,
  safe_not_equal: Sv,
  svg_element: Bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: qv,
  append_hydration: Tv,
  attr: xv,
  children: zv,
  claim_svg_element: Iv,
  detach: Rv,
  init: Lv,
  insert_hydration: Ov,
  noop: Pv,
  safe_not_equal: Mv,
  svg_element: Nv
} = window.__gradio__svelte__internal, {
  SvelteComponent: jv,
  append_hydration: Hv,
  attr: Vv,
  children: Uv,
  claim_svg_element: Gv,
  detach: Zv,
  init: Xv,
  insert_hydration: Yv,
  noop: Wv,
  safe_not_equal: Kv,
  svg_element: Qv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jv,
  append_hydration: eb,
  attr: tb,
  children: nb,
  claim_svg_element: ib,
  detach: lb,
  init: ob,
  insert_hydration: ab,
  noop: rb,
  safe_not_equal: sb,
  svg_element: ub
} = window.__gradio__svelte__internal, {
  SvelteComponent: _b,
  append_hydration: cb,
  attr: db,
  children: hb,
  claim_svg_element: fb,
  detach: pb,
  init: mb,
  insert_hydration: gb,
  noop: vb,
  safe_not_equal: bb,
  svg_element: Db
} = window.__gradio__svelte__internal, {
  SvelteComponent: yb,
  append_hydration: $b,
  attr: wb,
  children: Fb,
  claim_svg_element: kb,
  claim_text: Cb,
  detach: Eb,
  init: Ab,
  insert_hydration: Sb,
  noop: Bb,
  safe_not_equal: qb,
  svg_element: Tb,
  text: xb
} = window.__gradio__svelte__internal, {
  SvelteComponent: zb,
  append_hydration: Ib,
  attr: Rb,
  children: Lb,
  claim_svg_element: Ob,
  detach: Pb,
  init: Mb,
  insert_hydration: Nb,
  noop: jb,
  safe_not_equal: Hb,
  svg_element: Vb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ub,
  append_hydration: Gb,
  attr: Zb,
  children: Xb,
  claim_svg_element: Yb,
  detach: Wb,
  init: Kb,
  insert_hydration: Qb,
  noop: Jb,
  safe_not_equal: eD,
  svg_element: tD
} = window.__gradio__svelte__internal, {
  SvelteComponent: nD,
  append_hydration: iD,
  attr: lD,
  children: oD,
  claim_svg_element: aD,
  detach: rD,
  init: sD,
  insert_hydration: uD,
  noop: _D,
  safe_not_equal: cD,
  svg_element: dD
} = window.__gradio__svelte__internal, {
  SvelteComponent: hD,
  append_hydration: fD,
  attr: pD,
  children: mD,
  claim_svg_element: gD,
  detach: vD,
  init: bD,
  insert_hydration: DD,
  noop: yD,
  safe_not_equal: $D,
  svg_element: wD
} = window.__gradio__svelte__internal, {
  SvelteComponent: FD,
  append_hydration: kD,
  attr: CD,
  children: ED,
  claim_svg_element: AD,
  detach: SD,
  init: BD,
  insert_hydration: qD,
  noop: TD,
  safe_not_equal: xD,
  svg_element: zD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ID,
  append_hydration: RD,
  attr: LD,
  children: OD,
  claim_svg_element: PD,
  detach: MD,
  init: ND,
  insert_hydration: jD,
  noop: HD,
  safe_not_equal: VD,
  svg_element: UD
} = window.__gradio__svelte__internal, {
  SvelteComponent: GD,
  append_hydration: ZD,
  attr: XD,
  children: YD,
  claim_svg_element: WD,
  detach: KD,
  init: QD,
  insert_hydration: JD,
  noop: ey,
  safe_not_equal: ty,
  svg_element: ny
} = window.__gradio__svelte__internal, {
  SvelteComponent: iy,
  append_hydration: ly,
  attr: oy,
  children: ay,
  claim_svg_element: ry,
  claim_text: sy,
  detach: uy,
  init: _y,
  insert_hydration: cy,
  noop: dy,
  safe_not_equal: hy,
  svg_element: fy,
  text: py
} = window.__gradio__svelte__internal, {
  SvelteComponent: my,
  append_hydration: gy,
  attr: vy,
  children: by,
  claim_svg_element: Dy,
  claim_text: yy,
  detach: $y,
  init: wy,
  insert_hydration: Fy,
  noop: ky,
  safe_not_equal: Cy,
  svg_element: Ey,
  text: Ay
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sy,
  append_hydration: By,
  attr: qy,
  children: Ty,
  claim_svg_element: xy,
  claim_text: zy,
  detach: Iy,
  init: Ry,
  insert_hydration: Ly,
  noop: Oy,
  safe_not_equal: Py,
  svg_element: My,
  text: Ny
} = window.__gradio__svelte__internal, {
  SvelteComponent: jy,
  append_hydration: Hy,
  attr: Vy,
  children: Uy,
  claim_svg_element: Gy,
  detach: Zy,
  init: Xy,
  insert_hydration: Yy,
  noop: Wy,
  safe_not_equal: Ky,
  svg_element: Qy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jy,
  append_hydration: e$,
  attr: t$,
  children: n$,
  claim_svg_element: i$,
  detach: l$,
  init: o$,
  insert_hydration: a$,
  noop: r$,
  safe_not_equal: s$,
  svg_element: u$
} = window.__gradio__svelte__internal, {
  SvelteComponent: _$,
  append_hydration: c$,
  attr: d$,
  children: h$,
  claim_svg_element: f$,
  detach: p$,
  init: m$,
  insert_hydration: g$,
  noop: v$,
  safe_not_equal: b$,
  svg_element: D$
} = window.__gradio__svelte__internal, {
  SvelteComponent: y$,
  append_hydration: $$,
  attr: w$,
  children: F$,
  claim_svg_element: k$,
  detach: C$,
  init: E$,
  insert_hydration: A$,
  noop: S$,
  safe_not_equal: B$,
  svg_element: q$
} = window.__gradio__svelte__internal, {
  SvelteComponent: T$,
  append_hydration: x$,
  attr: z$,
  children: I$,
  claim_svg_element: R$,
  detach: L$,
  init: O$,
  insert_hydration: P$,
  noop: M$,
  safe_not_equal: N$,
  svg_element: j$
} = window.__gradio__svelte__internal, {
  SvelteComponent: H$,
  append_hydration: V$,
  attr: U$,
  children: G$,
  claim_svg_element: Z$,
  detach: X$,
  init: Y$,
  insert_hydration: W$,
  noop: K$,
  safe_not_equal: Q$,
  svg_element: J$
} = window.__gradio__svelte__internal, {
  SvelteComponent: ew,
  append_hydration: tw,
  attr: nw,
  children: iw,
  claim_svg_element: lw,
  detach: ow,
  init: aw,
  insert_hydration: rw,
  noop: sw,
  safe_not_equal: uw,
  svg_element: _w
} = window.__gradio__svelte__internal, {
  SvelteComponent: cw,
  append_hydration: dw,
  attr: hw,
  children: fw,
  claim_svg_element: pw,
  detach: mw,
  init: gw,
  insert_hydration: vw,
  noop: bw,
  safe_not_equal: Dw,
  svg_element: yw
} = window.__gradio__svelte__internal, {
  SvelteComponent: $w,
  append_hydration: ww,
  attr: Fw,
  children: kw,
  claim_svg_element: Cw,
  detach: Ew,
  init: Aw,
  insert_hydration: Sw,
  noop: Bw,
  safe_not_equal: qw,
  svg_element: Tw
} = window.__gradio__svelte__internal, {
  SvelteComponent: xw,
  append_hydration: zw,
  attr: Iw,
  children: Rw,
  claim_svg_element: Lw,
  detach: Ow,
  init: Pw,
  insert_hydration: Mw,
  noop: Nw,
  safe_not_equal: jw,
  svg_element: Hw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vw,
  append_hydration: Uw,
  attr: Gw,
  children: Zw,
  claim_svg_element: Xw,
  detach: Yw,
  init: Ww,
  insert_hydration: Kw,
  noop: Qw,
  safe_not_equal: Jw,
  svg_element: e2
} = window.__gradio__svelte__internal, qa = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ei = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
qa.reduce(
  (o, { color: e, primary: t, secondary: n }) => ({
    ...o,
    [e]: {
      primary: ei[e][t],
      secondary: ei[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: t2,
  claim_component: n2,
  create_component: i2,
  destroy_component: l2,
  init: o2,
  mount_component: a2,
  safe_not_equal: r2,
  transition_in: s2,
  transition_out: u2
} = window.__gradio__svelte__internal, { createEventDispatcher: _2 } = window.__gradio__svelte__internal, {
  SvelteComponent: c2,
  append_hydration: d2,
  attr: h2,
  check_outros: f2,
  children: p2,
  claim_component: m2,
  claim_element: g2,
  claim_space: v2,
  claim_text: b2,
  create_component: D2,
  destroy_component: y2,
  detach: $2,
  element: w2,
  empty: F2,
  group_outros: k2,
  init: C2,
  insert_hydration: E2,
  mount_component: A2,
  safe_not_equal: S2,
  set_data: B2,
  space: q2,
  text: T2,
  toggle_class: x2,
  transition_in: z2,
  transition_out: I2
} = window.__gradio__svelte__internal, {
  SvelteComponent: R2,
  attr: L2,
  children: O2,
  claim_element: P2,
  create_slot: M2,
  detach: N2,
  element: j2,
  get_all_dirty_from_scope: H2,
  get_slot_changes: V2,
  init: U2,
  insert_hydration: G2,
  safe_not_equal: Z2,
  toggle_class: X2,
  transition_in: Y2,
  transition_out: W2,
  update_slot_base: K2
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q2,
  append_hydration: J2,
  attr: eF,
  check_outros: tF,
  children: nF,
  claim_component: iF,
  claim_element: lF,
  claim_space: oF,
  create_component: aF,
  destroy_component: rF,
  detach: sF,
  element: uF,
  empty: _F,
  group_outros: cF,
  init: dF,
  insert_hydration: hF,
  listen: fF,
  mount_component: pF,
  safe_not_equal: mF,
  space: gF,
  toggle_class: vF,
  transition_in: bF,
  transition_out: DF
} = window.__gradio__svelte__internal, {
  SvelteComponent: yF,
  attr: $F,
  children: wF,
  claim_element: FF,
  create_slot: kF,
  detach: CF,
  element: EF,
  get_all_dirty_from_scope: AF,
  get_slot_changes: SF,
  init: BF,
  insert_hydration: qF,
  null_to_empty: TF,
  safe_not_equal: xF,
  transition_in: zF,
  transition_out: IF,
  update_slot_base: RF
} = window.__gradio__svelte__internal, {
  SvelteComponent: LF,
  check_outros: OF,
  claim_component: PF,
  create_component: MF,
  destroy_component: NF,
  detach: jF,
  empty: HF,
  group_outros: VF,
  init: UF,
  insert_hydration: GF,
  mount_component: ZF,
  noop: XF,
  safe_not_equal: YF,
  transition_in: WF,
  transition_out: KF
} = window.__gradio__svelte__internal, { createEventDispatcher: QF } = window.__gradio__svelte__internal;
function at(o) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; o > 1e3 && t < e.length - 1; )
    o /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(o) ? o : o.toFixed(1)) + n;
}
function Ht() {
}
const Sl = typeof window < "u";
let ti = Sl ? () => window.performance.now() : () => Date.now(), Bl = Sl ? (o) => requestAnimationFrame(o) : Ht;
const rt = /* @__PURE__ */ new Set();
function ql(o) {
  rt.forEach((e) => {
    e.c(o) || (rt.delete(e), e.f());
  }), rt.size !== 0 && Bl(ql);
}
function Ta(o) {
  let e;
  return rt.size === 0 && Bl(ql), { promise: new Promise((t) => {
    rt.add(e = { c: o, f: t });
  }), abort() {
    rt.delete(e);
  } };
}
const ot = [];
function xa(o, e = Ht) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function i(l) {
    if (s = l, ((r = o) != r ? s == s : r !== s || r && typeof r == "object" || typeof r == "function") && (o = l, t)) {
      const u = !ot.length;
      for (const _ of n) _[1](), ot.push(_, o);
      if (u) {
        for (let _ = 0; _ < ot.length; _ += 2) ot[_][0](ot[_ + 1]);
        ot.length = 0;
      }
    }
    var r, s;
  }
  function a(l) {
    i(l(o));
  }
  return { set: i, update: a, subscribe: function(l, r = Ht) {
    const s = [l, r];
    return n.add(s), n.size === 1 && (t = e(i, a) || Ht), l(o), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function ni(o) {
  return Object.prototype.toString.call(o) === "[object Date]";
}
function fn(o, e, t, n) {
  if (typeof t == "number" || ni(t)) {
    const i = n - t, a = (t - e) / (o.dt || 1 / 60), l = (a + (o.opts.stiffness * i - o.opts.damping * a) * o.inv_mass) * o.dt;
    return Math.abs(l) < o.opts.precision && Math.abs(i) < o.opts.precision ? n : (o.settled = !1, ni(t) ? new Date(t.getTime() + l) : t + l);
  }
  if (Array.isArray(t)) return t.map((i, a) => fn(o, e[a], t[a], n[a]));
  if (typeof t == "object") {
    const i = {};
    for (const a in t) i[a] = fn(o, e[a], t[a], n[a]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function ii(o, e = {}) {
  const t = xa(o), { stiffness: n = 0.15, damping: i = 0.8, precision: a = 0.01 } = e;
  let l, r, s, u = o, _ = o, c = 1, d = 0, f = !1;
  function g(v, F = {}) {
    _ = v;
    const p = s = {};
    return o == null || F.hard || m.stiffness >= 1 && m.damping >= 1 ? (f = !0, l = ti(), u = v, t.set(o = _), Promise.resolve()) : (F.soft && (d = 1 / (60 * (F.soft === !0 ? 0.5 : +F.soft)), c = 0), r || (l = ti(), f = !1, r = Ta((h) => {
      if (f) return f = !1, r = null, !1;
      c = Math.min(c + d, 1);
      const b = { inv_mass: c, opts: m, settled: !0, dt: 60 * (h - l) / 1e3 }, y = fn(b, u, o, _);
      return l = h, u = o, t.set(o = y), b.settled && (r = null), !b.settled;
    })), new Promise((h) => {
      r.promise.then(() => {
        p === s && h();
      });
    }));
  }
  const m = { set: g, update: (v, F) => g(v(_, o), F), subscribe: t.subscribe, stiffness: n, damping: i, precision: a };
  return m;
}
const {
  SvelteComponent: za,
  append_hydration: ge,
  attr: T,
  children: ae,
  claim_element: Ia,
  claim_svg_element: ve,
  component_subscribe: li,
  detach: le,
  element: Ra,
  init: La,
  insert_hydration: Oa,
  noop: oi,
  safe_not_equal: Pa,
  set_style: Ot,
  svg_element: be,
  toggle_class: ai
} = window.__gradio__svelte__internal, { onMount: Ma } = window.__gradio__svelte__internal;
function Na(o) {
  let e, t, n, i, a, l, r, s, u, _, c, d;
  return {
    c() {
      e = Ra("div"), t = be("svg"), n = be("g"), i = be("path"), a = be("path"), l = be("path"), r = be("path"), s = be("g"), u = be("path"), _ = be("path"), c = be("path"), d = be("path"), this.h();
    },
    l(f) {
      e = Ia(f, "DIV", { class: !0 });
      var g = ae(e);
      t = ve(g, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var m = ae(t);
      n = ve(m, "g", { style: !0 });
      var v = ae(n);
      i = ve(v, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ae(i).forEach(le), a = ve(v, "path", { d: !0, fill: !0, class: !0 }), ae(a).forEach(le), l = ve(v, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ae(l).forEach(le), r = ve(v, "path", { d: !0, fill: !0, class: !0 }), ae(r).forEach(le), v.forEach(le), s = ve(m, "g", { style: !0 });
      var F = ae(s);
      u = ve(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ae(u).forEach(le), _ = ve(F, "path", { d: !0, fill: !0, class: !0 }), ae(_).forEach(le), c = ve(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ae(c).forEach(le), d = ve(F, "path", { d: !0, fill: !0, class: !0 }), ae(d).forEach(le), F.forEach(le), m.forEach(le), g.forEach(le), this.h();
    },
    h() {
      T(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), T(i, "fill", "#FF7C00"), T(i, "fill-opacity", "0.4"), T(i, "class", "svelte-43sxxs"), T(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), T(a, "fill", "#FF7C00"), T(a, "class", "svelte-43sxxs"), T(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), T(l, "fill", "#FF7C00"), T(l, "fill-opacity", "0.4"), T(l, "class", "svelte-43sxxs"), T(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), T(r, "fill", "#FF7C00"), T(r, "class", "svelte-43sxxs"), Ot(n, "transform", "translate(" + /*$top*/
      o[1][0] + "px, " + /*$top*/
      o[1][1] + "px)"), T(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), T(u, "fill", "#FF7C00"), T(u, "fill-opacity", "0.4"), T(u, "class", "svelte-43sxxs"), T(_, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), T(_, "fill", "#FF7C00"), T(_, "class", "svelte-43sxxs"), T(c, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), T(c, "fill", "#FF7C00"), T(c, "fill-opacity", "0.4"), T(c, "class", "svelte-43sxxs"), T(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), T(d, "fill", "#FF7C00"), T(d, "class", "svelte-43sxxs"), Ot(s, "transform", "translate(" + /*$bottom*/
      o[2][0] + "px, " + /*$bottom*/
      o[2][1] + "px)"), T(t, "viewBox", "-1200 -1200 3000 3000"), T(t, "fill", "none"), T(t, "xmlns", "http://www.w3.org/2000/svg"), T(t, "class", "svelte-43sxxs"), T(e, "class", "svelte-43sxxs"), ai(
        e,
        "margin",
        /*margin*/
        o[0]
      );
    },
    m(f, g) {
      Oa(f, e, g), ge(e, t), ge(t, n), ge(n, i), ge(n, a), ge(n, l), ge(n, r), ge(t, s), ge(s, u), ge(s, _), ge(s, c), ge(s, d);
    },
    p(f, [g]) {
      g & /*$top*/
      2 && Ot(n, "transform", "translate(" + /*$top*/
      f[1][0] + "px, " + /*$top*/
      f[1][1] + "px)"), g & /*$bottom*/
      4 && Ot(s, "transform", "translate(" + /*$bottom*/
      f[2][0] + "px, " + /*$bottom*/
      f[2][1] + "px)"), g & /*margin*/
      1 && ai(
        e,
        "margin",
        /*margin*/
        f[0]
      );
    },
    i: oi,
    o: oi,
    d(f) {
      f && le(e);
    }
  };
}
function ja(o, e, t) {
  let n, i;
  var a = this && this.__awaiter || function(f, g, m, v) {
    function F(p) {
      return p instanceof m ? p : new m(function(h) {
        h(p);
      });
    }
    return new (m || (m = Promise))(function(p, h) {
      function b($) {
        try {
          D(v.next($));
        } catch (S) {
          h(S);
        }
      }
      function y($) {
        try {
          D(v.throw($));
        } catch (S) {
          h(S);
        }
      }
      function D($) {
        $.done ? p($.value) : F($.value).then(b, y);
      }
      D((v = v.apply(f, g || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const r = ii([0, 0]);
  li(o, r, (f) => t(1, n = f));
  const s = ii([0, 0]);
  li(o, s, (f) => t(2, i = f));
  let u;
  function _() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), s.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), s.set([125, -140])]), yield Promise.all([r.set([-125, 0]), s.set([125, -0])]), yield Promise.all([r.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function c() {
    return a(this, void 0, void 0, function* () {
      yield _(), u || c();
    });
  }
  function d() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), s.set([-125, 0])]), c();
    });
  }
  return Ma(() => (d(), () => u = !0)), o.$$set = (f) => {
    "margin" in f && t(0, l = f.margin);
  }, [l, n, i, r, s];
}
class Ha extends za {
  constructor(e) {
    super(), La(this, e, ja, Na, Pa, { margin: 0 });
  }
}
const {
  SvelteComponent: Va,
  append_hydration: We,
  attr: $e,
  binding_callbacks: ri,
  check_outros: pn,
  children: Be,
  claim_component: Tl,
  claim_element: qe,
  claim_space: _e,
  claim_text: j,
  create_component: xl,
  create_slot: zl,
  destroy_component: Il,
  destroy_each: Rl,
  detach: A,
  element: Te,
  empty: he,
  ensure_array_like: Zt,
  get_all_dirty_from_scope: Ll,
  get_slot_changes: Ol,
  group_outros: mn,
  init: Ua,
  insert_hydration: B,
  mount_component: Pl,
  noop: gn,
  safe_not_equal: Ga,
  set_data: fe,
  set_style: Ve,
  space: ce,
  text: H,
  toggle_class: re,
  transition_in: ye,
  transition_out: xe,
  update_slot_base: Ml
} = window.__gradio__svelte__internal, { tick: Za } = window.__gradio__svelte__internal, { onDestroy: Xa } = window.__gradio__svelte__internal, { createEventDispatcher: Ya } = window.__gradio__svelte__internal, Wa = (o) => ({}), si = (o) => ({}), Ka = (o) => ({}), ui = (o) => ({});
function _i(o, e, t) {
  const n = o.slice();
  return n[40] = e[t], n[42] = t, n;
}
function ci(o, e, t) {
  const n = o.slice();
  return n[40] = e[t], n;
}
function Qa(o) {
  let e, t, n, i, a = (
    /*i18n*/
    o[1]("common.error") + ""
  ), l, r, s;
  t = new Fa({
    props: {
      Icon: Ba,
      label: (
        /*i18n*/
        o[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    o[32]
  );
  const u = (
    /*#slots*/
    o[30].error
  ), _ = zl(
    u,
    o,
    /*$$scope*/
    o[29],
    si
  );
  return {
    c() {
      e = Te("div"), xl(t.$$.fragment), n = ce(), i = Te("span"), l = H(a), r = ce(), _ && _.c(), this.h();
    },
    l(c) {
      e = qe(c, "DIV", { class: !0 });
      var d = Be(e);
      Tl(t.$$.fragment, d), d.forEach(A), n = _e(c), i = qe(c, "SPAN", { class: !0 });
      var f = Be(i);
      l = j(f, a), f.forEach(A), r = _e(c), _ && _.l(c), this.h();
    },
    h() {
      $e(e, "class", "clear-status svelte-17v219f"), $e(i, "class", "error svelte-17v219f");
    },
    m(c, d) {
      B(c, e, d), Pl(t, e, null), B(c, n, d), B(c, i, d), We(i, l), B(c, r, d), _ && _.m(c, d), s = !0;
    },
    p(c, d) {
      const f = {};
      d[0] & /*i18n*/
      2 && (f.label = /*i18n*/
      c[1]("common.clear")), t.$set(f), (!s || d[0] & /*i18n*/
      2) && a !== (a = /*i18n*/
      c[1]("common.error") + "") && fe(l, a), _ && _.p && (!s || d[0] & /*$$scope*/
      536870912) && Ml(
        _,
        u,
        c,
        /*$$scope*/
        c[29],
        s ? Ol(
          u,
          /*$$scope*/
          c[29],
          d,
          Wa
        ) : Ll(
          /*$$scope*/
          c[29]
        ),
        si
      );
    },
    i(c) {
      s || (ye(t.$$.fragment, c), ye(_, c), s = !0);
    },
    o(c) {
      xe(t.$$.fragment, c), xe(_, c), s = !1;
    },
    d(c) {
      c && (A(e), A(n), A(i), A(r)), Il(t), _ && _.d(c);
    }
  };
}
function Ja(o) {
  let e, t, n, i, a, l, r, s, u, _ = (
    /*variant*/
    o[8] === "default" && /*show_eta_bar*/
    o[18] && /*show_progress*/
    o[6] === "full" && di(o)
  );
  function c(h, b) {
    if (
      /*progress*/
      h[7]
    ) return nr;
    if (
      /*queue_position*/
      h[2] !== null && /*queue_size*/
      h[3] !== void 0 && /*queue_position*/
      h[2] >= 0
    ) return tr;
    if (
      /*queue_position*/
      h[2] === 0
    ) return er;
  }
  let d = c(o), f = d && d(o), g = (
    /*timer*/
    o[5] && pi(o)
  );
  const m = [ar, or], v = [];
  function F(h, b) {
    return (
      /*last_progress_level*/
      h[15] != null ? 0 : (
        /*show_progress*/
        h[6] === "full" ? 1 : -1
      )
    );
  }
  ~(a = F(o)) && (l = v[a] = m[a](o));
  let p = !/*timer*/
  o[5] && $i(o);
  return {
    c() {
      _ && _.c(), e = ce(), t = Te("div"), f && f.c(), n = ce(), g && g.c(), i = ce(), l && l.c(), r = ce(), p && p.c(), s = he(), this.h();
    },
    l(h) {
      _ && _.l(h), e = _e(h), t = qe(h, "DIV", { class: !0 });
      var b = Be(t);
      f && f.l(b), n = _e(b), g && g.l(b), b.forEach(A), i = _e(h), l && l.l(h), r = _e(h), p && p.l(h), s = he(), this.h();
    },
    h() {
      $e(t, "class", "progress-text svelte-17v219f"), re(
        t,
        "meta-text-center",
        /*variant*/
        o[8] === "center"
      ), re(
        t,
        "meta-text",
        /*variant*/
        o[8] === "default"
      );
    },
    m(h, b) {
      _ && _.m(h, b), B(h, e, b), B(h, t, b), f && f.m(t, null), We(t, n), g && g.m(t, null), B(h, i, b), ~a && v[a].m(h, b), B(h, r, b), p && p.m(h, b), B(h, s, b), u = !0;
    },
    p(h, b) {
      /*variant*/
      h[8] === "default" && /*show_eta_bar*/
      h[18] && /*show_progress*/
      h[6] === "full" ? _ ? _.p(h, b) : (_ = di(h), _.c(), _.m(e.parentNode, e)) : _ && (_.d(1), _ = null), d === (d = c(h)) && f ? f.p(h, b) : (f && f.d(1), f = d && d(h), f && (f.c(), f.m(t, n))), /*timer*/
      h[5] ? g ? g.p(h, b) : (g = pi(h), g.c(), g.m(t, null)) : g && (g.d(1), g = null), (!u || b[0] & /*variant*/
      256) && re(
        t,
        "meta-text-center",
        /*variant*/
        h[8] === "center"
      ), (!u || b[0] & /*variant*/
      256) && re(
        t,
        "meta-text",
        /*variant*/
        h[8] === "default"
      );
      let y = a;
      a = F(h), a === y ? ~a && v[a].p(h, b) : (l && (mn(), xe(v[y], 1, 1, () => {
        v[y] = null;
      }), pn()), ~a ? (l = v[a], l ? l.p(h, b) : (l = v[a] = m[a](h), l.c()), ye(l, 1), l.m(r.parentNode, r)) : l = null), /*timer*/
      h[5] ? p && (mn(), xe(p, 1, 1, () => {
        p = null;
      }), pn()) : p ? (p.p(h, b), b[0] & /*timer*/
      32 && ye(p, 1)) : (p = $i(h), p.c(), ye(p, 1), p.m(s.parentNode, s));
    },
    i(h) {
      u || (ye(l), ye(p), u = !0);
    },
    o(h) {
      xe(l), xe(p), u = !1;
    },
    d(h) {
      h && (A(e), A(t), A(i), A(r), A(s)), _ && _.d(h), f && f.d(), g && g.d(), ~a && v[a].d(h), p && p.d(h);
    }
  };
}
function di(o) {
  let e, t = `translateX(${/*eta_level*/
  (o[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Te("div"), this.h();
    },
    l(n) {
      e = qe(n, "DIV", { class: !0 }), Be(e).forEach(A), this.h();
    },
    h() {
      $e(e, "class", "eta-bar svelte-17v219f"), Ve(e, "transform", t);
    },
    m(n, i) {
      B(n, e, i);
    },
    p(n, i) {
      i[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && Ve(e, "transform", t);
    },
    d(n) {
      n && A(e);
    }
  };
}
function er(o) {
  let e;
  return {
    c() {
      e = H("processing |");
    },
    l(t) {
      e = j(t, "processing |");
    },
    m(t, n) {
      B(t, e, n);
    },
    p: gn,
    d(t) {
      t && A(e);
    }
  };
}
function tr(o) {
  let e, t = (
    /*queue_position*/
    o[2] + 1 + ""
  ), n, i, a, l;
  return {
    c() {
      e = H("queue: "), n = H(t), i = H("/"), a = H(
        /*queue_size*/
        o[3]
      ), l = H(" |");
    },
    l(r) {
      e = j(r, "queue: "), n = j(r, t), i = j(r, "/"), a = j(
        r,
        /*queue_size*/
        o[3]
      ), l = j(r, " |");
    },
    m(r, s) {
      B(r, e, s), B(r, n, s), B(r, i, s), B(r, a, s), B(r, l, s);
    },
    p(r, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && fe(n, t), s[0] & /*queue_size*/
      8 && fe(
        a,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (A(e), A(n), A(i), A(a), A(l));
    }
  };
}
function nr(o) {
  let e, t = Zt(
    /*progress*/
    o[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = fi(ci(o, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = he();
    },
    l(i) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(i);
      e = he();
    },
    m(i, a) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(i, a);
      B(i, e, a);
    },
    p(i, a) {
      if (a[0] & /*progress*/
      128) {
        t = Zt(
          /*progress*/
          i[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = ci(i, t, l);
          n[l] ? n[l].p(r, a) : (n[l] = fi(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && A(e), Rl(n, i);
    }
  };
}
function hi(o) {
  let e, t = (
    /*p*/
    o[40].unit + ""
  ), n, i, a = " ", l;
  function r(_, c) {
    return (
      /*p*/
      _[40].length != null ? lr : ir
    );
  }
  let s = r(o), u = s(o);
  return {
    c() {
      u.c(), e = ce(), n = H(t), i = H(" | "), l = H(a);
    },
    l(_) {
      u.l(_), e = _e(_), n = j(_, t), i = j(_, " | "), l = j(_, a);
    },
    m(_, c) {
      u.m(_, c), B(_, e, c), B(_, n, c), B(_, i, c), B(_, l, c);
    },
    p(_, c) {
      s === (s = r(_)) && u ? u.p(_, c) : (u.d(1), u = s(_), u && (u.c(), u.m(e.parentNode, e))), c[0] & /*progress*/
      128 && t !== (t = /*p*/
      _[40].unit + "") && fe(n, t);
    },
    d(_) {
      _ && (A(e), A(n), A(i), A(l)), u.d(_);
    }
  };
}
function ir(o) {
  let e = at(
    /*p*/
    o[40].index || 0
  ) + "", t;
  return {
    c() {
      t = H(e);
    },
    l(n) {
      t = j(n, e);
    },
    m(n, i) {
      B(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = at(
        /*p*/
        n[40].index || 0
      ) + "") && fe(t, e);
    },
    d(n) {
      n && A(t);
    }
  };
}
function lr(o) {
  let e = at(
    /*p*/
    o[40].index || 0
  ) + "", t, n, i = at(
    /*p*/
    o[40].length
  ) + "", a;
  return {
    c() {
      t = H(e), n = H("/"), a = H(i);
    },
    l(l) {
      t = j(l, e), n = j(l, "/"), a = j(l, i);
    },
    m(l, r) {
      B(l, t, r), B(l, n, r), B(l, a, r);
    },
    p(l, r) {
      r[0] & /*progress*/
      128 && e !== (e = at(
        /*p*/
        l[40].index || 0
      ) + "") && fe(t, e), r[0] & /*progress*/
      128 && i !== (i = at(
        /*p*/
        l[40].length
      ) + "") && fe(a, i);
    },
    d(l) {
      l && (A(t), A(n), A(a));
    }
  };
}
function fi(o) {
  let e, t = (
    /*p*/
    o[40].index != null && hi(o)
  );
  return {
    c() {
      t && t.c(), e = he();
    },
    l(n) {
      t && t.l(n), e = he();
    },
    m(n, i) {
      t && t.m(n, i), B(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].index != null ? t ? t.p(n, i) : (t = hi(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && A(e), t && t.d(n);
    }
  };
}
function pi(o) {
  let e, t = (
    /*eta*/
    o[0] ? `/${/*formatted_eta*/
    o[19]}` : ""
  ), n, i;
  return {
    c() {
      e = H(
        /*formatted_timer*/
        o[20]
      ), n = H(t), i = H("s");
    },
    l(a) {
      e = j(
        a,
        /*formatted_timer*/
        o[20]
      ), n = j(a, t), i = j(a, "s");
    },
    m(a, l) {
      B(a, e, l), B(a, n, l), B(a, i, l);
    },
    p(a, l) {
      l[0] & /*formatted_timer*/
      1048576 && fe(
        e,
        /*formatted_timer*/
        a[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[19]}` : "") && fe(n, t);
    },
    d(a) {
      a && (A(e), A(n), A(i));
    }
  };
}
function or(o) {
  let e, t;
  return e = new Ha({
    props: { margin: (
      /*variant*/
      o[8] === "default"
    ) }
  }), {
    c() {
      xl(e.$$.fragment);
    },
    l(n) {
      Tl(e.$$.fragment, n);
    },
    m(n, i) {
      Pl(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*variant*/
      256 && (a.margin = /*variant*/
      n[8] === "default"), e.$set(a);
    },
    i(n) {
      t || (ye(e.$$.fragment, n), t = !0);
    },
    o(n) {
      xe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Il(e, n);
    }
  };
}
function ar(o) {
  let e, t, n, i, a, l = `${/*last_progress_level*/
  o[15] * 100}%`, r = (
    /*progress*/
    o[7] != null && mi(o)
  );
  return {
    c() {
      e = Te("div"), t = Te("div"), r && r.c(), n = ce(), i = Te("div"), a = Te("div"), this.h();
    },
    l(s) {
      e = qe(s, "DIV", { class: !0 });
      var u = Be(e);
      t = qe(u, "DIV", { class: !0 });
      var _ = Be(t);
      r && r.l(_), _.forEach(A), n = _e(u), i = qe(u, "DIV", { class: !0 });
      var c = Be(i);
      a = qe(c, "DIV", { class: !0 }), Be(a).forEach(A), c.forEach(A), u.forEach(A), this.h();
    },
    h() {
      $e(t, "class", "progress-level-inner svelte-17v219f"), $e(a, "class", "progress-bar svelte-17v219f"), Ve(a, "width", l), $e(i, "class", "progress-bar-wrap svelte-17v219f"), $e(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      B(s, e, u), We(e, t), r && r.m(t, null), We(e, n), We(e, i), We(i, a), o[31](a);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? r ? r.p(s, u) : (r = mi(s), r.c(), r.m(t, null)) : r && (r.d(1), r = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && Ve(a, "width", l);
    },
    i: gn,
    o: gn,
    d(s) {
      s && A(e), r && r.d(), o[31](null);
    }
  };
}
function mi(o) {
  let e, t = Zt(
    /*progress*/
    o[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = yi(_i(o, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = he();
    },
    l(i) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(i);
      e = he();
    },
    m(i, a) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(i, a);
      B(i, e, a);
    },
    p(i, a) {
      if (a[0] & /*progress_level, progress*/
      16512) {
        t = Zt(
          /*progress*/
          i[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = _i(i, t, l);
          n[l] ? n[l].p(r, a) : (n[l] = yi(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && A(e), Rl(n, i);
    }
  };
}
function gi(o) {
  let e, t, n, i, a = (
    /*i*/
    o[42] !== 0 && rr()
  ), l = (
    /*p*/
    o[40].desc != null && vi(o)
  ), r = (
    /*p*/
    o[40].desc != null && /*progress_level*/
    o[14] && /*progress_level*/
    o[14][
      /*i*/
      o[42]
    ] != null && bi()
  ), s = (
    /*progress_level*/
    o[14] != null && Di(o)
  );
  return {
    c() {
      a && a.c(), e = ce(), l && l.c(), t = ce(), r && r.c(), n = ce(), s && s.c(), i = he();
    },
    l(u) {
      a && a.l(u), e = _e(u), l && l.l(u), t = _e(u), r && r.l(u), n = _e(u), s && s.l(u), i = he();
    },
    m(u, _) {
      a && a.m(u, _), B(u, e, _), l && l.m(u, _), B(u, t, _), r && r.m(u, _), B(u, n, _), s && s.m(u, _), B(u, i, _);
    },
    p(u, _) {
      /*p*/
      u[40].desc != null ? l ? l.p(u, _) : (l = vi(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? r || (r = bi(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, _) : (s = Di(u), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (A(e), A(t), A(n), A(i)), a && a.d(u), l && l.d(u), r && r.d(u), s && s.d(u);
    }
  };
}
function rr(o) {
  let e;
  return {
    c() {
      e = H(" /");
    },
    l(t) {
      e = j(t, " /");
    },
    m(t, n) {
      B(t, e, n);
    },
    d(t) {
      t && A(e);
    }
  };
}
function vi(o) {
  let e = (
    /*p*/
    o[40].desc + ""
  ), t;
  return {
    c() {
      t = H(e);
    },
    l(n) {
      t = j(n, e);
    },
    m(n, i) {
      B(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && fe(t, e);
    },
    d(n) {
      n && A(t);
    }
  };
}
function bi(o) {
  let e;
  return {
    c() {
      e = H("-");
    },
    l(t) {
      e = j(t, "-");
    },
    m(t, n) {
      B(t, e, n);
    },
    d(t) {
      t && A(e);
    }
  };
}
function Di(o) {
  let e = (100 * /*progress_level*/
  (o[14][
    /*i*/
    o[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = H(e), n = H("%");
    },
    l(i) {
      t = j(i, e), n = j(i, "%");
    },
    m(i, a) {
      B(i, t, a), B(i, n, a);
    },
    p(i, a) {
      a[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[42]
      ] || 0)).toFixed(1) + "") && fe(t, e);
    },
    d(i) {
      i && (A(t), A(n));
    }
  };
}
function yi(o) {
  let e, t = (
    /*p*/
    (o[40].desc != null || /*progress_level*/
    o[14] && /*progress_level*/
    o[14][
      /*i*/
      o[42]
    ] != null) && gi(o)
  );
  return {
    c() {
      t && t.c(), e = he();
    },
    l(n) {
      t && t.l(n), e = he();
    },
    m(n, i) {
      t && t.m(n, i), B(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, i) : (t = gi(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && A(e), t && t.d(n);
    }
  };
}
function $i(o) {
  let e, t, n, i;
  const a = (
    /*#slots*/
    o[30]["additional-loading-text"]
  ), l = zl(
    a,
    o,
    /*$$scope*/
    o[29],
    ui
  );
  return {
    c() {
      e = Te("p"), t = H(
        /*loading_text*/
        o[9]
      ), n = ce(), l && l.c(), this.h();
    },
    l(r) {
      e = qe(r, "P", { class: !0 });
      var s = Be(e);
      t = j(
        s,
        /*loading_text*/
        o[9]
      ), s.forEach(A), n = _e(r), l && l.l(r), this.h();
    },
    h() {
      $e(e, "class", "loading svelte-17v219f");
    },
    m(r, s) {
      B(r, e, s), We(e, t), B(r, n, s), l && l.m(r, s), i = !0;
    },
    p(r, s) {
      (!i || s[0] & /*loading_text*/
      512) && fe(
        t,
        /*loading_text*/
        r[9]
      ), l && l.p && (!i || s[0] & /*$$scope*/
      536870912) && Ml(
        l,
        a,
        r,
        /*$$scope*/
        r[29],
        i ? Ol(
          a,
          /*$$scope*/
          r[29],
          s,
          Ka
        ) : Ll(
          /*$$scope*/
          r[29]
        ),
        ui
      );
    },
    i(r) {
      i || (ye(l, r), i = !0);
    },
    o(r) {
      xe(l, r), i = !1;
    },
    d(r) {
      r && (A(e), A(n)), l && l.d(r);
    }
  };
}
function sr(o) {
  let e, t, n, i, a;
  const l = [Ja, Qa], r = [];
  function s(u, _) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(o)) && (n = r[t] = l[t](o)), {
    c() {
      e = Te("div"), n && n.c(), this.h();
    },
    l(u) {
      e = qe(u, "DIV", { class: !0 });
      var _ = Be(e);
      n && n.l(_), _.forEach(A), this.h();
    },
    h() {
      $e(e, "class", i = "wrap " + /*variant*/
      o[8] + " " + /*show_progress*/
      o[6] + " svelte-17v219f"), re(e, "hide", !/*status*/
      o[4] || /*status*/
      o[4] === "complete" || /*show_progress*/
      o[6] === "hidden" || /*status*/
      o[4] == "streaming"), re(
        e,
        "translucent",
        /*variant*/
        o[8] === "center" && /*status*/
        (o[4] === "pending" || /*status*/
        o[4] === "error") || /*translucent*/
        o[11] || /*show_progress*/
        o[6] === "minimal"
      ), re(
        e,
        "generating",
        /*status*/
        o[4] === "generating" && /*show_progress*/
        o[6] === "full"
      ), re(
        e,
        "border",
        /*border*/
        o[12]
      ), Ve(
        e,
        "position",
        /*absolute*/
        o[10] ? "absolute" : "static"
      ), Ve(
        e,
        "padding",
        /*absolute*/
        o[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, _) {
      B(u, e, _), ~t && r[t].m(e, null), o[33](e), a = !0;
    },
    p(u, _) {
      let c = t;
      t = s(u), t === c ? ~t && r[t].p(u, _) : (n && (mn(), xe(r[c], 1, 1, () => {
        r[c] = null;
      }), pn()), ~t ? (n = r[t], n ? n.p(u, _) : (n = r[t] = l[t](u), n.c()), ye(n, 1), n.m(e, null)) : n = null), (!a || _[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && $e(e, "class", i), (!a || _[0] & /*variant, show_progress, status, show_progress*/
      336) && re(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!a || _[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && re(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!a || _[0] & /*variant, show_progress, status, show_progress*/
      336) && re(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!a || _[0] & /*variant, show_progress, border*/
      4416) && re(
        e,
        "border",
        /*border*/
        u[12]
      ), _[0] & /*absolute*/
      1024 && Ve(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), _[0] & /*absolute*/
      1024 && Ve(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      a || (ye(n), a = !0);
    },
    o(u) {
      xe(n), a = !1;
    },
    d(u) {
      u && A(e), ~t && r[t].d(), o[33](null);
    }
  };
}
var ur = function(o, e, t, n) {
  function i(a) {
    return a instanceof t ? a : new t(function(l) {
      l(a);
    });
  }
  return new (t || (t = Promise))(function(a, l) {
    function r(_) {
      try {
        u(n.next(_));
      } catch (c) {
        l(c);
      }
    }
    function s(_) {
      try {
        u(n.throw(_));
      } catch (c) {
        l(c);
      }
    }
    function u(_) {
      _.done ? a(_.value) : i(_.value).then(r, s);
    }
    u((n = n.apply(o, e || [])).next());
  });
};
let Pt = [], rn = !1;
const _r = typeof window < "u", Nl = _r ? window.requestAnimationFrame : (o) => {
};
function cr(o) {
  return ur(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (Pt.push(e), !rn) rn = !0;
      else return;
      yield Za(), Nl(() => {
        let n = [0, 0];
        for (let i = 0; i < Pt.length; i++) {
          const l = Pt[i].getBoundingClientRect();
          (i === 0 || l.top + window.scrollY <= n[0]) && (n[0] = l.top + window.scrollY, n[1] = i);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), rn = !1, Pt = [];
      });
    }
  });
}
function dr(o, e, t) {
  let n, { $$slots: i = {}, $$scope: a } = e;
  const l = Ya();
  let { i18n: r } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: _ } = e, { status: c } = e, { scroll_to_output: d = !1 } = e, { timer: f = !0 } = e, { show_progress: g = "full" } = e, { message: m = null } = e, { progress: v = null } = e, { variant: F = "default" } = e, { loading_text: p = "Loading..." } = e, { absolute: h = !0 } = e, { translucent: b = !1 } = e, { border: y = !1 } = e, { autoscroll: D } = e, $, S = !1, k = 0, q = 0, C = null, O = null, Xe = 0, ne = null, Fe, te = null, Me = !0;
  const V = () => {
    t(0, s = t(27, C = t(19, w = null))), t(25, k = performance.now()), t(26, q = 0), S = !0, J();
  };
  function J() {
    Nl(() => {
      t(26, q = (performance.now() - k) / 1e3), S && J();
    });
  }
  function pe() {
    t(26, q = 0), t(0, s = t(27, C = t(19, w = null))), S && (S = !1);
  }
  Xa(() => {
    S && pe();
  });
  let w = null;
  function Z(E) {
    ri[E ? "unshift" : "push"](() => {
      te = E, t(16, te), t(7, v), t(14, ne), t(15, Fe);
    });
  }
  const it = () => {
    l("clear_status");
  };
  function ie(E) {
    ri[E ? "unshift" : "push"](() => {
      $ = E, t(13, $);
    });
  }
  return o.$$set = (E) => {
    "i18n" in E && t(1, r = E.i18n), "eta" in E && t(0, s = E.eta), "queue_position" in E && t(2, u = E.queue_position), "queue_size" in E && t(3, _ = E.queue_size), "status" in E && t(4, c = E.status), "scroll_to_output" in E && t(22, d = E.scroll_to_output), "timer" in E && t(5, f = E.timer), "show_progress" in E && t(6, g = E.show_progress), "message" in E && t(23, m = E.message), "progress" in E && t(7, v = E.progress), "variant" in E && t(8, F = E.variant), "loading_text" in E && t(9, p = E.loading_text), "absolute" in E && t(10, h = E.absolute), "translucent" in E && t(11, b = E.translucent), "border" in E && t(12, y = E.border), "autoscroll" in E && t(24, D = E.autoscroll), "$$scope" in E && t(29, a = E.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = C), s != null && C !== s && (t(28, O = (performance.now() - k) / 1e3 + s), t(19, w = O.toFixed(1)), t(27, C = s))), o.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, Xe = O === null || O <= 0 || !q ? null : Math.min(q / O, 1)), o.$$.dirty[0] & /*progress*/
    128 && v != null && t(18, Me = !1), o.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (v != null ? t(14, ne = v.map((E) => {
      if (E.index != null && E.length != null)
        return E.index / E.length;
      if (E.progress != null)
        return E.progress;
    })) : t(14, ne = null), ne ? (t(15, Fe = ne[ne.length - 1]), te && (Fe === 0 ? t(16, te.style.transition = "0", te) : t(16, te.style.transition = "150ms", te))) : t(15, Fe = void 0)), o.$$.dirty[0] & /*status*/
    16 && (c === "pending" ? V() : pe()), o.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && $ && d && (c === "pending" || c === "complete") && cr($, D), o.$$.dirty[0] & /*status, message*/
    8388624, o.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = q.toFixed(1));
  }, [
    s,
    r,
    u,
    _,
    c,
    f,
    g,
    v,
    F,
    p,
    h,
    b,
    y,
    $,
    ne,
    Fe,
    te,
    Xe,
    Me,
    w,
    n,
    l,
    d,
    m,
    D,
    k,
    q,
    C,
    O,
    a,
    i,
    Z,
    it,
    ie
  ];
}
class hr extends Va {
  constructor(e) {
    super(), Ua(
      this,
      e,
      dr,
      sr,
      Ga,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: JF,
  SvelteComponent: ek,
  add_render_callback: tk,
  append_hydration: nk,
  attr: ik,
  bubble: lk,
  check_outros: ok,
  children: ak,
  claim_component: rk,
  claim_element: sk,
  claim_html_tag: uk,
  claim_space: _k,
  claim_text: ck,
  create_component: dk,
  create_in_transition: hk,
  create_out_transition: fk,
  destroy_component: pk,
  detach: mk,
  element: gk,
  get_svelte_dataset: vk,
  group_outros: bk,
  init: Dk,
  insert_hydration: yk,
  listen: $k,
  mount_component: wk,
  run_all: Fk,
  safe_not_equal: kk,
  set_data: Ck,
  space: Ek,
  stop_propagation: Ak,
  text: Sk,
  toggle_class: Bk,
  transition_in: qk,
  transition_out: Tk
} = window.__gradio__svelte__internal, { createEventDispatcher: xk, onMount: zk } = window.__gradio__svelte__internal, {
  SvelteComponent: Ik,
  append_hydration: Rk,
  attr: Lk,
  bubble: Ok,
  check_outros: Pk,
  children: Mk,
  claim_component: Nk,
  claim_element: jk,
  claim_space: Hk,
  create_animation: Vk,
  create_component: Uk,
  destroy_component: Gk,
  detach: Zk,
  element: Xk,
  ensure_array_like: Yk,
  fix_and_outro_and_destroy_block: Wk,
  fix_position: Kk,
  group_outros: Qk,
  init: Jk,
  insert_hydration: eC,
  mount_component: tC,
  noop: nC,
  safe_not_equal: iC,
  set_style: lC,
  space: oC,
  transition_in: aC,
  transition_out: rC,
  update_keyed_each: sC
} = window.__gradio__svelte__internal, {
  SvelteComponent: uC,
  attr: _C,
  children: cC,
  claim_element: dC,
  detach: hC,
  element: fC,
  empty: pC,
  init: mC,
  insert_hydration: gC,
  noop: vC,
  safe_not_equal: bC,
  set_style: DC
} = window.__gradio__svelte__internal, {
  SvelteComponent: fr,
  append_hydration: pt,
  attr: Ie,
  children: wt,
  claim_element: Ft,
  claim_space: wi,
  claim_text: jl,
  destroy_each: pr,
  detach: Le,
  element: kt,
  ensure_array_like: Fi,
  init: mr,
  insert_hydration: Yt,
  noop: ki,
  safe_not_equal: gr,
  set_data: Hl,
  set_style: Mt,
  space: Ci,
  text: Vl,
  toggle_class: Ei
} = window.__gradio__svelte__internal;
function Ai(o, e, t) {
  const n = o.slice();
  return n[13] = e[t], n;
}
function Si(o) {
  let e, t = Fi(
    /*display_items*/
    o[5]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = qi(Ai(o, t, i));
  return {
    c() {
      e = kt("div");
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      this.h();
    },
    l(i) {
      e = Ft(i, "DIV", { class: !0 });
      var a = wt(e);
      for (let l = 0; l < n.length; l += 1)
        n[l].l(a);
      a.forEach(Le), this.h();
    },
    h() {
      Ie(e, "class", "credits-container svelte-141h5y1");
    },
    m(i, a) {
      Yt(i, e, a);
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(e, null);
    },
    p(i, a) {
      if (a & /*display_items, name_style, title_style*/
      56) {
        t = Fi(
          /*display_items*/
          i[5]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = Ai(i, t, l);
          n[l] ? n[l].p(r, a) : (n[l] = qi(r), n[l].c(), n[l].m(e, null));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && Le(e), pr(n, i);
    }
  };
}
function Bi(o) {
  let e, t = (
    /*item*/
    o[13].name + ""
  ), n, i;
  return {
    c() {
      e = kt("p"), n = Vl(t), this.h();
    },
    l(a) {
      e = Ft(a, "P", { style: !0, class: !0 });
      var l = wt(e);
      n = jl(l, t), l.forEach(Le), this.h();
    },
    h() {
      Ie(e, "style", i = /*name_style*/
      o[3](
        /*item*/
        o[13].is_intro
      )), Ie(e, "class", "svelte-141h5y1");
    },
    m(a, l) {
      Yt(a, e, l), pt(e, n);
    },
    p(a, l) {
      l & /*display_items*/
      32 && t !== (t = /*item*/
      a[13].name + "") && Hl(n, t), l & /*name_style, display_items*/
      40 && i !== (i = /*name_style*/
      a[3](
        /*item*/
        a[13].is_intro
      )) && Ie(e, "style", i);
    },
    d(a) {
      a && Le(e);
    }
  };
}
function qi(o) {
  let e, t, n = (
    /*item*/
    o[13].title + ""
  ), i, a, l, r, s = (
    /*item*/
    o[13].name && Bi(o)
  );
  return {
    c() {
      e = kt("div"), t = kt("h2"), i = Vl(n), l = Ci(), s && s.c(), r = Ci(), this.h();
    },
    l(u) {
      e = Ft(u, "DIV", { class: !0 });
      var _ = wt(e);
      t = Ft(_, "H2", { style: !0, class: !0 });
      var c = wt(t);
      i = jl(c, n), c.forEach(Le), l = wi(_), s && s.l(_), r = wi(_), _.forEach(Le), this.h();
    },
    h() {
      Ie(t, "style", a = /*title_style*/
      o[4](
        /*item*/
        o[13].is_intro
      )), Ie(t, "class", "svelte-141h5y1"), Ie(e, "class", "credit svelte-141h5y1"), Ei(
        e,
        "intro-block",
        /*item*/
        o[13].is_intro
      );
    },
    m(u, _) {
      Yt(u, e, _), pt(e, t), pt(t, i), pt(e, l), s && s.m(e, null), pt(e, r);
    },
    p(u, _) {
      _ & /*display_items*/
      32 && n !== (n = /*item*/
      u[13].title + "") && Hl(i, n), _ & /*title_style, display_items*/
      48 && a !== (a = /*title_style*/
      u[4](
        /*item*/
        u[13].is_intro
      )) && Ie(t, "style", a), /*item*/
      u[13].name ? s ? s.p(u, _) : (s = Bi(u), s.c(), s.m(e, r)) : s && (s.d(1), s = null), _ & /*display_items*/
      32 && Ei(
        e,
        "intro-block",
        /*item*/
        u[13].is_intro
      );
    },
    d(u) {
      u && Le(e), s && s.d();
    }
  };
}
function vr(o) {
  let e, t = `${/*speed*/
  o[0]}s`, n = !/*reset*/
  o[2] && Si(o);
  return {
    c() {
      e = kt("div"), n && n.c(), this.h();
    },
    l(i) {
      e = Ft(i, "DIV", { class: !0 });
      var a = wt(e);
      n && n.l(a), a.forEach(Le), this.h();
    },
    h() {
      Ie(e, "class", "wrapper svelte-141h5y1"), Mt(e, "--animation-duration", t), Mt(
        e,
        "background",
        /*background_color*/
        o[1] || "black"
      );
    },
    m(i, a) {
      Yt(i, e, a), n && n.m(e, null);
    },
    p(i, [a]) {
      /*reset*/
      i[2] ? n && (n.d(1), n = null) : n ? n.p(i, a) : (n = Si(i), n.c(), n.m(e, null)), a & /*speed*/
      1 && t !== (t = `${/*speed*/
      i[0]}s`) && Mt(e, "--animation-duration", t), a & /*background_color*/
      2 && Mt(
        e,
        "background",
        /*background_color*/
        i[1] || "black"
      );
    },
    i: ki,
    o: ki,
    d(i) {
      i && Le(e), n && n.d();
    }
  };
}
function br(o, e, t) {
  let n, i, a, { credits: l } = e, { speed: r } = e, { base_font_size: s = 1.5 } = e, { background_color: u = null } = e, { title_color: _ = null } = e, { name_color: c = null } = e, { intro_title: d = null } = e, { intro_subtitle: f = null } = e, g = !1;
  function m() {
    t(2, g = !0), setTimeout(() => t(2, g = !1), 0);
  }
  return o.$$set = (v) => {
    "credits" in v && t(6, l = v.credits), "speed" in v && t(0, r = v.speed), "base_font_size" in v && t(7, s = v.base_font_size), "background_color" in v && t(1, u = v.background_color), "title_color" in v && t(8, _ = v.title_color), "name_color" in v && t(9, c = v.name_color), "intro_title" in v && t(10, d = v.intro_title), "intro_subtitle" in v && t(11, f = v.intro_subtitle);
  }, o.$$.update = () => {
    o.$$.dirty & /*intro_title, intro_subtitle, credits*/
    3136 && t(5, n = (() => {
      const v = [];
      return (d || f) && v.push({
        title: d || "",
        name: f || "",
        is_intro: !0
      }), [
        ...v,
        ...l.map((F) => Object.assign(Object.assign({}, F), { is_intro: !1 }))
      ];
    })()), o.$$.dirty & /*title_color, base_font_size*/
    384 && t(4, i = (v) => `color: ${_ || "white"}; font-size: ${v ? s * 1.5 : s}rem;`), o.$$.dirty & /*name_color, base_font_size*/
    640 && t(3, a = (v) => `color: ${c || "white"}; font-size: ${v ? s * 0.9 : s * 0.8}rem;`), o.$$.dirty & /*credits, speed*/
    65 && m();
  }, [
    r,
    u,
    g,
    a,
    i,
    n,
    l,
    s,
    _,
    c,
    d,
    f
  ];
}
class Dr extends fr {
  constructor(e) {
    super(), mr(this, e, br, vr, gr, {
      credits: 6,
      speed: 0,
      base_font_size: 7,
      background_color: 1,
      title_color: 8,
      name_color: 9,
      intro_title: 10,
      intro_subtitle: 11
    });
  }
}
const {
  SvelteComponent: yr,
  append_hydration: se,
  attr: ue,
  binding_callbacks: $r,
  children: Ne,
  claim_element: je,
  claim_space: Dt,
  claim_text: Ul,
  destroy_each: wr,
  detach: De,
  element: He,
  ensure_array_like: Ti,
  init: Fr,
  insert_hydration: qn,
  noop: xi,
  safe_not_equal: kr,
  set_data: Gl,
  set_style: Ye,
  space: yt,
  text: Zl,
  toggle_class: zi
} = window.__gradio__svelte__internal, { onMount: Cr, onDestroy: Er } = window.__gradio__svelte__internal;
function Ii(o, e, t) {
  const n = o.slice();
  return n[18] = e[t], n;
}
function Ri(o) {
  let e, t = (
    /*item*/
    o[18].name + ""
  ), n, i;
  return {
    c() {
      e = He("p"), n = Zl(t), this.h();
    },
    l(a) {
      e = je(a, "P", { style: !0, class: !0 });
      var l = Ne(e);
      n = Ul(l, t), l.forEach(De), this.h();
    },
    h() {
      ue(e, "style", i = /*name_style*/
      o[4](
        /*item*/
        o[18].is_intro
      )), ue(e, "class", "svelte-1gy01d0");
    },
    m(a, l) {
      qn(a, e, l), se(e, n);
    },
    p(a, l) {
      l & /*display_items*/
      8 && t !== (t = /*item*/
      a[18].name + "") && Gl(n, t), l & /*name_style, display_items*/
      24 && i !== (i = /*name_style*/
      a[4](
        /*item*/
        a[18].is_intro
      )) && ue(e, "style", i);
    },
    d(a) {
      a && De(e);
    }
  };
}
function Li(o) {
  let e, t, n = (
    /*item*/
    o[18].title + ""
  ), i, a, l, r, s = (
    /*item*/
    o[18].name && Ri(o)
  );
  return {
    c() {
      e = He("div"), t = He("h2"), i = Zl(n), l = yt(), s && s.c(), r = yt(), this.h();
    },
    l(u) {
      e = je(u, "DIV", { class: !0 });
      var _ = Ne(e);
      t = je(_, "H2", { style: !0, class: !0 });
      var c = Ne(t);
      i = Ul(c, n), c.forEach(De), l = Dt(_), s && s.l(_), r = Dt(_), _.forEach(De), this.h();
    },
    h() {
      ue(t, "style", a = /*title_style*/
      o[5](
        /*item*/
        o[18].is_intro
      )), ue(t, "class", "svelte-1gy01d0"), ue(e, "class", "credit svelte-1gy01d0"), zi(
        e,
        "intro-block",
        /*item*/
        o[18].is_intro
      );
    },
    m(u, _) {
      qn(u, e, _), se(e, t), se(t, i), se(e, l), s && s.m(e, null), se(e, r);
    },
    p(u, _) {
      _ & /*display_items*/
      8 && n !== (n = /*item*/
      u[18].title + "") && Gl(i, n), _ & /*title_style, display_items*/
      40 && a !== (a = /*title_style*/
      u[5](
        /*item*/
        u[18].is_intro
      )) && ue(t, "style", a), /*item*/
      u[18].name ? s ? s.p(u, _) : (s = Ri(u), s.c(), s.m(e, r)) : s && (s.d(1), s = null), _ & /*display_items*/
      8 && zi(
        e,
        "intro-block",
        /*item*/
        u[18].is_intro
      );
    },
    d(u) {
      u && De(e), s && s.d();
    }
  };
}
function Ar(o) {
  let e, t, n, i, a, l, r, s, u = Ti(
    /*display_items*/
    o[3]
  ), _ = [];
  for (let c = 0; c < u.length; c += 1)
    _[c] = Li(Ii(o, u, c));
  return {
    c() {
      e = He("div"), t = He("div"), n = yt(), i = He("div"), a = yt(), l = He("div"), r = yt(), s = He("div");
      for (let c = 0; c < _.length; c += 1)
        _[c].c();
      this.h();
    },
    l(c) {
      e = je(c, "DIV", { class: !0 });
      var d = Ne(e);
      t = je(d, "DIV", { class: !0, style: !0 }), Ne(t).forEach(De), n = Dt(d), i = je(d, "DIV", { class: !0, style: !0 }), Ne(i).forEach(De), a = Dt(d), l = je(d, "DIV", { class: !0, style: !0 }), Ne(l).forEach(De), r = Dt(d), s = je(d, "DIV", { class: !0, style: !0 });
      var f = Ne(s);
      for (let g = 0; g < _.length; g += 1)
        _[g].l(f);
      f.forEach(De), d.forEach(De), this.h();
    },
    h() {
      ue(t, "class", "stars small svelte-1gy01d0"), Ye(
        t,
        "box-shadow",
        /*small_stars*/
        o[6]
      ), ue(i, "class", "stars medium svelte-1gy01d0"), Ye(
        i,
        "box-shadow",
        /*medium_stars*/
        o[7]
      ), ue(l, "class", "stars large svelte-1gy01d0"), Ye(
        l,
        "box-shadow",
        /*large_stars*/
        o[8]
      ), ue(s, "class", "crawl svelte-1gy01d0"), Ye(
        s,
        "--animation-duration",
        /*speed*/
        o[0] + "s"
      ), ue(e, "class", "viewport svelte-1gy01d0"), Ye(
        e,
        "background",
        /*background_color*/
        o[1] || "black"
      );
    },
    m(c, d) {
      qn(c, e, d), se(e, t), se(e, n), se(e, i), se(e, a), se(e, l), se(e, r), se(e, s);
      for (let f = 0; f < _.length; f += 1)
        _[f] && _[f].m(s, null);
      o[15](s);
    },
    p(c, [d]) {
      if (d & /*display_items, name_style, title_style*/
      56) {
        u = Ti(
          /*display_items*/
          c[3]
        );
        let f;
        for (f = 0; f < u.length; f += 1) {
          const g = Ii(c, u, f);
          _[f] ? _[f].p(g, d) : (_[f] = Li(g), _[f].c(), _[f].m(s, null));
        }
        for (; f < _.length; f += 1)
          _[f].d(1);
        _.length = u.length;
      }
      d & /*speed*/
      1 && Ye(
        s,
        "--animation-duration",
        /*speed*/
        c[0] + "s"
      ), d & /*background_color*/
      2 && Ye(
        e,
        "background",
        /*background_color*/
        c[1] || "black"
      );
    },
    i: xi,
    o: xi,
    d(c) {
      c && De(e), wr(_, c), o[15](null);
    }
  };
}
function Sr(o, e, t) {
  let n, i, a, { credits: l } = e, { speed: r = 40 } = e, { base_font_size: s = 1.5 } = e, { background_color: u = null } = e, { title_color: _ = null } = e, { name_color: c = null } = e, { intro_title: d = null } = e, { intro_subtitle: f = null } = e, g;
  function m() {
    g && (t(2, g.style.animation = "none", g), g.offsetHeight, t(2, g.style.animation = "", g));
  }
  Cr(() => (m(), () => {
  })), Er(() => {
    t(2, g = null);
  });
  const v = (y, D) => {
    let $ = "";
    for (let S = 0; S < y; S++)
      $ += `${Math.random() * 2e3}px ${Math.random() * 2e3}px ${D} white, `;
    return $.slice(0, -2);
  }, F = v(200, "1px"), p = v(100, "2px"), h = v(50, "3px");
  function b(y) {
    $r[y ? "unshift" : "push"](() => {
      g = y, t(2, g);
    });
  }
  return o.$$set = (y) => {
    "credits" in y && t(9, l = y.credits), "speed" in y && t(0, r = y.speed), "base_font_size" in y && t(10, s = y.base_font_size), "background_color" in y && t(1, u = y.background_color), "title_color" in y && t(11, _ = y.title_color), "name_color" in y && t(12, c = y.name_color), "intro_title" in y && t(13, d = y.intro_title), "intro_subtitle" in y && t(14, f = y.intro_subtitle);
  }, o.$$.update = () => {
    o.$$.dirty & /*title_color, base_font_size*/
    3072 && t(5, n = (y) => `color: ${_ || "#feda4a"}; font-size: ${y ? s * 1.5 : s}rem !important;`), o.$$.dirty & /*name_color, base_font_size*/
    5120 && t(4, i = (y) => `color: ${c || "#feda4a"}; font-size: ${y ? s * 0.9 : s * 0.7}rem !important;`), o.$$.dirty & /*intro_title, intro_subtitle, credits*/
    25088 && t(3, a = (() => {
      const y = [];
      return (d || f) && y.push({
        title: d || "",
        name: f || "",
        is_intro: !0
      }), [
        ...y,
        ...l.map((D) => Object.assign(Object.assign({}, D), { is_intro: !1 }))
      ];
    })()), o.$$.dirty & /*credits, speed, base_font_size, background_color, title_color, name_color, intro_title, intro_subtitle*/
    32259 && m();
  }, [
    r,
    u,
    g,
    a,
    i,
    n,
    F,
    p,
    h,
    l,
    s,
    _,
    c,
    d,
    f,
    b
  ];
}
class Br extends yr {
  constructor(e) {
    super(), Fr(this, e, Sr, Ar, kr, {
      credits: 9,
      speed: 0,
      base_font_size: 10,
      background_color: 1,
      title_color: 11,
      name_color: 12,
      intro_title: 13,
      intro_subtitle: 14
    });
  }
}
const {
  SvelteComponent: qr,
  append_hydration: Re,
  attr: we,
  binding_callbacks: Oi,
  children: Ke,
  claim_element: Qe,
  claim_space: vn,
  claim_text: Xl,
  destroy_each: Tr,
  detach: Ce,
  element: Je,
  ensure_array_like: Pi,
  init: xr,
  insert_hydration: Tn,
  noop: Mi,
  safe_not_equal: zr,
  set_data: Yl,
  set_style: Ni,
  space: bn,
  text: Wl,
  toggle_class: ji
} = window.__gradio__svelte__internal, { onMount: Ir, onDestroy: Rr } = window.__gradio__svelte__internal;
function Hi(o, e, t) {
  const n = o.slice();
  return n[19] = e[t], n;
}
function Vi(o) {
  let e, t = (
    /*item*/
    o[19].name + ""
  ), n, i;
  return {
    c() {
      e = Je("div"), n = Wl(t), this.h();
    },
    l(a) {
      e = Qe(a, "DIV", { style: !0, class: !0 });
      var l = Ke(e);
      n = Xl(l, t), l.forEach(Ce), this.h();
    },
    h() {
      we(e, "style", i = /*name_style*/
      o[3](
        /*item*/
        o[19].is_intro
      )), we(e, "class", "name svelte-8jsw80");
    },
    m(a, l) {
      Tn(a, e, l), Re(e, n);
    },
    p(a, l) {
      l & /*display_items*/
      32 && t !== (t = /*item*/
      a[19].name + "") && Yl(n, t), l & /*name_style, display_items*/
      40 && i !== (i = /*name_style*/
      a[3](
        /*item*/
        a[19].is_intro
      )) && we(e, "style", i);
    },
    d(a) {
      a && Ce(e);
    }
  };
}
function Ui(o) {
  let e, t, n = (
    /*item*/
    o[19].title + ""
  ), i, a, l, r, s = (
    /*item*/
    o[19].name && Vi(o)
  );
  return {
    c() {
      e = Je("div"), t = Je("div"), i = Wl(n), l = bn(), s && s.c(), r = bn(), this.h();
    },
    l(u) {
      e = Qe(u, "DIV", { class: !0 });
      var _ = Ke(e);
      t = Qe(_, "DIV", { style: !0, class: !0 });
      var c = Ke(t);
      i = Xl(c, n), c.forEach(Ce), l = vn(_), s && s.l(_), r = vn(_), _.forEach(Ce), this.h();
    },
    h() {
      we(t, "style", a = /*title_style*/
      o[4](
        /*item*/
        o[19].is_intro
      )), we(t, "class", "title svelte-8jsw80"), we(e, "class", "credit-block svelte-8jsw80"), ji(
        e,
        "intro-block",
        /*item*/
        o[19].is_intro
      );
    },
    m(u, _) {
      Tn(u, e, _), Re(e, t), Re(t, i), Re(e, l), s && s.m(e, null), Re(e, r);
    },
    p(u, _) {
      _ & /*display_items*/
      32 && n !== (n = /*item*/
      u[19].title + "") && Yl(i, n), _ & /*title_style, display_items*/
      48 && a !== (a = /*title_style*/
      u[4](
        /*item*/
        u[19].is_intro
      )) && we(t, "style", a), /*item*/
      u[19].name ? s ? s.p(u, _) : (s = Vi(u), s.c(), s.m(e, r)) : s && (s.d(1), s = null), _ & /*display_items*/
      32 && ji(
        e,
        "intro-block",
        /*item*/
        u[19].is_intro
      );
    },
    d(u) {
      u && Ce(e), s && s.d();
    }
  };
}
function Lr(o) {
  let e, t, n, i, a, l = Pi(
    /*display_items*/
    o[5]
  ), r = [];
  for (let s = 0; s < l.length; s += 1)
    r[s] = Ui(Hi(o, l, s));
  return {
    c() {
      e = Je("div"), t = Je("canvas"), n = bn(), i = Je("div"), a = Je("div");
      for (let s = 0; s < r.length; s += 1)
        r[s].c();
      this.h();
    },
    l(s) {
      e = Qe(s, "DIV", { class: !0 });
      var u = Ke(e);
      t = Qe(u, "CANVAS", { class: !0 }), Ke(t).forEach(Ce), n = vn(u), i = Qe(u, "DIV", { class: !0 });
      var _ = Ke(i);
      a = Qe(_, "DIV", { class: !0, style: !0 });
      var c = Ke(a);
      for (let d = 0; d < r.length; d += 1)
        r[d].l(c);
      c.forEach(Ce), _.forEach(Ce), u.forEach(Ce), this.h();
    },
    h() {
      we(t, "class", "svelte-8jsw80"), we(a, "class", "credits-content svelte-8jsw80"), Ni(
        a,
        "--animation-duration",
        /*speed*/
        o[0] + "s"
      ), we(i, "class", "credits-scroll-overlay svelte-8jsw80"), we(e, "class", "matrix-container svelte-8jsw80");
    },
    m(s, u) {
      Tn(s, e, u), Re(e, t), o[10](t), Re(e, n), Re(e, i), Re(i, a);
      for (let _ = 0; _ < r.length; _ += 1)
        r[_] && r[_].m(a, null);
      o[11](a);
    },
    p(s, [u]) {
      if (u & /*display_items, name_style, title_style*/
      56) {
        l = Pi(
          /*display_items*/
          s[5]
        );
        let _;
        for (_ = 0; _ < l.length; _ += 1) {
          const c = Hi(s, l, _);
          r[_] ? r[_].p(c, u) : (r[_] = Ui(c), r[_].c(), r[_].m(a, null));
        }
        for (; _ < r.length; _ += 1)
          r[_].d(1);
        r.length = l.length;
      }
      u & /*speed*/
      1 && Ni(
        a,
        "--animation-duration",
        /*speed*/
        s[0] + "s"
      );
    },
    i: Mi,
    o: Mi,
    d(s) {
      s && Ce(e), o[10](null), Tr(r, s), o[11](null);
    }
  };
}
const ft = 16, Gi = "アァカサタナハマヤャラワガザダバパイィキシチニヒミリヰギジヂビピウゥクスツヌフムユュルグズブヅプエェケセテネヘメレヱゲゼデベペオォコソトノホモヨョロヲゴゾドボポヴッン01";
function Or(o, e, t) {
  let n, i, a, { credits: l } = e, { speed: r = 20 } = e, { base_font_size: s = 1 } = e, { intro_title: u = null } = e, { intro_subtitle: _ = null } = e, c, d, f, g, m = [], v;
  function F() {
    if (!c) return;
    const D = c.parentElement;
    D && (t(1, c.width = D.clientWidth, c), t(1, c.height = D.clientHeight, c)), d = c.getContext("2d"), g = Math.floor(c.width / ft), m = Array(g).fill(1);
  }
  function p() {
    if (d) {
      d.fillStyle = "rgba(0, 0, 0, 0.05)", d.fillRect(0, 0, c.width, c.height), d.fillStyle = "#0F0", d.font = `${ft}px monospace`;
      for (let D = 0; D < m.length; D++) {
        const $ = Gi.charAt(Math.floor(Math.random() * Gi.length));
        d.fillText($, D * ft, m[D] * ft), m[D] * ft > c.height && Math.random() > 0.975 && (m[D] = 0), m[D]++;
      }
      v = requestAnimationFrame(p);
    }
  }
  function h() {
    f && (t(2, f.style.animation = "none", f), f.offsetHeight, t(2, f.style.animation = "", f));
  }
  Ir(() => {
    F(), p(), h();
    const D = new ResizeObserver(() => {
      cancelAnimationFrame(v), F(), p();
    });
    return c.parentElement && D.observe(c.parentElement), () => {
      cancelAnimationFrame(v), c.parentElement && D.unobserve(c.parentElement);
    };
  }), Rr(() => {
    t(2, f = null);
  });
  function b(D) {
    Oi[D ? "unshift" : "push"](() => {
      c = D, t(1, c);
    });
  }
  function y(D) {
    Oi[D ? "unshift" : "push"](() => {
      f = D, t(2, f);
    });
  }
  return o.$$set = (D) => {
    "credits" in D && t(6, l = D.credits), "speed" in D && t(0, r = D.speed), "base_font_size" in D && t(7, s = D.base_font_size), "intro_title" in D && t(8, u = D.intro_title), "intro_subtitle" in D && t(9, _ = D.intro_subtitle);
  }, o.$$.update = () => {
    o.$$.dirty & /*intro_title, intro_subtitle, credits*/
    832 && t(5, n = (() => {
      const D = [];
      return (u || _) && D.push({
        title: u || "",
        name: _ || "",
        is_intro: !0
      }), [
        ...D,
        ...l.map(($) => Object.assign(Object.assign({}, $), { is_intro: !1 }))
      ];
    })()), o.$$.dirty & /*base_font_size*/
    128 && t(4, i = (D) => `font-size: ${D ? s * 1.2 : s * 0.8}em;`), o.$$.dirty & /*base_font_size*/
    128 && t(3, a = (D) => `font-size: ${D ? s * 1.5 : s}em;`), o.$$.dirty & /*credits, speed, intro_title, intro_subtitle*/
    833 && h();
  }, [
    r,
    c,
    f,
    a,
    i,
    n,
    l,
    s,
    u,
    _,
    b,
    y
  ];
}
class Pr extends qr {
  constructor(e) {
    super(), xr(this, e, Or, Lr, zr, {
      credits: 6,
      speed: 0,
      base_font_size: 7,
      intro_title: 8,
      intro_subtitle: 9
    });
  }
}
const { setContext: yC, getContext: Mr } = window.__gradio__svelte__internal, Nr = "WORKER_PROXY_CONTEXT_KEY";
function jr() {
  return Mr(Nr);
}
const Hr = "lite.local";
function Vr(o) {
  return o.host === window.location.host || o.host === "localhost:7860" || o.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  o.host === Hr;
}
function Ur(o, e) {
  const t = e.toLowerCase();
  for (const [n, i] of Object.entries(o))
    if (n.toLowerCase() === t)
      return i;
}
function Gr(o) {
  const e = typeof window < "u";
  if (o == null || !e)
    return !1;
  const t = new URL(o, window.location.href);
  return !(!Vr(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
let Nt;
async function Zr(o) {
  const e = typeof window < "u";
  if (o == null || !e || !Gr(o))
    return o;
  if (Nt == null)
    try {
      Nt = jr();
    } catch {
      return o;
    }
  if (Nt == null)
    return o;
  const n = new URL(o, window.location.href).pathname;
  return Nt.httpRequest({
    method: "GET",
    path: n,
    headers: {},
    query_string: ""
  }).then((i) => {
    if (i.status !== 200)
      throw new Error(`Failed to get file ${n} from the Wasm worker.`);
    const a = new Blob([i.body], {
      type: Ur(i.headers, "content-type")
    });
    return URL.createObjectURL(a);
  });
}
const {
  SvelteComponent: $C,
  assign: wC,
  check_outros: FC,
  children: kC,
  claim_element: CC,
  compute_rest_props: EC,
  create_slot: AC,
  detach: SC,
  element: BC,
  empty: qC,
  exclude_internal_props: TC,
  get_all_dirty_from_scope: xC,
  get_slot_changes: zC,
  get_spread_update: IC,
  group_outros: RC,
  init: LC,
  insert_hydration: OC,
  listen: PC,
  prevent_default: MC,
  safe_not_equal: NC,
  set_attributes: jC,
  set_style: HC,
  toggle_class: VC,
  transition_in: UC,
  transition_out: GC,
  update_slot_base: ZC
} = window.__gradio__svelte__internal, { createEventDispatcher: XC, onMount: YC } = window.__gradio__svelte__internal, {
  SvelteComponent: Xr,
  assign: Dn,
  bubble: Yr,
  claim_element: Wr,
  compute_rest_props: Zi,
  detach: Kr,
  element: Qr,
  exclude_internal_props: Jr,
  get_spread_update: es,
  init: ts,
  insert_hydration: ns,
  listen: is,
  noop: Xi,
  safe_not_equal: ls,
  set_attributes: Yi,
  src_url_equal: os,
  toggle_class: Wi
} = window.__gradio__svelte__internal;
function as(o) {
  let e, t, n, i, a = [
    {
      src: t = /*resolved_src*/
      o[0]
    },
    /*$$restProps*/
    o[1]
  ], l = {};
  for (let r = 0; r < a.length; r += 1)
    l = Dn(l, a[r]);
  return {
    c() {
      e = Qr("img"), this.h();
    },
    l(r) {
      e = Wr(r, "IMG", { src: !0 }), this.h();
    },
    h() {
      Yi(e, l), Wi(e, "svelte-kxeri3", !0);
    },
    m(r, s) {
      ns(r, e, s), n || (i = is(
        e,
        "load",
        /*load_handler*/
        o[4]
      ), n = !0);
    },
    p(r, [s]) {
      Yi(e, l = es(a, [
        s & /*resolved_src*/
        1 && !os(e.src, t = /*resolved_src*/
        r[0]) && { src: t },
        s & /*$$restProps*/
        2 && /*$$restProps*/
        r[1]
      ])), Wi(e, "svelte-kxeri3", !0);
    },
    i: Xi,
    o: Xi,
    d(r) {
      r && Kr(e), n = !1, i();
    }
  };
}
function rs(o, e, t) {
  const n = ["src"];
  let i = Zi(e, n), { src: a = void 0 } = e, l, r;
  function s(u) {
    Yr.call(this, o, u);
  }
  return o.$$set = (u) => {
    e = Dn(Dn({}, e), Jr(u)), t(1, i = Zi(e, n)), "src" in u && t(2, a = u.src);
  }, o.$$.update = () => {
    if (o.$$.dirty & /*src, latest_src*/
    12) {
      t(0, l = a), t(3, r = a);
      const u = a;
      Zr(u).then((_) => {
        r === u && t(0, l = _);
      });
    }
  }, [l, i, a, r, s];
}
class ss extends Xr {
  constructor(e) {
    super(), ts(this, e, rs, as, ls, { src: 2 });
  }
}
const {
  SvelteComponent: WC,
  append_hydration: KC,
  attr: QC,
  binding_callbacks: JC,
  bubble: e3,
  check_outros: t3,
  children: n3,
  claim_component: i3,
  claim_element: l3,
  claim_space: o3,
  create_component: a3,
  destroy_component: r3,
  detach: s3,
  element: u3,
  empty: _3,
  group_outros: c3,
  init: d3,
  insert_hydration: h3,
  listen: f3,
  mount_component: p3,
  safe_not_equal: m3,
  space: g3,
  toggle_class: v3,
  transition_in: b3,
  transition_out: D3
} = window.__gradio__svelte__internal, { createEventDispatcher: y3, onMount: $3 } = window.__gradio__svelte__internal, {
  SvelteComponent: us,
  append_hydration: ee,
  attr: W,
  check_outros: Ue,
  children: de,
  claim_component: st,
  claim_element: K,
  claim_space: Oe,
  claim_text: yn,
  create_component: ut,
  create_slot: _s,
  destroy_block: cs,
  destroy_component: _t,
  detach: x,
  element: Q,
  empty: Ge,
  ensure_array_like: Ki,
  get_all_dirty_from_scope: ds,
  get_slot_changes: hs,
  get_svelte_dataset: xn,
  group_outros: Ze,
  head_selector: fs,
  init: ps,
  insert_hydration: G,
  listen: ms,
  mount_component: ct,
  noop: Ct,
  safe_not_equal: Wt,
  set_data: $n,
  set_style: M,
  space: Pe,
  src_url_equal: Qi,
  text: wn,
  toggle_class: Ji,
  transition_in: L,
  transition_out: N,
  update_keyed_each: gs,
  update_slot_base: vs
} = window.__gradio__svelte__internal;
function el(o, e, t) {
  const n = o.slice();
  return n[24] = e[t][0], n[25] = e[t][1], n;
}
function tl(o) {
  let e, t, n, i;
  const a = [Ds, bs], l = [];
  function r(s, u) {
    return (
      /*gradio*/
      s[7] ? 0 : 1
    );
  }
  return t = r(o), n = l[t] = a[t](o), {
    c() {
      e = Q("div"), n.c(), this.h();
    },
    l(s) {
      e = K(s, "DIV", { class: !0 });
      var u = de(e);
      n.l(u), u.forEach(x), this.h();
    },
    h() {
      W(e, "class", "logo-panel svelte-1hawtr7"), M(
        e,
        "height",
        /*logo_panel_height*/
        o[12]
      ), M(e, "display", "flex"), M(
        e,
        "justify-content",
        /*logo_justify*/
        o[10]
      );
    },
    m(s, u) {
      G(s, e, u), l[t].m(e, null), i = !0;
    },
    p(s, u) {
      let _ = t;
      t = r(s), t === _ ? l[t].p(s, u) : (Ze(), N(l[_], 1, 1, () => {
        l[_] = null;
      }), Ue(), n = l[t], n ? n.p(s, u) : (n = l[t] = a[t](s), n.c()), L(n, 1), n.m(e, null)), u & /*logo_panel_height*/
      4096 && M(
        e,
        "height",
        /*logo_panel_height*/
        s[12]
      ), u & /*logo_justify*/
      1024 && M(
        e,
        "justify-content",
        /*logo_justify*/
        s[10]
      );
    },
    i(s) {
      i || (L(n), i = !0);
    },
    o(s) {
      N(n), i = !1;
    },
    d(s) {
      s && x(e), l[t].d();
    }
  };
}
function bs(o) {
  let e, t;
  return {
    c() {
      e = Q("img"), this.h();
    },
    l(n) {
      e = K(n, "IMG", { src: !0, alt: !0, style: !0 }), this.h();
    },
    h() {
      Qi(e.src, t = /*effectiveValue*/
      o[8].logo_path.url) || W(e, "src", t), W(e, "alt", "Logo"), M(
        e,
        "width",
        /*logo_width_style*/
        o[14]
      ), M(
        e,
        "height",
        /*logo_height_style*/
        o[13]
      ), M(
        e,
        "object-fit",
        /*object_fit*/
        o[11]
      );
    },
    m(n, i) {
      G(n, e, i);
    },
    p(n, i) {
      i & /*effectiveValue*/
      256 && !Qi(e.src, t = /*effectiveValue*/
      n[8].logo_path.url) && W(e, "src", t), i & /*logo_width_style*/
      16384 && M(
        e,
        "width",
        /*logo_width_style*/
        n[14]
      ), i & /*logo_height_style*/
      8192 && M(
        e,
        "height",
        /*logo_height_style*/
        n[13]
      ), i & /*object_fit*/
      2048 && M(
        e,
        "object-fit",
        /*object_fit*/
        n[11]
      );
    },
    i: Ct,
    o: Ct,
    d(n) {
      n && x(e);
    }
  };
}
function Ds(o) {
  let e, t;
  return e = new ss({
    props: {
      src: (
        /*effectiveValue*/
        o[8].logo_path.url
      ),
      alt: "Logo",
      loading: "lazy",
      gradio: (
        /*gradio*/
        o[7]
      ),
      style: "width: " + /*logo_width_style*/
      o[14] + "; height: " + /*logo_height_style*/
      o[13] + "; object-fit: " + /*object_fit*/
      o[11] + ";"
    }
  }), {
    c() {
      ut(e.$$.fragment);
    },
    l(n) {
      st(e.$$.fragment, n);
    },
    m(n, i) {
      ct(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*effectiveValue*/
      256 && (a.src = /*effectiveValue*/
      n[8].logo_path.url), i & /*gradio*/
      128 && (a.gradio = /*gradio*/
      n[7]), i & /*logo_width_style, logo_height_style, object_fit*/
      26624 && (a.style = "width: " + /*logo_width_style*/
      n[14] + "; height: " + /*logo_height_style*/
      n[13] + "; object-fit: " + /*object_fit*/
      n[11] + ";"), e.$set(a);
    },
    i(n) {
      t || (L(e.$$.fragment, n), t = !0);
    },
    o(n) {
      N(e.$$.fragment, n), t = !1;
    },
    d(n) {
      _t(e, n);
    }
  };
}
function nl(o) {
  var i;
  let e, t, n = (
    /*effectiveValue*/
    o[8].show_logo && /*effectiveValue*/
    ((i = o[8].logo_path) == null ? void 0 : i.url) && tl(o)
  );
  return {
    c() {
      e = Q("div"), n && n.c(), this.h();
    },
    l(a) {
      e = K(a, "DIV", { class: !0 });
      var l = de(e);
      n && n.l(l), l.forEach(x), this.h();
    },
    h() {
      W(e, "class", "outer-logo-wrapper svelte-1hawtr7"), M(
        e,
        "width",
        /*width_style*/
        o[15]
      );
    },
    m(a, l) {
      G(a, e, l), n && n.m(e, null), t = !0;
    },
    p(a, l) {
      var r;
      /*effectiveValue*/
      a[8].show_logo && /*effectiveValue*/
      ((r = a[8].logo_path) != null && r.url) ? n ? (n.p(a, l), l & /*effectiveValue*/
      256 && L(n, 1)) : (n = tl(a), n.c(), L(n, 1), n.m(e, null)) : n && (Ze(), N(n, 1, 1, () => {
        n = null;
      }), Ue()), l & /*width_style*/
      32768 && M(
        e,
        "width",
        /*width_style*/
        a[15]
      );
    },
    i(a) {
      t || (L(n), t = !0);
    },
    o(a) {
      N(n), t = !1;
    },
    d(a) {
      a && x(e), n && n.d();
    }
  };
}
function il(o) {
  let e = (
    /*effectiveValue*/
    o[8].sidebar_position
  ), t, n, i = ul(o);
  return {
    c() {
      i.c(), t = Ge();
    },
    l(a) {
      i.l(a), t = Ge();
    },
    m(a, l) {
      i.m(a, l), G(a, t, l), n = !0;
    },
    p(a, l) {
      l & /*effectiveValue*/
      256 && Wt(e, e = /*effectiveValue*/
      a[8].sidebar_position) ? (Ze(), N(i, 1, 1, Ct), Ue(), i = ul(a), i.c(), L(i, 1), i.m(t.parentNode, t)) : i.p(a, l);
    },
    i(a) {
      n || (L(i), n = !0);
    },
    o(a) {
      N(i), n = !1;
    },
    d(a) {
      a && x(t), i.d(a);
    }
  };
}
function ll(o) {
  let e = {
    effect: (
      /*effectiveValue*/
      o[8].effect
    ),
    speed: (
      /*effectiveValue*/
      o[8].speed
    )
  }, t, n, i = ol(o);
  return {
    c() {
      i.c(), t = Ge();
    },
    l(a) {
      i.l(a), t = Ge();
    },
    m(a, l) {
      i.m(a, l), G(a, t, l), n = !0;
    },
    p(a, l) {
      l & /*effectiveValue*/
      256 && Wt(e, e = {
        effect: (
          /*effectiveValue*/
          a[8].effect
        ),
        speed: (
          /*effectiveValue*/
          a[8].speed
        )
      }) ? (Ze(), N(i, 1, 1, Ct), Ue(), i = ol(a), i.c(), L(i, 1), i.m(t.parentNode, t)) : i.p(a, l);
    },
    i(a) {
      n || (L(i), n = !0);
    },
    o(a) {
      N(i), n = !1;
    },
    d(a) {
      a && x(t), i.d(a);
    }
  };
}
function ys(o) {
  let e, t;
  return e = new Pr({
    props: {
      credits: (
        /*effectiveValue*/
        o[8].credits
      ),
      speed: (
        /*effectiveValue*/
        o[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        o[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        o[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        o[8].intro_subtitle
      )
    }
  }), {
    c() {
      ut(e.$$.fragment);
    },
    l(n) {
      st(e.$$.fragment, n);
    },
    m(n, i) {
      ct(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*effectiveValue*/
      256 && (a.credits = /*effectiveValue*/
      n[8].credits), i & /*effectiveValue*/
      256 && (a.speed = /*effectiveValue*/
      n[8].speed), i & /*effectiveValue*/
      256 && (a.base_font_size = /*effectiveValue*/
      n[8].base_font_size), i & /*effectiveValue*/
      256 && (a.intro_title = /*effectiveValue*/
      n[8].intro_title), i & /*effectiveValue*/
      256 && (a.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), e.$set(a);
    },
    i(n) {
      t || (L(e.$$.fragment, n), t = !0);
    },
    o(n) {
      N(e.$$.fragment, n), t = !1;
    },
    d(n) {
      _t(e, n);
    }
  };
}
function $s(o) {
  let e, t;
  return e = new Br({
    props: {
      credits: (
        /*effectiveValue*/
        o[8].credits
      ),
      speed: (
        /*effectiveValue*/
        o[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        o[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        o[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        o[8].intro_subtitle
      )
    }
  }), {
    c() {
      ut(e.$$.fragment);
    },
    l(n) {
      st(e.$$.fragment, n);
    },
    m(n, i) {
      ct(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*effectiveValue*/
      256 && (a.credits = /*effectiveValue*/
      n[8].credits), i & /*effectiveValue*/
      256 && (a.speed = /*effectiveValue*/
      n[8].speed), i & /*effectiveValue*/
      256 && (a.base_font_size = /*effectiveValue*/
      n[8].base_font_size), i & /*effectiveValue*/
      256 && (a.intro_title = /*effectiveValue*/
      n[8].intro_title), i & /*effectiveValue*/
      256 && (a.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), e.$set(a);
    },
    i(n) {
      t || (L(e.$$.fragment, n), t = !0);
    },
    o(n) {
      N(e.$$.fragment, n), t = !1;
    },
    d(n) {
      _t(e, n);
    }
  };
}
function ws(o) {
  let e, t;
  return e = new Dr({
    props: {
      credits: (
        /*effectiveValue*/
        o[8].credits
      ),
      speed: (
        /*effectiveValue*/
        o[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        o[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        o[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        o[8].intro_subtitle
      ),
      background_color: (
        /*effectiveValue*/
        o[8].scroll_background_color
      ),
      title_color: (
        /*effectiveValue*/
        o[8].scroll_title_color
      ),
      name_color: (
        /*effectiveValue*/
        o[8].scroll_name_color
      )
    }
  }), {
    c() {
      ut(e.$$.fragment);
    },
    l(n) {
      st(e.$$.fragment, n);
    },
    m(n, i) {
      ct(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*effectiveValue*/
      256 && (a.credits = /*effectiveValue*/
      n[8].credits), i & /*effectiveValue*/
      256 && (a.speed = /*effectiveValue*/
      n[8].speed), i & /*effectiveValue*/
      256 && (a.base_font_size = /*effectiveValue*/
      n[8].base_font_size), i & /*effectiveValue*/
      256 && (a.intro_title = /*effectiveValue*/
      n[8].intro_title), i & /*effectiveValue*/
      256 && (a.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), i & /*effectiveValue*/
      256 && (a.background_color = /*effectiveValue*/
      n[8].scroll_background_color), i & /*effectiveValue*/
      256 && (a.title_color = /*effectiveValue*/
      n[8].scroll_title_color), i & /*effectiveValue*/
      256 && (a.name_color = /*effectiveValue*/
      n[8].scroll_name_color), e.$set(a);
    },
    i(n) {
      t || (L(e.$$.fragment, n), t = !0);
    },
    o(n) {
      N(e.$$.fragment, n), t = !1;
    },
    d(n) {
      _t(e, n);
    }
  };
}
function ol(o) {
  let e, t, n, i;
  const a = [ws, $s, ys], l = [];
  function r(s, u) {
    return (
      /*effectiveValue*/
      s[8].effect === "scroll" ? 0 : (
        /*effectiveValue*/
        s[8].effect === "starwars" ? 1 : (
          /*effectiveValue*/
          s[8].effect === "matrix" ? 2 : -1
        )
      )
    );
  }
  return ~(t = r(o)) && (n = l[t] = a[t](o)), {
    c() {
      e = Q("div"), n && n.c(), this.h();
    },
    l(s) {
      e = K(s, "DIV", { class: !0 });
      var u = de(e);
      n && n.l(u), u.forEach(x), this.h();
    },
    h() {
      W(e, "class", "main-credits-panel svelte-1hawtr7"), M(
        e,
        "height",
        /*height_style*/
        o[16]
      ), M(
        e,
        "width",
        /*effectiveValue*/
        o[8].sidebar_position === "right" && /*effectiveValue*/
        o[8].show_licenses ? "calc(100% - var(--sidebar-width, 400px))" : (
          /*width_style*/
          o[15]
        )
      );
    },
    m(s, u) {
      G(s, e, u), ~t && l[t].m(e, null), i = !0;
    },
    p(s, u) {
      let _ = t;
      t = r(s), t === _ ? ~t && l[t].p(s, u) : (n && (Ze(), N(l[_], 1, 1, () => {
        l[_] = null;
      }), Ue()), ~t ? (n = l[t], n ? n.p(s, u) : (n = l[t] = a[t](s), n.c()), L(n, 1), n.m(e, null)) : n = null), u & /*height_style*/
      65536 && M(
        e,
        "height",
        /*height_style*/
        s[16]
      ), u & /*effectiveValue, width_style*/
      33024 && M(
        e,
        "width",
        /*effectiveValue*/
        s[8].sidebar_position === "right" && /*effectiveValue*/
        s[8].show_licenses ? "calc(100% - var(--sidebar-width, 400px))" : (
          /*width_style*/
          s[15]
        )
      );
    },
    i(s) {
      i || (L(n), i = !0);
    },
    o(s) {
      N(n), i = !1;
    },
    d(s) {
      s && x(e), ~t && l[t].d();
    }
  };
}
function al(o) {
  let e, t, n = "Licenses", i, a, l = [], r = /* @__PURE__ */ new Map(), s, u = Ki(Object.entries(
    /*effectiveValue*/
    o[8].licenses
  ));
  const _ = (d) => (
    /*name*/
    d[24]
  );
  for (let d = 0; d < u.length; d += 1) {
    let f = el(o, u, d), g = _(f);
    r.set(g, l[d] = rl(g, f));
  }
  let c = (
    /*selected_license_name*/
    o[9] && sl(o)
  );
  return {
    c() {
      e = Q("div"), t = Q("h3"), t.textContent = n, i = Pe(), a = Q("ul");
      for (let d = 0; d < l.length; d += 1)
        l[d].c();
      s = Pe(), c && c.c(), this.h();
    },
    l(d) {
      e = K(d, "DIV", { class: !0 });
      var f = de(e);
      t = K(f, "H3", { class: !0, "data-svelte-h": !0 }), xn(t) !== "svelte-1txs4lo" && (t.textContent = n), i = Oe(f), a = K(f, "UL", {});
      var g = de(a);
      for (let m = 0; m < l.length; m += 1)
        l[m].l(g);
      g.forEach(x), s = Oe(f), c && c.l(f), f.forEach(x), this.h();
    },
    h() {
      W(t, "class", "svelte-1hawtr7"), W(e, "class", "licenses-sidebar svelte-1hawtr7");
    },
    m(d, f) {
      G(d, e, f), ee(e, t), ee(e, i), ee(e, a);
      for (let g = 0; g < l.length; g += 1)
        l[g] && l[g].m(a, null);
      ee(e, s), c && c.m(e, null);
    },
    p(d, f) {
      f & /*selected_license_name, Object, effectiveValue, show_license*/
      131840 && (u = Ki(Object.entries(
        /*effectiveValue*/
        d[8].licenses
      )), l = gs(l, f, _, 1, d, u, r, a, cs, rl, null, el)), /*selected_license_name*/
      d[9] ? c ? c.p(d, f) : (c = sl(d), c.c(), c.m(e, null)) : c && (c.d(1), c = null);
    },
    d(d) {
      d && x(e);
      for (let f = 0; f < l.length; f += 1)
        l[f].d();
      c && c.d();
    }
  };
}
function rl(o, e) {
  let t, n, i = (
    /*name*/
    e[24] + ""
  ), a, l, r, s;
  function u() {
    return (
      /*click_handler*/
      e[22](
        /*name*/
        e[24]
      )
    );
  }
  return {
    key: o,
    first: null,
    c() {
      t = Q("li"), n = Q("button"), a = wn(i), l = Pe(), this.h();
    },
    l(_) {
      t = K(_, "LI", { class: !0 });
      var c = de(t);
      n = K(c, "BUTTON", { type: !0, class: !0 });
      var d = de(n);
      a = yn(d, i), d.forEach(x), l = Oe(c), c.forEach(x), this.h();
    },
    h() {
      W(n, "type", "button"), W(n, "class", "svelte-1hawtr7"), Ji(
        n,
        "selected",
        /*selected_license_name*/
        e[9] === /*name*/
        e[24]
      ), W(t, "class", "svelte-1hawtr7"), this.first = t;
    },
    m(_, c) {
      G(_, t, c), ee(t, n), ee(n, a), ee(t, l), r || (s = ms(n, "click", u), r = !0);
    },
    p(_, c) {
      e = _, c & /*effectiveValue*/
      256 && i !== (i = /*name*/
      e[24] + "") && $n(a, i), c & /*selected_license_name, Object, effectiveValue*/
      768 && Ji(
        n,
        "selected",
        /*selected_license_name*/
        e[9] === /*name*/
        e[24]
      );
    },
    d(_) {
      _ && x(t), r = !1, s();
    }
  };
}
function sl(o) {
  let e, t, n, i, a, l = (
    /*effectiveValue*/
    o[8].licenses[
      /*selected_license_name*/
      o[9]
    ] + ""
  ), r;
  return {
    c() {
      e = Q("div"), t = Q("h4"), n = wn(
        /*selected_license_name*/
        o[9]
      ), i = Pe(), a = Q("pre"), r = wn(l), this.h();
    },
    l(s) {
      e = K(s, "DIV", { class: !0 });
      var u = de(e);
      t = K(u, "H4", { class: !0 });
      var _ = de(t);
      n = yn(
        _,
        /*selected_license_name*/
        o[9]
      ), _.forEach(x), i = Oe(u), a = K(u, "PRE", { class: !0 });
      var c = de(a);
      r = yn(c, l), c.forEach(x), u.forEach(x), this.h();
    },
    h() {
      W(t, "class", "svelte-1hawtr7"), W(a, "class", "svelte-1hawtr7"), W(e, "class", "license-display svelte-1hawtr7");
    },
    m(s, u) {
      G(s, e, u), ee(e, t), ee(t, n), ee(e, i), ee(e, a), ee(a, r);
    },
    p(s, u) {
      u & /*selected_license_name*/
      512 && $n(
        n,
        /*selected_license_name*/
        s[9]
      ), u & /*effectiveValue, selected_license_name*/
      768 && l !== (l = /*effectiveValue*/
      s[8].licenses[
        /*selected_license_name*/
        s[9]
      ] + "") && $n(r, l);
    },
    d(s) {
      s && x(e);
    }
  };
}
function ul(o) {
  let e, t, n, i = (
    /*effectiveValue*/
    o[8].show_licenses && Object.keys(
      /*effectiveValue*/
      o[8].licenses
    ).length > 0
  ), a, l = (
    /*effectiveValue*/
    o[8].show_credits && ll(o)
  ), r = i && al(o);
  return {
    c() {
      e = Q("div"), t = Q("div"), l && l.c(), n = Pe(), r && r.c(), this.h();
    },
    l(s) {
      e = K(s, "DIV", { class: !0 });
      var u = de(e);
      t = K(u, "DIV", { class: !0 });
      var _ = de(t);
      l && l.l(_), n = Oe(_), r && r.l(_), _.forEach(x), u.forEach(x), this.h();
    },
    h() {
      W(t, "class", "credits-panel-wrapper svelte-1hawtr7"), M(
        t,
        "width",
        /*width_style*/
        o[15]
      ), M(
        t,
        "height",
        /*effectiveValue*/
        o[8].sidebar_position === "right" ? (
          /*height_style*/
          o[16]
        ) : void 0
      ), M(t, "--main-panel-width", !/*effectiveValue*/
      o[8].show_credits && /*effectiveValue*/
      o[8].show_licenses ? "0px" : "auto"), W(e, "class", "outer-credits-wrapper svelte-1hawtr7"), M(
        e,
        "width",
        /*width_style*/
        o[15]
      );
    },
    m(s, u) {
      G(s, e, u), ee(e, t), l && l.m(t, null), ee(t, n), r && r.m(t, null), a = !0;
    },
    p(s, u) {
      /*effectiveValue*/
      s[8].show_credits ? l ? (l.p(s, u), u & /*effectiveValue*/
      256 && L(l, 1)) : (l = ll(s), l.c(), L(l, 1), l.m(t, n)) : l && (Ze(), N(l, 1, 1, () => {
        l = null;
      }), Ue()), u & /*effectiveValue*/
      256 && (i = /*effectiveValue*/
      s[8].show_licenses && Object.keys(
        /*effectiveValue*/
        s[8].licenses
      ).length > 0), i ? r ? r.p(s, u) : (r = al(s), r.c(), r.m(t, null)) : r && (r.d(1), r = null), u & /*width_style*/
      32768 && M(
        t,
        "width",
        /*width_style*/
        s[15]
      ), u & /*effectiveValue, height_style*/
      65792 && M(
        t,
        "height",
        /*effectiveValue*/
        s[8].sidebar_position === "right" ? (
          /*height_style*/
          s[16]
        ) : void 0
      ), u & /*effectiveValue*/
      256 && M(t, "--main-panel-width", !/*effectiveValue*/
      s[8].show_credits && /*effectiveValue*/
      s[8].show_licenses ? "0px" : "auto"), u & /*width_style*/
      32768 && M(
        e,
        "width",
        /*width_style*/
        s[15]
      );
    },
    i(s) {
      a || (L(l), a = !0);
    },
    o(s) {
      N(l), a = !1;
    },
    d(s) {
      s && x(e), l && l.d(), r && r.d();
    }
  };
}
function Fs(o) {
  var d, f, g;
  let e, t, n, i = (
    /*effectiveValue*/
    o[8].logo_position
  ), a, l, r;
  e = new hr({
    props: {
      autoscroll: (
        /*gradio*/
        o[7].autoscroll
      ),
      i18n: (
        /*gradio*/
        o[7].i18n
      ),
      queue_position: (
        /*loading_status*/
        ((d = o[6]) == null ? void 0 : d.queue_position) ?? -1
      ),
      queue_size: (
        /*loading_status*/
        ((f = o[6]) == null ? void 0 : f.queue_size) ?? 0
      ),
      status: (
        /*loading_status*/
        ((g = o[6]) == null ? void 0 : g.status) ?? "complete"
      )
    }
  });
  const s = (
    /*#slots*/
    o[21].default
  ), u = _s(
    s,
    o,
    /*$$scope*/
    o[23],
    null
  );
  let _ = nl(o), c = (
    /*effectiveValue*/
    (o[8].show_licenses || /*effectiveValue*/
    o[8].show_credits) && il(o)
  );
  return {
    c() {
      ut(e.$$.fragment), t = Pe(), u && u.c(), n = Pe(), _.c(), a = Pe(), c && c.c(), l = Ge();
    },
    l(m) {
      st(e.$$.fragment, m), t = Oe(m), u && u.l(m), n = Oe(m), _.l(m), a = Oe(m), c && c.l(m), l = Ge();
    },
    m(m, v) {
      ct(e, m, v), G(m, t, v), u && u.m(m, v), G(m, n, v), _.m(m, v), G(m, a, v), c && c.m(m, v), G(m, l, v), r = !0;
    },
    p(m, v) {
      var p, h, b;
      const F = {};
      v & /*gradio*/
      128 && (F.autoscroll = /*gradio*/
      m[7].autoscroll), v & /*gradio*/
      128 && (F.i18n = /*gradio*/
      m[7].i18n), v & /*loading_status*/
      64 && (F.queue_position = /*loading_status*/
      ((p = m[6]) == null ? void 0 : p.queue_position) ?? -1), v & /*loading_status*/
      64 && (F.queue_size = /*loading_status*/
      ((h = m[6]) == null ? void 0 : h.queue_size) ?? 0), v & /*loading_status*/
      64 && (F.status = /*loading_status*/
      ((b = m[6]) == null ? void 0 : b.status) ?? "complete"), e.$set(F), u && u.p && (!r || v & /*$$scope*/
      8388608) && vs(
        u,
        s,
        m,
        /*$$scope*/
        m[23],
        r ? hs(
          s,
          /*$$scope*/
          m[23],
          v,
          null
        ) : ds(
          /*$$scope*/
          m[23]
        ),
        null
      ), v & /*effectiveValue*/
      256 && Wt(i, i = /*effectiveValue*/
      m[8].logo_position) ? (Ze(), N(_, 1, 1, Ct), Ue(), _ = nl(m), _.c(), L(_, 1), _.m(a.parentNode, a)) : _.p(m, v), /*effectiveValue*/
      m[8].show_licenses || /*effectiveValue*/
      m[8].show_credits ? c ? (c.p(m, v), v & /*effectiveValue*/
      256 && L(c, 1)) : (c = il(m), c.c(), L(c, 1), c.m(l.parentNode, l)) : c && (Ze(), N(c, 1, 1, () => {
        c = null;
      }), Ue());
    },
    i(m) {
      r || (L(e.$$.fragment, m), L(u, m), L(_), L(c), r = !0);
    },
    o(m) {
      N(e.$$.fragment, m), N(u, m), N(_), N(c), r = !1;
    },
    d(m) {
      m && (x(t), x(n), x(a), x(l)), _t(e, m), u && u.d(m), _.d(m), c && c.d(m);
    }
  };
}
function ks(o) {
  let e, t = `.credits-panel-wrapper { 
              flex-direction: row !important; 
              --panel-direction: row; 
              --sidebar-width: 400px; 
              --border-left: 1px solid var(--border-color-primary); 
              --border-top: none; 
              --border: none;
              --sidebar-max-height: {height_style}; 
            }
            .licenses-sidebar { width: var(--sidebar-width, 400px) !important; border-left: 1px solid var(--border-color-primary) !important; border-top: none !important; }
            .main-credits-panel { width: calc(100% - var(--sidebar-width, 400px)) !important; }`;
  return {
    c() {
      e = Q("style"), e.textContent = t;
    },
    l(n) {
      e = K(n, "STYLE", { "data-svelte-h": !0 }), xn(e) !== "svelte-1hbm6cs" && (e.textContent = t);
    },
    m(n, i) {
      G(n, e, i);
    },
    d(n) {
      n && x(e);
    }
  };
}
function Cs(o) {
  let e, t = `.credits-panel-wrapper {
        flex-direction: column !important;
        --panel-direction: column;
        --sidebar-width: 100%;
        --border-left: none;
        --border-top: 1px solid var(--border-color-primary);
        --sidebar-max-height: 400px;
        --border: none;
      }
      .licenses-sidebar {
        width: 100% !important;
        border-left: none !important;
        border-top: 1px solid var(--border-color-primary) !important;
      }
      .main-credits-panel {
        width: 100% !important;
      }`;
  return {
    c() {
      e = Q("style"), e.textContent = t;
    },
    l(n) {
      e = K(n, "STYLE", { "data-svelte-h": !0 }), xn(e) !== "svelte-gyscx4" && (e.textContent = t);
    },
    m(n, i) {
      G(n, e, i);
    },
    d(n) {
      n && x(e);
    }
  };
}
function Es(o) {
  let e, t, n, i;
  e = new go({
    props: {
      visible: (
        /*visible*/
        o[2]
      ),
      elem_id: (
        /*elem_id*/
        o[0]
      ),
      elem_classes: (
        /*elem_classes*/
        o[1]
      ),
      container: (
        /*container*/
        o[3]
      ),
      scale: (
        /*scale*/
        o[4]
      ),
      min_width: (
        /*min_width*/
        o[5]
      ),
      padding: !1,
      $$slots: { default: [Fs] },
      $$scope: { ctx: o }
    }
  });
  function a(s, u) {
    return (
      /*effectiveValue*/
      s[8].sidebar_position === "bottom" ? Cs : ks
    );
  }
  let l = a(o), r = l(o);
  return {
    c() {
      ut(e.$$.fragment), t = Pe(), r.c(), n = Ge();
    },
    l(s) {
      st(e.$$.fragment, s), t = Oe(s);
      const u = fs("svelte-1lsh18a", document.head);
      r.l(u), n = Ge(), u.forEach(x);
    },
    m(s, u) {
      ct(e, s, u), G(s, t, u), r.m(document.head, null), ee(document.head, n), i = !0;
    },
    p(s, [u]) {
      const _ = {};
      u & /*visible*/
      4 && (_.visible = /*visible*/
      s[2]), u & /*elem_id*/
      1 && (_.elem_id = /*elem_id*/
      s[0]), u & /*elem_classes*/
      2 && (_.elem_classes = /*elem_classes*/
      s[1]), u & /*container*/
      8 && (_.container = /*container*/
      s[3]), u & /*scale*/
      16 && (_.scale = /*scale*/
      s[4]), u & /*min_width*/
      32 && (_.min_width = /*min_width*/
      s[5]), u & /*$$scope, effectiveValue, width_style, height_style, selected_license_name, logo_panel_height, logo_justify, gradio, logo_width_style, logo_height_style, object_fit, loading_status*/
      8519616 && (_.$$scope = { dirty: u, ctx: s }), e.$set(_), l !== (l = a(s)) && (r.d(1), r = l(s), r && (r.c(), r.m(n.parentNode, n)));
    },
    i(s) {
      i || (L(e.$$.fragment, s), i = !0);
    },
    o(s) {
      N(e.$$.fragment, s), i = !1;
    },
    d(s) {
      s && x(t), _t(e, s), r.d(s), x(n);
    }
  };
}
function As(o, e, t) {
  let n, i, a, l, r, s, u, _, { $$slots: c = {}, $$scope: d } = e, { value: f = null } = e, { elem_id: g = "" } = e, { elem_classes: m = [] } = e, { visible: v = !0 } = e, { container: F = !0 } = e, { scale: p = null } = e, { min_width: h = void 0 } = e, { height: b = void 0 } = e, { width: y = void 0 } = e, { loading_status: D } = e, { gradio: $ } = e, S = null;
  function k(C) {
    t(9, S = S === C ? null : C);
  }
  const q = (C) => k(C);
  return o.$$set = (C) => {
    "value" in C && t(18, f = C.value), "elem_id" in C && t(0, g = C.elem_id), "elem_classes" in C && t(1, m = C.elem_classes), "visible" in C && t(2, v = C.visible), "container" in C && t(3, F = C.container), "scale" in C && t(4, p = C.scale), "min_width" in C && t(5, h = C.min_width), "height" in C && t(19, b = C.height), "width" in C && t(20, y = C.width), "loading_status" in C && t(6, D = C.loading_status), "gradio" in C && t(7, $ = C.gradio), "$$scope" in C && t(23, d = C.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty & /*value*/
    262144 && t(8, n = f || {
      credits: [
        {
          title: "Lead Developer",
          name: "John Doe"
        },
        {
          title: "UI/UX Design",
          name: "Jane Smith"
        },
        {
          title: "Backend Engineering",
          name: "Alex Ray"
        },
        {
          title: "Component Concept",
          name: "Your Name"
        },
        {
          title: "Quality Assurance",
          name: "Sam Wilson"
        }
      ],
      licenses: {
        "Gradio Framework": "Apache License placeholder",
        "This Component": "MIT License placeholder"
      },
      effect: "scroll",
      speed: 40,
      base_font_size: 1.5,
      intro_title: "",
      intro_subtitle: "",
      sidebar_position: "right",
      logo_path: null,
      show_logo: !0,
      show_licenses: !0,
      show_credits: !0,
      logo_position: "center",
      logo_sizing: "resize",
      logo_width: null,
      logo_height: null,
      scroll_background_color: null,
      scroll_title_color: null,
      scroll_name_color: null
    }), o.$$.dirty & /*height*/
    524288 && t(16, i = typeof b == "number" ? `${b}px` : b || "500px"), o.$$.dirty & /*width*/
    1048576 && t(15, a = typeof y == "number" ? `${y}px` : y || "100%"), o.$$.dirty & /*effectiveValue*/
    256 && t(14, l = n.logo_width ? typeof n.logo_width == "number" ? `${n.logo_width}px` : n.logo_width : "auto"), o.$$.dirty & /*effectiveValue*/
    256 && t(13, r = n.logo_height ? typeof n.logo_height == "number" ? `${n.logo_height}px` : n.logo_height : "100px"), o.$$.dirty & /*effectiveValue*/
    256 && t(12, s = n.logo_height ? typeof n.logo_height == "number" ? `${n.logo_height}px` : n.logo_height : "100px"), o.$$.dirty & /*effectiveValue*/
    256 && t(11, u = n.logo_sizing === "stretch" ? "fill" : n.logo_sizing === "crop" ? "cover" : "contain"), o.$$.dirty & /*effectiveValue*/
    256 && t(10, _ = n.logo_position === "center" ? "center" : n.logo_position === "left" ? "flex-start" : "flex-end");
  }, [
    g,
    m,
    v,
    F,
    p,
    h,
    D,
    $,
    n,
    S,
    _,
    u,
    s,
    r,
    l,
    a,
    i,
    k,
    f,
    b,
    y,
    c,
    q,
    d
  ];
}
class w3 extends us {
  constructor(e) {
    super(), ps(this, e, As, Es, Wt, {
      value: 18,
      elem_id: 0,
      elem_classes: 1,
      visible: 2,
      container: 3,
      scale: 4,
      min_width: 5,
      height: 19,
      width: 20,
      loading_status: 6,
      gradio: 7
    });
  }
}
export {
  w3 as default
};
