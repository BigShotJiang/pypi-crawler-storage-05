netbox
======

.. automodule:: spicerack.netbox
