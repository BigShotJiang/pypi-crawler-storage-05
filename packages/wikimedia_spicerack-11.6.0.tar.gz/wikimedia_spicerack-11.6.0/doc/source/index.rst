Spicerack |release| documentation
=================================

Automation framework for the WMF production infrastructure.

.. toctree::
   :maxdepth: 3

   introduction
   installation
   configuration
   cookbook
   api/index
   development

.. toctree::
   :maxdepth: 2

   release


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
