Cookbook CLI
============

.. argparse::
   :module: spicerack._cookbook
   :func: argument_parser
   :prog: cookbook
   :nodefault:
