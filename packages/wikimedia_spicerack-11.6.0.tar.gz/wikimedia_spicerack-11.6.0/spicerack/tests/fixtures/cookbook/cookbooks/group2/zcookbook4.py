# Group2 zCookbook4. No docstring to test the fallback value.
# pylint: disable=missing-module-docstring
# noqa:  D100


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    return 0
