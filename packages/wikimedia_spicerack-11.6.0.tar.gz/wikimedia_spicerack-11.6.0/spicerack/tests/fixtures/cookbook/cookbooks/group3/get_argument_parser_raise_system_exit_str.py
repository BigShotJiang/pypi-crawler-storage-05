"""Group3 get argument_parser() raise SystemExit(str)."""


def argument_parser():
    """As required by spicerack._cookbook."""
    raise SystemExit("argument_parser")


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
