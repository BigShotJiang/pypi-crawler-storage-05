"""Group3 Raise SystemExit(0)."""


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    raise SystemExit(0)
