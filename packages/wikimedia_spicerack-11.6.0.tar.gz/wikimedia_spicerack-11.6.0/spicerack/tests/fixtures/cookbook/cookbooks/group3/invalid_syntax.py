"""Group3 Invalid syntax."""


def run(args, spicerack):  # pylint: disable=unused-argument
    """As required by spicerack._cookbook."""
    invalid =  # noqa: E999
