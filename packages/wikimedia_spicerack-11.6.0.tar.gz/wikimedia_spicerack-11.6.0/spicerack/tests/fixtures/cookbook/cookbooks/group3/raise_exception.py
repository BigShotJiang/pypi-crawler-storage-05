"""Group3 Raise Exception."""


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    raise RuntimeError("Something went wrong")
