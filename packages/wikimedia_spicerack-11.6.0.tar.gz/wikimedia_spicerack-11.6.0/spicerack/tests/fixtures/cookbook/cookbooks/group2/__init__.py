# Group2 Test Cookbooks. No docstring to test the fallback if __title__ is missing
# pylint: disable=missing-module-docstring
# noqa:  D104

__owner_team__ = "team2"
