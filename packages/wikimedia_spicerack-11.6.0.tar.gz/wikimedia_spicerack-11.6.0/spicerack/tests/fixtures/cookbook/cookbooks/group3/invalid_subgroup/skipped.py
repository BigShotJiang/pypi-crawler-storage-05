"""Group3 Invalid subgroup skipped."""


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    return 0
