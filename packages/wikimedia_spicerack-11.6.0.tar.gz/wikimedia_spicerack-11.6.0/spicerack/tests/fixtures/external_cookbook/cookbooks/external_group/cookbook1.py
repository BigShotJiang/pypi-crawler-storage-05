"""External Group Cookbook1."""

__title__ = __doc__


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    return 0
