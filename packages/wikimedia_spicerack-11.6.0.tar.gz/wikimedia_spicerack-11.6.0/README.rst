Spicerack - Automation framework for the WMF production infrastructure
----------------------------------------------------------------------

Spicerack provides an entry point to all the libraries needed to automate and orchestrate tasks inside the Wikimedia
Foundation's (WMF) production infrastructure. It provides also an entry point script ``cookbook`` to list and run the
available cookbooks, both one by one or via an interactive menu.
