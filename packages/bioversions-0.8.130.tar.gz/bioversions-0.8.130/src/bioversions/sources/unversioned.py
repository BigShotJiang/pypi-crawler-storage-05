"""A collection of unversioned resources."""

# TODO
