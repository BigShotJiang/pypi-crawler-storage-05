"""Entrypoint module, in case you use `python -m bioversions`."""

from .cli import main

if __name__ == "__main__":
    main()
