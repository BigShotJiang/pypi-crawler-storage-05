from svc_infra.db.sql.repository import SqlRepository
from svc_infra.db.sql.resource import SqlResource

__all__ = [
    "SqlResource",
    "SqlRepository",
]
