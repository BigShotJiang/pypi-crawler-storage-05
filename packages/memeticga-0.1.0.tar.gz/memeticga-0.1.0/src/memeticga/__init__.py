from .core import MGA

__all__ = ["MGA"]
__version__ = "0.1.0"