VERSION = (0, 1, 12)

__version__ = '.'.join(map(str, VERSION)) 