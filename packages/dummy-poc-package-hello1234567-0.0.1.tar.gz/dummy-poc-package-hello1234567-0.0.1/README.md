# dummy-poc-package-hello1234567
This is a safe PoC package demonstrating dependency confusion.
Claimed by cygut7.
