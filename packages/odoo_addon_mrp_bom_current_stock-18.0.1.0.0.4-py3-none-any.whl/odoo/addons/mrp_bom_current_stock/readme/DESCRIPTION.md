This modules extend the Manufacturing App adding a report that explodes
the bill of materials and show the stock available in the source
location.
