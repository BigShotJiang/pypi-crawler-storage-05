"""Finter Signal - Quantitative platform onboarding CLI."""

__version__ = "0.1.0"