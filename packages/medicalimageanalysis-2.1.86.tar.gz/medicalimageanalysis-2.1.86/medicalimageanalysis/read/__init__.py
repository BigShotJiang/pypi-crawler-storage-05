
from .dicom import DicomReader
from .stl import StlReader
from .vtk import VtkReader
from .mf3 import ThreeMfReader
