# __main__.py

from mcp_server_tavily import main

main()
