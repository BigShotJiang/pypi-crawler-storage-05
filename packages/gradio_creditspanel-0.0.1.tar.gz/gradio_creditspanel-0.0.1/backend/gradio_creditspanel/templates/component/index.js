var Wl = Object.defineProperty;
var In = (l) => {
  throw TypeError(l);
};
var Kl = (l, e, t) => e in l ? Wl(l, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : l[e] = t;
var O = (l, e, t) => Kl(l, typeof e != "symbol" ? e + "" : e, t), Ql = (l, e, t) => e.has(l) || In("Cannot " + t);
var Rn = (l, e, t) => e.has(l) ? In("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(l) : e.set(l, t);
var Bt = (l, e, t) => (Ql(l, e, "access private method"), t);
const {
  SvelteComponent: Jl,
  append_hydration: sn,
  assign: eo,
  attr: X,
  binding_callbacks: to,
  children: pt,
  claim_element: sl,
  claim_space: ul,
  claim_svg_element: en,
  create_slot: no,
  detach: Ee,
  element: _l,
  empty: Ln,
  get_all_dirty_from_scope: io,
  get_slot_changes: lo,
  get_spread_update: oo,
  init: ao,
  insert_hydration: yt,
  listen: ro,
  noop: so,
  safe_not_equal: uo,
  set_dynamic_element_data: On,
  set_style: x,
  space: cl,
  svg_element: tn,
  toggle_class: U,
  transition_in: dl,
  transition_out: hl,
  update_slot_base: _o
} = window.__gradio__svelte__internal;
function Pn(l) {
  let e, t, n, i, a;
  return {
    c() {
      e = tn("svg"), t = tn("line"), n = tn("line"), this.h();
    },
    l(o) {
      e = en(o, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var s = pt(e);
      t = en(s, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), pt(t).forEach(Ee), n = en(s, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), pt(n).forEach(Ee), s.forEach(Ee), this.h();
    },
    h() {
      X(t, "x1", "1"), X(t, "y1", "9"), X(t, "x2", "9"), X(t, "y2", "1"), X(t, "stroke", "gray"), X(t, "stroke-width", "0.5"), X(n, "x1", "5"), X(n, "y1", "9"), X(n, "x2", "9"), X(n, "y2", "5"), X(n, "stroke", "gray"), X(n, "stroke-width", "0.5"), X(e, "class", "resize-handle svelte-239wnu"), X(e, "xmlns", "http://www.w3.org/2000/svg"), X(e, "viewBox", "0 0 10 10");
    },
    m(o, s) {
      yt(o, e, s), sn(e, t), sn(e, n), i || (a = ro(
        e,
        "mousedown",
        /*resize*/
        l[27]
      ), i = !0);
    },
    p: so,
    d(o) {
      o && Ee(e), i = !1, a();
    }
  };
}
function co(l) {
  var d;
  let e, t, n, i, a;
  const o = (
    /*#slots*/
    l[31].default
  ), s = no(
    o,
    l,
    /*$$scope*/
    l[30],
    null
  );
  let r = (
    /*resizable*/
    l[19] && Pn(l)
  ), u = [
    { "data-testid": (
      /*test_id*/
      l[11]
    ) },
    { id: (
      /*elem_id*/
      l[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((d = l[7]) == null ? void 0 : d.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      l[20] ? "rtl" : "ltr"
    }
  ], _ = {};
  for (let c = 0; c < u.length; c += 1)
    _ = eo(_, u[c]);
  return {
    c() {
      e = _l(
        /*tag*/
        l[25]
      ), s && s.c(), t = cl(), r && r.c(), this.h();
    },
    l(c) {
      e = sl(
        c,
        /*tag*/
        (l[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var f = pt(e);
      s && s.l(f), t = ul(f), r && r.l(f), f.forEach(Ee), this.h();
    },
    h() {
      On(
        /*tag*/
        l[25]
      )(e, _), U(
        e,
        "hidden",
        /*visible*/
        l[14] === !1
      ), U(
        e,
        "padded",
        /*padding*/
        l[10]
      ), U(
        e,
        "flex",
        /*flex*/
        l[1]
      ), U(
        e,
        "border_focus",
        /*border_mode*/
        l[9] === "focus"
      ), U(
        e,
        "border_contrast",
        /*border_mode*/
        l[9] === "contrast"
      ), U(e, "hide-container", !/*explicit_call*/
      l[12] && !/*container*/
      l[13]), U(
        e,
        "fullscreen",
        /*fullscreen*/
        l[0]
      ), U(
        e,
        "animating",
        /*fullscreen*/
        l[0] && /*preexpansionBoundingRect*/
        l[24] !== null
      ), U(
        e,
        "auto-margin",
        /*scale*/
        l[17] === null
      ), x(
        e,
        "height",
        /*fullscreen*/
        l[0] ? void 0 : (
          /*get_dimension*/
          l[26](
            /*height*/
            l[2]
          )
        )
      ), x(
        e,
        "min-height",
        /*fullscreen*/
        l[0] ? void 0 : (
          /*get_dimension*/
          l[26](
            /*min_height*/
            l[3]
          )
        )
      ), x(
        e,
        "max-height",
        /*fullscreen*/
        l[0] ? void 0 : (
          /*get_dimension*/
          l[26](
            /*max_height*/
            l[4]
          )
        )
      ), x(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        l[24] ? `${/*preexpansionBoundingRect*/
        l[24].top}px` : "0px"
      ), x(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        l[24] ? `${/*preexpansionBoundingRect*/
        l[24].left}px` : "0px"
      ), x(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        l[24] ? `${/*preexpansionBoundingRect*/
        l[24].width}px` : "0px"
      ), x(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        l[24] ? `${/*preexpansionBoundingRect*/
        l[24].height}px` : "0px"
      ), x(
        e,
        "width",
        /*fullscreen*/
        l[0] ? void 0 : typeof /*width*/
        l[5] == "number" ? `calc(min(${/*width*/
        l[5]}px, 100%))` : (
          /*get_dimension*/
          l[26](
            /*width*/
            l[5]
          )
        )
      ), x(
        e,
        "border-style",
        /*variant*/
        l[8]
      ), x(
        e,
        "overflow",
        /*allow_overflow*/
        l[15] ? (
          /*overflow_behavior*/
          l[16]
        ) : "hidden"
      ), x(
        e,
        "flex-grow",
        /*scale*/
        l[17]
      ), x(e, "min-width", `calc(min(${/*min_width*/
      l[18]}px, 100%))`), x(e, "border-width", "var(--block-border-width)");
    },
    m(c, f) {
      yt(c, e, f), s && s.m(e, null), sn(e, t), r && r.m(e, null), l[32](e), a = !0;
    },
    p(c, f) {
      var g;
      s && s.p && (!a || f[0] & /*$$scope*/
      1073741824) && _o(
        s,
        o,
        c,
        /*$$scope*/
        c[30],
        a ? lo(
          o,
          /*$$scope*/
          c[30],
          f,
          null
        ) : io(
          /*$$scope*/
          c[30]
        ),
        null
      ), /*resizable*/
      c[19] ? r ? r.p(c, f) : (r = Pn(c), r.c(), r.m(e, null)) : r && (r.d(1), r = null), On(
        /*tag*/
        c[25]
      )(e, _ = oo(u, [
        (!a || f[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          c[11]
        ) },
        (!a || f[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          c[6]
        ) },
        (!a || f[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((g = c[7]) == null ? void 0 : g.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!a || f[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        c[20] ? "rtl" : "ltr")) && { dir: i }
      ])), U(
        e,
        "hidden",
        /*visible*/
        c[14] === !1
      ), U(
        e,
        "padded",
        /*padding*/
        c[10]
      ), U(
        e,
        "flex",
        /*flex*/
        c[1]
      ), U(
        e,
        "border_focus",
        /*border_mode*/
        c[9] === "focus"
      ), U(
        e,
        "border_contrast",
        /*border_mode*/
        c[9] === "contrast"
      ), U(e, "hide-container", !/*explicit_call*/
      c[12] && !/*container*/
      c[13]), U(
        e,
        "fullscreen",
        /*fullscreen*/
        c[0]
      ), U(
        e,
        "animating",
        /*fullscreen*/
        c[0] && /*preexpansionBoundingRect*/
        c[24] !== null
      ), U(
        e,
        "auto-margin",
        /*scale*/
        c[17] === null
      ), f[0] & /*fullscreen, height*/
      5 && x(
        e,
        "height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*height*/
            c[2]
          )
        )
      ), f[0] & /*fullscreen, min_height*/
      9 && x(
        e,
        "min-height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*min_height*/
            c[3]
          )
        )
      ), f[0] & /*fullscreen, max_height*/
      17 && x(
        e,
        "max-height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*max_height*/
            c[4]
          )
        )
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && x(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].top}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && x(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].left}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && x(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].width}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && x(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].height}px` : "0px"
      ), f[0] & /*fullscreen, width*/
      33 && x(
        e,
        "width",
        /*fullscreen*/
        c[0] ? void 0 : typeof /*width*/
        c[5] == "number" ? `calc(min(${/*width*/
        c[5]}px, 100%))` : (
          /*get_dimension*/
          c[26](
            /*width*/
            c[5]
          )
        )
      ), f[0] & /*variant*/
      256 && x(
        e,
        "border-style",
        /*variant*/
        c[8]
      ), f[0] & /*allow_overflow, overflow_behavior*/
      98304 && x(
        e,
        "overflow",
        /*allow_overflow*/
        c[15] ? (
          /*overflow_behavior*/
          c[16]
        ) : "hidden"
      ), f[0] & /*scale*/
      131072 && x(
        e,
        "flex-grow",
        /*scale*/
        c[17]
      ), f[0] & /*min_width*/
      262144 && x(e, "min-width", `calc(min(${/*min_width*/
      c[18]}px, 100%))`);
    },
    i(c) {
      a || (dl(s, c), a = !0);
    },
    o(c) {
      hl(s, c), a = !1;
    },
    d(c) {
      c && Ee(e), s && s.d(c), r && r.d(), l[32](null);
    }
  };
}
function jn(l) {
  let e;
  return {
    c() {
      e = _l("div"), this.h();
    },
    l(t) {
      e = sl(t, "DIV", { class: !0 }), pt(e).forEach(Ee), this.h();
    },
    h() {
      X(e, "class", "placeholder svelte-239wnu"), x(
        e,
        "height",
        /*placeholder_height*/
        l[22] + "px"
      ), x(
        e,
        "width",
        /*placeholder_width*/
        l[23] + "px"
      );
    },
    m(t, n) {
      yt(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && x(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && x(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && Ee(e);
    }
  };
}
function ho(l) {
  let e, t, n, i = (
    /*tag*/
    l[25] && co(l)
  ), a = (
    /*fullscreen*/
    l[0] && jn(l)
  );
  return {
    c() {
      i && i.c(), e = cl(), a && a.c(), t = Ln();
    },
    l(o) {
      i && i.l(o), e = ul(o), a && a.l(o), t = Ln();
    },
    m(o, s) {
      i && i.m(o, s), yt(o, e, s), a && a.m(o, s), yt(o, t, s), n = !0;
    },
    p(o, s) {
      /*tag*/
      o[25] && i.p(o, s), /*fullscreen*/
      o[0] ? a ? a.p(o, s) : (a = jn(o), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    i(o) {
      n || (dl(i, o), n = !0);
    },
    o(o) {
      hl(i, o), n = !1;
    },
    d(o) {
      o && (Ee(e), Ee(t)), i && i.d(o), a && a.d(o);
    }
  };
}
function fo(l, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { height: a = void 0 } = e, { min_height: o = void 0 } = e, { max_height: s = void 0 } = e, { width: r = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: _ = [] } = e, { variant: d = "solid" } = e, { border_mode: c = "base" } = e, { padding: f = !0 } = e, { type: g = "normal" } = e, { test_id: y = void 0 } = e, { explicit_call: m = !1 } = e, { container: $ = !0 } = e, { visible: p = !0 } = e, { allow_overflow: h = !0 } = e, { overflow_behavior: b = "auto" } = e, { scale: v = null } = e, { min_width: D = 0 } = e, { flex: w = !1 } = e, { resizable: S = !1 } = e, { rtl: k = !1 } = e, { fullscreen: q = !1 } = e, C = q, L, Ue = g === "fieldset" ? "fieldset" : "div", ne = 0, Fe = 0, te = null;
  function je(F) {
    q && F.key === "Escape" && t(0, q = !1);
  }
  const N = (F) => {
    if (F !== void 0) {
      if (typeof F == "number")
        return F + "px";
      if (typeof F == "string")
        return F;
    }
  }, Q = (F) => {
    let G = F.clientY;
    const et = (E) => {
      const tt = E.clientY - G;
      G = E.clientY, t(21, L.style.height = `${L.offsetHeight + tt}px`, L);
    }, ie = () => {
      window.removeEventListener("mousemove", et), window.removeEventListener("mouseup", ie);
    };
    window.addEventListener("mousemove", et), window.addEventListener("mouseup", ie);
  };
  function pe(F) {
    to[F ? "unshift" : "push"](() => {
      L = F, t(21, L);
    });
  }
  return l.$$set = (F) => {
    "height" in F && t(2, a = F.height), "min_height" in F && t(3, o = F.min_height), "max_height" in F && t(4, s = F.max_height), "width" in F && t(5, r = F.width), "elem_id" in F && t(6, u = F.elem_id), "elem_classes" in F && t(7, _ = F.elem_classes), "variant" in F && t(8, d = F.variant), "border_mode" in F && t(9, c = F.border_mode), "padding" in F && t(10, f = F.padding), "type" in F && t(28, g = F.type), "test_id" in F && t(11, y = F.test_id), "explicit_call" in F && t(12, m = F.explicit_call), "container" in F && t(13, $ = F.container), "visible" in F && t(14, p = F.visible), "allow_overflow" in F && t(15, h = F.allow_overflow), "overflow_behavior" in F && t(16, b = F.overflow_behavior), "scale" in F && t(17, v = F.scale), "min_width" in F && t(18, D = F.min_width), "flex" in F && t(1, w = F.flex), "resizable" in F && t(19, S = F.resizable), "rtl" in F && t(20, k = F.rtl), "fullscreen" in F && t(0, q = F.fullscreen), "$$scope" in F && t(30, i = F.$$scope);
  }, l.$$.update = () => {
    l.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && q !== C && (t(29, C = q), q ? (t(24, te = L.getBoundingClientRect()), t(22, ne = L.offsetHeight), t(23, Fe = L.offsetWidth), window.addEventListener("keydown", je)) : (t(24, te = null), window.removeEventListener("keydown", je))), l.$$.dirty[0] & /*visible*/
    16384 && (p || t(1, w = !1));
  }, [
    q,
    w,
    a,
    o,
    s,
    r,
    u,
    _,
    d,
    c,
    f,
    y,
    m,
    $,
    p,
    h,
    b,
    v,
    D,
    S,
    k,
    L,
    ne,
    Fe,
    te,
    Ue,
    N,
    Q,
    g,
    C,
    i,
    n,
    pe
  ];
}
class po extends Jl {
  constructor(e) {
    super(), ao(
      this,
      e,
      fo,
      ho,
      uo,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Fn() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Je = Fn();
function fl(l) {
  Je = l;
}
const pl = /[&<>"']/, mo = new RegExp(pl.source, "g"), ml = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, go = new RegExp(ml.source, "g"), vo = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Mn = (l) => vo[l];
function oe(l, e) {
  if (e) {
    if (pl.test(l))
      return l.replace(mo, Mn);
  } else if (ml.test(l))
    return l.replace(go, Mn);
  return l;
}
const bo = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Do(l) {
  return l.replace(bo, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const yo = /(^|[^\[])\^/g;
function R(l, e) {
  let t = typeof l == "string" ? l : l.source;
  e = e || "";
  const n = {
    replace: (i, a) => {
      let o = typeof a == "string" ? a : a.source;
      return o = o.replace(yo, "$1"), t = t.replace(i, o), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function Nn(l) {
  try {
    l = encodeURI(l).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return l;
}
const mt = { exec: () => null };
function Hn(l, e) {
  const t = l.replace(/\|/g, (a, o, s) => {
    let r = !1, u = o;
    for (; --u >= 0 && s[u] === "\\"; )
      r = !r;
    return r ? "|" : " |";
  }), n = t.split(/ \|/);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(/\\\|/g, "|");
  return n;
}
function qt(l, e, t) {
  const n = l.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && l.charAt(n - i - 1) === e; )
    i++;
  return l.slice(0, n - i);
}
function $o(l, e) {
  if (l.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < l.length; n++)
    if (l[n] === "\\")
      n++;
    else if (l[n] === e[0])
      t++;
    else if (l[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Vn(l, e, t, n) {
  const i = e.href, a = e.title ? oe(e.title) : null, o = l[1].replace(/\\([\[\]])/g, "$1");
  if (l[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const s = {
      type: "link",
      raw: t,
      href: i,
      title: a,
      text: o,
      tokens: n.inlineTokens(o)
    };
    return n.state.inLink = !1, s;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: a,
    text: oe(o)
  };
}
function wo(l, e) {
  const t = l.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((i) => {
    const a = i.match(/^\s+/);
    if (a === null)
      return i;
    const [o] = a;
    return o.length >= n.length ? i.slice(n.length) : i;
  }).join(`
`);
}
class Ht {
  // set by the lexer
  constructor(e) {
    O(this, "options");
    O(this, "rules");
    // set by the lexer
    O(this, "lexer");
    this.options = e || Je;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : qt(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], i = wo(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const i = qt(n, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (n = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = qt(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const a = this.lexer.blockTokens(n);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: a,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const i = n.length > 1, a = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = i ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = i ? n : "[*+-]");
      const o = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let s = "", r = "", u = !1;
      for (; e; ) {
        let _ = !1;
        if (!(t = o.exec(e)) || this.rules.block.hr.test(e))
          break;
        s = t[0], e = e.substring(s.length);
        let d = t[2].split(`
`, 1)[0].replace(/^\t+/, ($) => " ".repeat(3 * $.length)), c = e.split(`
`, 1)[0], f = 0;
        this.options.pedantic ? (f = 2, r = d.trimStart()) : (f = t[2].search(/[^ ]/), f = f > 4 ? 1 : f, r = d.slice(f), f += t[1].length);
        let g = !1;
        if (!d && /^ *$/.test(c) && (s += c + `
`, e = e.substring(c.length + 1), _ = !0), !_) {
          const $ = new RegExp(`^ {0,${Math.min(3, f - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), p = new RegExp(`^ {0,${Math.min(3, f - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), h = new RegExp(`^ {0,${Math.min(3, f - 1)}}(?:\`\`\`|~~~)`), b = new RegExp(`^ {0,${Math.min(3, f - 1)}}#`);
          for (; e; ) {
            const v = e.split(`
`, 1)[0];
            if (c = v, this.options.pedantic && (c = c.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), h.test(c) || b.test(c) || $.test(c) || p.test(e))
              break;
            if (c.search(/[^ ]/) >= f || !c.trim())
              r += `
` + c.slice(f);
            else {
              if (g || d.search(/[^ ]/) >= 4 || h.test(d) || b.test(d) || p.test(d))
                break;
              r += `
` + c;
            }
            !g && !c.trim() && (g = !0), s += v + `
`, e = e.substring(v.length + 1), d = c.slice(f);
          }
        }
        a.loose || (u ? a.loose = !0 : /\n *\n *$/.test(s) && (u = !0));
        let y = null, m;
        this.options.gfm && (y = /^\[[ xX]\] /.exec(r), y && (m = y[0] !== "[ ] ", r = r.replace(/^\[[ xX]\] +/, ""))), a.items.push({
          type: "list_item",
          raw: s,
          task: !!y,
          checked: m,
          loose: !1,
          text: r,
          tokens: []
        }), a.raw += s;
      }
      a.items[a.items.length - 1].raw = s.trimEnd(), a.items[a.items.length - 1].text = r.trimEnd(), a.raw = a.raw.trimEnd();
      for (let _ = 0; _ < a.items.length; _++)
        if (this.lexer.state.top = !1, a.items[_].tokens = this.lexer.blockTokens(a.items[_].text, []), !a.loose) {
          const d = a.items[_].tokens.filter((f) => f.type === "space"), c = d.length > 0 && d.some((f) => /\n.*\n/.test(f.raw));
          a.loose = c;
        }
      if (a.loose)
        for (let _ = 0; _ < a.items.length; _++)
          a.items[_].loose = !0;
      return a;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: i,
        title: a
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Hn(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), a = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], o = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === i.length) {
      for (const s of i)
        /^ *-+: *$/.test(s) ? o.align.push("right") : /^ *:-+: *$/.test(s) ? o.align.push("center") : /^ *:-+ *$/.test(s) ? o.align.push("left") : o.align.push(null);
      for (const s of n)
        o.header.push({
          text: s,
          tokens: this.lexer.inline(s)
        });
      for (const s of a)
        o.rows.push(Hn(s, o.header.length).map((r) => ({
          text: r,
          tokens: this.lexer.inline(r)
        })));
      return o;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: oe(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const o = qt(n.slice(0, -1), "\\");
        if ((n.length - o.length) % 2 === 0)
          return;
      } else {
        const o = $o(t[2], "()");
        if (o > -1) {
          const r = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + o;
          t[2] = t[2].substring(0, o), t[0] = t[0].substring(0, r).trim(), t[3] = "";
        }
      }
      let i = t[2], a = "";
      if (this.options.pedantic) {
        const o = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        o && (i = o[1], a = o[3]);
      } else
        a = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(n) ? i = i.slice(1) : i = i.slice(1, -1)), Vn(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: a && a.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const i = (n[2] || n[1]).replace(/\s+/g, " "), a = t[i.toLowerCase()];
      if (!a) {
        const o = n[0].charAt(0);
        return {
          type: "text",
          raw: o,
          text: o
        };
      }
      return Vn(n, a, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const o = [...i[0]].length - 1;
      let s, r, u = o, _ = 0;
      const d = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, t = t.slice(-1 * e.length + o); (i = d.exec(t)) != null; ) {
        if (s = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !s)
          continue;
        if (r = [...s].length, i[3] || i[4]) {
          u += r;
          continue;
        } else if ((i[5] || i[6]) && o % 3 && !((o + r) % 3)) {
          _ += r;
          continue;
        }
        if (u -= r, u > 0)
          continue;
        r = Math.min(r, r + u + _);
        const c = [...i[0]][0].length, f = e.slice(0, o + i.index + c + r);
        if (Math.min(o, r) % 2) {
          const y = f.slice(1, -1);
          return {
            type: "em",
            raw: f,
            text: y,
            tokens: this.lexer.inlineTokens(y)
          };
        }
        const g = f.slice(2, -2);
        return {
          type: "strong",
          raw: f,
          text: g,
          tokens: this.lexer.inlineTokens(g)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(n), a = /^ /.test(n) && / $/.test(n);
      return i && a && (n = n.substring(1, n.length - 1)), n = oe(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, i;
      return t[2] === "@" ? (n = oe(t[1]), i = "mailto:" + n) : (n = oe(t[1]), i = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, a;
      if (t[2] === "@")
        i = oe(t[0]), a = "mailto:" + i;
      else {
        let o;
        do
          o = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (o !== t[0]);
        i = oe(t[0]), t[1] === "www." ? a = "http://" + t[0] : a = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: a,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = oe(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Fo = /^(?: *(?:\n|$))+/, ko = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Co = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Ct = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Eo = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, gl = /(?:[*+-]|\d{1,9}[.)])/, vl = R(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, gl).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), kn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Ao = /^[^\n]+/, Cn = /(?!\s*\])(?:\\.|[^\[\]\\])+/, So = R(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Cn).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Bo = R(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, gl).getRegex(), Yt = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", En = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, qo = R("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", En).replace("tag", Yt).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), bl = R(kn).replace("hr", Ct).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Yt).getRegex(), To = R(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", bl).getRegex(), An = {
  blockquote: To,
  code: ko,
  def: So,
  fences: Co,
  heading: Eo,
  hr: Ct,
  html: qo,
  lheading: vl,
  list: Bo,
  newline: Fo,
  paragraph: bl,
  table: mt,
  text: Ao
}, Un = R("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Ct).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Yt).getRegex(), xo = {
  ...An,
  table: Un,
  paragraph: R(kn).replace("hr", Ct).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Un).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Yt).getRegex()
}, zo = {
  ...An,
  html: R(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", En).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: mt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: R(kn).replace("hr", Ct).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", vl).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Dl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Io = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, yl = /^( {2,}|\\)\n(?!\s*$)/, Ro = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Et = "\\p{P}\\p{S}", Lo = R(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Et).getRegex(), Oo = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Po = R(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Et).getRegex(), jo = R("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Et).getRegex(), Mo = R("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Et).getRegex(), No = R(/\\([punct])/, "gu").replace(/punct/g, Et).getRegex(), Ho = R(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Vo = R(En).replace("(?:-->|$)", "-->").getRegex(), Uo = R("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Vo).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Vt = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Go = R(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Vt).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), $l = R(/^!?\[(label)\]\[(ref)\]/).replace("label", Vt).replace("ref", Cn).getRegex(), wl = R(/^!?\[(ref)\](?:\[\])?/).replace("ref", Cn).getRegex(), Zo = R("reflink|nolink(?!\\()", "g").replace("reflink", $l).replace("nolink", wl).getRegex(), Sn = {
  _backpedal: mt,
  // only used for GFM url
  anyPunctuation: No,
  autolink: Ho,
  blockSkip: Oo,
  br: yl,
  code: Io,
  del: mt,
  emStrongLDelim: Po,
  emStrongRDelimAst: jo,
  emStrongRDelimUnd: Mo,
  escape: Dl,
  link: Go,
  nolink: wl,
  punctuation: Lo,
  reflink: $l,
  reflinkSearch: Zo,
  tag: Uo,
  text: Ro,
  url: mt
}, Xo = {
  ...Sn,
  link: R(/^!?\[(label)\]\((.*?)\)/).replace("label", Vt).getRegex(),
  reflink: R(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Vt).getRegex()
}, un = {
  ...Sn,
  escape: R(Dl).replace("])", "~|])").getRegex(),
  url: R(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Yo = {
  ...un,
  br: R(yl).replace("{2,}", "*").getRegex(),
  text: R(un.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Tt = {
  normal: An,
  gfm: xo,
  pedantic: zo
}, ct = {
  normal: Sn,
  gfm: un,
  breaks: Yo,
  pedantic: Xo
};
class Ae {
  constructor(e) {
    O(this, "tokens");
    O(this, "options");
    O(this, "state");
    O(this, "tokenizer");
    O(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Je, this.options.tokenizer = this.options.tokenizer || new Ht(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Tt.normal,
      inline: ct.normal
    };
    this.options.pedantic ? (t.block = Tt.pedantic, t.inline = ct.pedantic) : this.options.gfm && (t.block = Tt.gfm, this.options.breaks ? t.inline = ct.breaks : t.inline = ct.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Tt,
      inline: ct
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Ae(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Ae(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (s, r, u) => r + "    ".repeat(u.length));
    let n, i, a, o;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((s) => (n = s.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startBlock) {
          let s = 1 / 0;
          const r = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((_) => {
            u = _.call({ lexer: this }, r), typeof u == "number" && u >= 0 && (s = Math.min(s, u));
          }), s < 1 / 0 && s >= 0 && (a = e.substring(0, s + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(a))) {
          i = t[t.length - 1], o && i.type === "paragraph" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n), o = a.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (e) {
          const s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, i, a, o = e, s, r, u;
    if (this.tokens.links) {
      const _ = Object.keys(this.tokens.links);
      if (_.length > 0)
        for (; (s = this.tokenizer.rules.inline.reflinkSearch.exec(o)) != null; )
          _.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (o = o.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (s = this.tokenizer.rules.inline.blockSkip.exec(o)) != null; )
      o = o.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (s = this.tokenizer.rules.inline.anyPunctuation.exec(o)) != null; )
      o = o.slice(0, s.index) + "++" + o.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (r || (u = ""), r = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((_) => (n = _.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, o, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startInline) {
          let _ = 1 / 0;
          const d = e.slice(1);
          let c;
          this.options.extensions.startInline.forEach((f) => {
            c = f.call({ lexer: this }, d), typeof c == "number" && c >= 0 && (_ = Math.min(_, c));
          }), _ < 1 / 0 && _ >= 0 && (a = e.substring(0, _ + 1));
        }
        if (n = this.tokenizer.inlineText(a)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), r = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const _ = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(_);
            break;
          } else
            throw new Error(_);
        }
      }
    return t;
  }
}
class Ut {
  constructor(e) {
    O(this, "options");
    this.options = e || Je;
  }
  code(e, t, n) {
    var a;
    const i = (a = (t || "").match(/^\S*/)) == null ? void 0 : a[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + oe(i) + '">' + (n ? e : oe(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : oe(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const i = t ? "ol" : "ul", a = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + i + a + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const i = Nn(e);
    if (i === null)
      return n;
    e = i;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + t + '"'), a += ">" + n + "</a>", a;
  }
  image(e, t, n) {
    const i = Nn(e);
    if (i === null)
      return n;
    e = i;
    let a = `<img src="${e}" alt="${n}"`;
    return t && (a += ` title="${t}"`), a += ">", a;
  }
  text(e) {
    return e;
  }
}
class Bn {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Se {
  constructor(e) {
    O(this, "options");
    O(this, "renderer");
    O(this, "textRenderer");
    this.options = e || Je, this.options.renderer = this.options.renderer || new Ut(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Bn();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Se(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Se(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const a = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const o = a, s = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (s !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(o.type)) {
          n += s || "";
          continue;
        }
      }
      switch (a.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const o = a;
          n += this.renderer.heading(this.parseInline(o.tokens), o.depth, Do(this.parseInline(o.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const o = a;
          n += this.renderer.code(o.text, o.lang, !!o.escaped);
          continue;
        }
        case "table": {
          const o = a;
          let s = "", r = "";
          for (let _ = 0; _ < o.header.length; _++)
            r += this.renderer.tablecell(this.parseInline(o.header[_].tokens), { header: !0, align: o.align[_] });
          s += this.renderer.tablerow(r);
          let u = "";
          for (let _ = 0; _ < o.rows.length; _++) {
            const d = o.rows[_];
            r = "";
            for (let c = 0; c < d.length; c++)
              r += this.renderer.tablecell(this.parseInline(d[c].tokens), { header: !1, align: o.align[c] });
            u += this.renderer.tablerow(r);
          }
          n += this.renderer.table(s, u);
          continue;
        }
        case "blockquote": {
          const o = a, s = this.parse(o.tokens);
          n += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          const o = a, s = o.ordered, r = o.start, u = o.loose;
          let _ = "";
          for (let d = 0; d < o.items.length; d++) {
            const c = o.items[d], f = c.checked, g = c.task;
            let y = "";
            if (c.task) {
              const m = this.renderer.checkbox(!!f);
              u ? c.tokens.length > 0 && c.tokens[0].type === "paragraph" ? (c.tokens[0].text = m + " " + c.tokens[0].text, c.tokens[0].tokens && c.tokens[0].tokens.length > 0 && c.tokens[0].tokens[0].type === "text" && (c.tokens[0].tokens[0].text = m + " " + c.tokens[0].tokens[0].text)) : c.tokens.unshift({
                type: "text",
                text: m + " "
              }) : y += m + " ";
            }
            y += this.parse(c.tokens, u), _ += this.renderer.listitem(y, g, !!f);
          }
          n += this.renderer.list(_, s, r);
          continue;
        }
        case "html": {
          const o = a;
          n += this.renderer.html(o.text, o.block);
          continue;
        }
        case "paragraph": {
          const o = a;
          n += this.renderer.paragraph(this.parseInline(o.tokens));
          continue;
        }
        case "text": {
          let o = a, s = o.tokens ? this.parseInline(o.tokens) : o.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            o = e[++i], s += `
` + (o.tokens ? this.parseInline(o.tokens) : o.text);
          n += t ? this.renderer.paragraph(s) : s;
          continue;
        }
        default: {
          const o = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const a = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const o = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          n += o || "";
          continue;
        }
      }
      switch (a.type) {
        case "escape": {
          const o = a;
          n += t.text(o.text);
          break;
        }
        case "html": {
          const o = a;
          n += t.html(o.text);
          break;
        }
        case "link": {
          const o = a;
          n += t.link(o.href, o.title, this.parseInline(o.tokens, t));
          break;
        }
        case "image": {
          const o = a;
          n += t.image(o.href, o.title, o.text);
          break;
        }
        case "strong": {
          const o = a;
          n += t.strong(this.parseInline(o.tokens, t));
          break;
        }
        case "em": {
          const o = a;
          n += t.em(this.parseInline(o.tokens, t));
          break;
        }
        case "codespan": {
          const o = a;
          n += t.codespan(o.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const o = a;
          n += t.del(this.parseInline(o.tokens, t));
          break;
        }
        case "text": {
          const o = a;
          n += t.text(o.text);
          break;
        }
        default: {
          const o = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return n;
  }
}
class gt {
  constructor(e) {
    O(this, "options");
    this.options = e || Je;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
O(gt, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Qe, _n, Fl;
class Wo {
  constructor(...e) {
    Rn(this, Qe);
    O(this, "defaults", Fn());
    O(this, "options", this.setOptions);
    O(this, "parse", Bt(this, Qe, _n).call(this, Ae.lex, Se.parse));
    O(this, "parseInline", Bt(this, Qe, _n).call(this, Ae.lexInline, Se.parseInline));
    O(this, "Parser", Se);
    O(this, "Renderer", Ut);
    O(this, "TextRenderer", Bn);
    O(this, "Lexer", Ae);
    O(this, "Tokenizer", Ht);
    O(this, "Hooks", gt);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, a;
    let n = [];
    for (const o of e)
      switch (n = n.concat(t.call(this, o)), o.type) {
        case "table": {
          const s = o;
          for (const r of s.header)
            n = n.concat(this.walkTokens(r.tokens, t));
          for (const r of s.rows)
            for (const u of r)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const s = o;
          n = n.concat(this.walkTokens(s.items, t));
          break;
        }
        default: {
          const s = o;
          (a = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && a[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((r) => {
            const u = s[r].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : s.tokens && (n = n.concat(this.walkTokens(s.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const i = { ...n };
      if (i.async = this.defaults.async || i.async || !1, n.extensions && (n.extensions.forEach((a) => {
        if (!a.name)
          throw new Error("extension name required");
        if ("renderer" in a) {
          const o = t.renderers[a.name];
          o ? t.renderers[a.name] = function(...s) {
            let r = a.renderer.apply(this, s);
            return r === !1 && (r = o.apply(this, s)), r;
          } : t.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const o = t[a.level];
          o ? o.unshift(a.tokenizer) : t[a.level] = [a.tokenizer], a.start && (a.level === "block" ? t.startBlock ? t.startBlock.push(a.start) : t.startBlock = [a.start] : a.level === "inline" && (t.startInline ? t.startInline.push(a.start) : t.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (t.childTokens[a.name] = a.childTokens);
      }), i.extensions = t), n.renderer) {
        const a = this.defaults.renderer || new Ut(this.defaults);
        for (const o in n.renderer) {
          if (!(o in a))
            throw new Error(`renderer '${o}' does not exist`);
          if (o === "options")
            continue;
          const s = o, r = n.renderer[s], u = a[s];
          a[s] = (..._) => {
            let d = r.apply(a, _);
            return d === !1 && (d = u.apply(a, _)), d || "";
          };
        }
        i.renderer = a;
      }
      if (n.tokenizer) {
        const a = this.defaults.tokenizer || new Ht(this.defaults);
        for (const o in n.tokenizer) {
          if (!(o in a))
            throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o))
            continue;
          const s = o, r = n.tokenizer[s], u = a[s];
          a[s] = (..._) => {
            let d = r.apply(a, _);
            return d === !1 && (d = u.apply(a, _)), d;
          };
        }
        i.tokenizer = a;
      }
      if (n.hooks) {
        const a = this.defaults.hooks || new gt();
        for (const o in n.hooks) {
          if (!(o in a))
            throw new Error(`hook '${o}' does not exist`);
          if (o === "options")
            continue;
          const s = o, r = n.hooks[s], u = a[s];
          gt.passThroughHooks.has(o) ? a[s] = (_) => {
            if (this.defaults.async)
              return Promise.resolve(r.call(a, _)).then((c) => u.call(a, c));
            const d = r.call(a, _);
            return u.call(a, d);
          } : a[s] = (..._) => {
            let d = r.apply(a, _);
            return d === !1 && (d = u.apply(a, _)), d;
          };
        }
        i.hooks = a;
      }
      if (n.walkTokens) {
        const a = this.defaults.walkTokens, o = n.walkTokens;
        i.walkTokens = function(s) {
          let r = [];
          return r.push(o.call(this, s)), a && (r = r.concat(a.call(this, s))), r;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Ae.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Se.parse(e, t ?? this.defaults);
  }
}
Qe = new WeakSet(), _n = function(e, t) {
  return (n, i) => {
    const a = { ...i }, o = { ...this.defaults, ...a };
    this.defaults.async === !0 && a.async === !1 && (o.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), o.async = !0);
    const s = Bt(this, Qe, Fl).call(this, !!o.silent, !!o.async);
    if (typeof n > "u" || n === null)
      return s(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (o.hooks && (o.hooks.options = o), o.async)
      return Promise.resolve(o.hooks ? o.hooks.preprocess(n) : n).then((r) => e(r, o)).then((r) => o.hooks ? o.hooks.processAllTokens(r) : r).then((r) => o.walkTokens ? Promise.all(this.walkTokens(r, o.walkTokens)).then(() => r) : r).then((r) => t(r, o)).then((r) => o.hooks ? o.hooks.postprocess(r) : r).catch(s);
    try {
      o.hooks && (n = o.hooks.preprocess(n));
      let r = e(n, o);
      o.hooks && (r = o.hooks.processAllTokens(r)), o.walkTokens && this.walkTokens(r, o.walkTokens);
      let u = t(r, o);
      return o.hooks && (u = o.hooks.postprocess(u)), u;
    } catch (r) {
      return s(r);
    }
  };
}, Fl = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + oe(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Ke = new Wo();
function I(l, e) {
  return Ke.parse(l, e);
}
I.options = I.setOptions = function(l) {
  return Ke.setOptions(l), I.defaults = Ke.defaults, fl(I.defaults), I;
};
I.getDefaults = Fn;
I.defaults = Je;
I.use = function(...l) {
  return Ke.use(...l), I.defaults = Ke.defaults, fl(I.defaults), I;
};
I.walkTokens = function(l, e) {
  return Ke.walkTokens(l, e);
};
I.parseInline = Ke.parseInline;
I.Parser = Se;
I.parser = Se.parse;
I.Renderer = Ut;
I.TextRenderer = Bn;
I.Lexer = Ae;
I.lexer = Ae.lex;
I.Tokenizer = Ht;
I.Hooks = gt;
I.parse = I;
I.options;
I.setOptions;
I.use;
I.walkTokens;
I.parseInline;
Se.parse;
Ae.lex;
const Ko = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Qo = Object.hasOwnProperty;
class kl {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let i = Jo(e, t === !0);
    const a = i;
    for (; Qo.call(n.occurrences, i); )
      n.occurrences[a]++, i = a + "-" + n.occurrences[a];
    return n.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Jo(l, e) {
  return typeof l != "string" ? "" : (e || (l = l.toLowerCase()), l.replace(Ko, "").replace(/ /g, "-"));
}
new kl();
var Gn = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, ea = { exports: {} };
(function(l) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, a = 0, o = {}, s = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function p(h) {
          return h instanceof r ? new r(h.type, p(h.content), h.alias) : Array.isArray(h) ? h.map(p) : h.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(p) {
          return Object.prototype.toString.call(p).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(p) {
          return p.__id || Object.defineProperty(p, "__id", { value: ++a }), p.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function p(h, b) {
          b = b || {};
          var v, D;
          switch (s.util.type(h)) {
            case "Object":
              if (D = s.util.objId(h), b[D])
                return b[D];
              v = /** @type {Record<string, any>} */
              {}, b[D] = v;
              for (var w in h)
                h.hasOwnProperty(w) && (v[w] = p(h[w], b));
              return (
                /** @type {any} */
                v
              );
            case "Array":
              return D = s.util.objId(h), b[D] ? b[D] : (v = [], b[D] = v, /** @type {Array} */
              /** @type {any} */
              h.forEach(function(S, k) {
                v[k] = p(S, b);
              }), /** @type {any} */
              v);
            default:
              return h;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(p) {
          for (; p; ) {
            var h = i.exec(p.className);
            if (h)
              return h[1].toLowerCase();
            p = p.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(p, h) {
          p.className = p.className.replace(RegExp(i, "gi"), ""), p.classList.add("language-" + h);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (v) {
            var p = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(v.stack) || [])[1];
            if (p) {
              var h = document.getElementsByTagName("script");
              for (var b in h)
                if (h[b].src == p)
                  return h[b];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(p, h, b) {
          for (var v = "no-" + h; p; ) {
            var D = p.classList;
            if (D.contains(h))
              return !0;
            if (D.contains(v))
              return !1;
            p = p.parentElement;
          }
          return !!b;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: o,
        plaintext: o,
        text: o,
        txt: o,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(p, h) {
          var b = s.util.clone(s.languages[p]);
          for (var v in h)
            b[v] = h[v];
          return b;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(p, h, b, v) {
          v = v || /** @type {any} */
          s.languages;
          var D = v[p], w = {};
          for (var S in D)
            if (D.hasOwnProperty(S)) {
              if (S == h)
                for (var k in b)
                  b.hasOwnProperty(k) && (w[k] = b[k]);
              b.hasOwnProperty(S) || (w[S] = D[S]);
            }
          var q = v[p];
          return v[p] = w, s.languages.DFS(s.languages, function(C, L) {
            L === q && C != p && (this[C] = w);
          }), w;
        },
        // Traverse a language definition with Depth First Search
        DFS: function p(h, b, v, D) {
          D = D || {};
          var w = s.util.objId;
          for (var S in h)
            if (h.hasOwnProperty(S)) {
              b.call(h, S, h[S], v || S);
              var k = h[S], q = s.util.type(k);
              q === "Object" && !D[w(k)] ? (D[w(k)] = !0, p(k, b, null, D)) : q === "Array" && !D[w(k)] && (D[w(k)] = !0, p(k, b, S, D));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(p, h) {
        s.highlightAllUnder(document, p, h);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(p, h, b) {
        var v = {
          callback: b,
          container: p,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        s.hooks.run("before-highlightall", v), v.elements = Array.prototype.slice.apply(v.container.querySelectorAll(v.selector)), s.hooks.run("before-all-elements-highlight", v);
        for (var D = 0, w; w = v.elements[D++]; )
          s.highlightElement(w, h === !0, v.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(p, h, b) {
        var v = s.util.getLanguage(p), D = s.languages[v];
        s.util.setLanguage(p, v);
        var w = p.parentElement;
        w && w.nodeName.toLowerCase() === "pre" && s.util.setLanguage(w, v);
        var S = p.textContent, k = {
          element: p,
          language: v,
          grammar: D,
          code: S
        };
        function q(L) {
          k.highlightedCode = L, s.hooks.run("before-insert", k), k.element.innerHTML = k.highlightedCode, s.hooks.run("after-highlight", k), s.hooks.run("complete", k), b && b.call(k.element);
        }
        if (s.hooks.run("before-sanity-check", k), w = k.element.parentElement, w && w.nodeName.toLowerCase() === "pre" && !w.hasAttribute("tabindex") && w.setAttribute("tabindex", "0"), !k.code) {
          s.hooks.run("complete", k), b && b.call(k.element);
          return;
        }
        if (s.hooks.run("before-highlight", k), !k.grammar) {
          q(s.util.encode(k.code));
          return;
        }
        if (h && n.Worker) {
          var C = new Worker(s.filename);
          C.onmessage = function(L) {
            q(L.data);
          }, C.postMessage(JSON.stringify({
            language: k.language,
            code: k.code,
            immediateClose: !0
          }));
        } else
          q(s.highlight(k.code, k.grammar, k.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(p, h, b) {
        var v = {
          code: p,
          grammar: h,
          language: b
        };
        if (s.hooks.run("before-tokenize", v), !v.grammar)
          throw new Error('The language "' + v.language + '" has no grammar.');
        return v.tokens = s.tokenize(v.code, v.grammar), s.hooks.run("after-tokenize", v), r.stringify(s.util.encode(v.tokens), v.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(p, h) {
        var b = h.rest;
        if (b) {
          for (var v in b)
            h[v] = b[v];
          delete h.rest;
        }
        var D = new d();
        return c(D, D.head, p), _(p, D, h, D.head, 0), g(D);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(p, h) {
          var b = s.hooks.all;
          b[p] = b[p] || [], b[p].push(h);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(p, h) {
          var b = s.hooks.all[p];
          if (!(!b || !b.length))
            for (var v = 0, D; D = b[v++]; )
              D(h);
        }
      },
      Token: r
    };
    n.Prism = s;
    function r(p, h, b, v) {
      this.type = p, this.content = h, this.alias = b, this.length = (v || "").length | 0;
    }
    r.stringify = function p(h, b) {
      if (typeof h == "string")
        return h;
      if (Array.isArray(h)) {
        var v = "";
        return h.forEach(function(q) {
          v += p(q, b);
        }), v;
      }
      var D = {
        type: h.type,
        content: p(h.content, b),
        tag: "span",
        classes: ["token", h.type],
        attributes: {},
        language: b
      }, w = h.alias;
      w && (Array.isArray(w) ? Array.prototype.push.apply(D.classes, w) : D.classes.push(w)), s.hooks.run("wrap", D);
      var S = "";
      for (var k in D.attributes)
        S += " " + k + '="' + (D.attributes[k] || "").replace(/"/g, "&quot;") + '"';
      return "<" + D.tag + ' class="' + D.classes.join(" ") + '"' + S + ">" + D.content + "</" + D.tag + ">";
    };
    function u(p, h, b, v) {
      p.lastIndex = h;
      var D = p.exec(b);
      if (D && v && D[1]) {
        var w = D[1].length;
        D.index += w, D[0] = D[0].slice(w);
      }
      return D;
    }
    function _(p, h, b, v, D, w) {
      for (var S in b)
        if (!(!b.hasOwnProperty(S) || !b[S])) {
          var k = b[S];
          k = Array.isArray(k) ? k : [k];
          for (var q = 0; q < k.length; ++q) {
            if (w && w.cause == S + "," + q)
              return;
            var C = k[q], L = C.inside, Ue = !!C.lookbehind, ne = !!C.greedy, Fe = C.alias;
            if (ne && !C.pattern.global) {
              var te = C.pattern.toString().match(/[imsuy]*$/)[0];
              C.pattern = RegExp(C.pattern.source, te + "g");
            }
            for (var je = C.pattern || C, N = v.next, Q = D; N !== h.tail && !(w && Q >= w.reach); Q += N.value.length, N = N.next) {
              var pe = N.value;
              if (h.length > p.length)
                return;
              if (!(pe instanceof r)) {
                var F = 1, G;
                if (ne) {
                  if (G = u(je, Q, p, Ue), !G || G.index >= p.length)
                    break;
                  var tt = G.index, et = G.index + G[0].length, ie = Q;
                  for (ie += N.value.length; tt >= ie; )
                    N = N.next, ie += N.value.length;
                  if (ie -= N.value.length, Q = ie, N.value instanceof r)
                    continue;
                  for (var E = N; E !== h.tail && (ie < et || typeof E.value == "string"); E = E.next)
                    F++, ie += E.value.length;
                  F--, pe = p.slice(Q, ie), G.index -= Q;
                } else if (G = u(je, 0, pe, Ue), !G)
                  continue;
                var tt = G.index, At = G[0], Kt = pe.slice(0, tt), zn = pe.slice(tt + At.length), Qt = Q + pe.length;
                w && Qt > w.reach && (w.reach = Qt);
                var St = N.prev;
                Kt && (St = c(h, St, Kt), Q += Kt.length), f(h, St, F);
                var Yl = new r(S, L ? s.tokenize(At, L) : At, Fe, At);
                if (N = c(h, St, Yl), zn && c(h, N, zn), F > 1) {
                  var Jt = {
                    cause: S + "," + q,
                    reach: Qt
                  };
                  _(p, h, b, N.prev, Q, Jt), w && Jt.reach > w.reach && (w.reach = Jt.reach);
                }
              }
            }
          }
        }
    }
    function d() {
      var p = { value: null, prev: null, next: null }, h = { value: null, prev: p, next: null };
      p.next = h, this.head = p, this.tail = h, this.length = 0;
    }
    function c(p, h, b) {
      var v = h.next, D = { value: b, prev: h, next: v };
      return h.next = D, v.prev = D, p.length++, D;
    }
    function f(p, h, b) {
      for (var v = h.next, D = 0; D < b && v !== p.tail; D++)
        v = v.next;
      h.next = v, v.prev = h, p.length -= D;
    }
    function g(p) {
      for (var h = [], b = p.head.next; b !== p.tail; )
        h.push(b.value), b = b.next;
      return h;
    }
    if (!n.document)
      return n.addEventListener && (s.disableWorkerMessageHandler || n.addEventListener("message", function(p) {
        var h = JSON.parse(p.data), b = h.language, v = h.code, D = h.immediateClose;
        n.postMessage(s.highlight(v, s.languages[b], b)), D && n.close();
      }, !1)), s;
    var y = s.util.currentScript();
    y && (s.filename = y.src, y.hasAttribute("data-manual") && (s.manual = !0));
    function m() {
      s.manual || s.highlightAll();
    }
    if (!s.manual) {
      var $ = document.readyState;
      $ === "loading" || $ === "interactive" && y && y.defer ? document.addEventListener("DOMContentLoaded", m) : window.requestAnimationFrame ? window.requestAnimationFrame(m) : window.setTimeout(m, 16);
    }
    return s;
  }(e);
  l.exports && (l.exports = t), typeof Gn < "u" && (Gn.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, a) {
      var o = {};
      o["language-" + a] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[a]
      }, o.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var s = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: o
        }
      };
      s["language-" + a] = {
        pattern: /[\s\S]+/,
        inside: t.languages[a]
      };
      var r = {};
      r[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: s
      }, t.languages.insertBefore("markup", "cdata", r);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var a = n.languages.markup;
    a && (a.tag.addInlined("style", "css"), a.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", i = function(y, m) {
      return "✖ Error " + y + " while fetching file: " + m;
    }, a = "✖ Error: File does not exist or is empty", o = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, s = "data-src-status", r = "loading", u = "loaded", _ = "failed", d = "pre[data-src]:not([" + s + '="' + u + '"]):not([' + s + '="' + r + '"])';
    function c(y, m, $) {
      var p = new XMLHttpRequest();
      p.open("GET", y, !0), p.onreadystatechange = function() {
        p.readyState == 4 && (p.status < 400 && p.responseText ? m(p.responseText) : p.status >= 400 ? $(i(p.status, p.statusText)) : $(a));
      }, p.send(null);
    }
    function f(y) {
      var m = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(y || "");
      if (m) {
        var $ = Number(m[1]), p = m[2], h = m[3];
        return p ? h ? [$, Number(h)] : [$, void 0] : [$, $];
      }
    }
    t.hooks.add("before-highlightall", function(y) {
      y.selector += ", " + d;
    }), t.hooks.add("before-sanity-check", function(y) {
      var m = (
        /** @type {HTMLPreElement} */
        y.element
      );
      if (m.matches(d)) {
        y.code = "", m.setAttribute(s, r);
        var $ = m.appendChild(document.createElement("CODE"));
        $.textContent = n;
        var p = m.getAttribute("data-src"), h = y.language;
        if (h === "none") {
          var b = (/\.(\w+)$/.exec(p) || [, "none"])[1];
          h = o[b] || b;
        }
        t.util.setLanguage($, h), t.util.setLanguage(m, h);
        var v = t.plugins.autoloader;
        v && v.loadLanguages(h), c(
          p,
          function(D) {
            m.setAttribute(s, u);
            var w = f(m.getAttribute("data-range"));
            if (w) {
              var S = D.split(/\r\n?|\n/g), k = w[0], q = w[1] == null ? S.length : w[1];
              k < 0 && (k += S.length), k = Math.max(0, Math.min(k - 1, S.length)), q < 0 && (q += S.length), q = Math.max(0, Math.min(q, S.length)), D = S.slice(k, q).join(`
`), m.hasAttribute("data-start") || m.setAttribute("data-start", String(k + 1));
            }
            $.textContent = D, t.highlightElement($);
          },
          function(D) {
            m.setAttribute(s, _), $.textContent = D;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(m) {
        for (var $ = (m || document).querySelectorAll(d), p = 0, h; h = $[p++]; )
          t.highlightElement(h);
      }
    };
    var g = !1;
    t.fileHighlight = function() {
      g || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), g = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(ea);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(l) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  l.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, l.languages.tex = l.languages.latex, l.languages.context = l.languages.latex;
})(Prism);
(function(l) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  l.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = l.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], a = n.variable[1].inside, o = 0; o < i.length; o++)
    a[i[o]] = l.languages.bash[i[o]];
  l.languages.sh = l.languages.bash, l.languages.shell = l.languages.bash;
})(Prism);
new kl();
const ta = (l) => {
  const e = {};
  for (let t = 0, n = l.length; t < n; t++) {
    const i = l[t];
    for (const a in i)
      e[a] ? e[a] = e[a].concat(i[a]) : e[a] = i[a];
  }
  return e;
}, na = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], ia = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], la = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
ta([
  Object.fromEntries(na.map((l) => [l, ["*"]])),
  Object.fromEntries(ia.map((l) => [l, ["svg:*"]])),
  Object.fromEntries(la.map((l) => [l, ["math:*"]]))
]);
const {
  HtmlTagHydration: As,
  SvelteComponent: Ss,
  attr: Bs,
  binding_callbacks: qs,
  children: Ts,
  claim_element: xs,
  claim_html_tag: zs,
  detach: Is,
  element: Rs,
  init: Ls,
  insert_hydration: Os,
  noop: Ps,
  safe_not_equal: js,
  toggle_class: Ms
} = window.__gradio__svelte__internal, { afterUpdate: Ns, tick: Hs, onMount: Vs } = window.__gradio__svelte__internal, {
  SvelteComponent: Us,
  attr: Gs,
  children: Zs,
  claim_component: Xs,
  claim_element: Ys,
  create_component: Ws,
  destroy_component: Ks,
  detach: Qs,
  element: Js,
  init: eu,
  insert_hydration: tu,
  mount_component: nu,
  safe_not_equal: iu,
  transition_in: lu,
  transition_out: ou
} = window.__gradio__svelte__internal, {
  SvelteComponent: au,
  attr: ru,
  check_outros: su,
  children: uu,
  claim_component: _u,
  claim_element: cu,
  claim_space: du,
  create_component: hu,
  create_slot: fu,
  destroy_component: pu,
  detach: mu,
  element: gu,
  empty: vu,
  get_all_dirty_from_scope: bu,
  get_slot_changes: Du,
  group_outros: yu,
  init: $u,
  insert_hydration: wu,
  mount_component: Fu,
  safe_not_equal: ku,
  space: Cu,
  toggle_class: Eu,
  transition_in: Au,
  transition_out: Su,
  update_slot_base: Bu
} = window.__gradio__svelte__internal, {
  SvelteComponent: qu,
  append_hydration: Tu,
  attr: xu,
  children: zu,
  claim_component: Iu,
  claim_element: Ru,
  claim_space: Lu,
  claim_text: Ou,
  create_component: Pu,
  destroy_component: ju,
  detach: Mu,
  element: Nu,
  init: Hu,
  insert_hydration: Vu,
  mount_component: Uu,
  safe_not_equal: Gu,
  set_data: Zu,
  space: Xu,
  text: Yu,
  toggle_class: Wu,
  transition_in: Ku,
  transition_out: Qu
} = window.__gradio__svelte__internal, {
  SvelteComponent: oa,
  append_hydration: Mt,
  attr: ze,
  bubble: aa,
  check_outros: ra,
  children: cn,
  claim_component: sa,
  claim_element: dn,
  claim_space: Zn,
  claim_text: ua,
  construct_svelte_component: Xn,
  create_component: Yn,
  create_slot: _a,
  destroy_component: Wn,
  detach: vt,
  element: hn,
  get_all_dirty_from_scope: ca,
  get_slot_changes: da,
  group_outros: ha,
  init: fa,
  insert_hydration: Cl,
  listen: pa,
  mount_component: Kn,
  safe_not_equal: ma,
  set_data: ga,
  set_style: xt,
  space: Qn,
  text: va,
  toggle_class: Z,
  transition_in: nn,
  transition_out: ln,
  update_slot_base: ba
} = window.__gradio__svelte__internal;
function Jn(l) {
  let e, t;
  return {
    c() {
      e = hn("span"), t = va(
        /*label*/
        l[1]
      ), this.h();
    },
    l(n) {
      e = dn(n, "SPAN", { class: !0 });
      var i = cn(e);
      t = ua(
        i,
        /*label*/
        l[1]
      ), i.forEach(vt), this.h();
    },
    h() {
      ze(e, "class", "svelte-qgco6m");
    },
    m(n, i) {
      Cl(n, e, i), Mt(e, t);
    },
    p(n, i) {
      i & /*label*/
      2 && ga(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && vt(e);
    }
  };
}
function Da(l) {
  let e, t, n, i, a, o, s, r, u = (
    /*show_label*/
    l[2] && Jn(l)
  );
  var _ = (
    /*Icon*/
    l[0]
  );
  function d(g, y) {
    return {};
  }
  _ && (i = Xn(_, d()));
  const c = (
    /*#slots*/
    l[14].default
  ), f = _a(
    c,
    l,
    /*$$scope*/
    l[13],
    null
  );
  return {
    c() {
      e = hn("button"), u && u.c(), t = Qn(), n = hn("div"), i && Yn(i.$$.fragment), a = Qn(), f && f.c(), this.h();
    },
    l(g) {
      e = dn(g, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var y = cn(e);
      u && u.l(y), t = Zn(y), n = dn(y, "DIV", { class: !0 });
      var m = cn(n);
      i && sa(i.$$.fragment, m), a = Zn(m), f && f.l(m), m.forEach(vt), y.forEach(vt), this.h();
    },
    h() {
      ze(n, "class", "svelte-qgco6m"), Z(
        n,
        "x-small",
        /*size*/
        l[4] === "x-small"
      ), Z(
        n,
        "small",
        /*size*/
        l[4] === "small"
      ), Z(
        n,
        "large",
        /*size*/
        l[4] === "large"
      ), Z(
        n,
        "medium",
        /*size*/
        l[4] === "medium"
      ), e.disabled = /*disabled*/
      l[7], ze(
        e,
        "aria-label",
        /*label*/
        l[1]
      ), ze(
        e,
        "aria-haspopup",
        /*hasPopup*/
        l[8]
      ), ze(
        e,
        "title",
        /*label*/
        l[1]
      ), ze(e, "class", "svelte-qgco6m"), Z(
        e,
        "pending",
        /*pending*/
        l[3]
      ), Z(
        e,
        "padded",
        /*padded*/
        l[5]
      ), Z(
        e,
        "highlight",
        /*highlight*/
        l[6]
      ), Z(
        e,
        "transparent",
        /*transparent*/
        l[9]
      ), xt(e, "color", !/*disabled*/
      l[7] && /*_color*/
      l[11] ? (
        /*_color*/
        l[11]
      ) : "var(--block-label-text-color)"), xt(e, "--bg-color", /*disabled*/
      l[7] ? "auto" : (
        /*background*/
        l[10]
      ));
    },
    m(g, y) {
      Cl(g, e, y), u && u.m(e, null), Mt(e, t), Mt(e, n), i && Kn(i, n, null), Mt(n, a), f && f.m(n, null), o = !0, s || (r = pa(
        e,
        "click",
        /*click_handler*/
        l[15]
      ), s = !0);
    },
    p(g, [y]) {
      if (/*show_label*/
      g[2] ? u ? u.p(g, y) : (u = Jn(g), u.c(), u.m(e, t)) : u && (u.d(1), u = null), y & /*Icon*/
      1 && _ !== (_ = /*Icon*/
      g[0])) {
        if (i) {
          ha();
          const m = i;
          ln(m.$$.fragment, 1, 0, () => {
            Wn(m, 1);
          }), ra();
        }
        _ ? (i = Xn(_, d()), Yn(i.$$.fragment), nn(i.$$.fragment, 1), Kn(i, n, a)) : i = null;
      }
      f && f.p && (!o || y & /*$$scope*/
      8192) && ba(
        f,
        c,
        g,
        /*$$scope*/
        g[13],
        o ? da(
          c,
          /*$$scope*/
          g[13],
          y,
          null
        ) : ca(
          /*$$scope*/
          g[13]
        ),
        null
      ), (!o || y & /*size*/
      16) && Z(
        n,
        "x-small",
        /*size*/
        g[4] === "x-small"
      ), (!o || y & /*size*/
      16) && Z(
        n,
        "small",
        /*size*/
        g[4] === "small"
      ), (!o || y & /*size*/
      16) && Z(
        n,
        "large",
        /*size*/
        g[4] === "large"
      ), (!o || y & /*size*/
      16) && Z(
        n,
        "medium",
        /*size*/
        g[4] === "medium"
      ), (!o || y & /*disabled*/
      128) && (e.disabled = /*disabled*/
      g[7]), (!o || y & /*label*/
      2) && ze(
        e,
        "aria-label",
        /*label*/
        g[1]
      ), (!o || y & /*hasPopup*/
      256) && ze(
        e,
        "aria-haspopup",
        /*hasPopup*/
        g[8]
      ), (!o || y & /*label*/
      2) && ze(
        e,
        "title",
        /*label*/
        g[1]
      ), (!o || y & /*pending*/
      8) && Z(
        e,
        "pending",
        /*pending*/
        g[3]
      ), (!o || y & /*padded*/
      32) && Z(
        e,
        "padded",
        /*padded*/
        g[5]
      ), (!o || y & /*highlight*/
      64) && Z(
        e,
        "highlight",
        /*highlight*/
        g[6]
      ), (!o || y & /*transparent*/
      512) && Z(
        e,
        "transparent",
        /*transparent*/
        g[9]
      ), y & /*disabled, _color*/
      2176 && xt(e, "color", !/*disabled*/
      g[7] && /*_color*/
      g[11] ? (
        /*_color*/
        g[11]
      ) : "var(--block-label-text-color)"), y & /*disabled, background*/
      1152 && xt(e, "--bg-color", /*disabled*/
      g[7] ? "auto" : (
        /*background*/
        g[10]
      ));
    },
    i(g) {
      o || (i && nn(i.$$.fragment, g), nn(f, g), o = !0);
    },
    o(g) {
      i && ln(i.$$.fragment, g), ln(f, g), o = !1;
    },
    d(g) {
      g && vt(e), u && u.d(), i && Wn(i), f && f.d(g), s = !1, r();
    }
  };
}
function ya(l, e, t) {
  let n, { $$slots: i = {}, $$scope: a } = e, { Icon: o } = e, { label: s = "" } = e, { show_label: r = !1 } = e, { pending: u = !1 } = e, { size: _ = "small" } = e, { padded: d = !0 } = e, { highlight: c = !1 } = e, { disabled: f = !1 } = e, { hasPopup: g = !1 } = e, { color: y = "var(--block-label-text-color)" } = e, { transparent: m = !1 } = e, { background: $ = "var(--block-background-fill)" } = e;
  function p(h) {
    aa.call(this, l, h);
  }
  return l.$$set = (h) => {
    "Icon" in h && t(0, o = h.Icon), "label" in h && t(1, s = h.label), "show_label" in h && t(2, r = h.show_label), "pending" in h && t(3, u = h.pending), "size" in h && t(4, _ = h.size), "padded" in h && t(5, d = h.padded), "highlight" in h && t(6, c = h.highlight), "disabled" in h && t(7, f = h.disabled), "hasPopup" in h && t(8, g = h.hasPopup), "color" in h && t(12, y = h.color), "transparent" in h && t(9, m = h.transparent), "background" in h && t(10, $ = h.background), "$$scope" in h && t(13, a = h.$$scope);
  }, l.$$.update = () => {
    l.$$.dirty & /*highlight, color*/
    4160 && t(11, n = c ? "var(--color-accent)" : y);
  }, [
    o,
    s,
    r,
    u,
    _,
    d,
    c,
    f,
    g,
    m,
    $,
    n,
    y,
    a,
    i,
    p
  ];
}
class $a extends oa {
  constructor(e) {
    super(), fa(this, e, ya, Da, ma, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Ju,
  append_hydration: e_,
  attr: t_,
  binding_callbacks: n_,
  children: i_,
  claim_element: l_,
  create_slot: o_,
  detach: a_,
  element: r_,
  get_all_dirty_from_scope: s_,
  get_slot_changes: u_,
  init: __,
  insert_hydration: c_,
  safe_not_equal: d_,
  toggle_class: h_,
  transition_in: f_,
  transition_out: p_,
  update_slot_base: m_
} = window.__gradio__svelte__internal, {
  SvelteComponent: g_,
  append_hydration: v_,
  attr: b_,
  children: D_,
  claim_svg_element: y_,
  detach: $_,
  init: w_,
  insert_hydration: F_,
  noop: k_,
  safe_not_equal: C_,
  svg_element: E_
} = window.__gradio__svelte__internal, {
  SvelteComponent: A_,
  append_hydration: S_,
  attr: B_,
  children: q_,
  claim_svg_element: T_,
  detach: x_,
  init: z_,
  insert_hydration: I_,
  noop: R_,
  safe_not_equal: L_,
  svg_element: O_
} = window.__gradio__svelte__internal, {
  SvelteComponent: P_,
  append_hydration: j_,
  attr: M_,
  children: N_,
  claim_svg_element: H_,
  detach: V_,
  init: U_,
  insert_hydration: G_,
  noop: Z_,
  safe_not_equal: X_,
  svg_element: Y_
} = window.__gradio__svelte__internal, {
  SvelteComponent: W_,
  append_hydration: K_,
  attr: Q_,
  children: J_,
  claim_svg_element: ec,
  detach: tc,
  init: nc,
  insert_hydration: ic,
  noop: lc,
  safe_not_equal: oc,
  svg_element: ac
} = window.__gradio__svelte__internal, {
  SvelteComponent: rc,
  append_hydration: sc,
  attr: uc,
  children: _c,
  claim_svg_element: cc,
  detach: dc,
  init: hc,
  insert_hydration: fc,
  noop: pc,
  safe_not_equal: mc,
  svg_element: gc
} = window.__gradio__svelte__internal, {
  SvelteComponent: vc,
  append_hydration: bc,
  attr: Dc,
  children: yc,
  claim_svg_element: $c,
  detach: wc,
  init: Fc,
  insert_hydration: kc,
  noop: Cc,
  safe_not_equal: Ec,
  svg_element: Ac
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sc,
  append_hydration: Bc,
  attr: qc,
  children: Tc,
  claim_svg_element: xc,
  detach: zc,
  init: Ic,
  insert_hydration: Rc,
  noop: Lc,
  safe_not_equal: Oc,
  svg_element: Pc
} = window.__gradio__svelte__internal, {
  SvelteComponent: jc,
  append_hydration: Mc,
  attr: Nc,
  children: Hc,
  claim_svg_element: Vc,
  detach: Uc,
  init: Gc,
  insert_hydration: Zc,
  noop: Xc,
  safe_not_equal: Yc,
  svg_element: Wc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kc,
  append_hydration: Qc,
  attr: Jc,
  children: ed,
  claim_svg_element: td,
  detach: nd,
  init: id,
  insert_hydration: ld,
  noop: od,
  safe_not_equal: ad,
  svg_element: rd
} = window.__gradio__svelte__internal, {
  SvelteComponent: sd,
  append_hydration: ud,
  attr: _d,
  children: cd,
  claim_svg_element: dd,
  detach: hd,
  init: fd,
  insert_hydration: pd,
  noop: md,
  safe_not_equal: gd,
  svg_element: vd
} = window.__gradio__svelte__internal, {
  SvelteComponent: bd,
  append_hydration: Dd,
  attr: yd,
  children: $d,
  claim_svg_element: wd,
  detach: Fd,
  init: kd,
  insert_hydration: Cd,
  noop: Ed,
  safe_not_equal: Ad,
  svg_element: Sd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bd,
  append_hydration: qd,
  attr: Td,
  children: xd,
  claim_svg_element: zd,
  detach: Id,
  init: Rd,
  insert_hydration: Ld,
  noop: Od,
  safe_not_equal: Pd,
  svg_element: jd
} = window.__gradio__svelte__internal, {
  SvelteComponent: wa,
  append_hydration: on,
  attr: me,
  children: zt,
  claim_svg_element: It,
  detach: dt,
  init: Fa,
  insert_hydration: ka,
  noop: an,
  safe_not_equal: Ca,
  set_style: ke,
  svg_element: Rt
} = window.__gradio__svelte__internal;
function Ea(l) {
  let e, t, n, i;
  return {
    c() {
      e = Rt("svg"), t = Rt("g"), n = Rt("path"), i = Rt("path"), this.h();
    },
    l(a) {
      e = It(a, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var o = zt(e);
      t = It(o, "g", { transform: !0 });
      var s = zt(t);
      n = It(s, "path", { d: !0, style: !0 }), zt(n).forEach(dt), s.forEach(dt), i = It(o, "path", { d: !0, style: !0 }), zt(i).forEach(dt), o.forEach(dt), this.h();
    },
    h() {
      me(n, "d", "M18,6L6.087,17.913"), ke(n, "fill", "none"), ke(n, "fill-rule", "nonzero"), ke(n, "stroke-width", "2px"), me(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), me(i, "d", "M4.364,4.364L19.636,19.636"), ke(i, "fill", "none"), ke(i, "fill-rule", "nonzero"), ke(i, "stroke-width", "2px"), me(e, "width", "100%"), me(e, "height", "100%"), me(e, "viewBox", "0 0 24 24"), me(e, "version", "1.1"), me(e, "xmlns", "http://www.w3.org/2000/svg"), me(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), me(e, "xml:space", "preserve"), me(e, "stroke", "currentColor"), ke(e, "fill-rule", "evenodd"), ke(e, "clip-rule", "evenodd"), ke(e, "stroke-linecap", "round"), ke(e, "stroke-linejoin", "round");
    },
    m(a, o) {
      ka(a, e, o), on(e, t), on(t, n), on(e, i);
    },
    p: an,
    i: an,
    o: an,
    d(a) {
      a && dt(e);
    }
  };
}
class Aa extends wa {
  constructor(e) {
    super(), Fa(this, e, null, Ea, Ca, {});
  }
}
const {
  SvelteComponent: Md,
  append_hydration: Nd,
  attr: Hd,
  children: Vd,
  claim_svg_element: Ud,
  detach: Gd,
  init: Zd,
  insert_hydration: Xd,
  noop: Yd,
  safe_not_equal: Wd,
  svg_element: Kd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qd,
  append_hydration: Jd,
  attr: eh,
  children: th,
  claim_svg_element: nh,
  detach: ih,
  init: lh,
  insert_hydration: oh,
  noop: ah,
  safe_not_equal: rh,
  svg_element: sh
} = window.__gradio__svelte__internal, {
  SvelteComponent: uh,
  append_hydration: _h,
  attr: ch,
  children: dh,
  claim_svg_element: hh,
  detach: fh,
  init: ph,
  insert_hydration: mh,
  noop: gh,
  safe_not_equal: vh,
  svg_element: bh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dh,
  append_hydration: yh,
  attr: $h,
  children: wh,
  claim_svg_element: Fh,
  detach: kh,
  init: Ch,
  insert_hydration: Eh,
  noop: Ah,
  safe_not_equal: Sh,
  svg_element: Bh
} = window.__gradio__svelte__internal, {
  SvelteComponent: qh,
  append_hydration: Th,
  attr: xh,
  children: zh,
  claim_svg_element: Ih,
  detach: Rh,
  init: Lh,
  insert_hydration: Oh,
  noop: Ph,
  safe_not_equal: jh,
  svg_element: Mh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nh,
  append_hydration: Hh,
  attr: Vh,
  children: Uh,
  claim_svg_element: Gh,
  detach: Zh,
  init: Xh,
  insert_hydration: Yh,
  noop: Wh,
  safe_not_equal: Kh,
  svg_element: Qh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jh,
  append_hydration: ef,
  attr: tf,
  children: nf,
  claim_svg_element: lf,
  detach: of,
  init: af,
  insert_hydration: rf,
  noop: sf,
  safe_not_equal: uf,
  svg_element: _f
} = window.__gradio__svelte__internal, {
  SvelteComponent: cf,
  append_hydration: df,
  attr: hf,
  children: ff,
  claim_svg_element: pf,
  detach: mf,
  init: gf,
  insert_hydration: vf,
  noop: bf,
  safe_not_equal: Df,
  svg_element: yf
} = window.__gradio__svelte__internal, {
  SvelteComponent: $f,
  append_hydration: wf,
  attr: Ff,
  children: kf,
  claim_svg_element: Cf,
  detach: Ef,
  init: Af,
  insert_hydration: Sf,
  noop: Bf,
  safe_not_equal: qf,
  svg_element: Tf
} = window.__gradio__svelte__internal, {
  SvelteComponent: xf,
  append_hydration: zf,
  attr: If,
  children: Rf,
  claim_svg_element: Lf,
  detach: Of,
  init: Pf,
  insert_hydration: jf,
  noop: Mf,
  safe_not_equal: Nf,
  svg_element: Hf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vf,
  append_hydration: Uf,
  attr: Gf,
  children: Zf,
  claim_svg_element: Xf,
  detach: Yf,
  init: Wf,
  insert_hydration: Kf,
  noop: Qf,
  safe_not_equal: Jf,
  svg_element: ep
} = window.__gradio__svelte__internal, {
  SvelteComponent: tp,
  append_hydration: np,
  attr: ip,
  children: lp,
  claim_svg_element: op,
  detach: ap,
  init: rp,
  insert_hydration: sp,
  noop: up,
  safe_not_equal: _p,
  svg_element: cp
} = window.__gradio__svelte__internal, {
  SvelteComponent: dp,
  append_hydration: hp,
  attr: fp,
  children: pp,
  claim_svg_element: mp,
  detach: gp,
  init: vp,
  insert_hydration: bp,
  noop: Dp,
  safe_not_equal: yp,
  svg_element: $p
} = window.__gradio__svelte__internal, {
  SvelteComponent: wp,
  append_hydration: Fp,
  attr: kp,
  children: Cp,
  claim_svg_element: Ep,
  detach: Ap,
  init: Sp,
  insert_hydration: Bp,
  noop: qp,
  safe_not_equal: Tp,
  svg_element: xp
} = window.__gradio__svelte__internal, {
  SvelteComponent: zp,
  append_hydration: Ip,
  attr: Rp,
  children: Lp,
  claim_svg_element: Op,
  detach: Pp,
  init: jp,
  insert_hydration: Mp,
  noop: Np,
  safe_not_equal: Hp,
  svg_element: Vp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Up,
  append_hydration: Gp,
  attr: Zp,
  children: Xp,
  claim_svg_element: Yp,
  detach: Wp,
  init: Kp,
  insert_hydration: Qp,
  noop: Jp,
  safe_not_equal: em,
  svg_element: tm
} = window.__gradio__svelte__internal, {
  SvelteComponent: nm,
  append_hydration: im,
  attr: lm,
  children: om,
  claim_svg_element: am,
  detach: rm,
  init: sm,
  insert_hydration: um,
  noop: _m,
  safe_not_equal: cm,
  svg_element: dm
} = window.__gradio__svelte__internal, {
  SvelteComponent: hm,
  append_hydration: fm,
  attr: pm,
  children: mm,
  claim_svg_element: gm,
  detach: vm,
  init: bm,
  insert_hydration: Dm,
  noop: ym,
  safe_not_equal: $m,
  svg_element: wm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fm,
  append_hydration: km,
  attr: Cm,
  children: Em,
  claim_svg_element: Am,
  detach: Sm,
  init: Bm,
  insert_hydration: qm,
  noop: Tm,
  safe_not_equal: xm,
  svg_element: zm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Im,
  append_hydration: Rm,
  attr: Lm,
  children: Om,
  claim_svg_element: Pm,
  detach: jm,
  init: Mm,
  insert_hydration: Nm,
  noop: Hm,
  safe_not_equal: Vm,
  svg_element: Um
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gm,
  append_hydration: Zm,
  attr: Xm,
  children: Ym,
  claim_svg_element: Wm,
  detach: Km,
  init: Qm,
  insert_hydration: Jm,
  noop: eg,
  safe_not_equal: tg,
  svg_element: ng
} = window.__gradio__svelte__internal, {
  SvelteComponent: ig,
  append_hydration: lg,
  attr: og,
  children: ag,
  claim_svg_element: rg,
  detach: sg,
  init: ug,
  insert_hydration: _g,
  noop: cg,
  safe_not_equal: dg,
  svg_element: hg
} = window.__gradio__svelte__internal, {
  SvelteComponent: fg,
  append_hydration: pg,
  attr: mg,
  children: gg,
  claim_svg_element: vg,
  detach: bg,
  init: Dg,
  insert_hydration: yg,
  noop: $g,
  safe_not_equal: wg,
  svg_element: Fg
} = window.__gradio__svelte__internal, {
  SvelteComponent: kg,
  append_hydration: Cg,
  attr: Eg,
  children: Ag,
  claim_svg_element: Sg,
  detach: Bg,
  init: qg,
  insert_hydration: Tg,
  noop: xg,
  safe_not_equal: zg,
  svg_element: Ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rg,
  append_hydration: Lg,
  attr: Og,
  children: Pg,
  claim_svg_element: jg,
  detach: Mg,
  init: Ng,
  insert_hydration: Hg,
  noop: Vg,
  safe_not_equal: Ug,
  svg_element: Gg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zg,
  append_hydration: Xg,
  attr: Yg,
  children: Wg,
  claim_svg_element: Kg,
  detach: Qg,
  init: Jg,
  insert_hydration: e0,
  noop: t0,
  safe_not_equal: n0,
  svg_element: i0
} = window.__gradio__svelte__internal, {
  SvelteComponent: l0,
  append_hydration: o0,
  attr: a0,
  children: r0,
  claim_svg_element: s0,
  detach: u0,
  init: _0,
  insert_hydration: c0,
  noop: d0,
  safe_not_equal: h0,
  svg_element: f0
} = window.__gradio__svelte__internal, {
  SvelteComponent: p0,
  append_hydration: m0,
  attr: g0,
  children: v0,
  claim_svg_element: b0,
  detach: D0,
  init: y0,
  insert_hydration: $0,
  noop: w0,
  safe_not_equal: F0,
  svg_element: k0
} = window.__gradio__svelte__internal, {
  SvelteComponent: C0,
  append_hydration: E0,
  attr: A0,
  children: S0,
  claim_svg_element: B0,
  detach: q0,
  init: T0,
  insert_hydration: x0,
  noop: z0,
  safe_not_equal: I0,
  svg_element: R0
} = window.__gradio__svelte__internal, {
  SvelteComponent: L0,
  append_hydration: O0,
  attr: P0,
  children: j0,
  claim_svg_element: M0,
  detach: N0,
  init: H0,
  insert_hydration: V0,
  noop: U0,
  safe_not_equal: G0,
  svg_element: Z0
} = window.__gradio__svelte__internal, {
  SvelteComponent: X0,
  append_hydration: Y0,
  attr: W0,
  children: K0,
  claim_svg_element: Q0,
  detach: J0,
  init: e1,
  insert_hydration: t1,
  noop: n1,
  safe_not_equal: i1,
  svg_element: l1
} = window.__gradio__svelte__internal, {
  SvelteComponent: o1,
  append_hydration: a1,
  attr: r1,
  children: s1,
  claim_svg_element: u1,
  detach: _1,
  init: c1,
  insert_hydration: d1,
  noop: h1,
  safe_not_equal: f1,
  svg_element: p1
} = window.__gradio__svelte__internal, {
  SvelteComponent: m1,
  append_hydration: g1,
  attr: v1,
  children: b1,
  claim_svg_element: D1,
  detach: y1,
  init: $1,
  insert_hydration: w1,
  noop: F1,
  safe_not_equal: k1,
  svg_element: C1
} = window.__gradio__svelte__internal, {
  SvelteComponent: E1,
  append_hydration: A1,
  attr: S1,
  children: B1,
  claim_svg_element: q1,
  detach: T1,
  init: x1,
  insert_hydration: z1,
  noop: I1,
  safe_not_equal: R1,
  set_style: L1,
  svg_element: O1
} = window.__gradio__svelte__internal, {
  SvelteComponent: P1,
  append_hydration: j1,
  attr: M1,
  children: N1,
  claim_svg_element: H1,
  detach: V1,
  init: U1,
  insert_hydration: G1,
  noop: Z1,
  safe_not_equal: X1,
  svg_element: Y1
} = window.__gradio__svelte__internal, {
  SvelteComponent: W1,
  append_hydration: K1,
  attr: Q1,
  children: J1,
  claim_svg_element: ev,
  detach: tv,
  init: nv,
  insert_hydration: iv,
  noop: lv,
  safe_not_equal: ov,
  svg_element: av
} = window.__gradio__svelte__internal, {
  SvelteComponent: rv,
  append_hydration: sv,
  attr: uv,
  children: _v,
  claim_svg_element: cv,
  detach: dv,
  init: hv,
  insert_hydration: fv,
  noop: pv,
  safe_not_equal: mv,
  svg_element: gv
} = window.__gradio__svelte__internal, {
  SvelteComponent: vv,
  append_hydration: bv,
  attr: Dv,
  children: yv,
  claim_svg_element: $v,
  detach: wv,
  init: Fv,
  insert_hydration: kv,
  noop: Cv,
  safe_not_equal: Ev,
  svg_element: Av
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sv,
  append_hydration: Bv,
  attr: qv,
  children: Tv,
  claim_svg_element: xv,
  detach: zv,
  init: Iv,
  insert_hydration: Rv,
  noop: Lv,
  safe_not_equal: Ov,
  svg_element: Pv
} = window.__gradio__svelte__internal, {
  SvelteComponent: jv,
  append_hydration: Mv,
  attr: Nv,
  children: Hv,
  claim_svg_element: Vv,
  detach: Uv,
  init: Gv,
  insert_hydration: Zv,
  noop: Xv,
  safe_not_equal: Yv,
  svg_element: Wv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kv,
  append_hydration: Qv,
  attr: Jv,
  children: eb,
  claim_svg_element: tb,
  detach: nb,
  init: ib,
  insert_hydration: lb,
  noop: ob,
  safe_not_equal: ab,
  svg_element: rb
} = window.__gradio__svelte__internal, {
  SvelteComponent: sb,
  append_hydration: ub,
  attr: _b,
  children: cb,
  claim_svg_element: db,
  detach: hb,
  init: fb,
  insert_hydration: pb,
  noop: mb,
  safe_not_equal: gb,
  svg_element: vb
} = window.__gradio__svelte__internal, {
  SvelteComponent: bb,
  append_hydration: Db,
  attr: yb,
  children: $b,
  claim_svg_element: wb,
  claim_text: Fb,
  detach: kb,
  init: Cb,
  insert_hydration: Eb,
  noop: Ab,
  safe_not_equal: Sb,
  svg_element: Bb,
  text: qb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tb,
  append_hydration: xb,
  attr: zb,
  children: Ib,
  claim_svg_element: Rb,
  detach: Lb,
  init: Ob,
  insert_hydration: Pb,
  noop: jb,
  safe_not_equal: Mb,
  svg_element: Nb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hb,
  append_hydration: Vb,
  attr: Ub,
  children: Gb,
  claim_svg_element: Zb,
  detach: Xb,
  init: Yb,
  insert_hydration: Wb,
  noop: Kb,
  safe_not_equal: Qb,
  svg_element: Jb
} = window.__gradio__svelte__internal, {
  SvelteComponent: eD,
  append_hydration: tD,
  attr: nD,
  children: iD,
  claim_svg_element: lD,
  detach: oD,
  init: aD,
  insert_hydration: rD,
  noop: sD,
  safe_not_equal: uD,
  svg_element: _D
} = window.__gradio__svelte__internal, {
  SvelteComponent: cD,
  append_hydration: dD,
  attr: hD,
  children: fD,
  claim_svg_element: pD,
  detach: mD,
  init: gD,
  insert_hydration: vD,
  noop: bD,
  safe_not_equal: DD,
  svg_element: yD
} = window.__gradio__svelte__internal, {
  SvelteComponent: $D,
  append_hydration: wD,
  attr: FD,
  children: kD,
  claim_svg_element: CD,
  detach: ED,
  init: AD,
  insert_hydration: SD,
  noop: BD,
  safe_not_equal: qD,
  svg_element: TD
} = window.__gradio__svelte__internal, {
  SvelteComponent: xD,
  append_hydration: zD,
  attr: ID,
  children: RD,
  claim_svg_element: LD,
  detach: OD,
  init: PD,
  insert_hydration: jD,
  noop: MD,
  safe_not_equal: ND,
  svg_element: HD
} = window.__gradio__svelte__internal, {
  SvelteComponent: VD,
  append_hydration: UD,
  attr: GD,
  children: ZD,
  claim_svg_element: XD,
  detach: YD,
  init: WD,
  insert_hydration: KD,
  noop: QD,
  safe_not_equal: JD,
  svg_element: ey
} = window.__gradio__svelte__internal, {
  SvelteComponent: ty,
  append_hydration: ny,
  attr: iy,
  children: ly,
  claim_svg_element: oy,
  claim_text: ay,
  detach: ry,
  init: sy,
  insert_hydration: uy,
  noop: _y,
  safe_not_equal: cy,
  svg_element: dy,
  text: hy
} = window.__gradio__svelte__internal, {
  SvelteComponent: fy,
  append_hydration: py,
  attr: my,
  children: gy,
  claim_svg_element: vy,
  claim_text: by,
  detach: Dy,
  init: yy,
  insert_hydration: $y,
  noop: wy,
  safe_not_equal: Fy,
  svg_element: ky,
  text: Cy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ey,
  append_hydration: Ay,
  attr: Sy,
  children: By,
  claim_svg_element: qy,
  claim_text: Ty,
  detach: xy,
  init: zy,
  insert_hydration: Iy,
  noop: Ry,
  safe_not_equal: Ly,
  svg_element: Oy,
  text: Py
} = window.__gradio__svelte__internal, {
  SvelteComponent: jy,
  append_hydration: My,
  attr: Ny,
  children: Hy,
  claim_svg_element: Vy,
  detach: Uy,
  init: Gy,
  insert_hydration: Zy,
  noop: Xy,
  safe_not_equal: Yy,
  svg_element: Wy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ky,
  append_hydration: Qy,
  attr: Jy,
  children: e$,
  claim_svg_element: t$,
  detach: n$,
  init: i$,
  insert_hydration: l$,
  noop: o$,
  safe_not_equal: a$,
  svg_element: r$
} = window.__gradio__svelte__internal, {
  SvelteComponent: s$,
  append_hydration: u$,
  attr: _$,
  children: c$,
  claim_svg_element: d$,
  detach: h$,
  init: f$,
  insert_hydration: p$,
  noop: m$,
  safe_not_equal: g$,
  svg_element: v$
} = window.__gradio__svelte__internal, {
  SvelteComponent: b$,
  append_hydration: D$,
  attr: y$,
  children: $$,
  claim_svg_element: w$,
  detach: F$,
  init: k$,
  insert_hydration: C$,
  noop: E$,
  safe_not_equal: A$,
  svg_element: S$
} = window.__gradio__svelte__internal, {
  SvelteComponent: B$,
  append_hydration: q$,
  attr: T$,
  children: x$,
  claim_svg_element: z$,
  detach: I$,
  init: R$,
  insert_hydration: L$,
  noop: O$,
  safe_not_equal: P$,
  svg_element: j$
} = window.__gradio__svelte__internal, {
  SvelteComponent: M$,
  append_hydration: N$,
  attr: H$,
  children: V$,
  claim_svg_element: U$,
  detach: G$,
  init: Z$,
  insert_hydration: X$,
  noop: Y$,
  safe_not_equal: W$,
  svg_element: K$
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q$,
  append_hydration: J$,
  attr: ew,
  children: tw,
  claim_svg_element: nw,
  detach: iw,
  init: lw,
  insert_hydration: ow,
  noop: aw,
  safe_not_equal: rw,
  svg_element: sw
} = window.__gradio__svelte__internal, {
  SvelteComponent: uw,
  append_hydration: _w,
  attr: cw,
  children: dw,
  claim_svg_element: hw,
  detach: fw,
  init: pw,
  insert_hydration: mw,
  noop: gw,
  safe_not_equal: vw,
  svg_element: bw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dw,
  append_hydration: yw,
  attr: $w,
  children: ww,
  claim_svg_element: Fw,
  detach: kw,
  init: Cw,
  insert_hydration: Ew,
  noop: Aw,
  safe_not_equal: Sw,
  svg_element: Bw
} = window.__gradio__svelte__internal, {
  SvelteComponent: qw,
  append_hydration: Tw,
  attr: xw,
  children: zw,
  claim_svg_element: Iw,
  detach: Rw,
  init: Lw,
  insert_hydration: Ow,
  noop: Pw,
  safe_not_equal: jw,
  svg_element: Mw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nw,
  append_hydration: Hw,
  attr: Vw,
  children: Uw,
  claim_svg_element: Gw,
  detach: Zw,
  init: Xw,
  insert_hydration: Yw,
  noop: Ww,
  safe_not_equal: Kw,
  svg_element: Qw
} = window.__gradio__svelte__internal, Sa = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ei = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Sa.reduce(
  (l, { color: e, primary: t, secondary: n }) => ({
    ...l,
    [e]: {
      primary: ei[e][t],
      secondary: ei[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: Jw,
  claim_component: e2,
  create_component: t2,
  destroy_component: n2,
  init: i2,
  mount_component: l2,
  safe_not_equal: o2,
  transition_in: a2,
  transition_out: r2
} = window.__gradio__svelte__internal, { createEventDispatcher: s2 } = window.__gradio__svelte__internal, {
  SvelteComponent: u2,
  append_hydration: _2,
  attr: c2,
  check_outros: d2,
  children: h2,
  claim_component: f2,
  claim_element: p2,
  claim_space: m2,
  claim_text: g2,
  create_component: v2,
  destroy_component: b2,
  detach: D2,
  element: y2,
  empty: $2,
  group_outros: w2,
  init: F2,
  insert_hydration: k2,
  mount_component: C2,
  safe_not_equal: E2,
  set_data: A2,
  space: S2,
  text: B2,
  toggle_class: q2,
  transition_in: T2,
  transition_out: x2
} = window.__gradio__svelte__internal, {
  SvelteComponent: z2,
  attr: I2,
  children: R2,
  claim_element: L2,
  create_slot: O2,
  detach: P2,
  element: j2,
  get_all_dirty_from_scope: M2,
  get_slot_changes: N2,
  init: H2,
  insert_hydration: V2,
  safe_not_equal: U2,
  toggle_class: G2,
  transition_in: Z2,
  transition_out: X2,
  update_slot_base: Y2
} = window.__gradio__svelte__internal, {
  SvelteComponent: W2,
  append_hydration: K2,
  attr: Q2,
  check_outros: J2,
  children: eF,
  claim_component: tF,
  claim_element: nF,
  claim_space: iF,
  create_component: lF,
  destroy_component: oF,
  detach: aF,
  element: rF,
  empty: sF,
  group_outros: uF,
  init: _F,
  insert_hydration: cF,
  listen: dF,
  mount_component: hF,
  safe_not_equal: fF,
  space: pF,
  toggle_class: mF,
  transition_in: gF,
  transition_out: vF
} = window.__gradio__svelte__internal, {
  SvelteComponent: bF,
  attr: DF,
  children: yF,
  claim_element: $F,
  create_slot: wF,
  detach: FF,
  element: kF,
  get_all_dirty_from_scope: CF,
  get_slot_changes: EF,
  init: AF,
  insert_hydration: SF,
  null_to_empty: BF,
  safe_not_equal: qF,
  transition_in: TF,
  transition_out: xF,
  update_slot_base: zF
} = window.__gradio__svelte__internal, {
  SvelteComponent: IF,
  check_outros: RF,
  claim_component: LF,
  create_component: OF,
  destroy_component: PF,
  detach: jF,
  empty: MF,
  group_outros: NF,
  init: HF,
  insert_hydration: VF,
  mount_component: UF,
  noop: GF,
  safe_not_equal: ZF,
  transition_in: XF,
  transition_out: YF
} = window.__gradio__svelte__internal, { createEventDispatcher: WF } = window.__gradio__svelte__internal;
function it(l) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; l > 1e3 && t < e.length - 1; )
    l /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(l) ? l : l.toFixed(1)) + n;
}
function Nt() {
}
const El = typeof window < "u";
let ti = El ? () => window.performance.now() : () => Date.now(), Al = El ? (l) => requestAnimationFrame(l) : Nt;
const lt = /* @__PURE__ */ new Set();
function Sl(l) {
  lt.forEach((e) => {
    e.c(l) || (lt.delete(e), e.f());
  }), lt.size !== 0 && Al(Sl);
}
function Ba(l) {
  let e;
  return lt.size === 0 && Al(Sl), { promise: new Promise((t) => {
    lt.add(e = { c: l, f: t });
  }), abort() {
    lt.delete(e);
  } };
}
const nt = [];
function qa(l, e = Nt) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function i(o) {
    if (r = o, ((s = l) != s ? r == r : s !== r || s && typeof s == "object" || typeof s == "function") && (l = o, t)) {
      const u = !nt.length;
      for (const _ of n) _[1](), nt.push(_, l);
      if (u) {
        for (let _ = 0; _ < nt.length; _ += 2) nt[_][0](nt[_ + 1]);
        nt.length = 0;
      }
    }
    var s, r;
  }
  function a(o) {
    i(o(l));
  }
  return { set: i, update: a, subscribe: function(o, s = Nt) {
    const r = [o, s];
    return n.add(r), n.size === 1 && (t = e(i, a) || Nt), o(l), () => {
      n.delete(r), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function ni(l) {
  return Object.prototype.toString.call(l) === "[object Date]";
}
function fn(l, e, t, n) {
  if (typeof t == "number" || ni(t)) {
    const i = n - t, a = (t - e) / (l.dt || 1 / 60), o = (a + (l.opts.stiffness * i - l.opts.damping * a) * l.inv_mass) * l.dt;
    return Math.abs(o) < l.opts.precision && Math.abs(i) < l.opts.precision ? n : (l.settled = !1, ni(t) ? new Date(t.getTime() + o) : t + o);
  }
  if (Array.isArray(t)) return t.map((i, a) => fn(l, e[a], t[a], n[a]));
  if (typeof t == "object") {
    const i = {};
    for (const a in t) i[a] = fn(l, e[a], t[a], n[a]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function ii(l, e = {}) {
  const t = qa(l), { stiffness: n = 0.15, damping: i = 0.8, precision: a = 0.01 } = e;
  let o, s, r, u = l, _ = l, d = 1, c = 0, f = !1;
  function g(m, $ = {}) {
    _ = m;
    const p = r = {};
    return l == null || $.hard || y.stiffness >= 1 && y.damping >= 1 ? (f = !0, o = ti(), u = m, t.set(l = _), Promise.resolve()) : ($.soft && (c = 1 / (60 * ($.soft === !0 ? 0.5 : +$.soft)), d = 0), s || (o = ti(), f = !1, s = Ba((h) => {
      if (f) return f = !1, s = null, !1;
      d = Math.min(d + c, 1);
      const b = { inv_mass: d, opts: y, settled: !0, dt: 60 * (h - o) / 1e3 }, v = fn(b, u, l, _);
      return o = h, u = l, t.set(l = v), b.settled && (s = null), !b.settled;
    })), new Promise((h) => {
      s.promise.then(() => {
        p === r && h();
      });
    }));
  }
  const y = { set: g, update: (m, $) => g(m(_, l), $), subscribe: t.subscribe, stiffness: n, damping: i, precision: a };
  return y;
}
const {
  SvelteComponent: Ta,
  append_hydration: ge,
  attr: T,
  children: ae,
  claim_element: xa,
  claim_svg_element: ve,
  component_subscribe: li,
  detach: le,
  element: za,
  init: Ia,
  insert_hydration: Ra,
  noop: oi,
  safe_not_equal: La,
  set_style: Lt,
  svg_element: be,
  toggle_class: ai
} = window.__gradio__svelte__internal, { onMount: Oa } = window.__gradio__svelte__internal;
function Pa(l) {
  let e, t, n, i, a, o, s, r, u, _, d, c;
  return {
    c() {
      e = za("div"), t = be("svg"), n = be("g"), i = be("path"), a = be("path"), o = be("path"), s = be("path"), r = be("g"), u = be("path"), _ = be("path"), d = be("path"), c = be("path"), this.h();
    },
    l(f) {
      e = xa(f, "DIV", { class: !0 });
      var g = ae(e);
      t = ve(g, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var y = ae(t);
      n = ve(y, "g", { style: !0 });
      var m = ae(n);
      i = ve(m, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ae(i).forEach(le), a = ve(m, "path", { d: !0, fill: !0, class: !0 }), ae(a).forEach(le), o = ve(m, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ae(o).forEach(le), s = ve(m, "path", { d: !0, fill: !0, class: !0 }), ae(s).forEach(le), m.forEach(le), r = ve(y, "g", { style: !0 });
      var $ = ae(r);
      u = ve($, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ae(u).forEach(le), _ = ve($, "path", { d: !0, fill: !0, class: !0 }), ae(_).forEach(le), d = ve($, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ae(d).forEach(le), c = ve($, "path", { d: !0, fill: !0, class: !0 }), ae(c).forEach(le), $.forEach(le), y.forEach(le), g.forEach(le), this.h();
    },
    h() {
      T(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), T(i, "fill", "#FF7C00"), T(i, "fill-opacity", "0.4"), T(i, "class", "svelte-43sxxs"), T(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), T(a, "fill", "#FF7C00"), T(a, "class", "svelte-43sxxs"), T(o, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), T(o, "fill", "#FF7C00"), T(o, "fill-opacity", "0.4"), T(o, "class", "svelte-43sxxs"), T(s, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), T(s, "fill", "#FF7C00"), T(s, "class", "svelte-43sxxs"), Lt(n, "transform", "translate(" + /*$top*/
      l[1][0] + "px, " + /*$top*/
      l[1][1] + "px)"), T(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), T(u, "fill", "#FF7C00"), T(u, "fill-opacity", "0.4"), T(u, "class", "svelte-43sxxs"), T(_, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), T(_, "fill", "#FF7C00"), T(_, "class", "svelte-43sxxs"), T(d, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), T(d, "fill", "#FF7C00"), T(d, "fill-opacity", "0.4"), T(d, "class", "svelte-43sxxs"), T(c, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), T(c, "fill", "#FF7C00"), T(c, "class", "svelte-43sxxs"), Lt(r, "transform", "translate(" + /*$bottom*/
      l[2][0] + "px, " + /*$bottom*/
      l[2][1] + "px)"), T(t, "viewBox", "-1200 -1200 3000 3000"), T(t, "fill", "none"), T(t, "xmlns", "http://www.w3.org/2000/svg"), T(t, "class", "svelte-43sxxs"), T(e, "class", "svelte-43sxxs"), ai(
        e,
        "margin",
        /*margin*/
        l[0]
      );
    },
    m(f, g) {
      Ra(f, e, g), ge(e, t), ge(t, n), ge(n, i), ge(n, a), ge(n, o), ge(n, s), ge(t, r), ge(r, u), ge(r, _), ge(r, d), ge(r, c);
    },
    p(f, [g]) {
      g & /*$top*/
      2 && Lt(n, "transform", "translate(" + /*$top*/
      f[1][0] + "px, " + /*$top*/
      f[1][1] + "px)"), g & /*$bottom*/
      4 && Lt(r, "transform", "translate(" + /*$bottom*/
      f[2][0] + "px, " + /*$bottom*/
      f[2][1] + "px)"), g & /*margin*/
      1 && ai(
        e,
        "margin",
        /*margin*/
        f[0]
      );
    },
    i: oi,
    o: oi,
    d(f) {
      f && le(e);
    }
  };
}
function ja(l, e, t) {
  let n, i;
  var a = this && this.__awaiter || function(f, g, y, m) {
    function $(p) {
      return p instanceof y ? p : new y(function(h) {
        h(p);
      });
    }
    return new (y || (y = Promise))(function(p, h) {
      function b(w) {
        try {
          D(m.next(w));
        } catch (S) {
          h(S);
        }
      }
      function v(w) {
        try {
          D(m.throw(w));
        } catch (S) {
          h(S);
        }
      }
      function D(w) {
        w.done ? p(w.value) : $(w.value).then(b, v);
      }
      D((m = m.apply(f, g || [])).next());
    });
  };
  let { margin: o = !0 } = e;
  const s = ii([0, 0]);
  li(l, s, (f) => t(1, n = f));
  const r = ii([0, 0]);
  li(l, r, (f) => t(2, i = f));
  let u;
  function _() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 140]), r.set([-125, -140])]), yield Promise.all([s.set([-125, 140]), r.set([125, -140])]), yield Promise.all([s.set([-125, 0]), r.set([125, -0])]), yield Promise.all([s.set([125, 0]), r.set([-125, 0])]);
    });
  }
  function d() {
    return a(this, void 0, void 0, function* () {
      yield _(), u || d();
    });
  }
  function c() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 0]), r.set([-125, 0])]), d();
    });
  }
  return Oa(() => (c(), () => u = !0)), l.$$set = (f) => {
    "margin" in f && t(0, o = f.margin);
  }, [o, n, i, s, r];
}
class Ma extends Ta {
  constructor(e) {
    super(), Ia(this, e, ja, Pa, La, { margin: 0 });
  }
}
const {
  SvelteComponent: Na,
  append_hydration: Ze,
  attr: $e,
  binding_callbacks: ri,
  check_outros: pn,
  children: Be,
  claim_component: Bl,
  claim_element: qe,
  claim_space: _e,
  claim_text: j,
  create_component: ql,
  create_slot: Tl,
  destroy_component: xl,
  destroy_each: zl,
  detach: A,
  element: Te,
  empty: he,
  ensure_array_like: Gt,
  get_all_dirty_from_scope: Il,
  get_slot_changes: Rl,
  group_outros: mn,
  init: Ha,
  insert_hydration: B,
  mount_component: Ll,
  noop: gn,
  safe_not_equal: Va,
  set_data: fe,
  set_style: Ve,
  space: ce,
  text: M,
  toggle_class: re,
  transition_in: ye,
  transition_out: xe,
  update_slot_base: Ol
} = window.__gradio__svelte__internal, { tick: Ua } = window.__gradio__svelte__internal, { onDestroy: Ga } = window.__gradio__svelte__internal, { createEventDispatcher: Za } = window.__gradio__svelte__internal, Xa = (l) => ({}), si = (l) => ({}), Ya = (l) => ({}), ui = (l) => ({});
function _i(l, e, t) {
  const n = l.slice();
  return n[40] = e[t], n[42] = t, n;
}
function ci(l, e, t) {
  const n = l.slice();
  return n[40] = e[t], n;
}
function Wa(l) {
  let e, t, n, i, a = (
    /*i18n*/
    l[1]("common.error") + ""
  ), o, s, r;
  t = new $a({
    props: {
      Icon: Aa,
      label: (
        /*i18n*/
        l[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    l[32]
  );
  const u = (
    /*#slots*/
    l[30].error
  ), _ = Tl(
    u,
    l,
    /*$$scope*/
    l[29],
    si
  );
  return {
    c() {
      e = Te("div"), ql(t.$$.fragment), n = ce(), i = Te("span"), o = M(a), s = ce(), _ && _.c(), this.h();
    },
    l(d) {
      e = qe(d, "DIV", { class: !0 });
      var c = Be(e);
      Bl(t.$$.fragment, c), c.forEach(A), n = _e(d), i = qe(d, "SPAN", { class: !0 });
      var f = Be(i);
      o = j(f, a), f.forEach(A), s = _e(d), _ && _.l(d), this.h();
    },
    h() {
      $e(e, "class", "clear-status svelte-17v219f"), $e(i, "class", "error svelte-17v219f");
    },
    m(d, c) {
      B(d, e, c), Ll(t, e, null), B(d, n, c), B(d, i, c), Ze(i, o), B(d, s, c), _ && _.m(d, c), r = !0;
    },
    p(d, c) {
      const f = {};
      c[0] & /*i18n*/
      2 && (f.label = /*i18n*/
      d[1]("common.clear")), t.$set(f), (!r || c[0] & /*i18n*/
      2) && a !== (a = /*i18n*/
      d[1]("common.error") + "") && fe(o, a), _ && _.p && (!r || c[0] & /*$$scope*/
      536870912) && Ol(
        _,
        u,
        d,
        /*$$scope*/
        d[29],
        r ? Rl(
          u,
          /*$$scope*/
          d[29],
          c,
          Xa
        ) : Il(
          /*$$scope*/
          d[29]
        ),
        si
      );
    },
    i(d) {
      r || (ye(t.$$.fragment, d), ye(_, d), r = !0);
    },
    o(d) {
      xe(t.$$.fragment, d), xe(_, d), r = !1;
    },
    d(d) {
      d && (A(e), A(n), A(i), A(s)), xl(t), _ && _.d(d);
    }
  };
}
function Ka(l) {
  let e, t, n, i, a, o, s, r, u, _ = (
    /*variant*/
    l[8] === "default" && /*show_eta_bar*/
    l[18] && /*show_progress*/
    l[6] === "full" && di(l)
  );
  function d(h, b) {
    if (
      /*progress*/
      h[7]
    ) return er;
    if (
      /*queue_position*/
      h[2] !== null && /*queue_size*/
      h[3] !== void 0 && /*queue_position*/
      h[2] >= 0
    ) return Ja;
    if (
      /*queue_position*/
      h[2] === 0
    ) return Qa;
  }
  let c = d(l), f = c && c(l), g = (
    /*timer*/
    l[5] && pi(l)
  );
  const y = [lr, ir], m = [];
  function $(h, b) {
    return (
      /*last_progress_level*/
      h[15] != null ? 0 : (
        /*show_progress*/
        h[6] === "full" ? 1 : -1
      )
    );
  }
  ~(a = $(l)) && (o = m[a] = y[a](l));
  let p = !/*timer*/
  l[5] && $i(l);
  return {
    c() {
      _ && _.c(), e = ce(), t = Te("div"), f && f.c(), n = ce(), g && g.c(), i = ce(), o && o.c(), s = ce(), p && p.c(), r = he(), this.h();
    },
    l(h) {
      _ && _.l(h), e = _e(h), t = qe(h, "DIV", { class: !0 });
      var b = Be(t);
      f && f.l(b), n = _e(b), g && g.l(b), b.forEach(A), i = _e(h), o && o.l(h), s = _e(h), p && p.l(h), r = he(), this.h();
    },
    h() {
      $e(t, "class", "progress-text svelte-17v219f"), re(
        t,
        "meta-text-center",
        /*variant*/
        l[8] === "center"
      ), re(
        t,
        "meta-text",
        /*variant*/
        l[8] === "default"
      );
    },
    m(h, b) {
      _ && _.m(h, b), B(h, e, b), B(h, t, b), f && f.m(t, null), Ze(t, n), g && g.m(t, null), B(h, i, b), ~a && m[a].m(h, b), B(h, s, b), p && p.m(h, b), B(h, r, b), u = !0;
    },
    p(h, b) {
      /*variant*/
      h[8] === "default" && /*show_eta_bar*/
      h[18] && /*show_progress*/
      h[6] === "full" ? _ ? _.p(h, b) : (_ = di(h), _.c(), _.m(e.parentNode, e)) : _ && (_.d(1), _ = null), c === (c = d(h)) && f ? f.p(h, b) : (f && f.d(1), f = c && c(h), f && (f.c(), f.m(t, n))), /*timer*/
      h[5] ? g ? g.p(h, b) : (g = pi(h), g.c(), g.m(t, null)) : g && (g.d(1), g = null), (!u || b[0] & /*variant*/
      256) && re(
        t,
        "meta-text-center",
        /*variant*/
        h[8] === "center"
      ), (!u || b[0] & /*variant*/
      256) && re(
        t,
        "meta-text",
        /*variant*/
        h[8] === "default"
      );
      let v = a;
      a = $(h), a === v ? ~a && m[a].p(h, b) : (o && (mn(), xe(m[v], 1, 1, () => {
        m[v] = null;
      }), pn()), ~a ? (o = m[a], o ? o.p(h, b) : (o = m[a] = y[a](h), o.c()), ye(o, 1), o.m(s.parentNode, s)) : o = null), /*timer*/
      h[5] ? p && (mn(), xe(p, 1, 1, () => {
        p = null;
      }), pn()) : p ? (p.p(h, b), b[0] & /*timer*/
      32 && ye(p, 1)) : (p = $i(h), p.c(), ye(p, 1), p.m(r.parentNode, r));
    },
    i(h) {
      u || (ye(o), ye(p), u = !0);
    },
    o(h) {
      xe(o), xe(p), u = !1;
    },
    d(h) {
      h && (A(e), A(t), A(i), A(s), A(r)), _ && _.d(h), f && f.d(), g && g.d(), ~a && m[a].d(h), p && p.d(h);
    }
  };
}
function di(l) {
  let e, t = `translateX(${/*eta_level*/
  (l[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Te("div"), this.h();
    },
    l(n) {
      e = qe(n, "DIV", { class: !0 }), Be(e).forEach(A), this.h();
    },
    h() {
      $e(e, "class", "eta-bar svelte-17v219f"), Ve(e, "transform", t);
    },
    m(n, i) {
      B(n, e, i);
    },
    p(n, i) {
      i[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && Ve(e, "transform", t);
    },
    d(n) {
      n && A(e);
    }
  };
}
function Qa(l) {
  let e;
  return {
    c() {
      e = M("processing |");
    },
    l(t) {
      e = j(t, "processing |");
    },
    m(t, n) {
      B(t, e, n);
    },
    p: gn,
    d(t) {
      t && A(e);
    }
  };
}
function Ja(l) {
  let e, t = (
    /*queue_position*/
    l[2] + 1 + ""
  ), n, i, a, o;
  return {
    c() {
      e = M("queue: "), n = M(t), i = M("/"), a = M(
        /*queue_size*/
        l[3]
      ), o = M(" |");
    },
    l(s) {
      e = j(s, "queue: "), n = j(s, t), i = j(s, "/"), a = j(
        s,
        /*queue_size*/
        l[3]
      ), o = j(s, " |");
    },
    m(s, r) {
      B(s, e, r), B(s, n, r), B(s, i, r), B(s, a, r), B(s, o, r);
    },
    p(s, r) {
      r[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      s[2] + 1 + "") && fe(n, t), r[0] & /*queue_size*/
      8 && fe(
        a,
        /*queue_size*/
        s[3]
      );
    },
    d(s) {
      s && (A(e), A(n), A(i), A(a), A(o));
    }
  };
}
function er(l) {
  let e, t = Gt(
    /*progress*/
    l[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = fi(ci(l, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = he();
    },
    l(i) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(i);
      e = he();
    },
    m(i, a) {
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(i, a);
      B(i, e, a);
    },
    p(i, a) {
      if (a[0] & /*progress*/
      128) {
        t = Gt(
          /*progress*/
          i[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const s = ci(i, t, o);
          n[o] ? n[o].p(s, a) : (n[o] = fi(s), n[o].c(), n[o].m(e.parentNode, e));
        }
        for (; o < n.length; o += 1)
          n[o].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && A(e), zl(n, i);
    }
  };
}
function hi(l) {
  let e, t = (
    /*p*/
    l[40].unit + ""
  ), n, i, a = " ", o;
  function s(_, d) {
    return (
      /*p*/
      _[40].length != null ? nr : tr
    );
  }
  let r = s(l), u = r(l);
  return {
    c() {
      u.c(), e = ce(), n = M(t), i = M(" | "), o = M(a);
    },
    l(_) {
      u.l(_), e = _e(_), n = j(_, t), i = j(_, " | "), o = j(_, a);
    },
    m(_, d) {
      u.m(_, d), B(_, e, d), B(_, n, d), B(_, i, d), B(_, o, d);
    },
    p(_, d) {
      r === (r = s(_)) && u ? u.p(_, d) : (u.d(1), u = r(_), u && (u.c(), u.m(e.parentNode, e))), d[0] & /*progress*/
      128 && t !== (t = /*p*/
      _[40].unit + "") && fe(n, t);
    },
    d(_) {
      _ && (A(e), A(n), A(i), A(o)), u.d(_);
    }
  };
}
function tr(l) {
  let e = it(
    /*p*/
    l[40].index || 0
  ) + "", t;
  return {
    c() {
      t = M(e);
    },
    l(n) {
      t = j(n, e);
    },
    m(n, i) {
      B(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = it(
        /*p*/
        n[40].index || 0
      ) + "") && fe(t, e);
    },
    d(n) {
      n && A(t);
    }
  };
}
function nr(l) {
  let e = it(
    /*p*/
    l[40].index || 0
  ) + "", t, n, i = it(
    /*p*/
    l[40].length
  ) + "", a;
  return {
    c() {
      t = M(e), n = M("/"), a = M(i);
    },
    l(o) {
      t = j(o, e), n = j(o, "/"), a = j(o, i);
    },
    m(o, s) {
      B(o, t, s), B(o, n, s), B(o, a, s);
    },
    p(o, s) {
      s[0] & /*progress*/
      128 && e !== (e = it(
        /*p*/
        o[40].index || 0
      ) + "") && fe(t, e), s[0] & /*progress*/
      128 && i !== (i = it(
        /*p*/
        o[40].length
      ) + "") && fe(a, i);
    },
    d(o) {
      o && (A(t), A(n), A(a));
    }
  };
}
function fi(l) {
  let e, t = (
    /*p*/
    l[40].index != null && hi(l)
  );
  return {
    c() {
      t && t.c(), e = he();
    },
    l(n) {
      t && t.l(n), e = he();
    },
    m(n, i) {
      t && t.m(n, i), B(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].index != null ? t ? t.p(n, i) : (t = hi(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && A(e), t && t.d(n);
    }
  };
}
function pi(l) {
  let e, t = (
    /*eta*/
    l[0] ? `/${/*formatted_eta*/
    l[19]}` : ""
  ), n, i;
  return {
    c() {
      e = M(
        /*formatted_timer*/
        l[20]
      ), n = M(t), i = M("s");
    },
    l(a) {
      e = j(
        a,
        /*formatted_timer*/
        l[20]
      ), n = j(a, t), i = j(a, "s");
    },
    m(a, o) {
      B(a, e, o), B(a, n, o), B(a, i, o);
    },
    p(a, o) {
      o[0] & /*formatted_timer*/
      1048576 && fe(
        e,
        /*formatted_timer*/
        a[20]
      ), o[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[19]}` : "") && fe(n, t);
    },
    d(a) {
      a && (A(e), A(n), A(i));
    }
  };
}
function ir(l) {
  let e, t;
  return e = new Ma({
    props: { margin: (
      /*variant*/
      l[8] === "default"
    ) }
  }), {
    c() {
      ql(e.$$.fragment);
    },
    l(n) {
      Bl(e.$$.fragment, n);
    },
    m(n, i) {
      Ll(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*variant*/
      256 && (a.margin = /*variant*/
      n[8] === "default"), e.$set(a);
    },
    i(n) {
      t || (ye(e.$$.fragment, n), t = !0);
    },
    o(n) {
      xe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      xl(e, n);
    }
  };
}
function lr(l) {
  let e, t, n, i, a, o = `${/*last_progress_level*/
  l[15] * 100}%`, s = (
    /*progress*/
    l[7] != null && mi(l)
  );
  return {
    c() {
      e = Te("div"), t = Te("div"), s && s.c(), n = ce(), i = Te("div"), a = Te("div"), this.h();
    },
    l(r) {
      e = qe(r, "DIV", { class: !0 });
      var u = Be(e);
      t = qe(u, "DIV", { class: !0 });
      var _ = Be(t);
      s && s.l(_), _.forEach(A), n = _e(u), i = qe(u, "DIV", { class: !0 });
      var d = Be(i);
      a = qe(d, "DIV", { class: !0 }), Be(a).forEach(A), d.forEach(A), u.forEach(A), this.h();
    },
    h() {
      $e(t, "class", "progress-level-inner svelte-17v219f"), $e(a, "class", "progress-bar svelte-17v219f"), Ve(a, "width", o), $e(i, "class", "progress-bar-wrap svelte-17v219f"), $e(e, "class", "progress-level svelte-17v219f");
    },
    m(r, u) {
      B(r, e, u), Ze(e, t), s && s.m(t, null), Ze(e, n), Ze(e, i), Ze(i, a), l[31](a);
    },
    p(r, u) {
      /*progress*/
      r[7] != null ? s ? s.p(r, u) : (s = mi(r), s.c(), s.m(t, null)) : s && (s.d(1), s = null), u[0] & /*last_progress_level*/
      32768 && o !== (o = `${/*last_progress_level*/
      r[15] * 100}%`) && Ve(a, "width", o);
    },
    i: gn,
    o: gn,
    d(r) {
      r && A(e), s && s.d(), l[31](null);
    }
  };
}
function mi(l) {
  let e, t = Gt(
    /*progress*/
    l[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = yi(_i(l, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = he();
    },
    l(i) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(i);
      e = he();
    },
    m(i, a) {
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(i, a);
      B(i, e, a);
    },
    p(i, a) {
      if (a[0] & /*progress_level, progress*/
      16512) {
        t = Gt(
          /*progress*/
          i[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const s = _i(i, t, o);
          n[o] ? n[o].p(s, a) : (n[o] = yi(s), n[o].c(), n[o].m(e.parentNode, e));
        }
        for (; o < n.length; o += 1)
          n[o].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && A(e), zl(n, i);
    }
  };
}
function gi(l) {
  let e, t, n, i, a = (
    /*i*/
    l[42] !== 0 && or()
  ), o = (
    /*p*/
    l[40].desc != null && vi(l)
  ), s = (
    /*p*/
    l[40].desc != null && /*progress_level*/
    l[14] && /*progress_level*/
    l[14][
      /*i*/
      l[42]
    ] != null && bi()
  ), r = (
    /*progress_level*/
    l[14] != null && Di(l)
  );
  return {
    c() {
      a && a.c(), e = ce(), o && o.c(), t = ce(), s && s.c(), n = ce(), r && r.c(), i = he();
    },
    l(u) {
      a && a.l(u), e = _e(u), o && o.l(u), t = _e(u), s && s.l(u), n = _e(u), r && r.l(u), i = he();
    },
    m(u, _) {
      a && a.m(u, _), B(u, e, _), o && o.m(u, _), B(u, t, _), s && s.m(u, _), B(u, n, _), r && r.m(u, _), B(u, i, _);
    },
    p(u, _) {
      /*p*/
      u[40].desc != null ? o ? o.p(u, _) : (o = vi(u), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? s || (s = bi(), s.c(), s.m(n.parentNode, n)) : s && (s.d(1), s = null), /*progress_level*/
      u[14] != null ? r ? r.p(u, _) : (r = Di(u), r.c(), r.m(i.parentNode, i)) : r && (r.d(1), r = null);
    },
    d(u) {
      u && (A(e), A(t), A(n), A(i)), a && a.d(u), o && o.d(u), s && s.d(u), r && r.d(u);
    }
  };
}
function or(l) {
  let e;
  return {
    c() {
      e = M(" /");
    },
    l(t) {
      e = j(t, " /");
    },
    m(t, n) {
      B(t, e, n);
    },
    d(t) {
      t && A(e);
    }
  };
}
function vi(l) {
  let e = (
    /*p*/
    l[40].desc + ""
  ), t;
  return {
    c() {
      t = M(e);
    },
    l(n) {
      t = j(n, e);
    },
    m(n, i) {
      B(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && fe(t, e);
    },
    d(n) {
      n && A(t);
    }
  };
}
function bi(l) {
  let e;
  return {
    c() {
      e = M("-");
    },
    l(t) {
      e = j(t, "-");
    },
    m(t, n) {
      B(t, e, n);
    },
    d(t) {
      t && A(e);
    }
  };
}
function Di(l) {
  let e = (100 * /*progress_level*/
  (l[14][
    /*i*/
    l[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = M(e), n = M("%");
    },
    l(i) {
      t = j(i, e), n = j(i, "%");
    },
    m(i, a) {
      B(i, t, a), B(i, n, a);
    },
    p(i, a) {
      a[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[42]
      ] || 0)).toFixed(1) + "") && fe(t, e);
    },
    d(i) {
      i && (A(t), A(n));
    }
  };
}
function yi(l) {
  let e, t = (
    /*p*/
    (l[40].desc != null || /*progress_level*/
    l[14] && /*progress_level*/
    l[14][
      /*i*/
      l[42]
    ] != null) && gi(l)
  );
  return {
    c() {
      t && t.c(), e = he();
    },
    l(n) {
      t && t.l(n), e = he();
    },
    m(n, i) {
      t && t.m(n, i), B(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, i) : (t = gi(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && A(e), t && t.d(n);
    }
  };
}
function $i(l) {
  let e, t, n, i;
  const a = (
    /*#slots*/
    l[30]["additional-loading-text"]
  ), o = Tl(
    a,
    l,
    /*$$scope*/
    l[29],
    ui
  );
  return {
    c() {
      e = Te("p"), t = M(
        /*loading_text*/
        l[9]
      ), n = ce(), o && o.c(), this.h();
    },
    l(s) {
      e = qe(s, "P", { class: !0 });
      var r = Be(e);
      t = j(
        r,
        /*loading_text*/
        l[9]
      ), r.forEach(A), n = _e(s), o && o.l(s), this.h();
    },
    h() {
      $e(e, "class", "loading svelte-17v219f");
    },
    m(s, r) {
      B(s, e, r), Ze(e, t), B(s, n, r), o && o.m(s, r), i = !0;
    },
    p(s, r) {
      (!i || r[0] & /*loading_text*/
      512) && fe(
        t,
        /*loading_text*/
        s[9]
      ), o && o.p && (!i || r[0] & /*$$scope*/
      536870912) && Ol(
        o,
        a,
        s,
        /*$$scope*/
        s[29],
        i ? Rl(
          a,
          /*$$scope*/
          s[29],
          r,
          Ya
        ) : Il(
          /*$$scope*/
          s[29]
        ),
        ui
      );
    },
    i(s) {
      i || (ye(o, s), i = !0);
    },
    o(s) {
      xe(o, s), i = !1;
    },
    d(s) {
      s && (A(e), A(n)), o && o.d(s);
    }
  };
}
function ar(l) {
  let e, t, n, i, a;
  const o = [Ka, Wa], s = [];
  function r(u, _) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = r(l)) && (n = s[t] = o[t](l)), {
    c() {
      e = Te("div"), n && n.c(), this.h();
    },
    l(u) {
      e = qe(u, "DIV", { class: !0 });
      var _ = Be(e);
      n && n.l(_), _.forEach(A), this.h();
    },
    h() {
      $e(e, "class", i = "wrap " + /*variant*/
      l[8] + " " + /*show_progress*/
      l[6] + " svelte-17v219f"), re(e, "hide", !/*status*/
      l[4] || /*status*/
      l[4] === "complete" || /*show_progress*/
      l[6] === "hidden" || /*status*/
      l[4] == "streaming"), re(
        e,
        "translucent",
        /*variant*/
        l[8] === "center" && /*status*/
        (l[4] === "pending" || /*status*/
        l[4] === "error") || /*translucent*/
        l[11] || /*show_progress*/
        l[6] === "minimal"
      ), re(
        e,
        "generating",
        /*status*/
        l[4] === "generating" && /*show_progress*/
        l[6] === "full"
      ), re(
        e,
        "border",
        /*border*/
        l[12]
      ), Ve(
        e,
        "position",
        /*absolute*/
        l[10] ? "absolute" : "static"
      ), Ve(
        e,
        "padding",
        /*absolute*/
        l[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, _) {
      B(u, e, _), ~t && s[t].m(e, null), l[33](e), a = !0;
    },
    p(u, _) {
      let d = t;
      t = r(u), t === d ? ~t && s[t].p(u, _) : (n && (mn(), xe(s[d], 1, 1, () => {
        s[d] = null;
      }), pn()), ~t ? (n = s[t], n ? n.p(u, _) : (n = s[t] = o[t](u), n.c()), ye(n, 1), n.m(e, null)) : n = null), (!a || _[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && $e(e, "class", i), (!a || _[0] & /*variant, show_progress, status, show_progress*/
      336) && re(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!a || _[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && re(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!a || _[0] & /*variant, show_progress, status, show_progress*/
      336) && re(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!a || _[0] & /*variant, show_progress, border*/
      4416) && re(
        e,
        "border",
        /*border*/
        u[12]
      ), _[0] & /*absolute*/
      1024 && Ve(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), _[0] & /*absolute*/
      1024 && Ve(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      a || (ye(n), a = !0);
    },
    o(u) {
      xe(n), a = !1;
    },
    d(u) {
      u && A(e), ~t && s[t].d(), l[33](null);
    }
  };
}
var rr = function(l, e, t, n) {
  function i(a) {
    return a instanceof t ? a : new t(function(o) {
      o(a);
    });
  }
  return new (t || (t = Promise))(function(a, o) {
    function s(_) {
      try {
        u(n.next(_));
      } catch (d) {
        o(d);
      }
    }
    function r(_) {
      try {
        u(n.throw(_));
      } catch (d) {
        o(d);
      }
    }
    function u(_) {
      _.done ? a(_.value) : i(_.value).then(s, r);
    }
    u((n = n.apply(l, e || [])).next());
  });
};
let Ot = [], rn = !1;
const sr = typeof window < "u", Pl = sr ? window.requestAnimationFrame : (l) => {
};
function ur(l) {
  return rr(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (Ot.push(e), !rn) rn = !0;
      else return;
      yield Ua(), Pl(() => {
        let n = [0, 0];
        for (let i = 0; i < Ot.length; i++) {
          const o = Ot[i].getBoundingClientRect();
          (i === 0 || o.top + window.scrollY <= n[0]) && (n[0] = o.top + window.scrollY, n[1] = i);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), rn = !1, Ot = [];
      });
    }
  });
}
function _r(l, e, t) {
  let n, { $$slots: i = {}, $$scope: a } = e;
  const o = Za();
  let { i18n: s } = e, { eta: r = null } = e, { queue_position: u } = e, { queue_size: _ } = e, { status: d } = e, { scroll_to_output: c = !1 } = e, { timer: f = !0 } = e, { show_progress: g = "full" } = e, { message: y = null } = e, { progress: m = null } = e, { variant: $ = "default" } = e, { loading_text: p = "Loading..." } = e, { absolute: h = !0 } = e, { translucent: b = !1 } = e, { border: v = !1 } = e, { autoscroll: D } = e, w, S = !1, k = 0, q = 0, C = null, L = null, Ue = 0, ne = null, Fe, te = null, je = !0;
  const N = () => {
    t(0, r = t(27, C = t(19, F = null))), t(25, k = performance.now()), t(26, q = 0), S = !0, Q();
  };
  function Q() {
    Pl(() => {
      t(26, q = (performance.now() - k) / 1e3), S && Q();
    });
  }
  function pe() {
    t(26, q = 0), t(0, r = t(27, C = t(19, F = null))), S && (S = !1);
  }
  Ga(() => {
    S && pe();
  });
  let F = null;
  function G(E) {
    ri[E ? "unshift" : "push"](() => {
      te = E, t(16, te), t(7, m), t(14, ne), t(15, Fe);
    });
  }
  const et = () => {
    o("clear_status");
  };
  function ie(E) {
    ri[E ? "unshift" : "push"](() => {
      w = E, t(13, w);
    });
  }
  return l.$$set = (E) => {
    "i18n" in E && t(1, s = E.i18n), "eta" in E && t(0, r = E.eta), "queue_position" in E && t(2, u = E.queue_position), "queue_size" in E && t(3, _ = E.queue_size), "status" in E && t(4, d = E.status), "scroll_to_output" in E && t(22, c = E.scroll_to_output), "timer" in E && t(5, f = E.timer), "show_progress" in E && t(6, g = E.show_progress), "message" in E && t(23, y = E.message), "progress" in E && t(7, m = E.progress), "variant" in E && t(8, $ = E.variant), "loading_text" in E && t(9, p = E.loading_text), "absolute" in E && t(10, h = E.absolute), "translucent" in E && t(11, b = E.translucent), "border" in E && t(12, v = E.border), "autoscroll" in E && t(24, D = E.autoscroll), "$$scope" in E && t(29, a = E.$$scope);
  }, l.$$.update = () => {
    l.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (r === null && t(0, r = C), r != null && C !== r && (t(28, L = (performance.now() - k) / 1e3 + r), t(19, F = L.toFixed(1)), t(27, C = r))), l.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, Ue = L === null || L <= 0 || !q ? null : Math.min(q / L, 1)), l.$$.dirty[0] & /*progress*/
    128 && m != null && t(18, je = !1), l.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (m != null ? t(14, ne = m.map((E) => {
      if (E.index != null && E.length != null)
        return E.index / E.length;
      if (E.progress != null)
        return E.progress;
    })) : t(14, ne = null), ne ? (t(15, Fe = ne[ne.length - 1]), te && (Fe === 0 ? t(16, te.style.transition = "0", te) : t(16, te.style.transition = "150ms", te))) : t(15, Fe = void 0)), l.$$.dirty[0] & /*status*/
    16 && (d === "pending" ? N() : pe()), l.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && w && c && (d === "pending" || d === "complete") && ur(w, D), l.$$.dirty[0] & /*status, message*/
    8388624, l.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = q.toFixed(1));
  }, [
    r,
    s,
    u,
    _,
    d,
    f,
    g,
    m,
    $,
    p,
    h,
    b,
    v,
    w,
    ne,
    Fe,
    te,
    Ue,
    je,
    F,
    n,
    o,
    c,
    y,
    D,
    k,
    q,
    C,
    L,
    a,
    i,
    G,
    et,
    ie
  ];
}
class cr extends Na {
  constructor(e) {
    super(), Ha(
      this,
      e,
      _r,
      ar,
      Va,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: KF,
  SvelteComponent: QF,
  add_render_callback: JF,
  append_hydration: ek,
  attr: tk,
  bubble: nk,
  check_outros: ik,
  children: lk,
  claim_component: ok,
  claim_element: ak,
  claim_html_tag: rk,
  claim_space: sk,
  claim_text: uk,
  create_component: _k,
  create_in_transition: ck,
  create_out_transition: dk,
  destroy_component: hk,
  detach: fk,
  element: pk,
  get_svelte_dataset: mk,
  group_outros: gk,
  init: vk,
  insert_hydration: bk,
  listen: Dk,
  mount_component: yk,
  run_all: $k,
  safe_not_equal: wk,
  set_data: Fk,
  space: kk,
  stop_propagation: Ck,
  text: Ek,
  toggle_class: Ak,
  transition_in: Sk,
  transition_out: Bk
} = window.__gradio__svelte__internal, { createEventDispatcher: qk, onMount: Tk } = window.__gradio__svelte__internal, {
  SvelteComponent: xk,
  append_hydration: zk,
  attr: Ik,
  bubble: Rk,
  check_outros: Lk,
  children: Ok,
  claim_component: Pk,
  claim_element: jk,
  claim_space: Mk,
  create_animation: Nk,
  create_component: Hk,
  destroy_component: Vk,
  detach: Uk,
  element: Gk,
  ensure_array_like: Zk,
  fix_and_outro_and_destroy_block: Xk,
  fix_position: Yk,
  group_outros: Wk,
  init: Kk,
  insert_hydration: Qk,
  mount_component: Jk,
  noop: eC,
  safe_not_equal: tC,
  set_style: nC,
  space: iC,
  transition_in: lC,
  transition_out: oC,
  update_keyed_each: aC
} = window.__gradio__svelte__internal, {
  SvelteComponent: rC,
  attr: sC,
  children: uC,
  claim_element: _C,
  detach: cC,
  element: dC,
  empty: hC,
  init: fC,
  insert_hydration: pC,
  noop: mC,
  safe_not_equal: gC,
  set_style: vC
} = window.__gradio__svelte__internal, {
  SvelteComponent: dr,
  append_hydration: ft,
  attr: Ie,
  children: $t,
  claim_element: wt,
  claim_space: wi,
  claim_text: jl,
  destroy_each: hr,
  detach: Le,
  element: Ft,
  ensure_array_like: Fi,
  init: fr,
  insert_hydration: Wt,
  noop: ki,
  safe_not_equal: pr,
  set_data: Ml,
  set_style: Pt,
  space: Ci,
  text: Nl,
  toggle_class: Ei
} = window.__gradio__svelte__internal;
function Ai(l, e, t) {
  const n = l.slice();
  return n[13] = e[t], n;
}
function Si(l) {
  let e, t = Fi(
    /*display_items*/
    l[5]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = qi(Ai(l, t, i));
  return {
    c() {
      e = Ft("div");
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      this.h();
    },
    l(i) {
      e = wt(i, "DIV", { class: !0 });
      var a = $t(e);
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      a.forEach(Le), this.h();
    },
    h() {
      Ie(e, "class", "credits-container svelte-141h5y1");
    },
    m(i, a) {
      Wt(i, e, a);
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(e, null);
    },
    p(i, a) {
      if (a & /*display_items, name_style, title_style*/
      56) {
        t = Fi(
          /*display_items*/
          i[5]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const s = Ai(i, t, o);
          n[o] ? n[o].p(s, a) : (n[o] = qi(s), n[o].c(), n[o].m(e, null));
        }
        for (; o < n.length; o += 1)
          n[o].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && Le(e), hr(n, i);
    }
  };
}
function Bi(l) {
  let e, t = (
    /*item*/
    l[13].name + ""
  ), n, i;
  return {
    c() {
      e = Ft("p"), n = Nl(t), this.h();
    },
    l(a) {
      e = wt(a, "P", { style: !0, class: !0 });
      var o = $t(e);
      n = jl(o, t), o.forEach(Le), this.h();
    },
    h() {
      Ie(e, "style", i = /*name_style*/
      l[3](
        /*item*/
        l[13].is_intro
      )), Ie(e, "class", "svelte-141h5y1");
    },
    m(a, o) {
      Wt(a, e, o), ft(e, n);
    },
    p(a, o) {
      o & /*display_items*/
      32 && t !== (t = /*item*/
      a[13].name + "") && Ml(n, t), o & /*name_style, display_items*/
      40 && i !== (i = /*name_style*/
      a[3](
        /*item*/
        a[13].is_intro
      )) && Ie(e, "style", i);
    },
    d(a) {
      a && Le(e);
    }
  };
}
function qi(l) {
  let e, t, n = (
    /*item*/
    l[13].title + ""
  ), i, a, o, s, r = (
    /*item*/
    l[13].name && Bi(l)
  );
  return {
    c() {
      e = Ft("div"), t = Ft("h2"), i = Nl(n), o = Ci(), r && r.c(), s = Ci(), this.h();
    },
    l(u) {
      e = wt(u, "DIV", { class: !0 });
      var _ = $t(e);
      t = wt(_, "H2", { style: !0, class: !0 });
      var d = $t(t);
      i = jl(d, n), d.forEach(Le), o = wi(_), r && r.l(_), s = wi(_), _.forEach(Le), this.h();
    },
    h() {
      Ie(t, "style", a = /*title_style*/
      l[4](
        /*item*/
        l[13].is_intro
      )), Ie(t, "class", "svelte-141h5y1"), Ie(e, "class", "credit svelte-141h5y1"), Ei(
        e,
        "intro-block",
        /*item*/
        l[13].is_intro
      );
    },
    m(u, _) {
      Wt(u, e, _), ft(e, t), ft(t, i), ft(e, o), r && r.m(e, null), ft(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      32 && n !== (n = /*item*/
      u[13].title + "") && Ml(i, n), _ & /*title_style, display_items*/
      48 && a !== (a = /*title_style*/
      u[4](
        /*item*/
        u[13].is_intro
      )) && Ie(t, "style", a), /*item*/
      u[13].name ? r ? r.p(u, _) : (r = Bi(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      32 && Ei(
        e,
        "intro-block",
        /*item*/
        u[13].is_intro
      );
    },
    d(u) {
      u && Le(e), r && r.d();
    }
  };
}
function mr(l) {
  let e, t = `${/*speed*/
  l[0]}s`, n = !/*reset*/
  l[2] && Si(l);
  return {
    c() {
      e = Ft("div"), n && n.c(), this.h();
    },
    l(i) {
      e = wt(i, "DIV", { class: !0 });
      var a = $t(e);
      n && n.l(a), a.forEach(Le), this.h();
    },
    h() {
      Ie(e, "class", "wrapper svelte-141h5y1"), Pt(e, "--animation-duration", t), Pt(
        e,
        "background",
        /*background_color*/
        l[1] || "black"
      );
    },
    m(i, a) {
      Wt(i, e, a), n && n.m(e, null);
    },
    p(i, [a]) {
      /*reset*/
      i[2] ? n && (n.d(1), n = null) : n ? n.p(i, a) : (n = Si(i), n.c(), n.m(e, null)), a & /*speed*/
      1 && t !== (t = `${/*speed*/
      i[0]}s`) && Pt(e, "--animation-duration", t), a & /*background_color*/
      2 && Pt(
        e,
        "background",
        /*background_color*/
        i[1] || "black"
      );
    },
    i: ki,
    o: ki,
    d(i) {
      i && Le(e), n && n.d();
    }
  };
}
function gr(l, e, t) {
  let n, i, a, { credits: o } = e, { speed: s } = e, { base_font_size: r = 1.5 } = e, { background_color: u = null } = e, { title_color: _ = null } = e, { name_color: d = null } = e, { intro_title: c = null } = e, { intro_subtitle: f = null } = e, g = !1;
  function y() {
    t(2, g = !0), setTimeout(() => t(2, g = !1), 0);
  }
  return l.$$set = (m) => {
    "credits" in m && t(6, o = m.credits), "speed" in m && t(0, s = m.speed), "base_font_size" in m && t(7, r = m.base_font_size), "background_color" in m && t(1, u = m.background_color), "title_color" in m && t(8, _ = m.title_color), "name_color" in m && t(9, d = m.name_color), "intro_title" in m && t(10, c = m.intro_title), "intro_subtitle" in m && t(11, f = m.intro_subtitle);
  }, l.$$.update = () => {
    l.$$.dirty & /*intro_title, intro_subtitle, credits*/
    3136 && t(5, n = (() => {
      const m = [];
      return (c || f) && m.push({
        title: c || "",
        name: f || "",
        is_intro: !0
      }), [
        ...m,
        ...o.map(($) => Object.assign(Object.assign({}, $), { is_intro: !1 }))
      ];
    })()), l.$$.dirty & /*title_color, base_font_size*/
    384 && t(4, i = (m) => `color: ${_ || "white"}; font-size: ${m ? r * 1.5 : r}rem;`), l.$$.dirty & /*name_color, base_font_size*/
    640 && t(3, a = (m) => `color: ${d || "white"}; font-size: ${m ? r * 0.9 : r * 0.8}rem;`), l.$$.dirty & /*credits, speed*/
    65 && y();
  }, [
    s,
    u,
    g,
    a,
    i,
    n,
    o,
    r,
    _,
    d,
    c,
    f
  ];
}
class vr extends dr {
  constructor(e) {
    super(), fr(this, e, gr, mr, pr, {
      credits: 6,
      speed: 0,
      base_font_size: 7,
      background_color: 1,
      title_color: 8,
      name_color: 9,
      intro_title: 10,
      intro_subtitle: 11
    });
  }
}
const {
  SvelteComponent: br,
  append_hydration: se,
  attr: ue,
  binding_callbacks: Dr,
  children: Me,
  claim_element: Ne,
  claim_space: bt,
  claim_text: Hl,
  destroy_each: yr,
  detach: De,
  element: He,
  ensure_array_like: Ti,
  init: $r,
  insert_hydration: qn,
  noop: xi,
  safe_not_equal: wr,
  set_data: Vl,
  set_style: Ge,
  space: Dt,
  text: Ul,
  toggle_class: zi
} = window.__gradio__svelte__internal, { onMount: Fr, onDestroy: kr } = window.__gradio__svelte__internal;
function Ii(l, e, t) {
  const n = l.slice();
  return n[18] = e[t], n;
}
function Ri(l) {
  let e, t = (
    /*item*/
    l[18].name + ""
  ), n, i;
  return {
    c() {
      e = He("p"), n = Ul(t), this.h();
    },
    l(a) {
      e = Ne(a, "P", { style: !0, class: !0 });
      var o = Me(e);
      n = Hl(o, t), o.forEach(De), this.h();
    },
    h() {
      ue(e, "style", i = /*name_style*/
      l[4](
        /*item*/
        l[18].is_intro
      )), ue(e, "class", "svelte-1gy01d0");
    },
    m(a, o) {
      qn(a, e, o), se(e, n);
    },
    p(a, o) {
      o & /*display_items*/
      8 && t !== (t = /*item*/
      a[18].name + "") && Vl(n, t), o & /*name_style, display_items*/
      24 && i !== (i = /*name_style*/
      a[4](
        /*item*/
        a[18].is_intro
      )) && ue(e, "style", i);
    },
    d(a) {
      a && De(e);
    }
  };
}
function Li(l) {
  let e, t, n = (
    /*item*/
    l[18].title + ""
  ), i, a, o, s, r = (
    /*item*/
    l[18].name && Ri(l)
  );
  return {
    c() {
      e = He("div"), t = He("h2"), i = Ul(n), o = Dt(), r && r.c(), s = Dt(), this.h();
    },
    l(u) {
      e = Ne(u, "DIV", { class: !0 });
      var _ = Me(e);
      t = Ne(_, "H2", { style: !0, class: !0 });
      var d = Me(t);
      i = Hl(d, n), d.forEach(De), o = bt(_), r && r.l(_), s = bt(_), _.forEach(De), this.h();
    },
    h() {
      ue(t, "style", a = /*title_style*/
      l[5](
        /*item*/
        l[18].is_intro
      )), ue(t, "class", "svelte-1gy01d0"), ue(e, "class", "credit svelte-1gy01d0"), zi(
        e,
        "intro-block",
        /*item*/
        l[18].is_intro
      );
    },
    m(u, _) {
      qn(u, e, _), se(e, t), se(t, i), se(e, o), r && r.m(e, null), se(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      8 && n !== (n = /*item*/
      u[18].title + "") && Vl(i, n), _ & /*title_style, display_items*/
      40 && a !== (a = /*title_style*/
      u[5](
        /*item*/
        u[18].is_intro
      )) && ue(t, "style", a), /*item*/
      u[18].name ? r ? r.p(u, _) : (r = Ri(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      8 && zi(
        e,
        "intro-block",
        /*item*/
        u[18].is_intro
      );
    },
    d(u) {
      u && De(e), r && r.d();
    }
  };
}
function Cr(l) {
  let e, t, n, i, a, o, s, r, u = Ti(
    /*display_items*/
    l[3]
  ), _ = [];
  for (let d = 0; d < u.length; d += 1)
    _[d] = Li(Ii(l, u, d));
  return {
    c() {
      e = He("div"), t = He("div"), n = Dt(), i = He("div"), a = Dt(), o = He("div"), s = Dt(), r = He("div");
      for (let d = 0; d < _.length; d += 1)
        _[d].c();
      this.h();
    },
    l(d) {
      e = Ne(d, "DIV", { class: !0 });
      var c = Me(e);
      t = Ne(c, "DIV", { class: !0, style: !0 }), Me(t).forEach(De), n = bt(c), i = Ne(c, "DIV", { class: !0, style: !0 }), Me(i).forEach(De), a = bt(c), o = Ne(c, "DIV", { class: !0, style: !0 }), Me(o).forEach(De), s = bt(c), r = Ne(c, "DIV", { class: !0, style: !0 });
      var f = Me(r);
      for (let g = 0; g < _.length; g += 1)
        _[g].l(f);
      f.forEach(De), c.forEach(De), this.h();
    },
    h() {
      ue(t, "class", "stars small svelte-1gy01d0"), Ge(
        t,
        "box-shadow",
        /*small_stars*/
        l[6]
      ), ue(i, "class", "stars medium svelte-1gy01d0"), Ge(
        i,
        "box-shadow",
        /*medium_stars*/
        l[7]
      ), ue(o, "class", "stars large svelte-1gy01d0"), Ge(
        o,
        "box-shadow",
        /*large_stars*/
        l[8]
      ), ue(r, "class", "crawl svelte-1gy01d0"), Ge(
        r,
        "--animation-duration",
        /*speed*/
        l[0] + "s"
      ), ue(e, "class", "viewport svelte-1gy01d0"), Ge(
        e,
        "background",
        /*background_color*/
        l[1] || "black"
      );
    },
    m(d, c) {
      qn(d, e, c), se(e, t), se(e, n), se(e, i), se(e, a), se(e, o), se(e, s), se(e, r);
      for (let f = 0; f < _.length; f += 1)
        _[f] && _[f].m(r, null);
      l[15](r);
    },
    p(d, [c]) {
      if (c & /*display_items, name_style, title_style*/
      56) {
        u = Ti(
          /*display_items*/
          d[3]
        );
        let f;
        for (f = 0; f < u.length; f += 1) {
          const g = Ii(d, u, f);
          _[f] ? _[f].p(g, c) : (_[f] = Li(g), _[f].c(), _[f].m(r, null));
        }
        for (; f < _.length; f += 1)
          _[f].d(1);
        _.length = u.length;
      }
      c & /*speed*/
      1 && Ge(
        r,
        "--animation-duration",
        /*speed*/
        d[0] + "s"
      ), c & /*background_color*/
      2 && Ge(
        e,
        "background",
        /*background_color*/
        d[1] || "black"
      );
    },
    i: xi,
    o: xi,
    d(d) {
      d && De(e), yr(_, d), l[15](null);
    }
  };
}
function Er(l, e, t) {
  let n, i, a, { credits: o } = e, { speed: s = 40 } = e, { base_font_size: r = 1.5 } = e, { background_color: u = null } = e, { title_color: _ = null } = e, { name_color: d = null } = e, { intro_title: c = null } = e, { intro_subtitle: f = null } = e, g;
  function y() {
    g && (t(2, g.style.animation = "none", g), g.offsetHeight, t(2, g.style.animation = "", g));
  }
  Fr(() => (y(), () => {
  })), kr(() => {
    t(2, g = null);
  });
  const m = (v, D) => {
    let w = "";
    for (let S = 0; S < v; S++)
      w += `${Math.random() * 2e3}px ${Math.random() * 2e3}px ${D} white, `;
    return w.slice(0, -2);
  }, $ = m(200, "1px"), p = m(100, "2px"), h = m(50, "3px");
  function b(v) {
    Dr[v ? "unshift" : "push"](() => {
      g = v, t(2, g);
    });
  }
  return l.$$set = (v) => {
    "credits" in v && t(9, o = v.credits), "speed" in v && t(0, s = v.speed), "base_font_size" in v && t(10, r = v.base_font_size), "background_color" in v && t(1, u = v.background_color), "title_color" in v && t(11, _ = v.title_color), "name_color" in v && t(12, d = v.name_color), "intro_title" in v && t(13, c = v.intro_title), "intro_subtitle" in v && t(14, f = v.intro_subtitle);
  }, l.$$.update = () => {
    l.$$.dirty & /*title_color, base_font_size*/
    3072 && t(5, n = (v) => `color: ${_ || "#feda4a"}; font-size: ${v ? r * 1.5 : r}rem !important;`), l.$$.dirty & /*name_color, base_font_size*/
    5120 && t(4, i = (v) => `color: ${d || "#feda4a"}; font-size: ${v ? r * 0.9 : r * 0.7}rem !important;`), l.$$.dirty & /*intro_title, intro_subtitle, credits*/
    25088 && t(3, a = (() => {
      const v = [];
      return (c || f) && v.push({
        title: c || "",
        name: f || "",
        is_intro: !0
      }), [
        ...v,
        ...o.map((D) => Object.assign(Object.assign({}, D), { is_intro: !1 }))
      ];
    })()), l.$$.dirty & /*credits, speed, base_font_size, background_color, title_color, name_color, intro_title, intro_subtitle*/
    32259 && y();
  }, [
    s,
    u,
    g,
    a,
    i,
    n,
    $,
    p,
    h,
    o,
    r,
    _,
    d,
    c,
    f,
    b
  ];
}
class Ar extends br {
  constructor(e) {
    super(), $r(this, e, Er, Cr, wr, {
      credits: 9,
      speed: 0,
      base_font_size: 10,
      background_color: 1,
      title_color: 11,
      name_color: 12,
      intro_title: 13,
      intro_subtitle: 14
    });
  }
}
const {
  SvelteComponent: Sr,
  append_hydration: Re,
  attr: we,
  binding_callbacks: Oi,
  children: Xe,
  claim_element: Ye,
  claim_space: vn,
  claim_text: Gl,
  destroy_each: Br,
  detach: Ce,
  element: We,
  ensure_array_like: Pi,
  init: qr,
  insert_hydration: Tn,
  noop: ji,
  safe_not_equal: Tr,
  set_data: Zl,
  set_style: Mi,
  space: bn,
  text: Xl,
  toggle_class: Ni
} = window.__gradio__svelte__internal, { onMount: xr, onDestroy: zr } = window.__gradio__svelte__internal;
function Hi(l, e, t) {
  const n = l.slice();
  return n[19] = e[t], n;
}
function Vi(l) {
  let e, t = (
    /*item*/
    l[19].name + ""
  ), n, i;
  return {
    c() {
      e = We("div"), n = Xl(t), this.h();
    },
    l(a) {
      e = Ye(a, "DIV", { style: !0, class: !0 });
      var o = Xe(e);
      n = Gl(o, t), o.forEach(Ce), this.h();
    },
    h() {
      we(e, "style", i = /*name_style*/
      l[3](
        /*item*/
        l[19].is_intro
      )), we(e, "class", "name svelte-8jsw80");
    },
    m(a, o) {
      Tn(a, e, o), Re(e, n);
    },
    p(a, o) {
      o & /*display_items*/
      32 && t !== (t = /*item*/
      a[19].name + "") && Zl(n, t), o & /*name_style, display_items*/
      40 && i !== (i = /*name_style*/
      a[3](
        /*item*/
        a[19].is_intro
      )) && we(e, "style", i);
    },
    d(a) {
      a && Ce(e);
    }
  };
}
function Ui(l) {
  let e, t, n = (
    /*item*/
    l[19].title + ""
  ), i, a, o, s, r = (
    /*item*/
    l[19].name && Vi(l)
  );
  return {
    c() {
      e = We("div"), t = We("div"), i = Xl(n), o = bn(), r && r.c(), s = bn(), this.h();
    },
    l(u) {
      e = Ye(u, "DIV", { class: !0 });
      var _ = Xe(e);
      t = Ye(_, "DIV", { style: !0, class: !0 });
      var d = Xe(t);
      i = Gl(d, n), d.forEach(Ce), o = vn(_), r && r.l(_), s = vn(_), _.forEach(Ce), this.h();
    },
    h() {
      we(t, "style", a = /*title_style*/
      l[4](
        /*item*/
        l[19].is_intro
      )), we(t, "class", "title svelte-8jsw80"), we(e, "class", "credit-block svelte-8jsw80"), Ni(
        e,
        "intro-block",
        /*item*/
        l[19].is_intro
      );
    },
    m(u, _) {
      Tn(u, e, _), Re(e, t), Re(t, i), Re(e, o), r && r.m(e, null), Re(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      32 && n !== (n = /*item*/
      u[19].title + "") && Zl(i, n), _ & /*title_style, display_items*/
      48 && a !== (a = /*title_style*/
      u[4](
        /*item*/
        u[19].is_intro
      )) && we(t, "style", a), /*item*/
      u[19].name ? r ? r.p(u, _) : (r = Vi(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      32 && Ni(
        e,
        "intro-block",
        /*item*/
        u[19].is_intro
      );
    },
    d(u) {
      u && Ce(e), r && r.d();
    }
  };
}
function Ir(l) {
  let e, t, n, i, a, o = Pi(
    /*display_items*/
    l[5]
  ), s = [];
  for (let r = 0; r < o.length; r += 1)
    s[r] = Ui(Hi(l, o, r));
  return {
    c() {
      e = We("div"), t = We("canvas"), n = bn(), i = We("div"), a = We("div");
      for (let r = 0; r < s.length; r += 1)
        s[r].c();
      this.h();
    },
    l(r) {
      e = Ye(r, "DIV", { class: !0 });
      var u = Xe(e);
      t = Ye(u, "CANVAS", { class: !0 }), Xe(t).forEach(Ce), n = vn(u), i = Ye(u, "DIV", { class: !0 });
      var _ = Xe(i);
      a = Ye(_, "DIV", { class: !0, style: !0 });
      var d = Xe(a);
      for (let c = 0; c < s.length; c += 1)
        s[c].l(d);
      d.forEach(Ce), _.forEach(Ce), u.forEach(Ce), this.h();
    },
    h() {
      we(t, "class", "svelte-8jsw80"), we(a, "class", "credits-content svelte-8jsw80"), Mi(
        a,
        "--animation-duration",
        /*speed*/
        l[0] + "s"
      ), we(i, "class", "credits-scroll-overlay svelte-8jsw80"), we(e, "class", "matrix-container svelte-8jsw80");
    },
    m(r, u) {
      Tn(r, e, u), Re(e, t), l[10](t), Re(e, n), Re(e, i), Re(i, a);
      for (let _ = 0; _ < s.length; _ += 1)
        s[_] && s[_].m(a, null);
      l[11](a);
    },
    p(r, [u]) {
      if (u & /*display_items, name_style, title_style*/
      56) {
        o = Pi(
          /*display_items*/
          r[5]
        );
        let _;
        for (_ = 0; _ < o.length; _ += 1) {
          const d = Hi(r, o, _);
          s[_] ? s[_].p(d, u) : (s[_] = Ui(d), s[_].c(), s[_].m(a, null));
        }
        for (; _ < s.length; _ += 1)
          s[_].d(1);
        s.length = o.length;
      }
      u & /*speed*/
      1 && Mi(
        a,
        "--animation-duration",
        /*speed*/
        r[0] + "s"
      );
    },
    i: ji,
    o: ji,
    d(r) {
      r && Ce(e), l[10](null), Br(s, r), l[11](null);
    }
  };
}
const ht = 16, Gi = "アァカサタナハマヤャラワガザダバパイィキシチニヒミリヰギジヂビピウゥクスツヌフムユュルグズブヅプエェケセテネヘメレヱゲゼデベペオォコソトノホモヨョロヲゴゾドボポヴッン01";
function Rr(l, e, t) {
  let n, i, a, { credits: o } = e, { speed: s = 20 } = e, { base_font_size: r = 1 } = e, { intro_title: u = null } = e, { intro_subtitle: _ = null } = e, d, c, f, g, y = [], m;
  function $() {
    if (!d) return;
    const D = d.parentElement;
    D && (t(1, d.width = D.clientWidth, d), t(1, d.height = D.clientHeight, d)), c = d.getContext("2d"), g = Math.floor(d.width / ht), y = Array(g).fill(1);
  }
  function p() {
    if (c) {
      c.fillStyle = "rgba(0, 0, 0, 0.05)", c.fillRect(0, 0, d.width, d.height), c.fillStyle = "#0F0", c.font = `${ht}px monospace`;
      for (let D = 0; D < y.length; D++) {
        const w = Gi.charAt(Math.floor(Math.random() * Gi.length));
        c.fillText(w, D * ht, y[D] * ht), y[D] * ht > d.height && Math.random() > 0.975 && (y[D] = 0), y[D]++;
      }
      m = requestAnimationFrame(p);
    }
  }
  function h() {
    f && (t(2, f.style.animation = "none", f), f.offsetHeight, t(2, f.style.animation = "", f));
  }
  xr(() => {
    $(), p(), h();
    const D = new ResizeObserver(() => {
      cancelAnimationFrame(m), $(), p();
    });
    return d.parentElement && D.observe(d.parentElement), () => {
      cancelAnimationFrame(m), d.parentElement && D.unobserve(d.parentElement);
    };
  }), zr(() => {
    t(2, f = null);
  });
  function b(D) {
    Oi[D ? "unshift" : "push"](() => {
      d = D, t(1, d);
    });
  }
  function v(D) {
    Oi[D ? "unshift" : "push"](() => {
      f = D, t(2, f);
    });
  }
  return l.$$set = (D) => {
    "credits" in D && t(6, o = D.credits), "speed" in D && t(0, s = D.speed), "base_font_size" in D && t(7, r = D.base_font_size), "intro_title" in D && t(8, u = D.intro_title), "intro_subtitle" in D && t(9, _ = D.intro_subtitle);
  }, l.$$.update = () => {
    l.$$.dirty & /*intro_title, intro_subtitle, credits*/
    832 && t(5, n = (() => {
      const D = [];
      return (u || _) && D.push({
        title: u || "",
        name: _ || "",
        is_intro: !0
      }), [
        ...D,
        ...o.map((w) => Object.assign(Object.assign({}, w), { is_intro: !1 }))
      ];
    })()), l.$$.dirty & /*base_font_size*/
    128 && t(4, i = (D) => `font-size: ${D ? r * 1.2 : r * 0.8}em;`), l.$$.dirty & /*base_font_size*/
    128 && t(3, a = (D) => `font-size: ${D ? r * 1.5 : r}em;`), l.$$.dirty & /*credits, speed, intro_title, intro_subtitle*/
    833 && h();
  }, [
    s,
    d,
    f,
    a,
    i,
    n,
    o,
    r,
    u,
    _,
    b,
    v
  ];
}
class Lr extends Sr {
  constructor(e) {
    super(), qr(this, e, Rr, Ir, Tr, {
      credits: 6,
      speed: 0,
      base_font_size: 7,
      intro_title: 8,
      intro_subtitle: 9
    });
  }
}
const { setContext: bC, getContext: Or } = window.__gradio__svelte__internal, Pr = "WORKER_PROXY_CONTEXT_KEY";
function jr() {
  return Or(Pr);
}
const Mr = "lite.local";
function Nr(l) {
  return l.host === window.location.host || l.host === "localhost:7860" || l.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  l.host === Mr;
}
function Hr(l, e) {
  const t = e.toLowerCase();
  for (const [n, i] of Object.entries(l))
    if (n.toLowerCase() === t)
      return i;
}
function Vr(l) {
  const e = typeof window < "u";
  if (l == null || !e)
    return !1;
  const t = new URL(l, window.location.href);
  return !(!Nr(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
let jt;
async function Ur(l) {
  const e = typeof window < "u";
  if (l == null || !e || !Vr(l))
    return l;
  if (jt == null)
    try {
      jt = jr();
    } catch {
      return l;
    }
  if (jt == null)
    return l;
  const n = new URL(l, window.location.href).pathname;
  return jt.httpRequest({
    method: "GET",
    path: n,
    headers: {},
    query_string: ""
  }).then((i) => {
    if (i.status !== 200)
      throw new Error(`Failed to get file ${n} from the Wasm worker.`);
    const a = new Blob([i.body], {
      type: Hr(i.headers, "content-type")
    });
    return URL.createObjectURL(a);
  });
}
const {
  SvelteComponent: DC,
  assign: yC,
  check_outros: $C,
  children: wC,
  claim_element: FC,
  compute_rest_props: kC,
  create_slot: CC,
  detach: EC,
  element: AC,
  empty: SC,
  exclude_internal_props: BC,
  get_all_dirty_from_scope: qC,
  get_slot_changes: TC,
  get_spread_update: xC,
  group_outros: zC,
  init: IC,
  insert_hydration: RC,
  listen: LC,
  prevent_default: OC,
  safe_not_equal: PC,
  set_attributes: jC,
  set_style: MC,
  toggle_class: NC,
  transition_in: HC,
  transition_out: VC,
  update_slot_base: UC
} = window.__gradio__svelte__internal, { createEventDispatcher: GC, onMount: ZC } = window.__gradio__svelte__internal, {
  SvelteComponent: Gr,
  assign: Dn,
  bubble: Zr,
  claim_element: Xr,
  compute_rest_props: Zi,
  detach: Yr,
  element: Wr,
  exclude_internal_props: Kr,
  get_spread_update: Qr,
  init: Jr,
  insert_hydration: es,
  listen: ts,
  noop: Xi,
  safe_not_equal: ns,
  set_attributes: Yi,
  src_url_equal: is,
  toggle_class: Wi
} = window.__gradio__svelte__internal;
function ls(l) {
  let e, t, n, i, a = [
    {
      src: t = /*resolved_src*/
      l[0]
    },
    /*$$restProps*/
    l[1]
  ], o = {};
  for (let s = 0; s < a.length; s += 1)
    o = Dn(o, a[s]);
  return {
    c() {
      e = Wr("img"), this.h();
    },
    l(s) {
      e = Xr(s, "IMG", { src: !0 }), this.h();
    },
    h() {
      Yi(e, o), Wi(e, "svelte-kxeri3", !0);
    },
    m(s, r) {
      es(s, e, r), n || (i = ts(
        e,
        "load",
        /*load_handler*/
        l[4]
      ), n = !0);
    },
    p(s, [r]) {
      Yi(e, o = Qr(a, [
        r & /*resolved_src*/
        1 && !is(e.src, t = /*resolved_src*/
        s[0]) && { src: t },
        r & /*$$restProps*/
        2 && /*$$restProps*/
        s[1]
      ])), Wi(e, "svelte-kxeri3", !0);
    },
    i: Xi,
    o: Xi,
    d(s) {
      s && Yr(e), n = !1, i();
    }
  };
}
function os(l, e, t) {
  const n = ["src"];
  let i = Zi(e, n), { src: a = void 0 } = e, o, s;
  function r(u) {
    Zr.call(this, l, u);
  }
  return l.$$set = (u) => {
    e = Dn(Dn({}, e), Kr(u)), t(1, i = Zi(e, n)), "src" in u && t(2, a = u.src);
  }, l.$$.update = () => {
    if (l.$$.dirty & /*src, latest_src*/
    12) {
      t(0, o = a), t(3, s = a);
      const u = a;
      Ur(u).then((_) => {
        s === u && t(0, o = _);
      });
    }
  }, [o, i, a, s, r];
}
class as extends Gr {
  constructor(e) {
    super(), Jr(this, e, os, ls, ns, { src: 2 });
  }
}
const {
  SvelteComponent: XC,
  append_hydration: YC,
  attr: WC,
  binding_callbacks: KC,
  bubble: QC,
  check_outros: JC,
  children: e3,
  claim_component: t3,
  claim_element: n3,
  claim_space: i3,
  create_component: l3,
  destroy_component: o3,
  detach: a3,
  element: r3,
  empty: s3,
  group_outros: u3,
  init: _3,
  insert_hydration: c3,
  listen: d3,
  mount_component: h3,
  safe_not_equal: f3,
  space: p3,
  toggle_class: m3,
  transition_in: g3,
  transition_out: v3
} = window.__gradio__svelte__internal, { createEventDispatcher: b3, onMount: D3 } = window.__gradio__svelte__internal, {
  SvelteComponent: rs,
  append_hydration: J,
  attr: Y,
  check_outros: ot,
  children: de,
  claim_component: rt,
  claim_element: W,
  claim_space: Oe,
  claim_text: yn,
  create_component: st,
  create_slot: ss,
  destroy_block: us,
  destroy_component: ut,
  detach: z,
  element: K,
  empty: Zt,
  ensure_array_like: Ki,
  get_all_dirty_from_scope: _s,
  get_slot_changes: cs,
  get_svelte_dataset: xn,
  group_outros: at,
  head_selector: ds,
  init: hs,
  insert_hydration: ee,
  listen: fs,
  mount_component: _t,
  noop: kt,
  safe_not_equal: Xt,
  set_data: $n,
  set_style: P,
  space: Pe,
  src_url_equal: Qi,
  text: wn,
  toggle_class: Ji,
  transition_in: H,
  transition_out: V,
  update_keyed_each: ps,
  update_slot_base: ms
} = window.__gradio__svelte__internal;
function el(l, e, t) {
  const n = l.slice();
  return n[24] = e[t][0], n[25] = e[t][1], n;
}
function tl(l) {
  let e, t, n, i;
  const a = [vs, gs], o = [];
  function s(r, u) {
    return (
      /*gradio*/
      r[7] ? 0 : 1
    );
  }
  return t = s(l), n = o[t] = a[t](l), {
    c() {
      e = K("div"), n.c(), this.h();
    },
    l(r) {
      e = W(r, "DIV", { class: !0 });
      var u = de(e);
      n.l(u), u.forEach(z), this.h();
    },
    h() {
      Y(e, "class", "logo-panel svelte-1ewbjj5"), P(
        e,
        "height",
        /*logo_panel_height*/
        l[12]
      ), P(e, "display", "flex"), P(
        e,
        "justify-content",
        /*logo_justify*/
        l[10]
      );
    },
    m(r, u) {
      ee(r, e, u), o[t].m(e, null), i = !0;
    },
    p(r, u) {
      let _ = t;
      t = s(r), t === _ ? o[t].p(r, u) : (at(), V(o[_], 1, 1, () => {
        o[_] = null;
      }), ot(), n = o[t], n ? n.p(r, u) : (n = o[t] = a[t](r), n.c()), H(n, 1), n.m(e, null)), u & /*logo_panel_height*/
      4096 && P(
        e,
        "height",
        /*logo_panel_height*/
        r[12]
      ), u & /*logo_justify*/
      1024 && P(
        e,
        "justify-content",
        /*logo_justify*/
        r[10]
      );
    },
    i(r) {
      i || (H(n), i = !0);
    },
    o(r) {
      V(n), i = !1;
    },
    d(r) {
      r && z(e), o[t].d();
    }
  };
}
function gs(l) {
  let e, t;
  return {
    c() {
      e = K("img"), this.h();
    },
    l(n) {
      e = W(n, "IMG", { src: !0, alt: !0, style: !0 }), this.h();
    },
    h() {
      Qi(e.src, t = /*effectiveValue*/
      l[8].logo_path.url) || Y(e, "src", t), Y(e, "alt", "Logo"), P(
        e,
        "width",
        /*logo_width_style*/
        l[14]
      ), P(
        e,
        "height",
        /*logo_height_style*/
        l[13]
      ), P(
        e,
        "object-fit",
        /*object_fit*/
        l[11]
      );
    },
    m(n, i) {
      ee(n, e, i);
    },
    p(n, i) {
      i & /*effectiveValue*/
      256 && !Qi(e.src, t = /*effectiveValue*/
      n[8].logo_path.url) && Y(e, "src", t), i & /*logo_width_style*/
      16384 && P(
        e,
        "width",
        /*logo_width_style*/
        n[14]
      ), i & /*logo_height_style*/
      8192 && P(
        e,
        "height",
        /*logo_height_style*/
        n[13]
      ), i & /*object_fit*/
      2048 && P(
        e,
        "object-fit",
        /*object_fit*/
        n[11]
      );
    },
    i: kt,
    o: kt,
    d(n) {
      n && z(e);
    }
  };
}
function vs(l) {
  let e, t;
  return e = new as({
    props: {
      src: (
        /*effectiveValue*/
        l[8].logo_path.url
      ),
      alt: "Logo",
      loading: "lazy",
      gradio: (
        /*gradio*/
        l[7]
      ),
      style: "width: " + /*logo_width_style*/
      l[14] + "; height: " + /*logo_height_style*/
      l[13] + "; object-fit: " + /*object_fit*/
      l[11] + ";"
    }
  }), {
    c() {
      st(e.$$.fragment);
    },
    l(n) {
      rt(e.$$.fragment, n);
    },
    m(n, i) {
      _t(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*effectiveValue*/
      256 && (a.src = /*effectiveValue*/
      n[8].logo_path.url), i & /*gradio*/
      128 && (a.gradio = /*gradio*/
      n[7]), i & /*logo_width_style, logo_height_style, object_fit*/
      26624 && (a.style = "width: " + /*logo_width_style*/
      n[14] + "; height: " + /*logo_height_style*/
      n[13] + "; object-fit: " + /*object_fit*/
      n[11] + ";"), e.$set(a);
    },
    i(n) {
      t || (H(e.$$.fragment, n), t = !0);
    },
    o(n) {
      V(e.$$.fragment, n), t = !1;
    },
    d(n) {
      ut(e, n);
    }
  };
}
function nl(l) {
  var i;
  let e, t, n = (
    /*effectiveValue*/
    l[8].show_logo && /*effectiveValue*/
    ((i = l[8].logo_path) == null ? void 0 : i.url) && tl(l)
  );
  return {
    c() {
      e = K("div"), n && n.c(), this.h();
    },
    l(a) {
      e = W(a, "DIV", { class: !0 });
      var o = de(e);
      n && n.l(o), o.forEach(z), this.h();
    },
    h() {
      Y(e, "class", "outer-logo-wrapper svelte-1ewbjj5"), P(
        e,
        "width",
        /*width_style*/
        l[15]
      );
    },
    m(a, o) {
      ee(a, e, o), n && n.m(e, null), t = !0;
    },
    p(a, o) {
      var s;
      /*effectiveValue*/
      a[8].show_logo && /*effectiveValue*/
      ((s = a[8].logo_path) != null && s.url) ? n ? (n.p(a, o), o & /*effectiveValue*/
      256 && H(n, 1)) : (n = tl(a), n.c(), H(n, 1), n.m(e, null)) : n && (at(), V(n, 1, 1, () => {
        n = null;
      }), ot()), o & /*width_style*/
      32768 && P(
        e,
        "width",
        /*width_style*/
        a[15]
      );
    },
    i(a) {
      t || (H(n), t = !0);
    },
    o(a) {
      V(n), t = !1;
    },
    d(a) {
      a && z(e), n && n.d();
    }
  };
}
function bs(l) {
  let e, t;
  return e = new Lr({
    props: {
      credits: (
        /*effectiveValue*/
        l[8].credits
      ),
      speed: (
        /*effectiveValue*/
        l[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        l[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        l[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        l[8].intro_subtitle
      )
    }
  }), {
    c() {
      st(e.$$.fragment);
    },
    l(n) {
      rt(e.$$.fragment, n);
    },
    m(n, i) {
      _t(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*effectiveValue*/
      256 && (a.credits = /*effectiveValue*/
      n[8].credits), i & /*effectiveValue*/
      256 && (a.speed = /*effectiveValue*/
      n[8].speed), i & /*effectiveValue*/
      256 && (a.base_font_size = /*effectiveValue*/
      n[8].base_font_size), i & /*effectiveValue*/
      256 && (a.intro_title = /*effectiveValue*/
      n[8].intro_title), i & /*effectiveValue*/
      256 && (a.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), e.$set(a);
    },
    i(n) {
      t || (H(e.$$.fragment, n), t = !0);
    },
    o(n) {
      V(e.$$.fragment, n), t = !1;
    },
    d(n) {
      ut(e, n);
    }
  };
}
function Ds(l) {
  let e, t;
  return e = new Ar({
    props: {
      credits: (
        /*effectiveValue*/
        l[8].credits
      ),
      speed: (
        /*effectiveValue*/
        l[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        l[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        l[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        l[8].intro_subtitle
      )
    }
  }), {
    c() {
      st(e.$$.fragment);
    },
    l(n) {
      rt(e.$$.fragment, n);
    },
    m(n, i) {
      _t(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*effectiveValue*/
      256 && (a.credits = /*effectiveValue*/
      n[8].credits), i & /*effectiveValue*/
      256 && (a.speed = /*effectiveValue*/
      n[8].speed), i & /*effectiveValue*/
      256 && (a.base_font_size = /*effectiveValue*/
      n[8].base_font_size), i & /*effectiveValue*/
      256 && (a.intro_title = /*effectiveValue*/
      n[8].intro_title), i & /*effectiveValue*/
      256 && (a.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), e.$set(a);
    },
    i(n) {
      t || (H(e.$$.fragment, n), t = !0);
    },
    o(n) {
      V(e.$$.fragment, n), t = !1;
    },
    d(n) {
      ut(e, n);
    }
  };
}
function ys(l) {
  let e, t;
  return e = new vr({
    props: {
      credits: (
        /*effectiveValue*/
        l[8].credits
      ),
      speed: (
        /*effectiveValue*/
        l[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        l[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        l[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        l[8].intro_subtitle
      ),
      background_color: (
        /*effectiveValue*/
        l[8].scroll_background_color
      ),
      title_color: (
        /*effectiveValue*/
        l[8].scroll_title_color
      ),
      name_color: (
        /*effectiveValue*/
        l[8].scroll_name_color
      )
    }
  }), {
    c() {
      st(e.$$.fragment);
    },
    l(n) {
      rt(e.$$.fragment, n);
    },
    m(n, i) {
      _t(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*effectiveValue*/
      256 && (a.credits = /*effectiveValue*/
      n[8].credits), i & /*effectiveValue*/
      256 && (a.speed = /*effectiveValue*/
      n[8].speed), i & /*effectiveValue*/
      256 && (a.base_font_size = /*effectiveValue*/
      n[8].base_font_size), i & /*effectiveValue*/
      256 && (a.intro_title = /*effectiveValue*/
      n[8].intro_title), i & /*effectiveValue*/
      256 && (a.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), i & /*effectiveValue*/
      256 && (a.background_color = /*effectiveValue*/
      n[8].scroll_background_color), i & /*effectiveValue*/
      256 && (a.title_color = /*effectiveValue*/
      n[8].scroll_title_color), i & /*effectiveValue*/
      256 && (a.name_color = /*effectiveValue*/
      n[8].scroll_name_color), e.$set(a);
    },
    i(n) {
      t || (H(e.$$.fragment, n), t = !0);
    },
    o(n) {
      V(e.$$.fragment, n), t = !1;
    },
    d(n) {
      ut(e, n);
    }
  };
}
function il(l) {
  let e, t, n, i;
  const a = [ys, Ds, bs], o = [];
  function s(r, u) {
    return (
      /*effectiveValue*/
      r[8].effect === "scroll" ? 0 : (
        /*effectiveValue*/
        r[8].effect === "starwars" ? 1 : (
          /*effectiveValue*/
          r[8].effect === "matrix" ? 2 : -1
        )
      )
    );
  }
  return ~(t = s(l)) && (n = o[t] = a[t](l)), {
    c() {
      e = K("div"), n && n.c(), this.h();
    },
    l(r) {
      e = W(r, "DIV", { class: !0 });
      var u = de(e);
      n && n.l(u), u.forEach(z), this.h();
    },
    h() {
      Y(e, "class", "main-credits-panel svelte-1ewbjj5"), P(
        e,
        "height",
        /*height_style*/
        l[16]
      ), P(
        e,
        "width",
        /*effectiveValue*/
        l[8].sidebar_position === "right" && /*effectiveValue*/
        l[8].show_licenses ? "calc(100% - var(--sidebar-width, 400px))" : (
          /*width_style*/
          l[15]
        )
      );
    },
    m(r, u) {
      ee(r, e, u), ~t && o[t].m(e, null), i = !0;
    },
    p(r, u) {
      let _ = t;
      t = s(r), t === _ ? ~t && o[t].p(r, u) : (n && (at(), V(o[_], 1, 1, () => {
        o[_] = null;
      }), ot()), ~t ? (n = o[t], n ? n.p(r, u) : (n = o[t] = a[t](r), n.c()), H(n, 1), n.m(e, null)) : n = null), u & /*height_style*/
      65536 && P(
        e,
        "height",
        /*height_style*/
        r[16]
      ), u & /*effectiveValue, width_style*/
      33024 && P(
        e,
        "width",
        /*effectiveValue*/
        r[8].sidebar_position === "right" && /*effectiveValue*/
        r[8].show_licenses ? "calc(100% - var(--sidebar-width, 400px))" : (
          /*width_style*/
          r[15]
        )
      );
    },
    i(r) {
      i || (H(n), i = !0);
    },
    o(r) {
      V(n), i = !1;
    },
    d(r) {
      r && z(e), ~t && o[t].d();
    }
  };
}
function ll(l) {
  let e, t, n = "Licenses", i, a, o = [], s = /* @__PURE__ */ new Map(), r, u = Ki(Object.entries(
    /*effectiveValue*/
    l[8].licenses
  ));
  const _ = (c) => (
    /*name*/
    c[24]
  );
  for (let c = 0; c < u.length; c += 1) {
    let f = el(l, u, c), g = _(f);
    s.set(g, o[c] = ol(g, f));
  }
  let d = (
    /*selected_license_name*/
    l[9] && al(l)
  );
  return {
    c() {
      e = K("div"), t = K("h3"), t.textContent = n, i = Pe(), a = K("ul");
      for (let c = 0; c < o.length; c += 1)
        o[c].c();
      r = Pe(), d && d.c(), this.h();
    },
    l(c) {
      e = W(c, "DIV", { class: !0 });
      var f = de(e);
      t = W(f, "H3", { class: !0, "data-svelte-h": !0 }), xn(t) !== "svelte-1txs4lo" && (t.textContent = n), i = Oe(f), a = W(f, "UL", {});
      var g = de(a);
      for (let y = 0; y < o.length; y += 1)
        o[y].l(g);
      g.forEach(z), r = Oe(f), d && d.l(f), f.forEach(z), this.h();
    },
    h() {
      Y(t, "class", "svelte-1ewbjj5"), Y(e, "class", "licenses-sidebar svelte-1ewbjj5");
    },
    m(c, f) {
      ee(c, e, f), J(e, t), J(e, i), J(e, a);
      for (let g = 0; g < o.length; g += 1)
        o[g] && o[g].m(a, null);
      J(e, r), d && d.m(e, null);
    },
    p(c, f) {
      f & /*selected_license_name, Object, effectiveValue, show_license*/
      131840 && (u = Ki(Object.entries(
        /*effectiveValue*/
        c[8].licenses
      )), o = ps(o, f, _, 1, c, u, s, a, us, ol, null, el)), /*selected_license_name*/
      c[9] ? d ? d.p(c, f) : (d = al(c), d.c(), d.m(e, null)) : d && (d.d(1), d = null);
    },
    d(c) {
      c && z(e);
      for (let f = 0; f < o.length; f += 1)
        o[f].d();
      d && d.d();
    }
  };
}
function ol(l, e) {
  let t, n, i = (
    /*name*/
    e[24] + ""
  ), a, o, s, r;
  function u() {
    return (
      /*click_handler*/
      e[22](
        /*name*/
        e[24]
      )
    );
  }
  return {
    key: l,
    first: null,
    c() {
      t = K("li"), n = K("button"), a = wn(i), o = Pe(), this.h();
    },
    l(_) {
      t = W(_, "LI", { class: !0 });
      var d = de(t);
      n = W(d, "BUTTON", { type: !0, class: !0 });
      var c = de(n);
      a = yn(c, i), c.forEach(z), o = Oe(d), d.forEach(z), this.h();
    },
    h() {
      Y(n, "type", "button"), Y(n, "class", "svelte-1ewbjj5"), Ji(
        n,
        "selected",
        /*selected_license_name*/
        e[9] === /*name*/
        e[24]
      ), Y(t, "class", "svelte-1ewbjj5"), this.first = t;
    },
    m(_, d) {
      ee(_, t, d), J(t, n), J(n, a), J(t, o), s || (r = fs(n, "click", u), s = !0);
    },
    p(_, d) {
      e = _, d & /*effectiveValue*/
      256 && i !== (i = /*name*/
      e[24] + "") && $n(a, i), d & /*selected_license_name, Object, effectiveValue*/
      768 && Ji(
        n,
        "selected",
        /*selected_license_name*/
        e[9] === /*name*/
        e[24]
      );
    },
    d(_) {
      _ && z(t), s = !1, r();
    }
  };
}
function al(l) {
  let e, t, n, i, a, o = (
    /*effectiveValue*/
    l[8].licenses[
      /*selected_license_name*/
      l[9]
    ] + ""
  ), s;
  return {
    c() {
      e = K("div"), t = K("h4"), n = wn(
        /*selected_license_name*/
        l[9]
      ), i = Pe(), a = K("pre"), s = wn(o), this.h();
    },
    l(r) {
      e = W(r, "DIV", { class: !0 });
      var u = de(e);
      t = W(u, "H4", { class: !0 });
      var _ = de(t);
      n = yn(
        _,
        /*selected_license_name*/
        l[9]
      ), _.forEach(z), i = Oe(u), a = W(u, "PRE", { class: !0 });
      var d = de(a);
      s = yn(d, o), d.forEach(z), u.forEach(z), this.h();
    },
    h() {
      Y(t, "class", "svelte-1ewbjj5"), Y(a, "class", "svelte-1ewbjj5"), Y(e, "class", "license-display svelte-1ewbjj5");
    },
    m(r, u) {
      ee(r, e, u), J(e, t), J(t, n), J(e, i), J(e, a), J(a, s);
    },
    p(r, u) {
      u & /*selected_license_name*/
      512 && $n(
        n,
        /*selected_license_name*/
        r[9]
      ), u & /*effectiveValue, selected_license_name*/
      768 && o !== (o = /*effectiveValue*/
      r[8].licenses[
        /*selected_license_name*/
        r[9]
      ] + "") && $n(s, o);
    },
    d(r) {
      r && z(e);
    }
  };
}
function rl(l) {
  let e, t, n = {
    effect: (
      /*effectiveValue*/
      l[8].effect
    ),
    speed: (
      /*effectiveValue*/
      l[8].speed
    )
  }, i, a = (
    /*effectiveValue*/
    l[8].show_licenses && Object.keys(
      /*effectiveValue*/
      l[8].licenses
    ).length > 0
  ), o, s = il(l), r = a && ll(l);
  return {
    c() {
      e = K("div"), t = K("div"), s.c(), i = Pe(), r && r.c(), this.h();
    },
    l(u) {
      e = W(u, "DIV", { class: !0 });
      var _ = de(e);
      t = W(_, "DIV", { class: !0 });
      var d = de(t);
      s.l(d), i = Oe(d), r && r.l(d), d.forEach(z), _.forEach(z), this.h();
    },
    h() {
      Y(t, "class", "credits-panel-wrapper svelte-1ewbjj5"), P(
        t,
        "width",
        /*width_style*/
        l[15]
      ), P(
        t,
        "height",
        /*effectiveValue*/
        l[8].sidebar_position === "right" ? (
          /*height_style*/
          l[16]
        ) : void 0
      ), Y(e, "class", "outer-credits-wrapper svelte-1ewbjj5"), P(
        e,
        "width",
        /*width_style*/
        l[15]
      );
    },
    m(u, _) {
      ee(u, e, _), J(e, t), s.m(t, null), J(t, i), r && r.m(t, null), o = !0;
    },
    p(u, _) {
      _ & /*effectiveValue*/
      256 && Xt(n, n = {
        effect: (
          /*effectiveValue*/
          u[8].effect
        ),
        speed: (
          /*effectiveValue*/
          u[8].speed
        )
      }) ? (at(), V(s, 1, 1, kt), ot(), s = il(u), s.c(), H(s, 1), s.m(t, i)) : s.p(u, _), _ & /*effectiveValue*/
      256 && (a = /*effectiveValue*/
      u[8].show_licenses && Object.keys(
        /*effectiveValue*/
        u[8].licenses
      ).length > 0), a ? r ? r.p(u, _) : (r = ll(u), r.c(), r.m(t, null)) : r && (r.d(1), r = null), _ & /*width_style*/
      32768 && P(
        t,
        "width",
        /*width_style*/
        u[15]
      ), _ & /*effectiveValue, height_style*/
      65792 && P(
        t,
        "height",
        /*effectiveValue*/
        u[8].sidebar_position === "right" ? (
          /*height_style*/
          u[16]
        ) : void 0
      ), _ & /*width_style*/
      32768 && P(
        e,
        "width",
        /*width_style*/
        u[15]
      );
    },
    i(u) {
      o || (H(s), o = !0);
    },
    o(u) {
      V(s), o = !1;
    },
    d(u) {
      u && z(e), s.d(u), r && r.d();
    }
  };
}
function $s(l) {
  var f, g, y;
  let e, t, n, i = (
    /*effectiveValue*/
    l[8].logo_position
  ), a, o = (
    /*effectiveValue*/
    l[8].sidebar_position
  ), s, r;
  e = new cr({
    props: {
      autoscroll: (
        /*gradio*/
        l[7].autoscroll
      ),
      i18n: (
        /*gradio*/
        l[7].i18n
      ),
      queue_position: (
        /*loading_status*/
        ((f = l[6]) == null ? void 0 : f.queue_position) ?? -1
      ),
      queue_size: (
        /*loading_status*/
        ((g = l[6]) == null ? void 0 : g.queue_size) ?? 0
      ),
      status: (
        /*loading_status*/
        ((y = l[6]) == null ? void 0 : y.status) ?? "complete"
      )
    }
  });
  const u = (
    /*#slots*/
    l[21].default
  ), _ = ss(
    u,
    l,
    /*$$scope*/
    l[23],
    null
  );
  let d = nl(l), c = rl(l);
  return {
    c() {
      st(e.$$.fragment), t = Pe(), _ && _.c(), n = Pe(), d.c(), a = Pe(), c.c(), s = Zt();
    },
    l(m) {
      rt(e.$$.fragment, m), t = Oe(m), _ && _.l(m), n = Oe(m), d.l(m), a = Oe(m), c.l(m), s = Zt();
    },
    m(m, $) {
      _t(e, m, $), ee(m, t, $), _ && _.m(m, $), ee(m, n, $), d.m(m, $), ee(m, a, $), c.m(m, $), ee(m, s, $), r = !0;
    },
    p(m, $) {
      var h, b, v;
      const p = {};
      $ & /*gradio*/
      128 && (p.autoscroll = /*gradio*/
      m[7].autoscroll), $ & /*gradio*/
      128 && (p.i18n = /*gradio*/
      m[7].i18n), $ & /*loading_status*/
      64 && (p.queue_position = /*loading_status*/
      ((h = m[6]) == null ? void 0 : h.queue_position) ?? -1), $ & /*loading_status*/
      64 && (p.queue_size = /*loading_status*/
      ((b = m[6]) == null ? void 0 : b.queue_size) ?? 0), $ & /*loading_status*/
      64 && (p.status = /*loading_status*/
      ((v = m[6]) == null ? void 0 : v.status) ?? "complete"), e.$set(p), _ && _.p && (!r || $ & /*$$scope*/
      8388608) && ms(
        _,
        u,
        m,
        /*$$scope*/
        m[23],
        r ? cs(
          u,
          /*$$scope*/
          m[23],
          $,
          null
        ) : _s(
          /*$$scope*/
          m[23]
        ),
        null
      ), $ & /*effectiveValue*/
      256 && Xt(i, i = /*effectiveValue*/
      m[8].logo_position) ? (at(), V(d, 1, 1, kt), ot(), d = nl(m), d.c(), H(d, 1), d.m(a.parentNode, a)) : d.p(m, $), $ & /*effectiveValue*/
      256 && Xt(o, o = /*effectiveValue*/
      m[8].sidebar_position) ? (at(), V(c, 1, 1, kt), ot(), c = rl(m), c.c(), H(c, 1), c.m(s.parentNode, s)) : c.p(m, $);
    },
    i(m) {
      r || (H(e.$$.fragment, m), H(_, m), H(d), H(c), r = !0);
    },
    o(m) {
      V(e.$$.fragment, m), V(_, m), V(d), V(c), r = !1;
    },
    d(m) {
      m && (z(t), z(n), z(a), z(s)), ut(e, m), _ && _.d(m), d.d(m), c.d(m);
    }
  };
}
function ws(l) {
  let e, t = `.credits-panel-wrapper { flex-direction: row !important; --panel-direction: row; --sidebar-width: 400px; --border-left: 1px solid var(--border-color-primary); --border-top: none; --sidebar-max-height: {height_style}; }
            .licenses-sidebar { width: var(--sidebar-width, 400px) !important; border-left: 1px solid var(--border-color-primary) !important; border-top: none !important; }
            .main-credits-panel { width: calc(100% - var(--sidebar-width, 400px)) !important; }`;
  return {
    c() {
      e = K("style"), e.textContent = t;
    },
    l(n) {
      e = W(n, "STYLE", { "data-svelte-h": !0 }), xn(e) !== "svelte-xtzihd" && (e.textContent = t);
    },
    m(n, i) {
      ee(n, e, i);
    },
    d(n) {
      n && z(e);
    }
  };
}
function Fs(l) {
  let e, t = `.credits-panel-wrapper {
        flex-direction: column !important;
        --panel-direction: column;
        --sidebar-width: 100%;
        --border-left: none;
        --border-top: 1px solid var(--border-color-primary);
        --sidebar-max-height: 400px;
      }
      .licenses-sidebar {
        width: 100% !important;
        border-left: none !important;
        border-top: 1px solid var(--border-color-primary) !important;
      }
      .main-credits-panel {
        width: 100% !important;
      }`;
  return {
    c() {
      e = K("style"), e.textContent = t;
    },
    l(n) {
      e = W(n, "STYLE", { "data-svelte-h": !0 }), xn(e) !== "svelte-eaginr" && (e.textContent = t);
    },
    m(n, i) {
      ee(n, e, i);
    },
    d(n) {
      n && z(e);
    }
  };
}
function ks(l) {
  let e, t, n, i;
  e = new po({
    props: {
      visible: (
        /*visible*/
        l[2]
      ),
      elem_id: (
        /*elem_id*/
        l[0]
      ),
      elem_classes: (
        /*elem_classes*/
        l[1]
      ),
      container: (
        /*container*/
        l[3]
      ),
      scale: (
        /*scale*/
        l[4]
      ),
      min_width: (
        /*min_width*/
        l[5]
      ),
      padding: !1,
      $$slots: { default: [$s] },
      $$scope: { ctx: l }
    }
  });
  function a(r, u) {
    return (
      /*effectiveValue*/
      r[8].sidebar_position === "bottom" ? Fs : ws
    );
  }
  let o = a(l), s = o(l);
  return {
    c() {
      st(e.$$.fragment), t = Pe(), s.c(), n = Zt();
    },
    l(r) {
      rt(e.$$.fragment, r), t = Oe(r);
      const u = ds("svelte-108tboc", document.head);
      s.l(u), n = Zt(), u.forEach(z);
    },
    m(r, u) {
      _t(e, r, u), ee(r, t, u), s.m(document.head, null), J(document.head, n), i = !0;
    },
    p(r, [u]) {
      const _ = {};
      u & /*visible*/
      4 && (_.visible = /*visible*/
      r[2]), u & /*elem_id*/
      1 && (_.elem_id = /*elem_id*/
      r[0]), u & /*elem_classes*/
      2 && (_.elem_classes = /*elem_classes*/
      r[1]), u & /*container*/
      8 && (_.container = /*container*/
      r[3]), u & /*scale*/
      16 && (_.scale = /*scale*/
      r[4]), u & /*min_width*/
      32 && (_.min_width = /*min_width*/
      r[5]), u & /*$$scope, effectiveValue, width_style, height_style, selected_license_name, logo_panel_height, logo_justify, gradio, logo_width_style, logo_height_style, object_fit, loading_status*/
      8519616 && (_.$$scope = { dirty: u, ctx: r }), e.$set(_), o !== (o = a(r)) && (s.d(1), s = o(r), s && (s.c(), s.m(n.parentNode, n)));
    },
    i(r) {
      i || (H(e.$$.fragment, r), i = !0);
    },
    o(r) {
      V(e.$$.fragment, r), i = !1;
    },
    d(r) {
      r && z(t), ut(e, r), s.d(r), z(n);
    }
  };
}
function Cs(l, e, t) {
  let n, i, a, o, s, r, u, _, { $$slots: d = {}, $$scope: c } = e, { value: f = null } = e, { elem_id: g = "" } = e, { elem_classes: y = [] } = e, { visible: m = !0 } = e, { container: $ = !0 } = e, { scale: p = null } = e, { min_width: h = void 0 } = e, { height: b = void 0 } = e, { width: v = void 0 } = e, { loading_status: D } = e, { gradio: w } = e, S = null;
  function k(C) {
    t(9, S = S === C ? null : C);
  }
  const q = (C) => k(C);
  return l.$$set = (C) => {
    "value" in C && t(18, f = C.value), "elem_id" in C && t(0, g = C.elem_id), "elem_classes" in C && t(1, y = C.elem_classes), "visible" in C && t(2, m = C.visible), "container" in C && t(3, $ = C.container), "scale" in C && t(4, p = C.scale), "min_width" in C && t(5, h = C.min_width), "height" in C && t(19, b = C.height), "width" in C && t(20, v = C.width), "loading_status" in C && t(6, D = C.loading_status), "gradio" in C && t(7, w = C.gradio), "$$scope" in C && t(23, c = C.$$scope);
  }, l.$$.update = () => {
    l.$$.dirty & /*value*/
    262144 && t(8, n = f || {
      credits: [
        {
          title: "Lead Developer",
          name: "John Doe"
        },
        {
          title: "UI/UX Design",
          name: "Jane Smith"
        },
        {
          title: "Backend Engineering",
          name: "Alex Ray"
        },
        {
          title: "Component Concept",
          name: "Your Name"
        },
        {
          title: "Quality Assurance",
          name: "Sam Wilson"
        }
      ],
      licenses: {
        "Gradio Framework": "Apache License placeholder",
        "This Component": "MIT License placeholder"
      },
      effect: "scroll",
      speed: 40,
      base_font_size: 1.5,
      intro_title: "",
      intro_subtitle: "",
      sidebar_position: "right",
      logo_path: null,
      show_logo: !0,
      show_licenses: !0,
      logo_position: "center",
      logo_sizing: "resize",
      logo_width: null,
      logo_height: null,
      scroll_background_color: null,
      scroll_title_color: null,
      scroll_name_color: null
    }), l.$$.dirty & /*height*/
    524288 && t(16, i = typeof b == "number" ? `${b}px` : b || "500px"), l.$$.dirty & /*width*/
    1048576 && t(15, a = typeof v == "number" ? `${v}px` : v || "100%"), l.$$.dirty & /*effectiveValue*/
    256 && t(14, o = n.logo_width ? typeof n.logo_width == "number" ? `${n.logo_width}px` : n.logo_width : "auto"), l.$$.dirty & /*effectiveValue*/
    256 && t(13, s = n.logo_height ? typeof n.logo_height == "number" ? `${n.logo_height}px` : n.logo_height : "100px"), l.$$.dirty & /*effectiveValue*/
    256 && t(12, r = n.logo_height ? typeof n.logo_height == "number" ? `${n.logo_height}px` : n.logo_height : "100px"), l.$$.dirty & /*effectiveValue*/
    256 && t(11, u = n.logo_sizing === "stretch" ? "fill" : n.logo_sizing === "crop" ? "cover" : "contain"), l.$$.dirty & /*effectiveValue*/
    256 && t(10, _ = n.logo_position === "center" ? "center" : n.logo_position === "left" ? "flex-start" : "flex-end");
  }, [
    g,
    y,
    m,
    $,
    p,
    h,
    D,
    w,
    n,
    S,
    _,
    u,
    r,
    s,
    o,
    a,
    i,
    k,
    f,
    b,
    v,
    d,
    q,
    c
  ];
}
class y3 extends rs {
  constructor(e) {
    super(), hs(this, e, Cs, ks, Xt, {
      value: 18,
      elem_id: 0,
      elem_classes: 1,
      visible: 2,
      container: 3,
      scale: 4,
      min_width: 5,
      height: 19,
      width: 20,
      loading_status: 6,
      gradio: 7
    });
  }
}
export {
  y3 as default
};
