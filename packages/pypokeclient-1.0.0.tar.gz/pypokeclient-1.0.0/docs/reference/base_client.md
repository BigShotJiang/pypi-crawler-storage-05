# `BaseClient` class

Here's the reference information for the `BaseClient` class.

You should not import the `BaseClient` class from `pypokeclient` since it is an abstract class.

---

::: pypokeclient.sync_client.BaseClient
