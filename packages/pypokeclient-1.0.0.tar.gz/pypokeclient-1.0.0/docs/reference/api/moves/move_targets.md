---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/move-target/{id or name}/
```

::: pypokeclient._api.moves.move_targets
    options:
        separate_signature: false
