---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/contest-effect/{id}/
```

::: pypokeclient._api.contests.contest_effects
    options:
        separate_signature: false
