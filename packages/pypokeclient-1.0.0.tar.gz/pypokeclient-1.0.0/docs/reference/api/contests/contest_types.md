---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/contest-type/{id or name}/
```

::: pypokeclient._api.contests.contest_types
    options:
        separate_signature: false
