---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/berry-flavor/{id or name}/
```

::: pypokeclient._api.berries.berry_flavors
    options:
        separate_signature: false
