---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/berry-firmness/{id or name}/
```

::: pypokeclient._api.berries.berry_firmnesses
    options:
        separate_signature: false
