---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/item-category/{id or name}/
```

::: pypokeclient._api.items.item_categories
    options:
        separate_signature: false
