---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/item-pocket/{id or name}/
```

::: pypokeclient._api.items.item_pockets
    options:
        separate_signature: false
