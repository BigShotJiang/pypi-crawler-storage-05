---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/item-fling-effect/{id or name}/
```

::: pypokeclient._api.items.item_fling_effects
    options:
        separate_signature: false
