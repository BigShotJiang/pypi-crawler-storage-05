---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/generation/{id or name}/
```

::: pypokeclient._api.games.generations
    options:
        separate_signature: false
