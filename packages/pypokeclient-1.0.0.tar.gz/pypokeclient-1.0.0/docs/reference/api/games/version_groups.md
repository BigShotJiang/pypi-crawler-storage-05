---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/version-group/{id or name}/
```

::: pypokeclient._api.games.version_groups
    options:
        separate_signature: false
