---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/encounter-condition-value/{id or name}/
```

::: pypokeclient._api.encounters.encounter_condition_values
    options:
        separate_signature: false
