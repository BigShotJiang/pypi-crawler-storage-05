---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/pokemon-species/{id or name}/
```

::: pypokeclient._api.pokemon.pokemon_species
    options:
        separate_signature: false
