---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/ability/{id or name}/
```

::: pypokeclient._api.pokemon.abilities
    options:
        separate_signature: false
