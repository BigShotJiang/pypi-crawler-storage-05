---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/growth-rate/{id or name}/
```

::: pypokeclient._api.pokemon.growth_rates
    options:
        separate_signature: false
