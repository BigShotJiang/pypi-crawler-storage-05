---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/pokemon/{id or name}/
```

::: pypokeclient._api.pokemon.pokemon
    options:
        separate_signature: false
