---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/characteristic/{id}/
```

::: pypokeclient._api.pokemon.characteristics
    options:
        separate_signature: false
