---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/pokemon/{id or name}/encounters
```

::: pypokeclient._api.pokemon.pokemon_location_areas
    options:
        separate_signature: false
