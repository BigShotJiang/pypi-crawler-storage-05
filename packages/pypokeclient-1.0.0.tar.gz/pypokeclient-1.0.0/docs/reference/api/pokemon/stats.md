---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/stat/{id or name}/
```

::: pypokeclient._api.pokemon.stats
    options:
        separate_signature: false
