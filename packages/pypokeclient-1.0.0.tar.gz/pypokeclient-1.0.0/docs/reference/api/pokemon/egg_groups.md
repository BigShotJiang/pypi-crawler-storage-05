---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/egg-group/{id or name}/
```

::: pypokeclient._api.pokemon.egg_groups
    options:
        separate_signature: false
