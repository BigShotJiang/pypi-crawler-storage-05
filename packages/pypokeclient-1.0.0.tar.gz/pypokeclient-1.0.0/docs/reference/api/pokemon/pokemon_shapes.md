---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/pokemon-shape/{id or name}/
```

::: pypokeclient._api.pokemon.pokemon_shapes
    options:
        separate_signature: false
