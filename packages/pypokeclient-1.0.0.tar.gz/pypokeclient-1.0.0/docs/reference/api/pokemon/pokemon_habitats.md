---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/pokemon-habitat/{id or name}/
```

::: pypokeclient._api.pokemon.pokemon_habitats
    options:
        separate_signature: false
