---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/machine/{id}/
```

::: pypokeclient._api.machines.machines
    options:
        separate_signature: false
