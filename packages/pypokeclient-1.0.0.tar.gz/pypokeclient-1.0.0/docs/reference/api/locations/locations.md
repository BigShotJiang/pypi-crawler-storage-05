---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/location/{id or name}/
```

::: pypokeclient._api.locations.locations
    options:
        separate_signature: false
