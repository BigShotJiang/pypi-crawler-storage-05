---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/region/{id or name}/
```

::: pypokeclient._api.locations.regions
    options:
        separate_signature: false
