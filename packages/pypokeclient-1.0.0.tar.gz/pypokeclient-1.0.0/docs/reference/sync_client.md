# `Client` class

Here's the reference information for the `Client` class.

You can import the `Client` class directly from `pypokeclient`:
```python
from pypokeclient import Client
```

---

::: pypokeclient.sync_client.Client
