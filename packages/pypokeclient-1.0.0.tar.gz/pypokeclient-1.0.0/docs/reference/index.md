# Reference
This is the documentation for the main classes and attributes implemented in the package. Bear in mind that only `Client`, `AsyncClient` and `ENDPOINTS` are exposed at the top level of the package, as these provide everything you need to fetch data from PokéAPI.

Each class in the API section corresponds one-to-one with those from [PokéAPI](https://pokeapi.co/docs/v2).
