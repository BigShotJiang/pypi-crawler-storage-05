"""
Environment variable manager package.
"""

__version__ = '1.0.3'

from .cli.main import main

__all__ = ['main']
