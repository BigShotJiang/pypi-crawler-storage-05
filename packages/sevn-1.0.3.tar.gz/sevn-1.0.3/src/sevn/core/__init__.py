"""
Core functionality for environment variable management.
""" 