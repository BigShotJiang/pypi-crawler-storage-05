# tacozip-python

tacozip is a fast, minimal ZIP64-like archiver with ghost metadata support, designed for AI4EO workflows. It allows creating archives, reading ghost metadata, and updating metadata in place without rewriting the entire file.

# Install

```bash
pip install tacozip
```