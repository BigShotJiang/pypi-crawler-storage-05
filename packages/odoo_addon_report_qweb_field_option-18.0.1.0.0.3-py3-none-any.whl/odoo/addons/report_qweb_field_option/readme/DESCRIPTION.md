This module allows administrators to define the decimal precision of
float fields and add option values to fields (e.g., adding a date widget
option to datetime fields) for QWeb report and view presentation.
