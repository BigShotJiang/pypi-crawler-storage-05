Stock accounting determination for receptions, deliveries, consume,
usage\_giving, inventory and production.
