# REST API

The endpoints of the REST service are documented below.

```{eval-rst}
.. openapi:: ../../schema.json
```
