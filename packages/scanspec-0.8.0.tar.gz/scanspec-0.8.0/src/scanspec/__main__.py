"""Interface for ``python -m scanspec``."""

from scanspec import cli

if __name__ == "__main__":
    cli.cli()
