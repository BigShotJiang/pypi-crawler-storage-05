from edri.dataclass.event import Event, event


@event
class Scheduler(Event):
    pass
