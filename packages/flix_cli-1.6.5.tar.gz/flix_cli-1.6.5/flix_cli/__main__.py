from .core import __flix_cli__

def __flixcli__():
    __flix_cli__

if __name__ == "__main__":
    __flixcli__()
