from openai_websearch_mcp import main

main()
