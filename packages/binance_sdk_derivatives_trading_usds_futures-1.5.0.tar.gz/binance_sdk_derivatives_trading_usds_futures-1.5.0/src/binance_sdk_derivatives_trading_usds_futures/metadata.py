NAME = "binance-sdk-derivatives-trading-usds-futures"
