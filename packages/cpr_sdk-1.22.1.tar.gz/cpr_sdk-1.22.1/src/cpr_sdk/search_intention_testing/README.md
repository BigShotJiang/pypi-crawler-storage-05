# search-tests

See [search docs in the root of this repo](/docs/search/4_search_intention_tests.md).