SETUP_PREFIX = "setup"
TEST_PREFIX = "test"
BASE_TEST_INVOCATION = "BaseTestAgents.setup_method(self)"
SETUP_METHOD_SIGNATURE = "def __set_up_default_test_agents(self) -> None:"
FLOW_DEFINITION = 'flow = Flow(name="NL2Flow Test")'
BASE_TEST_FILE_PATH = "./tests/testing.py"
