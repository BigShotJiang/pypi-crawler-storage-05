"""
Faraday's constant
sA/mol
"""

F = 96485.3329
