class OgAI:
    pass