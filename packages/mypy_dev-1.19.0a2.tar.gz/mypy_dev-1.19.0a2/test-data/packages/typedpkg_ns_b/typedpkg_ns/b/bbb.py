def bf(a):
    return not a
