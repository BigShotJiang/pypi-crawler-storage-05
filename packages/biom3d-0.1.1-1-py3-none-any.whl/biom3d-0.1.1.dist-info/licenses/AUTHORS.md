# AUTHORS
Developpers
------------
- Guillaume Mougeot¹²³
- Sami Safarbati¹²
- Clément Colmerauer¹

Institutions / Organizations
----------------------------
¹ Institut de Génétique, Reproduction et Développement (iGReD), Université Clermont Auvergne (UCA), CNRS, Clermont-Ferrand, France  
² Institut Pascal, Université Clermont Auvergne (UCA), CNRS, Aubière, France  
³ Oxford Brookes University, UK
