## Release v0.3.0 - Semptember 9, 2025

First release