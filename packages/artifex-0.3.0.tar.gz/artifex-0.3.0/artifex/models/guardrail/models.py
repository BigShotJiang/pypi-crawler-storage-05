from typing import Literal


GuardrailExamplesModel = list[tuple[str, Literal[0, 1]]]
