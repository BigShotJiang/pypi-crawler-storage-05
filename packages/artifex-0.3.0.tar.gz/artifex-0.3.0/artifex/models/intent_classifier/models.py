from artifex.core import ClassificationClassName
    

IntentClassifierInstructions = dict[ClassificationClassName, str]