Después de instalar, debes clicar en el asistente de importación para
añadir las regiones NUTS en la base de datos de Odoo.

Contactos \> Configuración \> Importar NUTS 202

Este asistente descargará del servicio europeo Showvoc (Reference And
Management Of Nomenclatures) los metadatos para añadir las regiones NUTS
en Odoo. Este módulo específico de la localización española hereda este
asistente genérico para relacionar cada region NUTS española con las
provincias españolas definidas en Odoo.
