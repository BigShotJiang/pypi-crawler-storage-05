Este módulo permite relacionar las regiones NUTS para España de nivel 4
con las provincias españolas.
