from .modulo import poner, variable, si, bucle, LSL, consola_var, consola_nor
