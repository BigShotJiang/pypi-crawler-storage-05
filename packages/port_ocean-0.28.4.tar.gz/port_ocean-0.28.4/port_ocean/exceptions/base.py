class BaseOceanException(Exception):
    pass
