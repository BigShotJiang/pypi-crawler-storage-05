from llama_index.readers.arango_db.base import SimpleArangoDBReader

__all__ = ["SimpleArangoDBReader"]
