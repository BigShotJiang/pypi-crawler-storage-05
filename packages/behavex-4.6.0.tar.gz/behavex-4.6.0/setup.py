# -*- coding: utf-8 -*-
from setuptools import setup

# Minimal setup.py for backward compatibility
# All project metadata is now defined in pyproject.toml
setup()
