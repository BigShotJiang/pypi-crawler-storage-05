
# Utilities for managing Outerbounds projects

- `deploy` - CI/CD deployment script for obprojects
- `src-html` - Svelte source for highlight and table (eval) cards
- `metaflow-extensions` - the highlight card backend & `card(type='highlight')`
- `highlight_card` - highlight card mutator, i.e. the user-facing `@highlight`
- `obproject` - `ProjectFlow` base flow and supporting modules
