from bumpkin.base import NAME


def test_base():
    assert NAME == "bumpkin"
