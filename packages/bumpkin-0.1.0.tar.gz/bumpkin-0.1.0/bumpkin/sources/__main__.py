from bumpkin.sources import sources

for k, v in sources.items():
    print(k, v)
