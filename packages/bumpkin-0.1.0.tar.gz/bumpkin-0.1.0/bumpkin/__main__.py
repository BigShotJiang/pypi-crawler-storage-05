"""Entry point for bumpkin."""

from .cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()
