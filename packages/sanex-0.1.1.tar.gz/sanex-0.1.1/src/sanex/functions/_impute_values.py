import pandas as pd
import polars as pl
from typing import Union, Optional, List, Callable, Dict, Any

DataFrameType = Union[pd.DataFrame, pl.DataFrame]

# This file is currently empty and will be implemented in the future

