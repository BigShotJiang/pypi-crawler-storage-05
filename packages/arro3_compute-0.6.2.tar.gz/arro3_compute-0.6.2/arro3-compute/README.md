# arro3-compute

A minimal Python library for [Apache Arrow](https://arrow.apache.org/docs/index.html), binding to the [Rust Arrow implementation](https://github.com/apache/arrow-rs).

Consult the [documentation](https://kylebarron.dev/arro3/latest/).
