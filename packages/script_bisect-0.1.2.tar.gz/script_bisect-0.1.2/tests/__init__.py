"""Tests for script-bisect."""
