from .naive import *
from .parallel import *