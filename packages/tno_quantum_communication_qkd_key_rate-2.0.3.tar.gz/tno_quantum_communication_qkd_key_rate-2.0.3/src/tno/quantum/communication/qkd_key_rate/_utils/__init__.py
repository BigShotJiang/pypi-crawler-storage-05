"""Utility functions."""

from .entropy import binary_entropy, one_minus_binary_entropy

__all__ = ["binary_entropy", "one_minus_binary_entropy"]
