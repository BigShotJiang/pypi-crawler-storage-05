.. _ntp_mc_repo:

******************
firewheel_repo_ntp
******************

This repository contains FIREWHEEL model components for enabling the Network Time Protocol (NTP) within an experiment.

Building VMRs
=============

Due to licensing limitations, we are currently unable to provide the expected binary files (VM Resources nor Images) that are used within these model components.
For the VM Resources, we have provided an `INSTALL <https://sandialabs.github.io/firewheel/tutorials/install_file.html>`__ script to reproducibly recreate them, when possible.