import matplotlib.style

# matplotlib.style.use('seaborn')


from .default_kwargs import *
from .etc import *
from .rc_params import *
from . import COLORS
