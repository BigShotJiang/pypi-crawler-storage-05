To start a matlab session through the terminal without opening the matlab desktop, run:\
`/Applications/MATLAB_R<VERSION>.app/bin/matlab -nodesktop`
