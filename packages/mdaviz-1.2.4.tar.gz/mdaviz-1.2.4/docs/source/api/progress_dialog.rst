====================================
Progress Dialog
====================================

.. automodule:: mdaviz.progress_dialog
    :members:
    :private-members:
