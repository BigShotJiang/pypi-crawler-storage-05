====================================
Fit Manager
====================================

.. automodule:: mdaviz.fit_manager
    :members:
    :private-members:
