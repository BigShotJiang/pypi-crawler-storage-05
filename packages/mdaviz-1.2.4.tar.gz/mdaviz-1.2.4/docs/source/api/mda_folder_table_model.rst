====================================
MDA Folder Table Model
====================================

.. automodule:: mdaviz.mda_folder_table_model
    :members:
    :private-members:
