====================================
Empty Table Model
====================================

.. automodule:: mdaviz.empty_table_model
    :members:
    :private-members:
