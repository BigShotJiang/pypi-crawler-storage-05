====================================
License Dialog
====================================

.. automodule:: mdaviz.licensedialog
    :members:
    :private-members:
