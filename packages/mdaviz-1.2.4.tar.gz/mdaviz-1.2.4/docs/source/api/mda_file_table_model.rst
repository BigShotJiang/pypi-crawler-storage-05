====================================
MDA File Table Model
====================================

.. automodule:: mdaviz.mda_file_table_model
    :members:
    :private-members:
