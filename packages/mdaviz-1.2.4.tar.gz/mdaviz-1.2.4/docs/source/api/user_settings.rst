====================================
User Settings
====================================

.. automodule:: mdaviz.user_settings
    :members:
    :private-members:

    WARNING: Failed to import mdaviz.user_settings.
    Possible hints:
    * TypeError: ApplicationQSettings.__init__() missing 2 required positional arguments: 'orgName' and 'appName'
    * AttributeError: module 'mdaviz' has no attribute 'user_settings'
