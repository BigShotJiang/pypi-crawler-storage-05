====================================
MDA Folder
====================================

.. automodule:: mdaviz.mda_folder
    :members:
    :private-members:
