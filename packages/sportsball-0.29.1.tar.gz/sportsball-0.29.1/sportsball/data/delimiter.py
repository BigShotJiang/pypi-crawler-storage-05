"""Constants for column delimiters."""

DELIMITER = "/"
