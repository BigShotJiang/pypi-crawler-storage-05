from mcp_agentmemory import main

main()
