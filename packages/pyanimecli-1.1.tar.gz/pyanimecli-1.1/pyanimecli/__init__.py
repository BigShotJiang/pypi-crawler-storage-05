from .pyanimecli import main
