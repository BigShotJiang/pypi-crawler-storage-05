"""Tests for plugin.py."""

import pytest


@pytest.mark.usefixtures("with_plugins")
def test_plugin():
    pass
