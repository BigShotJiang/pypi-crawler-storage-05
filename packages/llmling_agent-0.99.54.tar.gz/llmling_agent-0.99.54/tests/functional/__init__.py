"""Tests for functional package."""
