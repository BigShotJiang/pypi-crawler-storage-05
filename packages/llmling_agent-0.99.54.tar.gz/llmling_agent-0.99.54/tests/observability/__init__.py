"""Observability-related tests."""
