"""Resource-related tests."""
