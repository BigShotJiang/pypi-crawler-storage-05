''' 
GenieTelemetry Crashdumps Plugin for IOSXR
'''

# GenieTelemetry
from ..plugin import Plugin as BasePlugin


class Plugin(BasePlugin):

    pass
