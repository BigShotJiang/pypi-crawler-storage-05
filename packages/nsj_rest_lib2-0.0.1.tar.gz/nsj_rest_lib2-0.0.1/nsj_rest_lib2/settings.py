import os

ESCOPO_RESTLIB2 = os.environ["ESCOPO_RESTLIB2"]
