To use this module, you need to log in as a salesman (i.e.: demo user), as sales manager
won't be locked. Then:

1. Create a new sales order.
2. Chose the pricelist we configured before.
3. Add the product FURN_5555: you'll see that the price unit is locked.
4. Add another product: the price unit can be edited for that line.
5. Change the pricelist: now you can edit the price for FURN_5555 again.
