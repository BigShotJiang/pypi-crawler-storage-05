This module allows to lock price edition based on the applied pricelist rule scope.
