class CreditNoteApiUrl:
    DETAILS = '/api/v3/credit-notes/{id}/'
    APPLICATION_LIST = '/api/v3/credit-note-applications'
    APPLICATION_DETAILS = '/api/v3/credit-note-applications/{uuid}'
    INVOICE_CN_APPLICATION_LIST = '/api/v3/invoices/{id}/credit-note-applications'
