# atopile project template

To use project-template use `ato create project`, which will setup the project for you. Project setup instructions are here: https://atopile.io/
