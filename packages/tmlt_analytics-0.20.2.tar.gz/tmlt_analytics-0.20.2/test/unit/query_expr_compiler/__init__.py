"""Test for :mod:`~tmlt.analytics._query_expr_compiler`.

By default, nosetests does not run tests inside folders that start with
an underscore. Don't move this folder back to ``_query_expr_compiler``, or the
tests won't run.
"""

# SPDX-License-Identifier: Apache-2.0
# Copyright Tumult Labs 2025
