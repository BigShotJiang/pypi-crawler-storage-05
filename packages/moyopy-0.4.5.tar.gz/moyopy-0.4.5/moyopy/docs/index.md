```{toctree}
---
caption: Contents
maxdepth: 1
hidden:
---
    Introduction <self>
    Examples <examples/index>
```

```{include} ../README.md
:relative-docs: docs/
```
