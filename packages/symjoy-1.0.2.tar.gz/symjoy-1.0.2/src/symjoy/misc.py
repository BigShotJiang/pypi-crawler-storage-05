# misc.py
misc = {
    "sun": "☀",
    "cloud": "☁",
    "umbrella": "☂",
    "snowflake": "❄",
    "star": "★",
    "lightning": "⚡",
    "skull": "☠",
    "peace": "☮",
    "yin_yang": "☯",
    "music": "♪",
    "note": "♫",
    "radioactive": "☢",
    "biohazard": "☣",
    "snowman": "☃",
    "fire": "🔥"
}
