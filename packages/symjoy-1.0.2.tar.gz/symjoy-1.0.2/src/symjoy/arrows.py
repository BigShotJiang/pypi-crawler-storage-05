# arrows.py
arrows = {
    "left": "\u2190",
    "up": "\u2191",
    "right": "\u2192",
    "down": "\u2193",
    "up_right": "\u2197",
    "up_left": "\u2196",
    "down_right": "\u2198",
    "down_left": "\u2199",
    "double_up": "\u21D1",
    "double_down": "\u21D3",
    "double_left": "\u21D0",
    "double_right": "\u21D2"
}