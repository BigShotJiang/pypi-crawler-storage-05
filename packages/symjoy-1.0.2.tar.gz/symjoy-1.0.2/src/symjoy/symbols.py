# symbols.py
symbols = {
    "heart": "\u2665",
    "spade": "\u2660",
    "club": "\u2663",
    "diamond": "\u2666",
    "check_mark": "\u2713",
    "cross_mark": "\u2717",
    "copyright": "\u00A9",
    "registered": "\u00AE",
    "trademark": "\u2122",
    "infinity": "\u221E",
    "star": "\u2605",
    "bullet": "\u2022",
    "section": "\u00A7",
    "pilcrow": "\u00B6",
    "paragraph": "\u00B6",
    "degree": "\u00B0",
    "plus_minus": "\u00B1",
    "micro": "\u00B5"
}