from symjoy import emojis


print(emojis["cry"])