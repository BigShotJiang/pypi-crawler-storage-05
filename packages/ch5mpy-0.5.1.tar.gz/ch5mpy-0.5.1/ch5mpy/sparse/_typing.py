from typing import Any

import numpy as np

INT_FLOAT = np.integer[Any] | np.floating[Any]
