:mod:`mozanalysis.metrics`
-----------------------------

.. automodule:: mozanalysis.metrics
   :members:
