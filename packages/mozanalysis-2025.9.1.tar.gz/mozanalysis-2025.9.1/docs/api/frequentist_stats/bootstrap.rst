:mod:`mozanalysis.frequentist_stats.bootstrap`
----------------------------------------------

.. automodule:: mozanalysis.frequentist_stats.bootstrap
   :members:
