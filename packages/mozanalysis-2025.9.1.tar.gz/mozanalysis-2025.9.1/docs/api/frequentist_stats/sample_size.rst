:mod:`mozanalysis.frequentist_stats.sample_size`
------------------------------------------------

.. automodule:: mozanalysis.frequentist_stats.sample_size
   :members:
