:mod:`mozanalysis.bayesian_stats.bayesian_bootstrap`
----------------------------------------------------

.. automodule:: mozanalysis.bayesian_stats.bayesian_bootstrap
   :members:
