:mod:`mozanalysis.bayesian_stats.binary`
----------------------------------------

.. automodule:: mozanalysis.bayesian_stats.binary
   :members:
