:mod:`mozanalysis.segments`
-----------------------------

.. automodule:: mozanalysis.segments
   :members:
