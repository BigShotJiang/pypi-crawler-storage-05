:mod:`mozanalysis.config`
-----------------------------

.. automodule:: mozanalysis.config
   :members:
   :private-members: _ConfigLoader

   .. autodata:: ConfigLoader

