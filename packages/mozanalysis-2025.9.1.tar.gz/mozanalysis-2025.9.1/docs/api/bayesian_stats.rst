:mod:`mozanalysis.bayesian_stats`
---------------------------------

.. automodule:: mozanalysis.bayesian_stats
   :members:
