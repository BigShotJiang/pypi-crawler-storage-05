=================
About Mozanalysis
=================

Goals
=====

The primary goal of mozanalysis is to facilitate experiment analysis.
