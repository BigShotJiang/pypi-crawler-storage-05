This module adds the analytical tags to the bank reconciliation.
