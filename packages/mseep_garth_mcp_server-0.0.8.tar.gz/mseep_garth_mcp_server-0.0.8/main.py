def main():
    print("Hello from garth-mcp-server!")


if __name__ == "__main__":
    main()
