class AlgorithmException(Exception):
    """Exception that is thrown when the estimation process did not find a maximum."""
