math Module
============================

.. automodule:: adaptivetesting.math
   :members:
   :undoc-members:
   :show-inheritance:
   :imported-members:


.. automodule:: adaptivetesting.math.estimators
   :members:
   :undoc-members:
   :show-inheritance:
   :imported-members:

.. automodule:: adaptivetesting.math.item_selection
   :members:
   :undoc-members:
   :show-inheritance:
   :imported-members:
