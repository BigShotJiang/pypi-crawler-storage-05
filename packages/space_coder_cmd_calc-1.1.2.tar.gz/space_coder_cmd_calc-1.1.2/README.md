# Calculator!!!

To run, simply install the package, `pip install space-coder-cmd-calc` and then run `python3 -m cmd_calc`