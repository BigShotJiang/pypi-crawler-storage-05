from .base import BaseCog

__all__ = ["BaseCog"]
