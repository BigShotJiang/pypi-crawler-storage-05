===================
 ``zope.datetime``
===================

.. image:: https://img.shields.io/pypi/v/zope.datetime.svg
        :target: https://pypi.python.org/pypi/zope.datetime/
        :alt: Latest release

.. image:: https://img.shields.io/pypi/pyversions/zope.datetime.svg
        :target: https://pypi.org/project/zope.datetime/
        :alt: Supported Python versions

.. image:: https://github.com/zopefoundation/zope.datetime/workflows/tests/badge.svg
        :target: https://github.com/zopefoundation/zope.datetime/actions?query=workflow%3Atests
        :alt: CI status

.. image:: https://coveralls.io/repos/github/zopefoundation/zope.datetime/badge.svg?branch=master
        :target: https://coveralls.io/github/zopefoundation/zope.datetime?branch=master
        :alt: Coverage

.. image:: https://readthedocs.org/projects/zopedatetime/badge/?version=latest
        :target: https://zopedatetime.readthedocs.io/en/latest/
        :alt: Documentation Status

Functions to parse and format date/time strings in common formats.

The documentation is hosted at https://zopedatetime.readthedocs.io/
