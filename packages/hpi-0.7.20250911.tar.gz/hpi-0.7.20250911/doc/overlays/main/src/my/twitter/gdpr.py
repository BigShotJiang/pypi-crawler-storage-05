print(f'[main] {__name__} hello')

def tweets() -> list[str]:
    return [
        'gdpr tweet 1',
        'gdpr tweet 2',
    ]

trigger_mypy_error: str = 123
