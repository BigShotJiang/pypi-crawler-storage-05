print(f'[main] {__name__} hello')


def upvotes() -> list[str]:
    return [
        'reddit upvote1',
        'reddit upvote2',
    ]


trigger_mypy_error: str = 123
