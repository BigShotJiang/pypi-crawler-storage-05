print(f'[overlay] {__name__} hello')

def tweets() -> list[str]:
    return [
        'talon tweet 1',
        'talon tweet 2',
    ]

trigger_mypy_error: str = 123
