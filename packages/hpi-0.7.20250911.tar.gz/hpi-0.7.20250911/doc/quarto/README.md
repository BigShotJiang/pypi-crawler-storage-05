Just experimenting with using Quarto for docs instead of org-mode.

- interactive preview `./run preview <doc>.qmd`
- use `./validate-references.py <doc>.qmd` to check for broken referneces
- to render markdown: `/run render <doc>.qmd`


TODO some issues with Quarto
- in markdown, cross-references are not output, and github uses custom cross-references syntax