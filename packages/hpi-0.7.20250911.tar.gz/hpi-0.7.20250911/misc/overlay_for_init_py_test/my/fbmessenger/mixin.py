def messages():
    yield from ['1', '2', '3']
