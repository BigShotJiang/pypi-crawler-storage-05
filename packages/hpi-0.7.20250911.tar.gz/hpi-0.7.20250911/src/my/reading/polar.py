from my.core import warnings

warnings.medium('my.reading.polar is deprecated! Use my.polar instead!')

from ..polar import *
