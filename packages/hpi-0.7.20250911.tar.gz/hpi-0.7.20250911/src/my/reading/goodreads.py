from my.core import warnings

warnings.medium('my.reading.goodreads is deprecated! Use my.goodreads instead!')

from ..goodreads import *
