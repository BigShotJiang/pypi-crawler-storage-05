# __init__.py
if __name__ == "__main__":
    from .DDS_All import *
    print("导入成功：", dir())