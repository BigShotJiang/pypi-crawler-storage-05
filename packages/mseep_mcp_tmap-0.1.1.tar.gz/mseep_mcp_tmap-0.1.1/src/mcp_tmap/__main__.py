from mcp_tmap import main

if __name__ == "__main__":
  main()
