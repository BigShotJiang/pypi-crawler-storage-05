dict_of_parts = {
    "36v-hub-motor": "x 4",
    "brushless-350w-drive": "x 2?",
}
