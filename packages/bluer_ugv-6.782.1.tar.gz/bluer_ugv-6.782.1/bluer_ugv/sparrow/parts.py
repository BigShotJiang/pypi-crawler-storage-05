dict_of_parts = {
    "DC-gearboxed-motor-12V-120RPM": "proposed, not used.",
}
