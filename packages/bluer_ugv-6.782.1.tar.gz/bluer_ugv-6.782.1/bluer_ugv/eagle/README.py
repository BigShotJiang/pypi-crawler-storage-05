from bluer_objects.README.items import ImageItems

from bluer_ugv.README.consts import assets2_bluer_eagle

items = ImageItems(
    {
        f"{assets2_bluer_eagle}/file_0000000007986246b45343b0c06325dd.png": "",
        f"{assets2_bluer_eagle}/20250727_182113.jpg": "",
        f"{assets2_bluer_eagle}/20250726_171953.jpg": "",
    }
)
