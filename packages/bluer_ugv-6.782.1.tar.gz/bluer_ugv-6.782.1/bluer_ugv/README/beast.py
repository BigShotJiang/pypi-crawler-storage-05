docs = [
    {"path": "../docs/bluer_beast"},
]
