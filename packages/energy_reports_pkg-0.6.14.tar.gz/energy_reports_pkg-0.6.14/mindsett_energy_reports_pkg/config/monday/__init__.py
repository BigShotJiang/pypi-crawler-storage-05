
from . import auth
from .columns_concerned import columns_concerned

board_id = '6323575451'
# columns_to_exclude=['Last Updated', 'timezone', 'floor_size']

email_prefix = 'email'