__all__ = [
    "__version__",
]

__version__ = "0.1.0"

# Convenience imports
from .core.app import PooolifyApp  # noqa: E402,F401

