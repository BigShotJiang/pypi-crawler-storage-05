# DO NOT EDIT
# Generated from .copier-answers.yml

from slidgram import main

main()
