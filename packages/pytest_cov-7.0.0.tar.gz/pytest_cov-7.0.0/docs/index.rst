Welcome to pytest-cov's documentation!
======================================

Contents:

.. toctree::
    :maxdepth: 2

    readme
    config
    reporting
    debuggers
    xdist
    subprocess-support
    contexts
    tox
    plugins
    markers-fixtures
    changelog
    authors
    releasing
    contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
