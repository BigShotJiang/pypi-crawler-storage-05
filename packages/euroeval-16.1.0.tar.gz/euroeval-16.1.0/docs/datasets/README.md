---
hide:
    - toc
---
# Datasets

👈 Choose a language on the left to see all the evaluation datasets available for that
language.
