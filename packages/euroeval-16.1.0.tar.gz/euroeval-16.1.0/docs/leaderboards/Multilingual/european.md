---
hide:
    - toc
---
# 🇪🇺 European

See the [leaderboard page](/leaderboards) for more information about all the columns.

/// tab | Generative Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-SZIle" src="https://datawrapper.dwcdn.net/SZIle" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="833" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",(function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}}))}();</script>
///

/// tab | NLU Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-IaQfD" src="https://datawrapper.dwcdn.net/IaQfD" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="775" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",(function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}}))}();</script>
///

/// tab | Generative Scatter Plot
<iframe title="Few-shot Performance of Generative Language Models on European Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-IZOX3" src="https://datawrapper.dwcdn.net/IZOX3/21/" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",(function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}}))}();</script>
///

/// tab | NLU Scatter Plot
<iframe title="Few-shot Performance of Language Models on European NLU Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-YcCTL" src="https://datawrapper.dwcdn.net/YcCTL/47/" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",(function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}}))}();</script>
///
