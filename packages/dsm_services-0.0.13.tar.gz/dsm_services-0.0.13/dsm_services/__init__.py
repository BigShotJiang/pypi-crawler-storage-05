__title__ = 'DigitalStoreMesh Services'
__version__ = '0.0.13'
__author__ = 'DigitalStoreMesh Co.,Ltd'
__license__ = 'MIT'

VERSION = __version__
