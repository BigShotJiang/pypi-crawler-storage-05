This package provides ZMI-based browser management pages and menu items
for zope.catalog - the cataloging and indexing framework for Zope 3.
