* `KMEE <https://www.kmee.com.br>`_:

  * Luis Felipe Mileo <mileo@kmee.com.br>
  * Fernando Marcato
  * Hendrix Costa <hendrix.costa@kmee.com.br>

* `Akretion <https://www.akretion.com/pt-BR>`_:

  * Magno Costa <magno.costa@akretion.com.br>

* `Engenere <https://engenere.one>`_:

  * Antônio S. Pereira Neto <neto@engenere.one>

* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>
