"""Utils module for stac_auth_proxy."""
