# Custom Integration Example

This example demonstrates how to integrate with a custom filter generator.

## Running the Example

From the root directory, run:

```sh
docker compose -f docker-compose.yaml -f examples/custom-integration/docker-compose.yaml up
```
