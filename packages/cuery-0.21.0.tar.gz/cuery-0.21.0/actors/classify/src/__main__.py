import asyncio

from cuery.actors import classify

asyncio.run(classify.main())
