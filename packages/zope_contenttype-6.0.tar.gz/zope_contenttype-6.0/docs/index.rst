.. include:: ../README.rst

.. toctree::
   :maxdepth: 2

   api


.. toctree::
   :maxdepth: 2

   changelog

Development
===========

zope.contenttype is hosted at GitHub:

    https://github.com/zopefoundation/zope.contenttype/



Project URLs
============

* https://pypi.python.org/pypi/zope.contenttype       (PyPI entry and downloads)


====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
