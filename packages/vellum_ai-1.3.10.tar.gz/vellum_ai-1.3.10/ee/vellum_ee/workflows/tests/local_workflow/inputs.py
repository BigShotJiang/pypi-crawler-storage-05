from vellum.workflows.inputs import BaseInputs


class Inputs(BaseInputs):
    input_value: str
