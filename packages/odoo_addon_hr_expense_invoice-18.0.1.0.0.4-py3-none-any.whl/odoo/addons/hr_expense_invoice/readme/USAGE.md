**Reference one invoice to an expense**

- Create an expense sheet.
- Add an expense line to sheet with an invoice_id selected or create one
  new.
- Process expense sheet.
- On paying expense sheet, you are reconciling supplier invoice too.

**Create one invoice to multiple expenses**

- Create an expense sheet with one or multiple expense lines
- After approved, click button "Create Vendor Bill"
- Select multiple expense to create an invoice, and process it.
- New invoice will be create and link to the selected expense lines.
- Validate newly create invoice.
- On paying expense sheet, you are reconciling supplier invoice(s) too.
