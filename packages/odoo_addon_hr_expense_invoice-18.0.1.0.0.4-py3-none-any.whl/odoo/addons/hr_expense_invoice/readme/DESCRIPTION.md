This module should be used when a supplier invoice is paid by an
employee. It allows to set a supplier invoice for each expense line,
adding the corresponding journal items to transfer the debt to the
employee.

There are 2 ways to reference expense to invoice.

1.  On expense, directly select one invoice.
2.  On expense report, use button "Create Vendor Bill" to create one
    invoice for multiple expenses.
