from . import stock_picking
from . import res_partner
