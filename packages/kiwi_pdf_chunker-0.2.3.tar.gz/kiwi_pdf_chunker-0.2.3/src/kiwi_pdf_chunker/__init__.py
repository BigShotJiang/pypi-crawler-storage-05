"""
PDF Parser - A tool for chunking PDF documents.

This package provides tools to structurally parse PDF documents
"""

__version__ = "0.2.3"