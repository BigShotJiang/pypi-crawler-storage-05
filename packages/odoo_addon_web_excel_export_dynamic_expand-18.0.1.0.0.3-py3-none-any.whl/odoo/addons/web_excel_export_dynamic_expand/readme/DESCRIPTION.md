When exporting a tree view to an Excel file, you can decide if you want
to export only the main groups or the full tree, depending if all groups
are collapsed, or there is one open.
