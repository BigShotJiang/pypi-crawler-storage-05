# These packages will be checked by the updater extension for updates on
# conda and pip
packages = ['opensesame-plugin-audio_low_latency']
