# flake8: noqa

STYLESHEETS.append(data("cubes.i18nfield.css"))
