# flake8: noqa

change_attribute_type("I18nField", "last_edited", "TZDatetime", ask_confirm=False)
