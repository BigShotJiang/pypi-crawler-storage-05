"""cubicweb-i18nfield application package

Provides a way to translate entity fields individually.
"""
