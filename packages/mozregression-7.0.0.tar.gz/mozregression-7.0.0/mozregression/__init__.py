from .version import version

__version__ = version
