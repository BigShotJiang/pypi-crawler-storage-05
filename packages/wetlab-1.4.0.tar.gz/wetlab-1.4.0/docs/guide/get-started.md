# Get started

Install all required dependencies:

```bash
pip install wetlab
```

Init your instance

```bash
lamin init --storage ./test-wetlab --modules bionty,wetlab
```

Everything else works exactly as for any other schema module and the core registries.
