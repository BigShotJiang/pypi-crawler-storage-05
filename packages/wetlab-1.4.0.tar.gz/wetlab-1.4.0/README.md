# `wetlab`: Wetlab registries

Read the docs: [docs.lamin.ai/wetlab](https://docs.lamin.ai/wetlab).
