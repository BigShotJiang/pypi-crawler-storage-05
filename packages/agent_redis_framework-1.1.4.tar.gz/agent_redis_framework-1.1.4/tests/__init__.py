"""Multi-Task Framework Test Suite

This package contains FastAPI-based RESTful API for testing
SortedSetQueue and RedisStreamsClient functionality.
"""