def main():
    print("Hello from water-column-sonar-resampling!")


if __name__ == "__main__":
    main()
