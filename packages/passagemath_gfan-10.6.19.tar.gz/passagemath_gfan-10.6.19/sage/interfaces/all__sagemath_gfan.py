# sage_setup: distribution = sagemath-gfan
