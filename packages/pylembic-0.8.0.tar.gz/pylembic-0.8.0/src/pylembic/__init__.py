"""Package configuration"""

__author__ = "Marco Espinosa"
__email__ = "marco@marcoespinosa.com"
