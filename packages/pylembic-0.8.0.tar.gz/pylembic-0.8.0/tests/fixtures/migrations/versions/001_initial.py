"""initial migration"""

revision = "001"
down_revision = None
branch_labels = None
depends_on = None
