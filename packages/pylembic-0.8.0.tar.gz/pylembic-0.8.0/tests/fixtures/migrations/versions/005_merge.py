"""merge branches"""

revision = "005"
down_revision = ("003", "004")
branch_labels = None
depends_on = None
