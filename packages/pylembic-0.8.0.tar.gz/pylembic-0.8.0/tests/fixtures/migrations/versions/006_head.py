"""head migration"""

revision = "006"
down_revision = "005"
branch_labels = None
depends_on = None
