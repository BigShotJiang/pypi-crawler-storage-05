"""initial migration"""

revision = "001"
down_revision = "004"
branch_labels = None
depends_on = None
