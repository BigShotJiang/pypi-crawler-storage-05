"""update table migration"""

revision = "003"
down_revision = "002"
branch_labels = None
depends_on = None
