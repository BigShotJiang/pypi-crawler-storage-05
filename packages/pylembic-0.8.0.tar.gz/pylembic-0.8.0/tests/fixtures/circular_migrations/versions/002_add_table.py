"""add table migration"""

revision = "002"
down_revision = "001"
branch_labels = None
depends_on = None
