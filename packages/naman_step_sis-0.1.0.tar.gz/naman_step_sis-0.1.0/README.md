# namanGay

A meme Python package that types text letter by letter with a blinking cursor.

## Example

```python
import namanGay

namanGay.type_writer("Sumit is Gay and Zade is transgender",
                     delay=0.25,
                     pause_after="Sumit is Gay",
                     pause_time=0.75)
