from manim_voiceover_fixed.tracker import VoiceoverTracker
from manim_voiceover_fixed.voiceover_scene import VoiceoverScene

import pkg_resources

__version__: str = pkg_resources.get_distribution(__name__).version
