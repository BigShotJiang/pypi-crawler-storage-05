from ckan import types


def mc_mail_create(context: types.Context, data_dict: types.DataDict):
    return {"success": False}


def mc_mail_list(context: types.Context, data_dict: types.DataDict):
    return {"success": False}


def mc_mail_show(context: types.Context, data_dict: types.DataDict):
    return {"success": False}


def mc_mail_delete(context: types.Context, data_dict: types.DataDict):
    return {"success": False}
