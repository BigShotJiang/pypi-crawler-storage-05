from django.apps import AppConfig


class BlogHj3415Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blog_hj3415'
