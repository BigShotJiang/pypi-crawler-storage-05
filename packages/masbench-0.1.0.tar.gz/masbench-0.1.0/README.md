# MASBench

Multi-Agent System Benchmark

A super amazing simple MAS Benchmark library is coming. Stay Tuned!
