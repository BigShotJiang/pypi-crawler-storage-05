"""
Module that for utilities

"""

DATESTR = "%Y-%m-%dT%H:%M:%S.%f"  # Format for datetime strings compatible with SPICE
