# from .base_manager import BaseManager

class FriendManager(list): # (BaseManager):
	def mutuals(self):
		raise Exception("Not implemented")