from .base import Base

class BaseStructure(Base):
	def int(self):
		return self.id