API_BASE_URL = "https://www.freeriderhd.com"
MAX_RETRIES = 5
TIMEOUT = 10