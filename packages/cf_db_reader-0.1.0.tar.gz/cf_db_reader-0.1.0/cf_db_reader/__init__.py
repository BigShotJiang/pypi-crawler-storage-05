# __init__.py
"""
MIT License

Minimal in-memory cf_db_reader package.
Reads Cloudflare API credentials from environment variables and executes a tiny
SQL-like query against an in-memory dataset. Returns results as a list of dictionaries.

Note: This is a pure-Python, stdlib-only demonstration and does not perform
network requests.
"""

import os
import re
from typing import List, Dict, Any

def cf_db_query(database_id: str, sql_query: str) -> List[Dict[str, Any]]:
    """
    Execute a tiny-in-memory SQL-like query against a mock dataset for a given
    Cloudflare account/database, using credentials provided via environment
    variables.

    This function does not perform real network operations. It validates that
    CF_API_TOKEN and CF_ACCOUNT_ID are present and uses them to select a small
    in-memory dataset scoped by (account_id, database_id).

    Supported syntax (very small subset):
      - SELECT * FROM <table>
      - SELECT col1, col2 FROM <table> WHERE col = <value>

    Parameters:
      - database_id: string identifier for the mocked database
      - sql_query: SQL-like query string

    Returns:
      - list[dict]: rows matching the query, with columns selected as requested
    """
    token = os.environ.get("CF_API_TOKEN")
    account_id = os.environ.get("CF_ACCOUNT_ID")
    if not token or not account_id:
        raise ValueError("Missing CF_API_TOKEN or CF_ACCOUNT_ID environment variables.")

    # Mock dataset per account/database
    dataset = {
        account_id: {
            database_id: {
                "users": [
                    {"id": 1, "name": "Alice", "role": "admin"},
                    {"id": 2, "name": "Bob", "role": "user"},
                    {"id": 3, "name": "Charlie", "role": "user"},
                    {"id": 4, "name": "Diana", "role": "guest"},
                ]
            }
        }
    }

    sql = sql_query.strip()
    m = re.fullmatch(r"SELECT\s+(?P<cols>[\*\w,\s]+)\s+FROM\s+(?P<table>\w+)(\s+WHERE\s+(?P<where>.+))?", sql, flags=re.IGNORECASE)
    if not m:
        raise ValueError(f"Unsupported query: {sql_query}")

    cols_str = m.group("cols").strip()
    table = m.group("table").strip()
    where_clause = m.group("where")

    if account_id not in dataset or database_id not in dataset[account_id] or table not in dataset[account_id][database_id]:
        return []

    rows = dataset[account_id][database_id][table]

    # Apply WHERE if provided
    if where_clause:
        where = where_clause.strip()
        w_match = re.fullmatch(r"(?P<col>\w+)\s*=\s*(?P<val>.+)", where, flags=re.IGNORECASE)
        if not w_match:
            raise ValueError(f"Unsupported WHERE clause: {where_clause}")
        col = w_match.group("col")
        val_raw = w_match.group("val").strip()
        if val_raw.startswith("'") and val_raw.endswith("'"):
            val = val_raw[1:-1]
        elif val_raw.isdigit():
            val = int(val_raw)
        else:
            val = val_raw
        filtered = []
        for row in rows:
            if col in row and row[col] == val:
                filtered.append(row)
        rows = filtered

    if cols_str.strip() == "*" or cols_str.strip() == "":
        result = [dict(r) for r in rows]
    else:
        cols = [c.strip() for c in cols_str.split(",")]
        result = []
        for r in rows:
            new_row = {}
            for c in cols:
                new_row[c] = r.get(c)
            result.append(new_row)

    return result