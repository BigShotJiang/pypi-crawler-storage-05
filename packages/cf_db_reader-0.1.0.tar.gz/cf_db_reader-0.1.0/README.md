[![PyPI version](https://badge.fury.io/py/cf_db_reader.svg)](https://badge.fury.io/py/cf_db_reader)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/cf_db_reader)](https://pepy.tech/project/cf_db_reader)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)

# cf_db_reader

`cf_db_reader` is a minimal Python package that retrieves Cloudflare API credentials from environment variables and executes simple in-memory SQL-like queries against mocked datasets related to Cloudflare accounts. It returns query results as a list of dictionaries.

## Installation

To install `cf_db_reader`, run:

```bash
pip install cf_db_reader
```

## Usage

Set the required environment variables `CF_API_TOKEN` and `CF_ACCOUNT_ID`, then use the `cf_db_query` function to perform queries. Here's a basic example:

```python
import os
from cf_db_reader import cf_db_query

# Set environment variables
os.environ['CF_API_TOKEN'] = 'your_token_here'
os.environ['CF_ACCOUNT_ID'] = 'your_account_id_here'

# Perform a query
result = cf_db_query('example_db', 'SELECT * FROM users WHERE role = "user"')
print(result)
# Expected output: [{'id': 2, 'name': 'Bob', 'role': 'user'}, {'id': 3, 'name': 'Charlie', 'role': 'user'}]
```

*Note:* This package does not perform real network requests. It uses in-memory mocked data for demonstration.

## Short Example

```python
import os
from cf_db_reader import cf_db_query

os.environ['CF_API_TOKEN'] = 'mock_token'
os.environ['CF_ACCOUNT_ID'] = 'mock_account'

# Query all users
all_users = cf_db_query('my_db', 'SELECT * FROM users')
print(all_users)

# Query specific fields with a WHERE clause
admins = cf_db_query('my_db', "SELECT id, name FROM users WHERE role = 'admin'")
print(admins)
```

## Author

Eugene Evstafev <hi@eugene.plus>

Repository: [https://github.com/chigwell/cf_db_reader](https://github.com/chigwell/cf_db_reader)