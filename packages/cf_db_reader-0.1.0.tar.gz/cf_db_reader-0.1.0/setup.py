from setuptools import setup, find_packages
import pathlib

here = pathlib.Path(__file__).resolve().parent
long_description = ""
readme_path = here / "README.md"
if readme_path.exists():
    long_description = readme_path.read_text(encoding="utf-8")

setup(
    name="cf_db_reader",
    version="0.1.0",
    author="Eugene Evstafev",
    author_email="hi@eugene.plus",
    description="A tiny in-memory Cloudflare API reader that reads API credentials from environment variables and executes a simple SQL-like query against a mock dataset.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/chigwell/cf_db_reader",
    packages=find_packages(),
    install_requires=[],
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    license="MIT",
    tests_require=["unittest"],
    test_suite="test",
)