=========
Functions
=========

is_async_test
=============
Returns whether a specific pytest Item is an asynchronous test managed by pytest-asyncio.

This function is intended to be used in pytest hooks or by plugins that depend on pytest-asyncio.
