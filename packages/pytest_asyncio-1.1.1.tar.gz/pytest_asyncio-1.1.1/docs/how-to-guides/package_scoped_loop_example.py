import pytest

pytestmark = pytest.mark.asyncio(loop_scope="package")
