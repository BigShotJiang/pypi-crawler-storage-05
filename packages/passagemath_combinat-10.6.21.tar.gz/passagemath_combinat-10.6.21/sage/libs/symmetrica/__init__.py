# sage_setup: distribution = sagemath-combinat

# Fail early if runtime deps of symmetrica are not available;
# symmetrica does not handle this well.

import sage.combinat.tableau
import sage.matrix.constructor
