# sage_setup: distribution = sagemath-combinat
from sage.rings.all__sagemath_categories import *
