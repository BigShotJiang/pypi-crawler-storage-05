# sage_setup: distribution = sagemath-combinat
r"""
Counting

- :ref:`sage.combinat.combinat`
- :ref:`sage.combinat.q_analogues`, :ref:`sage.combinat.q_bernoulli`
- :ref:`sage.combinat.binary_recurrence_sequences`
- :ref:`sage.combinat.expnums`
- :ref:`sage.rings.cfinite_sequence`
- :ref:`sage.databases.oeis`
- :ref:`sage.combinat.sloane_functions`
"""
