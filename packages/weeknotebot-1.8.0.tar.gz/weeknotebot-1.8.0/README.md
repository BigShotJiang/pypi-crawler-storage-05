# WeekNote Bot

This is a little script for generate a WeekNote for your Hugo static site.

## Run it

You launch after installing with

``` bash
weeknote
```

if you have your config at **~/.config/weeknote_bot/config.json** or you can run the command with the path of the config

``` bash
weeknote -config <path-of-the-config>
```

If it is the first time you run it, it will generate a black config and end the execution of the program
