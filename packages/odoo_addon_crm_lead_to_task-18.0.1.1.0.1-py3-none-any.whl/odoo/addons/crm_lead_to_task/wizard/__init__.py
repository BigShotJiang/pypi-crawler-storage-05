# License LGPL-3 - See https://www.gnu.org/licenses/lgpl-3.0.html
from . import crm_lead_convert2task
