This module allows you to convert leads or opportunities into project tasks.
It supports the following features:

- Optional automatic archiving of the lead after conversion.

- Ability to configure a Force Project so tasks are created directly without a popup.

- Preserves attachments and messages from the lead.

**DISCLAIMER:** This module is a forward-port of a module from Odoo S.A.
and as such, it is not included in the OCA CLA. That means we do not
have a copy of the copyright on it like all other OCA modules.
