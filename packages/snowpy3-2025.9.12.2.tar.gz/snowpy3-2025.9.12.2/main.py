def main():
    print("Hello from snowpy3!")


if __name__ == "__main__":
    main()
