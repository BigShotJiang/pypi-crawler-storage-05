.. include:: ../README.rst

Contents:

.. toctree::
   :maxdepth: 2

   api
   changelog

Development
===========

zope.filerepresentation is hosted at GitHub:

    https://github.com/zopefoundation/zope.filerepresentation/

Project URLs
============

* http://pypi.python.org/pypi/zope.filerepresentation       (PyPI entry and downloads)

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
