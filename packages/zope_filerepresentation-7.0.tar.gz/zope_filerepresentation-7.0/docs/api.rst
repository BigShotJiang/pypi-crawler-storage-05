====================================
 :mod:`zope.filerepresentation` API
====================================

.. automodule:: zope.filerepresentation.interfaces
