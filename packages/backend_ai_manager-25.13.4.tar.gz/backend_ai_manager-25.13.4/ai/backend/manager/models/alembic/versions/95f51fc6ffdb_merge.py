"""merge

Revision ID: 95f51fc6ffdb
Revises: 6129745f49b6, 5bce905c21e5
Create Date: 2022-11-24 08:40:16.719312

"""

# revision identifiers, used by Alembic.
revision = "95f51fc6ffdb"
down_revision = ("6129745f49b6", "5bce905c21e5")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
