"""Deployment repository for managing model service deployments."""

from .repository import DeploymentRepository

__all__ = ["DeploymentRepository"]
