MPSPlots's documentation
========================

**Date**: |today|, **Version**: |version|


.. include:: ../../README.rst
    :start-line: 0

.. toctree::
    :hidden:

    code
    gallery/index