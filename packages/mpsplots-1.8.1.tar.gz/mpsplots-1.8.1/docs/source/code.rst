.. _code:

Source code structures
======================

Axis
----
 .. automodule:: MPSPlots.render2D.axis
     :members:
     :inherited-members:
     :member-order: bysource



Artists list
------------
 .. automodule:: MPSPlots.render2D.artist
     :members:
     :inherited-members:
     :member-order: bysource
























