def test_empty():
    assert 1 == 1, "Empty"