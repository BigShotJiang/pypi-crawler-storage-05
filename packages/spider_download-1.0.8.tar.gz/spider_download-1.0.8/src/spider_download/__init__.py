from .spider import Spider

default_proxies = {"https": "http://127.0.0.1:7890", "http": "http://127.0.0.1:7890"}
