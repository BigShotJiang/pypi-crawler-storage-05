# cidwrap

A FastAPI middleware wrapper for logging correlation events with customizable correlation IDs.

## Installation

Install the package via pip:

```bash
pip install cidwrap
