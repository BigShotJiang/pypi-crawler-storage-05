"""
Version information for MCP Proxy Adapter.
"""

__version__ = "6.2.36"

