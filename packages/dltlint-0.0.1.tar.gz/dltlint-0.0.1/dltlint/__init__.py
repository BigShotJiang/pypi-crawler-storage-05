def hello() -> str:
    return "Hello from dltlint!"
