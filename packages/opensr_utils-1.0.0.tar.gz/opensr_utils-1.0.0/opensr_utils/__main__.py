# -*- coding: utf-8 -*-
"""Module entry-point: enables `python -m opensr_utils`."""
from main import main
if __name__ == "__main__":
    main()
