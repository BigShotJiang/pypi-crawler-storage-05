"""CLI module for scorebook."""
