__version__ = '1.27.5'
__commit_hash__ = 'ffb9a258f68c87a2b7981f456e85ff10dda1535e'
findlibs_dependencies = ["eccodeslib", "eckitlib", "atlaslib_ecmwf"]
