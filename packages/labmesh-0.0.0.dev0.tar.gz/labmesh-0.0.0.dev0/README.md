# labmesh
Mesh networking package using ZeroMQ specifically designed for constellation.
