# delphai-rpc
Queue-based RPC client and server
