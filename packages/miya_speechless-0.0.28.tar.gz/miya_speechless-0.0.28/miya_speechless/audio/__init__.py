"""Init audio module."""
