"""Init transcription module."""
