"""Init nlp module."""
