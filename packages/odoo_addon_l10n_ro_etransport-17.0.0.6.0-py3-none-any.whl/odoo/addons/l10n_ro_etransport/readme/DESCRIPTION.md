The module will generate E-Transport XML files according to ANAF
E-Transport service.

<https://mfinante.gov.ro/ro/web/etransport/informatii-tehnice>

Pentru functionarea acestui modul este necesara instalarea modulului de
intrastat
