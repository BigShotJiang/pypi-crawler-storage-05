"""
InteractiveExecutor module contains components of an executor
that can run your vector embeddings on a local computer
and store them in a specified vector database.
"""
