from cooper_epic_jungle.core.jungle import COOPER_EPIC_JUNGLE, EPT
