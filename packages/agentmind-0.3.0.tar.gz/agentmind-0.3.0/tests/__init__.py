"""
AgentMind test suite.
"""