# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from __future__ import annotations

import logging

from pydantic import BaseModel
from datetime import datetime
from typing import Optional

from microsoft_agents.activity import (
    Activity,
    ActivityTypes,
    TokenExchangeState,
    TokenResponse,
    SignInResource,
)

from ..connector.client import UserTokenClient
from .flow_state import FlowState, FlowStateTag, FlowErrorTag

logger = logging.getLogger(__name__)


class FlowResponse(BaseModel):
    """Represents the response for a flow operation."""

    flow_state: FlowState = FlowState()
    flow_error_tag: FlowErrorTag = FlowErrorTag.NONE
    token_response: Optional[TokenResponse] = None
    sign_in_resource: Optional[SignInResource] = None
    continuation_activity: Optional[Activity] = None


class OAuthFlow:
    """
    Manages the OAuth flow.

    This class is responsible for managing the entire OAuth flow, including
    obtaining user tokens, signing out users, and handling token exchanges.

    Contract with other classes (usage of other classes is enforced in unit tests):
        TurnContext.activity.channel_id
        TurnContext.activity.from_property.id

        UserTokenClient: user_token.get_token(), user_token.sign_out()
    """

    def __init__(
        self, flow_state: FlowState, user_token_client: UserTokenClient, **kwargs
    ):
        """
        Arguments:
            flow_state: The state of the flow.
            user_token_client: The user token client to use for token operations.

        Keyword Arguments:
            flow_duration: The duration of the flow in milliseconds (default: 60000).
            max_attempts: The maximum number of attempts for the flow
                set when starting a flow (default: 3).
        """
        if not flow_state or not user_token_client:
            raise ValueError(
                "OAuthFlow.__init__(): flow_state and user_token_client are required"
            )

        if (
            not flow_state.connection
            or not flow_state.ms_app_id
            or not flow_state.channel_id
            or not flow_state.user_id
        ):
            raise ValueError(
                "OAuthFlow.__init__: flow_state must have ms_app_id, channel_id, user_id, connection defined"
            )

        logger.debug("Initializing OAuthFlow with flow state: %s", flow_state)

        self._flow_state = flow_state.model_copy()

        self._abs_oauth_connection_name = self._flow_state.connection
        self._ms_app_id = self._flow_state.ms_app_id
        self._channel_id = self._flow_state.channel_id
        self._user_id = self._flow_state.user_id

        self._user_token_client = user_token_client

        self._default_flow_duration = kwargs.get(
            "default_flow_duration", 10 * 60
        )  # default to 10 minutes
        self._max_attempts = kwargs.get("max_attempts", 3)  # defaults to 3 max attempts

        logger.debug(
            "OAuthFlow initialized with connection: %s, ms_app_id: %s, channel_id: %s, user_id: %s",
            self._abs_oauth_connection_name,
            self._ms_app_id,
            self._channel_id,
            self._user_id,
        )
        logger.debug(
            "Default flow duration: %d ms, Max attempts: %d",
            self._default_flow_duration,
            self._max_attempts,
        )

    @property
    def flow_state(self) -> FlowState:
        return self._flow_state.model_copy()

    async def get_user_token(self, magic_code: str = None) -> TokenResponse:
        """Get the user token based on the context.

        Args:
            magic_code (str, optional): Defaults to None. The magic code for user authentication.

        Returns:
            TokenResponse
                The user token response.

        Notes:
            flow_state.user_token is updated with the latest token.
        """
        logger.info(
            "Getting user token for user_id: %s, connection: %s",
            self._user_id,
            self._abs_oauth_connection_name,
        )
        token_response: TokenResponse = (
            await self._user_token_client.user_token.get_token(
                user_id=self._user_id,
                connection_name=self._abs_oauth_connection_name,
                channel_id=self._channel_id,
                code=magic_code,
            )
        )
        if token_response:
            logger.info("User token obtained successfully: %s", token_response)
            self._flow_state.user_token = token_response.token
            self._flow_state.expiration = (
                datetime.now().timestamp() + self._default_flow_duration
            )
            self._flow_state.tag = FlowStateTag.COMPLETE

        return token_response

    async def sign_out(self) -> None:
        """Sign out the user.

        Sets the flow state tag to NOT_STARTED
        Resets the flow state user_token field
        """
        logger.info(
            "Signing out user_id: %s from connection: %s",
            self._user_id,
            self._abs_oauth_connection_name,
        )
        await self._user_token_client.user_token.sign_out(
            user_id=self._user_id,
            connection_name=self._abs_oauth_connection_name,
            channel_id=self._channel_id,
        )
        self._flow_state.user_token = ""
        self._flow_state.tag = FlowStateTag.NOT_STARTED

    def _use_attempt(self) -> None:
        """Decrements the remaining attempts for the flow, checking for failure."""
        self._flow_state.attempts_remaining -= 1
        if self._flow_state.attempts_remaining <= 0:
            self._flow_state.tag = FlowStateTag.FAILURE
        logger.debug(
            "Using an attempt for the OAuth flow. Attempts remaining after use: %d",
            self._flow_state.attempts_remaining,
        )

    async def begin_flow(self, activity: Activity) -> FlowResponse:
        """Begins the OAuthFlow.

        Args:
            activity: The activity that initiated the flow.

        Returns:
            The response containing the flow state and sign-in resource if applicable.

        Notes:
            The flow state is reset if a token is not obtained from cache.
        """
        token_response = await self.get_user_token()
        if token_response:
            return FlowResponse(
                flow_state=self._flow_state, token_response=token_response
            )

        logger.debug("Starting new OAuth flow")
        self._flow_state.tag = FlowStateTag.BEGIN
        self._flow_state.expiration = (
            datetime.now().timestamp() + self._default_flow_duration
        )

        self._flow_state.attempts_remaining = self._max_attempts
        self._flow_state.user_token = ""
        self._flow_state.continuation_activity = activity.model_copy()

        token_exchange_state = TokenExchangeState(
            connection_name=self._abs_oauth_connection_name,
            conversation=activity.get_conversation_reference(),
            relates_to=activity.relates_to,
            ms_app_id=self._ms_app_id,
        )

        sign_in_resource = (
            await self._user_token_client.agent_sign_in.get_sign_in_resource(
                state=token_exchange_state.get_encoded_state()
            )
        )

        logger.debug("Sign-in resource obtained successfully: %s", sign_in_resource)

        return FlowResponse(
            flow_state=self._flow_state, sign_in_resource=sign_in_resource
        )

    async def _continue_from_message(
        self, activity: Activity
    ) -> tuple[TokenResponse, FlowErrorTag]:
        """Handles the continuation of the flow from a message activity."""
        magic_code: str = activity.text
        if magic_code and magic_code.isdigit() and len(magic_code) == 6:
            token_response: TokenResponse = await self.get_user_token(magic_code)

            if token_response:
                return token_response, FlowErrorTag.NONE
            else:
                return token_response, FlowErrorTag.MAGIC_CODE_INCORRECT
        else:
            return TokenResponse(), FlowErrorTag.MAGIC_FORMAT

    async def _continue_from_invoke_verify_state(
        self, activity: Activity
    ) -> TokenResponse:
        """Handles the continuation of the flow from an invoke activity for verifying state."""
        token_verify_state = activity.value
        magic_code: str = token_verify_state.get("state")
        token_response: TokenResponse = await self.get_user_token(magic_code)
        return token_response

    async def _continue_from_invoke_token_exchange(
        self, activity: Activity
    ) -> TokenResponse:
        """Handles the continuation of the flow from an invoke activity for token exchange."""
        token_exchange_request = activity.value
        token_response = await self._user_token_client.user_token.exchange_token(
            user_id=self._user_id,
            connection_name=self._abs_oauth_connection_name,
            channel_id=self._channel_id,
            body=token_exchange_request,
        )
        return token_response

    async def continue_flow(self, activity: Activity) -> FlowResponse:
        """Continues the OAuth flow based on the incoming activity.

        Args:
            activity: The incoming activity to continue the flow with.

        Returns:
            A FlowResponse object containing the updated flow state and any token response.

        """
        logger.debug("Continuing auth flow...")

        if not self._flow_state.is_active():
            logger.debug("OAuth flow is not active, cannot continue")
            self._flow_state.tag = FlowStateTag.FAILURE
            return FlowResponse(
                flow_state=self._flow_state.model_copy(), token_response=None
            )

        flow_error_tag = FlowErrorTag.NONE
        if activity.type == ActivityTypes.message:
            token_response, flow_error_tag = await self._continue_from_message(activity)
        elif (
            activity.type == ActivityTypes.invoke
            and activity.name == "signin/verifyState"
        ):
            token_response = await self._continue_from_invoke_verify_state(activity)
        elif (
            activity.type == ActivityTypes.invoke
            and activity.name == "signin/tokenExchange"
        ):
            token_response = await self._continue_from_invoke_token_exchange(activity)
        else:
            raise ValueError(f"Unknown activity type {activity.type}")

        if not token_response and flow_error_tag == FlowErrorTag.NONE:
            flow_error_tag = FlowErrorTag.OTHER

        if flow_error_tag != FlowErrorTag.NONE:
            logger.debug("Flow error occurred: %s", flow_error_tag)
            self._flow_state.tag = FlowStateTag.CONTINUE
            self._use_attempt()
        else:
            self._flow_state.tag = FlowStateTag.COMPLETE
            self._flow_state.expiration = (
                datetime.now().timestamp() + self._default_flow_duration
            )
            self._flow_state.user_token = token_response.token
            logger.debug(
                "OAuth flow completed successfully, got TokenResponse: %s",
                token_response,
            )

        return FlowResponse(
            flow_state=self._flow_state.model_copy(),
            flow_error_tag=flow_error_tag,
            token_response=token_response,
            continuation_activity=self._flow_state.continuation_activity,
        )

    async def begin_or_continue_flow(self, activity: Activity) -> FlowResponse:
        """Begins a new OAuth flow or continues an existing one based on the activity.

        Args:
            activity: The incoming activity to begin or continue the flow with.

        Returns:
            A FlowResponse object containing the updated flow state and any token response.
        """
        self._flow_state.refresh()
        if self._flow_state.tag == FlowStateTag.COMPLETE:  # robrandao: TODO -> test
            logger.debug("OAuth flow has already been completed, nothing to do")
            return FlowResponse(
                flow_state=self._flow_state.model_copy(),
                token_response=TokenResponse(token=self._flow_state.user_token),
            )

        if self._flow_state.is_active():
            logger.debug("Active flow, continuing...")
            return await self.continue_flow(activity)

        logger.debug("No active flow, beginning new flow...")
        return await self.begin_flow(activity)
