# GetAllOptJobs

Array of job IDs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**[OptimizationJob]**](OptimizationJob.md) | Array of job IDs | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


