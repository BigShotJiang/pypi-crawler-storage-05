# CalColBooleanExpression

An expression that evaluates to either True or False 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**lit** | **[bool]** | A literal boolean value. The first argument must be a valid number  | [optional] 
**_and** | [**[CalColBooleanExpression]**](CalColBooleanExpression.md) |  | [optional] 
**_or** | [**[CalColBooleanExpression]**](CalColBooleanExpression.md) |  | [optional] 
**_not** | [**[CalColBooleanExpression]**](CalColBooleanExpression.md) |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


