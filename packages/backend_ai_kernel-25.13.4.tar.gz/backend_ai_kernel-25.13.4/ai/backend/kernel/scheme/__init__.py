import logging
import tempfile

from .. import BaseRunner

log = logging.getLogger()


class Runner(BaseRunner):
    log_prefix = "scheme-kernel"
    default_runtime_path = "/usr/bin/rustc"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    async def init_with_loop(self):
        pass

    async def build_heuristic(self) -> int:
        return 0

    async def execute_heuristic(self) -> int:
        return 0

    async def query(self, code_text) -> int:
        with tempfile.NamedTemporaryFile(suffix=".scm", dir=".") as tmpf:
            tmpf.write(code_text.encode("utf8"))
            tmpf.flush()
            cmd = f"scheme --quiet < {tmpf.name}"
            return await self.run_subproc(cmd)

    async def complete(self, data):
        return []

    async def interrupt(self):
        # subproc interrupt is already handled by BaseRunner
        pass

    async def start_service(self, service_info):
        return None, {}
