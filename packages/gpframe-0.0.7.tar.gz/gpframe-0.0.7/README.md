# gpframe

A general-purpose framework for managing routine execution with concurrency, event handling, and lifecycle control.

Note: This project is in an early stage. It currently provides implementation only, with no tests yet.

[![PyPI version](https://img.shields.io/pypi/v/gpframe.svg)](https://pypi.org/project/gpframe/)

