"""
Command implementations for KiCad Library Manager CLI.
"""
