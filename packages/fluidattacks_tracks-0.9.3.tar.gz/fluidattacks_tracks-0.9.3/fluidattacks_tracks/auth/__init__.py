"""Tracks authentication."""
