"""Implements common types used across the VTN module."""
