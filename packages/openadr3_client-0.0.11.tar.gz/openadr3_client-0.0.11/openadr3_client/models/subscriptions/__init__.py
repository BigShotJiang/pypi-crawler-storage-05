"""
Subscriptions domain module.

This module implements all the subscriptions-related domain objects of the OpenADR3 Client library.
"""
