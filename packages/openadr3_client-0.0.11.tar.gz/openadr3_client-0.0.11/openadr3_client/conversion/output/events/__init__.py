"""Contains types and logic for the conversion of OpenADR3 events to predefined output formats."""
