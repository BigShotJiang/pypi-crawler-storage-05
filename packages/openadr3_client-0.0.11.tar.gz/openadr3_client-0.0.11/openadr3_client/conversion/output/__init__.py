"""Contains types and logic for the conversion of OpenADR3 entities to predefined output formats."""
