"""OpenADR3 client root module."""
