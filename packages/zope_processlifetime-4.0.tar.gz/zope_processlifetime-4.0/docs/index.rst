.. include:: ../README.rst

This is a simple package consisting of just a few interfaces and
implementations.

.. automodule:: zope.processlifetime

.. toctree::
   :maxdepth: 2

   changelog

Development
===========

zope.processlifetime is hosted at GitHub:

    https://github.com/zopefoundation/zope.processlifetime/



Project URLs
============

* https://pypi.python.org/pypi/zope.processlifetime       (PyPI entry and downloads)


====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
