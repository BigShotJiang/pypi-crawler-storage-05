# src/imgshape/__main__.py
from imgshape.cli import main

if __name__ == "__main__":
    main()
