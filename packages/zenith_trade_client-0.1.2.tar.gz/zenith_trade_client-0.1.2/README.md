# Zenith Trade Client

A simple Python client to interact with the **Zenith-Trade FastAPI backend**.

## Installation

```bash
pip install zenith-trade-client
