"""Synthetic dataset generation module."""

from .linear_trend import LinearTrendDataset

__all__ = [
    'LinearTrendDataset',
]