"""
SII RTC/RPETC
=============

Concepts and acronyms used interchangeably:

* "Registro Transferencia de Crédito" (RTC)
* "Registro Público Electrónico de Transferencia de Crédito" (RPETC)
* "Registro Electrónico de Cesión de Créditos"
"""
