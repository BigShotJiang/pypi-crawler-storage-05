# trollflow2
Next generation trollflow

Trollflow2 supports only Python 3.9 and newer in Linux. OS X might work, but the tests are not run on it.
