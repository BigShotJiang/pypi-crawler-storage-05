# micalcu: un proyectp PyPi

El objetivo de este proyecto es extender funcionalidad para realizar `pip install` y utilizar las funcionalidades de manera rápida y fácil.

Paquete de ejemplo. Uso:

```python
from calculadora import MiCalculadora
print(MiCalculadora(2, 3).sumar())  # 5
```

