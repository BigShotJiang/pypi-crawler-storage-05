NAME = "binance-sdk-copy-trading"
