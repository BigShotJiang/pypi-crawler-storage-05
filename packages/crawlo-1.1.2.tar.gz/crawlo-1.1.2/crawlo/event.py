#!/usr/bin/python
# -*- coding:UTF-8 -*-

spider_error = "spider_error"
spider_opened = "spider_open"
spider_closed = "spider_closed"
ignore_request = "ignore_request"
request_scheduled = "request_scheduled"
response_received = "request_received"
item_successful = "item_successful"
item_discard = "item_discard"
