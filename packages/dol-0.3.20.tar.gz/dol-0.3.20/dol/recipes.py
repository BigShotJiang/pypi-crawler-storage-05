"""Recipes using dol"""

__all__ = ["search_paths"]

from dol.paths import path_filter as search_paths  # was recipe. Promoted to paths
