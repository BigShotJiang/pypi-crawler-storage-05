module.exports = require('@jupyterlab/testutils/lib/babel.config');
