from django.apps import AppConfig

class AutoGFKConfig(AppConfig):
    name = "autogfk"
    verbose_name = "Auto Generic ForeignKey"
