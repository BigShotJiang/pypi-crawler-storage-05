DVI - Import Customs Declaration

For creating a DVi you must go to:

Accounting -\> Actions -\> DVI \* Create a new record \* Complete the
tax with VAT 19% deductible, invoices linked for this DVI \* Complete
the "Customs Duty Value" and "Customs Commission Value" \* Complete the
DVI lines quantity with the quantity declared \* Click on button "Post"
to validate the Customs declaration

At post, a landed cost is created to distribute the amounts to the
correct products and creating the account moves for the VAT paid.

You have the possibility to revert one declaration, which will create
new valuation layers with minus, and cancel the account move of the
inital landed cost.
