DVI - declaraţie vamala de import

Se face legatura dintre factura de achizitie si DVI (landed cost)

Se genereaza automat un DVI cu doua linii si cu TVA.

Contul 447 trebuie sa fie un cont de reconciliere pentru a se putea
inchide prin banca
