DEFAULT_ENDPOINT = "lambda://bdk_library/3.27.0"
