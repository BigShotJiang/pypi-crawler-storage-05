.. NOTE::  All examples in this section are using the following options:

    * header_left = '+'
    * header_left_repeat = '-'
    * header_string = '[ Header ]'
    * header_right_repeat = '='
    * comment_left = '|'
    * footer_left = '+'
    * footer_left_repeat = '-'
    * footer_string = '[ Footer ]'
    * footer_right_repeat = '='
    * min_height = 3
    * header_alignment = 'center'
    * max_header_column = 40
    * footer_alignment = 'right'
    * max_footer_column = 40
