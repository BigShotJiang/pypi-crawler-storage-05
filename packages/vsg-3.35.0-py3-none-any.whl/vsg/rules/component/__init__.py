# -*- coding: utf-8 -*-

from .rule_001 import rule_001
from .rule_002 import rule_002
from .rule_003 import rule_003
from .rule_004 import rule_004
from .rule_005 import rule_005
from .rule_006 import rule_006
from .rule_007 import rule_007
from .rule_008 import rule_008
from .rule_009 import rule_009
from .rule_010 import rule_010
from .rule_011 import rule_011
from .rule_012 import rule_012
from .rule_013 import rule_013
from .rule_014 import rule_014
from .rule_015 import rule_015
from .rule_016 import rule_016
from .rule_017 import rule_017
from .rule_018 import rule_018
from .rule_019 import rule_019
from .rule_020 import rule_020
from .rule_021 import rule_021
from .rule_022 import rule_022
