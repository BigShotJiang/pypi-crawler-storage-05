# -*- coding: utf-8 -*-


class New:
    def __init__(self, sUniqueId):
        self.unique_id = sUniqueId
