# API

```{eval-rst}
.. currentmodule:: cellosaurus_mcp.tools

.. autosummary::
   :toctree: generated
   :recursive:

   search_cell_lines
   get_cell_line_info
   get_release_info
   find_cell_lines_by_disease
   find_cell_lines_by_tissue
   list_available_fields
```
