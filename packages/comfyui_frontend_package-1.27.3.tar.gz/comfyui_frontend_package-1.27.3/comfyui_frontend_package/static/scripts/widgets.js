// Shim for scripts/widgets.ts
export const updateControlWidgetLabel = window.comfyAPI.widgets.updateControlWidgetLabel;
export const IS_CONTROL_WIDGET = window.comfyAPI.widgets.IS_CONTROL_WIDGET;
export const addValueControlWidget = window.comfyAPI.widgets.addValueControlWidget;
export const addValueControlWidgets = window.comfyAPI.widgets.addValueControlWidgets;
export const ComfyWidgets = window.comfyAPI.widgets.ComfyWidgets;
