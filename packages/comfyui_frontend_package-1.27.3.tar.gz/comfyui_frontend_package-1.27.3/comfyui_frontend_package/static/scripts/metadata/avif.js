// Shim for scripts/metadata/avif.ts
export const getFromAvifFile = window.comfyAPI.avif.getFromAvifFile;
