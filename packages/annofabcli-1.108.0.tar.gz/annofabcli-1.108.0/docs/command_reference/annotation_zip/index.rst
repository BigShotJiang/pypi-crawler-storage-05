==================================================
annotation_zip
==================================================

Description
=================================
アノテーションZIPまたはそれを展開したディレクトリ関係のコマンドです。


Available Commands
=================================


.. toctree::
   :maxdepth: 1
   :titlesonly:

   list_annotation_bounding_box_2d


Usage Details
=================================

.. argparse::
   :ref: annofabcli.annotation_zip.subcommand_annotation_zip.add_parser
   :prog: annofabcli annotation_zip
   :nosubcommands:

