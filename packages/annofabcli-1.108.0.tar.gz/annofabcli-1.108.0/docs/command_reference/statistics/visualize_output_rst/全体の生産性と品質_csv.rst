==========================================
全体の生産性と品質.csv
==========================================

全体の生産性と品質が記載されています。
:doc:`メンバごとの生産性と品質_csv` の内容を集計した値になります。


`全体の生産性と品質.csvのサンプル <https://github.com/kurusugawa-computer/annofab-cli/blob/main/docs/command_reference/statistics/visualize/out_dir/全体の生産性と品質.csv>`_

