Abra o menu Configurações\>Empresas. Dentro da aba fiscal tem uma nova
página "certificados" onde você pode fazer o upload dos certificados A1.
