Permite gerenciar seus certificados A1 para a assinar e transmitir seus
documentos eletrônicos.
