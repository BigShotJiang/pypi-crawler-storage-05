from isofit.core.instrument import wl_tol


def test_wl_tol():
    assert wl_tol == 0.01
