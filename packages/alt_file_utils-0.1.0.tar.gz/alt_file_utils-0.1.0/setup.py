"""Setup script for ALT-file-utils."""

from setuptools import setup

# The actual setup is handled by pyproject.toml
# This file exists only for compatibility with older tools
setup()
