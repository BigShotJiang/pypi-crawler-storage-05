"""Collinear SDK schemas package."""
