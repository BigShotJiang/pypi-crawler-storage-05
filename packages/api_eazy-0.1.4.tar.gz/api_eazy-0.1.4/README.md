# api-eazy

Ultra-simple async web server framework for Python.

## Installation

```bash
pip install api-eazy
