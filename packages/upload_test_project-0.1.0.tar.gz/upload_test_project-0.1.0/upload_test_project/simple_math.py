def add_numbers(a, b):
    """
    두 개의 숫자를 더하는 함수입니다.

    :param a: 첫 번째 숫자
    :param b: 두 번째 숫자
    :return: 두 숫자의 합
    """
    return a + b