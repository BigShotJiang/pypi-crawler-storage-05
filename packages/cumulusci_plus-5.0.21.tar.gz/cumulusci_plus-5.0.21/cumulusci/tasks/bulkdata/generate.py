# for backwards compatibility
from .generate_mapping import GenerateMapping

__all__ = ["GenerateMapping"]
