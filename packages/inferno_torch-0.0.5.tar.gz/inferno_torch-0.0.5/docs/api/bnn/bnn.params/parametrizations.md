::: inferno.bnn.params.parametrizations
    options:
        members:
        - Parametrization
        - Standard
        - NeuralTangent
        - MaximalUpdate