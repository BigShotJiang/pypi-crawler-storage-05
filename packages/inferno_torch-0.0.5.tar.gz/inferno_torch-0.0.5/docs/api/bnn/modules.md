::: inferno.bnn.modules
    options:
        members: true