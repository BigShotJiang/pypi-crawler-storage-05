<template>
  <ConnectedLayout>
    <template #navbar>&nbsp;</template>
    <template #topbar>&nbsp;</template>
  </ConnectedLayout>
</template>

<script setup>
import ConnectedLayout from '@/layouts/connected/ConnectedLayout.vue'
</script>
