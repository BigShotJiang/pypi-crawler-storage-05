from .index import front_matter_plugin

__all__ = ("front_matter_plugin",)
