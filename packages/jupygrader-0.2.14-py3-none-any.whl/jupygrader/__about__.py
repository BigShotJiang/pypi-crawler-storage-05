# SPDX-FileCopyrightText: 2025-present Ye Joo Park <subwaymatch@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.2.14"
