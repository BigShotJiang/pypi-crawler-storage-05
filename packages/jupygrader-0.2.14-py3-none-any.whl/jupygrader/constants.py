GRADED_RESULT_JSON_FILENAME = "_jupygrader-result.json"
GRADED_RESULT_ELEMENT_ID = "_graded_result"
