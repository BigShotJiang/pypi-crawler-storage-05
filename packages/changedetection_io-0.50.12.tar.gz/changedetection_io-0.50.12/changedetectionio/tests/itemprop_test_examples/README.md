# A list of real world examples!

Always the price should be 666.66 for our tests

see test_restock_itemprop.py::test_special_prop_examples

