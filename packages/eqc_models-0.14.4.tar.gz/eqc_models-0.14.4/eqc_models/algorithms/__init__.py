# (C) Quantum Computing Inc., 2024.
from .penaltymultiplier import PenaltyMultiplierAlgorithm

__all__ = ["PenaltyMultiplierAlgorithm"]