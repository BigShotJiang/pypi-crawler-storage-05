__version__ = "0.1.0"
homepage = "https://github.com/kuhnemann/phrappy"
