from .base import BASE_URL, ContentPiece, PybitesSearch

PODCAST_ENDPOINT = BASE_URL + "api/podcasts/"
PODCAST_BASE_URL = "https://www.pybitespodcast.com/1501156/"


class PodcastSearch(PybitesSearch):
    def __init__(self) -> None:
        self.title = "Pybites Podcast Episodes"

    def match_content(self, search: str) -> list[ContentPiece]:
        entries = self.get_data(PODCAST_ENDPOINT)
        results = []
        for entry in entries:
            if search.lower() in (entry["title"] + entry["description"]).lower():
                results.append(
                    ContentPiece(
                        title=entry["title"],
                        url=PODCAST_BASE_URL + entry["slug"],
                        channel=self.title,
                    )
                )
        return results


if __name__ == "__main__":
    searcher = PodcastSearch()
    results = searcher.match_content("cms")
    searcher.show_matches(results)
