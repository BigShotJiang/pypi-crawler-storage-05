from .base import BASE_URL, ContentPiece, PybitesSearch

ARTICLE_ENDPOINT = BASE_URL + "api/articles/"


class ArticleSearch(PybitesSearch):
    def __init__(self) -> None:
        self.title = "Pybites Articles"

    def match_content(self, search: str) -> list[ContentPiece]:
        entries = self.get_data(ARTICLE_ENDPOINT)
        results = []
        for entry in entries:
            if search.lower() in (entry["title"] + entry["summary"]).lower():
                results.append(
                    ContentPiece(
                        title=entry["title"], url=entry["link"], channel=self.title
                    )
                )
        return results


if __name__ == "__main__":
    searcher = ArticleSearch()
    results = searcher.match_content("django")
    searcher.show_matches(results)
