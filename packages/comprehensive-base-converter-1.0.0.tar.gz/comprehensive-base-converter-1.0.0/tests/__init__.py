"""
Test package for Base Converter.
"""
