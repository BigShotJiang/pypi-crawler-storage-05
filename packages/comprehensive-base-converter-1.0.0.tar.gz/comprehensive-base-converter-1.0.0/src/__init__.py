"""
Base Converter - A comprehensive cross-platform base conversion utility.
"""

__version__ = "1.0.0"
__author__ = "Base Converter Team"
