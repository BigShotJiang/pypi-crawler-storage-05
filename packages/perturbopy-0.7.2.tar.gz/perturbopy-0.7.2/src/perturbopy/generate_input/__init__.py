from .generate_input import input_generation
