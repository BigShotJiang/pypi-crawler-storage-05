"""
   This module is wrapper to functions that compare yaml or HDF5 files
"""
