"""
   This module sets up the environment and runs Perturbo for the testsuite.
"""
