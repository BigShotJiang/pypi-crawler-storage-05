
class FailedToLoginException(Exception):
  pass

