# LOCAL TESTING
# do this in root of the project and it will solve
# Traceback (most recent call last):
#  File ".../sumologic-cse-python-sdk/./scripts/insights/resolve_insights.py", line 31, in <module>
#    from sumologiccse.sumologiccse import SumoLogicCSE
#ModuleNotFoundError: No module named 'sumologiccse'
 export PYTHONPATH="`pwd`"