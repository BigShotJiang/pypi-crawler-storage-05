===========
 Reference
===========

Interfaces
==========

.. automodule:: zope.intid.interfaces

Implementation
==============

.. automodule:: zope.intid
