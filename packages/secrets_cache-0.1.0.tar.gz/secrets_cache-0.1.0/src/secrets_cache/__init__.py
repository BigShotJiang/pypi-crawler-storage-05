"""Top-level package for Secrets Cache."""

__author__ = """Ritvik Nag"""
__email__ = 'me@ritviknag.com'
