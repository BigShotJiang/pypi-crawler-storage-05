Documentation section

To build the documentation locally

```
sphinx-build docs _build
```
or
```
make html
```