from dotenv import load_dotenv

__version__ = "3.9"
load_dotenv()
