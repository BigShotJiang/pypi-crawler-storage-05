class SDKConfig:
    PRINT_REQUEST_DATA = False
    PRINT_RAW_RESPONSE = False
    ENABLE_JSON_CONVERSION = False
