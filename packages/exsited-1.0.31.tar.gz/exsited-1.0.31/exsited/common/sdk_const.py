class SDKConst:
    SUCCESS = "success"
    ERROR = "errors"
