class SDKConsole:

    @staticmethod
    def log(message, is_print=True):
        if is_print:
            print(message)
