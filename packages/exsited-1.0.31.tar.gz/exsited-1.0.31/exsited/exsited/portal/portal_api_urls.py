class PortalApiUrl:
    PORTAL_LOGIN = "/api/v3/portal/login"
    PORTAL_CHANGE_PASSWORD = "/api/v3/portal/change-password"
