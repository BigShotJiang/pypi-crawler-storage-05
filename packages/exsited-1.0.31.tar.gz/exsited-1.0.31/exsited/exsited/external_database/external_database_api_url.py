class ExternalDatabaseApiUrl:
    EXTERNAL_DATABASE = "/api/v3/external-database"
    EXTERNAL_DATABASE_DETAILS = "/api/v3/external-database/{db_name}"
    EXTERNAL_DATABASE_TABLE_DETAILS = "/api/v3/external-database/{db_name}/table/{table_name}"