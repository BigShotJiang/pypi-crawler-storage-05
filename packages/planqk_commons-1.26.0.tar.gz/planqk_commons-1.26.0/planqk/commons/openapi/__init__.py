import os


def resolve_package_path() -> str:
    return os.path.dirname(__file__)
