from devapp.app import run_app


def main():
    print('da wrapper - upcomming')


run = lambda: run_app(main)


if __name__ == '__main__':
    run()
