table = {'foo': 'bar'}  # required otherwise no replacements
