"""
Rule implementations for the standard difference analysis policy.
"""
