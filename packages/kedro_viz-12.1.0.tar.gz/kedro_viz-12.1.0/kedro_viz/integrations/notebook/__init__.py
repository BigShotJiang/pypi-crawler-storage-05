"""`kedro_viz.integrations.notebook` provides interface to integrate Kedro-Viz with Notebook."""

# alias to ease Notebook visualization import
from .visualizer import NotebookVisualizer
