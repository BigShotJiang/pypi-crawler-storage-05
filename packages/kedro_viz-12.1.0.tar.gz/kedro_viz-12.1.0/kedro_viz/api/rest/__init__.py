"""`kedro_viz.api.rest` defines the REST API."""
