"""`kedro_viz.launchers.cli` launches the viz server as a CLI app."""
