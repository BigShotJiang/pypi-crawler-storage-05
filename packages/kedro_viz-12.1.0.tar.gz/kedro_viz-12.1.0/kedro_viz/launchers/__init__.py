"""`kedro_viz.launchers` provides scripts to launch the viz server depending on entrypoints."""
