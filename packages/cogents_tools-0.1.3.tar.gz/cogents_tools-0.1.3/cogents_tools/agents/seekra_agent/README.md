# Seekra Agent

A simple deep research agent.