from . import qt_patch  # noqa: F401

from .init import main

main()
