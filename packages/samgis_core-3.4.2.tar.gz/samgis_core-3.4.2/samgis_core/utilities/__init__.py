"""various helpers functions"""
