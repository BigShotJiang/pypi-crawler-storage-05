========
Analysis
========

Here you can find some analysis reports of (old) bugs.
Those are kept around mostly for historical reasons.

.. toctree::
    :titlesonly:
    :maxdepth: 1

    classes_without_constructor
    object_ref_counting_for_vfuncs_and_closures
    property_object_transfer
    signal_transfer