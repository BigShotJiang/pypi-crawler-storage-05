.. |python-logo| raw:: html

    <i class="fab fa-python"></i>

.. |ubuntu-logo| raw:: html

    <i class="fab fa-ubuntu"></i>

.. |debian-logo| raw:: html

    <i class="fab fa-debian"></i>

.. |fedora-logo| raw:: html

    <i class="fab fa-fedora"></i>

.. |opensuse-logo| raw:: html

    <i class="fab fa-suse"></i>

.. |windows-logo| raw:: html

    <i class="fab fa-windows"></i>

.. |source-logo| raw:: html

    <i class="fas fa-file"></i>

.. |arch-logo| raw:: html

    <img src="_static/arch.svg" alt="Arch Linux" class="only-light" style="width: 1em; height: 1em; vertical-align: middle;">
    <img src="_static/arch-dark.svg" alt="Arch Linux" class="only-dark" style="width: 1em; height: 1em; vertical-align: middle;">

.. |macosx-logo| raw:: html

    <i class="fab fa-apple"></i>

.. |github-logo| raw:: html

    <i class="fab fa-github"></i>

.. |git-logo| raw:: html

    <i class="fab fa-git-alt"></i>

.. |bug-logo| raw:: html

    <i class="fas fa-bug"></i>

.. |linux-logo| raw:: html

    <i class="fab fa-linux"></i>
