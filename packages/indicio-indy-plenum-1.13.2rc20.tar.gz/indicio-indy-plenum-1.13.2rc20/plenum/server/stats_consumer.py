from typing import Dict, Any


class StatsConsumer:

    def __init__(self):
        pass

    def sendStats(self, event: str, stats: Dict[str, Any]):
        pass
