# snakemake-executor-plugin-kubernetes

A snakemake executor plugin for submission of jobs to Kubernetes.