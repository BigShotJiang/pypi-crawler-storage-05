# This  is automatically updated at build time, do not edit manually.
# Double qoites are checked here

__version__ = "0.2.1" 
