from espnet2.gan_svs.post_frontend.fused import FusedPostFrontends  # noqa
from espnet2.gan_svs.post_frontend.s3prl import S3prlPostFrontend  # noqa
