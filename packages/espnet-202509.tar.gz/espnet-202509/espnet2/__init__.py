"""Initialize espnet2 package."""

from espnet import __version__  # NOQA
