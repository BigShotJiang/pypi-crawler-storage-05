import os

from dotenv import load_dotenv

load_dotenv(os.path.join(os.getenv("HOME"), ".env"))