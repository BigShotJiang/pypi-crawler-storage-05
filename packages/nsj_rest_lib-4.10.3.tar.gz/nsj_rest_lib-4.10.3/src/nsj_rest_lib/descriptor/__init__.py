from .dto_aggregator import DTOAggregator

__all__ = [
    'DTOAggregator'
]
