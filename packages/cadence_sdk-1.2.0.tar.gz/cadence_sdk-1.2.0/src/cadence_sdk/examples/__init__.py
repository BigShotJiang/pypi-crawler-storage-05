"""Example plugins for Cadence SDK."""

from . import template_plugin

__all__ = ["template_plugin"]
