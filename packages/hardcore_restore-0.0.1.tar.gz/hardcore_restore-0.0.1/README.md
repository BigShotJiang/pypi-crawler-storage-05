> Tested only on linux, minecraft 1.21.8, but should work on all platforms with java edition.

1. make sure you have python installed
2. download using pip install `pip install hardcore-reset`
3. run `hardcore-restore WORLDNAME`

you can specify coordinates to move your character if you died in a wrong place.

write me if you tested on other platforms, thanks.

# Backup
by default a backup of the world is zipped in the saves directory.

# Contribution
if you want to contribute, check out [webNBT](https://irath96.github.io/webNBT/)
