from .schema import CesnetServicePathQuery

schema = [CesnetServicePathQuery]
