from .losses import LossAdapter
