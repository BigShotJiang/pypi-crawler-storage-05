from .linear import linear_scalarization
