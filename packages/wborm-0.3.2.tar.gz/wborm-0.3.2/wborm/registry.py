_model_registry = {}
_model_cache = {}
_query_result_cache = {}  # Global TTL cache
_connection = None  # Conexão global compartilhada
