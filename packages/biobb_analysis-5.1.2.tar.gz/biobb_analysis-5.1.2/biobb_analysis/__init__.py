from . import ambertools, gromacs

name = "biobb_analysis"
__all__ = ["ambertools", "gromacs"]
__version__ = "5.1.2"
