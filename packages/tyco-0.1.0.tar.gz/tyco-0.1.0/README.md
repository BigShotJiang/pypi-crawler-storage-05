# Tyco
A Python library for parsing Tyco configuration files.

## Installation
```bash
pip install tyco

