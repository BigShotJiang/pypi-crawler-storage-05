"""LaMAReg: Label Augmented Modality Agnostic Registration."""

__version__ = "0.1.0"

from lamareg.scripts.lamar import lamareg
