from .handle_events_decorator import handle_events

__all__ = ('handle_events',)
