zope.interface documentation
============================

.. toctree::
   :maxdepth: 2

   README
   adapter
   human
   verify
   foodforthought
   api/index
   hacking
   changes

По-русски
=========

.. toctree::
   :maxdepth: 2

   README.ru
   adapter.ru
   human.ru



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
