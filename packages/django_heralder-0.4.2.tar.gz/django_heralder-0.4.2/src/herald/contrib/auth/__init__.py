default_app_config = "herald.contrib.auth.apps.HeraldAuthConfig"
