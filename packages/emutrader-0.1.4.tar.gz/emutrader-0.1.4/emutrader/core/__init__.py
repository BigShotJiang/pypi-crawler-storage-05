"""
Core modules for EmuTrader.

This package contains the fundamental classes and interfaces
for the trading simulation system.
"""