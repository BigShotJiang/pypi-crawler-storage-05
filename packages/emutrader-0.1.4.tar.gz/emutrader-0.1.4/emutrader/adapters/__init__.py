"""
Platform adapters for integration with different trading platforms.

This package contains adapters for JoinQuant, QMT, and other platforms.
"""