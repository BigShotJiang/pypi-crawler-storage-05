

:orphan:

.. raw:: html

   <div class="prename">{{ module }}.</div>
   <div class="empty"></div>

.. currentmodule:: {{ module }}

.. automodule:: {{module}}.{{ objname }}
