﻿

.. raw:: html

   <div class="prename">quant_met.bdg.</div>
   <div class="empty"></div>

diagonalize_bdg
=============================

.. currentmodule:: quant_met.bdg

.. autofunction:: diagonalize_bdg
