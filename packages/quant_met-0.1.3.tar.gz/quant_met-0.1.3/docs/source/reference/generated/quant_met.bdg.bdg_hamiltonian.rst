﻿

.. raw:: html

   <div class="prename">quant_met.bdg.</div>
   <div class="empty"></div>

bdg_hamiltonian
=============================

.. currentmodule:: quant_met.bdg

.. autofunction:: bdg_hamiltonian
