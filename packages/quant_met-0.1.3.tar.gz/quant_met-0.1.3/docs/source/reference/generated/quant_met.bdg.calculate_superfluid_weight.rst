﻿

.. raw:: html

   <div class="prename">quant_met.bdg.</div>
   <div class="empty"></div>

calculate_superfluid_weight
=========================================

.. currentmodule:: quant_met.bdg

.. autofunction:: calculate_superfluid_weight
