﻿

.. raw:: html

   <div class="prename">quant_met.quantum_geometry.</div>
   <div class="empty"></div>

calculate_qgt
========================================

.. currentmodule:: quant_met.quantum_geometry

.. autofunction:: calculate_qgt
