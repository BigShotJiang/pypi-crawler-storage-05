# -*- coding: utf-8 -*-
"""
:Authors: cykooz
:Date: 25.06.2019
"""


class HeifError(Exception):
    pass
