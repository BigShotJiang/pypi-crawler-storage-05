class AutoModel:
    def __init__(self,):
        pass

    def ask(self, prompt: str) -> str:
        pass
