"""Core functionality tests package."""

