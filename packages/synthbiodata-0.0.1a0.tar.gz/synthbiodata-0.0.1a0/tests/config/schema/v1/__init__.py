"""Version 1 configuration schema tests package."""

