"""Configuration schema tests package."""

