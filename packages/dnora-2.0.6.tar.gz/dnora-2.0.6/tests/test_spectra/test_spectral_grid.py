# from dnora.grid import Grid
# from dnora import modelrun
# import numpy as np
# from dnora.dnora_object_type import DnoraObjectType


# def test_set_spectral_grid():
#     grid = grd.Grid(lon=5, lat=60)
#     model = mdl.ModelRun(
#         grid, start_time="2020-01-01 00:00", end_time="2020-01-02 00:00"
#     )

#     model.set_spectral_grid()
#     model.spectral_grid()
#     model[DnoraObjectType.SpectralGrid]
