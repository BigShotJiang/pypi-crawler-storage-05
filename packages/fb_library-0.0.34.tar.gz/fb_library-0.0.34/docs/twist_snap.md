# twist_snap
![an illustration of a twist-snap connector and socket aligned](twist_snap.png)

## Introduction

the twist_snap module provides two functions for generating twist-snap connectors; which can be useful for creating connections that can be repeatedly opened. For example, these are used for connectors for PTFE tubes in the Fender-Bender project.
