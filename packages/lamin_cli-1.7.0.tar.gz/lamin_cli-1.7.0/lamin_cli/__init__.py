"""Lamin CLI."""

__version__ = "1.7.0"
