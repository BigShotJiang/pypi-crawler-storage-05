"""
MCP server implementation for constrained optimization problems.
"""

from .main import main

__all__ = ["main"]
