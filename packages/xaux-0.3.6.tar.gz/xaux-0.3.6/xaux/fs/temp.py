# copyright ############################### #
# This file is part of the Xaux Package.    #
# Copyright (c) CERN, 2024.                 #
# ######################################### #

import tempfile

_tempdir = tempfile.TemporaryDirectory()
