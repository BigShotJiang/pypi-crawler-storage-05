# Project Authors

The following people have made contributions to the project (in alphabetical
order by last name) and are considered "The pyCATHY Developers":

* [Benjamin Mary](https://github.com/BenjMy) -University of Padua, Italy (ORCID: 0000-0002-4065-8910)
* [Luca Peruzzo](https://github.com/Peruz) -University of Padua, Italy (ORCID: 0000-0002-4065-8910)

