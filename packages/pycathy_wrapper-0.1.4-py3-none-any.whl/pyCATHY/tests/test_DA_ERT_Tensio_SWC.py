"""
Test Data Assimlitation

Includes mutliples observations including ERT, tensiometers and SWC with different sampling times and obsolute datetime.
Update ?? parameters 
"""
