"""
Test Data Assimlitation

Includes time lapse ERT synthetic data to assimilate. The data are prodcued using pygimli. 
The simulation mimick RWU within a rhizotron.

Update Feddes parameters for different initial model inputs:
- root heteregeneity
- soil conductivity

Update parameters: 
- Archie
-  
"""
