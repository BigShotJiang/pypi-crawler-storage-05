# -*- coding: utf-8 -*-
"""Reader for CATHY input/outputs files CATHYv Manoli"""


def plant():
    # plant parameters only exist for CATHYv Manoli

    pass
