"""Main entry point for the Scout CLI."""

from .cli import main

if __name__ == "__main__":
    main()
