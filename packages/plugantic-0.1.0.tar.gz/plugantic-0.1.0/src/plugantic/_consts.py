# Single source of truth for information needed at runtime and compile-time (i.e. version)
version = "0.1.0"
