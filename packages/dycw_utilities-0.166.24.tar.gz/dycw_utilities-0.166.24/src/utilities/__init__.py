from __future__ import annotations

__version__ = "0.166.24"
