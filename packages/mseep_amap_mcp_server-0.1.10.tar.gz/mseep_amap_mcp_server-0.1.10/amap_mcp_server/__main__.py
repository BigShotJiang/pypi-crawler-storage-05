from amap_mcp_server import main

main()