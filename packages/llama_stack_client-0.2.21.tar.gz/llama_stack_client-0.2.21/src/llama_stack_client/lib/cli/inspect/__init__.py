from .inspect import inspect

__all__ = ["inspect"]
