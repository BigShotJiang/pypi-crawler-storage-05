from __future__ import annotations

from ._socket import SystemResolver

__all__ = ("SystemResolver",)
