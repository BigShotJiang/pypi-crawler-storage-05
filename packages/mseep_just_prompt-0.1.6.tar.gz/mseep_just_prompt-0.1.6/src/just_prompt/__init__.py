# just-prompt - A lightweight wrapper MCP server for various LLM providers

__version__ = "0.1.0"
