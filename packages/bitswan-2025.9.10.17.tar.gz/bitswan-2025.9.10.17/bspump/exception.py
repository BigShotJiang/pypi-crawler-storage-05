class ProcessingError(RuntimeError):
    """
    Generic exception that indicate an error in a pipeline processing.
    """

    pass
