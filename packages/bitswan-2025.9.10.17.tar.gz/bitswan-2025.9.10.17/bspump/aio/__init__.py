from .sink import AsyncSink


__all__ = [
    "AsyncSink",
]
