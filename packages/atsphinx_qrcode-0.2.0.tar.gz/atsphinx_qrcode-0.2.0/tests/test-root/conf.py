# noqa: D100

extensions = [
    "atsphinx.qrcode",
]
