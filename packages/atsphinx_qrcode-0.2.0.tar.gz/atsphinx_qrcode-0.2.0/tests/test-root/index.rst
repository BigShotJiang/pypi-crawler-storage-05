Test doc for atsphinx-qrcode
============================
