Release atsphinx-qrcode v0.2.0

- Changelog is https://github.com/atsphinx/qrcode/blob/v0.2.0/CHANGES.rst
