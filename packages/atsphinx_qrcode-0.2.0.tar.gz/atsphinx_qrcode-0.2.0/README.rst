===============
atsphinx-qrcode
===============

Render QR code image on Sphinx document.

Getting started
===============

.. code:: console

   pip install atsphinx-qrcode

.. code:: python

   extensions = [
       ...,  # Your extensions
       "atsphinx.qrcode",
   ]
