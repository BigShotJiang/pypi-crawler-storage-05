===============
atsphinx-qrcode
===============

.. container:: flex

    .. container:: size-1

        .. code-block:: rst

            .. qrcode::
                :align: center

                https://example.com

    .. container:: size-1

        .. qrcode::
            :align: center

            https://example.com

Overview
========

Simple Sphinx extension to render SVG of QR code.

.. toctree::
   :maxdepth: 1

   guide
   changes
