.. _reference.entry.created_parsed:

:py:attr:`entries[i].created_parsed`
====================================

The date this entry was first created (drafted), as a standard
:program:`Python` 9-tuple.


.. rubric:: Comes from

* /atom03:feed/atom03:entry/atom03:created
* /rdf:RDF/rdf:item/dcterms:created
* /rss/channel/item/dcterms:created


.. seealso::

    * :ref:`reference.entry.created`
