# Frequenz Weather API Client Release Notes

## Summary

This release relaxes the API common dependency so it can work up to v1.0.0, as all v0.x versions should be compatible from v0.8.0 on.
