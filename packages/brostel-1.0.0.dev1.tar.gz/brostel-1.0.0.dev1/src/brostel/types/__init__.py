"""Data types for Brostel."""

from .message import BuiltMessage

__all__ = ["BuiltMessage"]
