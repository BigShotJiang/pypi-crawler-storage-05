"""Brostel configuration."""

from .settings import BrostelConfig

__all__ = ["BrostelConfig"]
