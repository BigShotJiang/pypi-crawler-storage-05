# Arithmatic operator
This is a simple package.you can use to write your content



from arithematic_mr.sagar import arithematic.py

print(utilities.addition(1,2,3,4))

print(utilities.subtraction(1,2,3,4,5))


print(utilities.multiplication(1,5,6,,9))