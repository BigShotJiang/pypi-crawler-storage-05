"""Server constants."""

ROOM_KEY = 'room:{sid}'
