from openhands.agenthub.codeact_agent.codeact_agent import CodeActAgent
from openhands.controller.agent import Agent

Agent.register('CodeActAgent', CodeActAgent)
