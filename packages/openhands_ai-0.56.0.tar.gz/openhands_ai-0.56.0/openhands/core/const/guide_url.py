TROUBLESHOOTING_URL = 'https://docs.all-hands.dev/usage/troubleshooting'
