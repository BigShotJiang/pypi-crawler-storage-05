"""Python package for the tap-clinicaltrials CLI."""

from __future__ import annotations
