# binlookup

A simple Python wrapper for [binlist.net](https://binlist.net) API.

## Installation
```bash
pip install binlookup

