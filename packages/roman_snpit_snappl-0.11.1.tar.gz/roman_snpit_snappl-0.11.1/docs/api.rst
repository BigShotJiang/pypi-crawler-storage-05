.. _api:

==========
snappl API
==========

.. contents::

.. automodapi:: snappl.image

.. automodapi:: snappl.wcs

.. automodapi:: snappl.psf

.. automodapi:: snappl.sed
