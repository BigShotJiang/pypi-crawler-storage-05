from .run import get_header, get_cloud_run_token
from .gcloud import get_local_gcloud_token