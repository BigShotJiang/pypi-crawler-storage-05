from .classifierPratikFunctions import ZeroShotClassifier

__all__ = ["ZeroShotClassifier"]
