__version__ = "0.5.0"
VERSION = __version__
"Current version"
