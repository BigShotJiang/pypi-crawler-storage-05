from llama_index.readers.sec_filings.base import SECFilingsLoader

__all__ = ["SECFilingsLoader"]
