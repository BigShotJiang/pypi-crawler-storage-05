_instruments = ("dspy >= 2.6.0",)
_supports_metrics = False
