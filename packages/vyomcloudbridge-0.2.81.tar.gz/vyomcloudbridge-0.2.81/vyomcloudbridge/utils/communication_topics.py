[
    {
        "id": 382,
        "name": "hello",
        "data_type": "vyom_msg.msg.Hello",
        "topic": "/hello_topic"
    },
    {
        "id": 383,
        "name": "auth",
        "data_type": "vyom_msg.msg.Auth",
        "topic": "auth"
    },
    {
        "id": 384,
        "name": "mission_status_topic",
        "data_type": "vyom_mission_msgs.msg.MissionStatus",
        "topic": "mission_status_topic"
    },
    {
        "id": 385,
        "name": "bt_msg",
        "data_type": "vyom_mission_msgs.msg.MissionStatus",
        "topic": "mission_status_topic"
    },
    {
        "id": 386,
        "name": "update_topic_list",
        "data_type": "std_msgs.msg.String",
        "topic": "update_topic_list"
    },
    {
        "id": 387,
        "name": "systemcheck",
        "data_type": "vyom_msg.msg.Systemcheck",
        "topic": "systemcheck"
    },
    {
        "id": 388,
        "name": "e2e_diagnosis",
        "data_type": "std_msgs.msg.String",
        "topic": "e2e_diagnosis"
    }
]
