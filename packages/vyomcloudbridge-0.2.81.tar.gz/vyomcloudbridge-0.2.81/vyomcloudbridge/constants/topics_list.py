# import vyom_mission_msgs.msg
# import vyom_msg.msg 
MSG_PKGS = ["vyom_mission_msgs", "vyom_msg"]

# HELLO = vyom_msg.msg.Hello, "hello"
# DVID = vyom_msg.msg.Dvid, "dvid"
# AUTH = vyom_msg.msg.Auth, "auth"
# ACCESSINFO = vyom_msg.msg.Accessinfo, "accessinfo"
# ACCESS = vyom_msg.msg.Access, "access"
# ACK = vyom_msg.msg.Ack, "ack"
# MISSION_TOPIC = vyom_mission_msgs.msg.MissionStatus, "mission_status_topic"

