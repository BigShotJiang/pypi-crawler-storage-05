"""
Chess.com MCP Server
--------------------
A Model Context Protocol server implementation that provides tools and resources
for interacting with the Chess.com Published Data API.
"""

__version__ = "0.1.0"
