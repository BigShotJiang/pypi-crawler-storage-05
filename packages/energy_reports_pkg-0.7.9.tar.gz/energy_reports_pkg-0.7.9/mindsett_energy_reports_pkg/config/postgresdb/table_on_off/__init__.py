
name = 'on_off_detection_airflow_view'