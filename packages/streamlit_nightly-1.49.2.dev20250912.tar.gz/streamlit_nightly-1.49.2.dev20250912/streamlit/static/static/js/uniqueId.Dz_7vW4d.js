import{a2 as o,a3 as d}from"./index.Cvmw4olL.js";var r,u;function q(){if(u)return r;u=1;var e=o(),i=0;function n(t){var a=++i;return e(t)+a}return r=n,r}var s=q();const I=d(s);export{I as u};
