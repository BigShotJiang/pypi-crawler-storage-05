class t{setStatus(s){return new t(this.name,this.size,this.id,s)}constructor(s,i,e,h){this.name=s,this.size=i,this.id=e,this.status=h}}export{t as U};
