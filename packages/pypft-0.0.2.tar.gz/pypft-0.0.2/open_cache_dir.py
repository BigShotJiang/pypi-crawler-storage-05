from src.pypft.bessel_mat_handler import open_cache_folder

if __name__ == "__main__":
    open_cache_folder()