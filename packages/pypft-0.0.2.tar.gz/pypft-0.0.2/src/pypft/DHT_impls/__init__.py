from .naive import *
from .parallel import *
from .arrayprogramming import *