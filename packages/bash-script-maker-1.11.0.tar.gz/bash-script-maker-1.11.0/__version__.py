#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Version information for Bash-Script-Maker
"""

__version__ = "1.11.0"
__version_info__ = (1, 11, 0)
