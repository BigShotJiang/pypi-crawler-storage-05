=====================
The ``rstgen`` module
=====================

Warning: This repository has moved to https://gitlab.com/lino-framework/rstgen

Some utilities for generating chunks of `reStructuredText
<https://docutils.sourceforge.io/rst.html>`__.

It also contains a series of Sphinx extensions (in the `rstgen.sphinxconf`
package).

- Documentation: https://atelier.lino-framework.org/rstgen

- Source code: https://gitlab.com/lino-framework/rstgen

- Changelog: https://atelier.lino-framework.org/changes
