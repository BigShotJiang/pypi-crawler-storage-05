# This just adds a dummy et language to suppress warning "rST localisation for
# language 'et' not found".
