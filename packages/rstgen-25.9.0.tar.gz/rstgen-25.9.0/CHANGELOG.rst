=========
Changelog
=========

2021-05-01
==========

The ``srcref_url`` setting is no longer used. :func:`rstgen.srcref`  now looks
whether ``SETUP_INFO['url']`` exists and assumes that it contains the URL of the
source code repository.

Release to PyPI
