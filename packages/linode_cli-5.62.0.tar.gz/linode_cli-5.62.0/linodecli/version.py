"""
The version of the Linode CLI.
"""

__version__ = "v5.62.0"
