"""
Collection of classes for handling the parsed OpenAPI Spec for the CLI
"""

from .operation import OpenAPIOperation
