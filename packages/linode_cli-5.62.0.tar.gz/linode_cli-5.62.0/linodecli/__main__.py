"""
Launches the CLI
"""

from linodecli import main

main()
