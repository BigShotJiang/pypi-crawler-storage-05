"""Test suite for generated vardef_client models."""
