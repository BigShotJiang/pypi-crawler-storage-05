# Usage

Start the gui manager
``` bash
python -m gui_process_manager
```