"""Provides the navigation panel widget."""

##############################################################################
# Local imports.
from .widget import Navigation

##############################################################################
# Exports.
__all__ = ["Navigation"]


### __init__.py ends here
