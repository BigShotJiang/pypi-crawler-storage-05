version = '1.4.0'
repo = 'https://github.com/makodevai/gpuq'
commit = '89a9f143e89cb7e478d0ed349865cb5a17d1b832 (+2 untracked)'
has_repo = True
