# LlamaIndex Utils Integration: Baidu Qianfan

Client-side underlying components of Baidu Intelligent Cloud's Qianfan LLM Platform. Can be used to support access to model services of types such as chat, completion, and embedding.
