::: xwr.capture.defines
