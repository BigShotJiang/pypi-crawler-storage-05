::: xwr
    options:
        members:
        - XWRSystem
        - DCAConfig
        - XWRConfig
