# This file is a part of the `nequip` package. Please see LICENSE and README at the root for information on using it.
import pathlib

CONFTEST_PATH = pathlib.Path(__file__).parent / "conftest.py"
