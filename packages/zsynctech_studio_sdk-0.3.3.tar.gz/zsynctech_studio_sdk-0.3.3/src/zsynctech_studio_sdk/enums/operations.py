from enum import StrEnum


class Operations(StrEnum):
    CREATE = 'create'
    UPDATE = 'update'
