import logging

logger = logging.getLogger("ibauth")
