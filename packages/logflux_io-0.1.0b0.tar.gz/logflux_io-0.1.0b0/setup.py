"""
Setup script for LogFlux Python SDK.
"""

from setuptools import setup

# pyproject.toml handles most configuration
# This setup.py is minimal and primarily for backward compatibility
setup()