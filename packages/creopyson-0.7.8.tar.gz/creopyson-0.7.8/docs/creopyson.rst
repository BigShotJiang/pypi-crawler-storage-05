creopyson package
=================

Submodules
----------

creopyson.bom module
--------------------

.. automodule:: creopyson.bom
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.connection module
---------------------------

.. automodule:: creopyson.connection
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.creo module
---------------------

.. automodule:: creopyson.creo
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.dimension module
--------------------------

.. automodule:: creopyson.dimension
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.drawing module
------------------------

.. automodule:: creopyson.drawing
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.exceptions module
---------------------------

.. automodule:: creopyson.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.familytable module
----------------------------

.. automodule:: creopyson.familytable
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.feature module
------------------------

.. automodule:: creopyson.feature
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.file module
---------------------

.. automodule:: creopyson.file
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.geometry module
-------------------------

.. automodule:: creopyson.geometry
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.interface module
--------------------------

.. automodule:: creopyson.interface
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.layer module
----------------------

.. automodule:: creopyson.layer
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.note module
---------------------

.. automodule:: creopyson.note
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.objects module
------------------------

.. automodule:: creopyson.objects
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.parameter module
--------------------------

.. automodule:: creopyson.parameter
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.server module
-----------------------

.. automodule:: creopyson.server
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.view module
---------------------

.. automodule:: creopyson.view
   :members:
   :undoc-members:
   :show-inheritance:

creopyson.windchill module
--------------------------

.. automodule:: creopyson.windchill
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: creopyson
   :members:
   :undoc-members:
   :show-inheritance:
