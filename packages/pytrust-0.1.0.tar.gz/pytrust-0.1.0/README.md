# pytrust

A CLI tool to check if a Python package interacts with the file system, reads environment variables, makes web requests, or uses exec. Provide a package name and a permissions YAML file.
