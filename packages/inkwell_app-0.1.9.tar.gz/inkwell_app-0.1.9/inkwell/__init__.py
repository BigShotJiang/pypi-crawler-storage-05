"""
Inkwell - A command line tool that launches a local React website with FastAPI backend
"""

__version__ = "0.1.9"
__author__ = "Inkwell Team"