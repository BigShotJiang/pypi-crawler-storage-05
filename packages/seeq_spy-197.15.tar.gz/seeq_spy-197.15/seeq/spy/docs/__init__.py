from seeq.spy.docs._copy import copy

__all__ = ['copy']
