from dependency_injector import containers


class BaseFlavorContainer(containers.DynamicContainer):
    """Container for base flavor dependencies."""

    pass
