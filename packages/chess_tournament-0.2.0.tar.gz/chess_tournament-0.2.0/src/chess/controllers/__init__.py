"""Controllers for the chess application.

This package contains the controller classes that handle the application's logic,
such as managing tournaments and players.
"""
