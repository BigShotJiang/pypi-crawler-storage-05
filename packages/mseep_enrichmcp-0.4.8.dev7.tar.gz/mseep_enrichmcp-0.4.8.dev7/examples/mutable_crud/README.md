# Mutable CRUD Example

A minimal API demonstrating the new mutability features and CRUD decorators.

```bash
cd mutable_crud
python app.py
```

Use the generated tools to create, update and delete customers.
