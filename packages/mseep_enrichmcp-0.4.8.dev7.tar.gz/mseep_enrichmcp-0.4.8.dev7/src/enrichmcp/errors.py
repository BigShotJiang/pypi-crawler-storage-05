"""
Error classes for enrichmcp.

Provides standard error classes for common scenarios.
"""
