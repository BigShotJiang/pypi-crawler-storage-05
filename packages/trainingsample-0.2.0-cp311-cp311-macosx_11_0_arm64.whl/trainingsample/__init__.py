from .trainingsample import *

__doc__ = trainingsample.__doc__
if hasattr(trainingsample, "__all__"):
    __all__ = trainingsample.__all__