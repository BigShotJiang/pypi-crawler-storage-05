Part 3.1
