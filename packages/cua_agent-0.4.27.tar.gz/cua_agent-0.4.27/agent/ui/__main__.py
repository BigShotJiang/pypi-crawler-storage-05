from .gradio import launch_ui

if __name__ == "__main__":
    launch_ui()