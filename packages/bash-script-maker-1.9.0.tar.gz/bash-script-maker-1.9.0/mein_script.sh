#!/bin/bash
# Erstellt mit Bash-Script-Maker
# 2025-09-01 06:29:46
echo "Hallo Welt"