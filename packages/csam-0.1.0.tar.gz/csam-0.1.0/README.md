
# Cliente de sistema de almacenamiento basado en memoria

Es un cliente para el sistema de almacenamiento en memoria "ESS v1". El cliente es capaz de cargar en memoria datos locales, enviar datos al sistema de almacenamiento, cargar los datos en la memoria local y enviarlos al sistema de almacenamiento, y descargar datos del sistema de almacenamiento. 


## Authors

- [@juliocsp03](https://www.github.com/juliocsp03)


## License

[MIT](https://choosealicense.com/licenses/mit/)

