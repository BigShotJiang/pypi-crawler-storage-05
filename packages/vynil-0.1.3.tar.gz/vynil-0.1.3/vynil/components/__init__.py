from .component import Component
from .inline import inline_style, inline_styles

__all__ = [
    "Component",
    "inline_style",
    "inline_styles",
]