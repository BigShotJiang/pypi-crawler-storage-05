from .web import Web

__all__ = ["Web"]
