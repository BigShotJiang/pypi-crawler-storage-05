from maputil.map2 import map2

__all__ = ["map2"]
