import pandas as pd
mitacPandas= pd.Series([1, 2, 3, 4])