To use this module, you need to be an account adviser and go to:

Accounting -\> Adviser -\> Actions -\> Account Period Closing \* Select
the template to close \* Go to Action -\> Close Period, choose the dates
and click on the "Close" button.

For accounts that can close on different side (eg. 609, 709, 711xxx)
accounts, go to the account and select the Bypass Closing Side Check
option.
