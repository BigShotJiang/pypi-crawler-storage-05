from judgeval.data.judgment_types import ToolJudgmentType


class Tool(ToolJudgmentType):
    pass
