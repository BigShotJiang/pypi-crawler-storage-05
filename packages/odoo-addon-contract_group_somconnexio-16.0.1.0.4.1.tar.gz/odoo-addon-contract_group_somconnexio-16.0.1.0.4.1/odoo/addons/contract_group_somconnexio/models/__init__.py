from . import (
    contract,
    contract_group,
    res_partner,
    change_partner_emails,
)