_instruments = ("mcp >= 1.6.0",)
