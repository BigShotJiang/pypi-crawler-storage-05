from .pyglobcmp import *

__doc__ = pyglobcmp.__doc__
if hasattr(pyglobcmp, "__all__"):
    __all__ = pyglobcmp.__all__