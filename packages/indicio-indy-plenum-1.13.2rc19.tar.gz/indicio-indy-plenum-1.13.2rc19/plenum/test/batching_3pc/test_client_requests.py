import pytest


@pytest.mark.skip(reason='INDY-96. Not implemented')
def testClientRequestingStateProof():
    raise NotImplementedError


@pytest.mark.skip(reason='INDY-96. Not implemented')
def testClientRequestingStateVariableValue():
    raise NotImplementedError
