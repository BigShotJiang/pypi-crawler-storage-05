# test TXNs
BUY = "buy"
GET_BUY = "get_buy"
RANDOM_BUY = "randombuy"