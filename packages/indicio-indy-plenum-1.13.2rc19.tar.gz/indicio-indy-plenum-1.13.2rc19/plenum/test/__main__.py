from plenum import test

test.run()
