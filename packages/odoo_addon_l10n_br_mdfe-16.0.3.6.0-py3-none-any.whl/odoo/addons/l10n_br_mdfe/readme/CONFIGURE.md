To configure this module you need to set a digital certificate on the
company, and also set the company edoc processor.
