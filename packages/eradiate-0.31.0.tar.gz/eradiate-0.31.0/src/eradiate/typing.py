import os
from typing import Union

PathLike = Union[str, bytes, os.PathLike]
