"""
Task Manager - A tmux-based task scheduling and monitoring tool
"""

__version__ = "1.0.3"
__author__ = "zheng"
__email__ = "zheng.zheng.luck@gmail.com"
