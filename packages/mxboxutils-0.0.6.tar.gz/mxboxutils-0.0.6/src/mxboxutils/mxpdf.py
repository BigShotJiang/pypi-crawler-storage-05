def merge(pdf_dir: str, store_path: str) -> bool:
    return False
