Implementation of the product catalog for stock pickings.
