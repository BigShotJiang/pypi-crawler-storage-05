To access the catalog from a stock picking.

1. Create a new draft picking.
2. Click on the product catalog button.
3. Click it and start adding products to the picking.
