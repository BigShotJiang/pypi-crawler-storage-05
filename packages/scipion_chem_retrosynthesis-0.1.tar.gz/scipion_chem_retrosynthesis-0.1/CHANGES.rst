**v0.1: First version**

- Created repository
- Added Aizynthfinder package