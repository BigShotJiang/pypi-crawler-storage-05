"""
Kepler-Downloader-DR25 Test Suite
"""