# HPC Task
 
Python package for easy HPC task management based on paramiko.

## Installation

pip install -U hpc_task

**Requirements**
* paramiko

## Usage

See tests

## TODO
