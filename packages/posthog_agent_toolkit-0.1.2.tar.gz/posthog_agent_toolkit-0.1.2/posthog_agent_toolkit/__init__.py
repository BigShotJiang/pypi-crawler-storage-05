"""PostHog Agent Toolkit for Python."""

__version__ = "0.1.0"
