"""MATLAB MCP Tool - A Model Context Protocol server for MATLAB integration."""

__version__ = "0.1.0"
