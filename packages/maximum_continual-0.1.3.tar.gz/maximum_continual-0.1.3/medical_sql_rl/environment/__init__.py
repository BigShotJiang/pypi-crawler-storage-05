"""RL Environment module for medical SQL training"""
