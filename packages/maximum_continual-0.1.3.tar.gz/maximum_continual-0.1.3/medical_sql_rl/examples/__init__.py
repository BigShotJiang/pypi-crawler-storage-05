"""Examples module for medical SQL RL environment"""
