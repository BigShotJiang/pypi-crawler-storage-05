from pydantic import BaseModel

