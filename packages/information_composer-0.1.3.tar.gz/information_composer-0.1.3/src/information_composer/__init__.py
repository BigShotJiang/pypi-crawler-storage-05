"""
Information Composer
~~~~~~~~~~~~~~~~~~

A toolkit for collecting and composing information from various web resources.
"""

__version__ = "0.1.3"
