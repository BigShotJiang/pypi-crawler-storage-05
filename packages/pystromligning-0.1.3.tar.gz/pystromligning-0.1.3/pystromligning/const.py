"""Consts used in the pyStromligning library."""

API_URL = "https://stromligning.dk/api"
# API_URL = "https://staging.stromligning.dk/api"  # For testing purposes
