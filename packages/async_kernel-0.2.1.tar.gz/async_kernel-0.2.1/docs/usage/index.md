---
title: Usage
description: Usage tips for async kernel.
icon: material/note-text
# subtitle: A sub title
---

# Usage

If you have used ipykernel before, then you know how to use async-kernel. The
major difference is that async kernel is built to run asynchronously.
