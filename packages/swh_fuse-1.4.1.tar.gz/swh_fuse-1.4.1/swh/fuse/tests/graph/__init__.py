WEB_API_URL = "https://should.not.be.called.swhid.org"
