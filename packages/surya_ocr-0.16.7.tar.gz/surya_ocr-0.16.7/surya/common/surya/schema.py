class TaskNames:
    block_without_boxes = "block_without_boxes"
    ocr_with_boxes = "ocr_with_boxes"
    ocr_without_boxes = "ocr_without_boxes"
    layout = "layout"


TASK_NAMES = [
    TaskNames.block_without_boxes,
    TaskNames.ocr_with_boxes,
    TaskNames.ocr_without_boxes,
    TaskNames.layout
]
