def my_fn(x, y):
    _0 = -x
    assert _0 > 0
    _1 = _0 + y
    _2 = _1 + 2
    _3 = _2 + _1
    return _3
