"""
Global configuration for egglog.
"""

from __future__ import annotations

# Whether to display the type of each node in the graph when printing.
SHOW_TYPES = False
