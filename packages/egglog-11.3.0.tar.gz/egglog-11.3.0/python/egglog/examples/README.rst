Examples Gallery
================

This is a gallery of examples, most of which were translated from the original
`egglog rust examples <https://github.com/egraphs-good/egglog/tree/08a6e8fecdb77e6ba72a1b1d9ff4aff33229912c/tests>`_.
