# Blog

```{postlist}
:list-style: circle
:format: "{title} by {author} on {date}"
:excerpts:
:expand: Read more ...
```
