from . import test_product_customerinfo_sale
