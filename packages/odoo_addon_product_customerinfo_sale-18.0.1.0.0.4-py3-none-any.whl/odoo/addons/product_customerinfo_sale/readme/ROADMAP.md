- Putting a minimum qty in a pricelist rule means the system will use
  the option 'list price' instead of any option you chose.
