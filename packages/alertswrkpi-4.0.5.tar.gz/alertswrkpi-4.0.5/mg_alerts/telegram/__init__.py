from mg_alerts.telegram.tg_alerts import *
from mg_alerts.telegram.tg_base import GetUpdates
from mg_alerts.telegram.tg_config import is_configured, configure_app
