LOG_PATH: str = "./log"
CONFIG_DIR: str = "./data/config"
DUMP_DIR: str = "./data/dump"
OUTPUT_DIR: str = "./data/out"
ALL_PATH = [LOG_PATH, CONFIG_DIR, DUMP_DIR, OUTPUT_DIR]
