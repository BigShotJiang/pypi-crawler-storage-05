# SPDX-FileCopyrightText: 2023-present bernard jiang <bernardjiang5@outlook.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.17"
