from rpft.parsers.creation.datarowmodel import DataRowModel


class SimpleRowModel(DataRowModel):
    value1: str = ""
    value2: str = ""
