from collections import defaultdict

excel_to_json_type_map = {"send_message": "send_msg", "go_to": "go_to"}

nodes_map = defaultdict()
