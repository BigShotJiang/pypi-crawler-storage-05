from template_log_parser.log_functions import (
    parse_function as parse_function,
    log_pre_process as log_pre_process,
    process_log as process_log,
)

from template_log_parser.templates.template_functions import (
    compile_templates as compile_templates
)