class ResultError(Exception):
    """
    Raised when an error occurs while loading or dumping a result file.
    """
