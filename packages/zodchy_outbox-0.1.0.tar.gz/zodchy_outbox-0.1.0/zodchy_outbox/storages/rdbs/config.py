class Metadata:
    def __init__(self, schema: str = "zodchy"):
        self.schema = schema
