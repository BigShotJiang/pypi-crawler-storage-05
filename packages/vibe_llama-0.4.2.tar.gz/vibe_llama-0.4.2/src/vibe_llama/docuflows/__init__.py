"""Fast LLM-based workflow generator."""

from .cli import run_cli

__all__ = ["run_cli"]
