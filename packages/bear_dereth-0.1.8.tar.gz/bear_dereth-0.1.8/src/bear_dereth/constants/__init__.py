"""A set of helpful constants used throughout the Bear Dereth and beyond!"""
