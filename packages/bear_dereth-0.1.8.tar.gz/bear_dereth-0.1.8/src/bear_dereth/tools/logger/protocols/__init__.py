"""Protocols for the logger module."""
