=====
Usage
=====

To use pycomex in a project::

    import pycomex
