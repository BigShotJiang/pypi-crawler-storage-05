Basic Example
=============

This is a basic example:

.. literalinclude:: ../../pycomex/examples/basic.py
    :language: python

When executed, the above file produces the following output:

.. command-output:: python ../pycomex/examples/basic.py
