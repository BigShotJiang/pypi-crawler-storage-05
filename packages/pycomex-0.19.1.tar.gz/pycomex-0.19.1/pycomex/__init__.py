"""Top-level package for pycomex."""

__author__ = """Jonas Teufel"""
__email__ = "jonseb1998@gmail.com"
__version__ = "0.9.5"

from pycomex.experiment import Experiment  # noqa
