"""
The new functional interface.
"""