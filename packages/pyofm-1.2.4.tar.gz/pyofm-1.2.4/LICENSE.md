# OpenFOAM Mesh Reader
______________________________________________________________________________

Copyright (c) 2019 University of Michigan\
Additional copyright (c) 2019 Joaquim R. R. A. Martins, Kevin J. Maki, Ping He, and Charles A. Mader.\
All rights reserved.
______________________________________________________________________________

openfoammeshreader is licensed under the GNU General Public License (GPL), version 3 (the "License"); you may not use this software except in compliance with the License. You may obtain a copy of the License at:\
https://www.gnu.org/licenses/gpl-3.0.html
______________________________________________________________________________

University of Michigan's Multidisciplinary Design Optimization Laboratory (MDO Lab)\
College of Engineering, Aerospace Engineering Department\
http://mdolab.engin.umich.edu/
______________________________________________________________________________

