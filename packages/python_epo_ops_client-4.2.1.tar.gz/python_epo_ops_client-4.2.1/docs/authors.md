# Authors

The following people contributed to the software in one way or another,
thank you so much. The list is alphabetically sorted.

## Development Leads

- [George Song](https://github.com/gsong)

## Maintainers

- [Andreas Motl](https://github.com/amotl)

## Contributors

- [Alejandro Marti](https://github.com/MartiONE)
- [Alexander Meinhardt Scheurer](https://github.com/BeneCollyridam)
- [Daniel Blasco](https://github.com/dablak)
- [Dan Bolser](https://github.com/CholoTook)
- [fe60](https://github.com/fe60)
- [Felipe Eltermann](https://github.com/eltermann)
- [Geoffrey Cline](https://github.com/geoffcline)
- [Hiro Kobashi](https://github.com/kobaski)
- [Matt Keanny](https://github.com/mattkeanny)
- [Mike Matheson](https://github.com/mmath)
- [Oliver Fuerst](https://github.com/ofipify)
- [Roberto Faga](https://github.com/rfaga)
- [Sebastian Vilstrup](https://github.com/ipr-sv)
- [Sotiris Fragkiskos](https://github.com/sfranky)
