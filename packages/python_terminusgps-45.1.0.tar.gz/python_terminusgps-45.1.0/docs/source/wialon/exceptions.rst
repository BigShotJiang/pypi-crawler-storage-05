Exceptions
==========

.. autoexception:: terminusgps.wialon.session.WialonAPIError
    :members:
