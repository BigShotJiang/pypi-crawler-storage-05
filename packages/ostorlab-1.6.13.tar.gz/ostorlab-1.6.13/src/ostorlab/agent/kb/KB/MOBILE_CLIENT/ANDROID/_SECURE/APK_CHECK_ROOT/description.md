Presence of strings and methods indicating check for Rooted or Jail-broken devices.

The absence of the Jail-broken or Root detection is not a vulnerability, but its presence remediates the impact of
certain vulnerability classes or threats.
