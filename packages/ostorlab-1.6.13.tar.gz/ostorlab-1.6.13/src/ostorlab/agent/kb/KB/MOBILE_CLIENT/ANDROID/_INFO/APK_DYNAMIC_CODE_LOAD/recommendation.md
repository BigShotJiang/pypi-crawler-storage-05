This entry is informative, no recommendations applicable.
