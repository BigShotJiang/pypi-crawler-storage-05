The `android:requestLegacyExternalStorage` attribute grants access to directories and different types of media files stored in external storage.

This attribute works only for Android 10 (API level 29), on Android 11 and later, the system ignores the requestLegacyExternalStorage flag.