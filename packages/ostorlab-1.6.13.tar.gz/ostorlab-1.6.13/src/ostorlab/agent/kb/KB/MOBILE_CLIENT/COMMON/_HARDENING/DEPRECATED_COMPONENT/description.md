The application is using a deprecated component. New vulnerabilities will not be fixed and hackers might succeed in
exploiting this weakness.