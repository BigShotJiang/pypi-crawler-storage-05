"""Simple class-based argument parsing for python scripts."""

__version__ = "0.1.0"