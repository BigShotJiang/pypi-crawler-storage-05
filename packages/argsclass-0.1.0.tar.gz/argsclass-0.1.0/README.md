# argsclass
Simple class-based argument parsing for python scripts
