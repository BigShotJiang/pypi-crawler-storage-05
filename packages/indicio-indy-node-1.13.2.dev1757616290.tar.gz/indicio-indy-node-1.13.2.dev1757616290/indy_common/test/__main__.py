from indy_common import test

test.run()
