from indy_node import test

test.run()
