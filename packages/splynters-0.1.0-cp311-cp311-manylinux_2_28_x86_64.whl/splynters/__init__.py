from .splynters import *

__doc__ = splynters.__doc__
if hasattr(splynters, "__all__"):
    __all__ = splynters.__all__