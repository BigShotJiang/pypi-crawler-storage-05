"""
Treasure Data MCP Server - API client for Treasure Data
"""

__version__ = "0.1.0"
