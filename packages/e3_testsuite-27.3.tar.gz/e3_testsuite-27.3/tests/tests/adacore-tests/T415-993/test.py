import os.path


print("H\\E\\L\\O")
print("foo.exe")
print(">>>", os.path.join(os.getcwd(), "foobar"))
