import os.path


print("foo")
print(os.path.join(os.getcwd(), "subdir"))
print("bar")
