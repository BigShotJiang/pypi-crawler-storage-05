# An empty test checking that test.sh are correctly found and considered tests
echo success
