print("adacore")
print("legacy")
print("driver")
