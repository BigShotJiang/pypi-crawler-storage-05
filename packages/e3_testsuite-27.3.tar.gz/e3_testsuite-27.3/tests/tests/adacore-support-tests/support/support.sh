export TEXT="Hello, world!"
