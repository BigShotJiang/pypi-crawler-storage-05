# Folder classifier API

Implements a REST API for that calls an LLM-based classifier model hosted in Ray serve.

See [Build.md](Build.md) for build and deployment instructions.