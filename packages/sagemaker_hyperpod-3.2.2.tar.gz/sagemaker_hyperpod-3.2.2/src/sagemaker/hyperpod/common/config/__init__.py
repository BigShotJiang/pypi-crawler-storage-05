from sagemaker.hyperpod.common.config.metadata import Metadata
