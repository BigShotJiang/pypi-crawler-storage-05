Após a instalação do módulo deve ser configurado na empresa o processador de documentos eletrônicos como erpbrasil.edoc.
