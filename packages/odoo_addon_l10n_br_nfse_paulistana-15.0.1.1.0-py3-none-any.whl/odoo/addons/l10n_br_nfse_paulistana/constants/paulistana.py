ENVIO_LOTE_RPS = ["EnvioLoteRPS", "TesteEnvioLoteRPS"]

CONSULTA_LOTE = [
    "ConsultaLote",
    "ConsultaNFe",
]
