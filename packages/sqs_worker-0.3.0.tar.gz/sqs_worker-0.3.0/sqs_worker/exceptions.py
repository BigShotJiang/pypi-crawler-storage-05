class RetryLaterException(
    Exception,
):
    pass
