"""Test package for bycolors."""
