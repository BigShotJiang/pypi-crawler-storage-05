"""This whole module is yet to be implemented, I'm leaving this as a placeholder."""

from .core import BaseModule


class TeachersModule(BaseModule):
    endpoint = "teachers"
