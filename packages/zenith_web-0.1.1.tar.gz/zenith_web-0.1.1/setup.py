"""
Zenith Framework Setup Configuration

This file exists for compatibility with older tools.
The actual package configuration is in pyproject.toml.
"""

from setuptools import setup

# Configuration is in pyproject.toml
setup()
