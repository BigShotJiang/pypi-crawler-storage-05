__version__ = '5.17.4'
__commit_hash__ = 'fd01511a88c227794b5f46af23f0144c09421a7b'
findlibs_dependencies = ["eckitlib", "eccodeslib", "metkitlib"]
