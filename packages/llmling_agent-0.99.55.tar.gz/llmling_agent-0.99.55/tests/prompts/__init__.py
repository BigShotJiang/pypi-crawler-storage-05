"""Prompt-related tests."""
