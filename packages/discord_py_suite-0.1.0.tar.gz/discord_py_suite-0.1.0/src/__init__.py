"""Discord-Py-Suite: A comprehensive Discord MCP server with 120+ tools."""

__version__ = "0.1.0"

from .main import main

__all__ = ["main", "__version__"]
