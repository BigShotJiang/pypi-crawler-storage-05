This module extends the Odoo Account module to have the possibility to manage
account lock dates in a multi company context.

This module is interesting only if you have a lot of companies in a same Odoo instance.

In a mono company context, you can prefer the other OCA module, named ``account_lock_date_update``,
in account-financial-tools repository.
