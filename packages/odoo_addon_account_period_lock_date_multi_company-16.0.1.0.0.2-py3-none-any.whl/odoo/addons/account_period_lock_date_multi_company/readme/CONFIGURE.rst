* Go to "Invoicing > Configuration > Accounting > Companies Accounting Locks"

* For each companies, you can edit inline lock dates

.. figure:: ../static/description/res_company_tree.png
