# RSECon25

## Automated CI/CD with GitHub Actions, starting from scratch

This repo is a minimal Python package with tests from which we can build CI/CD workflows.

### Dependencies
On Linux systems, please install `bedtools` dependency as follows:
```
sudo apt-get install bedtools
```
On macOS, the same dependency should be installed with:
```
brew install bedtools
```
