# Plugins

This directory contains simple plugins. If a plugin has multiple different features
such as command line (CLI) or acts as a separate input, output it should be considered as a `component`.
These are located at `../components/`
