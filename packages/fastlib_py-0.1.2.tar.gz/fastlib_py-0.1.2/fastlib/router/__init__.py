"""Export router module."""

from fastlib.router.router_v1 import register_router

__all__ = [register_router]
