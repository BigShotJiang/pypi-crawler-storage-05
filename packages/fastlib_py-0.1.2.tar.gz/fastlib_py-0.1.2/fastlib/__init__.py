# SPDX-License-Identifier: MIT
"""Fast Web Application Libraries Package."""
