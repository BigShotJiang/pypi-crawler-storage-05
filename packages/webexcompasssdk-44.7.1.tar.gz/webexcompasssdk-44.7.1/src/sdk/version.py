
sdk_version = "44.7.1"
sdk_type='webex-compass-sdk'
sdk_it='compass-sdk'
sdk_email = 'sdk_email'
sdk_code = 'sdk_code'