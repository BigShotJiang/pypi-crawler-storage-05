"""CamSniff Python core package."""

__all__ = [
    "cli",
    "web_backend",
]

__version__ = "1.0.3"
