# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.


class MvErrors:
    @staticmethod
    def mv_items_accross_folders_within_ws() -> str:
        return "Moving items across folders in the same workspace is not yet supported"
