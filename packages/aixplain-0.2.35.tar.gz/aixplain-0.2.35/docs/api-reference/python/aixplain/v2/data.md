---
sidebar_label: data
title: aixplain.v2.data
---

