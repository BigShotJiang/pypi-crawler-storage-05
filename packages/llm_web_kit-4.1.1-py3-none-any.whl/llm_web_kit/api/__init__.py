"""LLM Web Kit API 模块.

提供基于 FastAPI 的 Web API 接口，用于处理 HTML 解析和内容提取功能。
"""

__version__ = "1.0.0"
__author__ = "LLM Web Kit Team"
