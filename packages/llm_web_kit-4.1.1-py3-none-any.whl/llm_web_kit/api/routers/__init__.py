"""路由模块.

包含所有 API 路由定义，按功能模块组织。
"""

from . import htmls

__all__ = ["htmls"]
