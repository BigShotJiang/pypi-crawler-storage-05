from llama_index.multi_modal_llms.huggingface.base import HuggingFaceMultiModal

__all__ = ["HuggingFaceMultiModal"]
