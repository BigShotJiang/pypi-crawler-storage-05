The development of this module has been supported by:

`KMEE INFORMATICA LTDA <https:/www.kmee.com.br>`__
