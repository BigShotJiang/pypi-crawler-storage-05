* `KMEE <https://www.kmee.com.br>`_:

  * Luis Felipe Miléo <mileo@kmee.com.br>
  * Cristiano Rodrigues <cristiano.rodrigues@kmee.com.br>
  * Kilian Macedo <kilian.macedo@kmee.com.br>

* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>
  * Eduardo Ribeiro <eduardo.ribeiro@escodoo.com.br>
