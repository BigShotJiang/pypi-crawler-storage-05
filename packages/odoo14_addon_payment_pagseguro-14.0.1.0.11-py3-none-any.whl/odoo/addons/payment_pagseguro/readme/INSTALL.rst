This module depends on:

* payment
* web_tour
