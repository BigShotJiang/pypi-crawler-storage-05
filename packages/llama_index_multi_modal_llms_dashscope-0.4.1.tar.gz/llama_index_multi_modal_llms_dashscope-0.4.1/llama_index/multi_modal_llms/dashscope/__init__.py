from llama_index.multi_modal_llms.dashscope.base import (
    DashScopeMultiModal,
    DashScopeMultiModalModels,
)

__all__ = ["DashScopeMultiModal", "DashScopeMultiModalModels"]
