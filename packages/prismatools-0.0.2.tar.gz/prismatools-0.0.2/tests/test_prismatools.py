#!/usr/bin/env python

"""Tests for `prismatools` package."""


import unittest

from prismatools import prismatools


class TestPrismatools(unittest.TestCase):
    """Tests for `prismatools` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
