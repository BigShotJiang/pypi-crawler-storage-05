# Welcome to prismatools


[![image](https://img.shields.io/pypi/v/prismatools.svg)](https://pypi.python.org/pypi/prismatools)


**prismatools is an open-source Python package for reading, analyzing, and visualizing hyperspectral imagery from the PRISMA mission.**


-   Free software: MIT License
-   Documentation: <https://gthlor.github.io/prismatools>


## Features

-   TODO
