# Usage

To use prismatools in a project:

```
import prismatools
```
