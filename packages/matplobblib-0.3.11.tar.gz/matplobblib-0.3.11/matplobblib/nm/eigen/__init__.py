from ...forall import *
from .jacobi import JACOBI
from .qr import QR

EIGEN = JACOBI + QR + []