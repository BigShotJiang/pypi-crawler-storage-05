"""Observability module - Logging and metrics"""

from pydhis2.observe.logging import setup_logging, get_logger

__all__ = [
    "setup_logging",
    "get_logger",
]
