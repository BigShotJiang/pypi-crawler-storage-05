# Faust Tools

Make it easier to faust application

## Feature

### Decorator

- stream

### Field

- ChoiceField

### Serializer (Record)

- ReadSerializer
- Write Serializer
