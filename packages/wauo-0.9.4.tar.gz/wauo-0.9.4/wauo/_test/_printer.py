from wauo.printer import Printer

p = Printer()
p.red("This is a red message")
p.green("This is a green message")
p.yellow("This is a yellow message")
p.blue("This is a blue message")
p.output("This is a custom color message", "magenta")
