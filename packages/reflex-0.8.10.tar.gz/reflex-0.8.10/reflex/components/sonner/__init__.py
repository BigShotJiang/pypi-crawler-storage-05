"""Init file for the sonner component."""

from .toast import toast
