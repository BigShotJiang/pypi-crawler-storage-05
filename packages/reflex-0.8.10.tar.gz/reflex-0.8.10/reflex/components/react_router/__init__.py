"""React-router internal components."""

from .dom import ReactRouterLink

link = ReactRouterLink.create
