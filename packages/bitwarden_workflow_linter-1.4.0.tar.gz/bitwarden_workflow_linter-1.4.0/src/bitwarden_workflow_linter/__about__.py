"""Metadata for Workflow Linter."""

__version__ = "1.4.0"
