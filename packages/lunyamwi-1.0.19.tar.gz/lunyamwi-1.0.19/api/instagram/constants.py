STYLISTS_WORDS = [
    "hair", "appointment", "appointments", "book", "call",
    "book.thecut.co", "licensed", "cutz", "kutz", "cuts",
    "cut", "hairstylist", "salon", "salons", "educator",
    "specialist", "beauty", "barber", "walk", "text",
    "stylist", "colour", "colouring", "loreal", "olaplex",
    "hairspray", "mousse", "pomade", "hair oil", "hair serum",
    "scissors", "comb", "brush", "blow dryer", "flat iron",
    "curling iron", "hair rollers", "hair clips", "hair ties",
    "headbands", "hair accessories", "updos", "braids",
    "twists", "buns", "ponytails", "curls", "waves",
    "volume", "texture", "shine", "frizz control",
    "breakage", "dryness", "oiliness", "thinning",
    "hair loss", "dandruff", "scalp problems"
]
MODEL="huggingface/mistralai/Mistral-7B-Instruct-v0.3"