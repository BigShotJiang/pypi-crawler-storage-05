let dataXmlTextEditorUrl = "{% url 'core_main_app_xml_text_editor_view'  %}";
let dataJSONTextEditorUrl = "{% url 'core_main_app_json_text_editor_view'  %}";
let changeDataDisplayUrl = "{% url 'core_main_add_change_data_display' %}";
var downloadTemplateUrl = "{% url 'core_main_app_rest_template_download' data.template_id  %}";
