var editGroupRightFormsUrl = "{% url 'core_main_edit_rights_groups_form' %}";
var addGroupToWorkspaceUrl = "{% url 'core_main_add_group_right_to_workspace' %}";