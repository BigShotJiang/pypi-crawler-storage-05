# CERTCC SSVC

**Stakeholder-Specific Vulnerability Categorization**

This is a placeholder for the official CERTCC SSVC package. The complete tooling and documentation is planned to be released by **September 2025**.

Stay tuned.
