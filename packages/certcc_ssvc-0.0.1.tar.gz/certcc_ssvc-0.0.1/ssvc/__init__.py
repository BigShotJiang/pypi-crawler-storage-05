"""
SSVC (Stakeholder-Specific Vulnerability Categorization)

This is a placeholder package. The official SSVC tools and documentation
will be released by September 2025.
"""

__version__ = "0.0.1"
__author__ = "CERTCC"

def coming_soon():
    return "SSVC package will be published by September 2025. Stay tuned!"
