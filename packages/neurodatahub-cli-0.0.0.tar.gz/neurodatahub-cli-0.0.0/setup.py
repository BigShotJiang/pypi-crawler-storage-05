"""Setup configuration for neurodatahub-cli package."""

from setuptools import setup

# This file exists for compatibility with older build systems
# The actual configuration is in pyproject.toml
setup()