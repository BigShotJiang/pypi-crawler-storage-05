#!/usr/bin/python
# coding: utf-8
from container_manager_mcp.container_manager_mcp import main

if __name__ == "__main__":
    main()
