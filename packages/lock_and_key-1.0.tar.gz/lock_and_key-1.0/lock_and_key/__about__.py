"""Version information for Lock & Key."""

__version__ = "1.0"
