"""AWS provider package."""

from lock_and_key.providers.aws.aws_provider import AWSProvider

__all__ = ["AWSProvider"]
