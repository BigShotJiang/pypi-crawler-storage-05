from noteparse.dbHelper import create_connection



def init():
#     create_connection(host,port,user,password,db)
    create_connection()