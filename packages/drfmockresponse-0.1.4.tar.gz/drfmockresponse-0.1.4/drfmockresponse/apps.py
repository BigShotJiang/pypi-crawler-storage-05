from django.apps import AppConfig


class DrfmockresponseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'drfmockresponse'
    verbose_name = 'DRF MOCK RESPONSE'
