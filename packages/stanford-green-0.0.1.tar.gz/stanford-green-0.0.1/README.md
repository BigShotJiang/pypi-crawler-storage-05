# stanford-green
This is a safe PoC package demonstrating dependency confusion.
Claimed by cygut7.
