# mosstool

MObility Simulation System (MOSS) Toolbox

## Installation

```bash
pip install mosstool
```

More basic concept introductions and tutorials are available at [MOSS](https://moss.fiblab.net/docs/introduction)

GitHub Repo: [https://github.com/tsinghua-fib-lab/mosstool](https://github.com/tsinghua-fib-lab/mosstool)
