=====
Usage
=====

To use ubuntu-cloud-image-changelog in a project::

    import ubuntu_cloud_image_changelog
