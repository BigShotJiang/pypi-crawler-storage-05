"""Top-level package for ubuntu-cloud-image-changelog."""

__author__ = """Philip Roche"""
__email__ = "cpc@groups.canonical.com"
__version__ = "0.15.7"
