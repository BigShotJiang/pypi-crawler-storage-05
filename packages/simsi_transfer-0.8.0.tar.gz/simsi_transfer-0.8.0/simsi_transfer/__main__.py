# -*- coding: utf-8 -*-


"""simsi_transfer.__main__: executed when bootstrap directory is called as script."""
import sys
from .main import main

main(sys.argv[1:])
