function sortable(options={}, func = undefined) {
    const dragSelector = options["drag"] || '.draggable-item';
    const dropContainer = options["dropTo"] || '.drop-zone';
    const onDrop = func;

    const draggableItems = document.querySelectorAll(dragSelector);
    const dropZones = document.querySelectorAll(dropContainer);
    const placeholder = document.createElement("div");
    placeholder.innerHTML = "<div class='card'></div>";

    draggableItems.forEach(item => {
        const dragHandle = item.querySelector('.drag-handle');
        if (dragHandle) {
            // mousedown on drag handle to enable dragging parent
            dragHandle.addEventListener('mousedown', (e) => {
                item.setAttribute('draggable', "true");
            });
        }
        item.addEventListener('dragstart', (e) => {
            placeholder.className = e.target.className;
            placeholder.classList.add('drag-placeholder');
            e.dataTransfer.setData('text/plain', e.target.id);
            setTimeout(function(){
                e.target.classList.add("dragging");
            }, 0);
        });
        item.addEventListener('dragend', (e) => {
            placeholder.remove();
            placeholder.className = "";
            e.target.classList.remove("dragging");
            e.target.removeAttribute("draggable");
            if (onDrop) {
                onDrop(e);
            }
        });
    });

    dropZones.forEach(zone => {
        zone.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = "move";
            const hoveredElement = e.target.closest(dragSelector) || e.target;
            if (hoveredElement.matches(dragSelector)) {
                hoveredElement.parentNode.insertBefore(placeholder, hoveredElement);
            }
        });

        zone.addEventListener('drop', (e) => {
            e.preventDefault();
            const data = e.dataTransfer.getData('text/plain');
            const draggedElement = document.getElementById(data);
            const dropTarget = e.target.closest(dragSelector) || e.target;

            if (dropTarget) {
                dropTarget.parentNode.insertBefore(draggedElement, placeholder);
            }
        });
    });
}