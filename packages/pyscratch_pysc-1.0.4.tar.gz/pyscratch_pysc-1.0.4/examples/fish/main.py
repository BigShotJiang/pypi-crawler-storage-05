import pyscratch as pysc
import fish

pysc.game.start()