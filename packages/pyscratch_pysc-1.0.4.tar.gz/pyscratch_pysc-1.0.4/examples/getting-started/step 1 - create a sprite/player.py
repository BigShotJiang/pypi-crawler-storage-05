import pyscratch as pysc


player = pysc.create_single_costume_sprite("assets/player-fish.png")
#player.set_draggable(True)