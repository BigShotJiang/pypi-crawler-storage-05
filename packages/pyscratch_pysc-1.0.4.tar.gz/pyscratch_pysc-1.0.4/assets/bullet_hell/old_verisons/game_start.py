from player import *
from enemy import *
from main import game


game.start(60, 300, False)