# PyScratch 
For more information, see: https://kwdchan.github.io/pyscratch/



## Change History

### 12 Sep 2025
**v1.0.4**  
Fixed the show/hide collision related problem due to the deferral of movement to the frame update.

### 07 Sep 2025
**v1.0.3**  
Added undeclared dependency: Pillow   
Specified the versions of the dependencies

### Jul 2025
**v1.0.0**  
The first version
