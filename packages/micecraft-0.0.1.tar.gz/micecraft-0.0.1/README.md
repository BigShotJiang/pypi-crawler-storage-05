# MiceCraft

The repository contains:

- the Python code to interact with the MiceCraft devices
- the arduino code for the microcontrollers of each block

## Using the packages

TODO

