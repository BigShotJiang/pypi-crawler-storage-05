## MicroProjects
This is a collection of MicroProjects I code for fun..

## Table of Content
- [MicroProjects](#microprojects)
- [Table of Content](#table-of-content)
- [Getting MicroProjects](#getting-microprojects)
    - [Source](#source)
    - [PyPI (Python)](#pypi-python)
- [1. Calculator](#1-calculator)
    - [Usage:](#usage)
- [2. ngit](#2-ngit)
    - [Usage:](#usage-1)

## Getting MicroProjects

### Source

Clone the development version from [MicroProjects - GitHub](https://github.com/nyx-4/MicroProjects.git)

```sh
git clone https://github.com/nyx-4/MicroProjects.git
cd MicroProjects
pip install .
```

### PyPI (Python)

Use the package manager pip to install foobar.

```sh
pip install microprojects
```


## 1. [Calculator](https://github.com/nyx-4/MicroProjects/tree/main/microprojects/calc)
A simple calculator written in Python that _just_ works. The source code is available on [nyx-4/MicroProjects/calc - GitHub](https://github.com/nyx-4/MicroProjects/tree/main/microprojects/calc).

### [Usage](https://github.com/nyx-4/MicroProjects/tree/main/microprojects/calc#usage):
- From CLI: `calc 5 + 10 x 3 - 2`
- As Python module: `python -m microprojects.calc 5 + 10 x 3 - 2`
- From Python source: `microprojects.calc("5 + 10 x 3 - 2")`


## 2. [ngit](https://github.com/nyx-4/MicroProjects/tree/main/microprojects/ngit)
Git re-implementation in Python that is _perfectly compatible_ with with [Git SCM](https://git-scm.com/). The source code is available on [nyx-4/MicroProjects/ngit - GitHub](https://github.com/nyx-4/MicroProjects/tree/main/microprojects/ngit).

### [Usage](https://github.com/nyx-4/MicroProjects/tree/main/microprojects/ngit#usage):
- From CLI:
```sh
ngit init
```

