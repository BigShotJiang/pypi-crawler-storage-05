import microprojects


def main() -> None:
    microprojects.calc_main()


if __name__ == "__main__":
    main()
