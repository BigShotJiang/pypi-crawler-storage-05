import microprojects


def main() -> None:
    microprojects.ngit_main()


if __name__ == "__main__":
    main()
