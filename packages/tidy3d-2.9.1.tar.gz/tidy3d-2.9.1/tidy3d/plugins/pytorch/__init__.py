from __future__ import annotations

from .wrapper import to_torch

__all__ = ["to_torch"]
