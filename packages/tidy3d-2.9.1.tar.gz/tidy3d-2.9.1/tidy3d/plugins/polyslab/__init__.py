"""Imports from complex polyslab plugin."""

from __future__ import annotations

from .polyslab import ComplexPolySlab

__all__ = ["ComplexPolySlab"]
