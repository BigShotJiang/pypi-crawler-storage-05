### INTENTION and CONTEXT
My intention is to implement {...} as python cli script
generate the cli script and the unit tests implemented with pytest

{Further implementation specific context and/or references ...}

