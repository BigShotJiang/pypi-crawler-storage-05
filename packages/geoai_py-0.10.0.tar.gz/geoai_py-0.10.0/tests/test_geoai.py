#!/usr/bin/env python

"""Tests for `geoai` package."""


import unittest

from geoai import geoai


class TestGeoai(unittest.TestCase):
    """Tests for `geoai` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
