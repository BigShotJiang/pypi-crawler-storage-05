# extract module

::: geoai.extract
