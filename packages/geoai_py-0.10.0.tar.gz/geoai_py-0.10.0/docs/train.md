# train module

::: geoai.train
