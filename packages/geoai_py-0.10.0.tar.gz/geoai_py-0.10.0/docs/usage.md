# Usage

To use geoai in a project:

```
import geoai
```
