from torch import tensor


D65 = tensor((0.95047, 1.0, 1.08883))
