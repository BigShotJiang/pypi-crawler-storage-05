annofabapi.pydantic\_models package
===================================

Submodules
----------

annofabapi.pydantic\_models.accept\_organization\_invitation\_request module
----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.accept_organization_invitation_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.account module
------------------------------------------

.. automodule:: annofabapi.pydantic_models.account
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.account\_worktime\_statistics module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.account_worktime_statistics
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.action\_required module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.action_required
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_default\_type module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_default_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_definition\_type module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_definition_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_definition\_v1 module
-------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_definition_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_definition\_v1\_choices\_inner module
-----------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_definition_v1_choices_inner
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_definition\_v2 module
-------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_definition_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_restriction module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_restriction
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_restriction\_condition module
---------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_restriction_condition
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_restriction\_condition\_can\_input module
---------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_restriction_condition_can_input
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_restriction\_condition\_equals module
-----------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_restriction_condition_equals
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_restriction\_condition\_has\_label module
---------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_restriction_condition_has_label
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_restriction\_condition\_imply module
----------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_restriction_condition_imply
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_restriction\_condition\_matches module
------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_restriction_condition_matches
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_restriction\_condition\_not\_equals module
----------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_restriction_condition_not_equals
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_restriction\_condition\_not\_matches module
-----------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_restriction_condition_not_matches
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_v1 module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_v2 module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_value module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_value
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_value\_choice module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_value_choice
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_value\_comment module
-------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_value_comment
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_value\_flag module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_value_flag
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_value\_integer module
-------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_value_integer
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_value\_link module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_value_link
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_value\_select module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_value_select
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_value\_text module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_value_text
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.additional\_data\_value\_tracking module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.additional_data_value_tracking
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.aggregation\_result module
------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.aggregation_result
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.all\_oidc\_endpoints module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.all_oidc_endpoints
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_data\_holding\_type module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_data_holding_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_data\_v1 module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_data_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_content\_input module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_content_input
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_content\_input\_inner module
----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_content_input_inner
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_content\_input\_outer module
----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_content_input_outer
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_content\_output module
----------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_content_output
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_content\_output\_inner module
-----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_content_output_inner
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_content\_output\_inner\_unknown module
--------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_content_output_inner_unknown
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_content\_output\_outer module
-----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_content_output_outer
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_content\_output\_outer\_unresolved module
-----------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_content_output_outer_unresolved
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_v1 module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_v2\_create module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_v2_create
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_v2\_get module
--------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_v2_get
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_v2\_import module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_v2_import
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_v2\_input module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_v2_input
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_v2\_output module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_v2_output
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_detail\_v2\_update module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_detail_v2_update
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_editor\_feature module
--------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_editor_feature
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_input module
----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_input
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_list module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_list
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_output module
-----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_output
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_props\_for\_editor module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_props_for_editor
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_query module
----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_query
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs module
----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs\_history module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs_history
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs\_movie\_option module
-------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs_movie_option
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs\_option module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs_option
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs\_request module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs\_request\_v1 module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs_request_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs\_request\_v2 module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs_request_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs\_request\_v3 module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs_request_v3
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs\_v1 module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs\_v2 module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_specs\_v3 module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_specs_v3
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_thumbnail module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_thumbnail
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_thumbnail\_detail module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_thumbnail_detail
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_thumbnail\_detail\_failed module
------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_thumbnail_detail_failed
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_thumbnail\_detail\_image\_slice module
------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_thumbnail_detail_image_slice
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_thumbnail\_detail\_unsupported module
-----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_thumbnail_detail_unsupported
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_thumbnail\_image module
---------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_thumbnail_image
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_thumbnail\_image\_source module
-----------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_thumbnail_image_source
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_definition\_annotation\_editor\_feature module
---------------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_definition_annotation_editor_feature
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_definition\_display\_line\_direction module
------------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_definition_display_line_direction
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_definition\_margin\_of\_error\_tolerance module
----------------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_definition_margin_of_error_tolerance
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_definition\_minimum\_area2d module
---------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_definition_minimum_area2d
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_definition\_minimum\_size2d module
---------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_definition_minimum_size2d
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_definition\_minimum\_size2d\_with\_default\_insert\_position module
------------------------------------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_definition_minimum_size2d_with_default_insert_position
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_definition\_one\_boolean\_field module
-------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_definition_one_boolean_field
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_definition\_one\_integer\_field module
-------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_definition_one_integer_field
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_definition\_one\_string\_field module
------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_definition_one_string_field
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_definition\_vertex\_count\_min\_max module
-----------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_definition_vertex_count_min_max
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_min\_warn\_rule module
---------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_min_warn_rule
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_annotation\_editor\_feature module
----------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_annotation_editor_feature
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_display\_line\_direction module
-------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_display_line_direction
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_empty\_field\_value module
--------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_empty_field_value
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_margin\_of\_error\_tolerance module
-----------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_margin_of_error_tolerance
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_minimum\_area2d module
----------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_minimum_area2d
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_minimum\_size module
--------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_minimum_size
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_minimum\_size2d\_with\_default\_insert\_position module
-------------------------------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_minimum_size2d_with_default_insert_position
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_one\_boolean\_field\_value module
---------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_one_boolean_field_value
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_one\_integer\_field\_value module
---------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_one_integer_field_value
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_one\_string\_field\_value module
--------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_one_string_field_value
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_type\_field\_value\_vertex\_count\_min\_max module
------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_type_field_value_vertex_count_min_max
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_v1 module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_v2\_input module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_v2_input
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotation\_v2\_output module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotation_v2_output
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.annotations\_by\_input\_data\_id\_identifier module
-------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.annotations_by_input_data_id_identifier
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.assignee\_rule\_of\_resubmitted\_task module
------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.assignee_rule_of_resubmitted_task
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_annotation\_request\_item module
-------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_annotation_request_item
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_annotation\_request\_item\_delete module
---------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_annotation_request_item_delete
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_annotation\_request\_item\_put\_v1 module
----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_annotation_request_item_put_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_annotation\_request\_item\_put\_v2 module
----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_annotation_request_item_put_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_annotation\_v1 module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_annotation_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_annotation\_v2 module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_annotation_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_comment\_request\_item module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_comment_request_item
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_comment\_request\_item\_delete module
------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_comment_request_item_delete
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_comment\_request\_item\_put module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_comment_request_item_put
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_input\_data\_request\_item module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_input_data_request_item
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_input\_data\_request\_item\_delete module
----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_input_data_request_item_delete
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_inspection\_request\_item module
-------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_inspection_request_item
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_inspection\_request\_item\_delete module
---------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_inspection_request_item_delete
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_inspection\_request\_item\_put module
------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_inspection_request_item_put
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_task\_request\_item module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_task_request_item
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.batch\_task\_request\_item\_delete module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.batch_task_request_item_delete
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.bounding\_box\_metadata module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.bounding_box_metadata
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.change\_password\_request module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.change_password_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.color module
----------------------------------------

.. automodule:: annofabapi.pydantic_models.color
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.comment module
------------------------------------------

.. automodule:: annofabapi.pydantic_models.comment
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.comment\_node module
------------------------------------------------

.. automodule:: annofabapi.pydantic_models.comment_node
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.comment\_status module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.comment_status
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.comment\_type module
------------------------------------------------

.. automodule:: annofabapi.pydantic_models.comment_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.comment\_validation\_error module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.comment_validation_error
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.confirm\_account\_delete\_request module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.confirm_account_delete_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.confirm\_reset\_email\_request module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.confirm_reset_email_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.confirm\_reset\_password\_request module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.confirm_reset_password_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.confirm\_sign\_up\_request module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.confirm_sign_up_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.confirm\_verify\_email\_request module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.confirm_verify_email_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.count module
----------------------------------------

.. automodule:: annofabapi.pydantic_models.count
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.count\_result module
------------------------------------------------

.. automodule:: annofabapi.pydantic_models.count_result
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.data\_path module
---------------------------------------------

.. automodule:: annofabapi.pydantic_models.data_path
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.date\_range module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.date_range
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.default\_annotation\_type module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.default_annotation_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.delete\_project\_response module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.delete_project_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.duplicated\_segmentation\_v2 module
---------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.duplicated_segmentation_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.duplicated\_v1 module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.duplicated_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.duplicated\_v2 module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.duplicated_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.editor\_usage\_timespan module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.editor_usage_timespan
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.error\_item module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.error_item
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.errors module
-----------------------------------------

.. automodule:: annofabapi.pydantic_models.errors
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.external\_idp\_determinant module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.external_idp_determinant
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_additional\_data module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_additional_data
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_additional\_data\_choice\_value module
------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_additional_data_choice_value
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_additional\_data\_value module
----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_additional_data_value
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_additional\_data\_value\_choice module
------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_additional_data_value_choice
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_additional\_data\_value\_comment module
-------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_additional_data_value_comment
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_additional\_data\_value\_flag module
----------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_additional_data_value_flag
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_additional\_data\_value\_integer module
-------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_additional_data_value_integer
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_additional\_data\_value\_link module
----------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_additional_data_value_link
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_additional\_data\_value\_tracking module
--------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_additional_data_value_tracking
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_data module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_data
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_data\_bounding\_box module
------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_data_bounding_box
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_data\_classification module
-------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_data_classification
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_data\_points module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_data_points
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_data\_range module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_data_range
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_data\_segmentation module
-----------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_data_segmentation
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_data\_segmentation\_v2 module
---------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_data_segmentation_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_data\_single\_point module
------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_data_single_point
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_data\_unknown module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_data_unknown
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.full\_annotation\_detail module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.full_annotation_detail
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.get\_editor\_annotations\_in\_bulk\_response module
-------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.get_editor_annotations_in_bulk_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.get\_input\_data\_in\_bulk\_response module
-----------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.get_input_data_in_bulk_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.get\_supplementary\_data\_in\_bulk\_response module
-------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.get_supplementary_data_in_bulk_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.get\_tasks\_in\_bulk\_response module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.get_tasks_in_bulk_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.global\_idp\_name\_determinant module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.global_idp_name_determinant
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.graph\_type module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.graph_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.histogram\_item module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.histogram_item
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.illegal\_state module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.illegal_state
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.initiate\_mfa\_setup\_request module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.initiate_mfa_setup_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.initiate\_mfa\_setup\_response module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.initiate_mfa_setup_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.input\_data module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.input_data
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.input\_data\_identifier module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.input_data_identifier
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.input\_data\_list module
----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.input_data_list
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.input\_data\_order module
-----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.input_data_order
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.input\_data\_request module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.input_data_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.input\_data\_set module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.input_data_set
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.input\_data\_summary module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.input_data_summary
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.input\_data\_type module
----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.input_data_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection module
---------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_data module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_data
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_data\_custom module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_data_custom
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_data\_point module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_data_point
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_data\_polyline module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_data_polyline
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_data\_polyline\_coordinates\_inner module
---------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_data_polyline_coordinates_inner
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_data\_time module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_data_time
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_or\_reply\_required module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_or_reply_required
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_phrase module
-----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_phrase
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_statistics module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_statistics
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_statistics\_breakdown module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_statistics_breakdown
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_statistics\_phrases module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_statistics_phrases
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_status module
-----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_status
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_summary module
------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_summary
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.inspection\_validation\_error module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.inspection_validation_error
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.instruction module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.instruction
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.instruction\_history module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.instruction_history
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.instruction\_image module
-----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.instruction_image
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.instruction\_image\_path module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.instruction_image_path
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.internationalization\_message module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.internationalization_message
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.internationalization\_message\_messages\_inner module
---------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.internationalization_message_messages_inner
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.invalid\_annotation\_data module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.invalid_annotation_data
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.invalid\_choice module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.invalid_choice
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.invalid\_link\_target module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.invalid_link_target
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.invalid\_value module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.invalid_value
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.invite\_organization\_member\_request module
------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.invite_organization_member_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.issue\_personal\_access\_token\_request module
--------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.issue_personal_access_token_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.issue\_project\_guest\_user\_token\_request module
------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.issue_project_guest_user_token_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.issue\_project\_token\_request module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.issue_project_token_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.issuer\_only\_oidc\_endpoints module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.issuer_only_oidc_endpoints
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.job\_detail module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.job_detail
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.job\_detail\_copy\_project module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.job_detail_copy_project
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.job\_detail\_gen\_inputs module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.job_detail_gen_inputs
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.job\_detail\_gen\_tasks module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.job_detail_gen_tasks
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.job\_detail\_invoke\_hook module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.job_detail_invoke_hook
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.job\_detail\_move\_project module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.job_detail_move_project
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.job\_status module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.job_status
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.key\_layout module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.key_layout
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.keybind module
------------------------------------------

.. automodule:: annofabapi.pydantic_models.keybind
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.label\_statistics module
----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.label_statistics
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.label\_v1 module
--------------------------------------------

.. automodule:: annofabapi.pydantic_models.label_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.label\_v2 module
--------------------------------------------

.. automodule:: annofabapi.pydantic_models.label_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.label\_v3 module
--------------------------------------------

.. automodule:: annofabapi.pydantic_models.label_v3
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.lang module
---------------------------------------

.. automodule:: annofabapi.pydantic_models.lang
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.login\_need\_challenge\_response module
-------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.login_need_challenge_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.login\_request module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.login_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.login\_respond\_to\_auth\_challenge\_request module
-------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.login_respond_to_auth_challenge_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.login\_response module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.login_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.login\_succeed\_response module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.login_succeed_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.marker module
-----------------------------------------

.. automodule:: annofabapi.pydantic_models.marker
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.markers module
------------------------------------------

.. automodule:: annofabapi.pydantic_models.markers
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.message module
------------------------------------------

.. automodule:: annofabapi.pydantic_models.message
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.message\_or\_job\_info module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.message_or_job_info
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.mfa\_setting module
-----------------------------------------------

.. automodule:: annofabapi.pydantic_models.mfa_setting
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.my\_account module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.my_account
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.my\_notification\_list module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.my_notification_list
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.my\_notification\_message module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.my_notification_message
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.my\_notification\_unread\_messages\_count module
----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.my_notification_unread_messages_count
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.my\_organization module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.my_organization
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.my\_organization\_list module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.my_organization_list
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.no\_comment module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.no_comment
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.no\_comment\_inspection module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.no_comment_inspection
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.oidc\_attribute\_mapping module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.oidc_attribute_mapping
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.oidc\_endpoints module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.oidc_endpoints
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization module
-----------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_activity module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_activity
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_cache\_record module
--------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_cache_record
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_idp\_id\_determinant module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_idp_id_determinant
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_job\_info module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_job_info
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_job\_info\_container module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_job_info_container
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_member module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_member
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_member\_list module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_member_list
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_member\_role module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_member_role
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_member\_status module
---------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_member_status
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_oidc\_idp module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_oidc_idp
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_plugin module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_plugin
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_plugin\_compatibility module
----------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_plugin_compatibility
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_plugin\_compatibility\_type module
----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_plugin_compatibility_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_plugin\_compatibility\_type\_bottom module
------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_plugin_compatibility_type_bottom
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_plugin\_compatibility\_type\_constant module
--------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_plugin_compatibility_type_constant
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_plugin\_compatibility\_type\_top module
---------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_plugin_compatibility_type_top
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_plugin\_list module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_plugin_list
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.organization\_registration\_request module
----------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.organization_registration_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.overlapped\_range\_annotation module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.overlapped_range_annotation
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.password\_reset\_request module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.password_reset_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.personal\_access\_token module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.personal_access_token
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.personal\_access\_token\_info module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.personal_access_token_info
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.personal\_access\_token\_permission module
----------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.personal_access_token_permission
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.personal\_access\_token\_permission\_all module
---------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.personal_access_token_permission_all
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.phase\_statistics module
----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.phase_statistics
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.plugin\_detail module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.plugin_detail
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.plugin\_detail\_annotation\_editor module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.plugin_detail_annotation_editor
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.plugin\_detail\_annotation\_specs module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.plugin_detail_annotation_specs
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.plugin\_detail\_extended\_annotation\_specs module
------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.plugin_detail_extended_annotation_specs
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.plugin\_detail\_task\_assignment module
-------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.plugin_detail_task_assignment
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.plugin\_token\_request module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.plugin_token_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.plugin\_token\_request\_authorization\_code module
------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.plugin_token_request_authorization_code
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.plugin\_token\_request\_refresh\_token module
-------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.plugin_token_request_refresh_token
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.plugin\_token\_response module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.plugin_token_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.point module
----------------------------------------

.. automodule:: annofabapi.pydantic_models.point
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.position\_for\_minimum\_bounding\_box\_insertion module
-----------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.position_for_minimum_bounding_box_insertion
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.post\_annotation\_archive\_update\_response module
------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.post_annotation_archive_update_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.post\_annotation\_archive\_update\_response\_wrapper module
---------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.post_annotation_archive_update_response_wrapper
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.post\_exchange\_code\_login\_response module
------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.post_exchange_code_login_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.post\_exchange\_code\_response module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.post_exchange_code_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.post\_mfa\_setting\_request module
--------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.post_mfa_setting_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.post\_project\_tasks\_update\_response module
-------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.post_project_tasks_update_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.price\_plan module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.price_plan
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project module
------------------------------------------

.. automodule:: annofabapi.pydantic_models.project
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_account\_statistics module
---------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_account_statistics
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_account\_statistics\_history module
------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_account_statistics_history
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_cache\_record module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_cache_record
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_configuration\_get module
--------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_configuration_get
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_configuration\_put module
--------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_configuration_put
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_container module
-----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_container
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_copy\_request module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_copy_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_copy\_response module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_copy_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_extra\_data module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_extra_data
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_extra\_data\_kind module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_extra_data_kind
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_extra\_data\_kind\_scope module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_extra_data_kind_scope
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_extra\_data\_value module
--------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_extra_data_value
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_extra\_data\_value\_default module
-----------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_extra_data_value_default
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_extra\_data\_value\_empty module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_extra_data_value_empty
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_extra\_data\_value\_saved module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_extra_data_value_saved
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_guest\_user\_profile module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_guest_user_profile
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_inputs\_update\_response module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_inputs_update_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_job\_info module
-----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_job_info
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_job\_info\_container module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_job_info_container
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_job\_type module
-----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_job_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_list module
------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_list
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_member module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_member
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_member\_list module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_member_list
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_member\_request module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_member_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_member\_role module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_member_role
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_member\_status module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_member_status
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_status module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_status
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_summary module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_summary
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_task\_counts module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_task_counts
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_task\_counts\_task\_counts\_inner module
-----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_task_counts_task_counts_inner
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_task\_statistics module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_task_statistics
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_task\_statistics\_history module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_task_statistics_history
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_token module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_token
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.project\_token\_info module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.project_token_info
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_annotation\_request module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_annotation_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_annotation\_thumbnail\_body module
-------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_annotation_thumbnail_body
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_input\_data\_set\_request module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_input_data_set_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_instruction\_request module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_instruction_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_markers\_request module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_markers_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_my\_account\_request module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_my_account_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_my\_notification\_message\_opened\_request module
----------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_my_notification_message_opened_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_organization\_idp\_body module
---------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_organization_idp_body
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_organization\_member\_role\_request module
---------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_organization_member_role_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_organization\_plugin\_request module
---------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_organization_plugin_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_organization\_request module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_organization_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_project\_extra\_data\_body module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_project_extra_data_body
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_project\_request module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_project_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_project\_response module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_project_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.put\_webhook\_request module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.put_webhook_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.refresh\_token\_request module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.refresh_token_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.reply\_comment module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.reply_comment
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.reply\_required module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.reply_required
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.reset\_email\_request module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.reset_email_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.resolution module
---------------------------------------------

.. automodule:: annofabapi.pydantic_models.resolution
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.revoke\_personal\_access\_token\_request module
---------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.revoke_personal_access_token_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.revoke\_project\_token\_request module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.revoke_project_token_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.root\_comment module
------------------------------------------------

.. automodule:: annofabapi.pydantic_models.root_comment
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.segmentation\_metadata module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.segmentation_metadata
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.sign\_up\_request module
----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.sign_up_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.simple\_annotation module
-----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.simple_annotation
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.simple\_annotation\_detail module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.simple_annotation_detail
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.single\_annotation module
-----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.single_annotation
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.single\_annotation\_detail\_v1 module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.single_annotation_detail_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.single\_annotation\_detail\_v2 module
-----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.single_annotation_detail_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.single\_annotation\_v1 module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.single_annotation_v1
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.single\_annotation\_v2 module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.single_annotation_v2
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.supplementary\_data module
------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.supplementary_data
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.supplementary\_data\_by\_input\_data\_id\_identifier module
---------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.supplementary_data_by_input_data_id_identifier
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.supplementary\_data\_request module
---------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.supplementary_data_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.supplementary\_data\_type module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.supplementary_data_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.system\_metadata module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.system_metadata
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.system\_metadata\_custom module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.system_metadata_custom
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.system\_metadata\_image module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.system_metadata_image
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.system\_metadata\_movie module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.system_metadata_movie
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task module
---------------------------------------

.. automodule:: annofabapi.pydantic_models.task
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_assign\_request module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_assign_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_assign\_request\_type module
--------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_assign_request_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_assign\_request\_type\_random module
----------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_assign_request_type_random
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_assign\_request\_type\_selection module
-------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_assign_request_type_selection
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_assign\_request\_type\_task\_property module
------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_assign_request_type_task_property
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_assignment\_order module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_assignment_order
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_assignment\_property module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_assignment_property
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_assignment\_type module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_assignment_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_generate\_request module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_generate_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_generate\_response module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_generate_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_generate\_response\_wrapper module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_generate_response_wrapper
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_generate\_rule module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_generate_rule
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_generate\_rule\_by\_count module
------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_generate_rule_by_count
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_generate\_rule\_by\_directory module
----------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_generate_rule_by_directory
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_generate\_rule\_by\_input\_data\_csv module
-----------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_generate_rule_by_input_data_csv
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_history module
------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_history
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_history\_event module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_history_event
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_history\_short module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_history_short
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_identifier module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_identifier
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_input\_validation module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_input_validation
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_list module
---------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_list
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_operation module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_operation
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_phase module
----------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_phase
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_phase\_statistics module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_phase_statistics
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_request module
------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_status module
-----------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_status
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.task\_validation module
---------------------------------------------------

.. automodule:: annofabapi.pydantic_models.task_validation
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.temporary\_url module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.temporary_url
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.token module
----------------------------------------

.. automodule:: annofabapi.pydantic_models.token
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.unconfirmed\_user\_response module
--------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.unconfirmed_user_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.unknown\_additional\_data module
------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.unknown_additional_data
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.unknown\_label module
-------------------------------------------------

.. automodule:: annofabapi.pydantic_models.unknown_label
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.unknown\_link\_target module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.unknown_link_target
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.update\_status\_required module
-----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.update_status_required
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.usage\_status module
------------------------------------------------

.. automodule:: annofabapi.pydantic_models.usage_status
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.usage\_status\_by\_day module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.usage_status_by_day
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.usage\_status\_csv\_file\_url module
----------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.usage_status_csv_file_url
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.user\_cache\_record module
------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.user_cache_record
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.user\_defined\_annotation\_data\_type module
------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.user_defined_annotation_data_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.user\_defined\_annotation\_type\_definition module
------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.user_defined_annotation_type_definition
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.user\_defined\_annotation\_type\_definition\_field\_definitions\_inner module
---------------------------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.user_defined_annotation_type_definition_field_definitions_inner
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.user\_defined\_annotation\_type\_field\_definition module
-------------------------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.user_defined_annotation_type_field_definition
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.user\_id\_determinant module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.user_id_determinant
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.validation\_error module
----------------------------------------------------

.. automodule:: annofabapi.pydantic_models.validation_error
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.verify\_email\_request module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.verify_email_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.webhook module
------------------------------------------

.. automodule:: annofabapi.pydantic_models.webhook
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.webhook\_event\_type module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.webhook_event_type
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.webhook\_header module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.webhook_header
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.webhook\_http\_method module
--------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.webhook_http_method
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.webhook\_status module
--------------------------------------------------

.. automodule:: annofabapi.pydantic_models.webhook_status
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.webhook\_test\_request module
---------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.webhook_test_request
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.webhook\_test\_response module
----------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.webhook_test_response
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.worktime\_statistics module
-------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.worktime_statistics
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.worktime\_statistics\_by\_account module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.worktime_statistics_by_account
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.worktime\_statistics\_by\_project module
--------------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.worktime_statistics_by_project
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.worktime\_statistics\_data module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.worktime_statistics_data
   :members:
   :show-inheritance:
   :undoc-members:

annofabapi.pydantic\_models.worktime\_statistics\_item module
-------------------------------------------------------------

.. automodule:: annofabapi.pydantic_models.worktime_statistics_item
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: annofabapi.pydantic_models
   :members:
   :show-inheritance:
   :undoc-members:
