annofabapi.api2 module
======================


annofabapi.AnnofabApi2 class
----------------------------
.. autoclass:: annofabapi.AnnofabApi2
    :inherited-members:

