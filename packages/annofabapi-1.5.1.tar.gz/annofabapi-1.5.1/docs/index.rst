.. annofabapi documentation master file, created by
   sphinx-quickstart on Tue Jun 11 16:47:23 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

annofabapi documentation
==================================================

--------------------------------------------------
Table of Contents
--------------------------------------------------

.. toctree::
   :maxdepth: 2

   user_guide/index
   api_reference/index
   faq


--------------------------------------------------
Indices and tables
--------------------------------------------------

* :ref:`genindex`
* :ref:`search`
