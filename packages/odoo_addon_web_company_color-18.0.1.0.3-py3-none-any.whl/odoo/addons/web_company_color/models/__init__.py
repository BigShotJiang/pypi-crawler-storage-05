# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import assetsbundle
from . import res_company
from . import ir_qweb
