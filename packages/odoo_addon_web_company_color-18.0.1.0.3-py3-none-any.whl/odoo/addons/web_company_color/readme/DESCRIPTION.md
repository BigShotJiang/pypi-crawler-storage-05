This module change navbar colors based in the company logo colors.
