===============
 ``zope.copy``
===============

.. image:: https://img.shields.io/pypi/v/zope.copy.svg
        :target: https://pypi.python.org/pypi/zope.copy/
        :alt: Latest release

.. image:: https://img.shields.io/pypi/pyversions/zope.copy.svg
        :target: https://pypi.org/project/zope.copy/
        :alt: Supported Python versions

.. image:: https://github.com/zopefoundation/zope.copy/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.copy/actions/workflows/tests.yml

.. image:: https://coveralls.io/repos/github/zopefoundation/zope.copy/badge.svg?branch=master
        :target: https://coveralls.io/github/zopefoundation/zope.copy?branch=master

.. image:: https://readthedocs.org/projects/zopecopy/badge/?version=latest
        :target: http://zopecopy.readthedocs.org/en/latest/
        :alt: Documentation Status

This package provides a pluggable mechanism for copying persistent objects.

Documentation is hosted at https://zopecopy.readthedocs.io/
