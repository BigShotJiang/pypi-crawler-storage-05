:mod:`zope.copy` API Reference
==============================

:mod:`zope.copy.interfaces`
---------------------------

.. automodule:: zope.copy.interfaces

   .. autoexception:: ResumeCopy

   .. autointerface:: ICopyHook
      :members:
      :member-order: bysource
