:mod:`zope.copy` Documentation
==============================

Contents:

.. toctree::
   :maxdepth: 2

   narr
   api
   hacking


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
