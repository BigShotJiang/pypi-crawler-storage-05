from .core import TileSpec, WSIData
