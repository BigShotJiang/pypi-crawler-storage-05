# 自动生成excel数据模型

## 安装
### pip install pypi_zc_tools

## 使用方法
### # 生成默认的20行数据
### pypi-zc-tools

### # 生成指定数量的数据
### pypi-zc-tools --count 50

### # 指定输出文件名
### pypi-zc-tools --output my_data.xlsx --count 100
