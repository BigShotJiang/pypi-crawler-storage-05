import math

class Trigonometry:
    @staticmethod
    def sin(a):
        return math.sin(a)

    @staticmethod
    def cos(a):
        return math.cos(a)

    @staticmethod
    def tan(a):
        return math.tan(a)

    @staticmethod
    def asin(a):
        return math.asin(a)

    @staticmethod
    def acos(a):
        return math.acos(a)

    @staticmethod
    def atan(a):
        return math.atan(a)