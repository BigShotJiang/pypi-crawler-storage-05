from .eq2 import Eq2
from .eq4 import Eq4
from .trigonometry import Trigonometry