# -*- coding: utf-8 -*-
# @Author  : zhousf
# @Function:

"""
pip install 'uvicorn[standard]'
"""