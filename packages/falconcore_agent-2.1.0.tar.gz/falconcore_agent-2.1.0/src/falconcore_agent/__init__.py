"""
FalconCore Security Agent - Enterprise Cybersecurity Threat Intelligence
"""

__version__ = "2.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .main import FalconCoreAgent

__all__ = ["FalconCoreAgent"]