# LlamaIndex Graph Stores Integration: Kuzu
