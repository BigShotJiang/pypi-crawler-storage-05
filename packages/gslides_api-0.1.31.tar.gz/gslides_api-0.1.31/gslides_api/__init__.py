from ._version import __version__, __version_info__
from .client import GoogleAPIClient, initialize_credentials
from .presentation import Presentation
from .page.slide import Slide
