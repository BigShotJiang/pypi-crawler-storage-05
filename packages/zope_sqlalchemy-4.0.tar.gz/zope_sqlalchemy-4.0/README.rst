|Build status|_

.. |Build status| image:: https://github.com/zopefoundation/zope.sqlalchemy/actions/workflows/tests.yml/badge.svg
.. _Build status: https://github.com/zopefoundation/zope.sqlalchemy/actions/workflows/tests.yml


See src/zope/sqlalchemy/README.rst
