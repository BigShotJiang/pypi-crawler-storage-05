class CanceledError(Exception):
    """
    This exception is raised when the user cancels an operation.
    """

    pass
