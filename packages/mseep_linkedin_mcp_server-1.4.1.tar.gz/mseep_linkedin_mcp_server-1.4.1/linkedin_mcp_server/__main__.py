#!/usr/bin/env python3
"""Entry point for linkedin-mcp-server command."""

from linkedin_mcp_server.cli_main import main

if __name__ == "__main__":
    main()
