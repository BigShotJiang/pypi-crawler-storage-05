This module depends on:

* website_sale
* l10n_br_sale
* l10n_br_portal
