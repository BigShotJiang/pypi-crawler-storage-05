.. _cluster:

Cluster
-------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: ClusterClient
   :members: