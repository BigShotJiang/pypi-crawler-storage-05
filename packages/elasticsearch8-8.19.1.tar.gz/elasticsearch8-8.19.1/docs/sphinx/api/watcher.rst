.. _watcher:

Watcher
-------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: WatcherClient
   :members: