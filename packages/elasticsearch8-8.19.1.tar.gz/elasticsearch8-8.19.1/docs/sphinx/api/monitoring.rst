.. _monitoring:

Monitoring
----------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: MonitoringClient
   :members: