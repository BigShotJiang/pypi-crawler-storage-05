.. _logstash:

Logstash
--------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: LogstashClient
   :members: