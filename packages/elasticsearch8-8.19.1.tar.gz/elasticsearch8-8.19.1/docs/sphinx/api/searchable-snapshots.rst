.. _searchable-snapshots:

Searchable Snapshots
--------------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: SearchableSnapshotsClient
   :members: