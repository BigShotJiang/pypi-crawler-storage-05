from ._eigen_dq import quat
from ._eigen_dq import dualquat
from ._eigen_dq import expq, logq
