from django_bulk_triggers.handler import Trigger as TriggerClass
from django_bulk_triggers.manager import BulkTriggerManager

__all__ = ["BulkTriggerManager", "TriggerClass"]
