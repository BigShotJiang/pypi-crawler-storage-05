# LlamaIndex Multi-Modal-Llms Integration: Gemini
