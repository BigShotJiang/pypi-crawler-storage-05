from llama_index.multi_modal_llms.gemini.base import GeminiMultiModal

__all__ = ["GeminiMultiModal"]
