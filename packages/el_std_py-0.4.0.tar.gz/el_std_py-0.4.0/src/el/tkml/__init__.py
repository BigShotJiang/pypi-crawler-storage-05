"""
Tkinter Markup Language

A more developer-friendly way to define Tkinter
UI structures
"""