"""
ELEKTRON © 2025 - now
Written by melektron
www.elektron.work
26.07.25, 13:15
All rights reserved.

This source code is licensed under the Apache-2.0 license found in the
LICENSE file in the root directory of this source tree. 

"""

import el.nixos_ctk_font_fix
import customtkinter as ctk


#def test_experiment():
#    root = ctk.CTk()
#
#    btn = ctk.CTkButton(root, text="Hi", anchor="abc")
#    btn.pack()
#
#    root.mainloop()