Ao acessar um prospecto sera visualizado campos, formatações e validações nos campos CNPJ, CPF, e IE, e a formatação do endereço utilizados no brasil.
