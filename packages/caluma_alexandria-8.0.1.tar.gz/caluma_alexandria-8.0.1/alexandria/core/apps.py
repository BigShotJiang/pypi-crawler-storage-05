from django.apps import AppConfig


class DefaultConfig(AppConfig):
    name = "alexandria.core"
    label = "alexandria_core"
