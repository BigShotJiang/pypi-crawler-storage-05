
Changelog
---------

V1.0.1: Oxford, 
+++++++++++++++++++++++++++++++++

- Fixed program stop with ``regul=False``

V1.0.0: Oxford, 10 September 2025
+++++++++++++++++++++++++++++++++

- Created by Michele Cappellari.

