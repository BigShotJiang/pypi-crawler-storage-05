import { FuncNodesReactPlugin } from "./types";
declare const CURRENT_VERSION = "1.0.0";
export declare const upgradeFuncNodesReactPlugin: (plugin: FuncNodesReactPlugin) => FuncNodesReactPlugin<typeof CURRENT_VERSION>;
export {};
//# sourceMappingURL=upgrading.d.ts.map
