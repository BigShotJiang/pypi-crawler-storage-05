export interface ProgressState {
  message: string;
  status: string;
  progress: number;
  blocking: boolean;
}
