from plenum.common.did_method import DidMethod
from plenum.common.did_method import DidMethods

IndyDidMethod = DidMethod('indy', 'did:indy:')
DefaultDidMethods = DidMethods(IndyDidMethod)
