# Current network
NETWORK_NAME = None

# Disable stdout logging
enableStdOutLogging = False
