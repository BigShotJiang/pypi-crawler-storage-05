from django.test import TestCase


class SpireChildAppServiceTestCase(TestCase):
    def setUp(self):
        super().setUp()
