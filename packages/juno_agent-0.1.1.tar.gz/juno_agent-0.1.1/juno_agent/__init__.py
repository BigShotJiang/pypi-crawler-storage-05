"""juno-agent: A Python CLI tool for setting up AI coding environments."""

__version__ = "0.1.0"