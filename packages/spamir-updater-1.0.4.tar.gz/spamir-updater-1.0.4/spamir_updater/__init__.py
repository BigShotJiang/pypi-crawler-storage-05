"""
spamir-updater: Secure automatic update client for Python applications
"""

from .updater_client import UpdaterClient

__version__ = "1.0.3"
__all__ = ["UpdaterClient"]