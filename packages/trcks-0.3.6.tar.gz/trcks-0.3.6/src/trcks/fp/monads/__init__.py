"""Monadic functions for generic types."""

__docformat__ = "google"
