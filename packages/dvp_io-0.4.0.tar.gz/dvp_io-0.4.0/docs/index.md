```{include} ../README.md

```

```{toctree}
:hidden: true
:maxdepth: 1

api.md
tutorials.md
faq.md
changelog.md
contributing.md
references.md
```
