.. include:: ../../CITATION.rst
