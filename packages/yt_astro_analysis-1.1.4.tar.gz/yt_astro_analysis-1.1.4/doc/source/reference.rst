.. _reference:

Reference
=========

Below are reference materials for the yt_astro_analysis package,
including API documentation for all available functionality and
a log of changes from each stable release.

.. toctree::
   :maxdepth: 2

   api_reference
   changelog
