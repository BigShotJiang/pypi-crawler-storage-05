Creating Position-Position-Velocity FITS Cubes
----------------------------------------------

For an example of this functionality, see this
`sample notebook <https://github.com/yt-project/yt_astro_analysis/blob/master/doc/source/PPVCube.ipynb>`__
