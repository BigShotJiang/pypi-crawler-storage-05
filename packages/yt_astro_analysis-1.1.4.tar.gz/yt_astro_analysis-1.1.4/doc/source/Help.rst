.. _help:

Help
====

If you encounter problems, we want to help and there are lots
of places to get help.  As an extension of `the yt project
<http://yt-project.org/>`_, we are members of the yt community.
Any questions regarding ytree can be posted to the `yt users list
<http://lists.spacepope.org/listinfo.cgi/yt-users-spacepope.org>`_.
You will also find interactive help on the `yt slack channel
<http://yt-project.org/docs/dev/help/index.html#go-on-slack-or-irc-to-ask-a-question>`__.
