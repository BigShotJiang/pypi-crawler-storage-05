Please contribute to the yt_astro_analysis package!

This package is part of the yt project and we really want your help.
For a guide to getting involved, see the yt developer guide at
http://yt-project.org/doc/developing/.
