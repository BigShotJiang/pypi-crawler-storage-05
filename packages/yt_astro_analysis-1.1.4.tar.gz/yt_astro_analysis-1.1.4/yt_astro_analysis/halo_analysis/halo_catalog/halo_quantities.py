"""
HaloCatalog quantities



"""
