from .bulk import Bulk
from .cluster import Cluster

struc_type = {'bulk': Bulk, 'cluster': Cluster}