operator_dict = {
    'generator': ['random_gen'],
    "mutation": ["strain_mut", "permutation_mut", "ripple_mut"],
	"crossover": ["plane_cross", 'cylinder_cross', 'sphere_cross']
}
