# 
#   Muna
#   Copyright © 2025 NatML Inc. All Rights Reserved.
#

from .prediction import PredictionService
from .remote import RemoteAcceleration