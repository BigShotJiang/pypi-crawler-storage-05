# streamlit-lexical-extended

Streamlit component that allows you to use Meta's [Lexical](https://lexical.dev/) as a rich text plugin. With tabbles and everything!

It is a spin off of [streamlit_lexical](https://github.com/alexander-dickson/streamlit_lexical).

## Installation instructions

```sh
pip install streamlit-lexical-extended
```
