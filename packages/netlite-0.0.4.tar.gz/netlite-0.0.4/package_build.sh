rm -rf dist
python -m build

