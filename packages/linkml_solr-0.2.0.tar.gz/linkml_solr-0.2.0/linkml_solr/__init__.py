from linkml_solr.query import SolrEndpoint, SolrQueryEngine

DEFAULT_CORE = 'test'
DEFAULT_SOLR_URL = 'http://localhost:8983/solr'
