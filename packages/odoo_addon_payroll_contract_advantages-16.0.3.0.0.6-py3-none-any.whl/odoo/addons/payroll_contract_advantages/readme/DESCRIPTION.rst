This module adds support for advantages templates and advantages to be set in contract form.
The advantages can be set in the contract form as a list of advantages templates.
Then it can be used in the calculation of the salary rules.
