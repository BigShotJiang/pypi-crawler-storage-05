Los códigos de impuestos incluidos en el Libro de IVA pueden verse en:
Contabilidad -\> Configuración -\> AEAT -\> Mapeo AEAT libro de IVA
