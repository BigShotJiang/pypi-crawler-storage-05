Para instalar este modulo necesitas:

- l10n_es_igic
- l10n_es_vat_book

Se instalan automáticamente si están disponibles en la lista de addons.
