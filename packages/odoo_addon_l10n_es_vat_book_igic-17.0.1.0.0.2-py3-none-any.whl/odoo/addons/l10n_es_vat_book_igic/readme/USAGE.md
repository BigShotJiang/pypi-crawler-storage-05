Para crear un libro de IVA con los impuestos canarios se debe añadir la
*Agencia Tributaria Canaria* en el campo *tax_agency_id* del libro.
