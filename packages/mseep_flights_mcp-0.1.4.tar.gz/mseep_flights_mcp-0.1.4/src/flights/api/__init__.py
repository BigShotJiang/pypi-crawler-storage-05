"""Duffel API client package."""

from .client import DuffelClient

__all__ = ['DuffelClient'] 