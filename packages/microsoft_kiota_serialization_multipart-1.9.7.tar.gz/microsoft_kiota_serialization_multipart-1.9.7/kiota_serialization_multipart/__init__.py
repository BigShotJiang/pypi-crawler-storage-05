"""
Implementation of Kiota Serialization Interfaces for Multipart serialization
"""
from ._version import VERSION

__version__ = VERSION
