curl -fsSL https://d2lang.com/install.sh | sh -s --
sudo apt-get install -y libxcb-cursor-dev