﻿edaflow.ml.plot\_roc\_curves
============================

.. currentmodule:: edaflow.ml

.. autofunction:: plot_roc_curves