﻿edaflow.ml.plot\_confusion\_matrix
==================================

.. currentmodule:: edaflow.ml

.. autofunction:: plot_confusion_matrix