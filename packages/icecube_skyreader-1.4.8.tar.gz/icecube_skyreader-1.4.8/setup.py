"""Setup."""

from setuptools import setup  # type: ignore[import]

setup()
