from squyrrel.core.context import Context


class CmdContext(Context):

    def build(self, squyrrel):
        pass