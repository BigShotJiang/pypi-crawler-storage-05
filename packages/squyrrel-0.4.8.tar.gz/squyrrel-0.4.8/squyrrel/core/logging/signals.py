from squyrrel.core.signals import Signal

error_signal = Signal('error_signal')
debug_signal = Signal('debug_signal')