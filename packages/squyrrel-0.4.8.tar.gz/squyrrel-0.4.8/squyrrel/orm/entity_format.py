from enum import Enum


class EntityFormat(Enum):
    MODEL = 'Model'
    JSON = 'Json'
