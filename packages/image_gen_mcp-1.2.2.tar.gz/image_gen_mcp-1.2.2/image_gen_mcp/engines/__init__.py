from __future__ import annotations

from .factory import ModelFactory

__all__ = ["ModelFactory"]
