This module was developed because there is no possibility to assign vehicles in Carriers or Transfers and propagate them to the Batches and Waves.

This is useful if you want to be able to propagate Vehicles or Drivers from the Sale to the Batch and change it when you want.
