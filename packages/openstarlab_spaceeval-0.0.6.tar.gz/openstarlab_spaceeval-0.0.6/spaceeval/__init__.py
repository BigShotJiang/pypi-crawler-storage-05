from .sports.main_class import Space_Model

__all__ = ['Space_Model']
#oohh j'ai changé le nom