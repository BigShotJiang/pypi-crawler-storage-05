#include <stdio.h>

int say(char *s)
{
    printf("%s", s);
    return 0;
}
