#include <stdio.h>
#include "common.h"

void
print_something(const char *s)
{
    printf("%s\n", s);
}
