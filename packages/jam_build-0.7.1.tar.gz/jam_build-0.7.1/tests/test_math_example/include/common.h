void print_something(const char *);
