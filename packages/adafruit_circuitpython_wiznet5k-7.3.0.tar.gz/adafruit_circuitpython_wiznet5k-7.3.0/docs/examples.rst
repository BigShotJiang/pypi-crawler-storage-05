Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/wiznet5k_simpletest.py
    :caption: examples/wiznet5k_simpletest.py
    :linenos:
