"""Parsers for workflows dervied from schema-salad descriptions and codegen.

Python files in this package probably shouldn't be modified manually. See
build_schema.sh for more information.
"""
