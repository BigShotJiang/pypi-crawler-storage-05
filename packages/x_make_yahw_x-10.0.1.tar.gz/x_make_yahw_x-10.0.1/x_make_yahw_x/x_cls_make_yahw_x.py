class x_cls_make_yahw_x:
    def __init__(self) -> None:
        pass

    def run(self) -> str:
        return "Hello world!"


def main() -> str:
    return x_cls_make_yahw_x().run()


if __name__ == "__main__":
    print(main())
