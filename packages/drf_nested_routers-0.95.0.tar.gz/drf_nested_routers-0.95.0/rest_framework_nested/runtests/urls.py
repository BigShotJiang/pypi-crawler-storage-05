"""
Blank URLConf just to keep runtests.py happy.
"""
from rest_framework.compat import patterns  # type: ignore[attr-defined]

urlpatterns = patterns('',)
