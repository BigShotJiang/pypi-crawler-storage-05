from mcp_ynab import main

main()
