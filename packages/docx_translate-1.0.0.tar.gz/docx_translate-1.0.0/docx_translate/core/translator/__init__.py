from .google import GoogleTranslator
