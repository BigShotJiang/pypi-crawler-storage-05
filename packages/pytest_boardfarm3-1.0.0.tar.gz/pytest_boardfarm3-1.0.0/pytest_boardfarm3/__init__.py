"""Integrate boardfarm as a pytest plugin."""

__version__ = "1.0.0"

__pypi_url__ = "https://github.com/lgirdk/pytest-boardfarm"
