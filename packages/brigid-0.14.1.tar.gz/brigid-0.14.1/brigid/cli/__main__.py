from brigid.cli.application import app  # noqa: F401
from brigid.cli.commands import configs  # noqa: F401
from brigid.cli.commands import static  # noqa: F401
from brigid.cli.commands import templates  # noqa: F401
from brigid.cli.commands import validate  # noqa: F401

app()
