.. contents::

.. _emissions:

*********
emissions
*********

This module consists of code that computes Scope 2 emissions given an electricity consumption profile.

.. automodule:: eeco.emissions
   :members: