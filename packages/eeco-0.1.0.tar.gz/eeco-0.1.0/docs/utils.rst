.. contents::

.. _utils:

*****
utils
*****

This module consists of helpful utility functions

.. automodule:: eeco.utils
   :members: