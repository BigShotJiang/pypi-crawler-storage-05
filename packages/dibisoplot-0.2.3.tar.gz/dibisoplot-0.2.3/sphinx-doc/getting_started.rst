Getting started
===============

This Documentation covers the usage of the Python library ``dibisoplot``.

TODO
