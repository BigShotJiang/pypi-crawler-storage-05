"""
Entry point for python -m mcp_server_tester
"""

from .cli import main

if __name__ == "__main__":
    main()
