# lab2mod167128850

`lab2mod167128850` is a lightweight Python package that provides simple utility functions
for **fixed_point_iteration**, **false_position**
It is designed mainly for learning purposes and as an example of Python packaging.

---

## Features


---

## Installation

You can install the package directly from PyPI:

```bash
pip install lab2mod167128850