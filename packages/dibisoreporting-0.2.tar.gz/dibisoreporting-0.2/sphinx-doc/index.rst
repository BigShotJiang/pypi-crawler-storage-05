.. mdinclude:: ../README.md

Table of contents
=================

.. toctree::
   :maxdepth: 2
   :titlesonly:

   getting_started
   examples
   settings
   reference/index
   development