## cdf 

### Fixed

- When deploying streamlit apps that has been dumped with Toolkit, then
entrypoint for the app is now correctly set.

## templates

No changes.