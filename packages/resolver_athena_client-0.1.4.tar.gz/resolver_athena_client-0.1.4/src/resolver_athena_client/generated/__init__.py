"""Library methods for Athena Client."""
