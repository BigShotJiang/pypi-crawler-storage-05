"""Django Prosemirror application configuration."""

from django.apps import AppConfig


class DjangoProsemirrorConfig(AppConfig):
    """Configuration for the Django Prosemirror application."""

    name = "django_prosemirror"
