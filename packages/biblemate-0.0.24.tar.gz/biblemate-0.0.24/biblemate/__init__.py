AGENTMAKE_CONFIG = {
    "print_on_terminal": False,
    "word_wrap": False,
}