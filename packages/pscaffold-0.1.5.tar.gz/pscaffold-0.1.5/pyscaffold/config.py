from pathlib import Path


BASE_CONFIG_PATH = Path(__file__).parent
