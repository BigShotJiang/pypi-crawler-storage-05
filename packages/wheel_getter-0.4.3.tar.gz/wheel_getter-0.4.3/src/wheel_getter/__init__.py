from importlib.metadata import version

VERSION = version("wheel-getter")
