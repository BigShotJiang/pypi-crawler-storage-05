Integração com o Backend para emissão de NCF-e.
