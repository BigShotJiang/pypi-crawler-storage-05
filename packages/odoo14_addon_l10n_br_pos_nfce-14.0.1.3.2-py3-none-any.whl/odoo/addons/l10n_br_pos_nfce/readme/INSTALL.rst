Esse módulo depende:

* l10n_br_pos

Alem disso você vai precisar configurar o Backend para emitir NFC-e.
