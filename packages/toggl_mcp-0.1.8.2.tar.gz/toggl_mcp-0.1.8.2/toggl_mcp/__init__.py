"""Toggl MCP Server - A Model Context Protocol server for Toggl API integration"""

__version__ = "0.1.5"
