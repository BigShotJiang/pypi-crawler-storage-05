"""Test suite for toggl-mcp"""
