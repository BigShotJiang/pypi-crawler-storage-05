"""
A2A Memory Test Suite

Comprehensive test suite for A2A task memory system
testing serialization, lifecycle, concurrency, and reliability.
"""
