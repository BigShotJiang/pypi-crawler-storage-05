version = '1.4.2'
repo = 'https://github.com/makodevai/gpuq'
commit = 'cb0f26c145115e726dfa022d761d7503c0a76586 (+2 untracked)'
has_repo = True
