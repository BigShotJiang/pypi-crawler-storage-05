.. image:: https://img.shields.io/pypi/l/tariochbctools.svg
   :target: https://pypi.python.org/pypi/tariochbctools
.. image:: https://img.shields.io/pypi/v/tariochbctools.svg
   :target: https://pypi.python.org/pypi/tariochbctools
.. image:: https://readthedocs.org/projects/tariochbctools/badge
   :target: https://tariochbctools.rtfd.io

tariochbctools
==============


Some importers, plugins and price fetchers for the double-entry bookkeeping software `Beancount <https://beancount.github.io/>`__.

See the detailed `Documentation <https://tariochbctools.rtfd.io/>`__.
