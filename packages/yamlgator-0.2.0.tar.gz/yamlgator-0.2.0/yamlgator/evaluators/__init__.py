class DEBUG:
    StateEvaluator = False
    TreeState = False
    AggregateState = False
    DAggregateState = False
    Observable = False
