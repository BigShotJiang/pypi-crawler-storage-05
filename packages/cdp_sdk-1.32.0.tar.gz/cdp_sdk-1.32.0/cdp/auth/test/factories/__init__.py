"""Test factories for the auth package."""
