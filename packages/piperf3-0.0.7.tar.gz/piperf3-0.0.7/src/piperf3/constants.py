STDOUT_FILENAME = "stdout.txt"
STDERR_FILENAME = "stderr.txt"
JSON_RESULTS_FILENAME = "results.json"
METADATA_FILENAME = "metadata.json"
