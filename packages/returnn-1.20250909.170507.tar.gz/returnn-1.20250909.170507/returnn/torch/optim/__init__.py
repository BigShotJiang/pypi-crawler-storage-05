"""
Any custom optimizer
"""
