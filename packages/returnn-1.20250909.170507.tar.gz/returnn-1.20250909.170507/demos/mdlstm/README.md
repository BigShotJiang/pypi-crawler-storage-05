Please note that the mdlstm demos require the Theano backend, which was removed in the past.

The latest commit to run this demo is 23cc84aa2b389737aa15e8a84c88c475bfd007a1

See also: https://github.com/rwth-i6/returnn/issues/593
