## Dataset processed and reshared for testing purposes:

X0A v3.0 Xenium Prime 5K Mouse Pan Tissue & Pathways Panel CG000760	Nuclear expansion (5 µm) Dataset<br>
by 10x Genomics, Inc., licensed under CC BY (https://cf.10xgenomics.com/samples/xenium/3.0.0/Xenium_Prime_Mouse_Ileum_tiny/Xenium_Prime_Mouse_Ileum_tiny_outs.zip).
