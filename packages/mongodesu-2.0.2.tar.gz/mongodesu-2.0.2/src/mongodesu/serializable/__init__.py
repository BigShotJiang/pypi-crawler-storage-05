from .serializable import Serializable

__all__ = ["Serializable"]