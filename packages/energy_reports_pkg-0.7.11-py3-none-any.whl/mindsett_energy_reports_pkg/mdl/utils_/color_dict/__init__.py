
color_dict = {"tomato": '#FF836A',
      "aquablue": '#6DC2B3',
      "peach": '#FED6D2',
      "darkgrey": '#9F9D9C',
      "potato": '#FEF8C8',
      "cyan": '#B6E4E1',
     "Mindsett Blue": '#132F57',
     "Black": '#000000',
     "Mindsett Grey":'#b3b3b3',
     "White": '#ffffff',
     "Mindsett Green": '#00A19A',
     "Mindsett Red":'#E6354C'}