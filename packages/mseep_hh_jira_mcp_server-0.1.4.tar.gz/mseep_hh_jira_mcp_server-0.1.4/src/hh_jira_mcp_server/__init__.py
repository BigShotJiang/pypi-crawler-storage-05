from hh_jira_mcp_server.server import mcp


def main():
    mcp.run()
