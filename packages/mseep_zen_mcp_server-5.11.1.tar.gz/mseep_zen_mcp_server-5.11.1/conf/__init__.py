"""Configuration data for Zen MCP Server."""
