.. _cli_reference:

CLI Reference
=============

.. typer:: soar_sdk.cli.cli.app
    :prog: soarapps
    :width: 80
    :preferred: text
    :show-nested:
    :make-sections:
