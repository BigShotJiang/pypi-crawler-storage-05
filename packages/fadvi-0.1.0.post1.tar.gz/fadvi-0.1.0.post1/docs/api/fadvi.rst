FADVI Module
============

.. automodule:: fadvi
   :members:
   :undoc-members:
   :show-inheritance:

Main Interface
--------------

.. autoclass:: fadvi.FADVI
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
