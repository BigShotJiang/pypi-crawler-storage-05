ENVIO_LOTE_RPS = ["NFeLoteEnviarArquivo"]

CONSULTAR_SITUACAO_LOTE_RPS = ["NFeLoteStatusArquivo"]

CONSULTAR_NFSE_POR_RPS = ["NFeLoteListarArquivos"]
