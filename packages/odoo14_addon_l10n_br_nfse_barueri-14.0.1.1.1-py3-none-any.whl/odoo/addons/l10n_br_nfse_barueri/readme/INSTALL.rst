* Este módulo tem uma depedencia do pacote python erpbrasil.edoc
* Este módulo tem uma depedencia do pacote python erpbrasil.assinatura
* Este módulo tem uma depedencia do pacote python erpbrasil.transmissao
* Este módulo tem uma depedencia do pacote python erpbrasil.base
* Este módulo tem uma depedencia do pacote python nfselib.barueri
