# Copyright 2014 Davide Corio
# Copyright 2015-2016 Lorenzo Battistini - Agile Business Group

from . import attachment
from . import account
from . import company
from . import partner
