When you receive a check that pays a customer invoice, you can go to
that invoice and click on the button *Pay* and select the
*Checks Received* journal as *Journal*.

When you want to deposit checks to the bank, go to the menu *Invoicing
\> Customers \> Checks Deposits*, create a new check deposit and set the
journal *Checks Received* and select the bank account on which you want
to credit the checks.

Then click on the button *Get All Received Checks* if you want to
deposit all the waiting received checks, or select the checks one by one
by clicking on *Add a line*.

Eventually, validate the deposit and print the report (you probably want
to customize this report).
