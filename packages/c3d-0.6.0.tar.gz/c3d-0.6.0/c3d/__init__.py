
from .c3d import Reader, Writer, DataTypes, Param, Group, PROCESSOR_INTEL, PROCESSOR_MIPS, PROCESSOR_DEC

__all__ = ["Reader", "Writer", "DataTypes", "Param", "Group", "PROCESSOR_INTEL", "PROCESSOR_MIPS", "PROCESSOR_DEC"]

__version__ = "0.6.0"
