#. Acesse  Configurações
#. Escolha um provedor para a busca
#. Acesse Configurações > Usuários e Empresas > Empresas > Criar ou acesse Contatos > Criar
#. Preencha os campos obrigatórios, insira no campo de CNPJ o CNPJ que deseja buscar e clique na lupa ao lado do campo para buscar
#. O mesmo procedimento pode ser feito editando alguma empresa.
