from gftools.builder import main
import yaml
import subprocess


if __name__ == "__main__":
    main()
