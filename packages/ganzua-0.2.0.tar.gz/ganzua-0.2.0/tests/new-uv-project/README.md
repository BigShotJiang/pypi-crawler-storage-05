a project with newer dependency using uv
