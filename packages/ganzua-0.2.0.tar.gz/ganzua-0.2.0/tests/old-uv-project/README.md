a project with an old dependency using uv
