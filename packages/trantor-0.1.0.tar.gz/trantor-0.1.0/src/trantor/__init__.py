def main() -> None:
    print("Hello from trantor!")
