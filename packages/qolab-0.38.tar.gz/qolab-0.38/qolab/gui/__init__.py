"""GUI Assisting package."""
