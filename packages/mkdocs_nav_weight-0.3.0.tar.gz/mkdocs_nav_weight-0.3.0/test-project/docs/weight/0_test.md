---
title: Weight Test Undefined(0)
---

filename: 0_test

"weight" undefined, goes to default value (0 or *default_page_weight* in mkdocs.yml config)
