---
title: Weight(-1)
weight: -1
retitled: true
---

**self weight: -10 (index_weight)**

folder name: "weight"

retitled: true
