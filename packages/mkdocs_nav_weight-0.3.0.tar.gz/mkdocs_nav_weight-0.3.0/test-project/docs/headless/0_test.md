---
title: Headless Test Undefined(0)
---

filename: 0_test

"weight" undefined, goes 0