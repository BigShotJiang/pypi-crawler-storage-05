---
title: Headless Section
retitled: true
headless: true
---

**All children of this headless section should been connected, see "Next" button.**

retitled: true

headless: true