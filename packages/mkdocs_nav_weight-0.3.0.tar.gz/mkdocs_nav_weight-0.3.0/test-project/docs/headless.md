---
title: Headless Page
headless: true
---

### A single headless page, should have no previous/next page