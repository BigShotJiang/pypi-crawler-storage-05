Examples
========

.. toctree::
   :maxdepth: 1

   gwtc3
   timing
   astropy_comparisons
   integral_comparisons