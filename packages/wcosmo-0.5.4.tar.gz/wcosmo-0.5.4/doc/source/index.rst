.. include:: ../../README.rst

.. toctree::
   :hidden:

   Examples <examples/index>
   API <api/index>
   Changelog <https://github.com/ColmTalbot/wcosmo/releases>
