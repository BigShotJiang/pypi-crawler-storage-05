`wcosmo.astropy`
================

.. currentmodule:: wcosmo.astropy

.. automodule:: wcosmo.astropy

.. autosummary::
    :toctree: _autosummary

    FlatLambdaCDM
    FlatwCDM
    WCosmoMixin
