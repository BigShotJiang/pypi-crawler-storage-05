`wcosmo.taylor`
===============

.. currentmodule:: wcosmo.taylor

.. automodule:: wcosmo.taylor

.. autosummary::
    :toctree: _autosummary

    flat_wcdm_pade_coefficients
    flat_wcdm_taylor_expansion
    indefinite_integral_pade
