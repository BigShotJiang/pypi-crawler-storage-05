from bbot.modules.base import BaseModule


class BaseReportModule(BaseModule):
    _stats_exclude = True
