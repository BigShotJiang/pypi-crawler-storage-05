"""Tests"""

from pdfdol.tests.utils_for_testing import get_test_pdf_folder
