"""Examples using pdfdol"""

from pdfdol.examples.aggregations import (
    images_to_pdf,
)  # make a pdf with images (and optionally, captions)
