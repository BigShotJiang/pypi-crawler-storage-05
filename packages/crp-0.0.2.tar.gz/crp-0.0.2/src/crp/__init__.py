"""crp: Tools for cropping images."""

__version__ = "0.0.2"
