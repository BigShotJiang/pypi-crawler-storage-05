def format_logging():
    from certiscan_commands_helpers.logging_struct import run
    run()
