"""
required to bootstrap testing
"""
SECRET_KEY = "required to bootstrap testing"
ENCRYPTED_MODEL_FIELDS = None