

# installing DevWorksDjangoLib
pip install -e ../DevWorksDjangoLib

# uninstalling DevWorksDjangoLib
pip uninstall devworksdjangolib


# add to your `requirements.txt`:
```
-e git+https://github.com/SamCzarski/DevWorksDjangoLib.git@9c7b21a58ebdfcdd89acb272a1678448358651a8#egg=DevWorksDjangoLib
```
or
```
devworksdjangolib==0.0.1
```


