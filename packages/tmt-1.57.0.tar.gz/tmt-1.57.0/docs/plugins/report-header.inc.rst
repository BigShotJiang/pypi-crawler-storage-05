Report test results according to user preferences.
