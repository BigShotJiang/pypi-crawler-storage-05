The ``prepare`` step is used to define how the guest
environment should be prepared so that the tests can be
successfully executed.
