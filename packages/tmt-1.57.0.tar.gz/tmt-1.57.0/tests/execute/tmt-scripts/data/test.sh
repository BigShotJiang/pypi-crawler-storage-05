ls $PATHS
echo "PATH=$PATH"
