#!/bin/bash -e

test "$(whoami)" == "root"
