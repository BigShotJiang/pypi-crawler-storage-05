#!/bin/sh -eux

ls -al /
