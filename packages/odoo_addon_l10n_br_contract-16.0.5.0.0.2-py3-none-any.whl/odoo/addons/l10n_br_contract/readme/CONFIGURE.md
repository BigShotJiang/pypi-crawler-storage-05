No additional configuration is required to use this module
