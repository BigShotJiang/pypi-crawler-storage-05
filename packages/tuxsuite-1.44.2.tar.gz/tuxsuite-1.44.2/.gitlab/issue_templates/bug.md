## Summary

(Summarize the bug you encountered concisely)

## Environment

* Operating System (`lsb_release -ds`):
* Python version (`python3 --version`):
* TuxSuite CLI version (`tuxsuite --version`):

## Steps to reproduce

(How one can reproduce the issue - this is very important. Include command line
parameters, any configuration bits that you think are relevant to the issue. Do
not share password, tokens and similar data)
