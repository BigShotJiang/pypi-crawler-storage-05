class Config:
    """
    Define config
    """
    LOG_PATH = None
