"""Ampio Output Registry.

Outputs are used to emit CAN frames or decoded messages.
Currently supported outputs:
- StdoutOutput: Emit to standard output
"""
