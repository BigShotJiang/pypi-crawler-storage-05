"""Ampio Codec Registry."""
