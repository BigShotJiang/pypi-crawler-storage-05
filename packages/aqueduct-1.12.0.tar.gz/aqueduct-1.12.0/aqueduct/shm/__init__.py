from .mixin import SharedFieldsMixin

__all__ = ['SharedFieldsMixin']
