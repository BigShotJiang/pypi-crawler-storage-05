import pytest


pytest_plugins = 'aiohttp.pytest_plugin'
