Esta busca de informações a partir do cnpj é realizada com base no
provedor SINTEGRA com o token da conta do usuário no site da API
configurado na aba de configurações ou com o WebService do SEFAZ ao
marcar a opção correspondente e configurando o certificado da empresa,
vale ressaltar que o provedor SINTEGRA é pago, enquanto que o SEFAZ é
gratuito.
