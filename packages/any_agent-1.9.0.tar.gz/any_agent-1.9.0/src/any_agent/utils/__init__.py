"""Utility functions for any-agent."""
