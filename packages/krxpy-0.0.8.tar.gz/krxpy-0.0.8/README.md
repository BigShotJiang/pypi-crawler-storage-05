# [data.krx.co.kr](http://data.krx.co.kr/contents/MDC/MAIN/main/index.cmd) 데이터 수집기 함수
> 증권거래소 정보데이터 시스템
[![License](http://img.shields.io/badge/license-MIT-brightgreen.svg?style=flat)](LICENSE)
[![Docs](https://img.shields.io/badge/docs-stable-blue.svg)](https://domschl.github.io/ml-indie-tools/index.html)
[![PyPI version fury.io](https://badge.fury.io/py/ml-indie-tools.svg)](https://pypi.python.org/pypi/ml-indie-tools/)


- PyKRX 와는 독립된 금융데이터 수집기 함수


## Version
0.0.1 - datetime object & string Integration management in Python

© 2024 GitHub : https://github.com/YongBeomKim
