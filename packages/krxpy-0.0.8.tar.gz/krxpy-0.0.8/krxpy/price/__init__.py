from .daum  import get_price_daum
from .naver import get_price_naver