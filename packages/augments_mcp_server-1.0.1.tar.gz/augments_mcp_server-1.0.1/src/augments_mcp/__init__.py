"""Augments MCP Server - Framework documentation provider."""

__version__ = "0.1.0"

from .server import mcp

__all__ = ["mcp"]
