from ark_sdk_python.services.sia.secrets.vm.ark_sia_vm_secrets_service import ArkSIAVMSecretsService

__all__ = ['ArkSIAVMSecretsService']
