from ark_sdk_python.services.identity.common.ark_identity_base_service import ArkIdentityBaseService

__all__ = ['ArkIdentityBaseService']
