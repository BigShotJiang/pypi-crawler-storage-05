from ark_sdk_python.models.services.sia.db.ark_sia_db_base_generate_assets import ArkSIADBBaseGenerateAssets


class ArkSIADBProxyFullchainGenerateAssets(ArkSIADBBaseGenerateAssets):
    pass
