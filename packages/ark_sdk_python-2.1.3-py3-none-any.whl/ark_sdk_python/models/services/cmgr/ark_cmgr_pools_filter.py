from ark_sdk_python.models.services.cmgr.ark_cmgr_pools_common_filter import ArkCmgrPoolsCommonFilter


class ArkCmgrPoolsFilter(ArkCmgrPoolsCommonFilter):
    pass
