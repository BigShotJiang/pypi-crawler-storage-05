from ark_sdk_python.models import ArkModel


class ArkSSHConnectionData(ArkModel):
    pass
