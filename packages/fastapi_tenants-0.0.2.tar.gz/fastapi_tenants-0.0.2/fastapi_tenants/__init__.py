"""
MODULE: fastapi_tenants/__init__.py
"""

from .version import __version__

__all__ = ["__version__"]
