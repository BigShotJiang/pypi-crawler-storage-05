# Welcome to fastapi-tenants

🚀 A multi-tenancy solution for FastAPI:
- Database-per-tenant
- Schema-per-tenant
- Row-level tenancy
