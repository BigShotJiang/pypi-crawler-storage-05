/**
 * Return to profile
 */
returnProfile = function()
{
	window.location = '/dashboard/my-profile';
}