var acceptUserRequestUrl = "{% url 'core-admin:core_website_app_accept_user_request' %}";
var denyUserRequestUrl = "{% url 'core-admin:core_website_app_deny_user_request' %}";
var denyGetEmailTemplateUrl = "{% url 'core-admin:core_website_app_get_deny_email_template' %}";
