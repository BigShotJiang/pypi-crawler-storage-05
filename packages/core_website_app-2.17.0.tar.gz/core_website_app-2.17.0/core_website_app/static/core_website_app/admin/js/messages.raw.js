var removeMessageUrl = "{% url 'core-admin:core_website_app_remove_contact_message' %}";
