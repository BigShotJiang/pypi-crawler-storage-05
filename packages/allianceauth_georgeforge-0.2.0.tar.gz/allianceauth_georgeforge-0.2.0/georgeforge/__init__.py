"""Initialize the app"""

__version__ = "0.2.0"
__title__ = "George Forge"
