Countdown Module
================

.. automodule:: spacepackets.countdown
 :members:
 :undoc-members:
 :show-inheritance:
