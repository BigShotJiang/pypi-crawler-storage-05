Utility Module
================

.. automodule:: spacepackets.util
 :members:
 :undoc-members:
 :show-inheritance:
