CCSDS Time Package 
================================

.. automodule:: spacepackets.ccsds.time
   :members:
   :undoc-members:
   :show-inheritance:

Common Time Submodule
---------------------------------------

.. automodule:: spacepackets.ccsds.time.common
   :members:
   :undoc-members:
   :show-inheritance:

CDS Time Submodule
------------------------------------

.. automodule:: spacepackets.ccsds.time.cds
   :members:
   :undoc-members:
   :show-inheritance:
