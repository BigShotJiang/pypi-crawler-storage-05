"""This modules contains generic CRC support."""
