# TODO String interpolation.
# TODO Test rewind.
# TODO Test errors.