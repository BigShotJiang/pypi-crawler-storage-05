from .svgp_network_dag import SVGPNetworkDAG
from .svgp_network import SVGPNetwork

__all__ = ["SVGPNetwork", "SVGPNetworkDAG"]
