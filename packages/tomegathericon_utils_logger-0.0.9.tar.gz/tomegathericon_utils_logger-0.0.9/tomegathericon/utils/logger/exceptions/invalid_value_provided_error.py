from tomegathericon.utils.exceptions import DefaultValueError


class InvalidValueProvidedError(DefaultValueError):
    pass
