from tomegathericon.utils.exceptions import DefaultValueError


class PropertyNotFoundError(DefaultValueError):
    pass
