from tomegathericon.utils.exceptions import DefaultRuntimeError


class LoggerNotAvailableError(DefaultRuntimeError):
    pass
