pytblis package
===============

.. automodule:: pytblis
   :members:
   :show-inheritance:
   :undoc-members:

.. autofunction:: pytblis.add
.. autofunction:: pytblis.mult
.. autofunction:: pytblis.dot
.. autofunction:: pytblis.reduce
.. autofunction:: pytblis.shift
.. autofunction:: pytblis.get_num_threads
.. autofunction:: pytblis.set_num_threads
