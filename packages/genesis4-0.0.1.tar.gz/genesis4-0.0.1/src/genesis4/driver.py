

class Genesis4:
    def __init__(self, path: str):
        self.name = self.__class__.__name__
        self.path = path

    def run(self, inputs, lattices):
        pass
    