# Clesyde_Cloud_Lib

[![PyPI](https://img.shields.io/pypi/v/clesyde_cloud_lib.svg)][pypi_]
[![Status](https://img.shields.io/pypi/status/clesyde_cloud_lib.svg)][status]
[![Python Version](https://img.shields.io/pypi/pyversions/clesyde_cloud_lib)][python version]
[![License](https://img.shields.io/pypi/l/clesyde_cloud_lib)][license]

[![Read the documentation at https://clesyde_cloud_lib.readthedocs.io/](https://img.shields.io/readthedocs/clesyde_cloud_lib/latest.svg?label=Read%20the%20Docs)][read the docs]
[![Tests](https://github.com/fdewasmes/clesyde_cloud_lib/workflows/Tests/badge.svg)][tests]
[![Codecov](https://codecov.io/gh/fdewasmes/clesyde_cloud_lib/branch/main/graph/badge.svg)][codecov]

[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)][pre-commit]
[![Black](https://img.shields.io/badge/code%20style-black-000000.svg)][black]

[pypi_]: https://pypi.org/project/clesyde_cloud_lib/
[status]: https://pypi.org/project/clesyde_cloud_lib/
[python version]: https://pypi.org/project/clesyde_cloud_lib
[read the docs]: https://clesyde_cloud_lib.readthedocs.io/
[tests]: https://github.com/fdewasmes/clesyde_cloud_lib/actions?workflow=Tests
[codecov]: https://app.codecov.io/gh/fdewasmes/clesyde_cloud_lib
[pre-commit]: https://github.com/pre-commit/pre-commit
[black]: https://github.com/psf/black

## Features

- TODO

## Requirements

- TODO

## Installation

You can install _Clesyde_Cloud_Lib_ via [pip] from [PyPI]:

```console
$ pip install clesyde_cloud_lib
```

## Usage

Please see the [Command-line Reference] for details.

## Contributing

Contributions are very welcome.
To learn more, see the [Contributor Guide].

## License

Distributed under the terms of the [GPL 3.0 license][license],
_Clesyde_Cloud_Lib_ is free and open source software.

## Issues

If you encounter any problems,
please [file an issue] along with a detailed description.

## Credits

This project was generated from [@cjolowicz]'s [Hypermodern Python Cookiecutter] template.

[@cjolowicz]: https://github.com/cjolowicz
[pypi]: https://pypi.org/
[hypermodern python cookiecutter]: https://github.com/cjolowicz/cookiecutter-hypermodern-python
[file an issue]: https://github.com/fdewasmes/clesyde_cloud_lib/issues
[pip]: https://pip.pypa.io/

<!-- github-only -->

[license]: https://github.com/fdewasmes/clesyde_cloud_lib/blob/main/LICENSE
[contributor guide]: https://github.com/fdewasmes/clesyde_cloud_lib/blob/main/CONTRIBUTING.md
[command-line reference]: https://clesyde_cloud_lib.readthedocs.io/en/latest/usage.html
