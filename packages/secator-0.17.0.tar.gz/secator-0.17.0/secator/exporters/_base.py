class Exporter:
	def __init__(self, report):
		self.report = report
