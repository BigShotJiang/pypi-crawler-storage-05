tobiko.openstack.designate
--------------------------

.. automodule:: tobiko.openstack.designate
    :members:
    :imported-members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
