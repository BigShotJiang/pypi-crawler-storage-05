# This file makes 'stk_mcp' a Python package.
# We also export the server instance so tools can access it easily.
from .server import mcp_server 