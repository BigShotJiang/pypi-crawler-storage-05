# Changelog

## [0.3.0](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.2.0...v0.3.0) (2025-09-12)


### Features

* complete support for named environments ([#7](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/issues/7)) ([b38aecd](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/b38aecdc93e3058d219e2b7fe8bdfcee9d59a690))

## [0.2.0](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.1.0...v0.2.0) (2025-05-16)


### Features

* add pypi support via uv ([#2](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/issues/2)) ([728c71a](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/728c71a8d4d62334ddb516acb23c992b5bcb656e))
* support pinfiles ([#5](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/issues/5)) ([58faba4](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/58faba47e8bb782dea27427f8419e4e5b47a6b20))

## 0.1.0 (2025-03-08)


### Bug Fixes

* update to latest interface ([0159285](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/015928520a4d87bb545cd2c1ab21f45f36466738))
