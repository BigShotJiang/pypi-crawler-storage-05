
def main():
    from .tg import AdvioTG
    
   