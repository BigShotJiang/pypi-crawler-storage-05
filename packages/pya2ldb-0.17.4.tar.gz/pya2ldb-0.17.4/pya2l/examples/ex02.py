from pya2l import DB

db = DB()
session = db.open_create("ASAP2_Demo_V161")
