# Beginning Package

This is a simple package that implements avg of two numbers.
