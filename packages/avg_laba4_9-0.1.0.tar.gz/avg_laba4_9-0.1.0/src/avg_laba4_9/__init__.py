from .main import avg
