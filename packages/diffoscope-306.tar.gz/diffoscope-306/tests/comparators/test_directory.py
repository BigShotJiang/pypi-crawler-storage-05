#
# diffoscope: in-depth comparison of files, archives, and directories
#
# Copyright © 2015 Jérémy Bobbio <lunar@debian.org>
# Copyright © 2015-2020, 2022 Chris Lamb <lamby@debian.org>
#
# diffoscope is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# diffoscope is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with diffoscope.  If not, see <https://www.gnu.org/licenses/>.

import os
import shutil
import time

import pytest

from diffoscope.comparators.binary import FilesystemFile
from diffoscope.comparators.directory import compare_directories
from diffoscope.comparators.utils.compare import compare_root_paths
from diffoscope.comparators.utils.specialize import specialize
from diffoscope.config import Config

from ..utils.data import data, get_data, assert_diff


TEST_FILE1_PATH = data("text_ascii1")
TEST_FILE2_PATH = data("text_ascii2")


def test_no_differences():
    x = os.path.dirname(__file__)
    difference = compare_directories(x, x)
    assert difference is None


def test_no_differences_with_extra_slash():
    x = os.path.dirname(__file__)
    difference = compare_directories(x + "/", x)
    assert difference is None


@pytest.fixture
def differences(tmpdir):
    tmpdir.mkdir("a")
    tmpdir.mkdir("a/dir")
    tmpdir.mkdir("b")
    tmpdir.mkdir("b/dir")
    shutil.copy(TEST_FILE1_PATH, str(tmpdir.join("a/dir/text")))
    shutil.copy(TEST_FILE2_PATH, str(tmpdir.join("b/dir/text")))
    os.utime(str(tmpdir.join("a/dir/text")), (0, 0))
    os.utime(str(tmpdir.join("b/dir/text")), (0, 0))
    os.utime(str(tmpdir.join("a/dir")), (0, 0))
    os.utime(str(tmpdir.join("b/dir")), (0, 0))
    os.utime(str(tmpdir.join("a")), (0, 0))
    os.utime(str(tmpdir.join("b")), (0, 0))
    return compare_directories(
        str(tmpdir.join("a")), str(tmpdir.join("b"))
    ).details


def test_content(differences):
    assert "/dir" in differences[0].source1
    assert "/dir/text" in differences[0].details[0].source1
    expected_diff = get_data("text_ascii_expected_diff")
    assert differences[0].details[0].unified_diff == expected_diff


def test_stat(differences):
    assert "stat" in differences[0].details[0].details[0].source1


def test_compare_to_file(tmpdir):
    path = str(tmpdir.join("file"))

    with open(path, "w") as f:
        f.write("content")

    a = specialize(FilesystemFile(str(tmpdir.mkdir("dir"))))
    b = specialize(FilesystemFile(path))

    assert_diff(a.compare(b), "test_directory_file_diff")


def test_compare_to_device(tmpdir):
    a = specialize(FilesystemFile(str(tmpdir.mkdir("dir"))))
    b = specialize(FilesystemFile("/dev/null"))

    assert_diff(a.compare(b), "test_directory_device_diff")


def test_compare_to_symlink(tmpdir):
    path = str(tmpdir.join("src"))
    os.symlink("/etc/passwd", path)

    a = specialize(FilesystemFile(str(tmpdir.mkdir("dir"))))
    b = specialize(FilesystemFile(path))

    assert_diff(a.compare(b), "test_directory_symlink_diff")


def test_compare_to_dangling_symlink(tmpdir):
    path = str(tmpdir.join("src"))
    os.symlink("/dangling", path)

    a = specialize(FilesystemFile(str(tmpdir.mkdir("dir"))))
    b = specialize(FilesystemFile(path))

    assert_diff(a.compare(b), "test_directory_symlink_diff")


def test_compare_both_ways(tmpdir):
    """
    Comparing a directory with a file shouldn't crash, but nor should as
    comparing a file with a directory either. (Re: #292)
    """

    a = str(tmpdir)
    b = TEST_FILE1_PATH

    assert_diff(compare_root_paths(a, b), "test_directory_a_b_diff")
    assert_diff(compare_root_paths(b, a), "test_directory_b_a_diff")


def test_identical_files_different_mtime(monkeypatch, tmpdir):

    monkeypatch.setattr(Config(), "exclude_directory_metadata", "no")

    file1_path = str(tmpdir.join("file1"))
    file2_path = str(tmpdir.join("file2"))

    now = time.time()
    for path, t in ((file1_path, now - 3600), (file2_path, now)):
        with open(path, "w") as f:
            f.write("identical content")
        os.utime(path, (t, t))

    difference = compare_root_paths(file1_path, file2_path)
    assert difference is not None
