pub(crate) const NUMBER_TOKEN: &str = "$serde_json::private::Number";
