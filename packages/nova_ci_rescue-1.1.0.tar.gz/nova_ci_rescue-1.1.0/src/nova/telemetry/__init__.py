"""Telemetry package placeholder to satisfy imports during local runs."""

__all__ = [
    "logger",
]


