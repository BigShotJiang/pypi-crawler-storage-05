APPLICATION_NAME = "annofab-cli-llm"
