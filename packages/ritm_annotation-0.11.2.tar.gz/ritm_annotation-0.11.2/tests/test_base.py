from ritm_annotation.base import NAME


def test_base():
    assert NAME == "ritm_annotation"
