This folder holds utility functions for other componentes grouped by type being misc the fallback one
