"""Entry point for ritm_annotation."""

from ritm_annotation.cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()
