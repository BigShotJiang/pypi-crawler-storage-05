"""The main formatting algorithms."""
