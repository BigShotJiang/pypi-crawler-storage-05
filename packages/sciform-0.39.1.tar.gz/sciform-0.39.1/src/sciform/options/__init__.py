"""Code pertaining to sciform options handling."""
