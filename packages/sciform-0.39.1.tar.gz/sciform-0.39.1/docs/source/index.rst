.. module:: sciform

.. include:: ../../README.rst

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   usage
   options
   fsml
   exp replacement
   api
   examples
   project

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
