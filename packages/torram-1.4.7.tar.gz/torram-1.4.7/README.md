# torram
Machine Learning tools for PyTorch.

Torram (தோற்றம்) means source, such as this collection of tools being the foundation
for machine learning projects. 

### Installation
```
pip3 install torram
```
