Handle sale orders via EDI.

This is a base module to plug sales processes with the EDI framework.

To handle inbound/outbound sale orders, you need to use
edi_sale_input_oca or edi_sale_output_oca modules, or create your own
modules.
