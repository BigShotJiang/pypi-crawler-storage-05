"""Haunted - AI-powered development tool."""

__version__ = "0.1.0"

from .cli import cli


def main():
    """Main entry point."""
    cli()
