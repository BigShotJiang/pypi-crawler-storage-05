"""MCP (Model Context Protocol) tools for Haunted."""

from .tools import MCPToolHandler

__all__ = ["MCPToolHandler"]
