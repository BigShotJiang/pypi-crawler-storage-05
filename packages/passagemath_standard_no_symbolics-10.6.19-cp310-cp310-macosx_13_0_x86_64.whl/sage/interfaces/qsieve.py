from sage.misc.superseded import deprecated_function_alias
import sage.libs.flint.qsieve_sage

qsieve = deprecated_function_alias(1, sage.libs.flint.qsieve_sage.qsieve)
