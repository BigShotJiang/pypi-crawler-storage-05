from setuptools import setup, find_packages

setup(
    name="user-terminator",
    version="0.1.0",
    description="OAuth client wrapper for multi-tenant projects",
    author="bw_song",
    packages=find_packages(include=["user_terminator", "user_terminator.*"]),
    python_requires=">=3.8",
)
