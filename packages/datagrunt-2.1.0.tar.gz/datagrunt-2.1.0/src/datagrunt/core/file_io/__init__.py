"""Initializes the file_io module of the datagrunt package."""

from datagrunt.core.file_io.fileproperties import FileProperties

__all__ = [
    "FileProperties",
]
