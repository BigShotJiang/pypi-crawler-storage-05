"""KeyCard AI OAuth Utils"""
