"""Tests for keycardai.oauth.types module."""
