"""Tests for keycardai.oauth.utils module."""
