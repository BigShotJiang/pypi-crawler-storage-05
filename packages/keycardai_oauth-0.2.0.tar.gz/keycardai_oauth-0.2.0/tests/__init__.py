"""Tests for KeyCard AI STS SDK."""
