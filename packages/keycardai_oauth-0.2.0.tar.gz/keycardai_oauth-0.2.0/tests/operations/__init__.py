"""Unit tests for OAuth 2.0 operations."""
