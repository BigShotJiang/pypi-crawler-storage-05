Home
========

.. include:: ../README.rst
   :start-after: .. SPHINX-START
