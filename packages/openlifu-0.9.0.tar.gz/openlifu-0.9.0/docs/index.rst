Welcome to openlifu's documentation!
=========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   includeme
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
