from setuptools import setup, find_packages

setup(
    name="my_semantic_analyzer",
    version="0.1.0",
    description="A semantic analyzer package",
    author="Your Name",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.7",
)