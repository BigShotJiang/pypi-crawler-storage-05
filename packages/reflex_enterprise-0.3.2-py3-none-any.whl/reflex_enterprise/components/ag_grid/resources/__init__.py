"""This module contains the resources for the ag-grid component."""

from .column import ColumnDef, ColumnGroupDef

__all__ = ["ColumnDef", "ColumnGroupDef"]
