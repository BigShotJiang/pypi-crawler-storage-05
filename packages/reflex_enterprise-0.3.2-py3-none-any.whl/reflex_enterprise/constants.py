"""Constants for Reflex Enterprise."""

SHOW_BUILT_WITH_REFLEX_INFO = "https://reflex.dev/docs/hosting/reflex-branding/"
IS_OFFLINE = False
