from dbt.tests.adapter.simple_snapshot.test_ephemeral_snapshot_hard_deletes import (
    BaseSnapshotEphemeralHardDeletes,
)


class TestSnapshotEphemeralHardDeletes(BaseSnapshotEphemeralHardDeletes):
    pass
