from dbt.tests.adapter.incremental.test_incremental_on_schema_change import (
    BaseIncrementalOnSchemaChange,
)


class TestIncrementalOnSchemaChange(BaseIncrementalOnSchemaChange):
    pass
