"""
MCP Presentation Layer

This module contains the presentation layer for MCP functionality,
exposing FastMCP tools that use the service classes.
"""
