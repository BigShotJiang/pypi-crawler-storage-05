"""
Workflow processors module.
Contains all processor implementations for entity processing.
"""
