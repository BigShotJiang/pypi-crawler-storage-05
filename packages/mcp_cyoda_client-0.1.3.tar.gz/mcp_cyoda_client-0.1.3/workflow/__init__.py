"""
Workflow module for Cyoda entities.
Contains workflow processors and state management logic.
"""
