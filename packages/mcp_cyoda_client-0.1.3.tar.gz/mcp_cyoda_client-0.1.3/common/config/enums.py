from enum import Enum


class TextType(Enum):
    JSON = "json"
    PYTHON = "python"