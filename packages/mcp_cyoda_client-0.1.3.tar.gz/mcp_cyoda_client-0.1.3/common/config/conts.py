# Constants
INFO = "info"
PROCESSORS_STACK = "PROCESSORS"
ENTITY_STACK = "ENTITY"
WORKFLOW_STACK = "WORKFLOW"
API_REQUEST_STACK = "API_REQUEST"
EDGE_MESSAGE_CLASS = "net.cyoda.saas.message.model.EdgeMessage"
TREE_NODE_ENTITY_CLASS = "com.cyoda.tdb.model.treenode.TreeNodeEntity"
UPDATE_TRANSITION = "update_transition"