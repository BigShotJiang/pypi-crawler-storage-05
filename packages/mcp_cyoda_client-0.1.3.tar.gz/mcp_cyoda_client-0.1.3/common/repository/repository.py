from abc import ABC


class Repository(ABC):
    pass
