"""
Mail entity module.
"""

from .model import MailEntity

__all__ = ['MailEntity']
