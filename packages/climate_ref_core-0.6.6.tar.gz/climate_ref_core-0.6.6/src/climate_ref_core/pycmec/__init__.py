"""
CMEC python package
"""
