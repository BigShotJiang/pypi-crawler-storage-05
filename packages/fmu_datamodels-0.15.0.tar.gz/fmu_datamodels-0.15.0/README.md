# fmu-datamodels

FMU data standard, including models and schemas

## About

## Link to documentation

## Schemas

## License

This project is licensed under the terms of the [Apache
2.0](https://github.com/equinor/fmu-datamodels/blob/main/LICENSE) license.
