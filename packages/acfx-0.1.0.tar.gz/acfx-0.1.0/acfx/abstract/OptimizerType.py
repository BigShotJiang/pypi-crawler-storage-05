from enum import Enum

class OptimizerType(Enum):
    EBM = 1
    LinearAdditive = 2
    Custom = 3