# download xgb model from google drive
MODEL_FILE = "model_10_202405.ubj"
FILE_ID = "1O34gyQ67rvrP9VFkNaagTDM9IP4iqAjM"
