"""
LigtTools - Tools for converting and searching data between different formats and RDF specification.
"""
