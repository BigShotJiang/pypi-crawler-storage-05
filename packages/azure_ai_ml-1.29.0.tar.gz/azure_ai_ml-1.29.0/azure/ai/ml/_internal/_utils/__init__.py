# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._yaml_utils import yaml_safe_load_with_base_resolver

__all__ = ["yaml_safe_load_with_base_resolver"]
