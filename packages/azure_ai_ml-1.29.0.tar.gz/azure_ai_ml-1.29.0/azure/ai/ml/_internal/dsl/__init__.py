# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ...dsl._settings import set_pipeline_settings

__all__ = ["set_pipeline_settings"]
