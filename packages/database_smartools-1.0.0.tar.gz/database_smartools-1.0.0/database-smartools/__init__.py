# -*- coding: utf-8 -*-
"""
@项目名称 : yhfin-data-agent
@文件名称 : __init__.py.py
@创建人   : zhongbinjie
@创建时间 : 2025/9/9 17:02
@文件说明 : 
@企业名称 : 深圳市赢和信息技术有限公司
@Copyright:2025-2035, 深圳市赢和信息技术有限公司. All rights Reserved.
"""


def test():
    print()


if __name__ == '__main__':
    None
