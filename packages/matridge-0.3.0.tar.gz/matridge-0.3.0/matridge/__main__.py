# DO NOT EDIT
# Generated from .copier-answers.yml

from matridge import main

main()
