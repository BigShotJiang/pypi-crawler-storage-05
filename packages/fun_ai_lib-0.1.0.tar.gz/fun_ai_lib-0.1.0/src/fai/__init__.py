raise RuntimeError("⚠️ f-ai is a placeholder package. Not implemented yet.")
