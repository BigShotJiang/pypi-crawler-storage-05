#!/usr/bin/env python3
"""
Setup script for the Wikipedia MCP server.
"""

from setuptools import setup

# Use pyproject.toml for configuration
setup() 