![](https://travis-ci.com/AntelopeLCA/foreground.svg?branch=master) ![](https://coveralls.io/repos/github/AntelopeLCA/foreground/badge.svg?branch=master)

# foreground
An interface and implementation for building and analyzing foreground models
