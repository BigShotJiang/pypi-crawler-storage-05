class AntelopeV1Error(Exception):
    pass


