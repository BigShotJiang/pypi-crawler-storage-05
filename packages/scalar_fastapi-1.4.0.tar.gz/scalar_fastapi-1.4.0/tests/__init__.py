# Tests package for scalar-fastapi 
