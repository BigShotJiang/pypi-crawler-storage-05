# Auto processing of SISF files

In this folder, a demo of how a watchdog can be used to automatically convert SNDiF tiles into SISF chunks
so that near-real-time processing can be achieved