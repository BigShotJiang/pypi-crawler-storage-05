"""
A project template for the sdPy effort..
"""

__version__ = "0.3.0"
from .spectrum import Spectrum
from . import tools
