# easy-image-labeling
This is a lightweight Python application with a Flask-powered web interface that runs locally. It allows users to upload unlabeled image datasets and assign each image to custom-defined labels. The goal is to gradually build a structured, labeled dataset for use in machine learning or other data-driven tasks.
