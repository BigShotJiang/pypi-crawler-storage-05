class MissingSecretEnvFile(Exception):
    """Raise when a secret.env file is missing."""
    pass
