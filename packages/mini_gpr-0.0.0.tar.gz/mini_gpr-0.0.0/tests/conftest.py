import numpy as np

np.random.seed(0)
