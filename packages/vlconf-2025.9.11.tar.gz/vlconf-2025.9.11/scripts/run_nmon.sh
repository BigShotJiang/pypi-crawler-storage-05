#!/usr/bin/env

bash nmon.sh >> nmon.out 2>&1
