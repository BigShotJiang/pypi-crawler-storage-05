# ！/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Project: mcp-android
@File: __main__.py.py
@Author: chuanwen.peng
@Date: 2025/9/8 17:32
@Contact: chuanwen.peng@tcl.com
@Description:  
"""
from .server import run_server

if __name__ == "__main__":
    run_server()