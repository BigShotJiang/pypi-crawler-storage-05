from DashAI.back.dependencies.job_queues.base_job_queue import BaseJobQueue
from DashAI.back.dependencies.job_queues.simple_job_queue import SimpleJobQueue
