effidict
========

.. toctree::
   :maxdepth: 4

   effidict
