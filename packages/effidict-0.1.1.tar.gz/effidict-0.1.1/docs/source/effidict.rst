effidict package
================

Submodules
----------

effidict.db\_dict module
------------------------

.. automodule:: effidict.db_dict
   :members:
   :undoc-members:
   :show-inheritance:

effidict.lru\_dict module
-------------------------

.. automodule:: effidict.lru_dict
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: effidict
   :members:
   :undoc-members:
   :show-inheritance:
