This module adds brazilian fields, validations and tax calc to point of sale.
