Configurar aba POS do cadastro da empresa.

Configurar o Ponto de venda, prestando atenção nos seguintes campos:

  * A aba Geral, com os detalhes do documento fiscal simplificado e não simplificado;
  * A aba tributos, com os dados da tributação a ser utilizada, o o cliente anónimo para servir como referência, assim como seus campos de endereço.
  * Clicar no botão Update Tax no pos config ou no produto;
  * Validar que a tributação esta correta;

Configurar e instalar um dos módulos responsáveis pela transmissão do documento fiscal:

  * l10n_br_pos_cfe
  * l10n_br_pos_nfce
  * l10n_br_account_nfe (Somente para emissão de NF-e);
