14.0.1.0.0 (2011)
~~~~~~~~~~~~~~~~~

O módulo foi reestruturado para atender novos tipos de documentos fiscais: NFC-E / CF-e (SP e Ceará), PAF-ECF e DAF-EFC;

12.0.1.0.0 (2011)
~~~~~~~~~~~~~~~~~

A partir da versão 12.0 o módulo foi melhorado para atender um volume maior de transações com maoir confiabilidade e adequação ao modelo de dados atual da localização.


8.0.1.0.0 (2016)
~~~~~~~~~~~~~~~~

O módulo do ponto de venda foi criado para atender clientes do estado de São Paulo, com SAT.
