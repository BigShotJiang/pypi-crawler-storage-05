* `KMEE <https://www.kmee.com.br>`_:

  * Luis Felipe Miléo <mileo@kmee.com.br>
  * Gabriel Cardoso <gabriel.cardoso@kmee.com.br>
  * Daniel Sadamo <daniel.sadamo@kmee.com.br>
  * Luiz Felipe do Divino <luiz.divino@kmee.com.br>
  * Luis Otavio Malta Conceição <luis.malta@kmee.com.br>
  * Ygor Carvalho <ygor.carvalho@kmee.com.br>
