# © 2016 KMEE INFORMATICA LTDA (https://kmee.com.br)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import pos_order
from . import pos_order_line
from . import res_company
from . import pos_config
from . import cfop
from . import document_related
from . import stock
from . import res_partner
from . import l10n_br_pos_product_fiscal_map
from . import product_template
from . import mail_thread
from . import product_product
