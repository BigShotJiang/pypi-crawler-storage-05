from . import test_l10n_br_pos_order
from . import test_l10n_br_pos_config
from . import test_l10n_br_pos_product
from . import test_l10n_br_pos_partner
