module.exports = {
  serialize: null,
  deserialize: null,
}
