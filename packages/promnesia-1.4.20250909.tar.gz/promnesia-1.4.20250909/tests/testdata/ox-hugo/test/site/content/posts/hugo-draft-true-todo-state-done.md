+++
title = "HUGO_DRAFT true, DONE state (Override)"
date = 2018-07-09T10:38:00+00:00
tags = ["draft", "todo", "done", "override"]
draft = false
+++

This post has `EXPORT_HUGO_DRAFT` set to `"true"`. But the **DONE**
state of Org TODO overrides that.
