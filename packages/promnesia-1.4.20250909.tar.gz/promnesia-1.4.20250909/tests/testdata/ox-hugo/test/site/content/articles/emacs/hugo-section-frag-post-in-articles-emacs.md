+++
title = "Post with all HUGO_SECTION, HUGO_SECTION*, EXPORT_FILE_NAME in same subtree"
description = "Test post created in `articles/emacs`."
tags = ["section", "fragment", "concatenation", "deep-nesting"]
draft = false
+++
