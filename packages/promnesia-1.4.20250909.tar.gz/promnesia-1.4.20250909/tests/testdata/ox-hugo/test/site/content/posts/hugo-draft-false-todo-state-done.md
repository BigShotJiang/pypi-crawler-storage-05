+++
title = "HUGO_DRAFT false, DONE state"
tags = ["draft", "todo", "done"]
draft = false
+++

The **DONE** state of Org TODO sets `draft` to `false` for this post.
