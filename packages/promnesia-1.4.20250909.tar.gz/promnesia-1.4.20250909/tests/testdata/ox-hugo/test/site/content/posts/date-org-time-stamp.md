+++
title = "Date set using Org time stamp"
date = 2018-01-23T00:00:00+00:00
tags = ["dates", "date"]
draft = false
+++

The `date` for this post is set in Org using the `C-c . RET` binding.
