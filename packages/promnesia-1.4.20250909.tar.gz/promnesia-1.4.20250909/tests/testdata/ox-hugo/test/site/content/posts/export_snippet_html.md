+++
title = "Export snippet HTML"
tags = ["export-snippet", "html"]
draft = false
+++

This HTML <b>Export Snippet</b> will also get exported for Hugo
exports, <code>verbatim</code>.
