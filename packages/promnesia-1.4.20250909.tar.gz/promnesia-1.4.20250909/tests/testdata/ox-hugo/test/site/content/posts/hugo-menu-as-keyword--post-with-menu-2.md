+++
title = "Post with menu 2 (HUGO_MENU as keyword)"
draft = false
[menu."auto weight"]
  weight = 1002
  identifier = "post-with-menu-2--hugo-menu-as-keyword"
+++
