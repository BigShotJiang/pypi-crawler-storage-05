+++
title = "Default Creator"
date = 2017-12-01
tags = ["export-option", "creator", "front-matter"]
draft = false
creator = "Emacs + Org mode + ox-hugo"
+++

The front-matter for this post contains the default Creator string.
