---
title: "Single-line description set using Org Special Block (YAML)"
description: "Short description --- **bold** -- _italics_ --- ~~strikethrough~~ `monospace`"
tags: ["front-matter", "description", "special-block", "yaml", "single-line"]
draft: false
---

Post content.
