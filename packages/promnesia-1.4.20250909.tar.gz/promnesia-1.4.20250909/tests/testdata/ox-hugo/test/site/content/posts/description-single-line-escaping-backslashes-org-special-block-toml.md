+++
title = "Single-line description with backslashes (TOML)"
description = "Test to check that backslashes in `\\|` and `\\\\` are correctly escaped."
tags = ["front-matter", "description", "special-block", "toml", "escaping", "backslashes", "single-line"]
draft = false
+++

Post content.
