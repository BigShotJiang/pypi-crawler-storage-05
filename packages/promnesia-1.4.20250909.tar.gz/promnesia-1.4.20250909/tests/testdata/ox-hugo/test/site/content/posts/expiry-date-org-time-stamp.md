+++
title = "Expiry date set using Org time stamp"
expiryDate = 2999-01-23T00:00:00+00:00
tags = ["dates", "expirydate"]
draft = false
+++

The `expirydate` for this post is set in Org using the `C-c . RET`
binding.
