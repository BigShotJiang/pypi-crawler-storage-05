+++
title = "Articles Index page"
tags = ["section", "fragment", "concatenation", "deep-nesting", "page-bundles"]
draft = false
+++

This is an index page (_branch_ bundle) for all the articles.

[Ref](https://github.com/kaushalmodi/ox-hugo/issues/210#issuecomment-424891371)
