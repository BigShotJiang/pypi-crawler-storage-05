+++
title = "Expiry date set using Hugo-compatible date string"
expiryDate = 2999-01-23
tags = ["dates", "expirydate"]
draft = false
+++

The `expirydate` for this post is Hugo-compatible
i.e. [RFC3339-compliant](https://tools.ietf.org/html/rfc3339#section-5.8).
