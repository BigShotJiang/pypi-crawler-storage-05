+++
title = "Bundled page foo"
tags = ["page-bundles"]
draft = false
+++

"Foo" page in _Page Bundle A_.
