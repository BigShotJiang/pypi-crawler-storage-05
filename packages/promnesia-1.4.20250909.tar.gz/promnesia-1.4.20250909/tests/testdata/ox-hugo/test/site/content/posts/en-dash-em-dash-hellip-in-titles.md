+++
title = "En dash –, Em dash —, Horizontal ellipsis … in titles"
tags = ["title"]
categories = ["upstream"]
draft = false
+++

This tests an `ox-hugo` feature that gets around an upstream
limitation, where the Blackfriday _smartDashes_ rendering does not
happen in post titles (`hugo` Issue #[4175](https://github.com/gohugoio/hugo/issues/4175)).
