+++
title = "Bundled page foo in the headless bundle"
tags = ["page-bundles", "headless"]
draft = false
+++

"Foo" page in _Headless Page Bundle_.
