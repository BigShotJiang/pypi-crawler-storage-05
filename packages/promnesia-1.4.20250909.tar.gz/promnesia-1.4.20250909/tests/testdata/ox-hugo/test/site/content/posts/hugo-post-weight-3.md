+++
title = "Post with auto weight calc 3 (EXPORT_HUGO_WEIGHT as subtree property)"
tags = ["weight", "page-weight", "auto"]
draft = false
weight = 4003
+++
