+++
title = "Auto-set Lastmod"
lastmod = 2100-12-21T00:00:00+00:00
draft = false
+++

This post will have its `lastmod` field in the front-matter
auto-updated the time it gets exported each time.
