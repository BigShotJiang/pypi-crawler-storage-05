+++
title = "HUGO_DRAFT not set, TEST__TODO state"
tags = ["draft", "todo", "test"]
draft = true
+++

This post is marked as draft as the Org TODO state is set to
`TEST__TODO`.
