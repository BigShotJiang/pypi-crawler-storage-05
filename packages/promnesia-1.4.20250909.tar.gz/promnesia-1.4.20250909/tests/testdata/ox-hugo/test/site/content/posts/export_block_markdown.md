+++
title = "Export block Markdown"
tags = ["export-block", "markdown"]
draft = false
+++

This Markdown **Export Block** will also get exported for Hugo exports,
`verbatim` ..

and **this too**.
