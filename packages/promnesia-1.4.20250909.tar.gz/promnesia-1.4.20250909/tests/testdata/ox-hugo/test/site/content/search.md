+++
title = "Search"
layout = "search"
outputs = ["html", "json"]
draft = false
[sitemap]
  priority = 0.1
[menu."0.search"]
  weight = 2001
  identifier = "search"
  title = "Click to Search"
+++

Results from static site search implemented using _Fusejs_, _jquery_
and _mark.js_. -- [Source](https://gist.github.com/eddiewebb/735feb48f50f0ddd65ae5606a1cb41ae)
