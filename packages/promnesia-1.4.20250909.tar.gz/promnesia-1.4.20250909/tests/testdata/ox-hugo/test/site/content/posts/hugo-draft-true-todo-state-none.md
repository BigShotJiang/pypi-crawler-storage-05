+++
title = "HUGO_DRAFT true, no TODO state"
tags = ["draft", "property"]
draft = true
+++

This post does not have any Org TODO state. So it uses the value of
`EXPORT_HUGO_DRAFT`.
