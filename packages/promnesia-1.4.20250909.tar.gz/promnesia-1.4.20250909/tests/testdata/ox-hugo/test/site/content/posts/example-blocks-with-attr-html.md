+++
title = "Example blocks with ATTR_HTML"
tags = ["example", "attr_html", "attr_css"]
draft = false
+++

Some text.

<style>.indent-block { padding-left: 50px;  }</style>

<div class="indent-block">
  <div></div>

```text
This is an example
Line 2
Line 3
```
</div>

Some more text.
