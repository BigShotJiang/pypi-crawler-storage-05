+++
title = "Checklist"
date = 2017-08-02
tags = ["lists"]
draft = false
[blackfriday]
  fractions = false
+++

This is a check-list:


## Checklist 1 <code>[60%]</code> {#checklist-1}

Checklist showing progress in percentage.

-   [ ] Task 1
-   [X] Task 2
-   [X] Task 3
-   [ ] Task 4
-   [X] Task 5


## Checklist 2 <code>[2/5]</code> {#checklist-2}

Checklist showing progress in ratio.

-   [ ] Task 1
-   [ ] Task 2
-   [X] Task 3
-   [ ] Task 4
-   [X] Task 5
