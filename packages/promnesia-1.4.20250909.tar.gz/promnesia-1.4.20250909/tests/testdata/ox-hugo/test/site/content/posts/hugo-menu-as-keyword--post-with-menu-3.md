+++
title = "Post with menu 3 (HUGO_MENU as keyword)"
draft = false
[menu."auto weight"]
  weight = 1003
  identifier = "post-with-menu-3--hugo-menu-as-keyword"
+++
