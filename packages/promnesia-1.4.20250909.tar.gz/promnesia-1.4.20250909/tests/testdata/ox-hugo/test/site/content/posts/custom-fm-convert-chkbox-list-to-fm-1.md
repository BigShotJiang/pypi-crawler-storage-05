+++
title = "Meeting 1"
author = ["xeijin"]
tags = ["custom-fm", "elisp"]
draft = false
[attendees]
  checked = ["Attendee 1"]
  not-checked = ["Attendee 2", "Attendee 3", "Attendee 4"]
+++

`ox-hugo` Issue #[272](https://github.com/kaushalmodi/ox-hugo/issues/272)


## Notes {#notes}

My notes
