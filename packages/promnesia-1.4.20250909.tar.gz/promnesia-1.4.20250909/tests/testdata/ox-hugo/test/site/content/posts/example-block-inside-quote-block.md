+++
title = "Example block inside quote block"
tags = ["quotes"]
draft = false
+++

Some text.

> Some quoted text.
>
> ```text
> (some-example)
> ```

Some other text.
