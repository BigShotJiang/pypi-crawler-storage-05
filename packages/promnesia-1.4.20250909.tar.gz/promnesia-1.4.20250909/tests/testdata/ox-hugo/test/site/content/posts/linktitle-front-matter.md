+++
title = "Linktitle Front-matter"
linkTitle = "My link title"
tags = ["front-matter", "linktitle"]
draft = false
+++

The `linktitle` front-matter is used for creating links to content. If
set, Hugo defaults to using the `linktitle` before the `title`.
