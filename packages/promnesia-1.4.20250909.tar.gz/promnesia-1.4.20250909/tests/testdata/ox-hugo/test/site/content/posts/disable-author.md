+++
title = "Disable exporting author"
tags = ["export-option", "author", "disable"]
draft = false
+++

This post will be exported without `author` in the front-matter because
it is disabled using `:EXPORT_OPTIONS: author:nil`.
