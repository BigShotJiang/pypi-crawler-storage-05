+++
title = "Custom Creator"
tags = ["export-option", "creator", "front-matter"]
draft = false
creator = "The awesome Emacs + Org-mode + ox-hugo + Hugo"
+++

The front-matter for this post contains a custom Creator string.
