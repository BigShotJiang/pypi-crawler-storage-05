+++
title = "Multiple aliases without section portion"
aliases = ["/posts/alias-e", "/posts/alias-f"]
tags = ["front-matter", "aliases"]
draft = false
+++
