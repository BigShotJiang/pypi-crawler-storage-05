+++
title = "Issue 335"
description = "Test the exporting of taxonomy weight parameters like `tags_weight`."
tags = ["taxonomy-weight"]
categories = ["issues"]
draft = false
tags_weight = 123
+++

`ox-hugo` Issue #[335](https://github.com/kaushalmodi/ox-hugo/issues/335)
