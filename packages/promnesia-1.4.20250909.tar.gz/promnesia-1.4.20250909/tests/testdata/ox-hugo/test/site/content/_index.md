+++
title = "Home page Branch Bundle with image"
tags = ["homepage", "branch", "image", "bundle"]
draft = false
+++

Image in homepage branch bundle:

{{< figure src="org-copy-3.png" link="org-copy-3.png" >}}
