+++
title = "HUGO_DRAFT not set, no TODO state either"
tags = ["draft", "default"]
draft = false
+++

This post has neither the `EXPORT_HUGO_DRAFT` property set, nor the
Org TODO state. So the draft state defaults to _false_.
