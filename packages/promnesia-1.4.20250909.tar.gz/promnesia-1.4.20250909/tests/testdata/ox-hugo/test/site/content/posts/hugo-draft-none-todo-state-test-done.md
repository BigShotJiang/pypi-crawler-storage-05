+++
title = "HUGO_DRAFT not set, TEST__DONE state"
date = 2018-07-10T10:42:00+00:00
tags = ["draft", "todo", "done", "test"]
draft = false
+++

This post is not marked as draft as the Org TODO state is set to
`TEST__DONE`.
