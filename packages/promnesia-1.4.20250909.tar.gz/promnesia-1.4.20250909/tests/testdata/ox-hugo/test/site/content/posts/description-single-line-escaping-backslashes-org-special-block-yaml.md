---
title: "Single-line description with backslashes (YAML)"
description: "Test to check that backslashes in `\\|` and `\\\\` are correctly escaped."
tags: ["front-matter", "description", "special-block", "yaml", "escaping", "backslashes", "single-line"]
draft: false
---

Post content.
