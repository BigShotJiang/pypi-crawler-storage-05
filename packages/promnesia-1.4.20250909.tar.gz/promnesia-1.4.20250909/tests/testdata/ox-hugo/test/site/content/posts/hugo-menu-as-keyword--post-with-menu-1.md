+++
title = "Post with menu 1 (HUGO_MENU as keyword)"
draft = false
[menu."auto weight"]
  weight = 1001
  identifier = "post-with-menu-1--hugo-menu-as-keyword"
+++
