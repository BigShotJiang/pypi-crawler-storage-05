+++
title = "Custom front matter with list values in TOML"
tags = ["custom-fm", "list-values"]
draft = false
animals = ["dog", "cat", "penguin", "mountain gorilla"]
strings-symbols = ["abc", "def", "two words"]
integers = [123, -5, 17, 1_234]
floats = [12.3, -5.0, -1.7e-05]
booleans = [true, false]
+++

`ox-hugo` Issue #[99](https://github.com/kaushalmodi/ox-hugo/issues/99)
