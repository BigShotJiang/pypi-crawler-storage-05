+++
title = "Post with menu 4 (HUGO_MENU as keyword)"
draft = false
[menu."auto weight"]
  weight = 1004
  identifier = "post-with-menu-4--hugo-menu-as-keyword"
+++
