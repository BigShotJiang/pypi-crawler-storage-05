+++
title = "Export snippet Hugo"
tags = ["export-snippet", "hugo"]
draft = false
+++

This will get exported **only for** Hugo exports, `verbatim`.

Newlines in Org source
between the `@​@` pairs are
allowed too
(but no blank lines).

Use **Export Blocks** if you need blank lines in-between.
