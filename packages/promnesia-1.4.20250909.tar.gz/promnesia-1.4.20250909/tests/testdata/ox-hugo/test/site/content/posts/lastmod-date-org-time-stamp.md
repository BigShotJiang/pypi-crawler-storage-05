+++
title = "Lastmod date set using Org time stamp"
lastmod = 2018-01-23T00:00:00+00:00
tags = ["dates", "lastmod"]
draft = false
+++

The `lastmod` for this post is set in Org using the `C-c . RET`
binding.
