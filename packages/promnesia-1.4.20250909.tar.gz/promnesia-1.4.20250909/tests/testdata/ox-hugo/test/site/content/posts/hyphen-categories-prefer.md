+++
title = "Prefer Hyphen Categories"
categories = ["-a", "_a", "b-", "b_", "a-b", "a_b", "a-b_c", "-a_b_c_"]
draft = false
+++
