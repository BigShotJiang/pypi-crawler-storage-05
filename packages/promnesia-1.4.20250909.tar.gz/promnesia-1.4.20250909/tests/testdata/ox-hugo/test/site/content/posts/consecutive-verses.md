+++
title = "Consecutive verses"
date = 2017-08-01
tags = ["verse"]
draft = false
+++

<p class="verse">
Tyger Tyger, burning bright,<br />
In the forests of the night;<br />
What immortal hand or eye,<br />
Could frame thy fearful symmetry?<br />
<br />
In what distant deeps or skies.<br />
Burnt the fire of thine eyes?<br />
On what wings dare he aspire?<br />
What the hand, dare seize the fire?<br />
<br />
&nbsp;&nbsp;&nbsp;-- "The Tyger" _by_ William Blake<br />
</p>

<p class="verse">
Some parts can be **bold**<br />
&nbsp;&nbsp;Some can be `monospace`<br />
&nbsp;&nbsp;&nbsp;&nbsp;Some can be _italic_ too.<br />
</p>

<p class="verse">
What is this life if, full of care,<br />
We have no time to stand and stare.<br />
<br />
No time to stand beneath the boughs<br />
And stare as long as sheep or cows.<br />
<br />
No time to see, when woods we pass,<br />
Where squirrels hide their nuts in grass.<br />
<br />
&nbsp;&nbsp;&nbsp;-- "Leisure" _by_ William Henry Davis<br />
</p>
