+++
title = "Multiple images"
images = ["image foo.svg", "images/bar.png", "zoo.jpg"]
tags = ["front-matter", "images", "multiple"]
draft = false
+++

If an image path has spaces in it, wrap the whole path in double
quotes.
