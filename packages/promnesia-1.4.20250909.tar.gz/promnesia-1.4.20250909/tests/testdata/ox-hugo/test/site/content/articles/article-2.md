+++
title = "Article 2"
date = 2017-07-19T08:34:22-04:00
tags = ["section"]
draft = false
+++

Second article.

This will also land in `content/articles/` the same way.
