+++
title = "Post with auto weight calc 4 (EXPORT_HUGO_WEIGHT as subtree property)"
tags = ["weight", "page-weight", "auto"]
draft = false
weight = 4004
+++
