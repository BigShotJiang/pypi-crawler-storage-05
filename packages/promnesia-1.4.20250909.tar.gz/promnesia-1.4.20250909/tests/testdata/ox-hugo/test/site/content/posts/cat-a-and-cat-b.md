+++
title = "Cat A and cat B"
date = 2017-07-24
categories = ["catA", "catB"]
draft = false
+++

This gets both categories `catA` and `catB`.
