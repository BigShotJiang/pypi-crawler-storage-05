+++
title = "Index"
draft = false
+++

Book 1 index.

This type of organization will generate this in the `content/`
directory:

```text
> tree book1
book1
├── chapter1
│   ├── _index.md
│   ├── section1.md
│   └── section2.md
├── chapter2
│   ├── _index.md
│   ├── section1.md
│   └── section2.md
└── _index.md
```

-   [Chapter 1](/book1/chapter1)
    -   [Chapter 1 Section 1](/book1/chapter1/section1)
    -   [Chapter 1 Section 2](/book1/chapter1/section2)
-   [Chapter 2](/book1/chapter2)
    -   [Chapter 2 Section 1](/book1/chapter2/section1)
    -   [Chapter 2 Section 2](/book1/chapter2/section2)
