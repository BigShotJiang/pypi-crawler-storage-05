+++
title = "Hyphens and spaces in categories"
categories = ["an-apple a_pear", "good bad and ugly"]
draft = false
+++

The Org tags do not allow spaces. So the trick we use is replace
**double** underscores with spaces.

So an Org tag `@abc__def` becomes Hugo category `abc def`.
