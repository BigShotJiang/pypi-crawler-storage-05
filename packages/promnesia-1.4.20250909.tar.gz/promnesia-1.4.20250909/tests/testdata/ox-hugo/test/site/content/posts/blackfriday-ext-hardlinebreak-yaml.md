---
title: "Hard line break (YAML)"
tags: ["blackfriday", "yaml"]
draft: false
blackfriday:
  extensions: ["hardLineBreak"]
---

a
b
c

Above, _a_, _b_ and _c_ must appear on separate lines.
