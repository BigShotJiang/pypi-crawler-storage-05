+++
title = "Auto-detected locale in front-matter"
description = "Locale is not specified, so is auto-detected."
tags = ["front-matter", "locale", "auto-detect"]
draft = false
locale = "en_US"
+++

Locale exporting is enabled using `:EXPORT_HUGO_WITH_LOCALE: t` in the
post's parent subtree.
