+++
title = "Bundled page bar"
tags = ["page-bundles"]
draft = false
+++

"Bar" page in _Page Bundle A_.
