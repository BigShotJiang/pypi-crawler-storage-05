+++
title = "Article One Index page"
tags = ["section", "fragment", "concatenation", "deep-nesting", "page-bundles"]
draft = false
+++

This is an index page (_branch_ bundle) for Articles/Article One.
