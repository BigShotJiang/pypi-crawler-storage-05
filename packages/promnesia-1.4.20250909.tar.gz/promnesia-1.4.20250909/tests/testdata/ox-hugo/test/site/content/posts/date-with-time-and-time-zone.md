+++
title = "Date with time and time-zone (default)"
date = 2018-01-29T00:00:00+00:00
tags = ["dates", "date-format", "time-zone", "time"]
draft = false
+++
