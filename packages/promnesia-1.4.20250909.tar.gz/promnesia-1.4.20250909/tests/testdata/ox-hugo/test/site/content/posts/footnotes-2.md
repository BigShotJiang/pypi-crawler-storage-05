+++
title = "Footnotes 2"
date = 2017-07-21
tags = ["footnote"]
draft = false
+++

This is some text[^fn:1].

[^fn:1]: Second footnote
