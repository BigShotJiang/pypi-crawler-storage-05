+++
title = "ox-hugo Issue 360 test (Bundle)"
description = "Link to image using `file:` in a Leaf Bundle."
tags = ["issues", "images", "figure", "bundle"]
draft = false
+++

`ox-hugo` Issue #[360](https://github.com/kaushalmodi/ox-hugo/issues/360)

{{< figure src="org.png" >}}
