+++
title = "Lastmod date set using Hugo-compatible date string"
lastmod = 2018-01-23
tags = ["dates", "lastmod"]
draft = false
+++

The `lastmod` for this post is Hugo-compatible i.e. [RFC3339-compliant](https://tools.ietf.org/html/rfc3339#section-5.8).
