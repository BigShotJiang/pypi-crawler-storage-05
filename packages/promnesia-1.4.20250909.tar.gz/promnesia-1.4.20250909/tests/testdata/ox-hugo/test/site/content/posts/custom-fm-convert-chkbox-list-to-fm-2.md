+++
title = "Meeting 2"
author = ["xeijin"]
tags = ["custom-fm", "elisp"]
draft = false
[attendees]
  checked = ["Attendee x", "Attendee z"]
  not-checked = ["Attendee y", "Attendee w"]
+++

`ox-hugo` Issue #[272](https://github.com/kaushalmodi/ox-hugo/issues/272)


## Notes {#notes}

My notes
