+++
title = "Cat A post 1"
date = 2017-07-24
tags = ["meow"]
categories = ["catA"]
draft = false
+++

This post is in category `catA` and tagged `meow`.
