+++
title = "Example block with escaped Org syntax inside quote block"
tags = ["quotes"]
draft = false
+++

Some text.

> Some quoted text.
>
> ```text
> #+name: some_example
> (some-example)
> ```

Some other text.
