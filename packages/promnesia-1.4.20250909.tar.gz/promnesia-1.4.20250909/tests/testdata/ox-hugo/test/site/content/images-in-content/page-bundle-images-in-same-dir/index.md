+++
title = "Page Bundle with images in the same dir"
draft = false
+++

## Link to an image in the same dir as this Org file {#link-to-an-image-in-the-same-dir-as-this-org-file}

{{< figure src="gnu.png" link="gnu.png" >}}


## Link to an image containing this bundle's name in the path {#link-to-an-image-containing-this-bundle-s-name-in-the-path}

{{< figure src="org-copy-2.png" link="org-copy-2.png" >}}


## Link to an image in a subdir in the same dir as this Org file {#link-to-an-image-in-a-subdir-in-the-same-dir-as-this-org-file}

{{< figure src="images/org-copy-1.png" link="images/org-copy-1.png" >}}
