+++
title = "Alias without section portion 1"
aliases = ["/posts/alias-a"]
tags = ["front-matter", "aliases"]
draft = false
+++

As the specified alias does not contain the "/" string, it will be
auto-prefixed with the section for the current post.
