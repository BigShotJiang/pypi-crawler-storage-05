+++
title = "Use Org Code markup for kbd tag (default behavior)"
date = 2017-07-31
tags = ["formatting"]
draft = false
+++

This is the default behavior. So `~C-h f~` will show up as `` `C-h f` ``
and then `<code>C-h f</code>` in the final Hugo generated HTML.

Example:

-   Few of Emacs help keybindings: `C-h f`, `C-h v`
