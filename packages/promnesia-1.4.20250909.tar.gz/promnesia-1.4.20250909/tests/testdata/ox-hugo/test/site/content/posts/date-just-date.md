+++
title = "Just date"
date = 2017-09-12
tags = ["dates", "date"]
draft = false
+++

The `date` for this post is Hugo-compatible i.e. [RFC3339-compliant](https://tools.ietf.org/html/rfc3339#section-5.8).
