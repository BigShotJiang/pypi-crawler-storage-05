+++
title = "Single-line description set using Org Special Block (TOML)"
description = "Short description --- **bold** -- _italics_ --- ~~strikethrough~~ `monospace`"
tags = ["front-matter", "description", "special-block", "toml", "single-line"]
draft = false
+++

Post content.
