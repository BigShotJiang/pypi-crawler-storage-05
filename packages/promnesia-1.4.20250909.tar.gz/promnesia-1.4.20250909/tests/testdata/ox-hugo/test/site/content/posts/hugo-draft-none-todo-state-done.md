+++
title = "HUGO_DRAFT not set, DONE state"
date = 2018-07-09T11:00:00+00:00
tags = ["draft", "todo", "done"]
draft = false
+++

This post is not marked as draft as the Org TODO state is set to
`DONE`.
