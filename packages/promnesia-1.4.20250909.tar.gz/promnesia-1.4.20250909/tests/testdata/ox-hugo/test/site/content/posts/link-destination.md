+++
title = "Link destination"
tags = ["links"]
draft = false
+++

## External target {#external-target}

<a id="org371fa62"></a>


## External target with **bold** and _italic_ {#external-target-with-bold-and-italic}
