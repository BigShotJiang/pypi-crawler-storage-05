+++
title = "Post with menu 5 (HUGO_MENU as keyword)"
draft = false
[menu."auto weight"]
  weight = 1005
  identifier = "post-with-menu-5--hugo-menu-as-keyword"
+++
