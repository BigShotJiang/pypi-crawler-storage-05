+++
title = "Alias specifying a different section"
aliases = ["/alias-test/alias-c"]
tags = ["front-matter", "aliases"]
draft = false
+++
