+++
title = "Prefer Hyphen in Tags"
tags = ["-a", "_a", "b-", "b_", "a-b", "a_b", "a-b_c", "-a-b_c_"]
draft = false
+++
