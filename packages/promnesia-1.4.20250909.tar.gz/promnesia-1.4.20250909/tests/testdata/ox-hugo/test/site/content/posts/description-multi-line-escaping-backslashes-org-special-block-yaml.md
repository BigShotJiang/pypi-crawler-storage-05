---
title: "Multi-line description with backslashes (YAML)"
description: >
  Test to check that backslashes in `\|` and `\\` are correctly escaped
  in the front-matter.
tags: ["front-matter", "description", "special-block", "yaml", "escaping", "backslashes", "multi-line"]
draft: false
---

Post content.
