+++
title = "HUGO_DRAFT not set, DRAFT state"
tags = ["draft", "todo"]
draft = true
+++

This post is marked as draft as the Org TODO state is set to `DRAFT`.
