+++
title = "Page Bundle B"
tags = ["page-bundles"]
draft = false
+++

Index page of _Page Bundle B_.

{{< figure src="copy-2-of-unicorn-logo.png" >}}
