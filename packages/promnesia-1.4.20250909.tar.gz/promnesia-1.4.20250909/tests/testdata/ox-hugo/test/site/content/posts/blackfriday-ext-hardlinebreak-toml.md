+++
title = "Hard line break (TOML)"
tags = ["blackfriday", "toml"]
draft = false
[blackfriday]
  extensions = ["hardLineBreak"]
+++

a
b
c

Above, _a_, _b_ and _c_ must appear on separate lines.
