---
title: "Multi-line description set using Org Special Block (YAML)"
description: >
  Short description
  of this post


  **bold** -- _italics_ --- ~~strikethrough~~ `monospace`


  These lines <br />
  show up with line breaks <br />
  but within the same paragraph.
tags: ["front-matter", "description", "special-block", "yaml", "multi-line"]
draft: false
---

Post content.
