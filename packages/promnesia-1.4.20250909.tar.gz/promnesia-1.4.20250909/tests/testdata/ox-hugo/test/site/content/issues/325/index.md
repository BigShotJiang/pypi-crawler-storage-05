+++
title = "ox-hugo Issue 325 test"
description = "summary of this test."
tags = ["front-matter", "extra", "verbatim", "src-block", "toml", "toml-extra"]
draft = false
weight = 5
url_pdf = "#"
url_code = "#"
url_dataset = "#"
url_video = "#"
external_link = "/courses/example/"
projects = ["signals and systems"]
[image]
  caption = " [**Watch**](https://youtube.com)"
  preview_only = true

[[links]]
icon = "youtube"
icon_pack = "fab"
name = "Watch It"
url = "/courses/example/"

[[links]]
icon = "instagram"
icon_pack = "fab"
name = "Inst"
url = "/courses/example/"

[[links]]
icon = "weibo"
icon_pack = "fab"
name = "Weibo"
url = "/courses/example/"

[[links]]
icon = "wechat"
icon_pack = "fab"
name = "Wechat"
url = "/courses/example/"
+++

<span class="timestamp-wrapper"><span class="timestamp">&lt;2020-01-29 Wed 16:39&gt;</span></span>
