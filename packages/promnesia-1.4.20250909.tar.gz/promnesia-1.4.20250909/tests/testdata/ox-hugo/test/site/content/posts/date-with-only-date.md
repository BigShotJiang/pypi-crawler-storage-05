+++
title = "Date with only date"
date = 2018-01-29
tags = ["dates", "date-format", "only-date"]
draft = false
+++
