+++
title = "Consecutive quotes"
date = 2017-08-01
tags = ["quotes"]
draft = false
+++

Some text.

> Quote 1. This is a long quote that auto-fills into multiple lines in
> Org, but it will be a single paragraph in the exported format.

<!--quoteend-->

> Quote 2. This is a short quote.

<!--quoteend-->

> Quote 3. This is a multi-paragraph quote.
>
> This is the second paragraph.

Some other text.
