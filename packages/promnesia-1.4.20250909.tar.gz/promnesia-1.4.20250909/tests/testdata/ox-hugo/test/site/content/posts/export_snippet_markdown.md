+++
title = "Export snippet Markdown"
tags = ["export-snippet", "markdown"]
draft = false
+++

This Markdown **Export Snippet** will also get exported for Hugo
exports, `verbatim`.

_This one too_

NOTE
: `ox-md.el` does not support **Export Snippets** as of writing
    this <span class="timestamp-wrapper"><span class="timestamp">&lt;2017-12-08 Fri&gt;</span></span>. So even the `@@md:foo@@` and
    `@@markdown:foo@@` snippets are handled by `ox-hugo`
    directly.
