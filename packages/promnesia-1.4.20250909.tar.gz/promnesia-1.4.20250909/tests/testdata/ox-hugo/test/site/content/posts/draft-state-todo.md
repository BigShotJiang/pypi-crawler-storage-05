+++
title = "Pre-Draft State"
date = 2017-07-12T17:05:41-04:00
tags = ["draft"]
draft = true
+++

If a post has the `TODO` keyword, the `draft` front matter variable
should be set to `true`.

Idea to to mark a post or blog idea as `TODO` that you yet have to
start writing.
