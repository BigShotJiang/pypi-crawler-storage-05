+++
title = "Image captions"
description = "Figure captions with markup."
date = 2017-07-19
tags = ["image"]
draft = false
+++

Some text before image.

{{< figure src="/images/org-mode-unicorn-logo.png" caption="Figure 1: A unicorn! \"Something in double quotes\"" >}}

Some more text, after image.

{{< figure src="/images/org-mode-unicorn-logo.png" caption="Figure 2: The _same_ figure **again**, testing [a link](https://ox-hugo.scripter.co) too!" >}}
