+++
title = "Custom front matter in one line"
date = 2017-07-24
tags = ["custom-fm"]
draft = false
foo = "bar"
baz = "zoo"
alpha = 1
beta = "two words"
gamma = 10
version = "6.17.00"
+++
