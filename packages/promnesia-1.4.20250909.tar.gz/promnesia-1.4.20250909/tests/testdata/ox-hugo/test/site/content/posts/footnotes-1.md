+++
title = "Footnotes 1"
date = 2017-07-21
tags = ["footnote"]
draft = false
+++

This is some text[^fn:1].

_Note to self: You **cannot** name an Org heading 'Footnotes'; that's
reserved by Org to store all the footnotes._

[^fn:1]: First footnote
