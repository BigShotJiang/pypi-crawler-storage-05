+++
title = "Alias specifying root section"
aliases = ["/alias-d"]
tags = ["front-matter", "aliases"]
draft = false
+++
