+++
title = "Single image"
images = ["image path with space.png"]
tags = ["front-matter", "images", "single"]
draft = false
+++

If an image path has spaces in it, wrap the whole path in double
quotes.
