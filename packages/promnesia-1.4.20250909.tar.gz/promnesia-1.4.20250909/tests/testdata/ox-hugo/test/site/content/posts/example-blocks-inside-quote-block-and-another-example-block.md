+++
title = "Example blocks inside quote block, followed by another example block outside"
tags = ["quotes"]
draft = false
+++

[Blackfriday Issue # 407](https://github.com/russross/blackfriday/issues/407)

Some text.

> Some quoted text.
>
> ```text
> (some-example)
> ```
>
> ````text
> (some-other-example)
> ````

`````text
(yet-another-example)
`````

Some other text.
