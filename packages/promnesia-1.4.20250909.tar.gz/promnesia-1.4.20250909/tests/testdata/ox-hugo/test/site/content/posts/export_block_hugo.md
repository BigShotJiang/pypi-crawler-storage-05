+++
title = "Export block Hugo"
tags = ["export-block", "hugo"]
draft = false
+++

This will get exported **only for** Hugo exports, `verbatim`.
