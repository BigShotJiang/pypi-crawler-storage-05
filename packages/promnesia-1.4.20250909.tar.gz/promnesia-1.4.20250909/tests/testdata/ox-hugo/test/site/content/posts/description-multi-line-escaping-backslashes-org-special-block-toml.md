+++
title = "Multi-line description with backslashes (TOML)"
description = """
  Test to check that backslashes in `\\|` and `\\\\` are correctly escaped
  in the front-matter.
  """
tags = ["front-matter", "description", "special-block", "toml", "escaping", "backslashes", "multi-line"]
draft = false
+++

Post content.
