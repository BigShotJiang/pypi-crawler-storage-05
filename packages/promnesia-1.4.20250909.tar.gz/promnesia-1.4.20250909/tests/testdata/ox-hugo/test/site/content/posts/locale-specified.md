+++
title = "Specified locale in front-matter"
description = "Specify the locale using `:EXPORT_HUGO_LOCALE: es_ES` property."
tags = ["front-matter", "locale"]
draft = false
locale = "es_ES"
+++

Locale exporting is enabled using `:EXPORT_HUGO_WITH_LOCALE: t` in the
post's parent subtree.
