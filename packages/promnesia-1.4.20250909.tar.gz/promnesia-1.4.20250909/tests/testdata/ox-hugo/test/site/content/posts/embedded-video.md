+++
title = "Embedded Video"
tags = ["videos", "embedded"]
draft = false
+++

[Using `video` HTML5 tag](https://www.w3schools.com/html/html5%5Fvideo.asp)

 <video width="320" height="240" controls>
  <source src="/videos/sample.mp4" type="video/mp4">
  Your browser does not support the video tag.
</video>

[Video source](https://sample-videos.com/)
