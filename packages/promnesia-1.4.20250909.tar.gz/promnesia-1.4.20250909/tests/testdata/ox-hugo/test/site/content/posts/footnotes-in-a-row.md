+++
title = "Footnotes in a row"
date = 2017-07-21
tags = ["footnote"]
draft = false
+++

This is some text[^fn:1]<sup>, </sup>[^fn:2].

[^fn:1]: First footnote
[^fn:2]: Second footnote
