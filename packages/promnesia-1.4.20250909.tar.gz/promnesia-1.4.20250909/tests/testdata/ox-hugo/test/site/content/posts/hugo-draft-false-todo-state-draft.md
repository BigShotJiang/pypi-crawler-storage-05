+++
title = "HUGO_DRAFT false, DRAFT state (Override)"
tags = ["draft", "todo", "override"]
draft = true
+++

This post has `EXPORT_HUGO_DRAFT` set to `"false"`. But the **DRAFT**
state of Org TODO overrides that.
