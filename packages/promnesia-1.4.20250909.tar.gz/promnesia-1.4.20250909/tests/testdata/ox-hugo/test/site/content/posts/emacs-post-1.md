+++
title = "Emacs Post 1"
date = 2017-07-12T17:31:56-04:00
tags = ["section", "emacs", "foo"]
draft = false
+++

Here is the first post on Emacs.
