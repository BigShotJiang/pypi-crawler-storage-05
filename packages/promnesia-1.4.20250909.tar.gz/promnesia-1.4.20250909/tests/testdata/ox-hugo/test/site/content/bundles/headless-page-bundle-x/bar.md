+++
title = "Bundled page bar in the headless bundle"
tags = ["page-bundles", "headless"]
draft = false
+++

"Bar" page in _Headless Page Bundle_.
