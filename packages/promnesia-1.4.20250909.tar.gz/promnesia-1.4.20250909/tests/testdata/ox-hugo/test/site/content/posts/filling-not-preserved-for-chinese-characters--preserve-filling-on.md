+++
title = "Filling automatically not preserved for Chinese characters (preserve filling on)"
description = """
  Ensure that multi-byte characters are force-unwrapped if the locale is
  manually set or auto-detected as Chinese.
  """
tags = ["filling", "chinese", "locale"]
draft = false
+++

abc
def
ghi
这是一个测试文本

[Reference](https://emacs-china.org/t/ox-hugo-auto-fill-mode-markdown/9547/5)
