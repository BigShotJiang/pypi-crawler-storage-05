+++
title = "Alias without section portion 2"
aliases = ["/alias-test/alias-b"]
tags = ["front-matter", "aliases"]
draft = false
+++

As the specified alias does not contain the "/" string, it will be
auto-prefixed with the section for the current post.
