+++
title = "Article 1"
date = 2017-07-19T08:34:29-04:00
tags = ["section"]
draft = false
+++

First article.

This will land in `content/articles/` as the parent of this subtree
sets `EXPORT_HUGO_SECTION` to `articles`. Note that the theme needs to
define at least the `single.html`, either in the `layouts/_default/`
directory, or `layouts/articles/`, either in the Hugo base dir or the
theme dir.
