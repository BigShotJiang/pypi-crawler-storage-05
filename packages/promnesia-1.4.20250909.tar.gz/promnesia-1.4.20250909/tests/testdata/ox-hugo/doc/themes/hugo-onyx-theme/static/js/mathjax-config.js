window.MathJax = {
  tex: {
    tags: "ams"
  }
};
