# checknum

checknum is a lightweight Python module that provides two simple utilities:
- av(*args): Calculates the average of a list of numbers.
- pr(n): Checks whether a given number is prime.

## Installation

You can install it via pip:

->  pip install checknum