Reading Gmsh Meshes
===================

.. automodule:: gmsh_interop.reader
