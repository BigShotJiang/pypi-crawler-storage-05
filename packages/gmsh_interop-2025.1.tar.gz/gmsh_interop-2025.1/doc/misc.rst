Installation
============

This command should install :mod:`gmsh_interop`::

    pip install gmsh_interop

User-visible changes
====================

Version 2020.2
--------------

.. note::

    This version is currently under development. You can get snapshots from
    gmsh_interop's `git repository <https://github.com/inducer/gmsh_interop>`_

.. _license:

License
=======

.. include:: ../LICENSE
