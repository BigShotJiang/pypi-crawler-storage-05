Running Gmsh
============

.. module:: gmsh_interop

.. automodule:: gmsh_interop.runner
