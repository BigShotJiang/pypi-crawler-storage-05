# Register your models here.
from django.contrib import admin

from .models import RequestTracker

admin.site.register(RequestTracker)
