title: A leading article headline
alt: this alt text goes on a image html tag
stuff: $dir/pages/error-pages.md#data
===
# hello new article post
