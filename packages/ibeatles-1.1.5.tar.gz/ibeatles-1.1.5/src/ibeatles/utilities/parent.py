class Parent:
    def __init__(self, parent=None):
        self.parent = parent
