class SaveTab:
    def __init__(self, parent=None, session_dict=None):
        self.parent = parent
        self.session_dict = session_dict
