class SessionSubKeys:
    table_dictionary = "table dictionary"
    plot_active_row_flag = "plot active row flag"
