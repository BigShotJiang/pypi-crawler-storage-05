from plone.app.registry.registry import Registry  # noqa: F401
