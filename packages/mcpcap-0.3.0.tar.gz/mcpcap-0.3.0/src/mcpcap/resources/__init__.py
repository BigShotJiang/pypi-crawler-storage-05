"""Resources for mcpcap analysis."""

from .references import setup_resources

__all__ = ["setup_resources"]
