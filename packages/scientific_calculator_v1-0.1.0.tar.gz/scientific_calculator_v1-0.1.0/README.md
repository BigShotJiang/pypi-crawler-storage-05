# Scientific Calculator

A Python package for performing scientific calculations.

## Features

- Basic arithmetic operations: addition, subtraction, multiplication, division
- Scientific functions: sine, cosine, tangent, logarithm, exponential, square root, power
- Error handling for invalid inputs
- Command-line interface for easy use

## Installation

Install from PyPI:
```
pip install scientific-calculator
```

Or install from source:
```
pip install .
```

## Usage

### As a Python module

```python
from scientific_calculator import ScientificCalculator

calc = ScientificCalculator()
result = calc.add(2, 3)
print(result)  # 5.0

result = calc.sin(90)
print(result)  # 1.0
```

### Command-line interface

```
python -m scientific_calculator.cli add 2 3
# Result: 5.0

python -m scientific_calculator.cli sin 90
# Result: 1.0
```

## Available Operations

- `add a b`: a + b
- `subtract a b`: a - b
- `multiply a b`: a * b
- `divide a b`: a / b
- `sin x`: sin(x) in degrees
- `cos x`: cos(x) in degrees
- `tan x`: tan(x) in degrees
- `log x [base]`: log(x, base) default base 10
- `exp x`: e^x
- `sqrt x`: square root of x
- `power base exponent`: base^exponent

## License

MIT License
