import unittest
from scientific_calculator.calculator import ScientificCalculator

class TestScientificCalculator(unittest.TestCase):
    def setUp(self):
        self.calc = ScientificCalculator()

    def test_add(self):
        self.assertEqual(self.calc.add(2, 3), 5)

    def test_subtract(self):
        self.assertEqual(self.calc.subtract(5, 3), 2)

    def test_multiply(self):
        self.assertEqual(self.calc.multiply(4, 3), 12)

    def test_divide(self):
        self.assertEqual(self.calc.divide(10, 2), 5)
        with self.assertRaises(ValueError):
            self.calc.divide(10, 0)

    def test_sin(self):
        self.assertAlmostEqual(self.calc.sin(90), 1, places=5)

    def test_cos(self):
        self.assertAlmostEqual(self.calc.cos(0), 1, places=5)

    def test_tan(self):
        self.assertAlmostEqual(self.calc.tan(45), 1, places=5)

    def test_log(self):
        self.assertAlmostEqual(self.calc.log(100), 2, places=5)
        with self.assertRaises(ValueError):
            self.calc.log(-1)

    def test_exp(self):
        self.assertAlmostEqual(self.calc.exp(1), 2.71828, places=4)

    def test_sqrt(self):
        self.assertEqual(self.calc.sqrt(16), 4)
        with self.assertRaises(ValueError):
            self.calc.sqrt(-4)

    def test_power(self):
        self.assertEqual(self.calc.power(2, 3), 8)

if __name__ == "__main__":
    unittest.main()
