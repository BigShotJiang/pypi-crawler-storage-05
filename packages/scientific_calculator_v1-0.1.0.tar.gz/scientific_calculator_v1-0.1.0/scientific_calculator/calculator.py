import math

class ScientificCalculator:
    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def multiply(self, a, b):
        return a * b

    def divide(self, a, b):
        if b == 0:
            raise ValueError("Division by zero is not allowed")
        return a / b

    def sin(self, x):
        return math.sin(math.radians(x))  # Assuming input in degrees

    def cos(self, x):
        return math.cos(math.radians(x))

    def tan(self, x):
        return math.tan(math.radians(x))

    def log(self, x, base=10):
        if x <= 0:
            raise ValueError("Logarithm is only defined for positive numbers")
        return math.log(x, base)

    def exp(self, x):
        return math.exp(x)

    def sqrt(self, x):
        if x < 0:
            raise ValueError("Square root is not defined for negative numbers")
        return math.sqrt(x)

    def power(self, base, exponent):
        return math.pow(base, exponent)
