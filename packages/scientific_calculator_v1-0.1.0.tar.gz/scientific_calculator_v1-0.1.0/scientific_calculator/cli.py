#!/usr/bin/env python3

from .calculator import ScientificCalculator
import sys

def main():
    if len(sys.argv) < 3:
        print("Usage: python -m scientific_calculator.cli <operation> <arg1> [arg2]")
        print("Operations: add, subtract, multiply, divide, sin, cos, tan, log, exp, sqrt, power")
        sys.exit(1)

    calc = ScientificCalculator()
    op = sys.argv[1]
    try:
        if op in ['add', 'subtract', 'multiply', 'divide']:
            a = float(sys.argv[2])
            b = float(sys.argv[3])
            if op == 'add':
                result = calc.add(a, b)
            elif op == 'subtract':
                result = calc.subtract(a, b)
            elif op == 'multiply':
                result = calc.multiply(a, b)
            elif op == 'divide':
                result = calc.divide(a, b)
        elif op in ['sin', 'cos', 'tan', 'log', 'exp', 'sqrt']:
            a = float(sys.argv[2])
            if op == 'sin':
                result = calc.sin(a)
            elif op == 'cos':
                result = calc.cos(a)
            elif op == 'tan':
                result = calc.tan(a)
            elif op == 'log':
                result = calc.log(a)
            elif op == 'exp':
                result = calc.exp(a)
            elif op == 'sqrt':
                result = calc.sqrt(a)
        elif op == 'power':
            a = float(sys.argv[2])
            b = float(sys.argv[3])
            result = calc.power(a, b)
        else:
            print("Unknown operation")
            sys.exit(1)
        print(f"Result: {result}")
    except ValueError as e:
        print(f"Error: {e}")
    except IndexError:
        print("Not enough arguments")

if __name__ == "__main__":
    main()
