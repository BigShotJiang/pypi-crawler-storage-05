from setuptools import setup, find_packages

setup(
    name="scientific-calculator-v1",
    version="0.1.0",
    packages=find_packages(),
    description="A Python package for a scientific calculator",
    author="Sarif Mia",
    author_email="sarifmia.ofc@gmail.com",
    url="https://github.com/sarif-mia/scientific-calculator",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
