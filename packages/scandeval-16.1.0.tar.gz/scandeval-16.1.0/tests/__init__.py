"""Tests for the EuroEval package."""
