"""AWS Security MCP - A comprehensive AWS security inspection and remediation tool."""

__version__ = "0.1.0" 