"""Constants for the MCP Agent auth utilities."""

# Default values
DEFAULT_CREDENTIALS_PATH = "~/.mcp-agent/credentials.json"
