"""MCP Agent Cloud app delete."""

from .main import delete_app

__all__ = ["delete_app"]
