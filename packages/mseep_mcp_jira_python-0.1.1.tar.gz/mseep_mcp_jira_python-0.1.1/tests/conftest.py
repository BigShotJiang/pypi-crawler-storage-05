import os
import sys

# Add src to path for all tests
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))