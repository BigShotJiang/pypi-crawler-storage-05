def main() -> None:
    print("Hello from shinalysis!")
