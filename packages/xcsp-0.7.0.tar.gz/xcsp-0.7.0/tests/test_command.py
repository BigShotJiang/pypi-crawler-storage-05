from xcsp.commands import manage_subcommand
class TestCommand:
    pass