from fabricks.core.scripts.job_schema import get_job_schema

__all__ = ["get_job_schema"]
