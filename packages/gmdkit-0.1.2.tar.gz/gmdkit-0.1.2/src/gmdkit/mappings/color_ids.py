class color_id:
    default = 0
    background = 1000
    ground = 1001
    line = 1002
    line_3d = 1003
    obj_outline = 1004
    player_1 = 1005
    player_2 = 1006
    light_bg = 1007
    ground_2 = 1009
    black = 1010
    white = 1011
    lighter = 1012
    middleground = 1013
    middleground_2 = 1014