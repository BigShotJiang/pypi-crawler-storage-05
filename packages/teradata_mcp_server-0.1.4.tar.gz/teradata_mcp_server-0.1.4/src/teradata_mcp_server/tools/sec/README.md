# Security Tools

**Dependencies**

Assumes Teradata >=17.20.

**Security** tools:

- sec_userDbPermissions - returns permissions that are assigned directly to a user
- sec_rolePermissions - returns permissions that are assigned to a user via that roles
- sec_userRoles - returns a list of roles that a user as assigned


**Security** prompts:

[Return to Main README](../../../../README.md)
