"""Static definitions and resources for MXCP.

This package contains modules for loading and managing static definitions
such as endpoint and evaluation YAML files.
"""
