"""MXCP dbt integration module.

This module provides functionality for dbt integration with MXCP,
including configuration management and wrapper commands.
"""
