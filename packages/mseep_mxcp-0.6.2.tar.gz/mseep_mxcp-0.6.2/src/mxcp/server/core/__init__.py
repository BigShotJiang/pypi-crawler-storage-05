"""Core utilities and types for MXCP.

This package contains fundamental utilities that have no internal dependencies
and are used throughout the application.
"""
