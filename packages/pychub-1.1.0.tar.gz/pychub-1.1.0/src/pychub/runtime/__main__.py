#!/usr/bin/env python3
from runtime.actions.runtime_main import main

if __name__ == "__main__":
    main()
