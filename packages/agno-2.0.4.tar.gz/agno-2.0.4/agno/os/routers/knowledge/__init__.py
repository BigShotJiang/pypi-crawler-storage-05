from agno.os.routers.knowledge.knowledge import get_knowledge_router

__all__ = ["get_knowledge_router"]
