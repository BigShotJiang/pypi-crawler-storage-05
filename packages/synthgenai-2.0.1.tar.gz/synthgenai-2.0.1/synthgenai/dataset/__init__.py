"""Dataset module for SynthGenAI."""

from synthgenai.dataset.dataset import Dataset

__all__ = ["Dataset"]
