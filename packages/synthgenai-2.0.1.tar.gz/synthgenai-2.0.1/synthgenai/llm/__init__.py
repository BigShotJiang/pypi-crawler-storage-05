"""LLM module initialization"""

from synthgenai.llm.llm import LLM

__all__ = ["LLM"]
