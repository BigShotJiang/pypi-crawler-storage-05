# README.md

Auto sync your itemsets, perks and spells with mobalytics.gg ones on champion selection.
