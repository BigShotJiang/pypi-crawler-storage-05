
class Globals():
    def __init__(self) -> None:
        self.data_folder: str = '/data'
        self.detector_port: int = 5004  # NOTE used for tests


GLOBALS = Globals()
