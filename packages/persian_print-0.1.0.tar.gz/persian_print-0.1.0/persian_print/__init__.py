from .core import print_persian, colored_print


