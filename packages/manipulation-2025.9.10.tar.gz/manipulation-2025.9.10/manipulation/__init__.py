# Note: don't import running_as_test here; it will give a copy
# instead of a reference.
from .utils import ConfigureParser, FindResource, running_as_notebook  # noqa
