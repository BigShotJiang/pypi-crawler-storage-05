# `manipulation.station`

```{eval-rst}
.. automodule:: manipulation.station
   :members:
