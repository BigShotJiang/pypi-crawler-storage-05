# `manipulation.remotes`

```{eval-rst}
.. automodule:: manipulation.remotes
   :members:
