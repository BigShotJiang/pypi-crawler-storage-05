class Pipeline:
    def __init__(self):
        pass
