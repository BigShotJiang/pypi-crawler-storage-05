function issues = validate_script(file_name)
issues = {checkcode(file_name).message};