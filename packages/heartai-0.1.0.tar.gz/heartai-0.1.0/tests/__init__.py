"""
Test suite for HeartAI library
"""
