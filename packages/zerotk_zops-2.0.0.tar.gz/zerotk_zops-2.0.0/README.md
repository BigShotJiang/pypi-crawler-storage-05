# zops

# How to run all tests?

```
poetry test
```
