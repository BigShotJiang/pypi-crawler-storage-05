from .flask_tor import run_with_tor

__version__ = '1.1.0'
