.. include:: ../README.rst
   :end-before: doc-inclusion-marker

.. module:: rootfinding

Contents
========

.. toctree::
   :maxdepth: 2

   api
   changelog_link
   license

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
