License
=======

.. include:: ../LICENSE.txt