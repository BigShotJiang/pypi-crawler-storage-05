``bracket_root()``
==================

.. currentmodule:: rootfinding

.. autofunction:: bracket_root
