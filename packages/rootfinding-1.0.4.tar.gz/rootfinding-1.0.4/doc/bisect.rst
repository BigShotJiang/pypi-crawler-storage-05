``bisect()``
============

.. currentmodule:: rootfinding

.. autofunction:: bisect
