API reference
=============

.. toctree::
   :maxdepth: 2
   
   bisect
   bracket_root
   exceptions