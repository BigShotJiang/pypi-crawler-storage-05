Exceptions
==========

.. currentmodule:: rootfinding

.. autoexception:: NotABracketError()
   :show-inheritance:

.. autoexception:: IterationLimitReached()
   :show-inheritance:
