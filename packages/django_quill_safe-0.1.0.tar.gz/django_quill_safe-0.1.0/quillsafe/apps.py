from django.apps import AppConfig

class QuillSafeConfig(AppConfig):
    name = "quillsafe"
    verbose_name = "Quill Safe"
