from .detect_lines import detect_table_with_lines
from .detect_gutter import detect_gutter
from .detect import detect_tables
