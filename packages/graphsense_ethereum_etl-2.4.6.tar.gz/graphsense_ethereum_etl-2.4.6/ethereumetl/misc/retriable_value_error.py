class RetriableValueError(ValueError):
    pass
