"""
XCoding Plugin Python 包测试包
"""