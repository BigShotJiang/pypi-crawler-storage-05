"""QArk Behave - Custom formatter for Behave"""

__version__ = "0.1.0"
__author__ = "Pablo Gibaja"
__email__ = "gibajapablo.dev@gmail.com"

from .formatter import QArkFormatter

__all__ = ["QArkFormatter"]