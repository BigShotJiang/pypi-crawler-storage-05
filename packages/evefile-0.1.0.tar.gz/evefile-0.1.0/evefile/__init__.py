"""evefile package

Transitional package to read eveH5 files containing synchrotron radiometry
data recorded at BESSY/MLS in Berlin.
"""

# Import facade class
from evefile.boundaries.evefile import EveFile  # noqa
