from dotenv import load_dotenv

from configure_logging import configure_logging

load_dotenv()
configure_logging()
