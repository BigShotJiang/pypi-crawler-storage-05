copul.families.other package
============================

Submodules
----------

copul.families.other.asymmetric\_xi\_rho\_si\_copula module
-----------------------------------------------------------

.. automodule:: copul.families.other.asymmetric_xi_rho_si_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.b11 module
-------------------------------

.. automodule:: copul.families.other.b11
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.biv\_independence\_copula module
-----------------------------------------------------

.. automodule:: copul.families.other.biv_independence_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.clamped\_parabola\_copula module
-----------------------------------------------------

.. automodule:: copul.families.other.clamped_parabola_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.diagonal\_band\_copula module
--------------------------------------------------

.. automodule:: copul.families.other.diagonal_band_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.diagonal\_strip\_alpha\_copula module
----------------------------------------------------------

.. automodule:: copul.families.other.diagonal_strip_alpha_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.diagonal\_strip\_alpha\_copula\_numerical module
---------------------------------------------------------------------

.. automodule:: copul.families.other.diagonal_strip_alpha_copula_numerical
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.diagonal\_strip\_alpha\_copula\_visualization module
-------------------------------------------------------------------------

.. automodule:: copul.families.other.diagonal_strip_alpha_copula_visualization
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.diagonal\_strip\_alpha\_copula\_visualization\_pt2 module
------------------------------------------------------------------------------

.. automodule:: copul.families.other.diagonal_strip_alpha_copula_visualization_pt2
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.diagonal\_strip\_alpha\_copula\_visualization\_two\_param module
-------------------------------------------------------------------------------------

.. automodule:: copul.families.other.diagonal_strip_alpha_copula_visualization_two_param
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.farlie\_gumbel\_morgenstern module
-------------------------------------------------------

.. automodule:: copul.families.other.farlie_gumbel_morgenstern
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.footrule\_minus\_xi\_lower\_bound module
-------------------------------------------------------------

.. automodule:: copul.families.other.footrule_minus_xi_lower_bound
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.footrule\_minus\_xi\_minimal\_copula module
----------------------------------------------------------------

.. automodule:: copul.families.other.footrule_minus_xi_minimal_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.frechet module
-----------------------------------

.. automodule:: copul.families.other.frechet
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.independence\_copula module
------------------------------------------------

.. automodule:: copul.families.other.independence_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.lower\_frechet module
------------------------------------------

.. automodule:: copul.families.other.lower_frechet
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.mardia module
----------------------------------

.. automodule:: copul.families.other.mardia
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.optimal\_affine\_jump\_copula module
---------------------------------------------------------

.. automodule:: copul.families.other.optimal_affine_jump_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.pi\_over\_sigma\_minus\_pi module
------------------------------------------------------

.. automodule:: copul.families.other.pi_over_sigma_minus_pi
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.plackett module
------------------------------------

.. automodule:: copul.families.other.plackett
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.raftery module
-----------------------------------

.. automodule:: copul.families.other.raftery
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.rho\_minus\_xi\_maximal\_copula module
-----------------------------------------------------------

.. automodule:: copul.families.other.rho_minus_xi_maximal_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.upper\_frechet module
------------------------------------------

.. automodule:: copul.families.other.upper_frechet
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.wiggly\_copula module
------------------------------------------

.. automodule:: copul.families.other.wiggly_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.other.xi\_max\_rho\_s\_copula module
---------------------------------------------------

.. automodule:: copul.families.other.xi_max_rho_s_copula
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: copul.families.other
   :members:
   :show-inheritance:
   :undoc-members:
