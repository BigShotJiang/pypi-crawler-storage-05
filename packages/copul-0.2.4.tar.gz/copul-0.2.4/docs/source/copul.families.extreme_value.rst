copul.families.extreme\_value package
=====================================

Submodules
----------

copul.families.extreme\_value.bb5 module
----------------------------------------

.. automodule:: copul.families.extreme_value.bb5
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.biv\_extreme\_value\_copula module
----------------------------------------------------------------

.. automodule:: copul.families.extreme_value.biv_extreme_value_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.cuadras\_auge module
--------------------------------------------------

.. automodule:: copul.families.extreme_value.cuadras_auge
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.galambos module
---------------------------------------------

.. automodule:: copul.families.extreme_value.galambos
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.gumbel\_hougaard module
-----------------------------------------------------

.. automodule:: copul.families.extreme_value.gumbel_hougaard
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.huesler\_reiss module
---------------------------------------------------

.. automodule:: copul.families.extreme_value.huesler_reiss
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.joeev module
------------------------------------------

.. automodule:: copul.families.extreme_value.joeev
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.marshall\_olkin module
----------------------------------------------------

.. automodule:: copul.families.extreme_value.marshall_olkin
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.multivar\_ev\_independence\_copula module
-----------------------------------------------------------------------

.. automodule:: copul.families.extreme_value.multivar_ev_independence_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.multivariate\_extreme\_value\_copula module
-------------------------------------------------------------------------

.. automodule:: copul.families.extreme_value.multivariate_extreme_value_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.multivariate\_gumbel\_hougaard module
-------------------------------------------------------------------

.. automodule:: copul.families.extreme_value.multivariate_gumbel_hougaard
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.t\_ev module
------------------------------------------

.. automodule:: copul.families.extreme_value.t_ev
   :members:
   :show-inheritance:
   :undoc-members:

copul.families.extreme\_value.tawn module
-----------------------------------------

.. automodule:: copul.families.extreme_value.tawn
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: copul.families.extreme_value
   :members:
   :show-inheritance:
   :undoc-members:
