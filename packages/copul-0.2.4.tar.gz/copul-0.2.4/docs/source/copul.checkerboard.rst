copul.checkerboard package
==========================

Submodules
----------

copul.checkerboard.bernstein module
-----------------------------------

.. automodule:: copul.checkerboard.bernstein
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.biv\_bernstein module
----------------------------------------

.. automodule:: copul.checkerboard.biv_bernstein
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.biv\_block\_diag\_mixed module
-------------------------------------------------

.. automodule:: copul.checkerboard.biv_block_diag_mixed
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.biv\_check\_min module
-----------------------------------------

.. automodule:: copul.checkerboard.biv_check_min
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.biv\_check\_mixed module
-------------------------------------------

.. automodule:: copul.checkerboard.biv_check_mixed
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.biv\_check\_pi module
----------------------------------------

.. automodule:: copul.checkerboard.biv_check_pi
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.biv\_check\_w module
---------------------------------------

.. automodule:: copul.checkerboard.biv_check_w
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.check module
-------------------------------

.. automodule:: copul.checkerboard.check
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.check\_min module
------------------------------------

.. automodule:: copul.checkerboard.check_min
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.check\_pi module
-----------------------------------

.. automodule:: copul.checkerboard.check_pi
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.checkerboarder module
----------------------------------------

.. automodule:: copul.checkerboard.checkerboarder
   :members:
   :show-inheritance:
   :undoc-members:

copul.checkerboard.shuffle\_min module
--------------------------------------

.. automodule:: copul.checkerboard.shuffle_min
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: copul.checkerboard
   :members:
   :show-inheritance:
   :undoc-members:
