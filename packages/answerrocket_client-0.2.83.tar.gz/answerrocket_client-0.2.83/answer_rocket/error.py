

class AnswerRocketClientError(Exception):
    pass
