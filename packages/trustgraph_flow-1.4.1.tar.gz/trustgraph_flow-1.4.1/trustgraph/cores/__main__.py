
from . service import run

if __name__ == '__main__':
    run()
