# CHANGELOG

## Version 0.2.0 (2025-09-09)

- Add support for `Precision-2` model

## Version 0.1.1 (2025-06-04)

- Allow arbitrary kwargs in `diarize`, `identify` and `voiceprint`

## Version 0.1.0 (2025-03-14)

- *Hello world!*
