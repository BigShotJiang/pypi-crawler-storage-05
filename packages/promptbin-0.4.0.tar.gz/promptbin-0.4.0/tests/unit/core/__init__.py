# Core module tests
