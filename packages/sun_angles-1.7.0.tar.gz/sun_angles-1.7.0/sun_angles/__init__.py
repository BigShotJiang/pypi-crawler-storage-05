from .version import __version__
from .sun_angles import *

__author__ = "Gregory H. Halverson"
