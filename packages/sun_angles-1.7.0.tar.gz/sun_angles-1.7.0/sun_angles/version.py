from os.path import join, abspath, dirname
from importlib.metadata import version

__version__ = version("sun-angles")
