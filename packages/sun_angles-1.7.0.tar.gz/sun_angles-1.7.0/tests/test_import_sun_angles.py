def test_import_sun_angles():
    import sun_angles
