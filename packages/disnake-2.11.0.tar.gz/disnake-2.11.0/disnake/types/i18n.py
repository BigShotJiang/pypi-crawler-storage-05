# SPDX-License-Identifier: MIT

from typing import Dict

LocalizationDict = Dict[str, str]
