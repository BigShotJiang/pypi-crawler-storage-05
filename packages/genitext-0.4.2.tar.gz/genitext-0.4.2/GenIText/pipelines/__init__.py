from .caption import End2EndCaptionPipeline

__all__ = ["End2EndCaptionPipeline"]