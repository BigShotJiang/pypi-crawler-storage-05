"""Docs package."""

from __future__ import annotations

from llmling_agent_docs.root import build, Build

__all__ = ["Build", "build"]
