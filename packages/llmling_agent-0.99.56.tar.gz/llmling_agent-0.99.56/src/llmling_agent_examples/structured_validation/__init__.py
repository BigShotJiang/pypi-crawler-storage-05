"""Example demonstrating structured response types."""

TITLE = "Structured Validation"
ICON = "simple-icons:instructure"
