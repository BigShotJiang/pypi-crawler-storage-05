# Beginning Package

This is a simple package that returns number is primeor not.
