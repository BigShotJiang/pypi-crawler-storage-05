from .is_prime import is_prime
