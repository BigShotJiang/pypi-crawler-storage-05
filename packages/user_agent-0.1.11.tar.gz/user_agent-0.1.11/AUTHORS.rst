UserAgent library is written and maintained by
==============================================

* jamb0ss
* Gregory Petukhov <lorien@lorien.name>
