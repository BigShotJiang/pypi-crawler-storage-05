Getting Started
===============

Installation
------------

.. code-block:: bash

   pip install yourpackage

Basic Usage
-----------

.. code-block:: python

   import yourpackage
   # Basic example code