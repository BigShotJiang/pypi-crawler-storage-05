poulet\_py.hardware.camera.uvctypes module
==========================================

.. automodule:: poulet_py.hardware.camera.uvctypes
   :members:
   :show-inheritance:
   :undoc-members:
