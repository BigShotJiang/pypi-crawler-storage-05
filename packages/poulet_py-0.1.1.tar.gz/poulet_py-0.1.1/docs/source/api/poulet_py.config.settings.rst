poulet\_py.config.settings module
=================================

.. automodule:: poulet_py.config.settings
   :members:
   :show-inheritance:
   :undoc-members:
