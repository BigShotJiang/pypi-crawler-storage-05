from .df2tables import *

__author__ = "Tomasz Slugocki"
__version__ = "0.1.1"
__license__ = "MIT"
VERSION = __version__
