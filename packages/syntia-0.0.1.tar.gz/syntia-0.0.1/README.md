# Syntia

A terminal-based code editor written using [Textual](https://textual.textualize.io/).

## Setup (no pypi yet)

```shell
git clone https://github.com/soumik12345/syntia
cd syntia
uv sync
source .venv/bin/activate
syntia .
```