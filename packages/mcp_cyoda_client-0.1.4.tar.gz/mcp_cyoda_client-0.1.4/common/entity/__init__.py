# Common entity module
