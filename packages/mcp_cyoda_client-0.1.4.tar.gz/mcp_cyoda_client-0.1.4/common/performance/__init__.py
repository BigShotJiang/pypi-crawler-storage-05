"""
Performance monitoring and caching utilities.
"""
