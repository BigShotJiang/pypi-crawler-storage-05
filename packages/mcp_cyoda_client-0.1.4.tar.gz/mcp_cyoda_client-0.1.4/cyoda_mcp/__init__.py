"""
MCP (Model Context Protocol) integration module for Cyoda client.

This module provides FastMCP server functionality with tools for working with Cyoda.
"""
