``fsleyes_widgets.utils.webpage``
=================================

.. automodule:: fsleyes_widgets.utils.webpage
    :members:
    :undoc-members:
    :show-inheritance:
