``fsleyes-widgets`` release history
===================================

.. include:: ../CHANGELOG.rst
