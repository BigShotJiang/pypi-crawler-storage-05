``fsleyes_widgets.utils.typedict``
==================================

.. automodule:: fsleyes_widgets.utils.typedict
    :members:
    :undoc-members:
    :show-inheritance:
