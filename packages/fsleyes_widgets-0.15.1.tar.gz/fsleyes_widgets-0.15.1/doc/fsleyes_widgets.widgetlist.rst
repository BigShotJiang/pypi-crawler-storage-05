``fsleyes_widgets.widgetlist``
==============================

.. automodule:: fsleyes_widgets.widgetlist
    :members:
    :undoc-members:
    :show-inheritance:
