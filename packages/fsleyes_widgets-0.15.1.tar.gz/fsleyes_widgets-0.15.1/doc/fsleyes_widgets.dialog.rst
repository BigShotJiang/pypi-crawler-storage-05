``fsleyes_widgets.dialog``
==========================

.. automodule:: fsleyes_widgets.dialog
    :members:
    :undoc-members:
    :show-inheritance:
