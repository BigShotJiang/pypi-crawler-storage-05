``fsleyes_widgets.widgetgrid``
==============================

.. automodule:: fsleyes_widgets.widgetgrid
    :members:
    :undoc-members:
    :show-inheritance:
