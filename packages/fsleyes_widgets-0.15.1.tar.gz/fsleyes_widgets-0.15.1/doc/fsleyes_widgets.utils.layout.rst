``fsleyes_widgets.utils.layout``
================================

.. automodule:: fsleyes_widgets.utils.layout
    :members:
    :undoc-members:
    :show-inheritance:
