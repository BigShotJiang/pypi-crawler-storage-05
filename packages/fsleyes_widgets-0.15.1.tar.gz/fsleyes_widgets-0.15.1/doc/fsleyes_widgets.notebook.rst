``fsleyes_widgets.notebook``
============================

.. automodule:: fsleyes_widgets.notebook
    :members:
    :undoc-members:
    :show-inheritance:
