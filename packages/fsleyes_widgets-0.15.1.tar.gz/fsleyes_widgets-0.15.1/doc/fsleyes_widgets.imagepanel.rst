``fsleyes_widgets.imagepanel``
==============================

.. automodule:: fsleyes_widgets.imagepanel
    :members:
    :undoc-members:
    :show-inheritance:
