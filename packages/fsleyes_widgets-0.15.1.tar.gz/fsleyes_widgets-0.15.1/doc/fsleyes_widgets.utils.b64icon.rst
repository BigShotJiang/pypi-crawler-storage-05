``fsleyes_widgets.utils.b64icon``
=================================

.. automodule:: fsleyes_widgets.utils.b64icon
    :members:
    :undoc-members:
    :show-inheritance:
