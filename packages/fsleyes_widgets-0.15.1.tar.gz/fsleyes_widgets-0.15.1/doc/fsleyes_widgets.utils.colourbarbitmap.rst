``fsleyes_widgets.utils.colourbarbitmap``
=========================================

.. automodule:: fsleyes_widgets.utils.colourbarbitmap
    :members:
    :undoc-members:
    :show-inheritance:
