``fsleyes_widgets.placeholder_textctrl``
========================================

.. automodule:: fsleyes_widgets.placeholder_textctrl
    :members:
    :undoc-members:
    :show-inheritance:
