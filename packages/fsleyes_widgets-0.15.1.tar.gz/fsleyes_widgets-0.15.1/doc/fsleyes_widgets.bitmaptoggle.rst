``fsleyes_widgets.bitmaptoggle``
================================

.. automodule:: fsleyes_widgets.bitmaptoggle
    :members:
    :undoc-members:
    :show-inheritance:
