``fsleyes_widgets.floatslider``
===============================

.. automodule:: fsleyes_widgets.floatslider
    :members:
    :undoc-members:
    :show-inheritance:
