``fsleyes_widgets.floatspin``
=============================

.. automodule:: fsleyes_widgets.floatspin
    :members:
    :undoc-members:
    :show-inheritance:
