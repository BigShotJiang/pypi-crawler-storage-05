``fsleyes_widgets.colourbutton``
================================

.. automodule:: fsleyes_widgets.colourbutton
    :members:
    :undoc-members:
    :show-inheritance:
