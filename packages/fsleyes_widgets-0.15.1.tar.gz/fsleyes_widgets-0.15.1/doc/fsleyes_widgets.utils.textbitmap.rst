``fsleyes_widgets.utils.textbitmap``
====================================

.. automodule:: fsleyes_widgets.utils.textbitmap
    :members:
    :undoc-members:
    :show-inheritance:
