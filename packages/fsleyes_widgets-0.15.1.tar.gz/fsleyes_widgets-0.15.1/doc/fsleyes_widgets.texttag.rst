``fsleyes_widgets.texttag``
===========================

.. automodule:: fsleyes_widgets.texttag
    :members:
    :undoc-members:
    :show-inheritance:
