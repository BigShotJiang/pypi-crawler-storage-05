``fsleyes_widgets.togglepanel``
===============================

.. automodule:: fsleyes_widgets.togglepanel
    :members:
    :undoc-members:
    :show-inheritance:
