
``fsleyes-widgets``
===================

.. toctree::
   :hidden:

   fsleyes_widgets
   fsleyes_widgets.utils
   changelog


The `fsleyes-widgets` package contains a collection of GUI widgets and
utilities, based on `wxPython <http://www.wxpython.org>`_. These widgets are
used by `fsleyes-props` and `fsleyes`.
