``fsleyes_widgets.textpanel``
=============================

.. automodule:: fsleyes_widgets.textpanel
    :members:
    :undoc-members:
    :show-inheritance:
