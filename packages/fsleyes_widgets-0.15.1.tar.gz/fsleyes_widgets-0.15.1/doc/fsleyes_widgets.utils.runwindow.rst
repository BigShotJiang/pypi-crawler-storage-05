``fsleyes_widgets.utils.runwindow``
===================================

.. automodule:: fsleyes_widgets.utils.runwindow
    :members:
    :undoc-members:
    :show-inheritance:
