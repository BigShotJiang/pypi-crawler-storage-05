``fsleyes_widgets.autotextctrl``
================================

.. automodule:: fsleyes_widgets.autotextctrl
    :members:
    :undoc-members:
    :show-inheritance:
