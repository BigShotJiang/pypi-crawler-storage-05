``fsleyes_widgets.utils.status``
================================

.. automodule:: fsleyes_widgets.utils.status
    :members:
    :undoc-members:
    :show-inheritance:
