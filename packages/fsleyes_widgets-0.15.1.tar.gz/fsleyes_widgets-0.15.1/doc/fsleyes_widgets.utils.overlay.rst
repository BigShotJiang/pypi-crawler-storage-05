``fsleyes_widgets.utils.overlay``
=================================

.. automodule:: fsleyes_widgets.utils.overlay
    :members:
    :undoc-members:
    :show-inheritance:
