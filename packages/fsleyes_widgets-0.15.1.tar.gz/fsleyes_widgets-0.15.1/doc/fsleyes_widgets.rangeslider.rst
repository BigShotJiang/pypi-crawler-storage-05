``fsleyes_widgets.rangeslider``
===============================

.. automodule:: fsleyes_widgets.rangeslider
    :members:
    :undoc-members:
    :show-inheritance:
