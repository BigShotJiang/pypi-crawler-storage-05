``fsleyes_widgets.numberdialog``
================================

.. automodule:: fsleyes_widgets.numberdialog
    :members:
    :undoc-members:
    :show-inheritance:
