``fsleyes_widgets.bitmapradio``
===============================

.. automodule:: fsleyes_widgets.bitmapradio
    :members:
    :undoc-members:
    :show-inheritance:
