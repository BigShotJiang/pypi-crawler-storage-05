``fsleyes_widgets``
===================

.. toctree::
   :hidden:

   fsleyes_widgets.autotextctrl
   fsleyes_widgets.bitmapradio
   fsleyes_widgets.bitmaptoggle
   fsleyes_widgets.colourbutton
   fsleyes_widgets.dialog
   fsleyes_widgets.elistbox
   fsleyes_widgets.floatslider
   fsleyes_widgets.floatspin
   fsleyes_widgets.imagepanel
   fsleyes_widgets.notebook
   fsleyes_widgets.numberdialog
   fsleyes_widgets.placeholder_textctrl
   fsleyes_widgets.rangeslider
   fsleyes_widgets.textpanel
   fsleyes_widgets.texttag
   fsleyes_widgets.togglepanel
   fsleyes_widgets.widgetgrid
   fsleyes_widgets.widgetlist

.. automodule:: fsleyes_widgets
    :members:
    :undoc-members:
    :show-inheritance:
