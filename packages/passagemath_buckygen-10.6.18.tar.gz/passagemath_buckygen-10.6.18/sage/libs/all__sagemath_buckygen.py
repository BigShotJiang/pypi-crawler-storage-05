# sage_setup: distribution = sagemath-buckygen
