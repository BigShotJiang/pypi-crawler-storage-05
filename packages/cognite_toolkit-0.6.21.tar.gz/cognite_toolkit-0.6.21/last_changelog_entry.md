## cdf 

### Improved

- Warning on syntax errors when running `cdf build` for resources types
containers, views, extraction pipeline, extraction pipeline conig,
workflow, workflow version, workflow trigger, and datapoint
subscriptions.

## templates

No changes.