SignalCliJSONRPCApi
===================

.. autoclass:: pysignalclijsonrpc.SignalCliJSONRPCApi
   :members:
   :private-members:
