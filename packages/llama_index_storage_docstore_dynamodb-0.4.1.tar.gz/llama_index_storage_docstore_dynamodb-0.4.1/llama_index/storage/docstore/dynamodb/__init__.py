from llama_index.storage.docstore.dynamodb.base import DynamoDBDocumentStore

__all__ = ["DynamoDBDocumentStore"]
