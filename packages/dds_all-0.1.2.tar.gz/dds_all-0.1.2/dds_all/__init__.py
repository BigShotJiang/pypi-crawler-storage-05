# __init__.py
from DDS_All import *
