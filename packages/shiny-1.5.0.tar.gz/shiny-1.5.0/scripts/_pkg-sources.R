list(
  bslib = "rstudio/bslib@main",
  shiny = "rstudio/shiny@main",
  sass = "sass",
  htmltools = "rstudio/htmltools@main"
)
