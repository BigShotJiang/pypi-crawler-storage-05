# -*- coding: utf-8 -*-

from .runner import HtmlTestRunner

__all__ = (HtmlTestRunner, )
