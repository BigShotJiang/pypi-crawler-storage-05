
class InvalidChartType(Exception):
    pass
