class BytePrintStyle:
    RED = "\033[31m"
    GREEN = "\033[32m"
    BLUE = "\033[34m"
    ORANGE = "\033[38;5;214m"
    RESET = "\033[0m"