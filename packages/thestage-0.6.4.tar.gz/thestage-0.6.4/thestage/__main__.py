import thestage.main as main


def start():
    main.main()


if __name__ == "__main__":
    start()
