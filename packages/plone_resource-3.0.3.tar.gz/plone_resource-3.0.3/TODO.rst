plone.resource to-do
--------------------

 [ ] Finish README documentation

 [ ] Implement IRawReadFile for in-ZODB files
 [ ] Implement IRawWriteFile for in-ZODB files

 [ ] Make in-ZODB files blob-backed

 [ ] Make stable resource urls possible, e.g. ++theme++my.theme++12345
