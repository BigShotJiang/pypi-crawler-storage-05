from epub_chapterize.chapterize import chapterize

print("EpubChapterize package imported successfully.")

print(chapterize("/Users/matthewgrant/Source/EpubChapterize/epub_chapterize/books/archive/Alice-In-Wonderland-En.epub"))