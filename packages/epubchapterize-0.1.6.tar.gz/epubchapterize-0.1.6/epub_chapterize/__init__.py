# __init__.py
from .chapterize import chapterize

__all__ = ["chapterize"]