# CHANGELOG


## v0.0.1 (2025-09-09)

### Bug Fixes

- Tear down client atexit; add tests
  ([`2e15c73`](https://github.com/bec-project/pylsp_bec/commit/2e15c73811674750555d480a6a44e730079fd964))

### Chores

- Add license
  ([`e7918dd`](https://github.com/bec-project/pylsp_bec/commit/e7918dd17e0d139c2607517a675fc2826a432f3d))

### Continuous Integration

- Add workflows
  ([`560d4e4`](https://github.com/bec-project/pylsp_bec/commit/560d4e4d03e2c4453de0f2d099fd4ade3dcf282c))
