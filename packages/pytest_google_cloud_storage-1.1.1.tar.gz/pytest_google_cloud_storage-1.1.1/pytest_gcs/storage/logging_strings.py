GCP_CREDENTIALS_ENV_VAR_NOT_SET =  ("Trying to disable 'GOOGLE_APPLICATION_CREDENTIALS'... "
                                    "No such environment variable existing.")
