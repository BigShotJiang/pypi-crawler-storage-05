This module provides online bank statements from
[PayPal.com](https://paypal.com/).
