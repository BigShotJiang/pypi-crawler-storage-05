To use this module:

1. Go to Sales > To Invoice or Sales > Orders (list view).
2. Select one or more confirmed sale orders.
3. From the list view, select the sales orders and choose Action > Create Invoices.
4. In the wizard:
    * Select the invoice date.
    * Select the pickings to invoice.
5. The invoices created will use the selected invoice date, even when specific pickings are selected.
