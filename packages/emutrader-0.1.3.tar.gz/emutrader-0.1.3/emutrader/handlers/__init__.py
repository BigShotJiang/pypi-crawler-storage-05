"""
Account handlers for different trading account types.

This package contains handlers for STOCK, FUTURE, CREDIT, and OPTION accounts.
"""