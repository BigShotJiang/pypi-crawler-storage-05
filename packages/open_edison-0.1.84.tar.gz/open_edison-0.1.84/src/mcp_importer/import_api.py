# legacy helpers were removed to satisfy deadcode scanning
