"""Type helpers for MCP importer."""

# This module intentionally minimal to avoid unused code flags.
