# TW3

::: ggsci.palettes
    options:
      members:
        - pal_tw3
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_tw3
        - scale_colour_tw3
        - scale_fill_tw3
      show_root_heading: true
      show_source: false
