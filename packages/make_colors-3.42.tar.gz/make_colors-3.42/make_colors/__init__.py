from .make_colors import make_colors, MakeColors, make_color

from . import __version__ as version
__version__ 	= version.version
__email__		= "cumulus13@gmail.com"
__author__		= "cumulus13@gmail.com"