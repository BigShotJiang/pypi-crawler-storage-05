from .protocol import Protocol
from .singleton import ProtobinLoader