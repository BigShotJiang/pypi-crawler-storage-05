"""A module for handling responses for functions, methods, and classes in Bear Utils."""

from .function_response import FunctionResponse

__all__ = ["FunctionResponse"]
