"""
Implementation of Kiota Serialization interfaces for text/plain
"""
from ._version import VERSION

__version__ = VERSION
