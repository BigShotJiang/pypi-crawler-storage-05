import importlib.metadata

VERSION: str = importlib.metadata.version('microsoft-kiota-serialization-text')
