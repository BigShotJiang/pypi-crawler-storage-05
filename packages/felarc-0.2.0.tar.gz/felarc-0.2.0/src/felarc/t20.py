from math import pi

ARC_ANGLE_DEG = 6.0
ARC_ANGLE_RAD = ARC_ANGLE_DEG * pi / 180
