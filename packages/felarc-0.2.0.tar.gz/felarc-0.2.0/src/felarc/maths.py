import numpy as np

def cot(x):
    return 1 / np.tan(x)
