"""
Module responsible for managing all objects that serve as a foundation for other objects.
"""
