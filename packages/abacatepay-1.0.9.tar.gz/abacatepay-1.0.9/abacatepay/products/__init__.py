from .models import Product

__all__ = ['Product']
