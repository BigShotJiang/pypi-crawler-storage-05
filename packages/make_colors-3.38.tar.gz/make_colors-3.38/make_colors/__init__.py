from .make_colors import make_colors

from . import __version__ as version
__version__ 	= version.version
__email__		= "licface@yahoo.com"
__author__		= "licface@yahoo.com"