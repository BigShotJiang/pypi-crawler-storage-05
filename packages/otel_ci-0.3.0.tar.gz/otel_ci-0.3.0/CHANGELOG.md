# Changelog

## [0.3.0](https://github.com/uptick/otel-ci/compare/v0.2.0...v0.3.0) (2025-09-11)


### Features

* add head_ref to resource_attributes ([f3747ed](https://github.com/uptick/otel-ci/commit/f3747ed1dd9b32a9558acf8cb58ed7c323189e6a))

## [0.2.0](https://github.com/uptick/otel-ci/compare/v0.1.2...v0.2.0) (2025-01-22)


### Features

* correctly forward the exit code ([9367814](https://github.com/uptick/otel-ci/commit/9367814cf9c892706e9d47850585ca632880f720))

## [0.1.2](https://github.com/uptick/otel-ci/compare/v0.1.1...v0.1.2) (2024-12-16)


### Bug Fixes

* inject the shell when adding traceid ([62fc9fb](https://github.com/uptick/otel-ci/commit/62fc9fbabfbf86d7efa8519638a1e9155c540f90))

## [0.1.1](https://github.com/uptick/otel-ci/compare/v0.1.0...v0.1.1) (2024-12-14)


### Bug Fixes

* modify ci pipeline ([a3f9b4b](https://github.com/uptick/otel-ci/commit/a3f9b4b1b4972249886c0f446661063a1b83e721))

## 0.1.0 (2024-12-14)


### Features

* add ci pipelines and fix broken resource attributes ([31812da](https://github.com/uptick/otel-ci/commit/31812da23959e666f21eac33af92ba5eb6775fdd))
