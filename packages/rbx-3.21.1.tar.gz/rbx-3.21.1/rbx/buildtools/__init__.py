REGISTRY = "474071279654.dkr.ecr.eu-west-1.amazonaws.com"
REGION = "eu-west-1"
CONFIGURATIONS = "s3://474071279654-eu-west-1-configurations"
