"""MCP Registry CLI - A command-line interface for navigating the MCP registry."""

__version__ = "0.2.0"
__author__ = "Loreto Parisi"
__email__ = "loretoparisi@gmail.com"