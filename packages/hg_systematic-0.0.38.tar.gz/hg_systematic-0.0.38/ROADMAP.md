Roadmap
=======

This is a list of features / tasks that are planned for future releases and
an idea of time-lines. The exact order of delivery may change as interest dictates.

0.1.0
-----

A set of simple examples.

