.. role:: small
.. role:: smaller

Release Notes
=============


Version 1.0 :small:`March 21, 2025`
-----------------------------------
First alpha release of TemporalVAE.
