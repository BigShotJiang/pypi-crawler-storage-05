---
name: Bug report
about: scVelo doesn’t do what it should? Please help us fix it!
title: ""
labels: bug
assignees: ""
---

<!-- Description of the bug -->

...

<!-- Reproducible example -->

```python
# paste your code here, if applicable
```

<!-- Error Output -->
<details>

<summary> Error output </summary>

```pytb
# paste the error output here, if applicable
```

</details>

<!-- Versions -->
<details> <summary> Versions </summary>

```pytb
# paste the ouput of scv.logging.print_versions() here
```

</details>
