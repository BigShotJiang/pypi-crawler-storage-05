"""This file allows the cli to be called as a module or via the dir."""

from autoverify.cli.main import main

main()
