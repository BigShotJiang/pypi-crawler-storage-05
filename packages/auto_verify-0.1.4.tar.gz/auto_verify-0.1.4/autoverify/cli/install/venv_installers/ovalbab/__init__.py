"""ovalbab venv installer package."""

from .venv_install import VenvOvalBabRepoInfo, install

__all__ = ["install", "VenvOvalBabRepoInfo"]