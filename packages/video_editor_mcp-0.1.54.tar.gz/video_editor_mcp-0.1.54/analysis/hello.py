def main():
    print("Hello Miles!")
    print("Hello Benji!")


def final():
    print("goodbye bros!")


if __name__ == "__main__":
    main()
    main()
    main()
    final()
