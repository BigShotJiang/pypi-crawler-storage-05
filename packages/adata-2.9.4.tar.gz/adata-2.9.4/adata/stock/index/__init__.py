# -*- coding: utf-8 -*-
"""
@desc: 指数相关数据
@author: 1nchaos
@time:2022/9/19
@log: 
"""
from adata.stock.index.cal_index import CalIndex


class Index(CalIndex):

    def __init__(self) -> None:
        super().__init__()


index = Index()
