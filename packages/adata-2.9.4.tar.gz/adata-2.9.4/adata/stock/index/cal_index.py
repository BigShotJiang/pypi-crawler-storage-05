# -*- coding: utf-8 -*-
"""
@desc: 指标计算 TODO
@author: 1nchaos
@time: 2023/5/23
@log: change log
"""


class CalIndex(object):

    def __init__(self) -> None:
        super().__init__()
