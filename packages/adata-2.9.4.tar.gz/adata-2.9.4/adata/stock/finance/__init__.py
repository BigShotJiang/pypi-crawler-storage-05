# -*- coding: utf-8 -*-
"""
@desc: 财务数据

@author: 1nchaos
@time: 2024/9/3
@log: change log
"""
from adata.stock.finance.core import Core


class Finance(Core):

    def __init__(self) -> None:
        super().__init__()


finance = Finance()
