# -*- coding: utf-8 -*-
"""
@desc: readme
@author: 1nchaos
@time: 2023/6/19
@log: change log
"""
from adata.stock.market.stock_market.stock_market import StockMarket

