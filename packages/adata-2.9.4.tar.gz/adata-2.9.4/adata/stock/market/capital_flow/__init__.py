# -*- coding: utf-8 -*-
"""
@desc:
@author: 1nchaos
@time:2023/8/3
@log:
"""
from adata.stock.market.capital_flow.stock_capital_flow import StockCapitalFlow
