# -*- coding: utf-8 -*-
"""
@desc: 
@author: 1nchaos
@time: 2023/8/6
@log: change log
"""
from adata.stock.market.index_market.market_index import StockMarketIndex
