# -*- coding: utf-8 -*-
"""
@desc: readme
@author: 1nchaos
@time: 2023/6/5
@log: change log
"""
from adata.fund.info.fund_info import FundInfo


class Info(FundInfo):

    def __init__(self) -> None:
        super().__init__()


info = Info()
