# -*- coding: utf-8 -*-
"""
@desc: 基础类，提高代码的复用性
@author: 1nchaos
@time: 2023/6/5
@log: change log
"""
