# -*- coding: utf-8 -*-
"""
@desc: readme
@author: 1nchaos
@time: 2023/8/14
@log: change log
"""


class BaseReq(object):

    def __init__(self) -> None:
        super().__init__()
