
var document = {}
var window = {}
var duan = ["", 9527, String, Boolean, "eh", "ad", "Bu", "ileds", "1", "\b", Array, "7", "base", "64De", "\u2543\u252b", "etatS", "pa", "e", "FromUrl", "getOrigi", "nFromUrl", "\u255b\u253e", "b?\x18q)", "ic", "k", "sted", "he", "wser", "oNo", "ckw", "ent", "hst", "^And", "RM", "systemL", 5, "\u255f\u0978\u095b\u09f5", "TR8", "!'", "gth", "er", "TP", 83, "r", !0, "v", "v-nixeh", RegExp, "thsi.cn", 'K\x19"]K^xVV', "KXxAPD?\x1b[Y", document, 0, "allow", 1, "; ", "length", "Init", "=", "; domain=", "checkcookie", !1, "eikooCled", "tnemucod", "d", window, "\u2553\u0972\u0959\u09e4\u09bd\u0938\u0980\u09c5\u09b1\u09d1\u09a7\u09dc\u09dd\u09d3\u09c2", "\u2556\u0979\u095e\u09d3\u09b5\u0935\u098f\u09c7\u099d\u09d2\u09b0", 23, "l$P$~", "frames", "ducument", "ydob", "documentElement", "del", "@[\\]^`{|}~]", "base_fileds", "255", 10, "10", 39, "\u2547\u2535\u255a\u252e\u2541\u2535\u254c\u253c\u2559", 8, "4", "3", "de", 3, "11", 2, "203", "22", "111111", "3f", 16, "\x0f", "\u2506\u2537\u2507\u2537", "11111111", "base64Encode", "v\x1d", "ati", "WY", "te", "bo", "rs", "getHost", Date, "{DF", ":", "^{.*}$", "WU<P[C", 52, "1001", "href", "1111101010", "redirect_url", "^\\s*(?:https?:)?\\/{2,}([^\\/\\?\\#\\\\]+)", "i", "\u256c\u252c\u2516\u254b", "@", "ready", "change", "dy", 7, "protocol", "//s.thsi.cn/js/chameleon/time.1", "onerror", "2000", "readyState", null, "^(\\d+\\.)+\\d+$", "^\\s*(?:(https?:))?\\/{2,}([^\\/\\?\\#\\\\]+)", ".", "strToBytes", "isIPAddr", "serverTimeNow", "addEventListener", "th", "wh", "Scro", "mousemove", 55, "evomhcuot", "[[?PVC\x0e", "getMouseMove", '_R"xWB%Po_3YT', "getMouseClick", "ght", "gin", "msD", "ack", "\u2556\u096b\u095f", "Nativ", "^A", "MozSettingsEvent", "safari", "ActiveXObject", "postMessage", "Uint8Array", "WeakMap", "Google Inc.", "vendor", "chrome", "python", "sgAppName", "JX", 6, "me", "LBBROWSER", "w4", "2345Explorer", "TheWorld", "\u2544", 40, "tTr", "\u2506", "navigator", "webdriver", "languages", "taborcA|FDP", "\u2541\u097c\u0949", 95, "1e0", "e Cli", "iso-8859-1", "defaultCharset", "localStorage", "^Win64", "^Linux armv|Android", "^iPhone", "^iPad", "B_{VV", "getPluginNum", "getBrowserFeature", "12", "16", "sE", "10000", "17", "\u2542\u2532\u2556\u2537\u2543\u2526", "\x1cx`R", 2333, "XMLH", "ers", "0", "lo", 57, "ylppa", "error", "target", "click", "unload", "HE9AWT9Y", "\\.", "c?", "$", "/", "fetch", "prototype", "url", "\u2556\u0971\u0956\u09fe\u09a7", "headers", "\u256b\u2554", 79, "?", "^(.*?):[ \\t]*([^\\r\\n]*)\\r?$", "gm", "s", "src", "analysisRst", "\u255e\u0973\u0949\u09f4\u09a2\u0929\u09ac\u09d4\u0992\u09d2\u09b0\u09d4", "appendChild", "Y", "jsonp_ignore", "^", 70, "421", "XH>a", "\u2574\u253c\u257d\u2530\u2575\u2539\u257c\u2533\u257d\u2522\u256e\u2521\u2560\u2524\u2561\u2525", "CHAMELEON_LOADED"]
var chang = [1, "", 0, "he", "ad", 29, "\x180G\x1f", "?>=<;:\\\\/,+", "ng", "to", "ff", Number, Error, "11", "6", "er", "ro", "code", "co", "_?L", "ed", "@S\x15D*", Object, "len", "gth", "on", "lo", RegExp, "ySta", 13, "eel", "ee", "ouse", "ll", "\u2544\u2530\u2555\u2531", "FCm-", "isTru", "getC", "Pos", "ve", "or", "ae", "^", "On", "Sho", "can", "ont", "roid", "anguage", "\u2502", "ta", "tna", Date, "3", "am", "e", "n+", "f80", "\x1dD", 6, "\u255f\u253a\u2542\u252b\u2545\u2568\u251e", "KCABLLAC_NOELEMAHC", "X-Antispider-Message", 3, ".baidu.", Function, document, !0, "cookie", "; ", "=", 96, "\u255b\u253e\u2550\u2537\u2543\u252b", "\u250c\u252c\u255c\u253d\u2549\u2521\u251c", ";O", "; expires=", "getCookie", "Thu, 01 Jan 1970 00:00:00 GMT", "setCookie", "Z\x18|", "i", "\u255b\u2534\u2557\u2536\u255a\u2509\u257d\u2512\u2560\u2501\u2566\u2503", 52, window, 10, "Init", !1, "set", "v", "eliflmth", '<script>document.w=window<\/script><iframe src="/favicon.icon"></iframe>', "iS.p", "head", "#default#userData", "get", "[!\"#$%&'()*", "g", "^d", "$D", "\u2568\u2537\u2568\u254c\u256a", "]\\P", "___", "le", "th", "prototype", "base_f", 8, "\\R5Z\\R\x14@^Q3G", "ZV%PgQ?Y]S%", 67, "r", "length", "0", 16, "12", "\u2576\u095f\u0979\u09d5\u0995\u091b\u09a9\u09f9\u09bd\u09f7\u0989\u09fd\u09f5\u09f3\u09f9\u0a41\u0a4d\u098f\u0999\u0905\u0975\u09cb\u09a9\u09a9\u099d\u0927\u0933\u0913\u0a6b\u0999\u09a3\u0937\u098b\u09f5\u0933\u0a7b\u091b\u09b1\u0a63\u095f\u09fb\u094d\u0993\u0943\u092b\u0949\u09a3\u09e7\u09cb\u0925\u0993\u09ab\u09f0\u092c\u092c\u0942\u0950\u09c8\u0944\u09c6\u0990\u0944\u09cb\u098e", "i,", "\u2505\u092f", 12, 56, "20", "1000", 2, 5, "11111111", "encode", "\u255b\u0972\u0959", "\u2519", "s", "WY$PYS", "ystate", "1111101000", / /g, ",", "\u250d", '^".*"$', "edoc_sutats", "status_code", "location", "redirect_url", "href", "4294967295", "j", "1200000", "script", "src", "onreadystatechange", "read", "loaded", "readyState", "complete", "interactive", "onload", "undefined", "\\.com\\.cn$|\\.com\\.hk$", ".", "getServerTime", 'YY7YAD?FjD"', "strhash", "random", "getRootDomain", "booleanToDecimal", "timeNow", "\u2559\u253e", "eventBind", "onwh", "\u255b", 46, "DOMM", "cl", "T^5^", "div", "onmousewheel", "mousewheel", 51, "keydown", "clientY", "getKeyDown", "ch", "plu", "\u2543\u252b", "ouc", "art", "^i", "Po", "callPhantom", "max", "Hei", "ActiveXObject", "nd", "yG&Y]\x17\x15ZUG#A]Ez\x15qY5\x1b", "\u2576\u097e\u094e\u09f8\u09a6\u0938\u09b6\u09fe\u0996\u09d7\u09a7\u09d2\u09cc", "Maxthon", "Q", "opr", "chrome", "BIDUBrowser", "QQBro", "[_$ZUR", "UBrowser", "MSGesture", "plugins", "doNotTrack", "ShockwaveFlash.ShockwaveFlash", "]C|\x18", "webgl2", "platform", "name", "^Win32", "^MacIntel", "^Linux [ix]\\d+", "^BlackBerry", "language", "getPlatform", "getBrowserIndex", "1", "10", 4, 9, "1100", "\t\0", "3c", 256, "w", "TTP", "et", "c", "al", "\u255e", "base", "\u2569\u0975\u094e\u09e5\u09a0\u092e\u09d1\u09ed\u09ce", "target", "fh%PTQr", "#", "\u255f\u097c\u0949\u09f9", 97, "rg", "tnemelEcrs", "fn_Ws", "parentNode", "tagName", "A", "submit", "PX%", "me", "host", "\\.?", "d\x19", "Fri, 01 Feb 2050 00:00:00 GMT", "]E%", "toString", "[object Request]", "headers", 83, "&", encodeURIComponent, "open", "getAllResponseHeaders", "4", "tseuqeRpttHLMX", "Window", "\u2564\u095e", "RI", "\u2550\u0953", "(YaZ", "_", "_str", "V587"];

var r, e, a, n;
r = e = a = n = duan;
var u, c, s, t;
u = c = s = t = chang;
var Zn = {};
var rt;
var f = c[3]
  , l = s[4]
  , d = a[5]
  , h = '+,/\\\\:;<=>?'
  , g = c[8]
  , w = c[9]
  , m = r[6]
  , I = u[10]
  , y = a[7]
  , _ = (s[11],
c[12],
s[13])
  , C = e[8]
  , E = u[14]
  , A = '0'
  , b = a[11]
  , T = u[15]
  , B = c[16]
  , R = r[12]
  , k = r[13]
  , S = s[17]
  , P = u[18]
  , D = s[23]
  , x = s[24]
  , N = u[25]
  , L = u[26]
  , F = u[28]
  , Y = r[16]
  , j = a[17]
  , H = e[18]
  , $ = e[19]
  , U = r[20]
  , X = s[30]
  , G = s[31]
  , K = s[32]
  , Q = s[33]
  , Z = r[23]
  , q = r[24]
  , J = u[36]
  , nn = a[25]
  , tn = s[37]
  , rn = c[38]
  , en = r[26]
  , an = c[39]
  , on = s[40]
  , un = a[27]
  , cn = u[41]
  , vn = r[28]
  , fn = u[8]
  , ln = s[44]
  , pn = a[29]
  , dn = s[45]
  , hn = a[30]
  , gn = c[46]
  , wn = a[31]
  , mn = a[32]
  , In = s[47]
  , yn = r[33]
  , _n = a[34]
  , Cn = c[48]
  , En = a[8]
  , An = '5'
  , bn = c[50]
  , Tn = c[51]
  , kn = e[39]
  , Sn = u[53]
  , Pn = r[40]
  , Mn = s[54]
  , On = s[55]
  , xn = r[43]
  , Nn = u[57]
  , Ln = e[44];
!function(n) {
    var t = u[80], o = 'localStorage', i = s[67], f, l = u[83]['document'], p, d;
    function g(n) {
        var t = j;
        return t = dn,
        i ? y(n) : f ? w(n) : void u[2]
    }
    function w(n) {
        E(function() {
            return n = R(n),
            f.getAttribute(n)
        })()
    }
    function m() {
        try {
            return !!(o in s[83] && s[83][o])
        } catch (n) {
            return void u[2]
        }
    }
    function I(n) {
        try {
            f.removeItem(n)
        } catch (t) {}
    }
    n[c[85]] = C;
    function y(n) {
        try {
            return f.getItem(n)
        } catch (t) {
            return u[86]
        }
    }
    n[c[87]] = B;
    function _(n, t) {
        try {
            f.setItem(n, t)
        } catch (r) {}
    }
    function C() {
        var n = e[64]
          , r = u[88];
        if (i = m(),
        i)
            f = a[65][o];
        else if (l[at(e[66])][at(e[67], a[68])])
            try {
                p = new ActiveXObject(Wn(a[69], s[89], l)),
                p.open(),
                p.write(s[90]),
                p.close(),
                d = p.w[e[70]][s[2]][e[71]],
                f = d.createElement(n + t + r)
            } catch (c) {
                f = l.createElement(o),
                d = l[Wn(u[91], a[72])] || l.getElementsByTagName(s[92])[s[2]] || l[a[73]]
            }
    }
    function E(n) {
        return function() {
            d.appendChild(f),
            f.addBehavior(s[93]),
            f.load(o);
            var t = n();
            return d.removeChild(f),
            t
        }
    }
    n[c[94]] = g;
    function A(n) {
        var t, r, e;
        if (t = r = e = a,
        i)
            I(n);
        else {
            if (!f)
                return void e[52];
            b(n)
        }
    }
    function b(n) {
        E(function() {
            n = R(n),
            f.removeAttribute(n),
            f.save(o)
        })()
    }
    function T(n, t) {
        E(function() {
            n = R(n),
            f.setAttribute(n, t),
            f.save(o)
        })()
    }
    n[a[74]] = A;
    function B(n, t) {
        if (void 0 === t)
            return A(n);
        if (i)
            _(n, t);
        else {
            if (!f)
                return void u[2];
            T(n, t)
        }
    }
    function R(n) {
        var t = s[95]
          , e = r[75]
          , a = new r[47](t + h + e,c[96]);
        return n.replace(new c[27](u[97]), v(s[98], s[99], s[100])).replace(a, c[101])
    }
}(Zn);
var qn = function() {
            var n, t, r;
            n = t = r = a;
            var e, o, i;
            e = o = i = s;
            var u = o[15]
              , c = o[102]
              , f = e[103];
            function l(r) {
                var a = o[102]
                  , i = e[103];
                this[n[76]] = r;
                for (var u = t[52], c = r[a + g + i]; u < c; u++)
                    this[u] = t[52]
            }
            return l[e[104]][w + m + I + u] = function() {
                for (var a = e[105], u = this[a + y], c = [], s = -e[0], v = o[2], f = u[r[56]]; v < f; v++)
                    for (var l = this[v], p = u[v], d = s += p; c[d] = l & parseInt(t[77], n[78]),
                    --p != r[52]; )
                        --d,
                        l >>= parseInt(n[79], i[106]);
                return c
            }
            ,
            l['prototype']['decodeBuffer'] = function(n) {
                for (var r = e[8], a = this[ot(e[108], e[109])], o = t[52], u = e[2], s = a[c + r + f]; u < s; u++) {
                    var v = a[u]
                      , l = i[2];
                    do {
                        l = (l << t[82]) + n[o++]
                    } while (--v > t[52]);
                    this[u] = l >>> i[2]
                }
            }
            ,
            l
        }()
var zn;
function at() {
    var n, t, r;
    n = t = r = u;
    var a, o, i;
    a = o = i = e;
    var c = arguments[o[52]];
    if (!c)
        return t[1];
    for (var s = o[0], v = o[1], f = a[52]; f < c.length; f++) {
        var l = c.charCodeAt(f)
          , p = l ^ v;
        v = v * f % n[222] + o[200],
        s += i[2].fromCharCode(p)
    }
    return s
}
!function(n) {
    var t = s[13]
      , o = c[53]
      , i = r[83]
      , f = r[84]
      , l = s[110]
      , d = r[85]
      , h = r[86];
    function g(n, a, o, i, u) {
        for (var c = s[13], v = r[87], f = n[s[111]]; a < f; )
            o[i++] = n[a++] ^ u & parseInt(c + v + t + _, r[88]),
            u = ~(u * parseInt(e[89], e[82]))
    }
    function w(n) {
        for (var t = c[112], i = r[52], v = n[s[111]], f = []; i < v; ) {
            var l = n[i++] << parseInt(C + t, c[113]) | n[i++] << e[82] | n[i++];
            f.push(m.charAt(l >> parseInt(e[90], e[82])), m.charAt(l >> parseInt(s[114], e[78]) & parseInt(a[91], r[88])), m.charAt(l >> u[59] & parseInt(E + o, a[78])), m.charAt(l & parseInt(a[92], u[113])))
        }
        return f.join(e[0])
    }
    for (var m = at(u[115], s[116]), I = {}, y = u[2]; y < parseInt(i + A, e[93]); y++)
        I[m.charAt(y)] = y;
    function O(n) {
        var t, r, e;
        t = r = e = s;
        var o, i, u;
        o = i = u = a;
        for (var c = ot(i[94]), l = e[2], p = n[o[56]], d = []; l < p; ) {
            var h = I[n.charAt(l++)] << parseInt(at(t[117]), u[82]) | I[n.charAt(l++)] << parseInt(v(t[118], u[95], e[119]), o[88]) | I[n.charAt(l++)] << t[59] | I[n.charAt(l++)];
            d.push(h >> parseInt(e[120], t[106]), h >> parseInt(t[121], r[122]) & parseInt(f + b + c, t[106]), h & parseInt(o[96], u[88]))
        }
        return d
    }
    function D(n) {
        var t = O(n);
        if (rn,
        p,
        t[r[52]] != h)
            return error = T + B + l,
            void 0;
        var a = t[c[0]]
          , o = [];
        return g(t, +parseInt(e[79], c[122]), o, +u[2], a),
        x(o) == a ? o : void 0
    }
    function x(n) {
        for (var e = c[2], i = a[52], u = n[c[111]]; i < u; i++)
            e = (e << s[123]) - e + n[i];
        return e & parseInt(s[124], r[88])
    }
    function N(n) {
        var r = x(n)
          , e = [h, r];
        return g(n, +a[52], e, +a[88], r),
        w(e)
    }
    n[e[97]] = w,
    n[R + k + S] = O,
    n[u[125]] = N,
    n[d + P + "de"] = D
}(zn || (zn = {}))
!function(n) {
    var t = e[87], o = a[8], i = e[8], f = s[215], l = r[52], p = s[0], d = parseInt(c[216], u[122]), h = e[86], g = u[217], w = u[123], m = e[165], I = parseInt(t + En, c[122]), y = parseInt(a[79], a[82]), _ = c[218], C = parseInt(a[193], e[82]), E = parseInt(o + i, r[78]), A = parseInt(u[219], s[122]), b = parseInt(f + An, s[106]), T = parseInt(r[194], s[106]), B = parseInt(8), R = parseInt(e[196], u[122]), k = parseInt(e[197], a[78]), S;
    function P() {
        var n = s[0]
          , t = r[88]
          , e = parseInt(u[13], c[122])
          , a = s[217];
        S = new qn([a, a, a, a, n, n, n, e, t, t, t, t, t, t, t, a, t, n]),
        S[p] = parseInt(TOKEN_SERVER_TIME),
        M(),
        S[B] = 0,
        S[k] = 3,
        S[R] = 0,
        S[h] = 505497997,
        S[b] = 3812,
        S[g] = 1,
        S[w] = 10,
        S[m] = 5
    }
    function M() {
        S[l] = Math.random() * parseInt("4294967295", 10) >>> 0
    }
    function O() {
        S[R]++,
        S[p] = parseInt(TOKEN_SERVER_TIME),
        S[d] = timeNow(),
        S[B] = 0,
        S[I] = 0,
        S[y] = 0,
        S[_] = 0,
        S[C] = 0,
        S[E] = 0,
        S[A] = 0;
        var n = S.toBuffer();
        console.log(zn.encode(n))
        return zn.encode(n)
    }
    P();
    function D() {
        return O()
    }
    n.updata = D
}(rt || (rt = {}));
function timeNow(){
        var n = new e[105];
    try {
        return time = s[52].now(),
        time / parseInt(c[131], a[88]) >>> c[2]
    } catch (t) {
        return time = n.getTime(),
        time / parseInt(s[121], s[84]) >>> r[52]
    }
}
var n = rt.updata()