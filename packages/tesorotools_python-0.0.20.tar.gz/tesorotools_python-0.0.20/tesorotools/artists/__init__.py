import matplotlib.style

from ..utils.globals import STYLE_SHEET

matplotlib.style.use(STYLE_SHEET)
