from tesorotools.database.local import LocalDatabase, ShortcutDatabase
