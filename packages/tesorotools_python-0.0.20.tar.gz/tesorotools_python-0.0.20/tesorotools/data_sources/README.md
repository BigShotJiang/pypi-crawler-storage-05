# LSEG Data Library for Python

## Capa de acceso

## Capa de contenido

## Capa de reparto

## Capa de sesión

## Referencias

- https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/index.html
- https://pypi.org/project/lseg-data/