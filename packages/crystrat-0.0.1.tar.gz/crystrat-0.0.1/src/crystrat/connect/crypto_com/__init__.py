"""Crypto.com Exchange connectors (REST + WebSocket)."""

