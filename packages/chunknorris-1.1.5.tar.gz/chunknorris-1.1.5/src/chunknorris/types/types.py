class HTMLString:
    """A HTML Formatted String"""
