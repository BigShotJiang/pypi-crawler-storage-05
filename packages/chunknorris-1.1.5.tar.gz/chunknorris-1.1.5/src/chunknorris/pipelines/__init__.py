from .abstract_pipeline import AbstractPipeline
from .base_pipeline import BasePipeline
from .wikit_pipeline import WikitJsonPipeline
