"""Logging utilities for VibeGen."""

from vibetools._internal import ConsoleLogger

console_logger = ConsoleLogger("VibeGen")
