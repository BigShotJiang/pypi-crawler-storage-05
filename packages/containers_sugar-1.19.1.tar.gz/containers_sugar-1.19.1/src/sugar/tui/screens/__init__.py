"""Screen components for the Sugar Terminal User Interface."""
