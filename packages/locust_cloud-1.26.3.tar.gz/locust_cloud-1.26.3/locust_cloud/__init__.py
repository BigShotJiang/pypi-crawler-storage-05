from locust_cloud.cloud import main

__all__ = ["main"]
