from . import result_summarizer

result_summarizer.main()
