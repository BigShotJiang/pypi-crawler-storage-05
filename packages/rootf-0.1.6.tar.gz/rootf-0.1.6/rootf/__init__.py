__version__ = "0.1.5"

from .system_info import get_distro, get_ascii_art, get_system_info
