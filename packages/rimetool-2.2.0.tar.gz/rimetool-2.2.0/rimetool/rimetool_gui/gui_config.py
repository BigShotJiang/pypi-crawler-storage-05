class GUIConfig:
    # Text for the Beian link
    ICP_BEIAN_TEXT = "晋ICP备2025058330号"
    
    # Website name and title
    WEBSITE_NAME = "你好👋"
    WEBSITE_TITLE = "医键通词库转换工具"
    BACKEND_VERSION = "1.8.2"
