# `Core`

::: mcpadapt.core
