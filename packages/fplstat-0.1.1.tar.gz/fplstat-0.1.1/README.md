# FPLstat
Python package for Fantasy Premier League data analysis and transformations

```bash
pip install fplstat
```

---

**Documentation**: [https://james-leslie.github.io/fplstat/](https://james-leslie.github.io/fplstat)

**Source code**: [https://github.com/James-Leslie/fpl-stat](https://github.com/James-Leslie/fpl-stat)

---
