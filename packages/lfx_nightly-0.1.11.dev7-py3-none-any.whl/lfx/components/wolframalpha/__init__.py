from .wolfram_alpha_api import WolframAlphaAPIComponent

__all__ = ["WolframAlphaAPIComponent"]
