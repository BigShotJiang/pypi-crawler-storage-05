from dataclasses import dataclass


@dataclass
class Group:
    id: str = None
    name: str = None
