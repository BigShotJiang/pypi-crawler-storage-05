Placeholder for a funtur release of ress
