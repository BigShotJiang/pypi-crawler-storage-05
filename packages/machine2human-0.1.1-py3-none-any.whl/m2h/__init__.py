from m2h.__version__ import __version__
from m2h.m2h import Hum2Sec, Sec2Hum

__all__ = ("Hum2Sec", "Sec2Hum", "__version__")
