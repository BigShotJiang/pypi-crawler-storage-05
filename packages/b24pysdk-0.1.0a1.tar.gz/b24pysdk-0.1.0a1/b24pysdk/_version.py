from typing import Final, Text

__title__: Final[Text] = "b24pysdk"
__version__: Final[Text] = "0.1.0a1"
