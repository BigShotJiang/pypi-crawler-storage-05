from typing import Final, Text

from ._version import __version__

SDK_VERSION: Final[Text] = __version__
