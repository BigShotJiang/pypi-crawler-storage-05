from .documentgenerator import Documentgenerator

__all__ = [
    "Documentgenerator",
]
