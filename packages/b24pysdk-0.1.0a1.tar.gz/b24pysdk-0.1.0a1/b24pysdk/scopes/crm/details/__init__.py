from .details import Details

__all__ = [
    "Details",
]
