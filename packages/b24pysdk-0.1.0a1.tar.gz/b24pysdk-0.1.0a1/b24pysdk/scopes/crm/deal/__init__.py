from .deal import Deal

__all__ = [
    "Deal",
]
