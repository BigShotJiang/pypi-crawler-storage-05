from .crm import CRM
from .department import Department
from .socialnetwork import Socialnetwork
from .user import User

__all__ = [
    "CRM",
    "Department",
    "Socialnetwork",
    "User",
]
