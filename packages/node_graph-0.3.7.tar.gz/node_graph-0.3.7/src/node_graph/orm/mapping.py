type_mapping = {
    "default": "node_graph.any",
    "namespace": "node_graph.namespace",
    int: "node_graph.int",
    float: "node_graph.float",
    str: "node_graph.string",
    bool: "node_graph.bool",
}
