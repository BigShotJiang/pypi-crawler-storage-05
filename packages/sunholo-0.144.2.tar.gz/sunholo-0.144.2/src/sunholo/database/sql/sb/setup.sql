-- Enable the pgvector extension to work with embedding vectors
create extension vector;
