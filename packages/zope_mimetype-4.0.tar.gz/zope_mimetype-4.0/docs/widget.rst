.. include:: ../src/zope/mimetype/widget.rst
