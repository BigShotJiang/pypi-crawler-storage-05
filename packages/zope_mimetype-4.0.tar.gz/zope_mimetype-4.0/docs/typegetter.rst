.. include:: ../src/zope/mimetype/typegetter.rst
