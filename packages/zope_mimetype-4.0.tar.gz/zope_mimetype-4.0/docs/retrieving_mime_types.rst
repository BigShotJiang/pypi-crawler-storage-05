.. include:: ../src/zope/mimetype/retrieving_mime_types.rst
