.. include:: ../src/zope/mimetype/source.rst
