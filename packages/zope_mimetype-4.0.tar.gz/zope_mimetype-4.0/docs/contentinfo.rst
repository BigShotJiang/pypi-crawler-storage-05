.. include:: ../src/zope/mimetype/contentinfo.rst
