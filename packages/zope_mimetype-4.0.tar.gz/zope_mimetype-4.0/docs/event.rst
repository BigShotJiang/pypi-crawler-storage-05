.. include:: ../src/zope/mimetype/event.rst
