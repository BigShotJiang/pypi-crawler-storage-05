.. include:: ../src/zope/mimetype/README.rst
