.. include:: ../src/zope/mimetype/codec.rst
