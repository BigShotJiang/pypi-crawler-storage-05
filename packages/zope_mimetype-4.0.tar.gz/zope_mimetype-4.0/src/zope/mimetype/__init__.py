from zope.mimetype import mtypes


types = mtypes  # alternate spelling/backwards (1.3) compatible export
