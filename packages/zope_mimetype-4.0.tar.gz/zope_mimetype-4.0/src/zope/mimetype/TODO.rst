- make tests into unit tests (setting up component framework and
  utilities/adapters)
- make the location of the CSV file configurable/extendable via ZCML
