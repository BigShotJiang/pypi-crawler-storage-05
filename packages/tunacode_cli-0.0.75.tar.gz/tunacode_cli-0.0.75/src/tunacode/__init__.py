# Initialize unified logging system on package import
from tunacode.core.logging import setup_logging

setup_logging()
