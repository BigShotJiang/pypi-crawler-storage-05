# py-lerchs-grossmann

[![PyPI - Version](https://img.shields.io/pypi/v/py-lerchs-grossmann.svg)](https://pypi.org/project/py-lerchs-grossmann)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/py-lerchs-grossmann.svg)](https://pypi.org/project/py-lerchs-grossmann)

---

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install py_lerchs_grossmann
```

## License

`py-lerchs-grossmann` is distributed under the terms of the [BSD-3-Clause](https://spdx.org/licenses/BSD-3-Clause.html) license.
