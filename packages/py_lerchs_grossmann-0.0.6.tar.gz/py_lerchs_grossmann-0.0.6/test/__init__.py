# SPDX-FileCopyrightText: 2025-present Mau-Aravena
#
# SPDX-License-Identifier: BSD-3-Clause
