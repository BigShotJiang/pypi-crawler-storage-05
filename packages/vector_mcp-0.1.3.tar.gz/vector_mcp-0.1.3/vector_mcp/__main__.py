#!/usr/bin/python
# coding: utf-8
from vector_mcp.vector_mcp import main

if __name__ == "__main__":
    main()
