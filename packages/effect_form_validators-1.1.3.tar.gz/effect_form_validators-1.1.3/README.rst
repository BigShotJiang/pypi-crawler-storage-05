|pypi| |actions| |codecov| |downloads| |clinicedc|


effect-form-validators
----------------------

Form validator classes for `EFFECT Edc <https://github.com/effect-trial/effect-edc#readme>`_ model forms

.. |pypi| image:: https://img.shields.io/pypi/v/effect-form-validators.svg
   :target: https://pypi.python.org/pypi/effect-form-validators

.. |actions| image:: https://github.com/effect-trial/effect-form-validators/actions/workflows/build.yml/badge.svg
   :target: https://github.com/effect-trial/effect-form-validators/actions/workflows/build.yml

.. |codecov| image:: https://codecov.io/gh/effect-trial/effect-form-validators/branch/develop/graph/badge.svg
   :target: https://codecov.io/gh/effect-trial/effect-form-validators

.. |downloads| image:: https://pepy.tech/badge/effect-form-validators
   :target: https://pepy.tech/project/effect-form-validators

.. |clinicedc| image:: https://img.shields.io/badge/framework-Clinic_EDC-green
   :alt:Made with clinicedc
   :target: https://github.com/clinicedc
