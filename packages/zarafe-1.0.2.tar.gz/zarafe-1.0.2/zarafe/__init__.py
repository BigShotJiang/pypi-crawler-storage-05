"""Zarafe - Video annotation tool for eye tracking studies."""

__version__ = "0.2.0"
