"""Widget panels for organizing UI components."""
