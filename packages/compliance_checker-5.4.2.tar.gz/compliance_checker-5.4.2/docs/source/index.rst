compliance_checker
==================

Python tool to check your datasets against compliance standards.

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   readme_link
   compliance_checker_api
   faq
   development

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
