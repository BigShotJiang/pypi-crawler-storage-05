{{ objname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. auto{{ objtype }}:: {{ objname }}

.. include:: {{fullname}}.examples

.. raw:: html

      <div style='clear:both'></div>
