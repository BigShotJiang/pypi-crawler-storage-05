---
name: Compliance Checker Issue Report
about: 'Report an issue running Compliance Checker '
title: ''
labels: ''
assignees: ''

---

**Version of compliance checker running:**

**Describe the checker this affects:**
_The ACDD, IOOS, and CF checkers are currently considered in scope for the purposes of the issue tracking on this repository. Issues with other plugins should be placed into their respective repositories._

**Attach a minimal CDL or NetCDF file which is able to reproduce the issue**

**To Reproduce:**
_List the steps or command line to run to reproduce the issue_

**Describe the issue below:**
_Any additional detail or information relevant to the issue_
