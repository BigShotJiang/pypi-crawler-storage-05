"""Version information for context-engine-mcp."""

__version__ = "2.0.1"
