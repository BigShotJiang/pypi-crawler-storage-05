"""Web app for inspecting and interacting with prompt calls and logs."""
