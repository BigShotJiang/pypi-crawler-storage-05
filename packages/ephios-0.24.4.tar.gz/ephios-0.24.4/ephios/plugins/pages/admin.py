from django.contrib import admin

from ephios.plugins.pages.models import Page

admin.site.register(Page)
