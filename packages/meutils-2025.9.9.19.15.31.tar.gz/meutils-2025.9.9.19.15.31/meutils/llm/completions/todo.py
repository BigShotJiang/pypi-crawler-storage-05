#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : todo
# @Time         : 2025/5/12 13:32
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  : 

from meutils.pipe import *

"""
400 {"code":20015,"message":"length of prompt_tokens (213479) must be less than max_seq_len (65536).","data":null}
"""