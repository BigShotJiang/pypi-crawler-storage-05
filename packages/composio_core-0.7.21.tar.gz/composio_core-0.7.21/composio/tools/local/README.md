Composio is your one-stop solution for all kind of LLM tools and functionalities. And a very important step on that front is the ability of adding your own custom tools. Once we add a tool(or Action).


This page contains necessary details for using Local Tools: [Local Tools Page](https://docs.composio.dev/concepts/tool-calling/overview#using-composios-local-tools)
