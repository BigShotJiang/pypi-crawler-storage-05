"""Shell execution actions."""
