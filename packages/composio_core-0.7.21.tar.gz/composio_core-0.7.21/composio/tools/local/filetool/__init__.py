"""
File manager.
"""

from .tool import Filetool
