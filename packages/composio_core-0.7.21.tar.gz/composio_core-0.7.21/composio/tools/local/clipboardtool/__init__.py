"""
Clipboard manager.
"""

from .tool import Clipboardtool
