from .tool import EmbedTool
