"""Browser manager for agents."""

from .browser import Browser
from .manager import BrowserManager
