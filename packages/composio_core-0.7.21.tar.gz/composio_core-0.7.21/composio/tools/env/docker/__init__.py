"""Docker workspace factory."""
