
#### Code for novelty search has moved to https://github.com/kenblu24/novelswarms-es

The `configs` folder contains project folders that can be used to run sample simulations.
