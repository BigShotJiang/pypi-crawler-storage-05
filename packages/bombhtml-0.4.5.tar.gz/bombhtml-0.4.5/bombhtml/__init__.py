"""
 Copyright (C) 2025  sophie (itsme@itssophi.ee)

    Double licensed under MIT and GPLv3. See LICENSE_* for more info.
"""

from .bomb import Build

__version__ = "0.4.5"