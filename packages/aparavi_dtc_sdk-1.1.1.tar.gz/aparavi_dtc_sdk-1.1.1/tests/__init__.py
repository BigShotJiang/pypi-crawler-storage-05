"""
Test package for Aparavi SDK
"""
