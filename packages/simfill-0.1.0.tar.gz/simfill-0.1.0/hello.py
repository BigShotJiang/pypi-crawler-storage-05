def main():
    print("Hello from simfill!")


if __name__ == "__main__":
    main()
