# Automata LINQ SDK

## Installation

The latest version of Automata LINQ SDK can be installed via pip using
>`pip install automata-linq-sdk`

If you need to specify a version, you can append `==x.x.x` onto the package name, e.g., 
> `pip install automata-linq-sdk==1.10.2`

## Documentation

Full documentation can be found at https://docs.automata.tech/index