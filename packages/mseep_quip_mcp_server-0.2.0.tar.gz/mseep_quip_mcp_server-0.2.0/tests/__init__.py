"""
Tests package for the Quip MCP server.
"""
