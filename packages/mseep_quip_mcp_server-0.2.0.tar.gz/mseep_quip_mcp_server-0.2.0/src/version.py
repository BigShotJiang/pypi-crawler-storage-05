"""
Version information for the quip-mcp-server package.
This file is the single source of truth for the version number.
"""

__version__ = "0.2.0"