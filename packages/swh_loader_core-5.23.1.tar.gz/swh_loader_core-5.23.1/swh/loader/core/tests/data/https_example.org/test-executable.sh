#!/usr/bin/env bash

# Dummy file with executable bit set
date
