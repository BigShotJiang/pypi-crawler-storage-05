from krsite_dl.krsite_dl import main

if __name__ == "__main__":
    main()