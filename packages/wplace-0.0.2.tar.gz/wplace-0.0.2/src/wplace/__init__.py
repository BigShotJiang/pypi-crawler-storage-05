__version__ = "0.0.2"

from .canvas import Pixel, Region, Tile
from .country import Country
from .palette import Color
