# wplace

Utility classes and methods for [Wplace.live](https://wplace.live/)

![PyPI - Python Version](https://img.shields.io/pypi/pyversions/wplace?style=flat-square)
![PyPI - Downloads](https://img.shields.io/pypi/dm/wplace?style=flat-square)
![PyPI](https://img.shields.io/pypi/v/wplace?style=flat-square)

## Installation

`wplace` is available on pypi:
```bash
python3 -m pip install --upgrade wplace
```
