
![Swamauri Logo](https://res.cloudinary.com/dbjmpekvl/image/upload/v1730099724/Swarmauri-logo-lockup-2048x757_hww01w.png)

<p align="center">
    <a href="https://pypi.org/project/zdx/">
        <img src="https://img.shields.io/pypi/dm/zdx" alt="PyPI - Downloads"/></a>
    <a href="https://hits.sh/github.com/swarmauri/swarmauri-sdk/tree/master/pkgs/experimental/ye/">
        <img alt="Hits" src="https://hits.sh/github.com/swarmauri/swarmauri-sdk/tree/master/pkgs/experimental/zdx.svg"/></a>
    <a href="https://pypi.org/project/zdx/">
        <img src="https://img.shields.io/pypi/pyversions/zdx" alt="PyPI - Python Version"/></a>
    <a href="https://pypi.org/project/zdx/">
        <img src="https://img.shields.io/pypi/l/zdx" alt="PyPI - License"/></a>
    <a href="https://pypi.org/project/zdx/">
        <img src="https://img.shields.io/pypi/v/zdx?label=zdx&color=green" alt="PyPI - zdx"/></a>
</p>

---

# Z Doc Builder Experience

