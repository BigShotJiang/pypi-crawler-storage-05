"""
IpyFormKit: Easy form creation with ipywidgets in Jupyter.
"""

__version__ = "0.3.6"

from .custom_widgets import *
from .core import Form, Masonry