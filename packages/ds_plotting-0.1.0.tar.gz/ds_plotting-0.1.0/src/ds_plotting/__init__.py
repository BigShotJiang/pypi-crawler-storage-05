"""
.. include:: ../../README.md

   :start-line: 1
"""

from ds_plotting.main import plot_fit

__all__ = ["plot_fit"]
