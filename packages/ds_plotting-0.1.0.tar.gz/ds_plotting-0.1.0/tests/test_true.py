def test_true() -> None:
    """At least one test will always pass :)."""
    assert True
