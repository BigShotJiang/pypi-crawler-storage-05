#!/usr/bin/env python3
"""
RhamaaCLI main entry point for python -m rhamaa
"""

from rhamaa.cli import main

if __name__ == '__main__':
    main()