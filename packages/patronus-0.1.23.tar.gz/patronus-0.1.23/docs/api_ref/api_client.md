# API

::: patronus.api.api_client.PatronusAPIClient
    options:
        show_root_heading: true
        members_order: alphabetical

::: patronus.api.api_types
    options:
        show_root_heading: true
        show_if_no_docstring: true
        members_order: alphabetical
