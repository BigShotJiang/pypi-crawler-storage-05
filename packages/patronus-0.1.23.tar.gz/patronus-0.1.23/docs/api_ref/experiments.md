# experiments

::: patronus.experiments
    options:
        show_submodules: true
        show_root_heading: true
