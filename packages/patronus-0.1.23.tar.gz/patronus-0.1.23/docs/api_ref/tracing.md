# Tracing

::: patronus.tracing
    options:
        show_submodules: true
        show_root_heading: true
