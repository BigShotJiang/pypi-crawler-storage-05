# Local Audio Transport

```bash
pip install "piopiy-ai[local]"
```

```python
from piopiy.transports.local.audio import (
    LocalAudioTransportParams,
    LocalAudioInputTransport,
    LocalAudioOutputTransport,
)

params = LocalAudioTransportParams()
```
