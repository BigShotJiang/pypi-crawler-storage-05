# TeleCMI Transport

```bash
pip install piopiy-ai
```

```python
from piopiy.transports.services.telecmi import (
    TelecmiTransportClient,
    TelecmiParams,
    TelecmiCallbacks,
)
```
