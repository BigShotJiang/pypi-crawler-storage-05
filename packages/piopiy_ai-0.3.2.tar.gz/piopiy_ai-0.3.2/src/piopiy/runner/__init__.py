"""Pipecat runner package for local and cloud bot execution."""
