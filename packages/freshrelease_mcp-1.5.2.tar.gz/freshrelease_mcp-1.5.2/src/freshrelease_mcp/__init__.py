from .server import main

__version__ = "1.5.2"
__all__ = ["main"]

