from enerbitdso.cli import cli

cli()
