# -*- coding: UTF-8 -*-
from matplotlib import pyplot
pyplot.rcParams['font.sans-serif']=['SimHei'] #设置字体
pyplot.rcParams['axes.unicode_minus']=False #该语句解决图像中的“-”负号的乱码问题