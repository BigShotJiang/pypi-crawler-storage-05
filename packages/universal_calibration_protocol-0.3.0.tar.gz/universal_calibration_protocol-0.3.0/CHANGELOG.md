## Changelog

### 0.3.0 

- Add inital version of documentation
- Updated project metadata

### 0.2.0 

- Added README

### 0.1.0 

- Initial Release
