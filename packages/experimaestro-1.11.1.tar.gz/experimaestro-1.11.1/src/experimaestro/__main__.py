from experimaestro.cli import cli

# flake8: noqa: F401
import experimaestro.cli.jobs


def main():
    cli(obj=None)


if __name__ == "__main__":
    main()
