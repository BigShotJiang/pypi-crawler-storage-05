# imsutils
This python package is a small collection of tools accumulated over some time.

currently WIP...
