"""Run command module for executing generated Python scripts."""

from .run import run_app

__all__ = ["run_app"]
