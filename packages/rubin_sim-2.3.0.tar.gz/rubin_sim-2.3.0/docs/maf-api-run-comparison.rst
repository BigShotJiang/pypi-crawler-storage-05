.. py:currentmodule:: rubin_sim.maf

.. _maf-api-run-comparison:

==============
Run Comparison
==============

.. automodule:: rubin_sim.maf.run_comparison
    :imported-members:
    :members:
    :show-inheritance:
