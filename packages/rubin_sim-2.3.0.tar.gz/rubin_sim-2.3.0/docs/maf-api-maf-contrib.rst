.. py:currentmodule:: rubin_sim.maf

.. _maf-api-maf-contrib:

===========
Maf Contrib
===========

.. automodule:: rubin_sim.maf.maf_contrib
    :imported-members:
    :members:
    :show-inheritance:
