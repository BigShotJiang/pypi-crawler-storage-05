2025-08-25 Version: 1.4.10
- Update API SubmitDocParserJob: add request parameters MultimediaParameters.


2025-08-19 Version: 1.4.9
- Update API SubmitDocParserJob: add request parameters EnhancementMode.


2025-08-14 Version: 1.4.8
- Update API SubmitDocParserJob: add request parameters OutputHtmlTable.


2025-05-22 Version: 1.4.7
- Generated python 2022-07-11 for docmind-api.

2025-05-22 Version: 1.4.6
- Update API QueryDocParserStatus: add response parameters Body.Data.Processing.
- Update API SubmitDocParserJob: add request parameters Option.
- Update API SubmitDocParserJob: add request parameters PageIndex.
- Update API SubmitDocStructureJob: add request parameters PageIndex.


2025-03-17 Version: 1.4.5
- Update API SubmitConvertPdfToWordJob: add param FormulaEnhancement.
- Update API SubmitConvertPdfToWordJob: add param Option.


2025-02-19 Version: 1.4.4
- Update API SubmitConvertImageToExcelJob: add param OssBucket.
- Update API SubmitConvertImageToExcelJob: add param OssEndpoint.
- Update API SubmitConvertImageToMarkdownJob: add param OssBucket.
- Update API SubmitConvertImageToMarkdownJob: add param OssEndpoint.
- Update API SubmitConvertImageToPdfJob: add param OssBucket.
- Update API SubmitConvertImageToPdfJob: add param OssEndpoint.
- Update API SubmitConvertImageToWordJob: add param OssBucket.
- Update API SubmitConvertImageToWordJob: add param OssEndpoint.
- Update API SubmitConvertPdfToExcelJob: add param OssBucket.
- Update API SubmitConvertPdfToExcelJob: add param OssEndpoint.
- Update API SubmitConvertPdfToImageJob: add param OssBucket.
- Update API SubmitConvertPdfToImageJob: add param OssEndpoint.
- Update API SubmitConvertPdfToMarkdownJob: add param OssBucket.
- Update API SubmitConvertPdfToMarkdownJob: add param OssEndpoint.
- Update API SubmitConvertPdfToWordJob: add param OssBucket.
- Update API SubmitConvertPdfToWordJob: add param OssEndpoint.
- Update API SubmitDigitalDocStructureJob: add param OssBucket.
- Update API SubmitDigitalDocStructureJob: add param OssEndpoint.
- Update API SubmitDocParserJob: add param LlmEnhancement.
- Update API SubmitDocParserJob: add param OssBucket.
- Update API SubmitDocParserJob: add param OssEndpoint.
- Update API SubmitDocStructureJob: add param OssBucket.
- Update API SubmitDocStructureJob: add param OssEndpoint.
- Update API SubmitDocumentExtractJob: add param OssBucket.
- Update API SubmitDocumentExtractJob: add param OssEndpoint.
- Update API SubmitTableUnderstandingJob: add param OssBucket.
- Update API SubmitTableUnderstandingJob: add param OssEndpoint.


2025-01-08 Version: 1.4.3
- Update API SubmitDocParserJob: add param LlmEnhancement.


2024-09-30 Version: 1.4.2
- Update API QueryDocParserStatus: update response param.


2024-08-16 Version: 1.4.1
- Generated python 2022-07-11 for docmind-api.

2024-08-16 Version: 1.4.0
- Support API GetDocParserResult.
- Support API QueryDocParserStatus.
- Support API SubmitDocParserJob.
- Update API GetDocStructureResult: add param UseUrlResponseBody.
- Update API SubmitDigitalDocStructureJob: add param UseUrlResponseBody.


2024-06-28 Version: 1.3.1
- Delete API SubmitDocumentCompareJob.
- Update API SubmitDocStructureJob: add param AllowPptFormat.


2024-05-09 Version: 1.3.0
- Support API SubmitConvertImageToMarkdownJob.
- Support API SubmitConvertPdfToMarkdownJob.
- Update API SubmitDocStructureJob: add param FormulaEnhancement.


2024-01-09 Version: 1.2.1
- Generated python 2022-07-11 for docmind-api.

2023-11-01 Version: 1.2.0
- Generated python 2022-07-11 for docmind-api.

2023-09-19 Version: 1.1.0
- Generated python 2022-07-11 for docmind-api.

2023-06-13 Version: 1.0.4
- Support docmind experience center.
- Docmind support new seven types for industry intelligence.
- Add new parameter to support different document parse process.

2023-03-13 Version: 1.0.3
- Add param to support digital chain.

2023-03-02 Version: 1.0.2
- Document covert support excel sheet merge.

2022-12-08 Version: 1.0.1
- Fix problems when using CSharp SDK.

2022-09-22 Version: 1.0.0
- Automatically generate sdk tasks.

