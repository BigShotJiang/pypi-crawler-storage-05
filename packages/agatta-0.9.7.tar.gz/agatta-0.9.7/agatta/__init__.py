# -*- coding: utf-8 -*-

"""
    AGATTA: Three-item analysis Python package
"""

from .main import main


if __name__ == "__main__":
    main()