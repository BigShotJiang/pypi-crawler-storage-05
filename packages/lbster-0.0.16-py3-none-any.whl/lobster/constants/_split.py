from enum import Enum


class Split(Enum):
    TRAIN = "train"
    VALIDATION = "validation"
    TEST = "test"
