import os

S3_BUCKET = os.getenv("S3_BUCKET", "prescient-lobster")
