import importlib.resources

HF_UME_REPO_ID = "karina-zadorozhny/ume"
HF_UME_MODEL_DIRPATH = importlib.resources.files("lobster") / "model/integrations/ume_huggingface/model"
