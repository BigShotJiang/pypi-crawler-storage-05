from ._hyena import LobsterHyenaCLM
