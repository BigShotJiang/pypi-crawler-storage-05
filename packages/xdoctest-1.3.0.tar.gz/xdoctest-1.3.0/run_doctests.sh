#!/usr/bin/env bash
xdoctest src/xdoctest --style=google all "$@"