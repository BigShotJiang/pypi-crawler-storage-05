:github_url: https://github.com/Erotemic/xdoctest

.. The __init__ files contains the top-level documentation overview
.. automodule:: xdoctest.__init__
   :show-inheritance:

.. toctree::
   :maxdepth: 8

   Package layout <auto/xdoctest>
   manual/xdoc_with_jupyter
   manual/async_doctest


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`

