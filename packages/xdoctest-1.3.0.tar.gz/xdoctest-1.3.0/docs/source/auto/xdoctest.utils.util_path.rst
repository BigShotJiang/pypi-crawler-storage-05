xdoctest.utils.util\_path module
================================

.. automodule:: xdoctest.utils.util_path
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
