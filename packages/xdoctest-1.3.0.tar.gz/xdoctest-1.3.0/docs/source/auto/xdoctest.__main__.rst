xdoctest.\_\_main\_\_ module
============================

.. automodule:: xdoctest.__main__
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
