xdoctest.core module
====================

.. automodule:: xdoctest.core
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
