xdoctest.docstr.docscrape\_google module
========================================

.. automodule:: xdoctest.docstr.docscrape_google
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
