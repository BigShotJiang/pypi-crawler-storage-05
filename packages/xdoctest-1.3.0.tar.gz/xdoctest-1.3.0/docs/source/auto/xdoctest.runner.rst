xdoctest.runner module
======================

.. automodule:: xdoctest.runner
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
