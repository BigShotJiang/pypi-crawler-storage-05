xdoctest.utils.util\_str module
===============================

.. automodule:: xdoctest.utils.util_str
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
