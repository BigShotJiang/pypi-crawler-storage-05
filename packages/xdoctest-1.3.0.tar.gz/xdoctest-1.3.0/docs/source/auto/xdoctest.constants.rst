xdoctest.constants module
=========================

.. automodule:: xdoctest.constants
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
