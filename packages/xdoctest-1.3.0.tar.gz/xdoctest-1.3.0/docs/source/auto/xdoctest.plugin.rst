xdoctest.plugin module
======================

.. automodule:: xdoctest.plugin
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
