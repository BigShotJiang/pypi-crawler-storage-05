xdoctest.checker module
=======================

.. automodule:: xdoctest.checker
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
