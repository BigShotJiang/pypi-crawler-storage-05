xdoctest.directive module
=========================

.. automodule:: xdoctest.directive
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
