xdoctest.\_tokenize module
==========================

.. automodule:: xdoctest._tokenize
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
