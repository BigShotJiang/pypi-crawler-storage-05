xdoctest.utils.util\_deprecation module
=======================================

.. automodule:: xdoctest.utils.util_deprecation
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
