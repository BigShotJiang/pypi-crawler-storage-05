xdoctest.utils.util\_stream module
==================================

.. automodule:: xdoctest.utils.util_stream
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
