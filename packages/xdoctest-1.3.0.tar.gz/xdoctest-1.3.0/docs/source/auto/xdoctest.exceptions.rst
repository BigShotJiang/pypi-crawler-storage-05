xdoctest.exceptions module
==========================

.. automodule:: xdoctest.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
