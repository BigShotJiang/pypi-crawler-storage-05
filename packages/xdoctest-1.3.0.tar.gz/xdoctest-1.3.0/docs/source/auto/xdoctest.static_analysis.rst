xdoctest.static\_analysis module
================================

.. automodule:: xdoctest.static_analysis
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
