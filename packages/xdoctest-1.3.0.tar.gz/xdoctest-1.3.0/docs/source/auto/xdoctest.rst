xdoctest package
================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   xdoctest.docstr
   xdoctest.utils

Submodules
----------

.. toctree::
   :maxdepth: 4

   xdoctest.__main__
   xdoctest._tokenize
   xdoctest.checker
   xdoctest.constants
   xdoctest.core
   xdoctest.demo
   xdoctest.directive
   xdoctest.doctest_example
   xdoctest.doctest_part
   xdoctest.dynamic_analysis
   xdoctest.exceptions
   xdoctest.global_state
   xdoctest.parser
   xdoctest.plugin
   xdoctest.runner
   xdoctest.static_analysis

Module contents
---------------

.. automodule:: xdoctest
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
