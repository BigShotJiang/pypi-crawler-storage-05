xdoctest.utils.util\_notebook module
====================================

.. automodule:: xdoctest.utils.util_notebook
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
