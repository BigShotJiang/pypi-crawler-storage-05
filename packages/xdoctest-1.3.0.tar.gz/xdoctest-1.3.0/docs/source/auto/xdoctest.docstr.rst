xdoctest.docstr package
=======================

Submodules
----------

.. toctree::
   :maxdepth: 4

   xdoctest.docstr.docscrape_google
   xdoctest.docstr.docscrape_numpy

Module contents
---------------

.. automodule:: xdoctest.docstr
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
