xdoctest.demo module
====================

.. automodule:: xdoctest.demo
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
