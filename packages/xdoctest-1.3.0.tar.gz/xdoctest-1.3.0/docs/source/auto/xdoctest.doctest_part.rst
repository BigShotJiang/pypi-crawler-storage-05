xdoctest.doctest\_part module
=============================

.. automodule:: xdoctest.doctest_part
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
