xdoctest.global\_state module
=============================

.. automodule:: xdoctest.global_state
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
