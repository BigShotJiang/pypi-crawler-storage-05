xdoctest.docstr.docscrape\_numpy module
=======================================

.. automodule:: xdoctest.docstr.docscrape_numpy
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
