xdoctest.doctest\_example module
================================

.. automodule:: xdoctest.doctest_example
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
