xdoctest.utils.util\_misc module
================================

.. automodule:: xdoctest.utils.util_misc
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
