xdoctest.parser module
======================

.. automodule:: xdoctest.parser
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
