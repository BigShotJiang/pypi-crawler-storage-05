def test_import():
    import xdoctest