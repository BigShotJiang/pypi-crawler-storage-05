## [2.0.2] - 2025-09-10

### Changed
- Update copier

