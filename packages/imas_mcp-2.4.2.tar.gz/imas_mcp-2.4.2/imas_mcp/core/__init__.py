"""Core IMAS MCP processing modules."""
