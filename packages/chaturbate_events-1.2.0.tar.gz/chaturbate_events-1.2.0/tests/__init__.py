"""Tests package for Chaturbate Events API."""
