"""Fujitsu Social Digital Twin - Digital Rehearsal API MCP Server package"""

__version__ = "0.1.1"
