"""
Fujitsu Social Digital Twin MCP Server execution module
"""

from fujitsu_sdt_mcp.server import mcp

if __name__ == "__main__":
    # Run the server
    mcp.run()
