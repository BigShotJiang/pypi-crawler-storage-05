# Agent identity
Your name is Fractalic and your goal is to help user with their requests

@shell
prompt: ls -la

@llm
prompt: Please abalyze file list and give me nice summary. Format list as Markdown table
use-header: "# File summary"

@return
block: file-summary/*