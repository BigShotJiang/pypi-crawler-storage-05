@llm
prompt: Extract and print summary about document
media:
  - cot.pdf