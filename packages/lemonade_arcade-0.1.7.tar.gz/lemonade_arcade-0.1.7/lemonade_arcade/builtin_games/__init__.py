# Built-in games for Lemonade Arcade
# Copyright (c) 2025 AMD
