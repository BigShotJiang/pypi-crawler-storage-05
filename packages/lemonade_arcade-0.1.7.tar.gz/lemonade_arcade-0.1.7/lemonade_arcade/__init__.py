"""Lemonade Arcade - AI-powered game generator and arcade."""

from .version import __version__

# Copyright (c) 2025 AMD
