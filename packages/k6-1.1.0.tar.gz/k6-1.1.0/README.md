# k6

[![PyPI - Version](https://img.shields.io/pypi/v/k6.svg)](https://pypi.org/project/k6)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/k6.svg)](https://pypi.org/project/k6)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install k6
```
