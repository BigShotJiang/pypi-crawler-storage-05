#!/usr/bin/env sh
./master.py --project ./master.json --outputdir ~/.out-master
