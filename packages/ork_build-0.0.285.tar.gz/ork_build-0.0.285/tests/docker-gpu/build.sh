#!/usr/bin/env sh

docker build -t glvnd-x:latest .

