PaidMediaVideo
==============

.. autoclass:: telegram.PaidMediaVideo
    :members:
    :show-inheritance:
