ChatBoostRemoved
================

.. versionadded:: 20.8

.. autoclass:: telegram.ChatBoostRemoved
    :members:
    :show-inheritance: