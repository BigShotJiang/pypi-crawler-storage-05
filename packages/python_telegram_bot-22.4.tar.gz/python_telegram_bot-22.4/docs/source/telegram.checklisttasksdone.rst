ChecklistTasksDone
==================

.. autoclass:: telegram.ChecklistTasksDone
    :members:
    :show-inheritance:
