BotDescription
==============

.. autoclass:: telegram.BotDescription
    :members:
    :show-inheritance: