InputStoryContent
=================

.. autoclass:: telegram.InputStoryContent
    :members:
    :show-inheritance:
