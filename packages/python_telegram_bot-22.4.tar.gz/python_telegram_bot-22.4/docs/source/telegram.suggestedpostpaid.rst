SuggestedPostPaid
=================

.. autoclass:: telegram.SuggestedPostPaid
    :members:
    :show-inheritance:
