InlineQueryResultAudio
======================

.. autoclass:: telegram.InlineQueryResultAudio
    :members:
    :show-inheritance:
