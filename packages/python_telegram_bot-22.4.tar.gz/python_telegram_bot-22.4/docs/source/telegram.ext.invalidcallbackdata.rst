InvalidCallbackData
===================

.. autoclass:: telegram.ext.InvalidCallbackData
    :members:
    :show-inheritance:
