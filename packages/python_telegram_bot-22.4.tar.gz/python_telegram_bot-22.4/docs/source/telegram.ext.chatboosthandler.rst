ChatBoostHandler
================

.. versionadded:: 20.8

.. autoclass:: telegram.ext.ChatBoostHandler
    :members:
    :show-inheritance: