Voice
=====

.. Also lists methods of _BaseThumbedMedium, but not the ones of TelegramObject

.. autoclass:: telegram.Voice
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject, object
