StarAmount
==========

.. autoclass:: telegram.StarAmount
    :members:
    :show-inheritance:
