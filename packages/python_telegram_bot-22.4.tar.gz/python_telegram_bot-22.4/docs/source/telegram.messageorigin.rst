MessageOrigin
=============

.. autoclass:: telegram.MessageOrigin
    :members:
    :show-inheritance:
