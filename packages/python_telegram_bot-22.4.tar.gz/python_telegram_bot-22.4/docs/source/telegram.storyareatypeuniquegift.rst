StoryAreaTypeUniqueGift
=======================

.. autoclass:: telegram.StoryAreaTypeUniqueGift
    :members:
    :show-inheritance:
