WebAppInfo
==========

.. autoclass:: telegram.WebAppInfo
    :members:
    :show-inheritance: