InputChecklist
==============

.. autoclass:: telegram.InputChecklist
    :members:
    :show-inheritance:
