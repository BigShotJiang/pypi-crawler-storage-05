SuggestedPostApprovalFailed
===========================

.. autoclass:: telegram.SuggestedPostApprovalFailed
    :members:
    :show-inheritance:
