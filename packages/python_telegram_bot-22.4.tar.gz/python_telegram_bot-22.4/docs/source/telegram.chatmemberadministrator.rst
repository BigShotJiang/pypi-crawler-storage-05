ChatMemberAdministrator
=======================

.. autoclass:: telegram.ChatMemberAdministrator
    :members:
    :show-inheritance:
