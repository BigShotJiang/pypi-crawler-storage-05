``deeplinking.py``
==================

.. literalinclude:: ../../examples/deeplinking.py
   :language: python
   :linenos:
    