OrderInfo
=========

.. autoclass:: telegram.OrderInfo
    :members:
    :show-inheritance:
