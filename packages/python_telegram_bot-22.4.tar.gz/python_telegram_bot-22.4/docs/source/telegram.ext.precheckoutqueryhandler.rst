PreCheckoutQueryHandler
=======================

.. autoclass:: telegram.ext.PreCheckoutQueryHandler
    :members:
    :show-inheritance:
