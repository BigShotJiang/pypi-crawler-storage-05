PreparedInlineMessage
=====================

.. autoclass:: telegram.PreparedInlineMessage
    :members:
    :show-inheritance: