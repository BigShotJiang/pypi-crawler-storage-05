RevenueWithdrawalState
======================

.. autoclass:: telegram.RevenueWithdrawalState
    :members:
    :show-inheritance:
