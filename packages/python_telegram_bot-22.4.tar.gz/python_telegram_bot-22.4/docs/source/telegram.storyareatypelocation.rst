StoryAreaTypeLocation
=====================

.. autoclass:: telegram.StoryAreaTypeLocation
    :members:
    :show-inheritance:
