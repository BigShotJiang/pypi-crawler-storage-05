ChatBoost
=========

.. versionadded:: 20.8

.. autoclass:: telegram.ChatBoost
    :members:
    :show-inheritance: