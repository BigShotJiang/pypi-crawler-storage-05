InputFile
=========

.. autoclass:: telegram.InputFile
    :members:
    :show-inheritance:
