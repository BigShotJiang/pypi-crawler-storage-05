telegram.request Module
=======================

.. versionadded:: 20.0

.. toctree::
    :titlesonly:

    telegram.request.baserequest
    telegram.request.requestdata
    telegram.request.httpxrequest
