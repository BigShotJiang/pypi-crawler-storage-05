StarTransactions
================

.. autoclass:: telegram.StarTransactions
    :members:
    :show-inheritance:

