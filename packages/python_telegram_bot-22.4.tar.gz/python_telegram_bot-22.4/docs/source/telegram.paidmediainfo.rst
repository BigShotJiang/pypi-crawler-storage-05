PaidMediaInfo
=============

.. autoclass:: telegram.PaidMediaInfo
    :members:
    :show-inheritance:
