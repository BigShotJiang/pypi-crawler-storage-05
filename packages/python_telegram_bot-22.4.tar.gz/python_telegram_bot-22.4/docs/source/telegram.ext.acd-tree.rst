Arbitrary Callback Data
-----------------------

.. toctree::
    :titlesonly:

    telegram.ext.callbackdatacache
    telegram.ext.invalidcallbackdata
