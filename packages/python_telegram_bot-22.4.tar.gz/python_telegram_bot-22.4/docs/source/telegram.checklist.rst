Checklist
=========

.. autoclass:: telegram.Checklist
    :members:
    :show-inheritance:
