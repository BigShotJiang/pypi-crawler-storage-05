ChatMemberHandler
=================

.. autoclass:: telegram.ext.ChatMemberHandler
    :members:
    :show-inheritance:
