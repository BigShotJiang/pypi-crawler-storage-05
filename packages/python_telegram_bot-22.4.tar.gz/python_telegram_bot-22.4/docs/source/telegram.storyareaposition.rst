StoryAreaPosition
=================

.. autoclass:: telegram.StoryAreaPosition
    :members:
    :show-inheritance:
