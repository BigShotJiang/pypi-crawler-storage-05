ExtBot
======

.. autoclass:: telegram.ext.ExtBot
    :show-inheritance:
    :members: insert_callback_data, defaults, rate_limiter, initialize, shutdown, callback_data_cache
