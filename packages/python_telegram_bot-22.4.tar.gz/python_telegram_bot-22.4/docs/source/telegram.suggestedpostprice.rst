SuggestedPostPrice
==================

.. autoclass:: telegram.SuggestedPostPrice
    :members:
    :show-inheritance:
