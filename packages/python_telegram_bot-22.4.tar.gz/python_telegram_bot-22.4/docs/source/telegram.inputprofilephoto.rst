InputProfilePhoto
=================

.. autoclass:: telegram.InputProfilePhoto
    :members:
    :show-inheritance: