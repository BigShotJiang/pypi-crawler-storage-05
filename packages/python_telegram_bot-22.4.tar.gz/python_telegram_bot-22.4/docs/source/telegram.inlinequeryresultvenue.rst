InlineQueryResultVenue
======================

.. autoclass:: telegram.InlineQueryResultVenue
    :members:
    :show-inheritance:
