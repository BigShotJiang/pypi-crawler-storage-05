MessageOriginHiddenUser
=======================

.. autoclass:: telegram.MessageOriginHiddenUser
    :members:
    :show-inheritance:

