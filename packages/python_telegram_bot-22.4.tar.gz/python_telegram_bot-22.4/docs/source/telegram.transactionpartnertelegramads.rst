TransactionPartnerTelegramAds
=============================

.. autoclass:: telegram.TransactionPartnerTelegramAds
    :members:
    :show-inheritance:
