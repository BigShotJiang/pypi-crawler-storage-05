UniqueGiftBackdropColors
========================

.. autoclass:: telegram.UniqueGiftBackdropColors
    :members:
    :show-inheritance:

