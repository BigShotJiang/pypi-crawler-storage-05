====
Home
====

deck2pdf is CLI tool to generate PDF from HTML presentation.

.. toctree::
   :maxdepth: 1

   usage
   formats
   changes

Motivation
==========

I am author of `sphinx-revealjs <https://pypi.org/project/sphinx-revealjs/>`_,
and I write presentation using it.

I have cases to upload PDF file exported from presentation (e.g. SpeakerDeck).
There is `decktape <https://github.com/astefanutti/decktape>`_ as application for this use case,
but I want to works by only Python.

It does not port all features from X yet.
If there are desires for these, I may do.
