=================
Supported formats
=================

``reavealjs``
=============

.. todo:: Write on v1.0

``generic``
===========

.. todo:: Write on v1.0

``custom``
==========

.. versionadded:: 0.9.0

You can use local module to capture presentation by using ``--format=custom``.
When you use this option, deck2pdf load ``custom.py`` on your current directory.

.. literalinclude:: ../custom.example.py
    :language: python
    :caption: custom.py
