from typing import TypedDict


class Size(TypedDict):
    width: int
    height: int
