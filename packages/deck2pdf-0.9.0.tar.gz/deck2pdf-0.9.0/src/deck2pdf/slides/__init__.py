"""Slide operator package."""
