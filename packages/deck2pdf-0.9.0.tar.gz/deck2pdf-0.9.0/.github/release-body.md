Release atsphinx-demo v0.8.0

- Changelog is https://github.com/attakei/deck2pdf-python/blob/v0.8.0/CHANGES.rst
- Diff is https://github.com/attakei/deck2pdf-python/compare/v0.7.0..v0.8.0
