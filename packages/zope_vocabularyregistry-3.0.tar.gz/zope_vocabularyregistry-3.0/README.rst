=========================
 zope.vocabularyregistry
=========================

.. image:: https://img.shields.io/pypi/v/zope.vocabularyregistry.svg
        :target: https://pypi.python.org/pypi/zope.vocabularyregistry/
        :alt: Latest release

.. image:: https://img.shields.io/pypi/pyversions/zope.vocabularyregistry.svg
        :target: https://pypi.org/project/zope.vocabularyregistry/
        :alt: Supported Python versions

.. image:: https://github.com/zopefoundation/zope.vocabularyregistry/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.vocabularyregistry/actions/workflows/tests.yml

.. image:: https://coveralls.io/repos/github/zopefoundation/zope.vocabularyregistry/badge.svg?branch=master
        :target: https://coveralls.io/github/zopefoundation/zope.vocabularyregistry?branch=master


This Zope 3 package provides a ``zope.schema`` vocabulary registry that uses
utilities to look up vocabularies.
