.. SPDX-FileCopyrightText: 2025 The Linux Foundation
..
.. SPDX-License-Identifier: EPL-1.0

.. _nexus2:

******
nexus2
******

.. program-output:: lftools-uv nexus2 --help

.. _nexus2_commands:

Commands
========


.. _nexus2_privileges:

privilege
---------

.. program-output:: lftools-uv nexus2 privilege --help

.. _nexus2_repository:

repository
----------

.. program-output:: lftools-uv nexus2 repository --help

.. _nexus2_role:

role
----

.. program-output:: lftools-uv nexus2 role --help

.. _nexus2_user:

user
----

.. program-output:: lftools-uv nexus2 user --help
