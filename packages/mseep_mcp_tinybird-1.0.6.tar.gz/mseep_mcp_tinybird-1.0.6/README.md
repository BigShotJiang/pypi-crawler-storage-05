# 🚨 DEPRECATED

**This repository is deprecated and no longer maintained.**

**New implementation:** [Tinybird MCP Server](https://www.tinybird.co/docs/forward/analytics-agents/mcp)

**Please migrate to the official implementation.**
