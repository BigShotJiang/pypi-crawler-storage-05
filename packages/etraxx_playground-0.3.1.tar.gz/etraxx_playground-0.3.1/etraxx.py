def etraxx_greetings():
    print("Hello from etraxx-playground!")


if __name__ == "__main__":
    etraxx_greetings()
