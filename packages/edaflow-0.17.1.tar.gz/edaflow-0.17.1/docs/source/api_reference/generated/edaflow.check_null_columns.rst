﻿edaflow.check\_null\_columns
============================

.. currentmodule:: edaflow

.. autofunction:: check_null_columns