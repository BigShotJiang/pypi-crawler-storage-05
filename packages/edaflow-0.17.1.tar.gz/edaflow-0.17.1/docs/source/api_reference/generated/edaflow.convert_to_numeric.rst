﻿edaflow.convert\_to\_numeric
============================

.. currentmodule:: edaflow

.. autofunction:: convert_to_numeric