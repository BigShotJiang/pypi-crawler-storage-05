def test_import_ECOv003_granules():
    import ECOv003_granules
