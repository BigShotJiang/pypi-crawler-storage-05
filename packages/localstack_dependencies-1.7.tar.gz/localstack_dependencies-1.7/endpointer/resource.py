RESOURCE_NOT_DEPLOYED = 'resource-not-published'
RESOURCE_NOT_PUBLISHED = 'resource-not-published'
RESOURCE_NOT_FOUND = 'resource-not-found'

def get_resource_token(request_uri):

    resource_token = request_uri[1]

    return resource_token
