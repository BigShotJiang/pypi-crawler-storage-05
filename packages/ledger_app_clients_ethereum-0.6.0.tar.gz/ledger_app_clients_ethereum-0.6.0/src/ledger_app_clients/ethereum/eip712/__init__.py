from .struct import EIP712FieldType  # noqa
