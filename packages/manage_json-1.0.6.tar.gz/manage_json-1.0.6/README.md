[![pypi](https://img.shields.io/badge/pypi-manage_json-blue)](https://pypi.org/project/manage_json/) [![tele](https://img.shields.io/badge/telegram-@paoligino-blue)](https://t.me/paoligino) [![Documentation Status](https://readthedocs.org/projects/manage-json/badge/?version=latest)](https://manage-json.readthedocs.io/?badge=latest)


```powershell
pip install -U manage_json
```
