default_app_config = (
    "core_user_registration_app.apps.UserRegistrationAppConfig"
)
