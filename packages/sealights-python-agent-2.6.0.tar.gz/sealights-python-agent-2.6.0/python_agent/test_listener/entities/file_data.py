class FileData(object):
    def __init__(self, path, methods, lines, branches):
        self.path = path
        self.methods = methods
        self.lines = lines
        self.branches = branches
