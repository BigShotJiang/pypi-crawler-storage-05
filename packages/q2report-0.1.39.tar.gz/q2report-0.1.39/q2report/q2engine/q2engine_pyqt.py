from .wwengine_core import WwEngineCore


class WwEnginePyQt(WwEngineCore):
    pass
