"""
VPC Stack Library for CDK-Factory
"""
