from .file_profiler import FileProfiler as FileProfiler

__all__ = ["FileProfiler"]
