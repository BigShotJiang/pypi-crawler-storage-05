from okctl_mcp_server.server import mcp, main

# Expose important items at package level
__all__ = ["main", "mcp"]
