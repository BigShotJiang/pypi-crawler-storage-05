"""
Millrun: A Python library and CLI tool to automate the execution of notebooks
with papermill.
"""

__version__ = "0.3.0"

from .millrun import execute_run
