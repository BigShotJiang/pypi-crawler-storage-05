import enum


class UnitAmountOfSubstancePerArea_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_mol_per_m2 = "mol/m2"
