import enum


class UnitTemperatureDifference_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_deltaC = "deltaC"
    Unit_deltaF = "deltaF"
    Unit_deltaR = "deltaR"
    Unit_deltaK = "deltaK"
