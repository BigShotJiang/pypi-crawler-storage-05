import enum


class UnitRadiantIntensity_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_W_per_sr = "W/sr"
