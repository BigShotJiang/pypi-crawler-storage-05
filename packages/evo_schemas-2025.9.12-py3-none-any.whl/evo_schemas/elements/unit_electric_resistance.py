import enum


class UnitElectricResistance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_ohm = "ohm"
    Unit_cohm = "cohm"
    Unit_dohm = "dohm"
    Unit_Eohm = "Eohm"
    Unit_fohm = "fohm"
    Unit_Gohm = "Gohm"
    Unit_kohm = "kohm"
    Unit_mohm = "mohm"
    Unit_Mohm = "Mohm"
    Unit_nohm = "nohm"
    Unit_pohm = "pohm"
    Unit_Tohm = "Tohm"
    Unit_uohm = "uohm"
