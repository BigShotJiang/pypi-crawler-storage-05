import enum


class UnitThermalConductance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_W_per_deltaK = "W/deltaK"
