import enum


class UnitMomentum_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_kg_m_per_s = "kg.m/s"
    Unit_lbm_ft_per_s = "lbm.ft/s"
