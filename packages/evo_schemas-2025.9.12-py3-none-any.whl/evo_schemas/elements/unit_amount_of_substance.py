import enum


class UnitAmountOfSubstance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_mol = "mol"
    Unit_lbmol = "lbmol"
    Unit_kmol = "kmol"
    Unit_mmol = "mmol"
    Unit_umol = "umol"
