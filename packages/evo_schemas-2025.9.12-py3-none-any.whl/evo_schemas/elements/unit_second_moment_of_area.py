import enum


class UnitSecondMomentOfArea_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_cm4 = "cm4"
    Unit_m4 = "m4"
    Unit_in4 = "in4"
