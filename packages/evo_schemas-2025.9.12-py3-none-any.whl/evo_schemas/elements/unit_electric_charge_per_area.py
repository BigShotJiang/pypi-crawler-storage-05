import enum


class UnitElectricChargePerArea_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_C_per_cm2 = "C/cm2"
    Unit_C_per_mm2 = "C/mm2"
    Unit_mC_per_m2 = "mC/m2"
    Unit_C_per_m2 = "C/m2"
