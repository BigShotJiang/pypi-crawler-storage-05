import enum


class UnitMassLength_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_kg_m = "kg.m"
    Unit_lbm_ft = "lbm.ft"
