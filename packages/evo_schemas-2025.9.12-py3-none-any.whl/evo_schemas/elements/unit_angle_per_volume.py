import enum


class UnitAnglePerVolume_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_rad_per_m3 = "rad/m3"
    Unit_rad_per_ft3 = "rad/ft3"
