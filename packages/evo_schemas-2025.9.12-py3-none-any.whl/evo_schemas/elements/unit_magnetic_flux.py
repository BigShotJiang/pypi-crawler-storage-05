import enum


class UnitMagneticFlux_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_Wb = "Wb"
    Unit_cWb = "cWb"
    Unit_dWb = "dWb"
    Unit_EWb = "EWb"
    Unit_fWb = "fWb"
    Unit_GWb = "GWb"
    Unit_kWb = "kWb"
    Unit_mWb = "mWb"
    Unit_MWb = "MWb"
    Unit_nWb = "nWb"
    Unit_pWb = "pWb"
    Unit_TWb = "TWb"
    Unit_uWb = "uWb"
