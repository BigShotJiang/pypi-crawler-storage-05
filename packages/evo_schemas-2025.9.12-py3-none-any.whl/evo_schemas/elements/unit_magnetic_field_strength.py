import enum


class UnitMagneticFieldStrength_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_Oe = "Oe"
    Unit_A_per_mm = "A/mm"
    Unit_A_per_m = "A/m"
