import enum


class UnitMomentOfInertia_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_kg_m2 = "kg.m2"
    Unit_lbm_ft2 = "lbm.ft2"
