import enum


class UnitLuminance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_cd_per_m2 = "cd/m2"
