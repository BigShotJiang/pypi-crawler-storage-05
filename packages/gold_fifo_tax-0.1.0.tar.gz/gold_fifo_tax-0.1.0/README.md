# Gold FIFO Tax Calculator 🇮🇳

A Python package to calculate **capital gains on gold (or similar assets) in India** using **FIFO matching** and **CII indexation**.
