"""
Common utilities package for Falcon MCP Server
"""
