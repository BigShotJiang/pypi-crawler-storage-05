hazards={
    "biostat_chf": {
        
    }
}
