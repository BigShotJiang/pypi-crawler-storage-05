from mcp_server_aliyun_observability import main

if __name__ == "__main__":
    main()
