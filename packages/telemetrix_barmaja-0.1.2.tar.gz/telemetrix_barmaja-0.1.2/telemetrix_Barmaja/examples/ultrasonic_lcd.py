
"""Strategy note: use Arduino to control I2C LCD; send text over Serial from Python if needed."""
print("See ultrasonic_lcd_telemetrix_Barmaja.py for distance; forward to Arduino LCD sketch.")
