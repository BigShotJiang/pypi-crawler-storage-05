def hello():
    print("Hello, Biotagging!")