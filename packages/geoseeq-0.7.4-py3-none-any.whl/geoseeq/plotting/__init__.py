from .constants import COLORS
from .highcharts import series_is_categorical, series_is_numeric, scatter_plot_config
from .selectable import SelectablePlot