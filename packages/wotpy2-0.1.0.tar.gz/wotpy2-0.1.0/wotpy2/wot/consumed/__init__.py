#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
ConsumedThing and related entities.

.. autosummary::
    :toctree: _consumed

    interaction_map
    thing
"""
