from django.dispatch import Signal

css_compressed = Signal()
js_compressed = Signal()
