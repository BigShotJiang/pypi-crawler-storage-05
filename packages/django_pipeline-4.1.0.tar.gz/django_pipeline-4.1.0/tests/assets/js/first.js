(function() {
  window.concat = function() {
    console.log(arguments);
  }
}()) // No semicolon
