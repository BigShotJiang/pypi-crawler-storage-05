const abc = 123;


//#  sourceMappingURL=sourcemap1.js.map

//@ sourceMappingURL=sourcemap2.js.map  

/*#  sourceMappingURL=sourcemap3.js.map */

/*@ sourceMappingURL=sourcemap4.js.map  */

//#  sourceURL=sourcemap5.js.map

//@ sourceURL=sourcemap6.js.map  

/*#  sourceURL=sourcemap7.js.map */

/*@ sourceURL=sourcemap8.js.map  */
