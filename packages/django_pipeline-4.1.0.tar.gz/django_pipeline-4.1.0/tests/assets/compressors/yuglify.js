(function(){!function(){window.concat=function(){console.log(arguments)}}(),function(){window.cat=function(){console.log("hello world")}}()}).call(this);
