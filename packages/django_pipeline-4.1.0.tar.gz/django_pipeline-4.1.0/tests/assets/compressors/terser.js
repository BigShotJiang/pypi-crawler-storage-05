(function(){window.concat=function(){console.log(arguments)},window.cat=function(){console.log("hello world")}}).call(this);
