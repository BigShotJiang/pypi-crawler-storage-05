# apis_acdhch_default_settings

Default settings for [APIS](https://github.com/acdh-oeaw/apis-core-rdf/) instances hosted at the ACDH-CH at the OEAW.
