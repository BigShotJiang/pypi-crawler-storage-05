import sys  
sys.path.append('../src')

from wsjt_all import *

wsjt_all_ab_live()

