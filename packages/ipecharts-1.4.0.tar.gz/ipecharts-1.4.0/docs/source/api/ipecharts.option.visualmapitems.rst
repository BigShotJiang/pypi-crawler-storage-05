ipecharts.option.visualmapitems package
=======================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   ipecharts.option.visualmapitems.continuous
   ipecharts.option.visualmapitems.piecewise

Module contents
---------------

.. automodule:: ipecharts.option.visualmapitems
   :members:
   :show-inheritance:
   :undoc-members:
