ipecharts.option.polar module
=============================

.. automodule:: ipecharts.option.polar
   :members:
   :show-inheritance:
   :undoc-members:
