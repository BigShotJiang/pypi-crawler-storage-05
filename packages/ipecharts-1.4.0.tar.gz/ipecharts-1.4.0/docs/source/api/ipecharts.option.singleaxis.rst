ipecharts.option.singleaxis module
==================================

.. automodule:: ipecharts.option.singleaxis
   :members:
   :show-inheritance:
   :undoc-members:
