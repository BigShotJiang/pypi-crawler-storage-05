ipecharts package
=================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ipecharts.option

Submodules
----------

.. toctree::
   :maxdepth: 4

   ipecharts.baseechartswidget
   ipecharts.basewidget
   ipecharts.echarts
   ipecharts.tools

Module contents
---------------

.. automodule:: ipecharts
   :members:
   :show-inheritance:
   :undoc-members:
