ipecharts.option.thumbnail module
=================================

.. automodule:: ipecharts.option.thumbnail
   :members:
   :show-inheritance:
   :undoc-members:
