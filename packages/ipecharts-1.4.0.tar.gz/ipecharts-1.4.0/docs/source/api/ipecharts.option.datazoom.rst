ipecharts.option.datazoom module
================================

.. automodule:: ipecharts.option.datazoom
   :members:
   :show-inheritance:
   :undoc-members:
