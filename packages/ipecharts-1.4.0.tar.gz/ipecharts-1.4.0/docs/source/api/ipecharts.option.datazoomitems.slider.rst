ipecharts.option.datazoomitems.slider module
============================================

.. automodule:: ipecharts.option.datazoomitems.slider
   :members:
   :show-inheritance:
   :undoc-members:
