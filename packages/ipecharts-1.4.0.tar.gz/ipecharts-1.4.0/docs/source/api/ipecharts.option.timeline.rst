ipecharts.option.timeline module
================================

.. automodule:: ipecharts.option.timeline
   :members:
   :show-inheritance:
   :undoc-members:
