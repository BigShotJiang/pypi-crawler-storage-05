ipecharts.option.seriesitems.line3d module
==========================================

.. automodule:: ipecharts.option.seriesitems.line3d
   :members:
   :show-inheritance:
   :undoc-members:
