ipecharts.option.parallelaxis module
====================================

.. automodule:: ipecharts.option.parallelaxis
   :members:
   :show-inheritance:
   :undoc-members:
