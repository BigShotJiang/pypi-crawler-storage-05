ipecharts.option.brush module
=============================

.. automodule:: ipecharts.option.brush
   :members:
   :show-inheritance:
   :undoc-members:
