ipecharts.option.datazoomitems.inside module
============================================

.. automodule:: ipecharts.option.datazoomitems.inside
   :members:
   :show-inheritance:
   :undoc-members:
