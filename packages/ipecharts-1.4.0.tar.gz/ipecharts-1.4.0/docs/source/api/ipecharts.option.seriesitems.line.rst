ipecharts.option.seriesitems.line module
========================================

.. automodule:: ipecharts.option.seriesitems.line
   :members:
   :show-inheritance:
   :undoc-members:
