ipecharts.option.seriesitems.scatter module
===========================================

.. automodule:: ipecharts.option.seriesitems.scatter
   :members:
   :show-inheritance:
   :undoc-members:
