ipecharts.option.seriesitems.boxplot module
===========================================

.. automodule:: ipecharts.option.seriesitems.boxplot
   :members:
   :show-inheritance:
   :undoc-members:
