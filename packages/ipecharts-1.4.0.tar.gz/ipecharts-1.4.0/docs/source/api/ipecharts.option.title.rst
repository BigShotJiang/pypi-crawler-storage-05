ipecharts.option.title module
=============================

.. automodule:: ipecharts.option.title
   :members:
   :show-inheritance:
   :undoc-members:
