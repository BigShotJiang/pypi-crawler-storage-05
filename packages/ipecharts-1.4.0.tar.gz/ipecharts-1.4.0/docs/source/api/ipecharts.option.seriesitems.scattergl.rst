ipecharts.option.seriesitems.scattergl module
=============================================

.. automodule:: ipecharts.option.seriesitems.scattergl
   :members:
   :show-inheritance:
   :undoc-members:
