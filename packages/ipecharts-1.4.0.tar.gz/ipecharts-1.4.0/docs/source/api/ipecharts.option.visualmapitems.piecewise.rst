ipecharts.option.visualmapitems.piecewise module
================================================

.. automodule:: ipecharts.option.visualmapitems.piecewise
   :members:
   :show-inheritance:
   :undoc-members:
