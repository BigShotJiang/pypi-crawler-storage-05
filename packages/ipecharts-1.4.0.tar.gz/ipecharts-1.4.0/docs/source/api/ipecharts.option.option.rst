ipecharts.option.option module
==============================

.. automodule:: ipecharts.option.option
   :members:
   :show-inheritance:
   :undoc-members:
