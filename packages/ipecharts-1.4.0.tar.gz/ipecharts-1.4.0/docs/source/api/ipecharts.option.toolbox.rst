ipecharts.option.toolbox module
===============================

.. automodule:: ipecharts.option.toolbox
   :members:
   :show-inheritance:
   :undoc-members:
