ipecharts.option.seriesitems.lines module
=========================================

.. automodule:: ipecharts.option.seriesitems.lines
   :members:
   :show-inheritance:
   :undoc-members:
