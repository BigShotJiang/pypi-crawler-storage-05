ipecharts.option.legend module
==============================

.. automodule:: ipecharts.option.legend
   :members:
   :show-inheritance:
   :undoc-members:
