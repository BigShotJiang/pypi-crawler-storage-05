ipecharts.option.seriesitems.map3d module
=========================================

.. automodule:: ipecharts.option.seriesitems.map3d
   :members:
   :show-inheritance:
   :undoc-members:
