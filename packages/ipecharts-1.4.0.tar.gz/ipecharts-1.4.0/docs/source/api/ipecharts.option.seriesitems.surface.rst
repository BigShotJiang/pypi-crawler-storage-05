ipecharts.option.seriesitems.surface module
===========================================

.. automodule:: ipecharts.option.seriesitems.surface
   :members:
   :show-inheritance:
   :undoc-members:
