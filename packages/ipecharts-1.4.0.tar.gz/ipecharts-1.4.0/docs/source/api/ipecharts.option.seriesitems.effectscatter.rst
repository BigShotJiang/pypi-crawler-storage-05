ipecharts.option.seriesitems.effectscatter module
=================================================

.. automodule:: ipecharts.option.seriesitems.effectscatter
   :members:
   :show-inheritance:
   :undoc-members:
