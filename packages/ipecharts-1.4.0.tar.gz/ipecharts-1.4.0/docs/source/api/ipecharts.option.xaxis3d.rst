ipecharts.option.xaxis3d module
===============================

.. automodule:: ipecharts.option.xaxis3d
   :members:
   :show-inheritance:
   :undoc-members:
