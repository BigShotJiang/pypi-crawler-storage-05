ipecharts.option.seriesitems.flowgl module
==========================================

.. automodule:: ipecharts.option.seriesitems.flowgl
   :members:
   :show-inheritance:
   :undoc-members:
