ipecharts.option.axispointer module
===================================

.. automodule:: ipecharts.option.axispointer
   :members:
   :show-inheritance:
   :undoc-members:
