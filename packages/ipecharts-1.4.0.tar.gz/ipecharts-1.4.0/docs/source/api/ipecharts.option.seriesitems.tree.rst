ipecharts.option.seriesitems.tree module
========================================

.. automodule:: ipecharts.option.seriesitems.tree
   :members:
   :show-inheritance:
   :undoc-members:
