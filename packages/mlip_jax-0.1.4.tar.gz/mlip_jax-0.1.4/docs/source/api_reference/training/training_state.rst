.. _training_state:

.. module:: mlip.training.training_state

Training state
==============

.. autoclass:: TrainingState
