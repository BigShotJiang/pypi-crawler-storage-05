.. _simulation_engine:

.. module:: mlip.simulation.simulation_engine

Simulation Engine: Interface
============================

.. autoclass:: SimulationEngine

    .. automethod:: __init__

    .. automethod:: run

    .. automethod:: attach_logger

    .. automethod:: _initialize
