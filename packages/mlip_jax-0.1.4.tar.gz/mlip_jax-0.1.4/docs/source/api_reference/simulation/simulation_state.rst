.. _simulation_state:

.. module:: mlip.simulation.state

Simulation State
================

.. autoclass:: SimulationState

    .. automethod:: __init__
