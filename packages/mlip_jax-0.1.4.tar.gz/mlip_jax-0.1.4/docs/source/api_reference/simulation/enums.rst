.. _simulation_enums:

.. module:: mlip.simulation.enums

Simulation Enums
================

.. _simulation_enums_type:

.. autoclass:: SimulationType

.. _simulation_enums_backend:

.. autoclass:: SimulationBackend

.. _simulation_enums_temperature_schedule_method:

.. autoclass:: TemperatureScheduleMethod
