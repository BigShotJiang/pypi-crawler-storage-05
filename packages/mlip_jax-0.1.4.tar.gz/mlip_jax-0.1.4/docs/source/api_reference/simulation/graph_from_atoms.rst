.. _graph_from_atoms:

.. module:: mlip.simulation.utils

Create graph from ASE atoms
===========================

.. autofunction:: create_graph_from_atoms
