.. _data_split:

.. module:: mlip.data.helpers.data_split

Data split
==========

.. autofunction:: split_data_randomly

.. autofunction:: split_data_randomly_by_group

.. autofunction:: split_data_by_group
