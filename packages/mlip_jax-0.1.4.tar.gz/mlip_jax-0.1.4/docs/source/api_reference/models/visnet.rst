.. _visnet:

ViSNet
======

.. module:: mlip.models.visnet.models

    .. autoclass:: Visnet

        .. automethod:: __call__

.. module:: mlip.models.visnet.config

    .. autoclass:: VisnetConfig
