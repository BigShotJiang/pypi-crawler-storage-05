.. _prediction:

.. module:: mlip.typing.prediction

Prediction
==========

.. autoclass:: Prediction
