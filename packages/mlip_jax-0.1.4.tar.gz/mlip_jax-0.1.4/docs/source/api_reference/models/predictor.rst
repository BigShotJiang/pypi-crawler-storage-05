.. _predictor:

.. module:: mlip.models.predictor

Force Field predictor
=====================

.. autoclass:: ForceFieldPredictor

        .. automethod:: __call__
