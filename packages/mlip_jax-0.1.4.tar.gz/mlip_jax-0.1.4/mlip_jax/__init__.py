from .dummy_script import show_message
