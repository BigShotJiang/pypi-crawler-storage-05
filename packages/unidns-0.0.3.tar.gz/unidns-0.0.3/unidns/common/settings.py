

class DNSSettings:
    def __init__(self):
        self.query_timeout = 0.5
        self.connection_keepalive_time = 10