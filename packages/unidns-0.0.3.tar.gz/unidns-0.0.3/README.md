# unidns

Rudimentary async DNS client in Python