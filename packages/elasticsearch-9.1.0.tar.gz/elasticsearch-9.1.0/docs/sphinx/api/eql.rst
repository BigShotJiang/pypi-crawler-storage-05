.. _eql:

Event Query Language (EQL)
--------------------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: EqlClient
   :members: