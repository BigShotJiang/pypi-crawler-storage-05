.. _query-rules:

Query rules
-----------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: QueryRulesClient
   :members:
