.. _async_search:

Async Search
------------

.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: AsyncSearchClient 
   :members:
