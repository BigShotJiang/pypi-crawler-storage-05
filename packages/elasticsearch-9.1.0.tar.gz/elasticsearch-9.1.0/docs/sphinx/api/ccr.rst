.. _ccr:

Cross-Cluster Replication (CCR)
-------------------------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: CcrClient
   :members: