.. _indices:

Indices
-------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: IndicesClient
   :members: