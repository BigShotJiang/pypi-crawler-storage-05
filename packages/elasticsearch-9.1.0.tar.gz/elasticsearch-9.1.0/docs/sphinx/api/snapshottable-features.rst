.. _snapshottable-features:

Snapshottable Features
----------------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: FeaturesClient
   :members: