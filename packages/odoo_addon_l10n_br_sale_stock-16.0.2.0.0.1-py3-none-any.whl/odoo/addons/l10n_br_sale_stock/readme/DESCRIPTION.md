Este módulo estende o módulo padrão de vendas e estoque do Odoo para
atender às necessidades específicas do Brasil, especialmente no contexto
de vendas de produtos com NF-e (Nota Fiscal Eletrônica).

Ele automatiza a propagação da operação fiscal, comentários fiscais e
incoterms para as faturas geradas diretamente a partir de ordens de
venda ou movimentações de estoque, garantindo que essas informações
sejam corretamente transferidas e utilizadas no processo de faturamento.
