from rich.prompt import Prompt, IntPrompt
from .logger import debug, info, warn, error
from .title import printTitle
import sys
def handle(commands):
    choice = IntPrompt.ask("[#f08080]Choose[/#f08080]")
    choice = int(choice)
    if(choice < 0 or choice > len(commands)+1):
        error("yiyliyo","Not a valid choice")
        return;
    if(choice == len(commands)+1): sys.exit(0)
    commands[choice].run()
        
    Prompt.ask(
        "[bold cyan]Press [Enter] to return to the menu[/bold cyan]",
        show_choices=False
    )
    printTitle(commands)