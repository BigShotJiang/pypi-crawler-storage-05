from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text
from rich.columns import Columns
from rich.rule import Rule
console = Console()

def printTitle(commands):
    console.clear()
    ascii_art = """_  _  __  _  _  __    __  _  _  __      
    ( \\/ )(  )( \\/ )(  )  (  )( \\/ )/  \\     
     )  /  )(  )  / / (_/\\ )(  )  /(  O )    
    (__/  (__)(__/  \\____/(__)(__/  \\__/     
     __ _  ____  ____  _  _   __  ____  __ _ 
    (  ( \\(  __)(_  _)/ )( \\ /  \\(  _ \\(  / )
    /    / ) _)   )(  \\ /\\ /(  O ))   / )  ( 
    \\_)__)(____) (__) (_/\\_) \\__/(__\\_)(__\\_)"""

    lines = ascii_art.splitlines()
    text = Text(justify="center")
    start_color = (255, 255, 0)
    mid_color = (255, 128, 0)
    end_color = (255, 0, 0)

    def lerp(a, b, t):
        return int(a + (b - a) * t)

    def blend(c1, c2, t):
        return tuple(lerp(a, b, t) for a, b in zip(c1, c2))

    n = len(lines)
    for i, line in enumerate(lines):
        if i < n // 2:
            color = blend(start_color, mid_color, i / (n // 2))
        else:
            color = blend(mid_color, end_color, (i - n // 2) / (n - n // 2 - 1))
        hex_color = f"#{color[0]:02x}{color[1]:02x}{color[2]:02x}"
        text.append(line + "\n", style=f"bold {hex_color}")
    cmds = []
    for i, (ind, mod) in enumerate(sorted(commands.items()), start=1):
        cmd_name = getattr(mod, "name", mod.__name__.split(".")[-1])
        cmds.append(f"[#f08080][{i}][/#f08080] {cmd_name}")

    cmds.append(f"[#f08080][{len(commands)+1}][/#f08080] Exit");
    columns = Columns(cmds, equal=True, expand=True)
    group = Group(
        text,
        Rule("", style="gray19"),
        columns
    )
    console.print(Panel(group, border_style="#382d0f"), overflow="crop")