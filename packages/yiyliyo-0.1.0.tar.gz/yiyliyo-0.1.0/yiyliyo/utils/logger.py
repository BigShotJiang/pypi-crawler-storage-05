from rich.console import Console
from rich.table import Table
from rich.text import Text
from datetime import datetime

console = Console()

def _log(level: str, color: str, prefix: str, text: str):
    table = Table.grid(expand=True)
    table.add_column(justify="left")
    table.add_column(justify="right")

    left = Text.assemble(
        (prefix, "bold cyan"), " | ",
        (level, color), " | ",
        text
    )
    right = Text(datetime.now().strftime("%H:%M:%S"), style="dim")

    table.add_row(left, right)
    console.print(table)

def debug(prefix: str, text: str):
    _log("DEBUG", "dim cyan", prefix, text)

def info(prefix: str, text: str):
    _log("INFO", "blue", prefix, text)

def warn(prefix: str, text: str):
    _log("WARNING", "yellow", prefix, text)

def error(prefix: str, text: str):
    _log("ERROR", "red", prefix, text)

def critical(prefix: str, text: str):
    _log("CRITICAL", "bold red", prefix, text)
