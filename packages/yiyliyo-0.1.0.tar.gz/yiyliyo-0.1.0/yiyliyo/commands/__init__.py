import pkgutil
import importlib

__all__ = []
modules = {} 

for _, module_name, _ in pkgutil.iter_modules(__path__):
    module = importlib.import_module(f"{__name__}.{module_name}")
    __all__.append(module_name)
    ind = getattr(module, "ind", None)
    if ind is None:
        raise ValueError(f"Module {module_name} does not define 'ind'")
    modules[ind] = module
