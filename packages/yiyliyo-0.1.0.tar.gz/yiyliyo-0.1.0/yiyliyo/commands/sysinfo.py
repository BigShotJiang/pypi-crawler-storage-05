name = "System Information"
description = "Prints information about the system"
ind = 1
import platform
import psutil
import socket
import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from yiyliyo.utils.logger import console

def run():
    hostname = socket.gethostname()
    os_name = platform.system()
    os_version = platform.version()
    os_release = platform.release()
    arch = platform.machine()
    kernel = platform.platform()
    uptime_seconds = psutil.boot_time()
    uptime = datetime.timedelta(seconds=(datetime.datetime.now().timestamp() - uptime_seconds))

    cpu_model = platform.processor() or "Unknown"
    cpu_cores = psutil.cpu_count(logical=False)
    cpu_threads = psutil.cpu_count(logical=True)
    cpu_freq = psutil.cpu_freq().current if psutil.cpu_freq() else None

    mem = psutil.virtual_memory()

    disk = psutil.disk_usage("/")

    net = psutil.net_if_addrs()
    interfaces = []
    for name, addrs in net.items():
        for addr in addrs:
            if addr.family == socket.AF_INET:
                interfaces.append((name, addr.address, addr.netmask, addr.broadcast))
            elif addr.family == psutil.AF_LINK:
                interfaces.append((name, addr.address, None, None))

    console.print(Panel.fit(f"[bold cyan]System Information[/bold cyan]", border_style="cyan"), justify="center")
    sys_table = Table(show_header=False, box=None)
    sys_table.add_row("Hostname:", hostname)
    sys_table.add_row("OS:", f"{os_name} {os_release}")
    sys_table.add_row("Kernel:", kernel)
    sys_table.add_row("Arch:", arch)
    sys_table.add_row("Uptime:", str(uptime).split('.')[0])
    console.print(sys_table)

    console.rule("[bold green]CPU", style="green")
    cpu_table = Table(show_header=False, box=None)
    cpu_table.add_row("Model:", cpu_model)
    cpu_table.add_row("Cores:", str(cpu_cores))
    cpu_table.add_row("Threads:", str(cpu_threads))
    if cpu_freq:
        cpu_table.add_row("Frequency:", f"{cpu_freq:.2f} MHz")
    console.print(cpu_table)

    console.rule("[bold magenta]Memory", style="magenta")
    mem_table = Table(show_header=False, box=None)
    mem_table.add_row("Total:", f"{mem.total / 1024**3:.2f} GiB")
    mem_table.add_row("Used:", f"{mem.used / 1024**3:.2f} GiB")
    mem_table.add_row("Free:", f"{mem.available / 1024**3:.2f} GiB")
    console.print(mem_table)

    console.rule("[bold yellow]Disk", style="yellow")
    disk_table = Table(show_header=False, box=None)
    disk_table.add_row("Total:", f"{disk.total / 1024**3:.2f} GiB")
    disk_table.add_row("Used:", f"{disk.used / 1024**3:.2f} GiB")
    disk_table.add_row("Free:", f"{disk.free / 1024**3:.2f} GiB")
    console.print(disk_table)

    net_table = Table(show_header=True, header_style="bold blue", title="Network Interfaces")
    net_table.add_column("Interface")
    net_table.add_column("IP Address")
    net_table.add_column("Netmask")
    net_table.add_column("Broadcast")
    for iface, ip, netmask, bcast in interfaces:
        net_table.add_row(iface, ip or "-", netmask or "-", bcast or "-")