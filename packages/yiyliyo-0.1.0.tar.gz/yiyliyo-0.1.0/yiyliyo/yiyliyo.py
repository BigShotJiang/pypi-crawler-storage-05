import argparse
import importlib
import pkgutil
from yiyliyo import commands
from rich.console import Console
from .utils.title import printTitle
from .utils.handler import handle


def main():
    printTitle(commands.modules);
    while True: handle(commands.modules)


    