"""
Mediascope API library
"""
version = '1.4.0'
