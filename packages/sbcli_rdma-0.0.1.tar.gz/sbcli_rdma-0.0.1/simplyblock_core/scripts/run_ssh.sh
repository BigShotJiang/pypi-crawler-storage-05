echo "root:$1" | chpasswd
/usr/sbin/sshd -D