---
title: Redirecting…
---

<meta http-equiv="refresh" content="0; url=https://lancedb.com/docs/geneva/deployment/troubleshooting/">
<link rel="canonical" href="url=https://lancedb.com/docs/geneva/deployment/troubleshooting/">

If you are not redirected, <a href="url=https://lancedb.com/docs/geneva/deployment/troubleshooting/">click here</a>.
