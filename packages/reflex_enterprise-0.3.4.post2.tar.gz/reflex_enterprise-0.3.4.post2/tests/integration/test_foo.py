def test_foo():
    """Placeholder for integrations tests."""
    assert True
