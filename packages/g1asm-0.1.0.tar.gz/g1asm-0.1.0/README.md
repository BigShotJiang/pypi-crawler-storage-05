# g1asm

Assembler implementation for the g1 ISA.
