from catchers.core import *
from catchers.tests import *

if __name__ == "__main__":
    main()
