# minivc

Minimal Git-like VCS for learning & demos.

## Install
```bash
pipx install minivc
minivc -h
