def main():
    print("Hello from awesome-energy-datasets!")


if __name__ == "__main__":
    main()
