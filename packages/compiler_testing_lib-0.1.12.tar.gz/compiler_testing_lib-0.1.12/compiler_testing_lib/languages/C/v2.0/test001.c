printf(1);
x = 3+6/3   *  2 -+-  +  2*4/2 + 0/1 -((6+ ((4)))/(2)); // Teste // Teste 2;
y_1 = 3;
y_1 = y_1 + 2;  

z__ = x + y_1;


// Saida final
printf(x);
printf(z__+1);
;;; // Teste do filter