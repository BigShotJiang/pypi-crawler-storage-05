// Unexpected token IDEN
X = 1;
j = 9 X;