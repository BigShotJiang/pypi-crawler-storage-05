// Unexpected token EOL
s = 1+;