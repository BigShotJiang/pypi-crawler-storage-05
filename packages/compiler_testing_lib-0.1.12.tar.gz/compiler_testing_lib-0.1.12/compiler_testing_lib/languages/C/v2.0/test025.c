// Unexpected token OPEN_PAR (wrong print token)
Printf(8);