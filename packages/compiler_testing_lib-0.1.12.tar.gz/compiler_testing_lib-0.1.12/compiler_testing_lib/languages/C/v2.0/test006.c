// Unexpected token EOL
a = -;