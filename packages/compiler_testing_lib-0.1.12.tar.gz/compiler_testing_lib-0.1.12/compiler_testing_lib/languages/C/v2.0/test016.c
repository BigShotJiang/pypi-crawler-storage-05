// Unexpected token DIV
n = 5+/6;