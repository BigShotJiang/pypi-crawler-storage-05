// Unexpected token DIV
y = /5;