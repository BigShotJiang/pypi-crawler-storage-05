// Unexpected token DIV
q = 7*/2;