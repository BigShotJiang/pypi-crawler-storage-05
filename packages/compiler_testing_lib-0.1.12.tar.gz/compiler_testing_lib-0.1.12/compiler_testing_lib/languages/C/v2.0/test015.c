// Unexpected token MULT
j = 6+*1;