// Unexpected token INT
3 = 2 + 6;