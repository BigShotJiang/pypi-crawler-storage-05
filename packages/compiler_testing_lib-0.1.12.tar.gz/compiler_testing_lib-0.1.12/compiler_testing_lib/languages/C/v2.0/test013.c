// Unexpected token MULT
r = *;