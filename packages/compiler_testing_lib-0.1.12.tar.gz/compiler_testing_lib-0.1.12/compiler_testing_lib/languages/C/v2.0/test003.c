// Unexpected token EOL
p = 1-;