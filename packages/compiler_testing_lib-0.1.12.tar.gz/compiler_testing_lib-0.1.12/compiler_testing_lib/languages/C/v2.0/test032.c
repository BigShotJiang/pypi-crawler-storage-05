// Unexpected token ASSIGN (expected OPEN_PAR)
printf = c;