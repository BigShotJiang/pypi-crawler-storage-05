// Unexpected token INT (expected EOL)
x = 3 5;