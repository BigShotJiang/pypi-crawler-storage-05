// Unexpected token EOF
r = //6;