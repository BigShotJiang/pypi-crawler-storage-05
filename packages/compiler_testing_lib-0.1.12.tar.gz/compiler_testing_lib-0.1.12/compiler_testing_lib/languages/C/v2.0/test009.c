// Unexpected token MULT
d = *6;