// Unexpected token MULT
e = 3/*5;