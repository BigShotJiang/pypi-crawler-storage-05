// Unexpected token EOL
z = ;