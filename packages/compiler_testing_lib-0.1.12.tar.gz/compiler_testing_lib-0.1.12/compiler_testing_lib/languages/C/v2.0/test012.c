// Unexpected token EOL
e = 2/;