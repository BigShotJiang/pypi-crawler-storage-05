// Unexpected token EOL
z = 7*;