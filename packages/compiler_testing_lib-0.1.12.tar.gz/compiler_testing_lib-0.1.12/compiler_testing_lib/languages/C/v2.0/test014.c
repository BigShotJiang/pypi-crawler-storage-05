// Unexpected token DIV
x = /;