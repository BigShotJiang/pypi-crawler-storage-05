// Unexpected token MULT
s = 8**1;