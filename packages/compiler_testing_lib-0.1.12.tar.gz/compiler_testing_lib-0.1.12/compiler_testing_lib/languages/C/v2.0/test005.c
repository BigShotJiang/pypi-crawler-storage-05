// Unexpected token EOL
b = +;