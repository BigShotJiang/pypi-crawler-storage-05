// Unexpected token IDEN
1x = 7;
printf(1x);