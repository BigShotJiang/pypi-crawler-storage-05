// Incompatible Types
int s = 6/true;