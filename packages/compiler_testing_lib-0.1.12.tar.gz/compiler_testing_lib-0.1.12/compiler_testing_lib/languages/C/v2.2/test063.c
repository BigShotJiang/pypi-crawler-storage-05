// Variable not found
bool k = True;