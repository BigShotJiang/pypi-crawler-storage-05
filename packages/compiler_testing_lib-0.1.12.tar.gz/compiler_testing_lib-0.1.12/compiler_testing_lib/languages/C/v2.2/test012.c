// Unexpected token EOL
int o = 6/;