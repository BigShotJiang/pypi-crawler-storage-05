// Missing Right Expression
int k = 1;
if (k <) {
  k = 2;
}