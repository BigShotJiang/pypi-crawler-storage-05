// Variable Already Declared
int s;
str s;