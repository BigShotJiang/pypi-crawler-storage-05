// Unexpected token DIV
int v = 6+/5;