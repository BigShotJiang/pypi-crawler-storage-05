// Incompatible Types
bool j = "a"."b";