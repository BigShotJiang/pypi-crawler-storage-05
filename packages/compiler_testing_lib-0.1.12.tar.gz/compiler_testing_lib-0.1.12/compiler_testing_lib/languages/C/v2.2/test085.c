// Incompatible Types
str o = 5+7;