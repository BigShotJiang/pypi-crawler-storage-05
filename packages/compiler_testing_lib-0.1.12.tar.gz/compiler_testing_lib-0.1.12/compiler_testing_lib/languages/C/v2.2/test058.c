// Incompatible types
str s = 3;