// Incompatible types
int u = true;