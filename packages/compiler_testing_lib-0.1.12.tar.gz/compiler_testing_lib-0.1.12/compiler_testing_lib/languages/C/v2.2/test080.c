// Incompatible Types
int s = 1*true;