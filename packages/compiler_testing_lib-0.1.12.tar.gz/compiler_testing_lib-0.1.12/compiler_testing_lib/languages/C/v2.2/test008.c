// Invalid token ,
int g = ,;