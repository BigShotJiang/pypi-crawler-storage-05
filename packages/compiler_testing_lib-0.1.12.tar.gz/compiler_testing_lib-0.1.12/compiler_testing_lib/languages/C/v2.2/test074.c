// Incompatible Types
bool e = "a"||6;