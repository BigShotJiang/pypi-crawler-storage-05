// Unexpected token DIV
int g = 2*/1;