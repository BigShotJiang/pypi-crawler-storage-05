// Unexpected token EOL (expected CLOSE_PAR)
printf(5;