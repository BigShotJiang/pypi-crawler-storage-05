// Incompatible types
bool r = 2;