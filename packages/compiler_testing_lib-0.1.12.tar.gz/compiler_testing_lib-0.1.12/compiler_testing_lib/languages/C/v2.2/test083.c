// Incompatible Types
int h = true/1;