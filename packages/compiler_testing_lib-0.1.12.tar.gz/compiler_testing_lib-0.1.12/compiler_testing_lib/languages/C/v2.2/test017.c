// Unexpected token MULT
int g = 1**8;