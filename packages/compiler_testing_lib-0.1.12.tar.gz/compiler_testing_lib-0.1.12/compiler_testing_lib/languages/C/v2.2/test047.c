// Missing Right Expression
int n = 1;
if (!) {
  n = 2;
}