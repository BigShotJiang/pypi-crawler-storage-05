// Unexpected token IDEN
int L = 1;
int g = 9 L;