{
  // Unexpected token EOF (expected CLOSE_BRA)
  int v = 5;