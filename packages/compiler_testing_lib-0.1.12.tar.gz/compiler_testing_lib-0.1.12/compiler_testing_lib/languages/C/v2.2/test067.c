// Incompatible Types
bool v = 8>"a";