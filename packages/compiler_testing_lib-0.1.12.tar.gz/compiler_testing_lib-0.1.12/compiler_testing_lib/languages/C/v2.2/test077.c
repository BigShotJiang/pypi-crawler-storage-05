// Incompatible Types
int s = true+1;