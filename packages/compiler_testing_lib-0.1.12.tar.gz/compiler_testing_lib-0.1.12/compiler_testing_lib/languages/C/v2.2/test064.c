// Incompatible Types
bool n = 3=="a";