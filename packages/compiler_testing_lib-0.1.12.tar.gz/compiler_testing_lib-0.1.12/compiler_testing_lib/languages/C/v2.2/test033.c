// Unexpected token IDEN
int 1x = 1;
printf(1x);