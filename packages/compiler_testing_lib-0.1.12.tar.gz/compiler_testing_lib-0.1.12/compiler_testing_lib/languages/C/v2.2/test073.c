// Incompatible Types
bool g = "a"&&6;