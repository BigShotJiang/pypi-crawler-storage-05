// Unexpected token EOL
int k = -;