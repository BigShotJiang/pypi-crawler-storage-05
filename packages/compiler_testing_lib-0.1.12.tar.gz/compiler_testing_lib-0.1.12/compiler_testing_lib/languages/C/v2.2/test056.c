// Incompatible types
bool d = "a";