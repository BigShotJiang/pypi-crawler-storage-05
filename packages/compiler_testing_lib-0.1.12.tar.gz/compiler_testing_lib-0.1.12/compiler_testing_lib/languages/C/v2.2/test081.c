// Incompatible Types
int p = true*1;