// Unexpected token INT (expected EOL)
int t = 3 4;