// Incompatible types
int g = "a";