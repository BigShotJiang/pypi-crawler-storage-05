// Incompatible types
bool q = 2;