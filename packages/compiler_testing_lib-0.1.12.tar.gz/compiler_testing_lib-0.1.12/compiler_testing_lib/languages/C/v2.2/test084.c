// Incompatible Types
int o = true||false;