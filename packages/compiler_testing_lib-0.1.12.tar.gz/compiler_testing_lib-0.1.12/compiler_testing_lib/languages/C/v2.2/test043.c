// Unexpected ELSE
int d = 1;
if (d == 1) {
  d = 2;
} else {
  d = 3;
} else {
  d = 4;
}