// Missing OPEN_PAR
int d = scanf;