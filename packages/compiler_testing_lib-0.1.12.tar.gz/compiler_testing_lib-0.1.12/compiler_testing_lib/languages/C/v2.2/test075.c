// Incompatible Types
bool k = !1;