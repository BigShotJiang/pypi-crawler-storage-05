// Unexpected token EOL
int x = 8*;