// Incompatible Types
if (1+1) {
}