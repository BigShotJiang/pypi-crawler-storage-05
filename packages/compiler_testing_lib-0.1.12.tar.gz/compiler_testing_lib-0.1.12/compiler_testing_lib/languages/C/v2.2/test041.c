// Unexpected EOF (Missing CLOSE_BRA)
int f = 1;
while (f == 1) {
  f = 2;