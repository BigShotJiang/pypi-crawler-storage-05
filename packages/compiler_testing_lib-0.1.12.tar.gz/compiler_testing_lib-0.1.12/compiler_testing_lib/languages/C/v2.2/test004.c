// Unexpected token EOL
int y = ;