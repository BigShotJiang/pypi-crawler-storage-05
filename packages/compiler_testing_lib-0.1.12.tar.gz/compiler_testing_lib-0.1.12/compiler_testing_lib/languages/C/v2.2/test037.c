// Unexpected EOF (Missing CLOSE_BRA)
int y = 1;
if (y == 1) {