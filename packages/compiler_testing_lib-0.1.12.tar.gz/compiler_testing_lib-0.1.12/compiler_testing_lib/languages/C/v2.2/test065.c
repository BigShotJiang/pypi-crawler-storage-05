// Incompatible Types
bool q = 1==true;