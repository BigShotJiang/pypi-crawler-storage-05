// Missing OPEN_BRA
int u = 1;
while (u == 1)
  u = 2;
}