// Unexpected token DIV
int r = /;