// Unexpected EOF (Missing CLOSE_BRA)
int m = 1;
if (m == 1) {
  m = 2;
} else {
  m = 3;