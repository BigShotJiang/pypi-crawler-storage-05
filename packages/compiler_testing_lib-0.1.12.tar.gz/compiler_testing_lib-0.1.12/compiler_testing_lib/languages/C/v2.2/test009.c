// Unexpected token MULT
int c = *1;