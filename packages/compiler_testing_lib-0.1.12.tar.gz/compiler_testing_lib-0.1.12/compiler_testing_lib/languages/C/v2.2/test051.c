// Missing OPEN_PAR
while 1 == 1 {
  int y = 6;
}