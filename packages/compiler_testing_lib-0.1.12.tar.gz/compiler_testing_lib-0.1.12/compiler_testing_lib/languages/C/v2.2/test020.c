// Unexpected token MULT
int y = 7/*7;