// Incompatible types
str s = scanf();