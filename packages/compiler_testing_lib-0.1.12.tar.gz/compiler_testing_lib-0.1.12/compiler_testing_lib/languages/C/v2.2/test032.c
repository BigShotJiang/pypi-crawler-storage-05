// Unexpected token CLOSE_BRA (expected EOF)
int x = 3;
}