// Incompatible types
str b = false;