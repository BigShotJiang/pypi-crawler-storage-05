// Incompatible Types
bool b = 1>true;