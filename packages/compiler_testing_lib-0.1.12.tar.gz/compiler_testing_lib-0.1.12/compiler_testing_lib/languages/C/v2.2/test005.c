// Unexpected token EOL
int z = +;