// Unexpected token MULT
int w = *;