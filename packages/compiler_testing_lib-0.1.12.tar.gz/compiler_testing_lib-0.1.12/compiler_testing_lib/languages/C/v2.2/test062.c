// Unexpected EOF
str h = "a;