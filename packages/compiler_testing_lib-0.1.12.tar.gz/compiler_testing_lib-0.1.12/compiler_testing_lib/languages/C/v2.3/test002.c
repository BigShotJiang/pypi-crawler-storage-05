void main() {
  // Unexpected token EOL
  int o = 4+;
}
