void main() {
  // Incompatible Types
  bool m = 1>true;
}
