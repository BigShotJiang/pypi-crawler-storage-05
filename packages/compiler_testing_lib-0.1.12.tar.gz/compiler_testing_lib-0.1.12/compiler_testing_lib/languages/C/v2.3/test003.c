void main() {
  // Unexpected token EOL
  int e = 9-;
}
