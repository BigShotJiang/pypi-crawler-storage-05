void main() {
  // Incompatible types
  int b = "a";
}
