void main() {
  // Unexpected token IDEN
  int 1x = 7;
  printf(1x);
}
