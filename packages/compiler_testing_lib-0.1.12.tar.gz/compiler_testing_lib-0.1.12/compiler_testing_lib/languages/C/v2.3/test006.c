void main() {
  // Unexpected token EOL
  int h = -;
}
