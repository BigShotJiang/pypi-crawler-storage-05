void main() {
  // Incompatible types
  int o = true;
}
