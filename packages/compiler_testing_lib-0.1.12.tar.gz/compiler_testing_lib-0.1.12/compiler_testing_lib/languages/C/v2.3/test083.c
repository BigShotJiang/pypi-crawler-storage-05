void main() {
  // Incompatible Types
  int g = 1*true;
}
