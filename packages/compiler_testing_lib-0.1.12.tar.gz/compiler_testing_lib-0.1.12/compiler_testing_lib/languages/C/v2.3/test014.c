void main() {
  // Unexpected token DIV
  int o = /;
}
