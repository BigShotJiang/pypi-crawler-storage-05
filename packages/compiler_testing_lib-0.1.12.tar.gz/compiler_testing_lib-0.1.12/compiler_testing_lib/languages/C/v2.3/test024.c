void main() {
  // Unexpected token CLOSE_PAR
  int a = (3));
}
