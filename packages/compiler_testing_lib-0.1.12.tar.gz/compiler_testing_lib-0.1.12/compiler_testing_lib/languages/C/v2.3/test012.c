void main() {
  // Unexpected token EOL
  int d = 4/;
}
