void main() {
  // Incompatible Types
  int i = true*1;
}
