void main() {
  // Incompatible Types
  bool m = "a"||1;
}
