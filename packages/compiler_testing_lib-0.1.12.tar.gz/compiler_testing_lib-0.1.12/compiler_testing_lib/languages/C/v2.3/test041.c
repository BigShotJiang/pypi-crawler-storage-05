void main() {
  // Missing OPEN_BRA
  int x = 1;
  if (x == 1)
    x = 2;
  }
}
