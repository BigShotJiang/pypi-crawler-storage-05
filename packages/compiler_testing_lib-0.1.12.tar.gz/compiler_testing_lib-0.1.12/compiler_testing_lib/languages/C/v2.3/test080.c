void main() {
  // Incompatible Types
  int e = true+1;
}
