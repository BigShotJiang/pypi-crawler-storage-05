void main() {
  // Missing CLOSE_PAR
  int x = (8;
}
