void main() {
  // Unexpected token MULT
  int q = 7+*1;
}
