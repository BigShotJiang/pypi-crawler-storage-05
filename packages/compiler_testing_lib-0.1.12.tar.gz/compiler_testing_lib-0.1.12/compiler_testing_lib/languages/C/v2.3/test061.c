void main() {
  // Incompatible types
  str z = 4;
}
