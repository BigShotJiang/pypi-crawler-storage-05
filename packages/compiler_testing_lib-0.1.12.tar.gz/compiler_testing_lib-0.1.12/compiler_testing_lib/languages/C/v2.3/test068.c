void main() {
  // Incompatible Types
  bool o = 1==true;
}
