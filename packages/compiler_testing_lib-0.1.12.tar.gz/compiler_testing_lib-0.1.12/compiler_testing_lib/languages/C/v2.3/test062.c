void main() {
  // Incompatible types
  str d = false;
}
