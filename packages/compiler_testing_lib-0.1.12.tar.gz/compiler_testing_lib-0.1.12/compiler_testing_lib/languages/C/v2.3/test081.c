void main() {
  // Incompatible Types
  int r = 1-true;
}
