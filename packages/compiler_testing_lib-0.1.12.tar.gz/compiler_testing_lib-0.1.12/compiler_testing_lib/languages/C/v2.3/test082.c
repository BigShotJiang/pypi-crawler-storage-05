void main() {
  // Incompatible Types
  int v = true-1;
}
