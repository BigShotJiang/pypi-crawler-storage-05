void main() {
  // Unexpected token EOF (expected CLOSE_BRA)
  int u = 1;
