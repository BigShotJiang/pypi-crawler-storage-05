void main() {
  // Missing OPEN_BRA
  int k = 1;
  while (k == 1)
    k = 2;
  }
}
