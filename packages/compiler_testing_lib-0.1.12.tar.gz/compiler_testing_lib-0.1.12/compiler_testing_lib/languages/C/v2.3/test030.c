void main() {
  // Identifier not found
  int x1 = 6;
  printf(X1);
}
