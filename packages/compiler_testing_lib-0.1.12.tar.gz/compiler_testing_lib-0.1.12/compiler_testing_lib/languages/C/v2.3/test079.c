void main() {
  // Incompatible Types
  int o = 1+true;
}
