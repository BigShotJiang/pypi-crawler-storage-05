int e = 6;
void main() {
  // Function not found
  printf(e(8));
}
