void main() {
  // Unexpected token MULT
  int a = 1**9;
}
