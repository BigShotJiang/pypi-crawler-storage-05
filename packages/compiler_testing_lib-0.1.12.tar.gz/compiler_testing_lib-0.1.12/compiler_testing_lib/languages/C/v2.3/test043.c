void main() {
  // Missing OPEN_BRA
  int m = 1;
  if (m == 1) {
    m = 2;
  } else
    m = 3;
  }
}
