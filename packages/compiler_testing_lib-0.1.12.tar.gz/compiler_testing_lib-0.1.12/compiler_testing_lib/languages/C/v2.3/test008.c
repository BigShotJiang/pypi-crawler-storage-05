void main() {
  // Invalid token @
  int o = @;
}
