void main() {
  // Incompatible Types
  bool k = "a"<true;
}
