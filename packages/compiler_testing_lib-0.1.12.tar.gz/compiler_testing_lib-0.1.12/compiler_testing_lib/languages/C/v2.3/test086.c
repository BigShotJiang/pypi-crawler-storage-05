void main() {
  // Incompatible Types
  int q = true/1;
}
