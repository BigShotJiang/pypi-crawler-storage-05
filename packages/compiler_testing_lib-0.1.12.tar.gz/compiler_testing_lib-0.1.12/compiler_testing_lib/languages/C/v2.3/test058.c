void main() {
  // Incompatible types
  bool u = 5;
}
