void main() {
  // Var out of scope
  {
    int n = 7;
  }
  n = 6;
}
