void main() {
  // Unexpected token CLOSE_PAR
  int u = 2);
}
