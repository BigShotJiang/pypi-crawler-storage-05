void main() {
  // Incompatible Types
  bool t = 2>"a";
}
