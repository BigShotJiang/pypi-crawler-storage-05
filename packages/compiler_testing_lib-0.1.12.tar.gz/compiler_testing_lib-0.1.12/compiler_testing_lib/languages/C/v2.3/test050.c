void main() {
  // Missing Right Expression
  int i = 1;
  if (!) {
    i = 2;
  }
}
