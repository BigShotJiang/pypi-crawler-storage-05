void main() {
  // Unexpected token INT (expected EOL)
  int h = 6 2;
}
