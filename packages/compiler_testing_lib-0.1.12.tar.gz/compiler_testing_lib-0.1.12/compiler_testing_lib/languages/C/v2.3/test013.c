void main() {
  // Unexpected token MULT
  int h = *;
}
