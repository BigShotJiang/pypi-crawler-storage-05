void main() {
  // Incompatible types
  bool f = "a";
}
