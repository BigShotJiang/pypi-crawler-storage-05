void main() {
  // Incompatible Types
  bool h = true<1;
}
