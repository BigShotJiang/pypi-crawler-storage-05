void main() {
  // Missing OPEN_PAR
  int e = scanf;
}
