void main() {
  // Incompatible Types
  int e = true||false;
}
