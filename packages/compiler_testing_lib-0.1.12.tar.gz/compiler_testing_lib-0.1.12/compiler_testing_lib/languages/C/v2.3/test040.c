void main() {
  // Unexpected EOF (Missing CLOSE_BRA)
  int u = 1;
  if (u == 1) {
}
