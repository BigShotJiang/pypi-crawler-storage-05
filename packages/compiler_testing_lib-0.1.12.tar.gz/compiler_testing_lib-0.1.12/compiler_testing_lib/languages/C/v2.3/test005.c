void main() {
  // Unexpected token EOL
  int q = +;
}
