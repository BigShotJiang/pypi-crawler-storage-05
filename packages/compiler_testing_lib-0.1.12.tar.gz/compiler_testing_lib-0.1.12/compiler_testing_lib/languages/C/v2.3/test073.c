void main() {
  // Incompatible Types
  bool x = 5<"a";
}
