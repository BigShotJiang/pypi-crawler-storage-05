void main() {
  // Incompatible Types
  bool i = "a"<true;
}
