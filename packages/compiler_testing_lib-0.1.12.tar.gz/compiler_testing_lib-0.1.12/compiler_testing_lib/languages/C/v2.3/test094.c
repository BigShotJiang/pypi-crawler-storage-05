int test(int x,) {
  // Missing second arg
  return 7;
}
void main() {
  printf(test(3));
}
