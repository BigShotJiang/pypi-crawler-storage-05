void main() {
  // Incompatible types
  bool a = 7;
}
