void main() {
  // Unexpected token EOL
  int k = ;
}
