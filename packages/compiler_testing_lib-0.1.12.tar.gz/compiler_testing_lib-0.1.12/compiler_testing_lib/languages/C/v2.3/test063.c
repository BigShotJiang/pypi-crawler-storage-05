void main() {
  // Incompatible types
  str v = scanf();
}
