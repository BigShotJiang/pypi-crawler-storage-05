void main() {
  // Unexpected token DIV
  int h = 9+/8;
}
