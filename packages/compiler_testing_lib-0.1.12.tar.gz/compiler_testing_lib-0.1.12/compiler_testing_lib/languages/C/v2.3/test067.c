void main() {
  // Incompatible Types
  bool h = 5=="a";
}
