void main() {
  // Unexpected token CLOSE_BRA (expected EOF)
  int k = 8;
}
}
