void main() {
  // Unexpected token MULT
  int r = 2/*5;
}
