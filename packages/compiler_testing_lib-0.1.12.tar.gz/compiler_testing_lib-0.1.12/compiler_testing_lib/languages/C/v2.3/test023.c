void main() {
  // Missing CLOSE_PAR
  int m = ((8);
}
