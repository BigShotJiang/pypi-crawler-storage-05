int test(int x) {
  return x;
}
void main() {
  // Function not found
  printf(Test(3));
}
