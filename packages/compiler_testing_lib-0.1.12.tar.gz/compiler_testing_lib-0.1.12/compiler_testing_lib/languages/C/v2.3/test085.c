void main() {
  // Incompatible Types
  int p = 7/true;
}
