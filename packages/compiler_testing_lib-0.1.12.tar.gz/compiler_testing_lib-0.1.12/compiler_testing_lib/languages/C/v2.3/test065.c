void main() {
  // Unexpected EOF
  str h = "a;
}
