void main() {
  // Incompatible Types
  str w = 2+7;
}
