void main() {
  // Unexpected token CLOSE_BRA
  int e = //9;
}
