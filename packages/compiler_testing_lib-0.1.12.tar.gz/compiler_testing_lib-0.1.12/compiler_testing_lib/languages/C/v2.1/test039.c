// Unexpected EOF (Missing CLOSE_BRA)
s = 1;
if (s == 1) {
  s = 2;
} else {
  s = 3;