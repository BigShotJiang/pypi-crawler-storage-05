// Unexpected token IDEN
X = 1;
t = 7 X;