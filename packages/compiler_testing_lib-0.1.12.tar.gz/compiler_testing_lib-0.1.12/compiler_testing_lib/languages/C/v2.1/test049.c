// Missing CLOSE_PAR
w = scanf(;