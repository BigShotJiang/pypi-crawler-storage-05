// Unexpected token MULT
r = *1;