// Unexpected EOF (Missing CLOSE_BRA)
o = 1;
if (o == 1) {