// Unexpected token MULT
m = *;