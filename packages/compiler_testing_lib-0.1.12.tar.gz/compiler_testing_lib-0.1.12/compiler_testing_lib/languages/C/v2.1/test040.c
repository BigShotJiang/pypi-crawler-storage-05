// Missing OPEN_BRA
c = 1;
if (c == 1) {
  c = 2;
} else
  c = 3;
}