// Unexpected token EOL
y = 2+;