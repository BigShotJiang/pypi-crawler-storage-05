// Unexpected token INT
3 = 7 + 2;