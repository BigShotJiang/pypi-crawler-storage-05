// Unexpected token MULT
z = 8/*2;