// Unexpected token EOL
z = +;