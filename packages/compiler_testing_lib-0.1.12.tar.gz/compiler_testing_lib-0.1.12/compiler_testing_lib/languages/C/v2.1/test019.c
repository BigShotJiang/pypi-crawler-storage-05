// Unexpected token DIV
o = 4*/7;