// Missing OPEN_PAR
while 1 == 1 {
  w = 2;
}