// Unexpected token EOL
t = 2-;