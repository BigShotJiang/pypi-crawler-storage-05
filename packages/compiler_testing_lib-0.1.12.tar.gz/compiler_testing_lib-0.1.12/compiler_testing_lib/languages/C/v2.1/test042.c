// Missing OPEN_BRA
u = 1;
while (u == 1)
  u = 2;
}