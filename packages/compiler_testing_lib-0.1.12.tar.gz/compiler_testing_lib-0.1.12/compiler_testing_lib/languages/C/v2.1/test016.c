// Unexpected token DIV
q = 7+/3;