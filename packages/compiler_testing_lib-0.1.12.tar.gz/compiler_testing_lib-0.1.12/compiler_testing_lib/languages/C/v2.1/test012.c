// Unexpected token EOL
w = 1/;