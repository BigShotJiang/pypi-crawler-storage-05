// Unexpected token CLOSE_PAR
r = (1));