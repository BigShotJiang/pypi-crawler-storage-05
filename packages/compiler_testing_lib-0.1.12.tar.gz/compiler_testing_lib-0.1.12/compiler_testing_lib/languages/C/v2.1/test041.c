// Unexpected EOF (Missing CLOSE_BRA)
n = 1;
while (n == 1) {
  n = 2;