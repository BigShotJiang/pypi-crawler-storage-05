// Unexpected token EOL
d = 5*;