// Missing OPEN_PAR
if 1 == 1 {
  o = 8;
}