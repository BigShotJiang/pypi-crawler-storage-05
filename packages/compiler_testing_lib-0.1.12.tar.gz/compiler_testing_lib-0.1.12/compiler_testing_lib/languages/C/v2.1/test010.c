// Unexpected token DIV
a = /6;