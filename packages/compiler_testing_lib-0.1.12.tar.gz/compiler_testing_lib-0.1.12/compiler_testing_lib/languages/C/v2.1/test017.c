// Unexpected token MULT
a = 4**6;