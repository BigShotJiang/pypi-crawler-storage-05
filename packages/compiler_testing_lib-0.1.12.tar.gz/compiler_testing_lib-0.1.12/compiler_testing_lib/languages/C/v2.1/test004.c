// Unexpected token EOL
b = ;