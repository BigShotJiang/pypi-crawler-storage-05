{
  // Unexpected token EOF (expected CLOSE_BRA)
  y = 1;