// Unexpected token IDEN
1x = 9;
printf(1x);