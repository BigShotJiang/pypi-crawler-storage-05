// Unexpected token MULT
y = 9+*4;