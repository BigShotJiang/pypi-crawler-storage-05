// Unexpected token INT (expected EOL)
h = 6 2;