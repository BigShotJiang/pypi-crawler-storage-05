// Missing CLOSE_PAR
s = (4;