// Unexpected token DIV
y = /;