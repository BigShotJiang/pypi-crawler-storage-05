// Missing OPEN_PAR
z = scanf;