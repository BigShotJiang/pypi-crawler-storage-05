This module adds valued stock picking report according to Romanian
Legislation.
