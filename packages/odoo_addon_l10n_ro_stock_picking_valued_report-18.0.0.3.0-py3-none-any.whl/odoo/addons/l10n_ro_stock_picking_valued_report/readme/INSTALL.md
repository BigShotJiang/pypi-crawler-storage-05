To install this module, you need to:

- clone the branch 16.0 of the repository
  <https://github.com/OCA/l10n-romania>
- add the path to this repository in your configuration (addons-path)
- update the module list
- search for "Romania - Stock Picking Valued Report" in your addons
- install the module
