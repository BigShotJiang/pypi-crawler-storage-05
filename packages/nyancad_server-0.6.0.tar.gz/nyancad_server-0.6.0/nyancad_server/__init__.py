"""NyanCAD Server - ASGI server with marimo integration."""

__version__ = "0.1.0"
