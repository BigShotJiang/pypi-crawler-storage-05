import{U as s,C as o}from"./mermaid-0ClPHFIM.js";const n=(a,r)=>s.lang.round(o.parse(a)[r]);export{n as c};
