import{b as n}from"./_baseUniq-kkBJp3jc.js";function o(r){return n(r,4)}export{o as c};
