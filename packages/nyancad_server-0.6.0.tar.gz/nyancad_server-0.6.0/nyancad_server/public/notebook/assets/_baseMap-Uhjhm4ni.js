import{b as m}from"./_baseEach-2yxz4QPK.js";import{x as s}from"./index-BB71mG_d.js";function e(r,o){var a=-1,t=s(r)?Array(r.length):[];return m(r,function(n,f,i){t[++a]=o(n,f,i)}),t}export{e as b};
