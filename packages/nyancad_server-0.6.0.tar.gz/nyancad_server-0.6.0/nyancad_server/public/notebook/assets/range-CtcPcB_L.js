function u(e,r,t){e=+e,r=+r,t=(a=arguments.length)<2?(r=e,e=0,1):a<3?1:+t;for(var n=-1,a=0|Math.max(0,Math.ceil((r-e)/t)),o=new Array(a);++n<a;)o[n]=e+n*t;return o}export{u as r};
