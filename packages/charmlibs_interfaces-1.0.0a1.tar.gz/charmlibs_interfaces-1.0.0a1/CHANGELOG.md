# 1.0.0a1 - 8 September 2025

* Drop Python 3.8 support (>=3.10)
