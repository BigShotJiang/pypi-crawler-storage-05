def fun():
    print("Mo Adly The Genius ")




    