Welcome to askcarl's documentation!
==========================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   readme
   installation
   contributing
   issues
   modules
   lightgmm

.. include:: ../README.rst

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
