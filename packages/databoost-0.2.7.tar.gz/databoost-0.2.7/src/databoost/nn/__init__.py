from .calcoutputnn import calculate_output_nn
