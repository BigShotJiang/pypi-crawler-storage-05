import os

DEFAULT_FAVORS_HOME = os.path.join('~', '.favorites_crawler')
