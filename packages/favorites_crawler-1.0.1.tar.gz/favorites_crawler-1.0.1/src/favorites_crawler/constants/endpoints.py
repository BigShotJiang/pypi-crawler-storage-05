PIXIV_USER_BOOKMARKS_ENDPOINT = 'https://app-api.pixiv.net/v1/user/bookmarks/illust'

YANDERE_LIST_POST_URL = 'https://yande.re/post.json'
YANDERE_SHOW_POST_URL = 'https://yande.re/post/show/{id}'
YANDERE_VOTE_POST_URL = 'https://yande.re/post/vote.json'

LEMON_PIC_USER_CENTER_URL = 'https://www.emonl.com/user-center'
LEMON_PIC_POST_URL_PATTERN = 'https://www.emonl.com/{id}.html'

NHENTAI_LOGIN_URL = 'https://nhentai.net/login/?next=/favorites/'
NHENTAI_USER_FAVORITES_URL = 'https://nhentai.net/favorites/'

TWITTER_LIKES_URL = 'https://x.com/i/api/graphql/{id}/Likes'
