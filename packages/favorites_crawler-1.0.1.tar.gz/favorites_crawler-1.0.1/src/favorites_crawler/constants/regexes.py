ILLEGAL_FILENAME_CHARACTERS = r'[#%{}\<>*?/$!\'":@+`|=]'
