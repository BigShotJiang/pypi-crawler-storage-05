PIXIV_IOS_USER_AGENT = 'PixivIOSApp/4.13.3 (iOS 14.6; iPhone13,2)'

PIXIV_REQUEST_HEADERS = {
    'APP-OS': 'ios',
    'APP-OS-Version': '12.6',
    'Accept-Language': 'en',
}
