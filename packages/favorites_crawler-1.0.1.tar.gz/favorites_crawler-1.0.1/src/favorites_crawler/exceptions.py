class LoginFailed(Exception):
    pass
