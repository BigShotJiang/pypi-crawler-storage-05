# Py-Database-Library
Simple wrapper that allows me to quickly connect to the database.
