__version__ = "1.0.1"

import nt2.containers.data as nt2_data


class Data(nt2_data.Data):
    pass
