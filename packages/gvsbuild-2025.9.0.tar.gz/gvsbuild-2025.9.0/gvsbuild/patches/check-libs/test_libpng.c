// test for libpng

// include
    // standard
    #include "check_utils.h"
    // library
    #include <png.h>

// check one function from the dll
CHECK_ONE(png_get_header_ver)
