// test for libjpeg

// include
    // standard
    #include "check_utils.h"
    // library
    #include <jpeglib.h>

// check one function from the dll
CHECK_ONE(jpeg_CreateCompress)
