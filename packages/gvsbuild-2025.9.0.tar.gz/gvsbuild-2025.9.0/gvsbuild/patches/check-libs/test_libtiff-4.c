// test for libtiff-4

// include
    // standard
    #include "check_utils.h"
    // library
    #include <tiffio.h>

// check one function from the dll
CHECK_ONE(TIFFCleanup)
