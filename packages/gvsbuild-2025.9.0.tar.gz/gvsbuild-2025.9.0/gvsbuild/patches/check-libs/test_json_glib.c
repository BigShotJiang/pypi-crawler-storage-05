// test for json-glib

// include
    // standard
    #include "check_utils.h"
    // library
    #include <json-glib\json-glib.h>

// check one function from the dll
CHECK_ONE(json_parser_new)
