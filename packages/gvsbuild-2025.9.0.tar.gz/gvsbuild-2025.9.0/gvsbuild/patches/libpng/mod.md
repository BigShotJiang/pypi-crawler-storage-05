 * Remove:
`set(CMAKE_DEBUG_POSTFIX "d")`
