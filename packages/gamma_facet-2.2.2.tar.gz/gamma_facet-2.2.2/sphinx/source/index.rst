.. image:: /_images/Gamma_Facet_Logo_RGB_LB.svg

|

Table of contents
-----------------

.. toctree::
   :maxdepth: 1
   :titlesonly:

   Getting started <_generated/getting_started>
   API reference <apidoc/facet>
   tutorials
   contribution_guide
   faqs
   about_us
   _generated/release_notes
