The figure below provides a high level overview of the workflow when using FACET, and
for each step in the workflow, a brief description.

.. image:: /_images/Facet_flow.svg
   :width: 550

Please refer to the :ref:`tutorials<tutorials>` for examples of using FACET classes
and functions, and the :ref:`release notes<release-notes>` for recent API updates and
bug fixes.
