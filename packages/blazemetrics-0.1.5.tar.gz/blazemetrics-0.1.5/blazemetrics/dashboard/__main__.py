from .app import run_dashboard

if __name__ == "__main__":
    run_dashboard()
