# Only for backward compatibility. Main logic has moved to dashboard/app.py.
from .dashboard.app import run_dashboard

if __name__ == "__main__":
    run_dashboard()
