from gaql_console import console

console.main()
