# Evaluation Module

???+ info "Additional dependencies"

    To use the `soundevent.evaluation` module you need to install some
    additional dependencies. Make sure you have them installed by running the
    following command:

    ```bash
    pip install soundevent[evaluation]
    ```

::: soundevent.evaluation
