# Terms Module

::: soundevent.terms
    options:
      members:
      - add_term
      - find_term
      - get_term
      - get_term_by
      - has_term
      - remove_term
      - add_terms_from_file
      - get_global_term_registry
      - set_global_term_registry
      - TermRegistry
      - TermSet


## Term Library

:::soundevent.terms.library
