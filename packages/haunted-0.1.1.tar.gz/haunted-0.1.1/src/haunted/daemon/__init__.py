"""Daemon service package for Haunted."""

from .service import HauntedDaemon

__all__ = ["HauntedDaemon"]