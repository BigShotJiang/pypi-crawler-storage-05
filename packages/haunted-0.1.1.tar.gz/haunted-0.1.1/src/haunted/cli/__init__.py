"""CLI package for Haunted."""

from .main import cli

__all__ = ["cli"]