from . import account_move
from . import res_partner
from . import transmit_method
