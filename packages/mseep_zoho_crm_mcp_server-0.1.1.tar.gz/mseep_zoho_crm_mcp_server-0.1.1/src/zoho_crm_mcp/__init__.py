"""Zoho CRM MCP Server - Model Context Protocol server for Zoho CRM integration."""

__version__ = "0.1.0"
