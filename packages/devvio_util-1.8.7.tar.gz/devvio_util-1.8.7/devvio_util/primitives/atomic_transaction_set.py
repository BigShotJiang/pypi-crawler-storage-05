class AtomicTransactionSet:
    def __init__(self):
        raise NotImplementedError
        self._txs = []
