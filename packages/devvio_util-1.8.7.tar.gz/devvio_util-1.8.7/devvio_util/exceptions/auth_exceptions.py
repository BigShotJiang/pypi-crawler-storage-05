from .devv_error import DevvError


class AuthError(DevvError):
    pass
