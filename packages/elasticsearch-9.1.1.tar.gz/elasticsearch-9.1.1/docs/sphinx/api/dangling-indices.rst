.. _dangling-indices:

Dangling Indices
----------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: DanglingIndicesClient
   :members: