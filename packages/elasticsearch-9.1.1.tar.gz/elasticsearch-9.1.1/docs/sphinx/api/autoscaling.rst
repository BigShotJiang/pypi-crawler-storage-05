.. _autoscaling:

Autoscaling
-----------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: AutoscalingClient
   :members:
