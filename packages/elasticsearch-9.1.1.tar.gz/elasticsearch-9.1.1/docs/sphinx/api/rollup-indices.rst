.. _rollup-indices:

Rollup Indices
--------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: RollupClient
   :members: