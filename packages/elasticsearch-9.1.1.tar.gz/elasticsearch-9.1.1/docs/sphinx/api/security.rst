.. _security:

Security
--------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: SecurityClient
   :members: