.. _ml:

Machine Learning (ML)
---------------------
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: MlClient
   :members: