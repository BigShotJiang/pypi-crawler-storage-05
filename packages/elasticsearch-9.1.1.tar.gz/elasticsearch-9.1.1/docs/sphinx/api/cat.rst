.. _cat:

Cat
---
.. py:module:: elasticsearch.client
   :no-index:

.. autoclass:: CatClient
   :members: