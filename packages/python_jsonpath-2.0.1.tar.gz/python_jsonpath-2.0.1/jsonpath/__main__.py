"""CLI entry point."""
from jsonpath.cli import main

main()
