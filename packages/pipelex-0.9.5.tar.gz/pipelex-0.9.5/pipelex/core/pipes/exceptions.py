class PipeBlueprintError(Exception):
    """Exception raised for errors in the PipeBlueprint class."""

    pass
