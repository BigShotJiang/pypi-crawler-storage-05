from pipelex.types import StrEnum


class OcrHandle(StrEnum):
    MISTRAL_OCR = "mistral/mistral-ocr-latest"
