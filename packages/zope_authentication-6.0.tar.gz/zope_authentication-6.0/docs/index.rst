.. include:: ../README.rst

Contents:

.. toctree::
   :maxdepth: 2

   logout
   principalterms
   api
   changelog

Development
===========

zope.authentication is hosted at GitHub:

    https://github.com/zopefoundation/zope.authentication/



Project URLs
============

* https://pypi.python.org/pypi/zope.authentication       (PyPI entry and downloads)



==================
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
