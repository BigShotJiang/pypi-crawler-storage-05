===============
 API Reference
===============

Interfaces
==========

.. automodule:: zope.authentication.interfaces

Principals
==========

.. automodule:: zope.authentication.principal

Login
=====

.. automodule:: zope.authentication.loginpassword

Logout
======

.. automodule:: zope.authentication.logout
