from zope.interface import Interface


class IMyLayer(Interface):
    """marker interface for a layer for testing purposes"""


class IOtherLayer(Interface):
    """marker interface for a second layer for testing purposes"""
