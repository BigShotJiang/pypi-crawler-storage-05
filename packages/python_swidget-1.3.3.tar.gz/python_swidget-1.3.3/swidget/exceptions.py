class SwidgetException(Exception):
    """Base exception for device errors."""
