## [2.0.6] - 2025-09-08

### Changed
- Update copier
- Ls whole folder structure
- Ls whole folder structure
- Allow docs manual run
- Update copier

