# -*- coding: utf-8 -*-
"""
Main Module Entry
Supports command line startup with python -m nacos.auto.registration
"""

from ..injectors.injector import main


if __name__ == '__main__':
    main()
