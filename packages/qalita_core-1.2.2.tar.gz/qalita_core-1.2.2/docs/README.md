# QALITA Platform CLI Core

<div style="text-align:center;">
<img width="250px" height="auto" src="https://cloud.platform.qalita.io/logo.svg" style="max-width:250px;"/>
</div>

QALITA Core is a helper library to be used in QALITA packs to easily load data for analysis.

Find the full documentation [in the online documentation](https://doc.qalita.io/)