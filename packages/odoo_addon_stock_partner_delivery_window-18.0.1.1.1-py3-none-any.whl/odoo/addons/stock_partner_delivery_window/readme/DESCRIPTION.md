This module allows to define time scheduling preference for delivery
orders on partners, in order to raise a warning when changing a
scheduled date to a time window that is not preferred by this customer.
