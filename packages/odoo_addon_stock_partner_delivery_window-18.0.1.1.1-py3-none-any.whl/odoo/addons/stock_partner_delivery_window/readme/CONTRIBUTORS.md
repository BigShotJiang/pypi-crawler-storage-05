- Akim Juillerat \<<akim.juillerat@camptocamp.com>\>
- Matthieu Méquignon \<<matthieu.mequignon@camptocamp.com>\>
- Jacques-Etienne Baudoux (BCIM) \<<je@bcim.be>\>

Trobz

- Dung Tran \<<dungtd@trobz.com>\>
- Vo Hong Thien \<<thienvh@trobz.com>\>
