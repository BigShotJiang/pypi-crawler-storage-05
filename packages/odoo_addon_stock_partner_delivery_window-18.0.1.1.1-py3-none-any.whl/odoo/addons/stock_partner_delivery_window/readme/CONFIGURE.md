On partners form view, under the "Sales & Purchases" tab, one can define
a "Delivery schedule preference" for each partner.

Possible configurations are:

- Any time: Do not postpone deliveries
- Fixed time windows: Postpone deliveries to the next preferred time
  window
- Weekdays: Postpone deliveries to the next weekday

After selecting "Fixed time windows", one can define the preferred
delivery windows in the embedded tree view below.
