class AlreadyExists(Exception):
    pass


class ClientError(Exception):
    pass


class NotFoundError(Exception):
    pass


class ServerError(Exception):
    pass
