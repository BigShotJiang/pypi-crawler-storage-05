_instruments = ("openai-agents >= 0.2.6",)
_supports_metrics = False
