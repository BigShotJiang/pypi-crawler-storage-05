#!/usr/bin/env python3

# SPDX-FileCopyrightText: © 2022-2024 Decompollaborate
# SPDX-License-Identifier: MIT

from __future__ import annotations

import argparse
from collections.abc import Callable
import decomp_settings
from pathlib import Path

from .. import mapfile
from .. import utils


def doSymInfo(
        mapPath: Path,
        symName: str,
        *,
        as_vram: bool=False,
        as_vrom: bool=False,
        as_name: bool=False,
        plfResolver: Callable[[Path], Path|None]|None=None,
    ) -> int:
    if not mapPath.exists():
        print(f"Could not find mapfile at '{mapPath}'")
        return 1

    mapFile = mapfile.MapFile.newFromMapFile(mapPath)
    if plfResolver is not None:
        mapFile = mapFile.resolvePartiallyLinkedFiles(plfResolver)

    possibleFiles: list[mapfile.Section] = []

    if as_vram:
        address = int(symName, 0)
        info, possibleFiles = mapFile.findSymbolByVram(address)
    elif as_vrom:
        address = int(symName, 0)
        info, possibleFiles = mapFile.findSymbolByVrom(address)
    elif as_name:
        info = mapFile.findSymbolByName(symName)

    # Start the guessing game
    elif utils.convertibleToInt(symName, 0):
        address = int(symName, 0)
        info, possibleFiles = mapFile.findSymbolByVram(address)
        if info is None:
            info, possibleFiles2 = mapFile.findSymbolByVrom(address)
            possibleFiles.extend(possibleFiles2)
    else:
        info = mapFile.findSymbolByName(symName)

    if info is not None:
        print(info.getAsStrPlusOffset(symName))
        return 0
    print(f"'{symName}' not found in map file '{mapPath}'")
    if len(possibleFiles) > 0:
        print("But it may be a local symbol of either of the following files:")
        for f in possibleFiles:
            print(f"    {f.asStr()})")
    return 1


def processArguments(args: argparse.Namespace, decompConfig: decomp_settings.Config|None=None):
    if decompConfig is not None:
        version = decompConfig.get_version_by_name(args.version)
        assert version is not None, f"Invalid version '{args.version}' selected"

        mapPath = Path(version.paths.map)
    else:
        mapPath = args.mapfile

    symName: str = args.symname
    as_vram: bool = args.vram
    as_vrom: bool = args.vrom
    as_name: bool = args.name
    plfExt: list[str]|None = args.plf_ext

    plfResolver = None
    if plfExt is not None:
        def resolver(x: Path) -> Path|None:
            if x.suffix in plfExt:
                newPath = x.with_suffix(".map")
                if newPath.exists():
                    return newPath
            return None

        plfResolver = resolver

    exit(doSymInfo(mapPath, symName, as_vram=as_vram, as_vrom=as_vrom, as_name=as_name, plfResolver=plfResolver))

def addSubparser(subparser: argparse._SubParsersAction[argparse.ArgumentParser], decompConfig: decomp_settings.Config|None=None):
    parser = subparser.add_parser("sym_info", help="Display various information about a symbol or address.")

    emitMapfile = True
    if decompConfig is not None:
        versions = []
        for version in decompConfig.versions:
            versions.append(version.name)

        if len(versions) > 0:
            parser.add_argument("-v", "--version", help="Version to process from the decomp.yaml file", type=str, choices=versions, default=versions[0])
            emitMapfile = False

    if emitMapfile:
        parser.add_argument("mapfile", help="Path to a map file.", type=Path)
    parser.add_argument("symname", help="Symbol name or VROM/VRAM address to lookup. How to treat this argument will be guessed.")

    parser.add_argument("-x", "--plf-ext", help="File extension for partially linked files (plf). Will be used to transform the `plf`s path into a mapfile path by replacing the extension. The extension must contain the leading period. This argument can be passed multiple times.", action="append")

    vram_vrom_group = parser.add_mutually_exclusive_group()
    vram_vrom_group.add_argument("--vram", help="Treat the argument as a VRAM address instead of guessing.", action="store_true")
    vram_vrom_group.add_argument("--vrom", help="Treat the argument as a VROM address instead of guessing.", action="store_true")
    vram_vrom_group.add_argument("--name", help="Treat the argument as a symbol name instead of guessing.", action="store_true")

    parser.set_defaults(func=processArguments)
