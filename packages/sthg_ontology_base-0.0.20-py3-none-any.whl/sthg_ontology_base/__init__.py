from .utils.base_decorator import function,edit,delete,create
from .utils.base_crud import TGClient,BaseModel,QuerySet,JoinedQuerySet,OntologyNamespace