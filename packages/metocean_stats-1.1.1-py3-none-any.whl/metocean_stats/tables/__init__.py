"""
This is the Stats-module that contains functions for stastistics of metocean data.

Copyright 2023, Konstantinos Christakos, MET Norway
"""


from .dir import *
from .extreme import *
from .general import *
from .climate import *
from .spectra import *
