"""
This is the Stats-module that contains functions for stastistics of metocean data.

Copyright 2023, Konstantinos Christakos, MET Norway
"""

from .general import *
from .extreme import *
