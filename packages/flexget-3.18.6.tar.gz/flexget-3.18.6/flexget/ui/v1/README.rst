FlexGet Web UI (v1)
===================

The Flexget WebUI (angular v1) is no longer being developed.
A new WebUI (v2) is being developed in ReactJS.

The source code is now available at https://github.com/Flexget/webui
