# Docker
A Dockerfile for building an image that has the dsa-helpers library with all the dependencies installed.

This image is pushed to DockerHub here.