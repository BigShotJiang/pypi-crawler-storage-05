class FailedExponentialBackoff(Exception):
    """
    Exception raised when the exponential backoff fails.
    """

    pass
