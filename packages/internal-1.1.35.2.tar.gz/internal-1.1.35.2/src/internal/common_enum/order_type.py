from enum import Enum


class OrderTypeEnum(str, Enum):
    ASC = "asc"
    DESC = "desc"
