"""
DIRACCommon.Utils - Stateless utility functions
"""
