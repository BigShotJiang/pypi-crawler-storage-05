.. include:: ../src/zope/lifecycleevent/manual.rst
