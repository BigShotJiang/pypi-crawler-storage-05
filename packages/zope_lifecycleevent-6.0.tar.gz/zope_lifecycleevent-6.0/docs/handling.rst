.. include:: ../src/zope/lifecycleevent/handling.rst
