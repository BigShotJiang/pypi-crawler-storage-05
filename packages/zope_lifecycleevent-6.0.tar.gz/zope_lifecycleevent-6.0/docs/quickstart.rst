.. include:: ../src/zope/lifecycleevent/README.rst
