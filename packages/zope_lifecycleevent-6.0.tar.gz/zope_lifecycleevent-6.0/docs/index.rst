==============================
 What is zope.lifecycleevent?
==============================

.. include:: ../README.rst

.. toctree::
   :maxdepth: 1

   quickstart
   manual
   handling
   api

.. toctree::
   :maxdepth: 2

   changelog

Development
===========

zope.lifecycleevent is hosted at GitHub:

    https://github.com/zopefoundation/zope.lifecycleevent/



Project URLs
============

* https://pypi.python.org/pypi/zope.lifecycleevent       (PyPI entry and downloads)


====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
