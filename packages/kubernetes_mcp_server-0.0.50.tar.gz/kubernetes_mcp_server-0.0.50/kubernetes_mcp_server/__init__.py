"""
Kubernetes MCP Server (Model Context Protocol) with special support for OpenShift.
"""
from .kubernetes_mcp_server import main

__all__ = ['main']

