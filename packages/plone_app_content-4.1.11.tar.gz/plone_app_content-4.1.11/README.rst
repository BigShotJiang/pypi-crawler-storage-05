Introduction
============

plone.app.content contains various views for Plone,
such as ``folder_contents``,
as well as general content infrastructure,
such as base classes and name choosers.


Source Code
===========

Contributors please read the document `Process for Plone core's development <https://docs.plone.org/develop/coredev/docs/index.html>`_

Sources are at the `Plone code repository hosted at Github <https://github.com/plone/plone.app.content>`_.
