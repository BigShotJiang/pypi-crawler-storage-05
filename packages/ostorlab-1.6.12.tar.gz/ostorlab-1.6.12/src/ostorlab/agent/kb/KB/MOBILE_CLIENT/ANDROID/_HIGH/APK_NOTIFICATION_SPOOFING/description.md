The application exposes an input to receive unauthorized notifications, exposing the users to phishing, unauthorized access or even remote code execution.

Notification attacks have leveraged in the by malicious applications like WolfRAT and Mandrake.

A common cause of unauthorized notifications' exposure is insecure or missing permissions on Firebase services or 3rd party push notification like Cordova `PushHandlerActivity`.

