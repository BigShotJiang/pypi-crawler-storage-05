List of all calls to cryptographic methods.
