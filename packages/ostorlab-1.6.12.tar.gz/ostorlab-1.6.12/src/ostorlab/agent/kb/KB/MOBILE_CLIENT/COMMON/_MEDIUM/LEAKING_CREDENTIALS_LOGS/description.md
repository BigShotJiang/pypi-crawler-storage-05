While logging all information may be helpful during development stages, it is important that logging levels be set
appropriately before a product ships so that sensitive user data and system information are not accidentally exposed to
potential attackers.