List of all HTTP methods used in the application.
