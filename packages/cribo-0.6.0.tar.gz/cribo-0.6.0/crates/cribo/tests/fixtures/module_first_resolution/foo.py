# This is the module file version - should NOT be imported
source = "foo.py (module file)"
value = "WRONG - module file"

print("ERROR: foo.py was imported instead of foo/__init__.py!")
