# This is the package version - should be imported
source = "foo/__init__.py (package)"
value = "CORRECT - package"

print("Successfully imported foo package")
