"""Version information for my_package"""

__version__ = "1.2.3"

# Add a side effect to force sys.modules wrapping
print("Loading version module...")
