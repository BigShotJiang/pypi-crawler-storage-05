from __future__ import annotations, print_function

from module_a import func_a
from module_b import func_b


def main():
    func_a()
    func_b()


if __name__ == "__main__":
    main()
