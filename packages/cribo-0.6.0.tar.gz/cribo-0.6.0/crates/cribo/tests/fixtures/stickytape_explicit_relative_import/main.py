#!/usr/bin/env python

import greetings.greeting

print(greetings.greeting.message)
