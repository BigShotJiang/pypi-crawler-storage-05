from . import mod_b

A_VALUE = f"A -> {mod_b.B_DERIVED_VALUE}"
