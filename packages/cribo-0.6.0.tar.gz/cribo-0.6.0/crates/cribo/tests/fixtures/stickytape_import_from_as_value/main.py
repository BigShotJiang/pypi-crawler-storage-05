#!/usr/bin/env python

from greeting import message as m

print(m)
