# my-module.py (invalid Python identifier due to hyphen)

value = 42


def get_value():
    return value
