def handler() -> str:
    return "Hello from foo.py"
