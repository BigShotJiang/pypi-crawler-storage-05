def handler() -> str:
    return "Hello from boo.py"
