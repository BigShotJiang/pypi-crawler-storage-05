# Package A's utils - converts to uppercase
def transform(text):
    return text.upper() + "_FROM_PACKAGE_A"
