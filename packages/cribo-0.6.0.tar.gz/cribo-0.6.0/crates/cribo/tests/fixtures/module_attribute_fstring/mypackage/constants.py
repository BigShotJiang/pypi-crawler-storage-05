# Constants module with module-level attributes
VERSION = "1.0.0"
API_KEY = "secret-key-123"
