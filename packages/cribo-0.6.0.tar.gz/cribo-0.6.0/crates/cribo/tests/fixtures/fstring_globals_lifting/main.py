"""Test fixture for f-string globals lifting"""

# Module-level variables
result = "initial"
counter = 0
values = [1, 2, 3]


def simple_fstring():
    """Test basic f-string with global variable"""
    global result
    result = "modified"
    return f"Result is: {result}"


def complex_fstring():
    """Test complex f-string expressions"""
    global counter, values
    counter += 1
    values.append(counter)
    return f"Count: {counter:03d}, Sum: {sum(values)}, Max: {max(values)}"


def nested_fstring():
    """Test nested expressions in f-string"""
    global result
    result = f"nested_{result}"
    return f"Result: {result.upper()}, Length: {len(result)}"


def fstring_with_format():
    """Test f-string with format specifications"""
    global counter
    counter = 42
    return f"Decimal: {counter:d}, Hex: {counter:#x}, Binary: {counter:08b}"


if __name__ == "__main__":
    print(simple_fstring())
    print(f"Module result: {result}")

    print(complex_fstring())
    print(f"Module counter: {counter}, values: {values}")

    print(nested_fstring())
    print(f"Final result: {result}")

    print(fstring_with_format())
    print(f"Final counter: {counter}")
