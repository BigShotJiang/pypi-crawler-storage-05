This directory intentionally contains no __main__.py or __init__.py files.
It's used to test error handling when --entry points to a directory without proper entry points.