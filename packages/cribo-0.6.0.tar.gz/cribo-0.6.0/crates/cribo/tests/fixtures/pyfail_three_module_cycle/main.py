#!/usr/bin/env python

import module_a


def main():
    result = module_a.process_a()
    print(f"Result: {result}")


if __name__ == "__main__":
    main()
