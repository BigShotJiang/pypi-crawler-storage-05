from foo import tada

if __name__ == "__main__":
    print(tada())
