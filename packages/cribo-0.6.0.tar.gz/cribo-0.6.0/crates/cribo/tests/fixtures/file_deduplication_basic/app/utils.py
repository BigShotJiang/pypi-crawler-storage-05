# app/utils.py


def get_name():
    return "app.utils"


def helper():
    return "I am from app.utils"
