"""Package init file."""

# Import utils to make it available
from . import utils

# Force this module to have side effects so it becomes a wrapper
print("Loading mypackage")
