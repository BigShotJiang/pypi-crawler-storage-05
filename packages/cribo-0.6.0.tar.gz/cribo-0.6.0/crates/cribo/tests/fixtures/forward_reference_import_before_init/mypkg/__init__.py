# Package init that imports from submodules
from .exceptions import CustomJSONError

__all__ = ["CustomJSONError"]
