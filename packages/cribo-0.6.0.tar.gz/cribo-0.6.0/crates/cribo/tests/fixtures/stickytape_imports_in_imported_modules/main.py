#!/usr/bin/env python

from greetings import message

print(message)
