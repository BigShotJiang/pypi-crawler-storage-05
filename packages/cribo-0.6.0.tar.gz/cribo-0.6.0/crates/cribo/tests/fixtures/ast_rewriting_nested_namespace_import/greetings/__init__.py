"""Greetings package"""
# Empty init file
