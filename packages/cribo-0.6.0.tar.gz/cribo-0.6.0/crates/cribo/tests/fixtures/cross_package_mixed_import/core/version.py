"""Version module separate from __init__ to avoid circular imports."""

CORE_MODEL_VERSION = "1.0.0"
