from pkg import submodule

print("VALUE:", submodule.VALUE)
