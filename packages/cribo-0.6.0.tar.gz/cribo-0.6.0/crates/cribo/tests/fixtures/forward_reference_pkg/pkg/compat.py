"""Compat module."""

# Various attributes
CONSTANT = "compat_value"


class BaseClass:
    """Base class."""

    pass
