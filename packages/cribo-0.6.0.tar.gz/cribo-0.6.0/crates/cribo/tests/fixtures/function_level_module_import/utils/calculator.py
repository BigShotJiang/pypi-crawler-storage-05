"""Calculator module with simple operations"""

description = "A simple calculator module"


def add(a, b):
    return a + b


def multiply(a, b):
    return a * b
