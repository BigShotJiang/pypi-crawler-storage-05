"""Subpackage with wildcard export."""

from .submodule import SubpkgClass

__all__ = ["SubpkgClass"]
