"""Another module."""


class AnotherClass:
    """Another class."""

    def __init__(self):
        self.another_value = "another"
