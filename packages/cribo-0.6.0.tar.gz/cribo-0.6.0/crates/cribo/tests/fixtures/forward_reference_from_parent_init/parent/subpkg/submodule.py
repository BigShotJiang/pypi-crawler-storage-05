"""Submodule in subpackage."""


class SubpkgClass:
    """A class from subpackage."""

    def __init__(self):
        self.subpkg_value = "subpkg"
