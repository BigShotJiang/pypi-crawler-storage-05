"""Base module defining base classes."""


class BaseClass:
    """A base class."""

    def __init__(self):
        self.base_value = "base"
