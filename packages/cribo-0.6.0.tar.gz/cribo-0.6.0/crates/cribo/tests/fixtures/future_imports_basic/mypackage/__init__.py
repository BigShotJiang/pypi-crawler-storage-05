from __future__ import annotations

"""Package initialization with future import."""

__version__ = "1.0.0"
