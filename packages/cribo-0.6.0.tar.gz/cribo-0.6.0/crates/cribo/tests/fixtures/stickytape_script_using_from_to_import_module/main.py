#!/usr/bin/env python

from greetings import greeting

print(greeting.message)
print(greeting.get_default_greeting())
