message = "Hello\n'''\n" + '"""'
