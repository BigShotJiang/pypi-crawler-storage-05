#!/usr/bin/env python

import greeting

print(greeting.message)
