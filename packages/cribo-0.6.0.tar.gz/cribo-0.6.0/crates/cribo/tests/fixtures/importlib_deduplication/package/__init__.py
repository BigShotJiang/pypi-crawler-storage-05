# Package init
print("package/__init__.py is being executed!")
