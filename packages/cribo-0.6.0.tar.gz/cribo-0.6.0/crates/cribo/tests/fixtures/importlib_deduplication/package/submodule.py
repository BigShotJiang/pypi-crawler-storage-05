# Submodule
print("package/submodule.py is being executed!")
sub_counter = 10
