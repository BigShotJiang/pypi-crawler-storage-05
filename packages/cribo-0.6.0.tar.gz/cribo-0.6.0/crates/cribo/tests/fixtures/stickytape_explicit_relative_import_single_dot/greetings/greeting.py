from . import messages

__all__ = ["message"]

message = messages.message
