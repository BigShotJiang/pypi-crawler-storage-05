class ElementNotFound(Exception):
    pass


class RequiredURL(Exception):
    pass
