import g4f11.api

if __name__ == "__main__":
    g4f11.api.run_api(debug=True)
