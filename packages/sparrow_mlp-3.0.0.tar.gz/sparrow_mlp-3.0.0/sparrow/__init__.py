# sparrow/__init__.py

from .models import DynamicMLP

print("Sparrow Dynamic MLP Library Loaded 🐦")