
def txt2dict(content,mapping_dict=None,encoding='utf-8'):
    content = content.decode(encoding=encoding)
    pass