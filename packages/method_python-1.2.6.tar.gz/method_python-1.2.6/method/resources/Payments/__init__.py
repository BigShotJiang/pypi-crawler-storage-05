from method.resources.Payments.Payment import Payment, PaymentResource
from method.resources.Payments.Reversal import ReversalResource
