from method.resources.Entities.Entity import Entity, EntityResource
