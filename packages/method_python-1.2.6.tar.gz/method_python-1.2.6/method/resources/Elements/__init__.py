from method.resources.Elements.Element import ElementResource
from method.resources.Elements.Token import ElementTokenResource, ElementToken
