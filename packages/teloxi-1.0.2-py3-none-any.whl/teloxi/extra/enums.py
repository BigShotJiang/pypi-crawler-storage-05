
class ChatType:
    NONE            = None
    USERNAME        = "USERNAME"
    PUBLIC          = "PUBLIC"
    PUBLIC_POST     = "PUBLIC_POST"
    PRIVATE         = "PRIVATE"
    PRIVATE_POST    = "PRIVATE_POST"
    REFERRAL_LINK   = "REFERRAL_LINK"