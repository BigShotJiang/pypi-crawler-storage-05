from .features import Features




class ExtraFeatures(Features):
   pass


__all__ = ['ExtraFeatures']