# OXASL_MULTITE

Plugin for the OXASL pipeline to support multi-TE ASL data.

The data is optionally initially fitted to the standard resting state
ASL model and then the fitted perfusion/arrival time data is used to initialize
the multi-TE model to fit the exchange time.

## Issues

## Citation
