from ._metadata import __title__, __description__, __url__, __version__
from ._metadata import __author__, __author_email__
from ._metadata import __license__, __copyright__