License
=======

CitySketch is licensed under the European Union Public License (EUPL) v1.2.

**EUPL-1.2**


The full text of the EUPL-1.2 license can be found at:
https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
