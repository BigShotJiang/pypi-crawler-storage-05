2025-08-28 Version: 1.1.0
- Support API DescribeInstanceAuthInfo.


2025-08-18 Version: 1.0.0
- Generated python 2025-05-07 for RdsAi.

