"""Django root URL configuration for ASGI deployments."""
urlpatterns = []
