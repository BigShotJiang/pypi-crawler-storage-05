mod adjacency;
mod crosswalk;
mod overlap;
mod perimeter;
mod proj;
