mod algorithm;
mod contiguity;
mod frontier;
mod partition;

pub use partition::Partition;
