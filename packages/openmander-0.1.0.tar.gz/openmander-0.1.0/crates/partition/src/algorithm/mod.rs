mod anneal;
mod equalize;
mod compactness;
mod randomize;
