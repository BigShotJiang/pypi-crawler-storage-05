"""GraphQL adapter layer for Dagster Plus CLI."""
