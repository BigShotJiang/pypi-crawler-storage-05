1. prj offered options
   1. verbose, visualization
   2. log level, env var, macro
2. util functions
