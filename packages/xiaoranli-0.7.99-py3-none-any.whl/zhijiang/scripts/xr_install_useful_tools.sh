sudo apt install -y peco bat lolcat expect twine \
    strace ltrace sysstat tree bc net-tools tig\
