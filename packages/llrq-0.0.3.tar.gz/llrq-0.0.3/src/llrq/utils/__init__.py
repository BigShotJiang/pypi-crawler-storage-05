"""Utilities for LLRQ package."""
