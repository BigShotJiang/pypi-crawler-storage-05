HTTP_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'
HTTP_ACCEPT_LANGUAGE = 'en,zh-CN;q=0.9,zh;q=0.8,en-US;q=0.7'
