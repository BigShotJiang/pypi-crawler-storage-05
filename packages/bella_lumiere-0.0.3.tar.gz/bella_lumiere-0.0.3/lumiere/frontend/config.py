LOGO_COLOR = "rgb(222, 183, 82)"

LABEL_WIDTH = 5
LABEL_CLASS = "fw-bold text-center"
