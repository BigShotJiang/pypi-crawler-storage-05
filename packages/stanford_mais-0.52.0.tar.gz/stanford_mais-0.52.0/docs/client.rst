MaIS Client Configuration
=========================

To begin using any of the MaIS API clients, you must first instantiate a
:class:`~stanford.mais.client.MAISClient`.  This stores configuration common to
all clients.

.. automodule:: stanford.mais.client
   :members:
