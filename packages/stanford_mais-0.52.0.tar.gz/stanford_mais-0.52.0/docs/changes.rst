Changelog
=========

This page provides a summary of changes present in each version of the
package.

.. include:: ../CHANGELOG.rst
