"""Setup configuration for solubilityCCS package."""

from setuptools import setup

# Configuration is handled by pyproject.toml
setup()
