
python -m venv venv

source venv/bin/active
