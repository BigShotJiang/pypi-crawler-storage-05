class TimeLimitExceededOnFileTransfer(Exception):
    pass
