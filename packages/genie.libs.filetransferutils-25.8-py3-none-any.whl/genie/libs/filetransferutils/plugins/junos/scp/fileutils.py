""" File utils base class for SCP on JunOS devices. """

from ..fileutils import FileUtils as FileUtilsJunOSBase

class FileUtils(FileUtilsJunOSBase):
	pass