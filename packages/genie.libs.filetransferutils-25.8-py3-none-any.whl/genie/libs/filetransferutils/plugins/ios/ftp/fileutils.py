""" File utils base class for FTP on IOS devices. """

from ...iosxe.ftp.fileutils import FileUtils as FileUtilsXEBase

class FileUtils(FileUtilsXEBase):
	pass
