from .fileutils import FileUtils
from genie import abstract
abstract.declare_token(protocol="ftp")