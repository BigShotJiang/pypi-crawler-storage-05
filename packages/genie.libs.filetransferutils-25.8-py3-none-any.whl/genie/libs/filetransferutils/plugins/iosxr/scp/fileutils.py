""" File utils base class for SCP on IOSXR devices. """

from ..fileutils import FileUtils as FileUtilsXRBase

class FileUtils(FileUtilsXRBase):
	pass