""" File utils base class for SFTP on NXOS devices. """

from ..fileutils import FileUtils as FileUtilsNXBase

class FileUtils(FileUtilsNXBase):
	pass