from .fileutils import FileUtils
from genie import abstract
abstract.declare_token(os="nxos")