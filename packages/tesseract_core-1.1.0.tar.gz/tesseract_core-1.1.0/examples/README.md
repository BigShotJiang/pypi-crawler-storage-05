# Basic examples

This folder contains some basic examples of Tesseract usage, tested regularly to ensure they work with the latest version of Tesseract.

For more information, see the [Tesseract documentation](https://docs.pasteurlabs.ai/projects/tesseract-core/latest/).
