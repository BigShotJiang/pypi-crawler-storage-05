(tr-api)=
# `tesseract_core` Python API

```{eval-rst}
.. automodule:: tesseract_core
   :members:
```
