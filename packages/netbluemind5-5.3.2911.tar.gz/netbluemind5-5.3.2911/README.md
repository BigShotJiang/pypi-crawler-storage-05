BlueMind API client
------------------- 

BlueMind is a open source email and collaboration software, more
information on https://www.bluemind.net

This client is generated automatically from BlueMind source code,
which is available at http://git.blue-mind.net/bluemind/

The version of this package should match the technical version of the
BlueMind server you want to use.

Issues with this piece of code should be reported at
https://forge.bluemind.net/jira
