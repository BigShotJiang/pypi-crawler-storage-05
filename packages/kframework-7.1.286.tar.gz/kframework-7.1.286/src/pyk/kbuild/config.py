from typing import Final

PROJECT_FILE_NAME: Final = 'kbuild.toml'
DIST_DIR_NAME: Final = 'kdist'
