"""Test suite for tap-readthedocs."""

from __future__ import annotations
