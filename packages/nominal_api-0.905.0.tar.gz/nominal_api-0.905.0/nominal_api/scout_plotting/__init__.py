# coding=utf-8
from .._impl import (
    scout_plotting_TimestampType as TimestampType,
)

__all__ = [
    'TimestampType',
]

