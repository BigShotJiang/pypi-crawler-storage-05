#!/usr/bin/env python3

from . counter import run

if __name__ == '__main__':
    run()

