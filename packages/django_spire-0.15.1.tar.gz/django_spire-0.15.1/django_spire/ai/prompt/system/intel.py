from __future__ import annotations

from dandy.intel import BaseIntel


class SystemPromptIntel(BaseIntel):
    system_prompt: str