__all__ = ["hello"]


def hello():
    return "bgm-labour ok"
