"""Config and settings management utilities for Bear Utils."""
