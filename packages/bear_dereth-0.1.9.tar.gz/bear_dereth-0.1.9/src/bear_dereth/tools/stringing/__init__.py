"""Tools related to string manipulation."""
