"""Dependency injection wiring tools."""
