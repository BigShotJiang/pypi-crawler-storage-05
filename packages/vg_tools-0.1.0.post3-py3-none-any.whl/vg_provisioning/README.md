## Provisioning Server - Terraform

**Current template is for DigitalOcean only, orther cloud providers are not supported yet**
