# SDK for computing and uploading RAI insights for AutoML models

### This package has been tested with Python 3.6, 3.7, 3.8 and 3.9