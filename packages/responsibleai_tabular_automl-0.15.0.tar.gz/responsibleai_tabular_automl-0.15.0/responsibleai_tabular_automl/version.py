# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

name = "responsibleai_tabular_automl"
_major = "0"
_minor = "15"
_patch = "0"
version = "{}.{}.{}".format(_major, _minor, _patch)
