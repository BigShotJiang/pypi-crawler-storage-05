# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

import setuptools

# Version will be read from version.py
version = ""
name = "responsibleai-tabular-automl"

# Fetch Version
with open("responsibleai_tabular_automl/version.py") as f:
    code = compile(f.read(), f.name, "exec")
    exec(code)

# Fetch ReadMe
with open("README.md", "r") as fh:
    long_description = fh.read()

# Use requirements.txt to set the install_requires
with open("requirements.txt") as f:
    install_requires = [line.strip() for line in f]

setuptools.setup(
    name=name,  # noqa: F821
    version=version,  # noqa: F821
    author="Gaurav Gupta, Ke Xu",
    author_email="raiwidgets-maintain@microsoft.com",
    description="SDK for computing RAI insights for AutoML models.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    packages=setuptools.find_packages(),
    python_requires=">=3.6",
    install_requires=install_requires,
    classifiers=[
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 3 - Alpha",
    ],
)
