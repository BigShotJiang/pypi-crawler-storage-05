from tacomaker.tortilla.extensions.majortom import MajorTOM
from tacomaker.tortilla.extensions.territorial import Territorial, TERRITORIAL_PRODUCTS
