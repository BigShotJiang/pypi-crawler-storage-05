from tacomaker.taco.extensions.labels import Labels, LabelClass
from tacomaker.taco.extensions.opticaldata import SpectralBand, OpticalData, SUPPORTED_SENSORS
from tacomaker.taco.extensions.scientific import Publication, Publications
from tacomaker.taco.extensions.split import SplitStrategy, SplitStrategyType