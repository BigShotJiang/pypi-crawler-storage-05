from tacomaker.sample.extensions.stac import STAC
from tacomaker.sample.extensions.scaling import Scaling
from tacomaker.sample.extensions.stats import GeotiffStats
