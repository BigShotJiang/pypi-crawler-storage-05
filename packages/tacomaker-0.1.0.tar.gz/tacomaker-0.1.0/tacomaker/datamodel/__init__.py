from tacomaker.sample.datamodel import Sample
from tacomaker.tortilla.datamodel import Tortilla  
from tacomaker.taco.datamodel import Taco


from tacomaker.datamodel import sample
from tacomaker.datamodel import tortilla
from tacomaker.datamodel import taco



__all__ = ['Sample', 'sample', 'Tortilla', 'tortilla', 'Taco', 'taco']