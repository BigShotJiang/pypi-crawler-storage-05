import daft
from daft import Window, col
from daft.functions import rank


class FrameExtractor:
    def __init__(self):
        pass
