# brotli-python

POC package for harmless beacon-only testing.
