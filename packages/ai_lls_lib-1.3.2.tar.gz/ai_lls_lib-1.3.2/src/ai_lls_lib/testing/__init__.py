"""
Testing utilities and fixtures
"""
