"""
Custom Exceptions specifically for an Interface
"""


class PlanhatUpsertError(Exception):
    pass
