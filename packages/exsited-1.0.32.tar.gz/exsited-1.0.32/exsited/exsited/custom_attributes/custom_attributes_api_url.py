class CustomAttributesApiUrl:
    CUSTOM_ATTRIBUTES_UPDATE = "/api/v3/custom_attributes/{uuid}/"
    CUSTOM_ATTRIBUTES = "api/v2/settings/custom_attributes"

