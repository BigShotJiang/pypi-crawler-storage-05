class PurchasePaymentsApiUrl:
    PURCHASE_PAYMENTS = "/api/v3/purchase-payments"
    PURCHASE_PAYMENTS_DETAILS = "/api/v3/purchase-payments/{id}"
    PURCHASE_PAYMENTS_FROM_PURCHASE_INVOICE = "/api/v3/purchase-invoices/{purchase_invoice_id}/purchase-payments"
