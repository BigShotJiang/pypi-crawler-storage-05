class ExpressApiUrl:
    EXPRESS_CREATE = "/api/v2/express"
