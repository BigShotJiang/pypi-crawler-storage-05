``APyFloatArray``
=================

.. doxygenclass:: APyFloatArray
    :project: APyTypes
    :members:
    :undoc-members:
