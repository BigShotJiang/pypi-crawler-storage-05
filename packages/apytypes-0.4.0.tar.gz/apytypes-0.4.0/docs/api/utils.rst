Utility functions
=================

Create scalars and arrays
-------------------------

.. autofunction:: apytypes.fx

.. autofunction:: apytypes.fp

Evaluate functions
------------------

.. autofunction:: apytypes.fn
