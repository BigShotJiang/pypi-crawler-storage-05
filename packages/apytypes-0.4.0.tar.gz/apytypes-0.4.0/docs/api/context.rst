Context handling
================

.. autoclass:: apytypes.APyFixedCastContext

   .. automethod:: __init__

.. autoclass:: apytypes.APyFloatQuantizationContext

   .. automethod:: __init__

.. autoclass:: apytypes.APyFixedAccumulatorContext

   .. automethod:: __init__

.. autoclass:: apytypes.APyFloatAccumulatorContext

   .. automethod:: __init__
