Code generation
===============

VHDL
----

.. autofunction:: apytypes.vhdl.generate_rom
