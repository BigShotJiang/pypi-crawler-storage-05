.. _examples:

========
Examples
========

These are examples of how APyTypes can be used.
