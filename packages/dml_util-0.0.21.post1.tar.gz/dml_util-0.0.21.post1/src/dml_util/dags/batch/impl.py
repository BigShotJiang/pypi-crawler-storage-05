from dml_util.runners.batch import BatchRunner

handler = BatchRunner.handler
