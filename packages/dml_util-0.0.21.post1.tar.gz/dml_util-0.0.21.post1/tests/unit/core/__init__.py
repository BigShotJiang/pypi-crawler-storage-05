"""Unit tests for the core package."""
