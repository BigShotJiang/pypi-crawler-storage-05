# TODO
from octobot_tentacles_manager.creators.tentacle_creator import TentacleCreator


def test_init():
    creator = TentacleCreator({})
