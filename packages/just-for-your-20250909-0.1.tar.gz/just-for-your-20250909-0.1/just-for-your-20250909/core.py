# -*-coding:utf-8-*-
def hello(name: str = "World") -> str:
    return f"Hello, {name}!"
