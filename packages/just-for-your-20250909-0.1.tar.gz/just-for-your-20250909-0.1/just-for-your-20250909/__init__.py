# -*-coding:utf-8-*-
from .core import hello

__all__ = ["hello"]
