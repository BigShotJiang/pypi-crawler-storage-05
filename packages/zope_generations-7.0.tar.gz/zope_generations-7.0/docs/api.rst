===================
 API Documentation
===================


.. there's actually nothing present in this module,
   but it provides a place to link to.

.. automodule:: zope.generations

zope.generations.interfaces
===========================

.. automodule:: zope.generations.interfaces

zope.generations.generations
============================

.. automodule:: zope.generations.generations

zope.generations.utility
========================

.. automodule:: zope.generations.utility


Configuration
=============

There are two ZCML files included in this package.

configure.zcml
--------------

.. literalinclude:: ../src/zope/generations/configure.zcml
   :language: xml

subscriber.zcml
---------------

.. literalinclude:: ../src/zope/generations/subscriber.zcml
   :language: xml
