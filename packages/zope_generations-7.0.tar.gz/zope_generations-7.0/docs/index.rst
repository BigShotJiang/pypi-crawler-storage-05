.. include:: ../README.rst

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   details
   changelog
   api




====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
