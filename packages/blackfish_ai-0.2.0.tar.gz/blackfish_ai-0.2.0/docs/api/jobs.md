# API Documentation

::: app.job

<!-- ## ::: app.job.Job
    :docstring:
    :members:

## ::: app.job.LocalJob
    :docstring:
    :members: -->
