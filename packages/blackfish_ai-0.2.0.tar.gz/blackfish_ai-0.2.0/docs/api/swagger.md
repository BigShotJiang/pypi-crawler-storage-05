<swagger-ui src="swagger.json"/>
