#!/bin/bash

{%- block command %}
{% endblock %}
