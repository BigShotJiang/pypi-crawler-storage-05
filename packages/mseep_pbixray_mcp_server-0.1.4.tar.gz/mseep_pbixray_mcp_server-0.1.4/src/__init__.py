"""
PBIXRay MCP Server package.

This package provides a Model Context Protocol (MCP) server for PBIXRay,
allowing AI models to interact with Power BI (.pbix) files.
"""

__version__ = "0.1.0"
