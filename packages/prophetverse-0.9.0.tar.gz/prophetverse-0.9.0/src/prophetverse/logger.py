import logging

logger = logging.getLogger("prophetverse")
