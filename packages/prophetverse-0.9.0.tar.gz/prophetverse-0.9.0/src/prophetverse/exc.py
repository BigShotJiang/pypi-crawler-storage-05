"""Collection of exceptions."""


class ConvergenceError(Exception):  # noqa: D101
    pass
