from django.apps import AppConfig


class DjangoAccessInspectorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_access_inspector"
    label = "django_access_inspector"
