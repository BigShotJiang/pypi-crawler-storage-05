"""Code for exposing Polars Cloud functionality to the CLI.

This is mostly a simple wrapper around the Python Client
It adds handling of error messages as sys.exit and some stdout prints.
"""
