from hh_mcp_comfyui import main

main()