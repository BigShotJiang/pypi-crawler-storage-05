class BaseRateLimiter:
    def wait(self, rate_limit_params: dict = None):
        pass
