[**高級選項**](./introduction.md) > **翻譯服務文檔** _(current)_

---

### 通過命令行查看可用的翻譯服務

您可以通過在命令行中打印幫助訊息來確認可用的翻譯服務及其使用方法。

```bash
pdf2zh_next -h
```

在幫助訊息的結尾，您可以查看不同翻譯服務的詳細資訊。

<div align="right"> 
<h6><small>Some content on this page has been translated by GPT and may contain errors.</small></h6>