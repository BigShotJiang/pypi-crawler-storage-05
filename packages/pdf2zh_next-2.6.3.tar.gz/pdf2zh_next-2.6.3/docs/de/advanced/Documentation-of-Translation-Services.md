[**Erweiterte Optionen**](./introduction.md) > **Dokumentation der Übersetzungsdienste** _(aktuell)_

---

### Verfügbare Übersetzungsdienste über die Kommandozeile anzeigen

Sie können die verfügbaren Übersetzungsdienste und deren Verwendung bestätigen, indem Sie die Hilfemeldung in der Kommandozeile ausgeben.

```bash
pdf2zh_next -h
```

Am Ende der Hilfenachricht können Sie detaillierte Informationen über die verschiedenen Übersetzungsdienste einsehen.

<div align="right"> 
<h6><small>Ein Teil des Inhalts dieser Seite wurde von GPT übersetzt und kann Fehler enthalten.</small></h6>