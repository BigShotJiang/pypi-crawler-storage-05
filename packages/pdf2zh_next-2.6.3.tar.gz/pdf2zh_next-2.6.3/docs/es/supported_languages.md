> [!NOTE]
> Por favor, [haz clic aquí](https://funstory-ai.github.io/BabelDOC/supported_languages/) para navegar a la página de *Idiomas soportados por BabelDOC*. La información allí también se aplica a pdf2zh.

<div align="right"> 
<h6><small>Parte del contenido de esta página ha sido traducido por GPT y puede contener errores.</small></h6>