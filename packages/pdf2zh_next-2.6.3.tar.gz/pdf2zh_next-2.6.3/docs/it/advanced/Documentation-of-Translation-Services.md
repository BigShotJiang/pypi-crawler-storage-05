[**Opzioni avanzate**](./introduction.md) > **Documentazione dei servizi di traduzione** _(attuale)_

---

### Visualizzazione dei servizi di traduzione disponibili tramite Riga di comando

È possibile verificare i servizi di traduzione disponibili e il loro utilizzo stampando il messaggio di aiuto nella Riga di comando.

```bash
pdf2zh_next -h
```

Alla fine del messaggio di aiuto, puoi visualizzare informazioni dettagliate sui diversi servizi di traduzione.

<div align="right"> 
<h6><small>Parte del contenuto di questa pagina è stata tradotta da GPT e potrebbe contenere errori.</small></h6>