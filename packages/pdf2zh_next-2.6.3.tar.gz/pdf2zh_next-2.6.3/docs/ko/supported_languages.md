> [!NOTE]
> *BabelDOC 지원 언어* 페이지로 이동하려면 [여기를 클릭하세요](https://funstory-ai.github.io/BabelDOC/supported_languages/). 해당 정보는 pdf2zh 에도 동일하게 적용됩니다.

<div align="right"> 
<h6><small>이 페이지의 일부 내용은 GPT 에 의해 번역되었으며 오류가 포함될 수 있습니다.</small></h6>