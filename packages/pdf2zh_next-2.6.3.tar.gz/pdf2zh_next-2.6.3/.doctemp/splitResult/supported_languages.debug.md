<!-- CHUNK ID: chunk_C7A7730D  CHUNK TYPE: blockquote START_LINE:1 -->
> [!NOTE]
> Please [click here](https://funstory-ai.github.io/BabelDOC/supported_languages/) to navigate to the *BabelDOC Supported Language* page. The information there also applies to pdf2zh.