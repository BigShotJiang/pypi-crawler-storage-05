"""Demo web application showcasing dc43 features."""
