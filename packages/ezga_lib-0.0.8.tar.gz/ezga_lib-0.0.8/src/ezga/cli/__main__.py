# SPDX-License-Identifier: GPL-3.0-only
from ezga.cli import app

if __name__ == "__main__":
    app()