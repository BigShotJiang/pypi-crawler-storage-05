"""
classification
==============

Sub-package for clustering, labeling, and evaluating structures based on SOAP descriptors.
"""
