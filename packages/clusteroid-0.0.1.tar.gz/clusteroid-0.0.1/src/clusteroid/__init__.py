"""
clusteroid - Ceph management tool.
"""

