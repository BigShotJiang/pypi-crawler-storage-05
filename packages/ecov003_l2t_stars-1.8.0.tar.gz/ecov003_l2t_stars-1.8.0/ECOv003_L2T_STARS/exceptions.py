class CMRServerUnreachable(Exception):
    pass
