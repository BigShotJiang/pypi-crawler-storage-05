from inspect_wandb.models.hooks import WandBModelHooks

__all__ = ["WandBModelHooks"]