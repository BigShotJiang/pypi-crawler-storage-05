# LlamaIndex Index_Store Integration: DuckDB Index Store
