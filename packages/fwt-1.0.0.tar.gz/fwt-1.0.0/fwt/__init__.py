from .authority import Authority

__all__ = ["Authority"]
