class ModelAdminLookupFailed(Exception):
    pass
