# This also needs to be updated in pyproject.toml
__version__ = "3.1.1"
