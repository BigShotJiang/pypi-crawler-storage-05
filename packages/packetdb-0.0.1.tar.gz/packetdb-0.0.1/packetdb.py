"""PacketDB: A data science-native database for packet analysis"""

def placeholder():
    raise NotImplementedError("PacketDB is coming soon! Check https://github.com/packetdb/packetdb")

__version__ = "0.0.1"
