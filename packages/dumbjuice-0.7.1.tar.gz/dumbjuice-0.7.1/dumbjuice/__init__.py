"""DumbJuice: A simple Python installer automation tool"""

from .__version__ import __version__

# Import the build function for convenience
from .build import build