from mcp_sse import main
main()