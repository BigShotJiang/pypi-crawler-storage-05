.. automodule:: apyt.spectrum
   :members:
   :undoc-members:
   :show-inheritance:
