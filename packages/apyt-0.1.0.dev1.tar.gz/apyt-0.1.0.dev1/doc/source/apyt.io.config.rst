.. automodule:: apyt.io.config
   :members:
   :show-inheritance:
   :undoc-members:
