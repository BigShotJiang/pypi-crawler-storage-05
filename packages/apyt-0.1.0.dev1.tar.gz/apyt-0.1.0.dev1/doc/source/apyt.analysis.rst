.. automodule:: apyt.analysis
   :members:
   :undoc-members:
   :show-inheritance:
