"""
Wrapper entry point for the `reconstruction.py` command-line script.
"""
#
#
def main():
    import apyt_cli.reconstruction
