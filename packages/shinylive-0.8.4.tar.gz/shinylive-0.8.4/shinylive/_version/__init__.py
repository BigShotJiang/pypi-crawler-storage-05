# The version of this Python package.
SHINYLIVE_PACKAGE_VERSION = "0.8.4"

# This is the version of the Shinylive assets to use.
SHINYLIVE_ASSETS_VERSION = "0.10.6"
