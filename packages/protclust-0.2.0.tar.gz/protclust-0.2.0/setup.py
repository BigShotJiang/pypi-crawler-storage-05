#!/usr/bin/env python
# setup.py - for backwards compatibility with older tooling
# Most configuration is in pyproject.toml

from setuptools import setup

if __name__ == "__main__":
    setup()
