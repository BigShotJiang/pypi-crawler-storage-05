"""Plugins module for "system" pseudo-instrument"""
