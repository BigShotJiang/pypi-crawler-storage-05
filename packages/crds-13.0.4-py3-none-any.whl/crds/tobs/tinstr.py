"""Place holder for instrument customization plugins module.  See hst package for examples
of actual plugin functions.
"""
