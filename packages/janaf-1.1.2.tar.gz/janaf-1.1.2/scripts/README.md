# How to update

```sh
uv run python ./scripts/update_json.py
uv run python ./scripts/update_data.py
uv run python ./scripts/fix_data.py
```
