.. Spine Database API documentation master file, created by
   sphinx-quickstart on Fri Jan 11 11:19:03 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Spine Database API's documentation!
==============================================

.. image:: img/spinetoolbox_on_wht.svg
   :align: center
   :scale: 30%

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   front_matter
   tutorial
   user_guide
   db_mapping_schema
   filters
   parameter_value_format
   metadata
   autoapi/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
