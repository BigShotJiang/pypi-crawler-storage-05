# SPDX-FileCopyrightText: 2024-present Chris O'Neill <chris@purplejay.io>
#
# SPDX-License-Identifier: MIT

from loguru import logger

logger.disable("pjdev_decorators")
