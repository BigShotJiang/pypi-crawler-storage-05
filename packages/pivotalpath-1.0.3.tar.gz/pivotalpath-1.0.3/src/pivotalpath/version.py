﻿"""Version information for pivotalpath."""
__version__ = "1.0.0"
