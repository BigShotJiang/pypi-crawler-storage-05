from setuptools import setup

setup(
    name='distributions-eg',
    version='0.1',
    packages=['distributions-eg'],
    install_requires=[],
    author='Ali Tharwat',
    zip_safe=False
)
