from distributions import Gaussian

gaussian_one = Gaussian(10, 5)
print(gaussian_one.mean)