from .GaussianDistribution import Gaussian
from .BinomialDistribution import Binomial