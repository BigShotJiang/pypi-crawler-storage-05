# Code of Conduct

Everyone interacting in the pyOpenSci project's codebases, issue trackers, chat rooms, and communication venues is
expected to follow the [pyOpenSci Code of Conduct](https://www.pyopensci.org/handbook/CODE_OF_CONDUCT.html).
