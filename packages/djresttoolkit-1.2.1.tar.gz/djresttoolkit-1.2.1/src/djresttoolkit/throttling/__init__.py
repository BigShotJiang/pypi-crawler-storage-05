from ._throttle_inspector import ThrottleInspector

__all__ = ["ThrottleInspector"]
