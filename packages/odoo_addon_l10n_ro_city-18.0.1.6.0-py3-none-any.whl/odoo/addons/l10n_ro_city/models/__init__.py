from . import res_city
from . import res_partner
from . import res_country_state
