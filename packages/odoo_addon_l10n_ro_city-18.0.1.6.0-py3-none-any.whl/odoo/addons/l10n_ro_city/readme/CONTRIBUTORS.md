  - [Terrabit](https://www.terrabit.ro):
      - Dorin Hongu \<<dhongu@gmail.com>\>
  - [QDev Web Labs](https://qdev.ro):
      - Anastasescu Răzvan-Ioan \<<razvan@qdev.ro>\>

Do not contact contributors directly about support or help with
technical issues.
