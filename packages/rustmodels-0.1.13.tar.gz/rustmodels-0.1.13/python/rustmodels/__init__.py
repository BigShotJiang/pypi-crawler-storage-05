from .py_api import fit_linear_regression
from ._linreg import load_linreg

__all__ = [
    'fit_linear_regression',
    'load_linreg'
]
