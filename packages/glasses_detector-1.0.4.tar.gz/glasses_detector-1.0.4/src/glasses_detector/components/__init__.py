from .base_model import BaseGlassesModel
from .pred_type import PredType
