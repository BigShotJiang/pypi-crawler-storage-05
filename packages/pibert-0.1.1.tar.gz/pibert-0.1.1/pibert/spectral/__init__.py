from .fourier import FourierEmbedding
from .wavelet import WaveletEmbedding
