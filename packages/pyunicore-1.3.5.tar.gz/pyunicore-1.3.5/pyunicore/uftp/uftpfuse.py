import argparse
import os
from errno import EIO
from errno import ENOENT
from errno import ENOSYS
from errno import EROFS
from time import time

from fuse import FUSE
from fuse import FuseOSError
from fuse import Operations

from pyunicore.uftp.uftp import UFTP


class UFTPFile:
    """handle to an in-progress read or write transfer"""

    BUFFER_SIZE = 65536

    def __init__(self, path, uftp_session: UFTP):
        self.uftp_session = uftp_session
        self.path = path
        self.pos = 0
        self.data = None
        self.write_mode = False

    def close(self):
        self.close_data()

    def close_data(self):
        if self.data is not None:
            self.data.close()
        self.data = None
        self.pos = 0

    def open_data(self, position, write_mode=False):
        """open data channel before a sequence of read/write operations"""

        self.write_mode = write_mode
        if self.write_mode:
            _sock = self.uftp_session.get_write_socket(self.path, position)
        else:
            _sock = self.uftp_session.get_read_socket(self.path, position)
        self.pos = position
        if self.write_mode:
            self.data = _sock.makefile("wb", buffering=UFTPFile.BUFFER_SIZE)
        else:
            self.data = _sock.makefile("rb", buffering=UFTPFile.BUFFER_SIZE)

    def read(self, offset, size):
        if self.data is not None and self.write_mode:
            raise OSError("Not open for reading")
        if self.data is None:
            self.open_data(offset, write_mode=False)
        data_block = self.data.read(size)
        self.pos += len(data_block)
        return data_block

    def write(self, offset, data):
        if self.data is not None and not self.write_mode:
            raise OSError("Not open for writing")
        if self.data is None:
            self.open_data(offset, write_mode=True)
        to_write = len(data)
        write_offset = 0
        while to_write > 0:
            written = self.data.write(data[write_offset:])
            if written is None:
                written = 0
            write_offset += written
            to_write -= written
        self.data.flush()
        self.pos += len(data)
        return len(data)


class UFTPDriver(Operations):
    """
    FUSE Driver
    Connects to uftpd at host:port with
    the given session password (which can be obtained by
    authenticating to an Authserver or UNICORE/X)
    """

    def __init__(self, host, port, password, debug=False, read_only=False):
        self.host = host
        self.port = port
        self.password = password
        self.last_file = None
        self.file_map = {}
        self.next_file_handle = 0
        self.debug = debug
        self.read_only = read_only
        self.uftp_session = self.new_session()

    def new_session(self):
        uftp_session = UFTP()
        uftp_session.open_uftp_session(self.host, self.port, self.password)
        if self.debug:
            print("UFTP session initialised.")
        return uftp_session

    def chmod(self, path, mode):
        if self.debug:
            print(f"chmod {path} {mode}")
        if self.read_only:
            raise FuseOSError(EROFS)
        self.uftp_session.chmod(path, mode)

    def chown(self, path, uid, gid):
        raise FuseOSError(ENOSYS)

    def create(self, path, mode):
        if self.debug:
            print(f"create {path} {mode}")
        if self.read_only:
            raise FuseOSError(EROFS)
        fh = self.open(path, os.O_WRONLY)
        f = self.file_map[fh]
        f.write(0, [])
        # TBD f.chmod(mode)
        return fh

    def destroy(self, path):
        for f in self.file_map.values():
            f.close()
        self.uftp_session.close()

    def getattr(self, path, fh=None):
        try:
            return self.uftp_session.stat(path)
        except OSError:
            raise FuseOSError(ENOENT)

    def mkdir(self, path, mode):
        if self.debug:
            print(f"mkdir {path} {mode}")
        if self.read_only:
            raise FuseOSError(EROFS)
        return self.uftp_session.mkdir(path, mode)

    def open(self, path, fi_flags):
        if self.read_only and (os.O_WRONLY & fi_flags):
            raise FuseOSError(EROFS)
        fh = self.next_file_handle
        if os.O_RDWR & fi_flags:
            raise FuseOSError(EIO)
        if self.debug:
            print(f"open [{fh}] {path} flags={fi_flags}")
        self.next_file_handle += 1
        f = UFTPFile(path, self.new_session())
        self.file_map[fh] = f
        return fh

    def read(self, path, size, offset, fh):
        if self.debug:
            print(f"read [{fh}] {path} len={size} offset={offset}")
        f = self.file_map[fh]
        return f.read(offset, size)

    def readdir(self, path, fh):
        return [".", ".."] + [name for name in self.uftp_session.listdir(path)]

    def readlink(self, path):
        raise FuseOSError(ENOSYS)

    def rename(self, old, new):
        if self.read_only:
            raise FuseOSError(EROFS)
        return self.uftp_session.rename(old, new)

    def release(self, path, fh):
        if self.debug:
            print(f"release [{fh}] {path}")
        f = self.file_map[fh]
        f.close()
        self.file_map.__delitem__(fh)

    def rmdir(self, path):
        if self.read_only:
            raise FuseOSError(EROFS)
        if self.debug:
            print(f"rmdir {path}")
        return self.uftp_session.rmdir(path)

    def symlink(self, target, source):
        raise FuseOSError(ENOSYS)

    def truncate(self, path, length, fh=None):
        if self.read_only:
            raise FuseOSError(EROFS)
        if self.debug:
            print(f"truncate size={length} {path}")
        pass

    def unlink(self, path):
        if self.read_only:
            raise FuseOSError(EROFS)
        return self.uftp_session.rm(path)

    def utimens(self, path, times=None):
        if self.read_only:
            raise FuseOSError(EROFS)
        if times is None:
            _time = time()
        else:
            _time = times[0]
        self.uftp_session.set_time(path, _time)

    def write(self, path, data, offset, fh):
        if self.debug:
            print(f"write [{fh}] {path} len={len(data)} offset={offset}")
        f = self.file_map[fh]
        f.write(offset, data)
        return len(data)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-d",
        "--debug",
        action="store_true",
        help="debug mode (also keeps process in the foreground)",
    )
    parser.add_argument(
        "-r",
        "--read-only",
        action="store_true",
        help="read-only mode, prevents writes, renames, etc",
    )
    parser.add_argument(
        "-f",
        "--foreground",
        action="store_true",
        help="run fusedriver in foreground",
    )
    parser.add_argument(
        "-P",
        "--password",
        help="one-time password (if not given, it is expected in the environment UFTP_PASSWORD)",
    )
    parser.add_argument(
        "-o",
        "--fuse-options",
        help="additional options (key1=value1,key2=value2,...) for fusepy",
    )
    parser.add_argument("address", help="UFTPD server's address (host:port)")
    parser.add_argument(
        "mount_point",
        help="the local mount directory (must exist and be empty)",
    )

    args = parser.parse_args()
    _pwd = args.password
    if _pwd is None:
        _pwd = os.getenv("UFTP_PASSWORD")
    if _pwd is None:
        raise TypeError(
            "UFTP one-time password must be given with '-P ...' or as environment UFTP_PASSWORD"
        )
    _host, _port = args.address.split(":")
    foreground = args.foreground or args.debug
    extra_opts = _parse_args(args.fuse_options)
    driver = UFTPDriver(_host, int(_port), _pwd, debug=args.debug, read_only=args.read_only)
    FUSE(
        driver,
        args.mount_point,
        debug=args.debug,
        foreground=foreground,
        nothreads=True,
        **extra_opts,
    )


def _parse_args(args: str) -> dict:
    result = {}
    if args:
        for opt in args.split(","):
            kv = opt.split("=") if "=" in opt else [opt, True]
            result[kv[0]] = kv[1]
    return result


if __name__ == "__main__":
    main()
