#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Overriden subclasses.

.. autosummary::
    :toctree: _wot_subclass

    default_servient
    exposed
"""
