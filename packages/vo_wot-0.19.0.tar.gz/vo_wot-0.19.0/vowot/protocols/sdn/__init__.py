#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
SDN utility functions.

.. autosummary::
    :toctree: _netconf

    utils
"""
