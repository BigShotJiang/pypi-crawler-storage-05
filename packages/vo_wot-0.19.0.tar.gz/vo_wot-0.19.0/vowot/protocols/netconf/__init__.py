#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Netconf utility functions.

.. autosummary::
    :toctree: _netconf

    utils
"""
