#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Generic functions that can be used by VOs.

.. autosummary::
    :toctree: _utils

    functions
"""
