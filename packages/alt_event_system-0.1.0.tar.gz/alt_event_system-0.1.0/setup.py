"""
Setup script for ALT-event-system.

This file exists for compatibility with older installation methods.
The package is primarily configured through pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
