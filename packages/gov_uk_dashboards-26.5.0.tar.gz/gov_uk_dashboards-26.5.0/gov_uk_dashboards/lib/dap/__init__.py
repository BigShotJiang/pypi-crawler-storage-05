"""
Common functionality relating to the DLUHC Data Analytical Platform
"""
