from custom_document_chunker import DemoChunker
from custom_user_function import this_is_a_test_function

if __name__ == "__main__":
    demo_chunker = DemoChunker()
    this_is_a_test_function()
