from setuptools import setup, find_packages

setup(
    name="my-hello-lib-velsankar",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    description="A simple hello world logging library",
    author="Your Name",
    python_requires=">=3.7",
)
