import logging

logging.basicConfig(level=logging.INFO)

def hello_world():
    logging.info("Hello, World from my-hello-lib!")
