The PlotBin Package
===================

The PlotBin package contains utilities to plot binned maps and various
other general plotting utilities for two-dimensional maps.

Installation
------------

install with::

    pip install plotbin

Without writing access to the global ``site-packages`` directory, use::

    pip install --user plotbin

Documentation
-------------

See the file headers.

License
-------

Copyright (c) 2013-2025 Michele Cappellari

This software is provided as is without any warranty whatsoever.
Permission to use, for non-commercial purposes is granted.
Permission to modify for personal or internal use is granted,
provided this copyright and disclaimer are included in all
copies of the software. All other rights are reserved.
In particular, redistribution of the code is not allowed.

