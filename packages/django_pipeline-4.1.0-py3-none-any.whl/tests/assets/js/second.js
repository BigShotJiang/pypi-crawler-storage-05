(function() {
  window.cat = function() {
    console.log("hello world");
  }
}());
