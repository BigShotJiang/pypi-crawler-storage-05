__version__ = '1.27.4'
__commit_hash__ = 'f180e8dc4073334526e2133b98c5f1f7c6be098a'
findlibs_dependencies = ["eccodeslib", "eckitlib", "atlaslib_ecmwf"]
