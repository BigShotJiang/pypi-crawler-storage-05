# kinfer-sim

Viewer for running K-Infer models in simulation.

For more information, see the documentation [here](https://docs.kscale.dev/docs/simulate)
