=======
Credits
=======

Development Lead
----------------

* `Daniel Scheffler <https://www.gfz.de/staff/daniel.scheffler/sec14/>`__ <danschef@gfz.de>

Contributors
------------

* Jessica Palka <jessica.palka@gfz.de>
