__version__ = "0.0.4"

from .api import WplaceAPI
from .canvas import Pixel, Region, Tile
from .color import Color
from .country import Country
