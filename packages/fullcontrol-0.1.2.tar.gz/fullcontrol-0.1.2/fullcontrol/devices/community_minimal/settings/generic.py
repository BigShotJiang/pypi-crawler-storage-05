default_initial_settings = {
    "name": "Generic",
    "start_gcode": "",
    "end_gcode": "",
}
