from .math import add, subtract, multiply, divide

__version__ = "1.0.0"
