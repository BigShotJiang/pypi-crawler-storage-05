"""Entry point for running specify-cli as a module."""

from .core.app import main

if __name__ == "__main__":
    main()
