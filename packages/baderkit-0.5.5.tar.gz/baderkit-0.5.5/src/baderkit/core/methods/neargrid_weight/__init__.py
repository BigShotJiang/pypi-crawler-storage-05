# -*- coding: utf-8 -*-

from .neargrid_weight_method import NeargridWeightMethod
