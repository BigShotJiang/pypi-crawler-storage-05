"""Top-level package for bump-my-version."""

__version__ = "1.2.2"
