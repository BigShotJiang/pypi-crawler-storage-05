# SPDX-FileCopyrightText: 2025-present MauMau <mau.aravena@outlook.com>
#
# SPDX-License-Identifier: BSD-3-Clause
__version__ = "0.0.7"
