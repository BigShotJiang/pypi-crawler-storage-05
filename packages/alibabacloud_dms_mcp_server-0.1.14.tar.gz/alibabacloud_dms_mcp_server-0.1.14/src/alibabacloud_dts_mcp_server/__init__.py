def main() -> None:
    print("Hello from alibabacloud-dts-mcp-server!")
