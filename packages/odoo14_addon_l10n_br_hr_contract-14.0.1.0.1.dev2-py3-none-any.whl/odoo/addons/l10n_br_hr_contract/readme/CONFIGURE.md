Nothing special is needed to configure this module
