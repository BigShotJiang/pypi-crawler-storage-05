# Copyright (C) 2016  Daniel Sadamo - KMEE Informática
# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import hr_data_abstract
from . import hr_contract
from . import hr_contract_admission_type
from . import hr_contract_labor_bond_type
from . import hr_contract_labor_regime
from . import hr_contract_labor_resignation_cause
from . import hr_contract_labor_salary_unit
from . import hr_contract_notice_termination
