def run():
    from . import agent
    agent.main()