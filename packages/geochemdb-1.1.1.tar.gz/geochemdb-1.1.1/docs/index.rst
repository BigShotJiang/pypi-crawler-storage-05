.. mdinclude:: ../readme.md

Contents
========

.. toctree::
   :maxdepth: 2

   Guide <guide>
   Module Reference <modules>
   License <license>
   Changelog <changelog>

Indices and tables
==================

* :ref:`genindex`
