from .flory_huggins import FloryHuggins
from .no_osmosis import NoOsmosis