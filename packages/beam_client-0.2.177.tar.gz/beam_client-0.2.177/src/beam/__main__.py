from beam.cli import main

main.cli()
