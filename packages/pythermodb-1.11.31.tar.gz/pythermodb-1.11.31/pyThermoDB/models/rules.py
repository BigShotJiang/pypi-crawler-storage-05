# import libs
from typing import Dict

ComponentRule = Dict[str, str]
