from .code import code

def hellos():
    print('init hello')
