def phishing():
    return [
        """

Open Terminal and enter following command
>>> setoolkit

• Choose Social –Engineering Attacks by giving “1”
• Choose Website Attack Vectors by giving “2”
• Choose Credential Harvester Attack Method by giving “3”
• Choose Web Templates by giving “1”
• Choose Google Website by giving “2”
• Open browser and enter IPAddress

it opens google
• Enter your details
• Close the Terminal and repeat the above steps until Credential Harvester Attack

• Choose Site Cloner by giving “2”
Enter a website link : www.facebook.com

• Open browser and enter IPAddress and enter details.


"""
    ]