pub const FRAGSPLIT_CMD: &str = "pb";
pub const DEFAULT_OUT: &str = "out/";
