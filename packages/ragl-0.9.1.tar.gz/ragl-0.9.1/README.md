# ragl -- A Python library for storage and retrieval of text embeddings

ragl is being actively developed and will soon be released; check here for updates.
