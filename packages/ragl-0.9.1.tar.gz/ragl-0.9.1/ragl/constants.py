"""Constants shared by more than one module in ragl."""

TEXT_ID_PREFIX = 'txt:'
