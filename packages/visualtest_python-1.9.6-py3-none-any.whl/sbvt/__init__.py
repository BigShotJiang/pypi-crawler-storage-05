# this import statement is here for context.py in tests folder
from .visualtest import VisualTest

__version__ = '1.9.6'
