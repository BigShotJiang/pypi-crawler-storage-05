def main():
    print("Hello from grid-cortex-client!")


if __name__ == "__main__":
    main()
