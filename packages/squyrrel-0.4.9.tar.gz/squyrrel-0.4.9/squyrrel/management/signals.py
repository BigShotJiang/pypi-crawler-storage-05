from squyrrel.core.signals import Signal

