# from .signals import error_signal, debug_signal


# class SquyrrelDefaultLogger:

#     def __init__(self):
#         pass

#     def debug(self, text):
#         print(text)

