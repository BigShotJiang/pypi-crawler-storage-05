from squyrrel.core.signals import Signal

gui_error_signal = Signal('gui_error_signal')
gui_debug_signal = Signal('gui_debug_signal')