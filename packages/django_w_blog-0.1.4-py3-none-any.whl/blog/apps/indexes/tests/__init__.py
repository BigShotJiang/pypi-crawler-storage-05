"""Tests for blog.indexes"""
