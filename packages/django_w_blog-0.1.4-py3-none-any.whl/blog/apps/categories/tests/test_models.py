"""Tests for blog.categories.models"""

from django.test import TestCase


# Create your tests here.
class BlogCategoryTests(TestCase):
    """BlogCategory model tests"""

    def setUp(self) -> None:
        """Setup before tests"""

        return super().setUp()
