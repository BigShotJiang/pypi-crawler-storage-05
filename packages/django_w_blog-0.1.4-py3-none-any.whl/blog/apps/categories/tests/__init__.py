"""Tests for blog.categories"""
