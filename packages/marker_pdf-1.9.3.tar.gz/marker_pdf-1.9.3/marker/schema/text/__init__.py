from marker.schema.text.line import Line
from marker.schema.text.span import Span
