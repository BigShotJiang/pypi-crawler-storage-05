


import time

def block_python_main_thread_exit():
    while 1:
        time.sleep(100)