[![Documentation](https://img.shields.io/badge/documentation-online-blue.svg)](https://libsms.readthedocs.io/en/latest/)
