

def version():
    """
    get version from version file
    :return:
    """
    from bomiot import __version__
    return __version__.version()
