pub mod smart_cache;

pub use smart_cache::{EvictionPolicy, SmartCache};
