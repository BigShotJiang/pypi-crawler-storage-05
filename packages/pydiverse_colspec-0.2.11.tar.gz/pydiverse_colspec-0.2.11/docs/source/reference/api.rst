***
API
***

Public
======

.. py:module:: pydiverse.colspec

.. autoclass:: ColSpec
.. autoclass:: Collection
.. autoclass:: Filter
.. autoclass:: Rule
.. autoclass:: Column
.. autoclass:: Any
.. autoclass:: Bool
.. autoclass:: Date
.. autoclass:: Datetime
.. autoclass:: Decimal
.. autoclass:: Duration
.. autoclass:: Enum
.. autoclass:: Time
.. autoclass:: Float
.. autoclass:: Float32
.. autoclass:: Float64
.. autoclass:: Int8
.. autoclass:: Int16
.. autoclass:: Int32
.. autoclass:: Int64
.. autoclass:: Integer
.. autoclass:: UInt8
.. autoclass:: UInt16
.. autoclass:: UInt32
.. autoclass:: UInt64
.. autoclass:: String
.. autoclass:: List
.. autoclass:: Struct
