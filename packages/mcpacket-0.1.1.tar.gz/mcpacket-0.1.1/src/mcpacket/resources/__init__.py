"""Resources for mcpacket analysis."""

from .references import setup_resources

__all__ = ["setup_resources"]