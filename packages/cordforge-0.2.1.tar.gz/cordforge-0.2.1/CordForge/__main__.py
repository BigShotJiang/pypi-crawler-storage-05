from CordForge.Launcher import Launcher

def run():
    print("Launching Launcher")
    Launcher()

if __name__ == "__main__":
    run()