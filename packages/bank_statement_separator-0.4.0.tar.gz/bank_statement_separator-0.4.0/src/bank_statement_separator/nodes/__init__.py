"""LangGraph nodes for document processing."""
