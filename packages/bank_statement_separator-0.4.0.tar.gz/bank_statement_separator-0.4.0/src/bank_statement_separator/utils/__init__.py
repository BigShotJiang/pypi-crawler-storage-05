"""Utility modules for document processing."""
