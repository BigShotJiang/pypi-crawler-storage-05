To install this module, you need to have the module [Base Comment
Template](https://github.com/OCA/reporting-engine/tree/16.0/base_comment_template).
