Adds comments on

1.  Purchases orders:

    The comments can be edited directly on the purchases orders or
    loaded from templates.

    Two positions are available for the comments:

    - Above purchase order lines
    - Below purchase order lines
