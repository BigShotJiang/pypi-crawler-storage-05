# Do not update manually, this will be generate when building
__version__ = "1.0.0"
