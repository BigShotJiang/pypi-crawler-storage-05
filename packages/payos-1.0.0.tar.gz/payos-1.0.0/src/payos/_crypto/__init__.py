"""Crypto module initialization."""

from .provider import CryptoProvider

__all__ = ["CryptoProvider"]
