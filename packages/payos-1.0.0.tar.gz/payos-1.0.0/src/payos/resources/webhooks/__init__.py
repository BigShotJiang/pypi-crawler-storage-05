"""payOS webhooks resource."""

from .webhooks import AsyncWebhooks, Webhooks

__all__ = ["Webhooks", "AsyncWebhooks"]
