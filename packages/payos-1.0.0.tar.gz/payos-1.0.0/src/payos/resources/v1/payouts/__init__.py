"""Payouts resource module for payOS API v1."""

from .payouts import AsyncPayouts, Payouts

__all__ = ["Payouts", "AsyncPayouts"]
