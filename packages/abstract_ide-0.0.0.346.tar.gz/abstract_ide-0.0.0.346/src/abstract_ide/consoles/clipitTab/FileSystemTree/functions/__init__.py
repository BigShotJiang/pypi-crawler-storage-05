from .text_utils import (copy_selected, _log)
