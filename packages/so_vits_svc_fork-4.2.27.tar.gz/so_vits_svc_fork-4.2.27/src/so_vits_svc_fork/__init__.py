__version__ = "4.2.27"

from .logger import init_logger

init_logger()
