# databoost

`databoost` is a Python library that **enhances your Data Science workflow** with:

- Custom metrics
- Advanced plots (built on matplotlib & seaborn)
- ML models (planned)

## Installation

```bash
pip install databoost
```