# -*- coding: utf-8 -*-
"""
    sphinxcontrib-plot
    ~~~~~~~~~~~~~~~~~~~

    To plot in the .rst document.

    :copyright: Copyright 2021-2031 by Yongping Guo
    :license: BSD, see LICENSE for details.
"""

__import__('pkg_resources').declare_namespace(__name__)

