print("this")
print("and that")
