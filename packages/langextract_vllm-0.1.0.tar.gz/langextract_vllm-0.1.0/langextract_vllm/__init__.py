"""LangExtract provider plugin for VLLM."""

from langextract_vllm.provider import VLLMLanguageModel

__all__ = ['VLLMLanguageModel']
__version__ = "0.1.0"
