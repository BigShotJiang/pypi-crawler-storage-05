# Shuey, M. M., Stead, W. W., Aka, I., Barnado, A. L., Bastarache, J. A., Brokamp, E., … Bastarache, L. (2023).
# Next-generation phenotyping: introducing phecodeX for enhanced discovery research in medical phenomics.
# Bioinformatics (Oxford, England), 39(11). doi:10.1093/bioinformatics/btad655

from pathlib import Path

import pandas as pd
import polars as pl

# Import the generalized function
from .CustomComorbidityIndex import CustomComorbidityIndex


def Phecode(
    df: pl.DataFrame,
    id_col: str = "id",
    code_col: str = "code",
    sex_col: str = "sex",
    icd_version: str = "icd10",
    icd_version_col: str = None,
    implementation: str = "phecode",
):
    """
    Calculate the Elixhauser Comorbidity Index (ECI) using ICD codes.

    Args:
        df (pl.DataFrame): DataFrame with at least columns [id_col, code_col].
        id_col (str): Name of the column containing unique identifier. Default: "id".
        code_col (str): Name of the column containing ICD codes. Default: "code".
        sex_col (str): Name of the column containing patient sexes. Default: "sex".
        icd_version (str): ICD version ('icd9', 'icd10', or 'icd9_10'). Default: "icd10".
        icd_version_col (str, optional): Name of the column with ICD version for 'icd9_10'. Default: None.
        implementation (str): Coding algorithm ('phecode' or 'phecodeX'). Default: "phecode".

    Returns:
        - DataFrame with [id_col, score_col_name] and category indicators if return_categories is True, else None.
    """

    # Check if input is pandas DataFrame and convert to polars
    is_pandas = pd and isinstance(df, pd.DataFrame)
    if is_pandas:
        df = pl.from_pandas(df)

    # Input validation specific to Elixhauser
    assert implementation in [
        "phecode",
        "phecodeX",
    ], "implementation must be one of: 'phecode', 'phecodeX'."

    # Determine definition file based on implementation
    if implementation == "phecode":
        definition_file = "phecode.csv"
    elif implementation == "phecodeX":
        definition_file = "phecodeX_R_map.csv"
        rollup_map_file = "phecodeX_R_rollup_map.csv"
        exclusions_file = "phecodeX_R_sex.csv"
    else:
        # Should be caught by assert earlier, but as a safeguard
        raise ValueError(f"Unsupported implementation: {implementation}")

    # Load definition files
    base_path = Path(__file__).parent / "common/"
    definition_file_path = base_path / definition_file
    rollup_map_file_path = base_path / rollup_map_file
    exclusions_file_path = base_path / exclusions_file

    # Transform definitions to wide format
    df_definitions = (
        pl.read_csv(definition_file_path)
        .join(
            pl.read_csv(rollup_map_file_path).rename({"code": "phecode"}),
            on="phecode",
            how="full",
            coalesce=True,
        )
        # replace dots in ICD codes to match input format
        .with_columns(pl.col("code").str.replace_all(r"\.", ""))
        .group_by("phecode_unrolled", "vocabulary_id")
        .agg(pl.col("code").explode())
        .with_columns(pl.col("code").list.join("|").alias("code"))
        .pivot(
            values="code",
            index="phecode_unrolled",
            columns="vocabulary_id",
            aggregate_function="first",
        )
        .rename(
            {
                "phecode_unrolled": "category",
                "ICD9CM": "icd9_codes",
                "ICD10CM": "icd10_codes",
            }
        )
    )

    df_combined = df_definitions.with_columns(pl.lit(0).alias("weight"))

    # Load and process exclusion rules for phecodeX
    mutual_exclusion_rules = []
    if implementation == "phecodeX":
        df_exclusions = pl.read_csv(exclusions_file_path).filter(
            pl.col("male_only") | pl.col("female_only")
        )
        for row in df_exclusions.iter_rows(named=True):
            mutual_exclusion_rules.append(
                ("Is Male" if row["male_only"] else "Is Female", row["phecode"])
            )

    # Add relevant sex column to df
    df = df.with_columns(
        pl.when(pl.col(sex_col) == "Male")
        .then(pl.lit(1))
        .otherwise(pl.lit(0))
        .alias("Is Male"),
        pl.when(pl.col(sex_col) == "Female")
        .then(pl.lit(1))
        .otherwise(pl.lit(0))
        .alias("Is Female"),
    )

    # Call the generalized function with the combined DataFrame
    df_phecode = CustomComorbidityIndex(
        df=df,
        id_col=id_col,
        code_col=code_col,
        icd_version=icd_version,
        icd_version_col=icd_version_col,
        definition_data=df_combined,
        weight_col_name="weight",
        score_col_name="score_col",
        mutual_exclusion_rules=None,
        return_categories=True,
        no_best_prefix_match=True,
    ).drop("score_col")

    if is_pandas:
        return df_phecode.to_pandas()

    return df_phecode
