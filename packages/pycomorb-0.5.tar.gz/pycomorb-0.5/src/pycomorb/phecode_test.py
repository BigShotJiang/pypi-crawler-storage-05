import polars as pl
import time
from pycomorb import comorbidity

info = pl.scan_parquet(
    "/Users/fassbender/Developer/reprodICUbility/reprodICU_OMOP/reprodICU_files/patient_information.parquet"
)
diags = pl.scan_parquet(
    "/Users/fassbender/Developer/reprodICUbility/reprodICU_OMOP/reprodICU_files/diagnoses_imputed.parquet"
)

SEXES = info.select("Global ICU Stay ID", "Gender")

DIAGNOSES = diags.join(
    SEXES, on="Global ICU Stay ID", how="left", coalesce=True
).with_columns(
    pl.when(pl.col("Diagnosis ICD Code Version (source)") == "ICD-9")
    .then(pl.col("Diagnosis ICD-9 Code"))
    .otherwise(pl.col("Diagnosis ICD-10 Code"))
    .alias("Diagnosis ICD Code")
)

start = time.time()
PHECODE = (
    comorbidity(
        score="phecode",
        implementation="phecodeX",
        df=DIAGNOSES.collect(),
        id_col="Global ICU Stay ID",
        code_col="Diagnosis ICD Code",
        sex_col="Gender",
        icd_version="icd9_10",
        icd_version_col="Diagnosis ICD Code Version (source)",
    )
)
print(f"Time taken: {time.time() - start:.2f} seconds")
PHECODE.write_parquet("phecode_output.parquet")
print(PHECODE)