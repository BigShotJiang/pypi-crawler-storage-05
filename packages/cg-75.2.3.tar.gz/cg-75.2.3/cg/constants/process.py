"""Constants for Processes"""

EXIT_SUCCESS = 0
EXIT_WARNING = 8
EXIT_FAIL = 1
EXIT_PARSE_ERROR = 2
