"""Constants for manifest files."""

TRANSFER_VALIDATED_FILE = "transfer_validated.txt"
PACBIO_MANIFEST_FILE_PATTERN = "transferdone"
