# ipgs/__init__.py
from .core import iPgs
