"""
This package supports the diffify backend, and the submissions and data APIs for diffify
"""

__version__ = "0.2.1"
