python3 -m grpc_tools.protoc --python_out=src/tollingvision_scsinfo/ --grpc_python_out=src/tollingvision_scsinfo/ --proto_path=../../service/src/main/proto/ TollingVisionService.proto
