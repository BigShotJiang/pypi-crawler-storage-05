"""
Version for PyMandel Application.
"""

__version__ = "1.0.16"
