import time


START_TIME = time.perf_counter_ns()
