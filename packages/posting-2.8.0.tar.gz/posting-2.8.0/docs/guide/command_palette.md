## Overview

The *command palette* is a way to search for and execute commands in Posting.

Some functionality in Posting can only be accessed through the command palette.

It can be used to switch themes, show/hide parts of the UI, and more.

### Using the command palette

Press ++ctrl+p++ to open the command palette.
