cd ..
git add .
git commit -m "fix"
git push arpakit_github_1
