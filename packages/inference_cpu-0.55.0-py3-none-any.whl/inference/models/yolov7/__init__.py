from inference.models.yolov7.yolov7_instance_segmentation import (
    YOLOv7InstanceSegmentation,
)
