"""Test package for smoketests.

Ensures relative imports like `from .utils import ...` work under pytest.
"""


