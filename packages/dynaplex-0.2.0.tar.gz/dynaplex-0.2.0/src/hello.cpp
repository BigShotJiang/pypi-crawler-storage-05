#include "dynaplex/hello.h"

namespace dynaplex {
	std::string goodbye() {
		return "Goodbye from DynaPlex!";
	}
} // namespace dynaplex