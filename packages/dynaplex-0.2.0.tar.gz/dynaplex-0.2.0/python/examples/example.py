import dynaplex as dp

print(dp.greet("World"))
