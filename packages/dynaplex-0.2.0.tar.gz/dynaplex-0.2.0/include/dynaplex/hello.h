#pragma once
#include <string>


namespace dynaplex {


inline std::string hello() {
return "Hello from DynaPlex!";
}

std::string goodbye();

} // namespace dynaplex