# © 2016 Chafique DELLI @ Akretion
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import wizard_update_invoice_supplierinfo
from . import wizard_update_invoice_supplierinfo_line
