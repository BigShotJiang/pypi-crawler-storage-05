This module allows to automatically update all products information in a
vendor bill for which the purchase information on the line is different
from the vendor information defined in the product form.

It creates a new vendor information line if there isn't any, or it
updates the first one in the list.
