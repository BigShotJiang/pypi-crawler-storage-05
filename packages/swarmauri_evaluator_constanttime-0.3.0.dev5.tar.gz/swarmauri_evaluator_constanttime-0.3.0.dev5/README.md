# swarmauri_evaluator_constanttime

Evaluator that detects timing side channels using a simple fixed-vs-random test.
