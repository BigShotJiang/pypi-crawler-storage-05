# my_package/main.py

def main():
    print("Hello from my Python CLI authbox-library!")

if __name__ == "__main__":
    main()