"""
Provides authbox_learn version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update authbox_learn` to change this file.

from incremental import Version

__version__ = Version("authbox_learn", 1, 0, 0)
__all__ = ["__version__"]
