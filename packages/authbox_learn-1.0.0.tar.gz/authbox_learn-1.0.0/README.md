# Learn Library

Use for learn how to create library in python, that can be use in linx after install it.

## Content of library folder
1. manage.py            # when you create django project this file auto create
2. MANIFEST.in          # when your library need to include additional file
3. LICENSE              # Always include this file
4. requirements.txt     # if library need other library to run
5. setup.py             # need by pypi.org to name the library and create release version


### How to use
    > mkvirtualenv env_test     # named your environment
    > workon env_test           # activate yout environment
    > mylearn                   # your library is ready to use

