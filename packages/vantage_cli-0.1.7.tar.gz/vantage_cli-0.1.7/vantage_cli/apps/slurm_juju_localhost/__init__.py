"""Juju localhost deployment app package."""

from .app import deploy

__all__ = ["deploy"]
