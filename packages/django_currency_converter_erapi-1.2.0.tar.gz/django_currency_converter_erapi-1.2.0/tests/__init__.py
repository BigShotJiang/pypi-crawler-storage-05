"""
Tests package initialization
"""

