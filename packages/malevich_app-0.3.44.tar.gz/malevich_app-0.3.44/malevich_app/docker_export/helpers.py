from malevich_app.export.secondary.LocalDfs import LocalDfs


class LocalDfsSpark(LocalDfs):  # only for spark mode
    pass
