Python REST API client for Shaken Fist
======================================

This is a python REST API client and command line client for the minimal cloud [Shaken Fist](https://github.com/shakenfist/shakenfist).

The library is a complete interface to the Shaken Fist HTTP API.