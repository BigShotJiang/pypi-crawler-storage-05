"""
Lakeshore
"""
from .lakeshore import Lakeshore

