"""
Function Generators
"""
from .keysightDSOX1200 import KeysightDSOX1200

