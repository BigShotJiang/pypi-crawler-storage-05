"""
Function Generators
"""
from .rigoldg800 import RigolDG800


