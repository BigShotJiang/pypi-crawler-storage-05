"""
Function Generators
"""
from .agilent33500B import Agilent33500B


