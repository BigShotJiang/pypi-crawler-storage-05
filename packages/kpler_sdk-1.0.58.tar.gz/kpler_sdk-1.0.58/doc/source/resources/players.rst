Players
-------

.. note::
    available on platforms : Platform.Liquids, Platform.LNG, Platform.LPG, Platform.Dry

.. autoclass:: kpler.sdk.resources.players.Players
    :members:
