Vessels
-------

.. note::
    available on platforms : Platform.Liquids, Platform.LNG, Platform.LPG, Platform.Dry

.. autoclass:: kpler.sdk.resources.vessels.Vessels
    :members:
