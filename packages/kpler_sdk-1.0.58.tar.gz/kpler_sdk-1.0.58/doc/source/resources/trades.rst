Trades
------

.. note::
    available on platforms : Platform.Liquids, Platform.LNG, Platform.LPG, Platform.Dry

.. autoclass:: kpler.sdk.resources.trades.Trades
    :members:

.. autoclass:: kpler.sdk.TradesStatus
    :members:
