Inventories Tank Levels
-----------------------

.. note::
    available on platform : Platform.Liquids

.. autoclass:: kpler.sdk.resources.inventories_tank_levels.InventoriesTankLevels
    :members:
