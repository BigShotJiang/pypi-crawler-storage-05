Contracts
---------

.. note::
    available on platform : Platform.LNG

.. autoclass:: kpler.sdk.resources.contracts.Contracts
    :members:

.. autoclass:: kpler.sdk.ContractsTypes
    :members:
