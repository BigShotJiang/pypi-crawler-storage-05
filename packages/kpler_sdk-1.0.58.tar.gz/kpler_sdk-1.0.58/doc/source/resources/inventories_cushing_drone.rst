Inventories Cushing Drone
-------------------------

.. note::
    available on platform : Platform.Liquids

.. autoclass:: kpler.sdk.resources.inventories_cushing_drone.InventoriesCushingDrone
    :members:

.. autoclass:: kpler.sdk.enums.InventoriesDronePeriod
    :members:
