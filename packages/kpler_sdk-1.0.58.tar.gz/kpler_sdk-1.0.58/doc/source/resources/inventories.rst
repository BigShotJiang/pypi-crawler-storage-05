Inventories
-----------

.. note::
    available on platform : Platform.Liquids

.. autoclass:: kpler.sdk.resources.inventories.Inventories
    :members:

.. autoclass:: kpler.sdk.InventoriesPeriod
    :members:

.. autoclass:: kpler.sdk.InventoriesSplit
    :members:
