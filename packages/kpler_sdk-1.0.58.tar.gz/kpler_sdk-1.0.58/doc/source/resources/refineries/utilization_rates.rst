Refineries Utilization Rates
----------------------------

.. note::
    available on platforms : Platform.Liquids

.. autoclass:: kpler.sdk.resources.refineries.utilization_rates.UtilizationRates
    :members:

.. autoclass:: kpler.sdk.UtilizationGranularity
    :members:
    :noindex:

.. autoclass:: kpler.sdk.UtilizationSplit
    :members:
    :noindex:
