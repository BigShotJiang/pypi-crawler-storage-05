Refineries Crude Runs
---------------------

.. note::
    available on platforms : Platform.Liquids

.. autoclass:: kpler.sdk.resources.refineries.crude_runs.CrudeRuns
    :members:
    :noindex:

.. autoclass:: kpler.sdk.RunsGranularity
    :members:
    :noindex:

.. autoclass:: kpler.sdk.RunsUnit
    :members:
    :noindex:
.. autoclass:: kpler.sdk.RunsQualities
    :members:
    :noindex:
.. autoclass:: kpler.sdk.RunsSplit
    :members:
    :noindex:
