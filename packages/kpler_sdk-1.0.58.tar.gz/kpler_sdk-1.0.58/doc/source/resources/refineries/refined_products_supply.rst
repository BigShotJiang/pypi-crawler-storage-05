Refineries Refined Products Supply
----------------------------------

.. note::
    available on platforms : Platform.Liquids

.. autoclass:: kpler.sdk.resources.refineries.refined_products_supply.RefinedProductsSupply
    :members:

.. autoclass:: kpler.sdk.RefinedProductsGranularity
    :members:
    :noindex:

.. autoclass:: kpler.sdk.RefinedProductsUnit
    :members:
    :noindex:

.. autoclass:: kpler.sdk.RefinedProducts
    :members:
    :noindex:

.. autoclass:: kpler.sdk.RefinedProductsSplit
    :members:
    :noindex:


