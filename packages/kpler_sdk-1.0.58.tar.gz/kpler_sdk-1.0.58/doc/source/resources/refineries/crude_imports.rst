Refineries Crude Imports
------------------------

.. note::
    available on platforms : Platform.Liquids

.. autoclass:: kpler.sdk.resources.refineries.crude_imports.CrudeImports
    :members:
    :noindex:
.. autoclass:: kpler.sdk.ImportsGranularity
    :members:
    :noindex:
.. autoclass:: kpler.sdk.ImportsUnit
    :members:
    :noindex:
.. autoclass:: kpler.sdk.RunsQualities
    :members:
    :noindex:
.. autoclass:: kpler.sdk.ImportsSplit
    :members:
    :noindex:

.. autoclass:: kpler.sdk.ImportsMetric
    :members:
    :noindex:
