Refineries Margins
-------------------

.. note::
    available on platforms : Platform.Liquids

.. autoclass:: kpler.sdk.resources.refineries.margins.Margins
    :members:

.. autoclass:: kpler.sdk.MarginsGranularity
    :members:
    :noindex:

.. autoclass:: kpler.sdk.MarginsSplit
    :members:
    :noindex:
