Refineries Secondary Unit Feed Input
------------------------------------

.. note::
    available on platforms : Platform.Liquids

.. autoclass:: kpler.sdk.resources.refineries.secondary_unit_feed_input.SecondaryUnitFeedInput
    :members:

.. autoclass:: kpler.sdk.SecondaryFeedGranularity
    :members:
    :noindex:

.. autoclass:: kpler.sdk.SecondaryFeedUnit
    :members:
    :noindex:
.. autoclass:: kpler.sdk.SecondaryFeedSplit
    :members:
    :noindex:

