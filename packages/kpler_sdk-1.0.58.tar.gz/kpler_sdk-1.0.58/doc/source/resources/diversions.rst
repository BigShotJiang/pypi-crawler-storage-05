Diversions
----------

.. note::
    available on platform : Platform.LNG

.. autoclass:: kpler.sdk.resources.diversions.Diversions
    :members:

.. autoclass:: kpler.sdk.DiversionsVesselState
    :members:
