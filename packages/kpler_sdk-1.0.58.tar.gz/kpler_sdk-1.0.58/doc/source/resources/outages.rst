Outages
-------

.. note::
    available on platform : Platform.LNG

.. autoclass:: kpler.sdk.resources.outages.Outages
    :members:

.. autoclass:: kpler.sdk.OutagesTypes
    :members:
