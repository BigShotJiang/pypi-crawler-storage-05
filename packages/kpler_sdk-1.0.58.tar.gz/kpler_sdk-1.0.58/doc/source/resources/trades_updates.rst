Trades Updates
--------------

.. note::
    available on platforms : Platform.Liquids, Platform.LNG, Platform.LPG, Platform.Dry

.. autoclass:: kpler.sdk.resources.trades_updates.TradesUpdates
    :members:

