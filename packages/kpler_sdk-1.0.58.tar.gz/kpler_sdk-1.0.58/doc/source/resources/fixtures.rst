Fixtures
--------

.. note::
    available on platforms : Platform.Liquids

.. autoclass:: kpler.sdk.resources.fixtures.Fixtures
    :members:

.. autoclass:: kpler.sdk.VesselTypesCPP
    :members:
    :noindex:

.. autoclass:: kpler.sdk.VesselTypesOil
    :members:
    :noindex:

.. autoclass:: kpler.sdk.FixturesStatuses
    :members:
    :noindex:
