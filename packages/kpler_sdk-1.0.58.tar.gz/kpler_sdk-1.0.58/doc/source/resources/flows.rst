Flows
-----

.. note::
    available on platforms : Platform.Liquids, Platform.LNG, Platform.LPG, Platform.Dry

.. autoclass:: kpler.sdk.resources.flows.Flows
    :members:

.. autoclass:: kpler.sdk.FlowsDirection
    :members:

.. autoclass:: kpler.sdk.FlowsSplit
    :members:

.. autoclass:: kpler.sdk.FlowsPeriod
    :members:

.. autoclass:: kpler.sdk.FlowsMeasurementUnit
    :members:
    
.. autoclass:: kpler.sdk.VesselTypesCPP
    :members:
    :noindex:

.. autoclass:: kpler.sdk.VesselTypesLNG
    :members:
    :noindex:

.. autoclass:: kpler.sdk.VesselTypesLPG
    :members:
    :noindex:

.. autoclass:: kpler.sdk.VesselTypesDry
    :members:
    :noindex:

.. autoclass:: kpler.sdk.VesselTypesOil
    :members:
    :noindex:


