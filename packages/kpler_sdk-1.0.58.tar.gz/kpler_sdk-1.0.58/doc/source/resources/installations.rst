Installations
-------------

.. note::
    available on platforms : Platform.LNG

.. autoclass:: kpler.sdk.resources.installations.Installations
    :members:
