Trades Snapshot
---------------

.. note::
    available on platforms : Platform.Liquids, Platform.LNG, Platform.LPG, Platform.Dry

.. autoclass:: kpler.sdk.resources.trades_snapshot.TradesSnapshot
    :members:

.. autoclass:: kpler.sdk.TradesStatus
    :noindex:
    :members:
