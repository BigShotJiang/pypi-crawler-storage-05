Supply & Demand
---------------

.. note::
    available on platforms : Platform.Liquids

.. autoclass:: kpler.sdk.resources.supply_demand.SupplyDemand
    :members:

.. autoclass:: kpler.sdk.SupplyDemandMetric
    :members:

.. autoclass:: kpler.sdk.SupplyDemandSplit
    :members:
