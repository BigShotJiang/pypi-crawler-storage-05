Ship To Ships
-------------

.. note::
    available on platforms : Platform.Liquids, Platform.LNG, Platform.LPG

.. autoclass:: kpler.sdk.resources.ship_to_ships.ShipToShips
    :members:
