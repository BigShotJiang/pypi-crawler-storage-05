This module allows exporting HTML fields as plain text.
