Lists (numbered, bullets, checklists) and rich formatting (bold, italics, 
underline, colors, fonts, alignment) from Odoo HTML fields are not preserved in 
exports; all are simplified to plain text.
