"""JVM MCP Server Native 测试包"""
