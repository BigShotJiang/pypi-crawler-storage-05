"""JVM MCP Server

基于Arthas的JVM监控MCP服务器实现
"""

__version__ = "0.1.0"
