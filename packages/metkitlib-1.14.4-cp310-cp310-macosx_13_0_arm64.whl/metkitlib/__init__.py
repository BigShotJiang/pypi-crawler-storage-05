__version__ = '1.14.4'
__commit_hash__ = 'f7e645d0f89c1f10aba00142c10d161c3e50d021'
findlibs_dependencies = ["eckitlib", "eccodeslib"]
