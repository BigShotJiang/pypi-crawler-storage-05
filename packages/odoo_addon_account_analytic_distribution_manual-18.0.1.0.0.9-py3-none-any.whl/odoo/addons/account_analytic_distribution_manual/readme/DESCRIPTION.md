This module provides an easy way to quickly autocomplete analytic
accounts on any model that has a field for analytic accounts.
