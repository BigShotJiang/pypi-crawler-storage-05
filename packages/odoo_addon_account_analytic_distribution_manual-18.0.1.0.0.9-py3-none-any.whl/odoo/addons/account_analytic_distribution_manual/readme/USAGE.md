1.  Go to Invoicing \> Customer \> Invoices
2.  Open or create a invoice
3.  On the invoice line, select the analytic account. A new field
    labeled "Manual Distribution" should appear at the top.
4.  Select a record from the list, and it will be added to the
    distribution and the invoice lines.
