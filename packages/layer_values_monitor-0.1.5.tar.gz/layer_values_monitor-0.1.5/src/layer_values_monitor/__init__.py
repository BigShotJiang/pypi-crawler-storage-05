# ruff: noqa
def main() -> None:
    print("Hello from layer-values-monitor!")
