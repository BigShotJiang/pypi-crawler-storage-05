from dify_oapi.core.model.base_response import BaseResponse

from .tool_icon import AppMeta


class GetMetaResponse(AppMeta, BaseResponse):
    pass
