from core_lib.data_layers.data_access.data_access import DataAccess
# template_connections_imports
# template_function_imports
# template_entity_imports


class Template(DataAccess):
# template_init
# template_functions
