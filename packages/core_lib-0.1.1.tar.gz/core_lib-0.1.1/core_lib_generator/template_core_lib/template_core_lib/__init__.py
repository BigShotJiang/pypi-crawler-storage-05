# Version of the core_lib
# template_version
