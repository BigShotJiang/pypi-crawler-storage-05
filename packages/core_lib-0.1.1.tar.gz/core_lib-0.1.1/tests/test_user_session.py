import unittest

cache_client_name = "xyz"


class TestUserSession(unittest.TestCase):

    test_value = 100

    @classmethod
    def setUpClass(cls):
        pass

    def test_x(self):
        pass
