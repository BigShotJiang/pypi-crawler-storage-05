from abc import ABC

from core_lib.registry.registry import Registry


class ConnectionRegistry(Registry, ABC):
    pass
