# Version of the core_lib
__version__ = "0.1.1"
