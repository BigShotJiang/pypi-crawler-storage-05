class Service(object):
    pass
