# this class is the basic data_access class.
class DataAccess(object):
    pass
