class CoreLibInitException(Exception):
    pass
