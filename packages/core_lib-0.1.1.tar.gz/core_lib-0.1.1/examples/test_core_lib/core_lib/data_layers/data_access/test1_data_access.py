from core_lib.data_layers.data_access.data_access import DataAccess


class Test1DataAccess(DataAccess):
    def get_value(self):
        return 1
