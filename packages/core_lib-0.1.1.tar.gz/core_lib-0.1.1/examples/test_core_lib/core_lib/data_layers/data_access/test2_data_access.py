from core_lib.data_layers.data_access.data_access import DataAccess


class Test2DataAccess(DataAccess):
    def get_value(self):
        return 2
