# sage_setup: distribution = sagemath-giac
