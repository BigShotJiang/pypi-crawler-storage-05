from slidge import entrypoint

entrypoint("superduper")
