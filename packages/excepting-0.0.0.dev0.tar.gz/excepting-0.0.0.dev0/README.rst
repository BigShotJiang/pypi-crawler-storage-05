=========
excepting
=========

Overview
--------

excepting

Installation
------------

To install ``excepting``, you can use ``pip``. Open your terminal and run:

.. code-block:: bash

    pip install excepting

License
-------

This project is licensed under the MIT License.

Links
-----

* `Download <https://pypi.org/project/excepting/#files>`_
* `Index <https://pypi.org/project/excepting/>`_
* `Source <https://github.com/johannes-programming/excepting/>`_

Credits
-------

* Author: Johannes
* Email: `johannes.programming@gmail.com <mailto:johannes.programming@gmail.com>`_

Thank you for using ``excepting``!