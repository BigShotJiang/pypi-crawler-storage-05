from excepting.core import *
from excepting.tests import *

if __name__ == "__main__":
    main()
