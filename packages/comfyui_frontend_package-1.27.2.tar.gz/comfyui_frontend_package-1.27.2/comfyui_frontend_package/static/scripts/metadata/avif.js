// Shim for scripts/metadata/avif.ts
export const parseExifData = window.comfyAPI.avif.parseExifData;
export const getFromAvifFile = window.comfyAPI.avif.getFromAvifFile;
