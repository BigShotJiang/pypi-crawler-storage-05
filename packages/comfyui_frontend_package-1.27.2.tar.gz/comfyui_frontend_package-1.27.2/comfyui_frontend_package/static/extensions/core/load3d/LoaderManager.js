// Shim for extensions/core/load3d/LoaderManager.ts
export const LoaderManager = window.comfyAPI.LoaderManager.LoaderManager;
