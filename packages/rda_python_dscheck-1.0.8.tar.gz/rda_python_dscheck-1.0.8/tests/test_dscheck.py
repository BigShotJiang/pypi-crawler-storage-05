# test_dscheck.py

import pytest

def test_something():
   pass
