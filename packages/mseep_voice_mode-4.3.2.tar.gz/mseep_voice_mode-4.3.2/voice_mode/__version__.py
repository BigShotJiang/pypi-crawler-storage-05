# This file is automatically updated by 'make release'
# Do not edit manually
__version__ = "4.3.2"
