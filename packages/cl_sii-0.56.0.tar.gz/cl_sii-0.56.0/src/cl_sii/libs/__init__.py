"""
Package that contains code useful for :mod:`cl_sii` but not particular to it.

"""
