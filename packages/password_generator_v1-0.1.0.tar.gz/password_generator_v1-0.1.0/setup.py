from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="scientific-calculator-v1",
    version="0.2.0",
    packages=find_packages(),
    description="A Python package for a scientific calculator",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Sarif Mia",
    author_email="sarifmia.ofc@gmail.com",
    url="https://github.com/sarif-mia/scientific-calculator",
    project_urls={
        "Documentation": "https://github.com/sarif-mia/scientific-calculator#readme",
        "Source": "https://github.com/sarif-mia/scientific-calculator",
        "Tracker": "https://github.com/sarif-mia/scientific-calculator/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
