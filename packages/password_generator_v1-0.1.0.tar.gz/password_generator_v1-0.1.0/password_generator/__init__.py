from .password_generator import PasswordGenerator

__version__ = "0.1.0"
