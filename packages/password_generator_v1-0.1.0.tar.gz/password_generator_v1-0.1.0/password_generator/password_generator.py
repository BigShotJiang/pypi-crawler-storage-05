import random
import string

class PasswordGenerator:
    def __init__(self, length=12, use_uppercase=True, use_digits=True, use_special=True):
        self.length = length
        self.use_uppercase = use_uppercase
        self.use_digits = use_digits
        self.use_special = use_special

    def generate(self):
        characters = string.ascii_lowercase
        if self.use_uppercase:
            characters += string.ascii_uppercase
        if self.use_digits:
            characters += string.digits
        if self.use_special:
            characters += string.punctuation

        if self.length < 1:
            raise ValueError("Password length must be at least 1")

        password = ''.join(random.choice(characters) for _ in range(self.length))
        return password
