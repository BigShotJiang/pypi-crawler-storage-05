#!/usr/bin/env python3

import argparse
from .password_generator import PasswordGenerator

def main():
    parser = argparse.ArgumentParser(description="Generate secure passwords")
    parser.add_argument("-l", "--length", type=int, default=12, help="Password length (default: 12)")
    parser.add_argument("--no-uppercase", action="store_true", help="Exclude uppercase letters")
    parser.add_argument("--no-digits", action="store_true", help="Exclude digits")
    parser.add_argument("--no-special", action="store_true", help="Exclude special characters")
    parser.add_argument("-n", "--number", type=int, default=1, help="Number of passwords to generate (default: 1)")

    args = parser.parse_args()

    generator = PasswordGenerator(
        length=args.length,
        use_uppercase=not args.no_uppercase,
        use_digits=not args.no_digits,
        use_special=not args.no_special
    )

    for _ in range(args.number):
        password = generator.generate()
        print(password)

if __name__ == "__main__":
    main()
