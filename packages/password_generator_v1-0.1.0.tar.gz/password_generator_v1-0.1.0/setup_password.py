from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="password-generator-v1",
    version="0.1.0",
    packages=find_packages(),
    description="A secure password generator Python package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Sarif Mia",
    author_email="sarifmia.ofc@gmail.com",
    url="https://github.com/sarif-mia/password-generator",
    project_urls={
        "Documentation": "https://github.com/sarif-mia/password-generator#readme",
        "Source": "https://github.com/sarif-mia/password-generator",
        "Tracker": "https://github.com/sarif-mia/password-generator/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    entry_points={
        'console_scripts': [
            'password-generator=password_generator.cli:main',
        ],
    },
)
