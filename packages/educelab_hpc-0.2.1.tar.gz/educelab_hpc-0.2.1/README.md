# EduceLab HPC

`educelab-hpc` is a Python module providing helper functions for working in HPC
environments.
