# Lokis Duplicates

A simple Python library by Loki to find duplicate values in lists, strings, and more.

## Installation
```bash
pip install lokis-duplicates
