def custom_msg(msg) :
    print(msg)
    return " DONE "
print(custom_msg(" HELLO WORLD "))