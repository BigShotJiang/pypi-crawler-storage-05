# My DSA Python Package

Single-file Python toolkit for Data Structures and Algorithms.
Supports Array, LinkedList, Stack, Queue, Graph, Sorting, Searching.
Pipe-style chaining supported.