"""Compatibility wrapper for autocleaneeg_view.viewer."""

from autocleaneeg_view.viewer import *  # noqa: F401,F403
