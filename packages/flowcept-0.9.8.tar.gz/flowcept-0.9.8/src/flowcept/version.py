"""Version module."""

# WARNING: CHANGE THIS FILE MANUALLY ONLY TO RESOLVE CONFLICTS OR TO UPDATE Major or Minor versions.
# The expected format is: <Major>.<Minor>.<Patch>
# This file is supposed to be automatically modified by the CI Bot.
# See .github/workflows/version_bumper.py
__version__ = "0.9.8"
