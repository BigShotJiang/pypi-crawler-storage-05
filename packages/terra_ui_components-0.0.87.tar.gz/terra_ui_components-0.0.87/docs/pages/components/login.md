---
meta:
    title: Login
    description:
layout: component
---

```html:preview
<terra-login>
  <span slot="loading">Please wait...checking if you are logged in...</span>
  <span slot="logged-in">You are logged in!</span>
</terra-login>
```

[component-metadata:terra-login]
