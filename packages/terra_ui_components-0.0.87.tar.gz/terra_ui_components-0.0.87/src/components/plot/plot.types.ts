export interface Plot {
    type: string
    mode: string
    name: string
    x: Array<number>
    y: Array<number>
    line: string
}
