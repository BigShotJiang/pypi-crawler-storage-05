# mmap_ninja_dataframe
Memory-mapped dataframe abstraction based on mmap_ninja 
