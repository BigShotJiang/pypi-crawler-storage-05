# convert_markdown
#convert_md dir=/path ext=pdf,docx
#convert_md dir=/path recursive=true
#convert_md dir=/path output=/output/path
#convert_md dir=/path ext=pdf,pptx recursive=true output=//output/pat
### doc truc tiep, khong luu file
#convert_md uri=file:///path/to/your/document.pdf
### luu file
#convert_md uri=/path_to_file(pdf..) output=/output/path output=/path
#convert_md uri=https://d2l.ai/chapter_recurrent-neural-networks/index.html output=/path name=recurrent.md (or default name if without using name)