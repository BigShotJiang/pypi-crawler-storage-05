This package provides a flexible and pluggable authentication utility for Zope
3, using `zope.pluggableauth`. Several common plugins are provided.
