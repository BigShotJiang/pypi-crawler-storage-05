# r-irkernel

POC package for harmless beacon-only testing.
