# aiorexense

A Rexense device client library featuring an HTTP API for retrieving basic information and WebSocket-based status push functionality.

## Install
```bash
pip install aiorexense