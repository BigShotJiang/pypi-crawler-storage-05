#ifndef CASM_clexmonte_events_lotto
#define CASM_clexmonte_events_lotto

#include "casm/clexmonte/events/lotto/rejection.hpp"
#include "casm/clexmonte/events/lotto/rejection_free.hpp"

#endif
