#include "casm/clexmonte/nfold/nfold_impl.hh"

namespace CASM {
namespace clexmonte {
namespace nfold {

template struct Nfold<std::mt19937_64>;

}  // namespace nfold
}  // namespace clexmonte
}  // namespace CASM
