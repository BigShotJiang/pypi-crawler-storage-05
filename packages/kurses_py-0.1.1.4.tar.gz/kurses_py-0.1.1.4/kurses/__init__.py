from kurses.backend import VirtualTerminal
from kurses.stream import StreamBuffer
