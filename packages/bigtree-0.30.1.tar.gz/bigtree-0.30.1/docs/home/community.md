---
title: Community
---

# 🐾 Community
There are many ways to contribute to bigtree

* Give bigtree a 🌟 on [GitHub](https://github.com/kayjan/bigtree)
* [Share](https://github.com/kayjan/bigtree/discussions/52) your bigtree projects
* [Contribute](contributing.md) to bigtree open source libraries
* Support bigtree on [buymeacoffee](https://buymeacoffee.com/kayjan)
