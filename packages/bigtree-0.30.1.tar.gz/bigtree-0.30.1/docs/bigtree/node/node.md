---
title: Node
---

# 🌺 Node

::: bigtree.node.node
