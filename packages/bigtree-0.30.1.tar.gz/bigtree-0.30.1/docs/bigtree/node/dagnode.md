---
title: DAGNode
---

# 🌼 DAGNode

::: bigtree.node.dagnode
