---
title: Binary Tree Construct
---

# ✨ Construct

Construct Binary Tree from a list.

## Binary Tree Construct Methods

| Construct Binary Tree from | Using heapq structure | Add node attributes |
|----------------------------|-----------------------|---------------------|
| List                       | `list_to_binarytree`  | No                  |

-----

::: bigtree.binarytree.construct
