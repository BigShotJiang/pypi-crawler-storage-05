"""KeyMint Python SDK version information."""

__version__ = "2.0.0"
__author__ = "KeyMint"
__email__ = "admin@keymint.dev"
__url__ = "https://github.com/keymint-dev/keymint-python"
