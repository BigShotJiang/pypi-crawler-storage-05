""""""
"""by LTPLAX"""
"""version 0.3.2"""
"""Please use Tools.init before use"""
from .music import music
from .flush import flush
from .log import log
from .option import option
__all__=["music","flush","log","option"]

def init():
    print("LTPpyTools 0.1 Normal mode ready.")



