This is a python package for any python delelop 
init():init Tools  
----music----  
init():init music  
load():load file  
play():play .wav file  
stop():stop playing.  
---flush---  
flush():flush text  
