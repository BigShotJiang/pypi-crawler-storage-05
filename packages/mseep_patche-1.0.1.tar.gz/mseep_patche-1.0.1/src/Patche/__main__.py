from .app import app

app()
