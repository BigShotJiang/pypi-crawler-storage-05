from Patche.mcp import main

main()
