.. sidebar:: Key Contributors

    * `Yijun Liu`_: lead developer since 2022, maintainer
    * `Yuanhua Huang`_: lead developer since 2022, maintainer

.. _Yuanhua Huang: https://www.sbms.hku.hk/staff/yuanhua-huang

