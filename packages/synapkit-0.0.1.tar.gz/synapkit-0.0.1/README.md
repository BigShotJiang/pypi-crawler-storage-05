# synapkit

**Synapkit — a tiny, typed agent toolkit.**

This is a minimal placeholder release (`0.0.1`) to reserve the name on PyPI and give you a clean scaffold to start building.

## Install (once published)

```bash
pip install synapkit
```
