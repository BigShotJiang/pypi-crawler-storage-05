from dataclasses import dataclass


@dataclass
class Component:
    name: str
    version: str