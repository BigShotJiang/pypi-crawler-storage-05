"""Maniac post-training module - Dataset upload and training management"""

from .post_train import PostTrain

__all__ = ["PostTrain"]
