"""Entry point for running instamatte as a module."""

from instamatte.cli import cli_application

if __name__ == "__main__":
    cli_application()
