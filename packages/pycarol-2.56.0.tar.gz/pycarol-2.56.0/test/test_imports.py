
def test_luigi_extension():
    import pycarol.luigi_extension
    import pycarol.luigi_extension.targets
    from pycarol.luigi_extension.targets import PickleTarget
    from pycarol.luigi_extension.task import Task

