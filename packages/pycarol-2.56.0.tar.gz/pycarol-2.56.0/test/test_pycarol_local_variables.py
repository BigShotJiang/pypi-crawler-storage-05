import pycarol


def test_dunder_version():

    assert pycarol.__version__


def test_dunder_temp_storage():

    assert pycarol.__TEMP_STORAGE__

def test_dunder_connector_id():

    assert pycarol.__CONNECTOR_PYCAROL__



