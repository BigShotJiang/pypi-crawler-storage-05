"""
Database models for openedx_owly_apis.
"""
