def main():
    print("haveno-client CLI OK")