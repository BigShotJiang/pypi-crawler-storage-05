=====
Usage
=====

To use SEAMM Util in a project::

    import seamm_util
