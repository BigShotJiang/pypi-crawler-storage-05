kill %1
kill %2
kill %3
kill %4