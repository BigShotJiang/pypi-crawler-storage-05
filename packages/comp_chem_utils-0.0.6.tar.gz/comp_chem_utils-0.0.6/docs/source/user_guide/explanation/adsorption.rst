==================
Adsorption (WIP)
==================

This page will explain concepts related to adsorption

Adsorbate Complex (WIP)
===========================

TODO

Adsorption Site (WIP)
===========================

TODO

Adsorbate Orientations and Orientation Factories (WIP)
=======================================================

.. _site-space:

Site Space
----------

TODO

Site Finders (WIP)
==================

TODO

Displacers (WIP)
==================

TODO

Putting it all Together (WIP)
====================================

TODO
