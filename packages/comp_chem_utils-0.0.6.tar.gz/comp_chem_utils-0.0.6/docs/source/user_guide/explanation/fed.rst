=============================================
The Anatomy of a Free Energy Diagram (WIP)
=============================================

This page will describe the components of a free energy diagram
in `FancyPlots` and explain the underlying data model.

Data (WIP)
===========

TODO

Formatting (WIP)
======================

TODO

Annotations (WIP)
======================

TODO
