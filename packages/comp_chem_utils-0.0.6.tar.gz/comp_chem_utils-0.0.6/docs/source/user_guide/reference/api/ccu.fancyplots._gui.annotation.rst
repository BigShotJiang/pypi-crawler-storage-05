`ccu.fancyplots._gui.annotation`
================================

.. automodule:: ccu.fancyplots._gui.annotation
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
