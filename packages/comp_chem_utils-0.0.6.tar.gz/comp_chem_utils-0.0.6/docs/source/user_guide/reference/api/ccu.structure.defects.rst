`ccu.structure.defects`
=======================

.. automodule:: ccu.structure.defects
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
