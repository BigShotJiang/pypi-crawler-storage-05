`ccu.workflows.vibration`
=========================

.. automodule:: ccu.workflows.vibration
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
