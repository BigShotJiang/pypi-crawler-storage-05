`ccu.adsorption.adsorbates`
===========================

.. automodule:: ccu.adsorption.adsorbates
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
