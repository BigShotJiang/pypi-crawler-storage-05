`ccu.workflows.infrared`
========================

.. automodule:: ccu.workflows.infrared
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
