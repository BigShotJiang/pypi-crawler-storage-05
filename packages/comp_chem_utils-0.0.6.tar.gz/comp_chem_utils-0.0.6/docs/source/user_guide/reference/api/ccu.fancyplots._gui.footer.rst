`ccu.fancyplots._gui.footer`
============================

.. automodule:: ccu.fancyplots._gui.footer
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
