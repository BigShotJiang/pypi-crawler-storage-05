`ccu.fancyplots._gui.fed`
=========================

.. automodule:: ccu.fancyplots._gui.fed
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
