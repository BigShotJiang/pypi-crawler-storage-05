`ccu.fancyplots._gui.formatting`
================================

.. automodule:: ccu.fancyplots._gui.formatting
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
