`ccu.fancyplots._gui.utils`
===========================

.. automodule:: ccu.fancyplots._gui.utils
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
