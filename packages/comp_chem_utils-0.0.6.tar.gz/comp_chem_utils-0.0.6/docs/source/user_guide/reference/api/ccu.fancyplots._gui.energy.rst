`ccu.fancyplots._gui.energy`
============================

.. automodule:: ccu.fancyplots._gui.energy
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
