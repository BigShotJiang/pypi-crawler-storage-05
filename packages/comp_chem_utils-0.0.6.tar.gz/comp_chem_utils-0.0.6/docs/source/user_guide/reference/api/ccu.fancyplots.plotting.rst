`ccu.fancyplots.plotting`
=========================

.. automodule:: ccu.fancyplots.plotting
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
