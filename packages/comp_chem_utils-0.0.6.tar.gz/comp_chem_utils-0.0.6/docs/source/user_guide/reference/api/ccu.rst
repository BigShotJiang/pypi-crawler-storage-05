`ccu`
=====
.. automodule:: ccu
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 3

   ccu._cli
   ccu.adsorption
   ccu.fancyplots
   ccu.pop
   ccu.structure
   ccu.thermo
   ccu.workflows

Submodules
----------

.. toctree::
   :maxdepth: 1

   ccu.__about__
   ccu.__main__
