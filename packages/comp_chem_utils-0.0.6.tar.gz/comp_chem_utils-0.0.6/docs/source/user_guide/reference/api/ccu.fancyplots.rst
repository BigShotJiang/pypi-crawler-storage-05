`ccu.fancyplots`
================
.. automodule:: ccu.fancyplots
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 3

   ccu.fancyplots._gui

Submodules
----------

.. toctree::
   :maxdepth: 1

   ccu.fancyplots._cli
   ccu.fancyplots.data
   ccu.fancyplots.plotting
   ccu.fancyplots.styles
   ccu.fancyplots.validation
