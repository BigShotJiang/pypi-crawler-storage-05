`ccu.fancyplots.validation`
===========================

.. automodule:: ccu.fancyplots.validation
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
