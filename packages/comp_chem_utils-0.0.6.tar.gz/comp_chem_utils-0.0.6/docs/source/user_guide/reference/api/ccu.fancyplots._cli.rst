`ccu.fancyplots._cli`
=====================

.. automodule:: ccu.fancyplots._cli
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
