`ccu.structure.resizecell`
==========================

.. automodule:: ccu.structure.resizecell
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
