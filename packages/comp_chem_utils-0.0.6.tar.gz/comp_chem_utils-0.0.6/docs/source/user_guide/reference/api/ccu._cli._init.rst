`ccu._cli._init`
================

.. automodule:: ccu._cli._init
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
