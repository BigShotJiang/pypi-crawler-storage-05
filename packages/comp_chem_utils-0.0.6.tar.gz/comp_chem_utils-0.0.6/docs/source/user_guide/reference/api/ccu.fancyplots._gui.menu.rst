`ccu.fancyplots._gui.menu`
==========================

.. automodule:: ccu.fancyplots._gui.menu
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
