`ccu.fancyplots._gui.frames`
============================

.. automodule:: ccu.fancyplots._gui.frames
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
