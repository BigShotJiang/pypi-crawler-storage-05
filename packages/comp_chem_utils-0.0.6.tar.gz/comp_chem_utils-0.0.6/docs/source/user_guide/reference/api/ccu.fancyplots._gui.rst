`ccu.fancyplots._gui`
=====================
.. automodule:: ccu.fancyplots._gui
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 1

   ccu.fancyplots._gui.annotation
   ccu.fancyplots._gui.energy
   ccu.fancyplots._gui.fed
   ccu.fancyplots._gui.footer
   ccu.fancyplots._gui.formatting
   ccu.fancyplots._gui.frames
   ccu.fancyplots._gui.instructions
   ccu.fancyplots._gui.mechanism
   ccu.fancyplots._gui.menu
   ccu.fancyplots._gui.palette
   ccu.fancyplots._gui.root
   ccu.fancyplots._gui.tooltip
   ccu.fancyplots._gui.utils
