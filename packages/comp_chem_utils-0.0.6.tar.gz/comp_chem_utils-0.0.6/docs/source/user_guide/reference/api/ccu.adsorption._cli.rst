`ccu.adsorption._cli`
=====================

.. automodule:: ccu.adsorption._cli
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
