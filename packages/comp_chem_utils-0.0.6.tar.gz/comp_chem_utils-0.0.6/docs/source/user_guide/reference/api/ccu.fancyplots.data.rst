`ccu.fancyplots.data`
=====================

.. automodule:: ccu.fancyplots.data
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
