`ccu.fancyplots._gui.mechanism`
===============================

.. automodule:: ccu.fancyplots._gui.mechanism
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
