`ccu.structure._cli`
====================

.. automodule:: ccu.structure._cli
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
