`ccu.fancyplots._gui.palette`
=============================

.. automodule:: ccu.fancyplots._gui.palette
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
