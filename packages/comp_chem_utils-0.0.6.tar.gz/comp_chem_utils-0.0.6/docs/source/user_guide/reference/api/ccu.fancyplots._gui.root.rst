`ccu.fancyplots._gui.root`
==========================

.. automodule:: ccu.fancyplots._gui.root
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
