`ccu.fancyplots._gui.instructions`
==================================

.. automodule:: ccu.fancyplots._gui.instructions
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
