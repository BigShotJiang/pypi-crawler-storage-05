=================
Fancy Plots (WIP)
=================

This page will walk through the creation of free energy diagrams with the
`FancyPlots` GUI.
