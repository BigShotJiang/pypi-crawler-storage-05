=================
`ccu.fed` (WIP)
=================

This page will walk through the creation of free energy diagrams with the
Python API to :mod:`ccu.fancyplots`.
