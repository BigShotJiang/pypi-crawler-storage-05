===========
Get Started
===========

.. include:: ../../README.rst
   :start-after: .. start
   :end-before: .. end
