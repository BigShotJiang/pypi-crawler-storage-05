r"""Utilities for adsorption studies."""
