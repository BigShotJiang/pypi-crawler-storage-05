"""Utilities for computational catalysis."""

from ccu.settings import CCUSettings

#: The current :class:`~ccu.settings.CCUSettings`
SETTINGS = CCUSettings()
