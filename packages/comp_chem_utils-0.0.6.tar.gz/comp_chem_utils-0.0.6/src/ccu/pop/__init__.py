"""Utilities related to population analysis.

This includes the calculation of atomic charges, bond orders, and
charge density differences.
"""
