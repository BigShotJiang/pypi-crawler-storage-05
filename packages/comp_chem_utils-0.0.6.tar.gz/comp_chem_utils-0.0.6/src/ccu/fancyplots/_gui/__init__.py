"""An internal subpackage for the FancyPlots GUI."""
