"""
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the MIT License.
"""

from .router import get_router as conversations_router

__all__ = ["conversations_router"]
