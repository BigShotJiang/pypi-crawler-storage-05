class JSONSchemaValidationError(ValueError):
    """Raised when the completion does not match the specified schema."""
