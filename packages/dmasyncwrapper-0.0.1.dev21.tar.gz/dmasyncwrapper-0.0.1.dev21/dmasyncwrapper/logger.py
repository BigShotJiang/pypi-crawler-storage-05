# -*- coding: UTF-8 -*-

import logging

logger = logging.getLogger('dmasyncwrapper')
