from importlib.metadata import version

__version__ = version("natsext")

__all__ = ["__version__"]
