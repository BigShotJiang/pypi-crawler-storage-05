"""Widgets related to tomography reconstruction (cor search, nabu volume reconstruction...)"""
