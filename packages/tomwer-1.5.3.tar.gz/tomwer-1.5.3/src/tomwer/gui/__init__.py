"""This package contains all the widget which are not inheriting from
WidgetOW (orange widgets)
"""
