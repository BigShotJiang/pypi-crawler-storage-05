"""Different dialog used to select TomwerObject (like a scans - aka data or volumes)"""
