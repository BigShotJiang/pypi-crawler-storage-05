"""Widgets useful to debut a tomography workflow (generate random scan...)"""
