# coding: utf-8

DOC_TITLE = "doc_title"
SCAN_ID = "scan_ID"
FROM = "from"
TO = "to"
