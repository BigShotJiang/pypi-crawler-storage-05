from pycrm.label.function import LabellingFunction

__all__ = ["LabellingFunction"]
