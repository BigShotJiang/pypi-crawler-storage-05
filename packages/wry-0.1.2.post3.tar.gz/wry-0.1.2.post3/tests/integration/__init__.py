"""Integration tests for wry with Click framework."""
