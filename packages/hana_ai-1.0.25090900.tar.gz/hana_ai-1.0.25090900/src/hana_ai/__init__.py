"""
hana_ai is a Python package for AI/ML related utilities.
"""

__version__ = "1.0.25090900"
