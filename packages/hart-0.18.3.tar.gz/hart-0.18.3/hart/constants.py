DEBIAN_VERSIONS = {
    "bookworm": 12,
    "bullseye": 11,
    "buster": 10,
}
