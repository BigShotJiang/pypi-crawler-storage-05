class UserError(Exception):
    '''Raised when a user gives invalid instructions.'''
