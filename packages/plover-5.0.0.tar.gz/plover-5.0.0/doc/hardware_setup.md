# Hardware Setup

```{todo}
Complete this section.
```

## Standard Keyboards

```{todo}
Complete this section.
```

## Hobbyist Steno Writers

```{todo}
Complete this section.
```

## Student and Professional Steno Writers

```{todo}
Complete this section.
```
