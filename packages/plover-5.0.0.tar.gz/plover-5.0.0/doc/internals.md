# Plover Internals

```{toctree}
:maxdepth: 1

design
hardware_communication
platform_layer
```
