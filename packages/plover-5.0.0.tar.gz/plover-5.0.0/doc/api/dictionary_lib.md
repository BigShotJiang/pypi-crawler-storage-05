# `plover_python_dictionary_lib` -- Dictionary generation library

The `plover_python_dictionary_lib` library provides utilities for writing
Python programmatic dictionaries, as well as generating JSON dictionaries
from them.

```{note}
This library is a separate package from `plover`; note the underscore
in the name.
```

```{py:module} plover_python_dictionary_lib
```

% TODO
