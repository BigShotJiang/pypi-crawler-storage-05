# Basic Usage

```{todo}
Complete this section.
```

## Paper Tape

```{todo}
Complete this section.
```

## Lookup

```{todo}
Complete this section.
```

## Suggestions

```{todo}
Complete this section.
```
