# Dictionaries

```{todo}
Complete this section.
```

```{toctree}
:maxdepth: 2

add_translation
dict_editor
dict_formats
translation_language
```
