from plover.steno import Stroke


def steno_to_stroke(steno):
    return Stroke.from_steno(steno)
