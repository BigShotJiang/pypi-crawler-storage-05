def patch_ports_info(port_list):
    """NOP…"""
    return port_list
