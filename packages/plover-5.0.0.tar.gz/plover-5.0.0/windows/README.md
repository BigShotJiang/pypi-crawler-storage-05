# Windows Development

## Environment setup

Some of the development helpers rely on `bash` being available. You can use the
version provided by the official `git` installer.

See the [developer guide](../doc/developer_guide.md) for the rest of the steps.
