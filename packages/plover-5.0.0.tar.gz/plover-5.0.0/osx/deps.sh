py_installer_version="3.13.3"
py_installer_macos="11"
py_installer_sha1="2f3d458d3fdb74fc2df0f8b5ad81a04a366a3064"
reloc_py_url='https://github.com/gregneagle/relocatable-python/archive/8ee72fe3a5dbef733365370ebf44f25022b895ef.zip'
reloc_py_sha1='5ecbd252d11ef18ef0934dce46df13cc113f0671'
