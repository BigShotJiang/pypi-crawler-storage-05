==============
zope.errorview
==============

Provides basic HTTP and Browser views for common exceptions.

Refactored from `zope.app.http`_.exception and `zope.app.exception`_.

.. _`zope.app.http`: http://pypi.python.org/pypi/zope.app.http
.. _`zope.app.exception`: http://pypi.python.org/pypi/zope.app.exception
