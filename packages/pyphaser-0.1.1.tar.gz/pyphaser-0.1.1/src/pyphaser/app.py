def main():
    print('Running PyPhaser...')