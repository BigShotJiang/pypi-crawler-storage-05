import os
curr_dir = os.path.dirname(os.path.abspath(__file__))

health_config = os.path.join(curr_dir, 'health_config.yaml')
pyats_health_yaml = os.path.join(curr_dir, 'pyats_health.yaml')
