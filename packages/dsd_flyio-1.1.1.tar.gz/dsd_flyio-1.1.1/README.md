# dsd-flyio

A plugin for deploying Django projects to Fly.io, using django-simple-deploy.

For full documentation, see the documentation for [django-simple-deploy](https://django-simple-deploy.readthedocs.io/en/latest/).