"""Initialize the control module."""
