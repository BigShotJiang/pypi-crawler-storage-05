from .decimator import compute_error_map, generate_random_dem  # noqa: F401
