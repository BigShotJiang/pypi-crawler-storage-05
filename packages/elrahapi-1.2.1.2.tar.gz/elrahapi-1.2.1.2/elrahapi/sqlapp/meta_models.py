# from pydantic import BaseModel, Field

# class EntityBaseModel(BaseModel):
#     pass


# class EntityInEntity2Model(BaseModel):
#     pass
