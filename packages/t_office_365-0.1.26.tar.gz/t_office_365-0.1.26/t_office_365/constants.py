"""Constants."""

MS_GRAPH_BASE_URL: str = "https://graph.microsoft.com/v1.0"
FILE_CHUNK_SIZE: int = 10485760
