"""Top-level package for t_office_365/drive."""

__author__ = """Thoughtful"""
__email__ = "support@thoughtful.ai"
__version__ = "0.1.26"
