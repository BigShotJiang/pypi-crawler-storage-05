export const iam = [
    {
        label: "Commerçant",
        value: "merchant",
    },
    {
        label: "Demandeur d'emploi",
        value: "job_seeker",
    },
    {
        label: "En situation de handicap",
        value: "disabled_person",
    },
    {
        label: "Jeune",
        value: "young",
    },
    {
        label: "Journaliste",
        value: "journalist",
    },
    {
        label: "Nouvel arrivant",
        value: "newcomer",
    },
    {
        label: "Organisateur d'événement",
        value: "event_planner",
    },
    {
        label: "Parent",
        value: "parent",
    },
    {
        label: "Senior",
        value: "elder",
    },
    {
        label: "Touriste",
        value: "tourist",
    },
];
