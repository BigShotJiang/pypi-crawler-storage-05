# Run this file to trigger a model download
import openhands.agenthub  # noqa F401 (we import this to get the agents registered)
