"""Version information for pyzxing package."""

__version__ = "1.1.1"

# For backward compatibility
VERSION = __version__