from discord_self._vendor.discord.interactions import Interaction

__all__ = ["Interaction"]
