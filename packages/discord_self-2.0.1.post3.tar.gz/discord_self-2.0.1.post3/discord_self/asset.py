from discord_self._vendor.discord.asset import Asset

__all__ = ["Asset"]
