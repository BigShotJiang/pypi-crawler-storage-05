from discord_self._vendor.discord.affinity import GuildAffinity, UserAffinity

__all__ = ["GuildAffinity", "UserAffinity"]
