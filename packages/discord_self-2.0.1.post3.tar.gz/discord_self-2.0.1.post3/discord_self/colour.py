from discord_self._vendor.discord.colour import Color, Colour

__all__ = ["Color", "Colour"]
