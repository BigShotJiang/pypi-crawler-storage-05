from discord_self._vendor.discord.partial_emoji import PartialEmoji

__all__ = ["PartialEmoji"]
