from discord_self._vendor.discord.opus import Encoder, OpusError, OpusNotLoaded

__all__ = ["Encoder", "OpusError", "OpusNotLoaded"]
