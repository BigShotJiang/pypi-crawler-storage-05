from discord_self._vendor.discord.voice_client import VoiceClient, VoiceProtocol

__all__ = ["VoiceClient", "VoiceProtocol"]
