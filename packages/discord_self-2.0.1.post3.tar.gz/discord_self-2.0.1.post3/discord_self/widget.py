from discord_self._vendor.discord.widget import Widget, WidgetChannel, WidgetMember

__all__ = ["Widget", "WidgetChannel", "WidgetMember"]
