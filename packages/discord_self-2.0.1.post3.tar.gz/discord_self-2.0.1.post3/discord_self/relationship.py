from discord_self._vendor.discord.relationship import Relationship

__all__ = ["Relationship"]
