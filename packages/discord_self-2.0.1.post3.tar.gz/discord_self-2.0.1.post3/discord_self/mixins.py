from discord_self._vendor.discord.mixins import EqualityComparable, Hashable

__all__ = ["EqualityComparable", "Hashable"]
