from discord_self._vendor.discord.file import File

__all__ = ["File"]
