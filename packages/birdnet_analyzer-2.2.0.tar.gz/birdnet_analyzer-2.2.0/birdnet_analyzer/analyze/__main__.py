from birdnet_analyzer.analyze.cli import main

main()
