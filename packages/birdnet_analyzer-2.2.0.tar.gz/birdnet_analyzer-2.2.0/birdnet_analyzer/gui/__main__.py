from birdnet_analyzer.gui import main

main()
