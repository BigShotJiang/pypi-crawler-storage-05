#__all__ = ['manman']
from .procman import __version__, Window

