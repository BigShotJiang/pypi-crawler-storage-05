## 16.0.2.0.0 (2023-06-29)

> - Biblioteca PyCEP-Correios foi renomeada para BrazilCEP.

## 16.0.1.0.0 (2022-10-25)

> - Migração para 16.0

## 15.0.1.0.0 (2022-10-25)

> - Migração para 15.0

## 14.0.1.0.0 (2022-10-25)

> - Migração para 14.0

## 12.0.3.0.0 (2021-01-08)

> - Atualizada a biblioteca pycep-correios para a versão 5.0.0
> - \[ADD\] Adicionado a opção para selecionar o provedor do serviço de
>   busca de CEP.

## 12.0.2.0.0 (2019-06-17)

> - \[REF\] Incluida pesquisa e dependência da biblioteca
>   PyCEP-Correios.
