from . import test_l10n_br_zip_res_company
from . import test_l10n_br_zip_res_partner
