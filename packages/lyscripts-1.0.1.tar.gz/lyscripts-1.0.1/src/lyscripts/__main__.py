"""Utility for common tasks w.r.t. inference & prediction using `lymph` package."""

from lyscripts import main

if __name__ == "__main__":
    main()
