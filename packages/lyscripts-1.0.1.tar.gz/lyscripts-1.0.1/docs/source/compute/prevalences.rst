.. currentmodule:: lyscripts.compute.prevalences

Predict Prevalence of Involvement
=================================

.. automodule:: lyscripts.compute.prevalences
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts compute prevalences --help
