.. currentmodule:: lyscripts.compute.posteriors

Posterior State Distributions
=============================

.. automodule:: lyscripts.compute.posteriors
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts compute posteriors --help
