.. currentmodule:: lyscripts.compute.priors

Prior State Distributions
=========================

.. automodule:: lyscripts.compute.priors
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts compute priors --help
