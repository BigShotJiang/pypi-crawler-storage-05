.. currentmodule:: lyscripts.compute.risks

Compute Risk of Involvement
===========================

.. automodule:: lyscripts.compute.risks
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts compute risks --help
