.. currentmodule:: lyscripts.sample

MCMC Sampling
=============

.. automodule:: lyscripts.sample
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts sample --help
