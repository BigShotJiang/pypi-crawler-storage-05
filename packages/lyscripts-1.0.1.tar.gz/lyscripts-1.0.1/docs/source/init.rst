.. currentmodule:: lyscripts

Main Lyscripts CLI
==================

.. automodule:: lyscripts
    :members:

Command Help
------------

.. program-output:: lyscripts --help
