.. currentmodule:: lyscripts.evaluate

Evaluation
==========

.. automodule:: lyscripts.evaluate
    :members:
    :show-inheritance:

Command Help
------------

..
    .. program-output:: lyscripts evaluate --help
