.. currentmodule:: lyscripts.data.lyproxify

Map to LyProX Format
====================

.. automodule:: lyscripts.data.lyproxify
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts data lyproxify --help
