.. currentmodule:: lyscripts.data.collect

Collect lyDATA Tables Interactively
===================================

.. automodule:: lyscripts.data.collect
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts data collect --help
