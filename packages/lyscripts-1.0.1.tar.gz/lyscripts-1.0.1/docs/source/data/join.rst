.. currentmodule:: lyscripts.data.join

Join Data Files
===============

.. automodule:: lyscripts.data.join
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts data join --help
