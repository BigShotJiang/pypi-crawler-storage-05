.. currentmodule:: lyscripts.data.split

Split Data
==========

.. automodule:: lyscripts.data.split
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts data split --help
