.. currentmodule:: lyscripts.data.filter

Filtering Datasets
==================

.. automodule:: lyscripts.data.filter
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts data filter --help
