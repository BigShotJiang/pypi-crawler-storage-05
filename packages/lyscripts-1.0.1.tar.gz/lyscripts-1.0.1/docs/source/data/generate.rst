.. currentmodule:: lyscripts.data.generate

Generating Synthetic Data
=========================

.. automodule:: lyscripts.data.generate
    :members:
    :show-inheritance:

Command Help
------------

.. program-output:: lyscripts data generate --help
