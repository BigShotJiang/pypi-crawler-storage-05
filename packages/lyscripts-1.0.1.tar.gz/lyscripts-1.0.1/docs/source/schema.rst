.. currentmodule:: lyscripts.schema

JSON Schema
===========

.. automodule:: lyscripts.schema
    :members:
