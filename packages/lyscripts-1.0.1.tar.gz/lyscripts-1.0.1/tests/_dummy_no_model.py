"""File that does not provide a `model`."""

no_model = 42
