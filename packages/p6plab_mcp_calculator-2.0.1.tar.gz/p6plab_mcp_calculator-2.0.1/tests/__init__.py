"""Test suite for Scientific Calculator MCP Server."""
