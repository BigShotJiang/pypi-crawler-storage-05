"""Pydantic data models for request/response validation."""
