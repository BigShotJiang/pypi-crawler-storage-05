"""Base service implementation."""

# Re-export the base service from core.base
from calculator.core.base.service import BaseService

__all__ = ["BaseService"]
