STEPS = ["mkgtf", "mapping_vdj"]
__ASSAY__ = "utils"
