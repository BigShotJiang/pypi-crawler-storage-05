STEPS = [
    "mkref",
    "sample",
    "barcode",
    "cutadapt",
    "star_fusion",
    "count_fusion",
    "filter_fusion",
    "analysis_fusion",
]
__ASSAY__ = "fusion"
