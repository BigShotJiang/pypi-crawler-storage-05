# constants

# colnames in df_tsne (UMI sum of all features)
SUM_UMI_COLNAME = "sum_UMI"
LOG2_COLNAME = SUM_UMI_COLNAME + "_log2"
