from celescope.tools.multi import Multi


class Multi_hla(Multi):
    pass


def main():
    # TODO
    pass


if __name__ == "__main__":
    main()
