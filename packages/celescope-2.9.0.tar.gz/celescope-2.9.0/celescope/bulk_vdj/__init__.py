STEPS = [
    "mkref",
    "sample",
    "barcode",
    "consensus",
    "mapping_vdj",
]
__ASSAY__ = "bulk_vdj"

IMPORT_DICT = {
    "mkref": "celescope.vdj",
}
