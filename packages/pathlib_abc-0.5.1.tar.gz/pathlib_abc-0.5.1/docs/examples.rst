Examples
========

ZipPath
-------

.. literalinclude:: examples/zippath.py
