.. include:: ../README.rst

Contents
--------

.. toctree::
    examples
    api
    changes
    license
