License
=======

PSF LICENSE AGREEMENT
---------------------

.. literalinclude:: ../LICENSE.txt
    :language: text
