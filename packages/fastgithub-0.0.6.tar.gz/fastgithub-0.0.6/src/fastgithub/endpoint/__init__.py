"""A package that handles FastAPI endpoints and routers."""

from .webhook_router import webhook_router
