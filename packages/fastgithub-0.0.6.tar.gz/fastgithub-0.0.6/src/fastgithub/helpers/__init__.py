"""A package to help the handling of recipes."""
