"""A package that handles hook operations."""

from ._base import GithubRecipe, Recipe
