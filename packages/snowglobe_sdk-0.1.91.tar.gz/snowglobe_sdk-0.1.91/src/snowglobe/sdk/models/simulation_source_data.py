from collections.abc import Mapping
from typing import Any, TypeVar, TYPE_CHECKING

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from typing import Union

if TYPE_CHECKING:
    from ..models.simulation_source_data_evaluation_configuration import (
        SimulationSourceDataEvaluationConfiguration,
    )
    from ..models.simulation_source_data_autofix_configuration import (
        SimulationSourceDataAutofixConfiguration,
    )
    from ..models.simulation_source_data_generation_configuration import (
        SimulationSourceDataGenerationConfiguration,
    )
    from ..models.simulation_source_data_docs import SimulationSourceDataDocs
    from ..models.simulation_source_data_schedule import SimulationSourceDataSchedule
    from ..models.simulation_source_data_persona_topics_item import (
        SimulationSourceDataPersonaTopicsItem,
    )


T = TypeVar("T", bound="SimulationSourceData")


@_attrs_define
class SimulationSourceData:
    """
    Attributes:
        docs (SimulationSourceDataDocs):
        generation_configuration (SimulationSourceDataGenerationConfiguration):
        personas (Union[Unset, list[str]]):
        topics (Union[Unset, list[str]]):
        evaluation_configuration (Union[Unset, SimulationSourceDataEvaluationConfiguration]):
        persona_topics (Union[Unset, list['SimulationSourceDataPersonaTopicsItem']]):
        schedule (Union[Unset, SimulationSourceDataSchedule]):
        autofix_configuration (Union[Unset, SimulationSourceDataAutofixConfiguration]):
    """

    docs: "SimulationSourceDataDocs"
    generation_configuration: "SimulationSourceDataGenerationConfiguration"
    personas: Union[Unset, list[str]] = UNSET
    topics: Union[Unset, list[str]] = UNSET
    evaluation_configuration: Union[
        Unset, "SimulationSourceDataEvaluationConfiguration"
    ] = UNSET
    persona_topics: Union[Unset, list["SimulationSourceDataPersonaTopicsItem"]] = UNSET
    schedule: Union[Unset, "SimulationSourceDataSchedule"] = UNSET
    autofix_configuration: Union[Unset, "SimulationSourceDataAutofixConfiguration"] = (
        UNSET
    )
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        docs = self.docs.to_dict()

        generation_configuration = self.generation_configuration.to_dict()

        personas: Union[Unset, list[str]] = UNSET
        if not isinstance(self.personas, Unset):
            personas = self.personas

        topics: Union[Unset, list[str]] = UNSET
        if not isinstance(self.topics, Unset):
            topics = self.topics

        evaluation_configuration: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.evaluation_configuration, Unset):
            evaluation_configuration = self.evaluation_configuration.to_dict()

        persona_topics: Union[Unset, list[dict[str, Any]]] = UNSET
        if not isinstance(self.persona_topics, Unset):
            persona_topics = []
            for persona_topics_item_data in self.persona_topics:
                persona_topics_item = persona_topics_item_data.to_dict()
                persona_topics.append(persona_topics_item)

        schedule: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.schedule, Unset):
            schedule = self.schedule.to_dict()

        autofix_configuration: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.autofix_configuration, Unset):
            autofix_configuration = self.autofix_configuration.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "docs": docs,
                "generation_configuration": generation_configuration,
            }
        )
        if personas is not UNSET:
            field_dict["personas"] = personas
        if topics is not UNSET:
            field_dict["topics"] = topics
        if evaluation_configuration is not UNSET:
            field_dict["evaluation_configuration"] = evaluation_configuration
        if persona_topics is not UNSET:
            field_dict["persona_topics"] = persona_topics
        if schedule is not UNSET:
            field_dict["schedule"] = schedule
        if autofix_configuration is not UNSET:
            field_dict["autofix_configuration"] = autofix_configuration

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.simulation_source_data_evaluation_configuration import (
            SimulationSourceDataEvaluationConfiguration,
        )
        from ..models.simulation_source_data_autofix_configuration import (
            SimulationSourceDataAutofixConfiguration,
        )
        from ..models.simulation_source_data_generation_configuration import (
            SimulationSourceDataGenerationConfiguration,
        )
        from ..models.simulation_source_data_docs import SimulationSourceDataDocs
        from ..models.simulation_source_data_schedule import (
            SimulationSourceDataSchedule,
        )
        from ..models.simulation_source_data_persona_topics_item import (
            SimulationSourceDataPersonaTopicsItem,
        )

        d = dict(src_dict)
        docs = SimulationSourceDataDocs.from_dict(d.pop("docs"))

        generation_configuration = (
            SimulationSourceDataGenerationConfiguration.from_dict(
                d.pop("generation_configuration")
            )
        )

        personas = cast(list[str], d.pop("personas", UNSET))

        topics = cast(list[str], d.pop("topics", UNSET))

        _evaluation_configuration = d.pop("evaluation_configuration", UNSET)
        evaluation_configuration: Union[
            Unset, SimulationSourceDataEvaluationConfiguration
        ]
        if isinstance(_evaluation_configuration, Unset):
            evaluation_configuration = UNSET
        else:
            evaluation_configuration = (
                SimulationSourceDataEvaluationConfiguration.from_dict(
                    _evaluation_configuration
                )
            )

        persona_topics = []
        _persona_topics = d.pop("persona_topics", UNSET)
        for persona_topics_item_data in _persona_topics or []:
            persona_topics_item = SimulationSourceDataPersonaTopicsItem.from_dict(
                persona_topics_item_data
            )

            persona_topics.append(persona_topics_item)

        _schedule = d.pop("schedule", UNSET)
        schedule: Union[Unset, SimulationSourceDataSchedule]
        if isinstance(_schedule, Unset):
            schedule = UNSET
        else:
            schedule = SimulationSourceDataSchedule.from_dict(_schedule)

        _autofix_configuration = d.pop("autofix_configuration", UNSET)
        autofix_configuration: Union[Unset, SimulationSourceDataAutofixConfiguration]
        if isinstance(_autofix_configuration, Unset):
            autofix_configuration = UNSET
        else:
            autofix_configuration = SimulationSourceDataAutofixConfiguration.from_dict(
                _autofix_configuration
            )

        simulation_source_data = cls(
            docs=docs,
            generation_configuration=generation_configuration,
            personas=personas,
            topics=topics,
            evaluation_configuration=evaluation_configuration,
            persona_topics=persona_topics,
            schedule=schedule,
            autofix_configuration=autofix_configuration,
        )

        simulation_source_data.additional_properties = d
        return simulation_source_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
