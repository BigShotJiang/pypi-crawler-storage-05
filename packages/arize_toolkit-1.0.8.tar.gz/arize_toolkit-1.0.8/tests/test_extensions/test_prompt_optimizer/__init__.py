"""Test package for prompt learning extension."""
