from .main import SegmentationGUI

__all__ = ["SegmentationGUI"]
