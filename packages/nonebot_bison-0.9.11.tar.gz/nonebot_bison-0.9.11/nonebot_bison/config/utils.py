class NoSuchUserException(Exception):
    pass


class NoSuchSubscribeException(Exception):
    pass


class NoSuchTargetException(Exception):
    pass


class DuplicateCookieTargetException(Exception):
    pass
