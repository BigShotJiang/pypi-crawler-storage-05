from .platform import CeobeCanteen as CeobeCanteen
