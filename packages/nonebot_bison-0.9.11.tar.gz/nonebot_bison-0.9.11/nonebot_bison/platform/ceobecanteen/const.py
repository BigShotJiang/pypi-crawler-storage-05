DATASOURCE_URL = "https://server.ceobecanteen.top/api/v1/canteen/config/datasource/list"
COMB_ID_URL = "https://server.ceobecanteen.top/api/v1/canteen/user/getDatasourceComb"
COOKIE_ID_URL = "https://cdn.ceobecanteen.top/datasource-comb"
COOKIES_URL = "https://server-cdn.ceobecanteen.top/api/v1/cdn/cookie/mainList/cookieList"
