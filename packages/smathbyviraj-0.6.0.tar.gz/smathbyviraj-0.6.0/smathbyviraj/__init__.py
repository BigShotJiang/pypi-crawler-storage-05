from .smathbyvirajcode import divby, fctrl, fbnci, xnrt, euler_totient, baseconv, vedicmath

__version__ = '0.6.0'

def hello():
    return f'Welcome to smathbyviraj v{__version__}'
