def main() -> None:
    print("Hello from pydicomrt!")
