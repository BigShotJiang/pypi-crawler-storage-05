## Response Types

Data models and types for API responses.

::: any_llm.types.responses
