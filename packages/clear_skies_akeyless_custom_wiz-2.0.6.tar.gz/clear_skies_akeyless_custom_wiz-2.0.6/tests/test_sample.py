import unittest


class TestSample(unittest.TestCase):
    """Simple test_sample."""

    def test_sample(self) -> None:
        """Simple test to test."""
        assert 1 + 1 == 2
