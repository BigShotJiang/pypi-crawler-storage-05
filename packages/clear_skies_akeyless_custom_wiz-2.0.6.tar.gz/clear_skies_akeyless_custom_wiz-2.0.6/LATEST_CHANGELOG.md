## [2.0.6] - 2025-09-08

### Added
- Add template

### Changed
- Update copier
- Update to v0.0.24
- Merge pull request #1 from clearskies-akeyless-custom-producers/copier by @tnijboer in [#1](https://github.com/clearskies-akeyless-custom-producers/wiz/pull/1)
- Transcription error by @cmancone
- Transcription error by @cmancone
- Missing import by @cmancone
- Testing by @cmancone
- Bugfix by @cmancone
- First version by @cmancone
- Initial commit by @cmancone

## New Contributors
* @ made their first contribution
* @tnijboer made their first contribution in [#1](https://github.com/clearskies-akeyless-custom-producers/wiz/pull/1)
* @cmancone made their first contribution
