"""Tests for math operations mixin."""
