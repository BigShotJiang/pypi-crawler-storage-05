"""Tests for UtilityMixin."""
