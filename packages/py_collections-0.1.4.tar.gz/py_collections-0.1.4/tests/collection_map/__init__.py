"""Tests for CollectionMap."""
