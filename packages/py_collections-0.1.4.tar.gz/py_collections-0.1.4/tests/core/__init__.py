"""Tests for core Collection functionality."""
