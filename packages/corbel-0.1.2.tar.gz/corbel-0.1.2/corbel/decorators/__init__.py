from __future__ import annotations

from ._property import corbel_property


__all__ = ("corbel_property",)
