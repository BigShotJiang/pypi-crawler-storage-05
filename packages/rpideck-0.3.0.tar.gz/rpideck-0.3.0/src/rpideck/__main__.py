# SPDX-FileCopyrightText: Daniel Skowroński <daniel@skowron.ski>
#
# SPDX-License-Identifier: MIT
import sys

if __name__ == "__main__":
    from rpideck.cli import rpideck

    sys.exit(rpideck())
