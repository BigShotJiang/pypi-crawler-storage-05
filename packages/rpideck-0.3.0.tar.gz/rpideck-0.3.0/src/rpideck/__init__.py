# SPDX-FileCopyrightText: Daniel Skowroński <daniel@skowron.ski>
#
# SPDX-License-Identifier: MIT
