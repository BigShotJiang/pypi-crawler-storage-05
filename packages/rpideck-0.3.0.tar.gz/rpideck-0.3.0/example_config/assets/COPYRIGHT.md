<a target="_blank" href="https://icons8.com/icon/ofWDphz4az7r/mac-studio">Mac Studio</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/7oneoROZtZWa/mac-studio">Mac Studio</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/2784/briefcase">Briefcase</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/482/briefcase">Briefcase</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/10342/hdmi-cable">HDMI Cable</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/uI4k7cPiwxCJ/power-off-button">Power</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/10861/apple-tv">Apple TV</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/10330/rca">RCA</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/12519/playstation">Playstation</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/XaIQdSh4y3F9/nintendo-switch-logo">Nintendo Switch Logo</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/6989/toslink">Toslink</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>
<a target="_blank" href="https://icons8.com/icon/9Oy5N3CNV3Y1/apple-arcade">Game</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>