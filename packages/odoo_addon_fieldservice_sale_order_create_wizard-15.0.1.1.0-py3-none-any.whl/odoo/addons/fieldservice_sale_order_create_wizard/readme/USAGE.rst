* Go to Field Service
* Click on the **Create Sale Order** button
* A wizard will appear allowing you to select the customer and the sale order lines
* Click on **Create**.
* Now it will create a new sales order, with the customer and fsm location set, and the sale order lines will be added to the order.
* It will be confirmed automatically, and the fsm order will be generated.
