 `APSL-Nagarro <https://www.apsl.tech>`_:
  * Bernat Obrador <bobrador@apsl.net>
