This module extends the functionality of the Field Service, by allowing users to create sale orders directly from the field service Kanban View.
This is especially useful for companies that generate sales orders directly on-site, enabling them to convert service tasks into sales documents seamlessly within the Field Service interface.

**Important**: 
This module gives to the user and user own documents groups, the posibility to create field service orders and sale orders.
It will force the schedule of all the routes, bypassing the day validation.
