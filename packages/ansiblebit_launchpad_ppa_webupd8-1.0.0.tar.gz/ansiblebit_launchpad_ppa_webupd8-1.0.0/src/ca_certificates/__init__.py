__version__ = "1.0.0"

def info():
    return "This is a dummy ansiblebit.launchpad-ppa-webupd8 package for PyPI."
