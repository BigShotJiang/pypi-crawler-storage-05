"""Version information."""

__version__ = "1.2.2"
