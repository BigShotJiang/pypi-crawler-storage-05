app_name = "logger"

urlpatterns = [
    # Add your URL patterns here
]
