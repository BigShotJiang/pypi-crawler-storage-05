Account overview
==================

This is the account overview page:

.. image:: https://github.com/FlexMeasures/screenshots/raw/main/screenshot_account.png
    :align: center
..    :scale: 40%

|
|

This is the current User overview page:

.. image:: https://github.com/FlexMeasures/screenshots/raw/main/screenshot-user-overview.png
    :align: center
..    :scale: 40%

|
|

This is the account audit log page:

.. image:: https://github.com/FlexMeasures/screenshots/raw/main/screenshot-account-auditlog.PNG
    :align: center
..    :scale: 40%
