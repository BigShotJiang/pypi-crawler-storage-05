.. _get_in_touch:

Get in touch
=============

We want you to succeed in using, hosting or extending FlexMeasures. For all your questions and ideas, you can join the FlexMeasures community in the following ways:

- View the code and/or create a ticket on `GitHub <https://github.com/FlexMeasures/flexmeasures>`_
- Join the ``#flexmeasures`` Slack channel over at `https://lfenergy.slack.com <https://lfenergy.slack.com>`_
- Write to us at `flexmeasures@lists.lfenergy.org <flexmeasures@lists.lfenergy.org>`_ (you can join this mailing list `here <https://lists.lfenergy.org/g/flexmeasures>`_)
- Follow `@flexmeasures <https://twitter.com/flexmeasures>`_ on Twitter

We'd love to hear from you!