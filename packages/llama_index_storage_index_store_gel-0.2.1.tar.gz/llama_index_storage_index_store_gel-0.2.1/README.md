# LlamaIndex Index_Store Integration: Gel
