# Change Summary


| Section                   | Changes                             |
| ------------------------- | ----------------------------------- |
| [Layout](#layout-changes) | {{ diff_report.layout_updates() }}  |
| Section                   | {{ diff_report.section_updates() }} |
| Visual                    | {{ diff_report.visual_updates()  }} |
| [SSAS](#ssas-changes)     | {{ diff_report.ssas_changes         | length }} |
