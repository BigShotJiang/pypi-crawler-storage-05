from .main import diff

__all__ = ["diff"]
__version__ = "0.5.1"
