from .models import WebfingerResult
from .models import Resource as WebfingerResource
from .models import Link as WebfingerLink

__all__ = [
    "WebfingerResult",
    "WebfingerResource",
    "WebfingerLink"
]