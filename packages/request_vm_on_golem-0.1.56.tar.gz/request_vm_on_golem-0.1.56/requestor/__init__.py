"""
VM on Golem Requestor Node

A simple CLI tool for managing VMs on the Golem Network.
"""

__version__ = "0.1.0"
