#!/bin/python
# -*- coding: utf-8 -*-
"""
__main__.py

Author: GrimAndGreedy
License: MIT
"""

from aria2tui.aria2tui_app import aria2tui as main

if __name__ == "__main__":
    main()
