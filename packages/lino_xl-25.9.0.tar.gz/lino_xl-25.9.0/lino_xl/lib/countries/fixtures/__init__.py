"""The fixtures for `lino_xl.lib.countries`.

.. autosummary::
   :toctree:

    all_countries
    be
    eesti
    few_countries
    few_cities

"""
