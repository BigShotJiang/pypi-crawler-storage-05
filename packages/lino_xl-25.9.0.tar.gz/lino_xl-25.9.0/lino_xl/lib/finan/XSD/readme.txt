
CustomerCreditTransferInitiation

- `pain.001.001.02.xsd`
  downloaded from http://wiki.xmldation.com/General_Information/ISO_20022/pain.001

- `pain.001.001.05.xsd`   
  downloaded from 
  http://www.iso20022.org/payments_messages.page  20130718
