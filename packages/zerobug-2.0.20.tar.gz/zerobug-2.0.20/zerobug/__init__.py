# -*- coding: utf-8 -*-
from . import scripts
from . import _travis
from . import z0testlib
from .scripts.main import internal_main

z0test = z0testlib.Z0test()
z0testodoo = z0testlib.Z0testOdoo()
