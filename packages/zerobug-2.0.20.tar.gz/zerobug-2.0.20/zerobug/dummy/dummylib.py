# -*- coding: utf-8 -*-
# dummylib
# Used to test searching library path in zerobug unit test

dummy_version = '1.2.3.4'
