* Autodiscovery test modules and functions
* Python 2.7+ and 3.5+
* coverage integration
* travis-ci integration
