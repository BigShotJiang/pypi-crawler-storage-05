::

    $(zerobug -h)
