# morethon
Interpreter for morethon language.

## Installation
```sh
$ pip install morethon
```

## Requirements
```txt

```

## See Also
### Github repository
* https://github.com/Chitaoji/morethon/

### PyPI project
* https://pypi.org/project/morethon/

## License
This project falls under the BSD 3-Clause License.

## History
### v0.0.0
* Initial release.