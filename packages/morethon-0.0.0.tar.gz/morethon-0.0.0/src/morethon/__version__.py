"""Version file."""
VERSION = (0, 0, 0)

__version__ = ".".join(map(str, VERSION))
