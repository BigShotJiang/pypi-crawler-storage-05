from .test_cython import invoke_main_entry_point

invoke_main_entry_point()
