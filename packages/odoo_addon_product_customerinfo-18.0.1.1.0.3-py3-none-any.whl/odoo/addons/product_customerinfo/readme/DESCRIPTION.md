This module allows to use supplier info structure, available in
*Purchase* tab of the product form, also for defining customer
information, allowing to define prices per customer and product.
