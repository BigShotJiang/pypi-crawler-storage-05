project = "lakers-python"
copyright = "see project web page"

extensions = [
    "sphinx.ext.autodoc",
]
