This crate is part of [lakers], a microcontroller-optimized implementation of EDHOC in Rust.

[lakers]: https://crates.io/crates/lakers
