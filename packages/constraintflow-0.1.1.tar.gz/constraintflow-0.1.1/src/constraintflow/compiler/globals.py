debug_flag1 = False 

def set_debug_flag1():
    global debug_flag1
    debug_flag1 = True

def reset_debug_flag1():
    global debug_flag1
    debug_flag1 = False

def get_debug_flag1():
    global debug_flag1
    return debug_flag1