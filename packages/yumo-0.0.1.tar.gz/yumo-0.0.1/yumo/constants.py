CMAPS = ("rainbow", "viridis", "coolwarm", "jet", "turbo", "magma")
DENOISE_METHODS = ("nearest_and_gaussian", "nearest", "gaussian")
