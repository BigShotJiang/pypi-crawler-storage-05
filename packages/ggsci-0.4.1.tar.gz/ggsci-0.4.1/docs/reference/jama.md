# JAMA

::: ggsci.palettes
    options:
      members:
        - pal_jama
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_jama
        - scale_colour_jama
        - scale_fill_jama
      show_root_heading: true
      show_source: false
