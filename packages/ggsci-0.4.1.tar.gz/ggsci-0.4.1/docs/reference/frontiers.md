# Frontiers

::: ggsci.palettes
    options:
      members:
        - pal_frontiers
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_frontiers
        - scale_colour_frontiers
        - scale_fill_frontiers
      show_root_heading: true
      show_source: false
