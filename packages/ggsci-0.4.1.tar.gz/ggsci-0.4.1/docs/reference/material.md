# Material

::: ggsci.palettes
    options:
      members:
        - pal_material
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_material
        - scale_colour_material
        - scale_fill_material
      show_root_heading: true
      show_source: false
