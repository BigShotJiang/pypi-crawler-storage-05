# Lancet

::: ggsci.palettes
    options:
      members:
        - pal_lancet
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_lancet
        - scale_colour_lancet
        - scale_fill_lancet
      show_root_heading: true
      show_source: false
