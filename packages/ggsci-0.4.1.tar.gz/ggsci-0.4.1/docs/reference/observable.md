# Observable

::: ggsci.palettes
    options:
      members:
        - pal_observable
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_observable
        - scale_colour_observable
        - scale_fill_observable
      show_root_heading: true
      show_source: false
