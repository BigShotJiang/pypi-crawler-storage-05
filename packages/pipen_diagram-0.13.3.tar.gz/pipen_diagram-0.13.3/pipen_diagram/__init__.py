"""A plugin for pipen to draw pipeline diagrams"""

from .entry import PipenDiagram

__version__ = "0.13.3"

PipenDiagram.__version__ = __version__
