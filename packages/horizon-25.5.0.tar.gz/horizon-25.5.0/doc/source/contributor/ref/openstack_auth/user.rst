===============
The User Module
===============

.. automodule:: openstack_auth.user
   :members:
