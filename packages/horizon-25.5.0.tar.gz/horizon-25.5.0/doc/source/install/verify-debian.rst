===========================
Verify operation for Debian
===========================

Verify operation of the dashboard.

Access the dashboard using a web browser at
``http://controller/horizon/``.

Authenticate using ``admin`` or ``demo`` user
and ``default`` domain credentials.
