#
# PROGRAM: CONJUNO
# VERSION: 08/2022
# MODULE : __init__
#
from ._version import __version__  # noqa
