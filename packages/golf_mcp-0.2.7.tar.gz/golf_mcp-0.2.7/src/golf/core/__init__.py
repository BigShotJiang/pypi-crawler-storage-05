"""Core functionality for the GolfMCP framework."""
