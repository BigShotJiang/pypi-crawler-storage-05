from importlib.metadata import version

VERSION = version("external-resources")  # this must be pyproject.toml's project name
__version__ = VERSION
