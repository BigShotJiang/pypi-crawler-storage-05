from vecorel_cli.cli.setup import setup_cli

run = setup_cli()
