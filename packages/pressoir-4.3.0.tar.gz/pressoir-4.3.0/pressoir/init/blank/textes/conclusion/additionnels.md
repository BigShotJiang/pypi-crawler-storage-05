## idCA1

---
title: >-
   Séminaire IMPEC 2019 - Hélène BEAUCHEF et Servanne MONJOUR - Les Ateliers de [sens public]
credits: >-
   Laboratoire ICAR
keywords: séminaire,IMPEC,Hélène Beauchef,Servanne Monjour,
lang: fr
type: video
link: https://youtu.be/TvlxJshxLVc?si=L3w_GIWdJEcQYL6Q
link-archive:
embed: https://www.youtube.com/embed/TvlxJshxLVc?si=w5aB0-Pa9h6_rs65
zotero:
date: 2023-04-04
date-publication: 2024-03-06
source: auteur
priority: lowpriority
position: main

---

Ici il est possible -- mais pas obligatoire -- d'ajouter un texte.
