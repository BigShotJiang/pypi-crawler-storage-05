"""
MemU Self-Hosted Server

A FastAPI-based self-hosted server for MemU memory management system.
Provides REST APIs for memory storage and retrieval operations.
"""

__version__ = "0.1.0"
