"""
Server API Routers

FastAPI routers for different API endpoints.
"""
