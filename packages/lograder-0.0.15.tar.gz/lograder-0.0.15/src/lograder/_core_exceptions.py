class LograderError(Exception):
    """
    This is the base exception class for all exceptions raised
    by the `lograder` module, for easy error handling.
    """

    pass
