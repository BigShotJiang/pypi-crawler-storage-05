from .registry import TestRegistry

__all__ = ["TestRegistry"]
