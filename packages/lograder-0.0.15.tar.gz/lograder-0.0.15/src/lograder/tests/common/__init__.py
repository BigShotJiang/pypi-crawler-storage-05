from lograder.common.types import FilePath

__all__ = ["FilePath"]
