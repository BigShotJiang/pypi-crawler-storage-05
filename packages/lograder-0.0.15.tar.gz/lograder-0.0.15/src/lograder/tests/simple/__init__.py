from .test_maker import make_tests_from_strs

__all__ = ["make_tests_from_strs"]
