from llama_index.embeddings.oci_genai.base import OCIGenAIEmbeddings


__all__ = ["OCIGenAIEmbeddings"]
