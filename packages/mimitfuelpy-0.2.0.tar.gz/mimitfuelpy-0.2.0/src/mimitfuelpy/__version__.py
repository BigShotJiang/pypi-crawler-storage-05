"""Version information for mimitfuelpy."""

__version__ = "0.1.0"
__author__ = "Francesco"
__email__ = "francesco@example.com"