from dataclasses import dataclass

@dataclass
class Highway:
    id: int
    description: str