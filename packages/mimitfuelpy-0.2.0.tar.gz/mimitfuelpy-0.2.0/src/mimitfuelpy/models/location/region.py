from dataclasses import dataclass

@dataclass
class Region:
    id: int
    description: str