"""Enumerations for mimitfuelpy."""

from .fuel_type import FuelType
from .service_type import ServiceType

__all__ = ['FuelType', 'ServiceType']