# Boolean literals

```py
reveal_type(True)  # revealed: Literal[True]
reveal_type(False)  # revealed: Literal[False]
```
