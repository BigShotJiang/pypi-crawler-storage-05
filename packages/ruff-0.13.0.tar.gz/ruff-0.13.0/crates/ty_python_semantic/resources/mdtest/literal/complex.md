# Complex literals

## Complex numbers

```py
reveal_type(2j)  # revealed: complex
```
