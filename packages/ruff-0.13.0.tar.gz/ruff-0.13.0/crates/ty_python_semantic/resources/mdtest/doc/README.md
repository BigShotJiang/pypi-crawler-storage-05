This directory contains user-facing documentation, but also doubles as an extended test suite that
makes sure that our documentation stays up to date.
