for a in b:
    c
else:
    d
