def foo(a, b):
    a + b
