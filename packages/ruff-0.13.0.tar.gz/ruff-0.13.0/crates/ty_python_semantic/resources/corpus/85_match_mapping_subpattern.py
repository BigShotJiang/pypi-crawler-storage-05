match x:
    case {0: (0 | 1 | 2 as z)}:
        pass
