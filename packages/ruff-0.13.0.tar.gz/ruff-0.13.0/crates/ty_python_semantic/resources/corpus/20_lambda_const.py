lambda x: y + 1
