from __future__ import annotations

import builtins

x: Callable[..., object] = __import__
