c = {a: 1, b: 2}
fun(a, b, **c)
