def f(name, args):
    return f"foo.{name!r}{name!s}{name!a}"
