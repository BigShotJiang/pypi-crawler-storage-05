from typing import Callable

def a(x: Callable[.., None]): ...

def b(x: Callable[..
