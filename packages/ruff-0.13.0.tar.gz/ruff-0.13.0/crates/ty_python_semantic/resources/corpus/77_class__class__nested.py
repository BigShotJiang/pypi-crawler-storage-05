class Outer:
    def z(self):
        def x():
            super()
