from __future__ import annotations

import builtins

builtins.__import__: Callable[..., object] = __import__
