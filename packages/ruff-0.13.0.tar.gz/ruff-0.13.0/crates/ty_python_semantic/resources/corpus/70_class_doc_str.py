class List(list): "List() doc"
