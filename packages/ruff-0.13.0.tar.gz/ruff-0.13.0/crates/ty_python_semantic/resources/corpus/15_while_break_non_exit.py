while a:
    try:
       x
    except:
        break
if x:
    z = 1
