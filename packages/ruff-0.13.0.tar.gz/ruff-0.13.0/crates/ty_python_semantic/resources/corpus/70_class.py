class C:
    pass
