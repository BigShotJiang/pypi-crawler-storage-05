while False:
    b
