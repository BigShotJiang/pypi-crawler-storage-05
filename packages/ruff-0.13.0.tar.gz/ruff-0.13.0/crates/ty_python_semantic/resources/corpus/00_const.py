None
False
True
Ellipsis
...
