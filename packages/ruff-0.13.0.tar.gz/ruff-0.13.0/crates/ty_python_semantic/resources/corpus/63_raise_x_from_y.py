raise b from c
