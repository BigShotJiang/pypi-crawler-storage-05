a if b else c

