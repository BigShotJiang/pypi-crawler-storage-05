try:
    pass
finally:
    if x:
        y = x
