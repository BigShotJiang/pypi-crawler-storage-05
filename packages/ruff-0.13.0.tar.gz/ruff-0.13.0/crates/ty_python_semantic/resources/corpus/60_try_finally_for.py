try:
    pass
finally:
    for f in fs:
        pass
