del (a, b, c)
del [a, b, c]
