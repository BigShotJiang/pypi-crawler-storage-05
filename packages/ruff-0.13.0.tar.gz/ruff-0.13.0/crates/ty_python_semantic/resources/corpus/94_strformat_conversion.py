msg = "hello"

f"{msg!r:>{10+10}}"
