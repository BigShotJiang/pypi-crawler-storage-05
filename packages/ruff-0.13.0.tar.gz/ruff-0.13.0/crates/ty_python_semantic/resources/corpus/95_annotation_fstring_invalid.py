x: f"Literal[{1 + 2}]" = 3
