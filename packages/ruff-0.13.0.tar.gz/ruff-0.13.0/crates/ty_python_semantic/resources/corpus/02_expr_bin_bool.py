a or b or c
a and b and c

a or b and c

#a and b or c
