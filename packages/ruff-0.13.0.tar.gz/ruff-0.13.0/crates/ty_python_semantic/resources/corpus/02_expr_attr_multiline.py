foo(
    bar=1
).attr
