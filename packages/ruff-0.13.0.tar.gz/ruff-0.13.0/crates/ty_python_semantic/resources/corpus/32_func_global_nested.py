def foo():
    global bar
    def bar():
        pass
