class F():
    z: int = 5

