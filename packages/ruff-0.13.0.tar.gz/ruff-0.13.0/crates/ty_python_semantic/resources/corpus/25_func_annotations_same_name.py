def bool(x) -> bool:
    return True


class MyClass: ...


def MyClass() -> MyClass: ...


def x(self) -> x: ...
