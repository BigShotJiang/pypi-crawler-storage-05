def f(w):
    match w:
        case x:
            pass
