"str"
1
1.1
b"bin"
