def __add__():
    "A docstring."
    return foo(**kw)
