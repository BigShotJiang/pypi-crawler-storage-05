@foo.bar
class C:
   def __init__(self):
       self.x = 42

