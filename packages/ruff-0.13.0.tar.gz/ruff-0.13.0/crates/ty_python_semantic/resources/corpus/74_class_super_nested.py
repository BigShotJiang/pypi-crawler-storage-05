def fun():

    class Foo:

        def __init__(self):
            super().__init__()

        def no_super(self):
            return
