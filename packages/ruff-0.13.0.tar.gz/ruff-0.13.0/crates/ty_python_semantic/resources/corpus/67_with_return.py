def foo():
    with x:
        return y
