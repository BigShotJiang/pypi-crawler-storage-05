async def test3():
    async for i in x:
        if i > 20:
           continue
        else:
           c
    d
