if a:
    b
elif c:
    d
