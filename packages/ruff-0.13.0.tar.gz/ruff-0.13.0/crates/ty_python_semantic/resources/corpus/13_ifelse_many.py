if a:
    a1
elif b:
    b1
elif c:
    c1
elif d:
    d1
