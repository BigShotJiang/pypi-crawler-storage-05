"""Rotating JWT token service plugin."""

from .rotating_jwt import RotatingJWTTokenService

__all__ = ["RotatingJWTTokenService"]
