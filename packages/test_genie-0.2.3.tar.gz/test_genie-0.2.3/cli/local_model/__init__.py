# Local model package for offline test generation
