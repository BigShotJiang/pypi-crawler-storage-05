from enum import Enum


class TemplateFormatVersion(str, Enum):
    VERSION_1 = "2025-03-31"
