"""
Domain-specific tests for anomaly-grid-py.

These tests validate the mathematical and logical correctness of the library
across different domains of knowledge.
"""
