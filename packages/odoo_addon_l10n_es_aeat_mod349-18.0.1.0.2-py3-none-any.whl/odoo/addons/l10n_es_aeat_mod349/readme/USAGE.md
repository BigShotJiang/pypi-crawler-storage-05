Ir a:

- Contabilidad / Informes AEAT / Modelo 349
- Crear un nuevo registro e informar los datos básicos de la
  declaración.
- Pulsar 'Calcular' y revisar el resultado. Pulsar el botón 'Imprimir'
  para obtener el resultado en PDF.
- Para excluir ciertas operaciones de la declaración, ir a las pestañas
  'Registros de empresas' o 'Rectificaciones', y eliminar, en la seccion
  'Detalles', las operaciones que se desee excluir de la declaración.

Consideraciones importantes:

- En caso de indicar el tipo de declaración 'Suplementaria' o 'Normal'
  se propondrán todas las operaciones que apliquen para el periodo.
- En caso de indicar 'Complementaria', se propondrán únicamente aquellas
  operaciones que no hubieran sido aún presentadas en otra declaración.
