- Luis Manuel Angueira Blanco (Pexego)

- Omar Castiñeira Saavedra\<<omar@pexego.es>\>

- Miguel López (Top Consultant)

- Ignacio Martínez (Top Consultant)

- [Tecnativa](https://www.tecnativa.com):

  - Pedro M. Baeza
  - Ángel Moya
  - Luis M. Ontalba
  - Carlos Daudén

- ForgeFlow (<http://www.forgeflow.com>)

  - Jordi Ballester \<<jordi.ballester@forgeflow.com>\>
  - Aarón Henríquez

- Aitor Bouzas \<<aitor.bouzas@adaptivecity.com>\>

- Acysos:

  - Ignacio Ibeas

- [Sygel](https://www.sygel.es):

  - Valentin Vinagre
  - Manuel Regidor

- Jairo Llopis (Moduon)

- [Factor Libre](https://factorlibre.com):

  > - Luis J. Salvatierra \<<luis.salvatierra@factorlibre.com>\>
  > - Alejandro Ji Cheung \<<alejandro.jicheung@factorlibre.com>\>
