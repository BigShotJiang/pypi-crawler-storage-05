This is zkyhaxpy package.
zkyhaxpy is a python package for personal usage.
It provides a lot of useful tools for working as data scientist.