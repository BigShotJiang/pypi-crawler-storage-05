
'''
%%javascript
IPython.notebook.kernel.execute('nb_name = "' + IPython.notebook.notebook_name + '"')
import os
nb_full_path = os.path.join(os.getcwd(), nb_name)
'''


