def main():
    print("Hello from energyapi!")


if __name__ == "__main__":
    main()
