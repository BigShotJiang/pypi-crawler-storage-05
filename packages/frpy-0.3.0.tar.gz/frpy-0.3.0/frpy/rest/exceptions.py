class FreeRiderHDAPIError(Exception):
	pass

class AuthenticationError(FreeRiderHDAPIError):
	pass