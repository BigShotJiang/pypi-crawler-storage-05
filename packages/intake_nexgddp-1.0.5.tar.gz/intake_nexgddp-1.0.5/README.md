# intake-nexgddp

### To publish to pypi,
`pip install setuptools wheel twine`

`python -m build`
If build error, install:

`pip install 'build<0.10.0'`


`twine upload dist/* `



## Developer Only
Pypi token:
get one from pypi.org
