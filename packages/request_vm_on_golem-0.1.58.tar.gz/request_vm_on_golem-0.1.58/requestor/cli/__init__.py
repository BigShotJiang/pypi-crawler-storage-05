"""CLI interface for VM on Golem."""
