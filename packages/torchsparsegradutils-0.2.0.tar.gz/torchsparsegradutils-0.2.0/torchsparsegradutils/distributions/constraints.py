# TODO: constraints for sparse distributions
