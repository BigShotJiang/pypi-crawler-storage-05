import ctypes


def ktime():
    return ctypes.c_int64(0)
