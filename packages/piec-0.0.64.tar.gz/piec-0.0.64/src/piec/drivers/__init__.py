# Make the autodetect function available at the package level
from .utilities import autodetect_instrument
