# DO NOT EDIT
# Generated from .copier-answers.yml

from matteridge import main

main()
