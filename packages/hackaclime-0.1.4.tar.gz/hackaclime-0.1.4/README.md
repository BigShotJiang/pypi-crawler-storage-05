## HackaCLIme
A CLI terminal app to read time tracked on Hack Club's Wakatime modification, known as Hackatime!

## Installation
`pip install hackaclime`

## Usage
Make sure you've set up your Hackatime, and have a .wakatime.cfg file. Run `hackaclime` in your chosen terminal emulator.

## Themes
A utility to create custom themes is included, or you can make yourself in `hackaclime.cfg`!