``zope.error``
==============

.. image:: https://github.com/zopefoundation/zope.error/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.error/actions/workflows/tests.yml

.. image:: https://coveralls.io/repos/github/zopefoundation/zope.error/badge.svg
        :target: https://coveralls.io/github/zopefoundation/zope.error


This package provides an error reporting utility which is able to store errors.
