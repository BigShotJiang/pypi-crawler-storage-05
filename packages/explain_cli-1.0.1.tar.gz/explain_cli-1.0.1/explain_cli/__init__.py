"""explain-cli: Explain Git commits, PRs, and branch differences using AI."""

__version__ = "1.0.1"
__author__ = "ccmdi"
__email__ = "ccmdi.dev@gmail.com"
