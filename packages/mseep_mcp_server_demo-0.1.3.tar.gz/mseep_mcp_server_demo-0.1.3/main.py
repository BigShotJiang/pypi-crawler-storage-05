from tg_tools import mcp
# import .tg_resources  # Ensure resources are registered

# If running directly, launch the MCP app
def main():
    mcp.run()
