from ..resources.resolve_path import resolve_path

map1 =  resolve_path('kenney_sokoban/map1.tmx')
map2 = resolve_path('kenney_sokoban/map2.tmx')
map3 = resolve_path('kenney_sokoban/map3.tmx')
map4 = resolve_path('kenney_sokoban/map4.tmx')
map5 = resolve_path('kenney_sokoban/map5.tmx')
map6 = resolve_path('kenney_sokoban/map6.tmx')