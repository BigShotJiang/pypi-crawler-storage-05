from codomir import player, set_map, wait_quit, maps

set_map(maps.linear.map2)

player.move_forward()
player.move_forward()
player.move_forward()

wait_quit()
