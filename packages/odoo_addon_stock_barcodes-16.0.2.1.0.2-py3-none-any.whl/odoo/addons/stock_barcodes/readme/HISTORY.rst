11.0.1.1.0 (2019-09-24)
~~~~~~~~~~~~~~~~~~~~~~~

* [ADD] New feature.
  User can uses barcode interface in picking operations.

13.0.1.1.1 (2021-02-06)
~~~~~~~~~~~~~~~~~~~~~~~

* [ADD] New feature.
  Add option to get lots automatically based on removal strategy in inventory.

14.0.1.0.0 (2021-04-05)
~~~~~~~~~~~~~~~~~~~~~~~

* [ADD] New feature.
  Add security for users.

16.0.1.0.0 (2025-01-23)
~~~~~~~~~~~~~~~~~~~~~~~
* [IMP]
  Improved views to optimize navigation and functionality.
  Intuitive and mobile-friendly views.
  Visual improvement of the main view accessed from the Barcodes menu.

* [ADD] New feature.
  Barcode reading to barcode actions.
  Generate PDF document for the barcodes of the selected barcode actions.

