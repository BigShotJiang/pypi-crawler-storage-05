# SPDX-FileCopyrightText: 2025-present David Kalliecharan <david@david.science>
#
# SPDX-License-Identifier: BSD-2-Clause
__version__ = "0.2.0"
