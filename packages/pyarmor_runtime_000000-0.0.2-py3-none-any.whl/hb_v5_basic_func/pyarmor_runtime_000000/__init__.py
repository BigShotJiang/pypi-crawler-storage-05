# Pyarmor 9.1.9 (trial), 000000, 2025-09-11T09:04:26.422515
from .pyarmor_runtime import __pyarmor__
