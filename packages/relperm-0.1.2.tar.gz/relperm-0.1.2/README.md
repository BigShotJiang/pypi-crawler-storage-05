# Relperm

A Python package for petroleum engineering relative permeability calculations.

## Installation

```bash
pip install relperm
```

## Usage

```python
import relperm
# Your usage examples here
```