"""
OpenCV MCP Server - MCP server providing OpenCV computer vision capabilities.
"""

__version__ = "0.1.0"
