This module adds support for **cash deposits at the bank**. It also
supports the other way around: **ordering cash at the bank**. It allows
to declare the kind of cash you want to deposit (or order): bank notes,
coins and coin rolls and the quantity for each of them. Coins are rarely
used, because most banks only allow to deposit/order coin rolls.
