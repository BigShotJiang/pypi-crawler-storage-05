# sage_setup: distribution = sagemath-cmr
# delvewheel: patch

from sage.all__sagemath_graphs import *
from sage.all__sagemath_modules import *
