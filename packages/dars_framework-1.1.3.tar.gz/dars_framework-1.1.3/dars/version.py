__version__ = "1.1.3"
__release_url__ = "https://github.com/ZtaMDev/Dars-Framework/releases/tag/1.1.3"
