"""The Volatus module for interacting with Volatus system software from Python.

   The main means of interaction is provided by the :class:`Volatus <volatus.volatus.Volatus>` class.
"""