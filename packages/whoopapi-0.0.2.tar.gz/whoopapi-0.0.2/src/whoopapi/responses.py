DEFAULT_404_PAGE = """
<div style="display:flex;flex-direction:row;justify-content:center;align-items:center;margin:50px">
    <h1><b>404 Error! This resource is not available.</b></h1>
</div>
"""

DEFAULT_500_PAGE = """
<div style="display:flex;flex-direction:row;justify-content:center;align-items:center;margin:50px">
    <h1><b>500 Error! Internal server error.</b></h1>
</div>
"""
