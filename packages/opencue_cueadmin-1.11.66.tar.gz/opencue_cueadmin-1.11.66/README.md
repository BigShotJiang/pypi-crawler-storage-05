# CueAdmin

The OpenCue commandline client.

This client is used to administer an OpenCue deployment. It's written in Python
and provides a thin layer over the OpenCue Python API.

