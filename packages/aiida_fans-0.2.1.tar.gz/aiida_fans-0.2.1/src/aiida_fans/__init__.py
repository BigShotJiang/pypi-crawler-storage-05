"""aiida_fans - AiiDA plugin for FANS, an FFT-based homogenization solver."""
