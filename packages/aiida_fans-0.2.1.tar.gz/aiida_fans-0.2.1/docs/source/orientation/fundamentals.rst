Fundamentals
============

TODO

FANS
----

See the `FANS README <https://github.com/DataAnalyticsEngineering/FANS/tree/main?tab=readme-ov-file#fourier-accelerated-nodal-solvers-fans>`_.

Explanation of the CLI
^^^^^^^^^^^^^^^^^^^^^^

TODO

Some Configuration Options
^^^^^^^^^^^^^^^^^^^^^^^^^^

TODO

The Working Directory
^^^^^^^^^^^^^^^^^^^^^

TODO

AiiDA
-----

See the `AiiDA documentation <https://aiida.readthedocs.io/projects/aiida-core/en/stable/index.html>`_.

Profiles and You
^^^^^^^^^^^^^^^^

TODO

The Computer & The Code
^^^^^^^^^^^^^^^^^^^^^^^

TODO

Starting Up & Shutting Down
^^^^^^^^^^^^^^^^^^^^^^^^^^^

TODO

Remote Execution
^^^^^^^^^^^^^^^^

TODO
