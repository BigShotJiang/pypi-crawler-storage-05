Tutorial
========

.. note::

   The tutorial is available at the 
   `aiida-fans-tutorial <https://github.com/ethan-shanahan/aiida-fans-tutorial>`_
   repository. It includes a `marimo <https://marimo.io/>`_ notebook that helps 
   you to get started with AiiDA and run FANS simulations with the plugin.
