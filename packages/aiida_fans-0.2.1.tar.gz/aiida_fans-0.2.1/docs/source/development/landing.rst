#################
 Developer Guide
#################

TODO

*********
 Testing
*********

TODO

**************
 Contributing
**************

TODO

Style Guide
===========

TODO

Pipeline
========

TODO

Releasing
=========

TODO

PyPI
----

TODO

Conda
-----

TODO

*************
 Documenting
*************

TODO

Building
========

TODO

Publishing
==========

TODO
