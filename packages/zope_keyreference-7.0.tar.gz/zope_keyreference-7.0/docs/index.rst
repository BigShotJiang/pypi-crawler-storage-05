============================
 What is zope.keyreference?
============================

Object references that support stable comparison and hashes.

.. toctree::
   :maxdepth: 1

   persistent
   reference


.. toctree::
   :maxdepth: 2

   changelog

Development
===========

zope.keyreference is hosted at GitHub:

    https://github.com/zopefoundation/zope.keyreference/



Project URLs
============

* https://pypi.org/project/zope.keyreference/       (PyPI entry and downloads)


====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
