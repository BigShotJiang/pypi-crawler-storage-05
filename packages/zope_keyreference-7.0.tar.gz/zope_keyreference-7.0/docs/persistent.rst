.. include:: ../src/zope/keyreference/persistent.txt
