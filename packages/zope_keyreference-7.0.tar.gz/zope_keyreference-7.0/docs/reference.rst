===========
 Reference
===========

Interfaces
==========

.. automodule:: zope.keyreference.interfaces

Persistent Objects
==================

.. automodule:: zope.keyreference.persistent
