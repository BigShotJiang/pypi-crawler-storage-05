===================
 zope.keyreference
===================

.. image:: https://img.shields.io/pypi/v/zope.keyreference.svg
   :target: https://pypi.org/project/zope.keyreference/
   :alt: Latest Version

.. image:: https://img.shields.io/pypi/pyversions/zope.keyreference.svg
   :target: https://pypi.org/project/zope.keyreference/
   :alt: Supported Python versions

.. image:: https://github.com/zopefoundation/zope.keyreference/actions/workflows/tests.yml/badge.svg
   :target: https://github.com/zopefoundation/zope.keyreference/actions/workflows/tests.yml
   :alt: Build Status

.. image:: https://coveralls.io/repos/github/zopefoundation/zope.keyreference/badge.svg
   :target: https://coveralls.io/github/zopefoundation/zope.keyreference
   :alt: Code Coverage

.. image:: https://readthedocs.org/projects/zopekeyreference/badge/?version=latest
   :target: https://zopekeyreference.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation Status

Object references that support stable comparison and hashes.

Documentation can be found at https://zopekeyreference.readthedocs.io
