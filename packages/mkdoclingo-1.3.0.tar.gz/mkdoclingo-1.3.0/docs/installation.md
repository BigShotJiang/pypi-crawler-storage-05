---
icon: "material/wrench"
---

# Getting started

## Installation

### Using `pip`

```console
pip install mkdoclingo
```
