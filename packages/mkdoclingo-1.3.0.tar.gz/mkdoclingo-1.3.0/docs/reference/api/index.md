---
title: "API"
icon: "material/book-open-variant"
---

Comprehensive API documentation for the [Python package](https://mkdocstrings.github.io/) utilized as a plugin in the mkdocstrings framework.
