# Semantics

::: mkdocstrings_handlers.asp.semantics
    handler: python
    options:
      members: true
      show_submodules: true
