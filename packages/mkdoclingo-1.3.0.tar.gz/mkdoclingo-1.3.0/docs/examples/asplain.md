---
icon: material/head-question
---

# Asplain


!!! tip

    Use the :material-file-eye-outline: icon in the top right to see the source code for this page.


::: examples/asplain/base.lp
    handler: asp
    options:
        encodings: true
        glossary:
            include_undocumented: false
        predicate_table:
            include_undocumented: false
        dependency_graph: true
        start_level: 2
