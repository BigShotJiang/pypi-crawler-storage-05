import tgmath


test0 = tgmath.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
test1 = tgmath.array([10, 20, 30, 40, 50, 55, 70, 80, 90])

print(tgmath.array.pcc(test0, test1))