# Supported Titles

The currently supported NES titles are:
    - Arkanoid
    - Baseball
    - Bubble Bobble
    - Dr Mario
    - Excitebike
    - Golf
    - Kung Fu
    - The Adventures of Lolo 1
    - Mario Bros
    - Mike Tyson's Punch Out!!!
    - Super Mario Bros 1
    - Super Mario Bros 2
    - Super Mario Bros 3
    - Tetris
    - Teenage Mutant Ninja Turtles
    - The Legend of Zelda