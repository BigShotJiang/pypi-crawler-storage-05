VERSION = "0.7.0"
__version__ = VERSION
