"""
SlopRank utilities for visualization, confidence calculation, and dashboard generation.
"""