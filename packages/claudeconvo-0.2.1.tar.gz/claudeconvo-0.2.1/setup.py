#!/usr/bin/env python3
"""Setup script for claudeconvo - for backward compatibility."""

from setuptools import setup

# The actual configuration is in pyproject.toml
# This file exists for compatibility with older pip versions
setup()