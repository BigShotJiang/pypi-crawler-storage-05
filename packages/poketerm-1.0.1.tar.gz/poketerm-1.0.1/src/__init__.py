"""
Put a custom message and/or 
a pokemon ASCII art and/or 
a random oneliner when you start your terminal
"""
__version__ = "1.0.1"
__author__ = "devarshi16"
