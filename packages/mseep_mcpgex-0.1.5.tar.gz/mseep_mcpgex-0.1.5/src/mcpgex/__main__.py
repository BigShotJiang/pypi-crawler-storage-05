from mcpgex import main

main()