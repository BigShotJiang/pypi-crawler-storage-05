# Import for backward compatibility
from encord.orm.project import ProjectDataset
