class PyWinTunException(Exception):
    pass
