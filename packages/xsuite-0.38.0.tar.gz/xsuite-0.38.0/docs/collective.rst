==================
Collective effects
==================

.. contents:: Table of Contents
    :depth: 3

.. include:: collective_intro.rst

.. include:: spacechargeauto.rst

.. include:: beambeam.rst

.. include:: pyhtinterface.rst

.. include:: combined_cpu_gpu.rst

.. include:: pipeline.rst
