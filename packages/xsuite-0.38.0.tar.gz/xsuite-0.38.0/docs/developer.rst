=================
Developer's guide
=================

.. toctree::
    :maxdepth: 2

    dev_guide_xtrack_beam_elements
    xobjexample
    autogeneration
    numericalreproducibility
    testing