import warnings

warnings.warn(
    "acmems (acme-mgmtserver) has been renamed to macen. Switch to new pkg to receive upgrades.",
    FutureWarning,
)
