from django.contrib import admin

from ephios.plugins.files.models import Document

admin.site.register(Document)
