from django.contrib import admin

from ephios.modellogging.models import LogEntry

admin.site.register(LogEntry)
