==============
 zope.formlib
==============

.. image:: https://github.com/zopefoundation/zope.formlib/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.formlib/actions/workflows/tests.yml

.. image:: https://readthedocs.org/projects/zopeformlib/badge/?version=latest
        :target: https://zopeformlib.readthedocs.io/en/latest/
        :alt: Documentation Status


Forms are web components that use widgets to display and input data.
Typically a template displays the widgets by accessing an attribute or
method on an underlying class.

Documentation is hosted at https://zopeformlib.readthedocs.io/en/latest/
