.. include:: ../src/zope/formlib/widgets.rst
