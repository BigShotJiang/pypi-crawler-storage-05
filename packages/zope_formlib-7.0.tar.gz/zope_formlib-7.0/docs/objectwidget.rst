.. include:: ../src/zope/formlib/objectwidget.rst
