# Project Context

## Current State
- **Active Feature**: None
- **Last Updated**: [AUTO-GENERATED]
- **Phase**: Initialization

## Recent Decisions
<!-- Updated by AI during development -->

## Active Specifications
<!-- List of in-progress specifications -->

## Completed Features
<!-- List of completed features with links -->

## Technical Stack
<!-- Current technology choices -->

## Known Issues
<!-- Active bugs or technical debt -->

## Performance Metrics
<!-- Key performance indicators -->

## Team Notes
<!-- Important reminders or observations -->