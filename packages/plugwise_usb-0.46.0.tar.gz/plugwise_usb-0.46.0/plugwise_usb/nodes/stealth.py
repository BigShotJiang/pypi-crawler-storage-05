"""Plugwise Stealth node object."""

from ..nodes.circle import PlugwiseCircle


class PlugwiseStealth(PlugwiseCircle):
    """provides interface to the Plugwise Stealth nodes."""
