===========================
 Parsing and Compiling XML
===========================

.. automodule:: zope.tal.talparser

.. autoclass:: zope.tal.xmlparser.XMLParser
