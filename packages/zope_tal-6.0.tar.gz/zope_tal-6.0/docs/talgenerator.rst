==========================
 Generating Compiled Code
==========================

.. automodule:: zope.tal.talgenerator
