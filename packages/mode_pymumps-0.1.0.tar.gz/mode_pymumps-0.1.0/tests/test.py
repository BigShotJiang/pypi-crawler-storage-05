import pyMUMPS

print("hello world")
