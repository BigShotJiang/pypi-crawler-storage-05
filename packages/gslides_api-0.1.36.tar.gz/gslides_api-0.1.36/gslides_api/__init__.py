from ._version import __version__, __version_info__
from .client import GoogleAPIClient, initialize_credentials
from .page.slide import Slide
from .presentation import Presentation
