This module extend existing "Compute Asset" feature by allowing to
create an Compute Asset Batch (record) to track the computation.
