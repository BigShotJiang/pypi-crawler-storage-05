# -*- coding: utf-8 -*-
from dart_fss.auth.auth import set_api_key, get_api_key

__all__ = ['set_api_key', 'get_api_key']