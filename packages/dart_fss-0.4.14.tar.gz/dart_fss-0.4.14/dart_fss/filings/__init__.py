# -*- coding: utf-8 -*-
from dart_fss.filings.search import search

__all__ = ['search']