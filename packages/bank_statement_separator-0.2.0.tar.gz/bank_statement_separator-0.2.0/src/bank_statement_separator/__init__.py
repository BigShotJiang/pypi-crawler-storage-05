"""
Bank Statement Separator

AI-powered tool for separating multi-statement PDF files using LangChain and LangGraph.
"""

__version__ = "0.2.0"
__author__ = "Bank Statement Separator Team"
