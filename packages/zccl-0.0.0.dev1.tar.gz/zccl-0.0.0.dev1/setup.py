from setuptools import setup

# This file is maintained for backwards compatibility.
# For modern Python packaging, the project configuration is in pyproject.toml
# and this file simply delegates to setuptools.setup().

setup()
