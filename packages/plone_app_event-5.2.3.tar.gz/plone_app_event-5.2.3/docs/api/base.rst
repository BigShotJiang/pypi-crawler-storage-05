plone.app.event.base
====================

.. automodule:: plone.app.event.base
    :members:
