plone.app.event.browser.event_view
==================================

.. automodule:: plone.app.event.browser.event_view
    :members:
