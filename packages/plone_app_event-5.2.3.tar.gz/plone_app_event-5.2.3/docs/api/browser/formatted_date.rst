plone.app.event.browser.formatted_date
======================================

.. automodule:: plone.app.event.browser.formatted_date
    :members:
