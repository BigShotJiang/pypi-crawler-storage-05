plone.app.event.interfaces
==========================

.. automodule:: plone.app.event.interfaces
    :members:
