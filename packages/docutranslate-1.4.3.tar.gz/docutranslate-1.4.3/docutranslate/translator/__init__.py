default_params = {
    "thinking": "disable",
    "chunk_size": 3000,
    "concurrent": 30,
    "temperature": 0.7,
    "timeout": 1200,
    "retry": 2
}
