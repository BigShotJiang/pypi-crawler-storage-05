# @untrace/sdk-python

## 0.1.2

### Patch Changes

- [`c3d9a49`](https://github.com/untrace-dev/untrace-sdk/commit/c3d9a4919effed705611ff737ac76b0d3d810649) Thanks [@seawatts](https://github.com/seawatts)! - Bump

## 0.1.1

### Patch Changes

- [`9ce57bc`](https://github.com/untrace-dev/untrace-sdk/commit/9ce57bcf7a4c1633aed4b7e7d6ea17b11efb0521) Thanks [@seawatts](https://github.com/seawatts)! - Fixing publishing
