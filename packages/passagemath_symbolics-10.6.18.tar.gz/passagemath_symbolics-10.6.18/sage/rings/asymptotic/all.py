# sage_setup: distribution = sagemath-symbolics
from sage.misc.lazy_import import lazy_import
lazy_import('sage.rings.asymptotic.asymptotic_ring', 'AsymptoticRing')
lazy_import('sage.rings.asymptotic.asymptotic_expansion_generators',
            'asymptotic_expansions')
del lazy_import
