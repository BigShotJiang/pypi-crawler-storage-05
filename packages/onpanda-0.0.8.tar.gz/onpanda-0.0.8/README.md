# The companion Python package for onPanda

## ▮ Features
- [x] Parse panda json data into SFT (dense), DPO (outcome-level) and token level pair data
- [ ] Provide simple back-end API server for scaling up data annotation


## ▮ Parse panda json





