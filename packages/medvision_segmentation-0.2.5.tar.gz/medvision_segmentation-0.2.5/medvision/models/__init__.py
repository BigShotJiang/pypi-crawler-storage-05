"""Models module for MedVision."""

from medvision.models.model_factory import get_model, SegmentationModel
