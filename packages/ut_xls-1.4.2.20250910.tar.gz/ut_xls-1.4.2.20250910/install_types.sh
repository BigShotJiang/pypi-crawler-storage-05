python3 -m pip install types-toml
python3 -m pip install types-ujson
mypy --install-types
