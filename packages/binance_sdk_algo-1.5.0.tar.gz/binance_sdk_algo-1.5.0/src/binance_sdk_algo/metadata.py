NAME = "binance-sdk-algo"
