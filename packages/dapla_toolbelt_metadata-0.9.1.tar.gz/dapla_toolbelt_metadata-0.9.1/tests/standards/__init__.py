"""Test suite for the standards package."""
