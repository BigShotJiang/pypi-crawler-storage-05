```{include} ../src/dapla_metadata/variable_definitions/generated/README.md
:relative-docs: ../src/dapla_metadata/variable_definitions/generated/vardef_client/docs/
```
