"""Tests for Zammad MCP server."""
