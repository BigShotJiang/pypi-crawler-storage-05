.. If you created a package, create one automodule per module in the package.

API Reference
#############

.. automodule:: adafruit_character_lcd.character_lcd
   :members:

.. automodule:: adafruit_character_lcd.character_lcd_i2c
   :members:

.. automodule:: adafruit_character_lcd.character_lcd_rgb_i2c
   :members:

.. automodule:: adafruit_character_lcd.character_lcd_spi
   :members:
