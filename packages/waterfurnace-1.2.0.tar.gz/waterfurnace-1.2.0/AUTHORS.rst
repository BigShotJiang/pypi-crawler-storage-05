=======
Credits
=======

Development Lead
----------------

* Sean Dague <sean@dague.net>

Contributors
------------

* mdallaire
* scondas
