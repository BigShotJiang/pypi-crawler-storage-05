# -*- coding: utf-8 -*-

"""Top-level package for waterfurnace."""

__author__ = """Sean Dague"""
__email__ = "sean@dague.net"
__version__ = "1.2.0"
