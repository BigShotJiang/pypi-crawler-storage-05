History
=======

1.2.0 (2025-09-13)
------------------
* Add SSL legacy compatibility to connect with modern SSL. Addresses
  UNSAFE_LEGACY_RENEGOTIATION_DISABLED error.
* Add LeavingWaterTemp and WaterFlowRate sensors (Series 7 WF)
* Added features to CLI (for details see --help)
  * Added debug flag 
  * Added option sensor list specification 
  * Added continous reporting 
  * Added ability to specify furnace in a multi unit system

1.1.0 (2019-01-07)
------------------
* Fix retry logic

1.0.0 (2018-12-05)
------------------
* Detect unit automatically
* Add series 7 sensors

0.7.0 (2018-07-13)
------------------

* Add workaround timer to handle socket failures

0.6.0 (2018-02-21)
------------------

* Add timeout on socket

0.5.0 (2018-02-16)
------------------

* Update exception handling to be more Home Assistant friendly

0.4.0 (2018-02-05)
------------------

* More exceptions to distinguish errors we are expecting

0.3.0 (2018-01-23)
------------------

* Handle tid rollover

0.2.0 (2018-01-19)
------------------

* Library specific exceptions for login failures.

0.1.0 (2018-01-17)
------------------

* First release on PyPI.
