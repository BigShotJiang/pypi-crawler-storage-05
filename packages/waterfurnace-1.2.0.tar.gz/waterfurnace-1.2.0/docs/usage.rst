=====
Usage
=====

To use waterfurnace in a project::

    import waterfurnace
