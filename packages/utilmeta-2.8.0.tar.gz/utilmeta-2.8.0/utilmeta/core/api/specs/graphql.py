from utilmeta.core.api import API


class GraphQL(API):
    def __init_subclass__(cls, **kwargs):
        pass
