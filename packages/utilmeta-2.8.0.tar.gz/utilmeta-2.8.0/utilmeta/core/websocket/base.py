# from utilmeta.core.api import API
#
#
# class Websocket(API):
#     def send(self):
#         pass
#
#     async def asend(self):
#         pass
#
#     def accept(self):
#         pass
#
#     async def aaccept(self):
#         pass
#
#     def receive(self):
#         pass
#
#     def connect(self):
#         pass
#
#     def disconnect(self):
#         pass
