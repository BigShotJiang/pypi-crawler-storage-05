from .model import DjangoModelAdaptor
