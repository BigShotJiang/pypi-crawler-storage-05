from django.core.exceptions import *
from django.db.utils import (
    DataError,
    DatabaseError,
    NotSupportedError,
    IntegrityError,
    InterfaceError,
    InternalError,
    OperationalError,
    ProgrammingError,
)
