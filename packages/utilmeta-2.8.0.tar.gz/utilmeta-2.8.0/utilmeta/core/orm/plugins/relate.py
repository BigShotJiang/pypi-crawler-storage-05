# from utilmeta.utils.plugin import Plugin


# class Relate(Plugin):
#     def __init__(self, *relations):
#         self.relations = relations
#         super().__init__(relations=relations)
#
#     def validate(self, api):
#         request = api.request
#         resource = api.queryset
#
#     def validate_relation(self, user, resource):
#         pass
