from .equation import Equation
from .system import EquationSystem

__all__ = ["Equation", "EquationSystem"]
