A Test Program!
===============

.. toctree::
   :maxdepth: 1
   :hidden:

   exercise/_enum_mathtitle_label
   exercise/_enum_notitle_label
   exercise/_enum_title_class_label
   exercise/_enum_title_nolabel
   exercise/_enum_ref_notitle
   exercise/_enum_ref_title
   exercise/_enum_ref_mathtitle
   exercise/_enum_numref_notitle
   exercise/_enum_numref_title
   exercise/_enum_numref_mathtitle

   exercise/_unenum_mathtitle_label
   exercise/_unenum_notitle_label
   exercise/_unenum_title_class_label
   exercise/_unenum_title_nolabel
   exercise/_unenum_ref_notitle
   exercise/_unenum_ref_title
   exercise/_unenum_ref_mathtitle
   exercise/_unenum_numref_notitle
   exercise/_unenum_numref_title
   exercise/_unenum_numref_mathtitle
   exercise/_enum_numref_placeholders

   exercise/_enum_duplicate_label

   solution/_linked_enum
   solution/_linked_enum_class
   solution/_linked_missing_arg
   solution/_linked_unenum_mathtitle
   solution/_linked_unenum_mathtitle2
   solution/_linked_unenum_notitle
   solution/_linked_unenum_title
   solution/_linked_wrong_targetlabel

   solution/_linked_ref_unenum_notitle
   solution/_linked_ref_unenum_title
   solution/_linked_ref_unenum_mathtitle
   solution/_linked_ref_unenum_mathtitle2
   solution/_linked_ref_enum

   solution/_linked_ref_wronglabel
   solution/_linked_duplicate_label
