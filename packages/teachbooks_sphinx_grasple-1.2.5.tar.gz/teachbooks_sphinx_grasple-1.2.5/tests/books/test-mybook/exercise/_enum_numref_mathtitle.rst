_enum_numref_mathtitle
======================

This is a reference :numref:`test-exc-label-math`.

This is a second reference :numref:`some text %s <test-exc-label-math>`.

This is a third reference :numref:`some text {number} <test-exc-label-math>`.

This is a fourth reference :numref:`some text {name} <test-exc-label-math>`.
