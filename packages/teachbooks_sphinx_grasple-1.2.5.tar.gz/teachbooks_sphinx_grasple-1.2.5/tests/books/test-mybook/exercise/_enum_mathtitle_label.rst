_enum_mathtitle_label
=====================

.. exercise:: Test :math:`\mathbb{R}`
	:label: test-exc-label-math

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
