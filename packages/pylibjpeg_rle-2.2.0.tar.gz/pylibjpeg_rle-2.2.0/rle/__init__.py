"""Set package shortcuts."""

from rle._version import __version__
from rle.utils import (
    pixel_array,
    generate_frames,
    decode_pixel_data,
    encode_pixel_data,
    pack_bits,
    unpack_bits,
)
