# AutoED

AutoED is a Python package for the automatic processing of electron
diffraction datasets collected at Diamond Light Source Electron
Biology Imaging Centre (eBIC). For more details, please look at the
[documentation page](https://autoed.readthedocs.io/en/latest/).


