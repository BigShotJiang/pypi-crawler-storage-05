"""DEPRECATED: Please import tabpfn.architectures.base.preprocessing instead."""

from __future__ import annotations

from tabpfn.architectures.base.preprocessing import *  # noqa: F403
