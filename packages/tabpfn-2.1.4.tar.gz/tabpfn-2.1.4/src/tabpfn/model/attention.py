"""DEPRECATED: Please import tabpfn.architectures.base.attention instead."""

from __future__ import annotations

from tabpfn.architectures.base.attention import *  # noqa: F403
