def main():
    print("Hello from awesome-energy-models!")


if __name__ == "__main__":
    main()
