from .main import logPaneTab
from ..imports import *
def startLogPaneConsole():
    startConsole(logPaneTab)
