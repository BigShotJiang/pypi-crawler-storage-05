from .main import finderTab
from abstract_gui.QT6.utils.console_utils import startConsole

from .main import finderConsole
from abstract_gui.QT6.utils.console_utils import startConsole
def startFinderConsole():
    startConsole(finderConsole)
