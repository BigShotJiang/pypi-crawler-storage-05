from ._config import config_from_root

__all__ = ["config_from_root"]
