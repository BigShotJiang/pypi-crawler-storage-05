import sys

from oasys2.canvas.main import main

if __name__ == "__main__":
    sys.exit(main(sys.argv))
