"""Only required to hold the automatically generated version for the "core" extras"""

from ._version import __version__
