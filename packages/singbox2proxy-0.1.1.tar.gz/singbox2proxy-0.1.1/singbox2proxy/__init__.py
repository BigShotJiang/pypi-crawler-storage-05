from .base import SingBoxCore, SingBoxProxy

VERSION = "0.1.1"

print(f"sing-box2proxy version {VERSION}")

__all__ = ["SingBoxCore", "SingBoxProxy", "VERSION"]
