from mytonwallet_pay.client import MTWPay


__all__ = [
    "MTWPay"
]
