from mytonwallet_pay.client.client import MTWPay

__all__ = [
    "MTWPay"
]