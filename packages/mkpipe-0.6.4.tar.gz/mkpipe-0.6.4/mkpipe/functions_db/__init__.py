from .register_db import get_db_connector

__all__ = get_db_connector
