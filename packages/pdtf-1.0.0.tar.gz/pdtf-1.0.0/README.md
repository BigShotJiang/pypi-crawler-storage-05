Description
using python 3.11 to use progressbar in you code.
Example:
import pdtf
for i in pdtf(range(0,10),0.1,"Data",20)
for i in pdtf(,range(int,int),sleep,name,length progressbar)