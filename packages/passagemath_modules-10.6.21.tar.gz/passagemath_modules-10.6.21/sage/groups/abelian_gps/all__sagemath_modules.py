# sage_setup: distribution = sagemath-modules

# from dual_abelian_group import DualAbelianGroup
from sage.groups.abelian_gps.abelian_group import AbelianGroup, word_problem
from sage.groups.abelian_gps.values import AbelianGroupWithValues
