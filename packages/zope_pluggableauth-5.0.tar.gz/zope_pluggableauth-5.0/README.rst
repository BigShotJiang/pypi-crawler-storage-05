========================
 ``zope.pluggableauth``
========================

.. image:: https://github.com/zopefoundation/zope.pluggableauth/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.pluggableauth/actions/workflows/tests.yml

Based on ``zope.authentication``, this package provides a flexible and
pluggable authentication utility, and provides a number of common plugins.
