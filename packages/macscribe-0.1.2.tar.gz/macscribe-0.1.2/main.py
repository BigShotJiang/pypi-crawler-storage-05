#!/usr/bin/env python3
from macscribe.cli import app

if __name__ == "__main__":
    app()