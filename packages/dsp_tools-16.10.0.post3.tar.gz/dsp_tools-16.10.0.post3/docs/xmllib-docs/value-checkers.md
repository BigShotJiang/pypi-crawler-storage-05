::: xmllib.value_checkers
