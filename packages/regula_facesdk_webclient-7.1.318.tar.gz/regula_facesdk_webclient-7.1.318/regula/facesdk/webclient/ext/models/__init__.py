from regula.facesdk.webclient.ext.models.match_request import MatchRequest
from regula.facesdk.webclient.ext.models.match_image import MatchImage
from regula.facesdk.webclient.ext.models.detect_request import DetectRequest

CompareRequest = MatchRequest
CompareImage = MatchImage
