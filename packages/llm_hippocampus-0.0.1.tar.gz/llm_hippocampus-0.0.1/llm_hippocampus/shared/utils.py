# -*- coding: utf-8 -*-
import uuid
def str_to_bool(val):
    return str(val).lower() in ["1", "yes", "true"]
