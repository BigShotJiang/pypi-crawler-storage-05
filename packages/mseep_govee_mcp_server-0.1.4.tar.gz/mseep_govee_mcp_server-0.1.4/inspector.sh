npx @modelcontextprotocol/inspector uv --directory . run python src/govee_mcp_server/server.py
