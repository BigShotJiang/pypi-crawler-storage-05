#
# Tina4 - This is not a 4ramework.
# Copy-right 2007 - current Tina4
# License: MIT https://opensource.org/licenses/MIT
#
# flake8: noqa: E501
request = None
body = None
params = {}
headers = {}
cookies = {}
url = None
session = None
files = {}
raw_request = None
raw_data = None
raw_content = None
transport = None
asgi_response = None
