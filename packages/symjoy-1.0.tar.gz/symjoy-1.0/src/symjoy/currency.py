# currency.py
currency = {
    "dollar": "$",
    "euro": "€",
    "pound": "£",
    "yen": "¥",
    "rupee": "₹",
    "won": "₩",
    "bitcoin": "₿",
    "cent": "¢",
    "franc": "₣",
    "lira": "₺",
    "rubl": "₽",
    "peso": "₱"
}
