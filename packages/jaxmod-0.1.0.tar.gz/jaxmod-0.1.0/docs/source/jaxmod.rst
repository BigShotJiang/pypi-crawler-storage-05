jaxmod package
==============

Submodules
----------

jaxmod.type\_aliases module
---------------------------

.. automodule:: jaxmod.type_aliases
   :members:
   :show-inheritance:
   :undoc-members:

jaxmod.utils module
-------------------

.. automodule:: jaxmod.utils
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: jaxmod
   :members:
   :show-inheritance:
   :undoc-members:
