# ljobx - LinkedIn Guest Job Scraper

A fast and simple command-line tool to scrape LinkedIn job postings without needing to log in.

## Installation

Install `ljobx` directly from PyPI:

```sh
pip install ljobx