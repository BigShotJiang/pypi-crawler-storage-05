# Cookiecutter Template Directory for .claude items

This directory contains the cookiecutter template structure for new mem8 projects that are for claude-code's CLAUDE.md subsystem.
