"""Templates package for mem8."""

# Ensure templates are discoverable
__all__ = ["claude-dot-md-template", "shared-thoughts-template"]