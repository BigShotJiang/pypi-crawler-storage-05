"""Entry point for running mem8 as a module."""

from mem8.cli import main

if __name__ == "__main__":
    main()