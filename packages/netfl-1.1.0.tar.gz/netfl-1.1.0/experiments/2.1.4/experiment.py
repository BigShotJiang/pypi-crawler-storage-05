from fogbed import HardwareResources, CloudResourceModel, EdgeResourceModel
from netfl.core.experiment import NetflExperiment
from netfl.utils.resources import LinkResources, calculate_compute_units, cu_with_margin
from task import MainTask


task = MainTask()
num_devices = task.train_configs().num_clients

host_cpu_ghz = 2.25

server_cpu_ghz = 2.0
server_memory_mb = 2048
server_network_mbps = 1000

pi3_cpu_ghz = 1.2
pi3_memory_mb = 1024
pi3_network_mbps = 100

server_cu = calculate_compute_units(host_cpu_ghz, server_cpu_ghz)
server_mu = server_memory_mb
server_bw = server_network_mbps

pi3_cu = calculate_compute_units(host_cpu_ghz, pi3_cpu_ghz)
pi3_mu = pi3_memory_mb
pi3_bw = pi3_network_mbps

cloud_cu = cu_with_margin(server_cu)
cloud_mu = server_mu

edge_cu = cu_with_margin(pi3_cu * (num_devices // 2))
edge_mu = pi3_mu * (num_devices // 2)

exp_cu = cu_with_margin(cloud_cu + (2 * edge_cu))
exp_mu = cloud_mu + (2 * edge_mu)

exp = NetflExperiment(
	name="exp-2.1.4",
	task=task,
	max_cu=exp_cu,
	max_mu=exp_mu
)

cloud = exp.add_virtual_instance(
	"cloud",
	CloudResourceModel(max_cu=cloud_cu, max_mu=cloud_mu)
)

edges = [
	exp.add_virtual_instance(
		"edge0",
		EdgeResourceModel(max_cu=edge_cu, max_mu=edge_mu)
	),
	exp.add_virtual_instance(
		"edge1",
		EdgeResourceModel(max_cu=edge_cu, max_mu=edge_mu)
	)
]

server = exp.create_server(
	"server",
	HardwareResources(cu=server_cu, mu=server_mu),
	LinkResources(bw=server_bw),
)

devices = exp.create_devices(
	"pi3",
	HardwareResources(cu=pi3_cu, mu=pi3_mu),
	LinkResources(bw=pi3_bw),
	num_devices
)

exp.add_docker(server, cloud)
for i, device in enumerate(devices): 
    exp.add_docker(device, edges[0] if i % 2 == 0 else edges[1])

worker = exp.add_worker("127.0.0.1", port=5000)
worker.add(cloud)
for edge in edges:
	worker.add(edge)
	worker.add_link(cloud, edge)

try:
	exp.start()
except Exception as ex: 
	print(ex)
finally:
	exp.stop()
