"""
Tools for working with the validated-llm framework.
"""
