from natlog.test.benchmark import *

if __name__ == "__main__":
    run_all()
