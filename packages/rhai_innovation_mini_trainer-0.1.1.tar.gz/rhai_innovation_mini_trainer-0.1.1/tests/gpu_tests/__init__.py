"""GPU-based tests for mini_trainer.

These tests require CUDA and flash-attention to be installed.
They are designed to help diagnose training accuracy issues.
"""
