"""Exceptions for the datacosmos package."""
