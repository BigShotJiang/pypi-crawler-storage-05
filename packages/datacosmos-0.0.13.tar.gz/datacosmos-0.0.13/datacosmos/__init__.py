"""A library for interacting with DataCosmos from Python code."""
