"""Dataclasses for the uploader module."""
