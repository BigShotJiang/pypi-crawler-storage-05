"""Models for the Collection Client."""
