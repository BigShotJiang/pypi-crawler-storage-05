"""Models for configuration settings."""
