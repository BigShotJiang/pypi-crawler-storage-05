"""Configuration package for the Datacosmos SDK.

This package includes modules for loading and managing authentication
configurations.
"""
