__version__ = "0.2.1"

__all_plugins__ = ["compas_masonry.scene"]
