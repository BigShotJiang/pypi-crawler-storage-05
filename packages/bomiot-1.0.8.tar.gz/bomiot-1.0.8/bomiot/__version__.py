VERSION = (1, 0, '8')

__version__ = '.'.join(map(str, VERSION))


def version(): return __version__
