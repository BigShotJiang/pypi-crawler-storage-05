The following organizations or individuals have contributed to this repo:

- Shivam Sandbhor @sbs2001
- Philippe Ombredanne @pombredanne
- Hritik Vijay @Hritik14
- Tushar Goel @TG1999
- Keshav Priyadarshi @keshav-space
- Chin-Yeung Li @chinyeungli
- Ayan Sinha Mahapatra @AyanSinhaMahapatra
- Jono Yang @JonoYang

Plus 100+ contributors that created the underlying and bundled version handling
utilities.