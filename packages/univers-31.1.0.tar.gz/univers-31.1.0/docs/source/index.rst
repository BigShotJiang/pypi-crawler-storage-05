Welcome to nexb-skeleton's documentation!
=========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   skeleton-usage
   contribute/contrib_doc

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
