# SPDX-FileCopyrightText: 2023 Espressif Systems (Shanghai) CO LTD
# SPDX-License-Identifier: Apache-2.0

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
