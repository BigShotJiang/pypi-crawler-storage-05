from tautulli.tools.webhooks.base import (
    TautulliWebhookTrigger,
    TautulliWebhook,
)
