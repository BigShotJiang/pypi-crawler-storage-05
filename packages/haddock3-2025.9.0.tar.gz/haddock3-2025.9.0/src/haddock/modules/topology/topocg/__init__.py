"""Create and manage CNS coarse-grained-atom topology.

This module is under development...
"""
# to be developed
# adding dummy interfaces to pass the tests
from pathlib import Path

from haddock.core.defaults import MODULE_DEFAULT_YAML

RECIPE_PATH = Path(__file__).resolve().parent
DEFAULT_CONFIG = Path(RECIPE_PATH, MODULE_DEFAULT_YAML)
