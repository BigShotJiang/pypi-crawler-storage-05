"""
HADDOCK3 extra modules.

The extra modules are modules that do not belong to any of the standard
simulation categories but that help further configuring the workflow.
"""
