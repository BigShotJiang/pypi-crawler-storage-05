# Citing

Cite HADDOCK3 with the following:

1. HADDOCK3, Bonvin's Lab, https://github.com/haddocking/haddock3, 2022.
2. Dominguez, C., Boelens, R. & Bonvin, A. M. J. J. HADDOCK: a protein-protein docking approach based on biochemical or biophysical information. J Am Chem Soc 125, 1731–1737 (2003).

Developed with financial support from the Horizon 2020 [BioExcel CoE](https://www.bioexcel.eu) project [823830](https://cordis.europa.eu/project/id/823830)
