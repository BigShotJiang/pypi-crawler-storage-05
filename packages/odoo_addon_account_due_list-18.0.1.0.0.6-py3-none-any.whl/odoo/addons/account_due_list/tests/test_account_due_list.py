from odoo.tests import common


class TestAccountDueList(common.TransactionCase):
    def test_account_due_list(self):
        pass
