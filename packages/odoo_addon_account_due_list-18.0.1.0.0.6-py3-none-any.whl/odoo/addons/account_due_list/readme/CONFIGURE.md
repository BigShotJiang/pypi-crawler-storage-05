To use this module, you need to:

1.  Activate developer mode.
2.  Go to *Settings \> Users & Companies \> Groups*.
3.  Search for and choose "Technical / Show Full Accounting Features".
4.  Edit it, and add your user on the "Users" tab
