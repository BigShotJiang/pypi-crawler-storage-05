# sage_setup: distribution = sagemath-tdlib
# delvewheel: patch
