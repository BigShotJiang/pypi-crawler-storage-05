# coding: utf-8

from snaptrade_client.apis.tags.trading_api_generated import TradingApiGenerated

class TradingApi(TradingApiGenerated):
    pass
