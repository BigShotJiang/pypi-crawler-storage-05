# coding: utf-8

from snaptrade_client.apis.tags.authentication_api_generated import AuthenticationApiGenerated

class AuthenticationApi(AuthenticationApiGenerated):
    pass
