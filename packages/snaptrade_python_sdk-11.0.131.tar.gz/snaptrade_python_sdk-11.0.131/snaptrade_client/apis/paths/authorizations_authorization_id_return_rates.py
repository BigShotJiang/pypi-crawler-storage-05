from snaptrade_client.paths.authorizations_authorization_id_return_rates.get import ApiForget


class AuthorizationsAuthorizationIdReturnRates(
    ApiForget,
):
    pass
