from snaptrade_client.paths.symbols.post import ApiForpost


class Symbols(
    ApiForpost,
):
    pass
