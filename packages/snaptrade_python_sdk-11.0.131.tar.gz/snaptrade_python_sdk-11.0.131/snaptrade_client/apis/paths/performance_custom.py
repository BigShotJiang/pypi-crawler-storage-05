from snaptrade_client.paths.performance_custom.get import ApiForget


class PerformanceCustom(
    ApiForget,
):
    pass
