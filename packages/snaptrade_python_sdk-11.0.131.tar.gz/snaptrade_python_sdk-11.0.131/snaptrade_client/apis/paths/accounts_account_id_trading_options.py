from snaptrade_client.paths.accounts_account_id_trading_options.post import ApiForpost


class AccountsAccountIdTradingOptions(
    ApiForpost,
):
    pass
