from snaptrade_client.paths.activities.get import ApiForget


class Activities(
    ApiForget,
):
    pass
