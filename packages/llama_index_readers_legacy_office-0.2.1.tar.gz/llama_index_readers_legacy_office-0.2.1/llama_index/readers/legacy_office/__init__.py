"""Legacy Office Reader for LlamaIndex."""

from llama_index.readers.legacy_office.reader import LegacyOfficeReader

__all__ = ["LegacyOfficeReader"]
