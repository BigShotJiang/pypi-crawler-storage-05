from __future__ import annotations

import json
import os
from typing import Dict, List, Optional

from .features import to_feature_vector
from .model import ID_TO_LABEL
from .config import get_artifacts_dir

_FAST_MODEL: Optional[Dict] = None
_FAST_MODEL_PATH: Optional[str] = None


def _get_default_fast_model_path() -> str:
    return os.path.join(get_artifacts_dir(), "forest.json")


def load_fast_model(path: Optional[str] = None) -> Dict:
    global _FAST_MODEL, _FAST_MODEL_PATH
    use_path = path or _get_default_fast_model_path()
    if _FAST_MODEL is None or _FAST_MODEL_PATH != use_path:
        with open(use_path, "r") as f:
            _FAST_MODEL = json.load(f)
        _FAST_MODEL_PATH = use_path
    return _FAST_MODEL  # type: ignore[return-value]


def _tree_predict(tree: Dict, x: List[float]) -> int:
    nodes = tree["nodes"]
    i = 0
    while True:
        node = nodes[i]
        if "value" in node:
            vec: List[float] = node["value"]
            return int(max(range(len(vec)), key=lambda k: vec[k]))
        feat = node["feature"]
        thr = node["threshold"]
        left = node["left"]
        right = node["right"]
        i = left if x[feat] <= thr else right


def predict_fast(props: Dict[str, float], *, model_path: Optional[str] = None) -> str:
    fm = load_fast_model(model_path)
    x = to_feature_vector(props)
    votes: List[int] = []
    for tree in fm["trees"]:
        votes.append(_tree_predict(tree, x))
    if not votes:
        return "timsort"
    counts: Dict[int, int] = {}
    for v in votes:
        counts[v] = counts.get(v, 0) + 1
    best_id = max(counts.items(), key=lambda kv: kv[1])[0]
    return ID_TO_LABEL[int(best_id)]
