from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
from sklearn.ensemble import RandomForestClassifier

from .model import LABELS


def export_forest(model: RandomForestClassifier) -> dict:
    trees = []
    for est in model.estimators_:
        t = est.tree_
        nodes = []
        for i in range(t.node_count):
            if t.children_left[i] == -1 and t.children_right[i] == -1:
                value = t.value[i][0].tolist()
                nodes.append({"value": value})
            else:
                nodes.append({
                    "feature": int(t.feature[i]),
                    "threshold": float(t.threshold[i]),
                    "left": int(t.children_left[i]),
                    "right": int(t.children_right[i]),
                })
        trees.append({"nodes": nodes})
    return {"label_names": LABELS, "trees": trees}


def main():
    p = argparse.ArgumentParser(description="Export sklearn RandomForest to fast JSON format")
    p.add_argument("--model", required=True, help="Path to model.joblib")
    p.add_argument("--out", required=True, help="Path to write forest.json")
    args = p.parse_args()

    model: RandomForestClassifier = joblib.load(args.model)
    spec = export_forest(model)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(spec))
    print(f"Wrote {args.out}")  # noqa: T201


if __name__ == "__main__":
    main()
