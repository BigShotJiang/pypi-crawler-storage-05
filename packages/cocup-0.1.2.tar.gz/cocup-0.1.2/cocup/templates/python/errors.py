'''
custom errors for {project_name}
'''
class {capitalised_project_name}Error(Exception):
    '''General class of errors unique to {project_name}'''
    pass
