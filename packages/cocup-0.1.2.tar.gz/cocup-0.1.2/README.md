# Thom's COokie CUtter for Python (CoCuP)

## Description
A 'cookie cutter' to create a blank template for a python package in the target directory.

`cocup` will create a skeleton Python package with the following architechture:

```
my_package/
├── setup.py
├── LICENSE
├── README.md
├── .gitignore
├── my_package/
│   ├── __init__.py
│   ├── __main__.py
│   ├── main.py
│   ├── parser/
│   │   ├── __init__.py
│   │   └── parser.py
│   ├── utils/
│   │   ├── __init__.py
│   │   └── errors.py
├── example_data/
│   ├── example_in/
│   └── example_out/
└── tests/
```
Minimal scripts will be generated to produce a functioning skeleton package with a simple parser and basic logging functions.

## Installation
Either clone this repository, or download and install with PyPI:

`pip install cocup`

## Usage
### Minimal Usage
At minimum `cocup` requires two positional arguments: the project name and description. 
For example, to create a package called `my_package`, navigate to an empty directory and run:

`cocup my_package 'a description of my package'`

**IMPORTANT:** By default, `cocup` creates a GPL3.0 license for the package. If you want to use a different license,
you can either select a different license with `-l`, or delete this license and replace it with you own. **You alone
are responsible for licensing your software!** You have been warned!

### Recommended Usage
I recommend to use `cocup` with additional parameters to help you populate the package with information about the author.
Specifically:

`cocup my_package 'a description of my package' -a 'John Smith' -e john.smith@email.com`

### Other Parameters
There are a few other parameters that might be useful:

`-l` change the license, **IMPORTANT:** Defaults to GPL3.0, see above.

`-r` add requirements to the setup.py (e.g. `-r numpy,matplotlib`)

`-h` print the help text for the parser

## Citation
None - go crazy!

## Version Log
- 0.1.0 
  - initial version
- 0.1.1
  - fixed a bug when creating a setup.py with no requirements
- 0.1.2 
  - fixed printing and logging errors in main.py template
  - fixed inconsistent indentation in parser.py template
