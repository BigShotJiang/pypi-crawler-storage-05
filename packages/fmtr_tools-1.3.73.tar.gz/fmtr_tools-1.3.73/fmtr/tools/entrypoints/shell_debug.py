def main():
    """

    Start debugger

    """
    from fmtr.tools import debug
    debug.debug_shell()
