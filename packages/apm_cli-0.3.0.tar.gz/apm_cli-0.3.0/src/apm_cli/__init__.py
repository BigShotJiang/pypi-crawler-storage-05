"""APM-CLI package."""

from .version import get_version

__version__ = get_version()
