"""Package entry point for python -m purl2notices."""

from .cli import main

if __name__ == '__main__':
    main()