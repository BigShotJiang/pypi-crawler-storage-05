from sinch.core.exceptions import SinchException


class ConversationException(SinchException):
    pass
