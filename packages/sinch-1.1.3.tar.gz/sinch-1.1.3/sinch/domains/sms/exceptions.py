from sinch.core.exceptions import SinchException


class SMSException(SinchException):
    pass
