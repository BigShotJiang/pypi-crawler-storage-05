from sinch.core.exceptions import SinchException


class VoiceException(SinchException):
    pass
