from sinch.core.exceptions import SinchException


class VerificationException(SinchException):
    pass
