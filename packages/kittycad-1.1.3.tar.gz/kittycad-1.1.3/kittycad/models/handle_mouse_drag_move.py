from .base import KittyCadBaseModel


class HandleMouseDragMove(KittyCadBaseModel):
    """The response from the `HandleMouseDragMove` endpoint."""
