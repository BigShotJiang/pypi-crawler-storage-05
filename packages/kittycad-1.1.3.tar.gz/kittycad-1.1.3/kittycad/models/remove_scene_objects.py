from .base import KittyCadBaseModel


class RemoveSceneObjects(KittyCadBaseModel):
    """The response from the `RemoveSceneObjects` endpoint."""
