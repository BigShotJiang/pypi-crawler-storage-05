from .base import KittyCadBaseModel


class HighlightSetEntities(KittyCadBaseModel):
    """The response from the `HighlightSetEntities` endpoint."""
