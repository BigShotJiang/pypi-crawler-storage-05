from .base import KittyCadBaseModel


class DisableDryRun(KittyCadBaseModel):
    """The response from the `DisableDryRun` endpoint."""
