from .base import KittyCadBaseModel


class MakePlane(KittyCadBaseModel):
    """The response from the `MakePlane` endpoint."""
