from .base import KittyCadBaseModel


class DefaultCameraLookAt(KittyCadBaseModel):
    """The response from the `DefaultCameraLookAt` endpoint."""
