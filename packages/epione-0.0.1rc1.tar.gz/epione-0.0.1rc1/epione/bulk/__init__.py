from ._bigwig import bigwig,plot_matrix,plot_matrix_line,plotloc
from ._getScorePerBigWigBin import *
