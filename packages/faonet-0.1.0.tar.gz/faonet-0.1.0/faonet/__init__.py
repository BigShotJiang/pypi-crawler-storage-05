# FAONet package initialization
