import sys
import os

# 获取当前包的目录路径
package_dir = os.path.dirname(__file__)

# 将包的顶层目录添加到sys.path
sys.path.append(package_dir)
