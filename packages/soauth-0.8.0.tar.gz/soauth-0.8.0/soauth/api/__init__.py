"""
Core endpoints for generating and managing keys.
"""
