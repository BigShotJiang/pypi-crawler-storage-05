## 13.0.1.0.0

- \[MIG\] Port account_spread_cost_revenue to V13.

## 12.0.2.0.0

- \[ENH\] In spread template, add option to auto create spread on
  invoice validation

## 12.0.1.1.0

- \[ENH\] Add optional Expense/Revenue Account in Chart Template, which
  can be used in place of account from invoice line to set
  Expense/Revenue account in the spread

## 12.0.1.0.0

- \[MIG\] Port account_spread_cost_revenue to V12.

## 11.0.1.0.0

- \[ADD\] Module account_spread_cost_revenue.
  ([\#715](https://github.com/OCA/account-financial-tools/pull/715))
