Part of the code in this module (in particular the computation of the
spread lines) is highly inspired by the Assets Management module from
the standard Odoo 11.0 Community developed by Odoo SA.
