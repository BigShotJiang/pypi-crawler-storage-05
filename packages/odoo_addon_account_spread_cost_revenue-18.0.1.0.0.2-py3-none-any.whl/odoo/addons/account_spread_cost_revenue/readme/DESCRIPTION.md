Allows to spread costs or revenues over a customizable periods, to even
out cost or invoice spikes.
