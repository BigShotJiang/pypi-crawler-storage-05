from .mapper import map_vulnerabilities

__all__ = ["map_vulnerabilities"]
