|pypi| |actions| |codecov| |downloads|

edc_csf
-------

.. |pypi| image:: https://img.shields.io/pypi/v/edc-csf.svg
    :target: https://pypi.python.org/pypi/edc-csf

.. |actions| image:: https://github.com/clinicedc/edc-csf/actions/workflows/build.yml/badge.svg
  :target: https://github.com/clinicedc/edc-csf/actions/workflows/build.yml

.. |codecov| image:: https://codecov.io/gh/clinicedc/edc-csf/branch/develop/graph/badge.svg
  :target: https://codecov.io/gh/clinicedc/edc-csf

.. |downloads| image:: https://pepy.tech/badge/edc-csf
   :target: https://pepy.tech/project/edc-csf
