# AlgoSec AppViz Python Library

Unofficial library to interract with AlgoSec AppViz in Python.

## Installation

```shell
$ pip install algosec_appviz
```
