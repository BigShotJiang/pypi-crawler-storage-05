# src/indexly/__main__.py

from .indexly import main  # relative import

if __name__ == "__main__":
    main()
