# m-tecConnectOPC-UA

OPC-UA client classes for m-tec machines (Mixingpump, Printhead, Dosingpump).

## Installation

```bash
pip install m-tecConnectOPC-UA
```

## Usage

```python
from m-tecConnectOPC-UA import Mixingpump, Printhead, Dosingpump

# Example usage
mp = Mixingpump()
mp.connect("opc.tcp://10.129.4.73:4840")
mp.running = True
print(mp.real_speed)
```

## Requirements
- Python >= 3.7
- asyncua >= 1.0.0

## License
MIT
