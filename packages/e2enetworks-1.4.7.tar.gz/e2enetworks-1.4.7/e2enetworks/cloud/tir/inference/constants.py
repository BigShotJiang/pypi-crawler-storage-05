# Model constants
INVALID_MODEL_ID = "Invalid Model Id"
MODEL_LOAD_ERROR = "Failed to load model with ID {model_id} from path {local_path}: {error_message}"
