# =====================================
# generator=datazen
# version=3.2.3
# hash=f2ca2fce4efce471320e489ab653a86a
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "Read the sign."
PKG_NAME = "experimental-lowqa"
VERSION = "0.1.9"
