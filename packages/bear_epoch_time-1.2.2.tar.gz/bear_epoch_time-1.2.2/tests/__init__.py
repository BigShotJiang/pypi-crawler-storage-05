"""Test package for bear-epoch-time.

This package contains test modules for the bear-epoch-time library.
"""
