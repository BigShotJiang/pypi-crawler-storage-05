"""Cable modem hardware template."""

from boardfarm3.templates.cpe import CPEHW


class CableModemHW(CPEHW):
    """Cable modem hardware template."""
