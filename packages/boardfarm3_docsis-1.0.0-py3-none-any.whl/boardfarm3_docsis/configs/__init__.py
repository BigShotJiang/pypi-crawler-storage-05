"""Boardfarm DOCSIS configs module."""

from pathlib import Path

DOCSIS_DEVICE_MIBS_PATH = str((Path(__file__).parent / "mibs").resolve())
