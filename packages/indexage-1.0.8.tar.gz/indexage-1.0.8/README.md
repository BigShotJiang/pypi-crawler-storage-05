# indexage

Create apache2-like html index

## Usage

```bash
python -m pip install indexage

python -m indexage .
```

## License

- [MIT](LICENSE)
