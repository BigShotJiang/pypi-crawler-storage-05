"""main module"""

from .lib import create_html_index  # noqa: F401
