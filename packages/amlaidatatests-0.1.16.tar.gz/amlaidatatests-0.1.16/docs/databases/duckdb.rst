======
DuckDB
======

`DuckDB <https://duckdb.org/docs/installation/?version=stable>`_ is used for
unittesting the amlaidatatests tool. It is not supported for production use.

Using duckdb
============

duckdb is an optional requirement. To use duckdb, run:
``pip install amlaidatatests[duckdb]``

Connection String
=================

``duckdb://my-project/my-dataset``
