=====
About
=====

``amlaidatatests`` is developed by `GroundtruthAI <https://groundtruthai.net/>`_
who specialize in Google's AML AI API.


The source code is available `on github
<https://github.com/ground-truth-ai/amlaidatatests/tree/main>`_.

Feature requests and support
----------------------------

Please raise any feature requests or support issues on the project's `issues
page on github <https://github.com/ground-truth-ai/amlaidatatests/issues>`_.

If you cannot use github, we have a mailing list:

``amlaidatatests -ampersand symbol- groundtruthai.net``

Licence
-------

``amlaidatatests`` is `licensed under the Apache Licence, version 2.0
<https://github.com/ground-truth-ai/amlaidatatests/blob/main/LICENSE.md>`_.
