-- Tests: transaction.type
-- Severity: ERROR
-- Description: Field is constrained to permitted enumerations
SELECT
  COUNT(*) AS "CountStar()"
FROM (
  SELECT
    "t0"."type" AS "field"
  FROM "PLACEHOLDER"."transaction" AS "t0"
  WHERE
    NOT (
      "t0"."type" IN ('WIRE', 'CASH', 'CHECK', 'CARD', 'OTHER')
    )
) AS "t1"
