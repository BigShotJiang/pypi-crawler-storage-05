"""Version information for claude-code-supervisor package."""

__version__ = '0.3.1'
__author__ = 'Vinícius Trevisan'
__email__ = 'vinicius@viniciustrevisan.com'
__description__ = (
  'An intelligent wrapper around Claude Code SDK for automated problem-solving'
)
