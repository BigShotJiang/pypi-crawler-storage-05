## v0.1.1rc40 (September 09, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc39...v0.1.1rc40

### Features

- add retain_local_copy option to upload methods in ObjectStore (#691) (by @Mustafa in [38285f0](https://github.com/atlanhq/application-sdk/commit/38285f0))
- enhance bugbot rules (#681) (by @AdvitXAtlan in [546d23f](https://github.com/atlanhq/application-sdk/commit/546d23f))

### Bug Fixes

- make sql client use context managers (#699) (by @Nishchith Shetty in [211f31b](https://github.com/atlanhq/application-sdk/commit/211f31b))
