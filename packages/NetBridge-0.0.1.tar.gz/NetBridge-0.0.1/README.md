# NetBridge

Biblioteca Python para iniciantes que permite a Comunicação interProgramas Locais ou Remotos.

## Instalação

```bash
pip install NetBridge