"""
Core functionality for SU2GUI.
"""
