"""Job CLI commands."""

import click


def register_commands(group: click.Group) -> None:
    """Register job commands with the given group."""
