from .base import KittyCadBaseModel


class SetSelectionType(KittyCadBaseModel):
    """The response from the `SetSelectionType` endpoint."""
