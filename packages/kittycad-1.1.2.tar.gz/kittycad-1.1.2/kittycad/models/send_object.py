from .base import KittyCadBaseModel


class SendObject(KittyCadBaseModel):
    """The response from the `SendObject` endpoint."""
