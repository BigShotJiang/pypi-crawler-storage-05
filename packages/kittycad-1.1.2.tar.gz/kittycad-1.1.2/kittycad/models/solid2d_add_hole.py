from .base import KittyCadBaseModel


class Solid2dAddHole(KittyCadBaseModel):
    """The response from the `Solid2dAddHole` endpoint."""
