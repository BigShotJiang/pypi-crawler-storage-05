from .base import KittyCadBaseModel


class SelectReplace(KittyCadBaseModel):
    """The response from the `SelectReplace` endpoint."""
