from .base import KittyCadBaseModel


class UpdateAnnotation(KittyCadBaseModel):
    """The response from the `UpdateAnnotation` endpoint."""
