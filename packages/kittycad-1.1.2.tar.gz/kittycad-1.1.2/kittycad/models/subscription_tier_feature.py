from .base import KittyCadBaseModel


class SubscriptionTierFeature(KittyCadBaseModel):
    """A subscription tier feature."""

    info: str
