from .base import KittyCadBaseModel


class Solid3dFilletEdge(KittyCadBaseModel):
    """The response from the `Solid3dFilletEdge` endpoint."""
