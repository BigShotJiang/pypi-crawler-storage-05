from .base import KittyCadBaseModel


class SetDefaultSystemProperties(KittyCadBaseModel):
    """The response from the `SetDefaultSystemProperties` endpoint."""
