from .base import KittyCadBaseModel


class Extrude(KittyCadBaseModel):
    """The response from the `Extrude` endpoint."""
