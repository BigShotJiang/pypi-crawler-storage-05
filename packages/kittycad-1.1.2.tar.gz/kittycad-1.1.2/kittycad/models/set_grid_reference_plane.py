from .base import KittyCadBaseModel


class SetGridReferencePlane(KittyCadBaseModel):
    """The response from the 'SetGridReferencePlane'."""
