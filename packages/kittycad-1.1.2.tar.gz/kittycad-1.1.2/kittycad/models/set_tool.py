from .base import KittyCadBaseModel


class SetTool(KittyCadBaseModel):
    """The response from the `SetTool` endpoint."""
