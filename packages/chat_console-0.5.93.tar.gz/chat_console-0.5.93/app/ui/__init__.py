"""UI components for the terminal chat application."""
