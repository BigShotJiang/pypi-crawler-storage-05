"""
text2mol - Memory Operating Language

A language designed for memory operations within the text2memory ecosystem.
"""

__version__ = '0.1.0'
