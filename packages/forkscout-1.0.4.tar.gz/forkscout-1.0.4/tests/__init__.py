"""Test package for Forklift application."""
