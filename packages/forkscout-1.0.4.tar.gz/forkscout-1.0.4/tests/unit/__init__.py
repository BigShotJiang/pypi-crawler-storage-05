"""Unit tests for Forklift application."""
