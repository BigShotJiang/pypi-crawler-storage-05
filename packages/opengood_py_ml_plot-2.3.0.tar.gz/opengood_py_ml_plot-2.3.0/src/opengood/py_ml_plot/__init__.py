from .classification_plot import setup_classification_plot

__all__ = ["setup_classification_plot"]

print("opengood.py_ml_plot imported")
