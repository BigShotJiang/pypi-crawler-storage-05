Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ble_midi_simpletest.py
    :caption: examples/ble_midi_simpletest.py
    :linenos:
