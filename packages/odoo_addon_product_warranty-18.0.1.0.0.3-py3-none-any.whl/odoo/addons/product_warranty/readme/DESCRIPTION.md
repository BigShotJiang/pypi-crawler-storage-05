This module extends the functionality of 'Sales Management' to allows
you to set product warranty details on products and product-supplier
relation.
