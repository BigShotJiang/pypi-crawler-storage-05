To use this module, you need to:

1.  Go to *Sales \> Products \> Products (or Product Variants)*
2.  Create a new product (or product variant) or edit an existing one
    and set 'Warranty Duration' under 'Sales' tab.
3.  If 'Purchase' module is installed, got to *Sales \> Products \>
    Products (or Product Variants)*, go to 'Purchase' tab, edit supplier
    information lines an set the warranty information for each one.
