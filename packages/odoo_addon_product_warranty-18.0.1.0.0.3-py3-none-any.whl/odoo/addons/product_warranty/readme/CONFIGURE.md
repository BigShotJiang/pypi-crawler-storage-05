To manage the available return instructions, enable debug mode and go to
*Sales -\> Configuration -\> Product Return Instructions*.
