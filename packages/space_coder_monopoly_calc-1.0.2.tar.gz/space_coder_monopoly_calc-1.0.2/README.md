# Calculator!!!

To run, simply install the package, `pip install space-coder-monopoly-calc` and then run `python3 -m calc`.

If it fails, you should see if the error mentions installing python from the microsoft store. If so, you should try running `python.exe -m calc` or installing python from the microsoft store, and trying again.

To install from the Microsoft Store, open the store, search python, and install 'python 3.13' or you can try going here: https://apps.microsoft.com/detail/9PNRBTZXMB4Z?hl=en-us&gl=CA&ocid=pdpshare. Click 'view in store' and then install it.