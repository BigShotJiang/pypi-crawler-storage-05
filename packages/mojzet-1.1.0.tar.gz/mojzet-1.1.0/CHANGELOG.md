# Zet Changelog

## 1.1.0 (2025-07-12)

* Add `trip-stops` command
* Add `trips --route` option
* Add `route-trips --direction` option
* Handle HTTP errors

## 1.0.0 (2025-07-10)

* Initial release
