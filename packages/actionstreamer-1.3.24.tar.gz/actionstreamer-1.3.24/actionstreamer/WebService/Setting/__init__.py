from .Setting import get_device_setting, update_device_setting


__all__ = ['get_device_setting', 'update_device_setting']
