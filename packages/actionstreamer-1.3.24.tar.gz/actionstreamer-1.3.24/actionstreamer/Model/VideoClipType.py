
from enum import Enum


class VideoClipType(Enum):

    Original_clip = 1
    Concatenated_clip = 2
    Extracted_clip = 3