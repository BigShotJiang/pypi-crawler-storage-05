primary_colors=['#D95B6F','#42A399','#E1AE38']
ReIm_colors = ['#D61B00','#00BBD6']
shade_colors=[]
