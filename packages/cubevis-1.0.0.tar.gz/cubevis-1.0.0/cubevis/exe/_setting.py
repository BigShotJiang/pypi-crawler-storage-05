from enum import Enum

class Setting(Enum):
    CLI = "python_cli"
