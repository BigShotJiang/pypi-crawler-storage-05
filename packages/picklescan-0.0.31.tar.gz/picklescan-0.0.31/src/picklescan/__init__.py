import logging

logging.getLogger("picklescan").addHandler(logging.NullHandler())
