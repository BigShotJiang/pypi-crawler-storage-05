# __init__.py
from .main import encrypt_file, decrypt_file

__all__ = ["encrypt_file", "decrypt_file"]
__version__ = "0.1.0"