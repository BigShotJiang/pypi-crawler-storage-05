"""Sketchup integration through Model Context Protocol"""

__version__ = "0.1.17"

# Expose key classes and functions for easier imports
from .server import mcp 