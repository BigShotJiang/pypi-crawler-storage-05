rm -r ./build
rm -r ./dist
rm -r ./piper_sdk.egg-info