"""Group3 Raise SystemExit('message')."""


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    raise SystemExit("message")
