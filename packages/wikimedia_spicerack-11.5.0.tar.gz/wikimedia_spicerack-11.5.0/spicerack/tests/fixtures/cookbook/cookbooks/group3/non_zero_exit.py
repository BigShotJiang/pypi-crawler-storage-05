"""Group3 Non-Zero return code."""


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
    return 1
