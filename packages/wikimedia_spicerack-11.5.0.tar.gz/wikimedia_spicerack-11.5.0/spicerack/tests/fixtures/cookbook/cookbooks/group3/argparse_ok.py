"""Group3 argparse_ok."""

import argparse

__owner_team__ = "team1"


def argument_parser():
    """As required by spicerack._cookbook."""
    return argparse.ArgumentParser("group3.argparse_ok")


def run(_args, _spicerack):
    """As required by spicerack._cookbook."""
