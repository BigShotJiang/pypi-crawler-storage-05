"""Group3 Invalid Subgroup Test Cookbooks."""
invalid =  # noqa: E999
