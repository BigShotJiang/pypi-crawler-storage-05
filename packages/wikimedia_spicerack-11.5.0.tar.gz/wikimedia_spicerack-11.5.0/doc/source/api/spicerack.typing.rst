typing
======

.. automodule:: spicerack.typing
