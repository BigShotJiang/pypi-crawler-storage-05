from .wikis import (
    ContentObjectWikiArticleButtonConfig,
    WikiArticleRelationshipButtonConfig,
)
