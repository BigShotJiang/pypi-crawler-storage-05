# Authors

## Project Lead

- GoTLiuM InSPiRiT ([@gotlium](https://github.com/gotlium))

## Special Thanks

- Company SmsAero for providing resources
- All the users who reported bugs and provided feedback
