AEPyBaMM is written and maintained by [About:Energy](https://www.aboutenergy.io/). 

Please contribute by providing feedback, comments, and bug reports through the GitHub issues for this repository: https://github.com/About-Energy-OpenSource/AEPyBaMM/issues

Please contact About:Energy directly to report any issues associated with proprietary parameter sets.

In future we may consider community contributions to source code, or identify routes for the community to support deprecating AEPyBaMM features by including them in the base [PyBaMM](https://pybamm.org) library.
