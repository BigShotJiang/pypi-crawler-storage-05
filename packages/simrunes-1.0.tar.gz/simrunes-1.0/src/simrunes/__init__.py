import asyncio

from simrunes.core import start


def main() -> None:
    asyncio.run(start())
