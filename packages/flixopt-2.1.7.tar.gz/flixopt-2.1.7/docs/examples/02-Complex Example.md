# Complex example
This saves the results of a calculation to file and reloads them to analyze the results
## Build the Model
```python
{! ../examples/02_Complex/complex_example.py !}
```
## Load the Results from file
```python
{! ../examples/02_Complex/complex_example_results.py !}
```
