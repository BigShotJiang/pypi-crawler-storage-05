import unittest

# from src.wrappers import HttpRequest, HttpResponse


class TestRequestWrapper(unittest.TestCase):
    def setUp(self):
        pass

    def test_case1(self):
        pass


class TestResponseWrapper(unittest.TestCase):
    def setUp(self):
        pass

    def test_case1(self):
        pass
