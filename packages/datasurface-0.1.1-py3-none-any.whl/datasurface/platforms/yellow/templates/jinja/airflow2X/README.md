This folder contains the jinja2 templates for an airflow 2.x version and a conventional kubernetes environment.
