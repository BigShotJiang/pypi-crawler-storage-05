This folder contains the jinja2 templates for an airflow 2.x version in an AWS environment with EKS, EFS, and ECR.
