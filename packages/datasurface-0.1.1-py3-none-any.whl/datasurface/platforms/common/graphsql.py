"""
// Copyright (c) William Newport
// SPDX-License-Identifier: BUSL-1.1
"""
