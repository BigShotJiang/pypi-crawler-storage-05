"""RAMSES RF - a RAMSES-II protocol decoder & analyser (transport layer)."""

__version__ = "0.51.5"
VERSION = __version__
