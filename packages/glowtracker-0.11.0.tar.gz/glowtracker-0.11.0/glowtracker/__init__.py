# This acts as an entry point for a convenient executable script
def initApp():
    from . import __main__