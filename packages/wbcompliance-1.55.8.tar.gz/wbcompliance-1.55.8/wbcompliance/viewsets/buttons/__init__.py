from .compliance_form import (
    ComplianceFormButtonConfig,
    ComplianceFormSignatureButtonConfig,
)
from .compliance_task import (
    ComplianceTaskButtonConfig,
    ReviewComplianceTaskButtonConfig,
)
from .risk_managment import *
