"""Entry point for DevMatch CLI when run as a module."""

from .cli import main

if __name__ == "__main__":
    main()