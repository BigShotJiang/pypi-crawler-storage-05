"""DevMatch CLI - A minimal developer collaborative platform client."""

__version__ = "0.1.0"
__author__ = "DevMatch Team"
__description__ = "A minimal developer collaborative platform "