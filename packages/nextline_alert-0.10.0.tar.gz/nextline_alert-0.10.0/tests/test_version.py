import nextline_alert


def test_version():
    '''Confirm that the version string is attached to the module'''
    nextline_alert.__version__
