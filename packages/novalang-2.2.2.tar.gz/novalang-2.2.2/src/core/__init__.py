# NovaLang Core Components
