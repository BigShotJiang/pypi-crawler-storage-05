Allow to propagate a lot number from a component to a finished product.
