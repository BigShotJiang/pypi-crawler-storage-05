# lbt-honeybee

Collection of all Honeybee core Python libraries.

Note that this Python package does not contain any code and it simply exists to
provide a shortcut for installing all of the honeybee Python libraries together.
