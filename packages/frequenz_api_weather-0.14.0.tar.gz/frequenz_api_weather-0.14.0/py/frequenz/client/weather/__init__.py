# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Frequenz gRPC API to access weather forecasts."""
