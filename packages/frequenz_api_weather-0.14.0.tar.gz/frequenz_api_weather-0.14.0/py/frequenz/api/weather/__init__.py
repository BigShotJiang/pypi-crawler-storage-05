# License: MIT
# Copyright © 2023 Frequenz Energy-as-a-Service GmbH

"""Protobuf spec for the weather API."""
