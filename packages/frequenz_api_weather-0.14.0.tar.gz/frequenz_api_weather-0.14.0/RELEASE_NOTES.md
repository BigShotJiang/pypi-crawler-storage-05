# Frequenz Weather API Release Notes

## Summary

This release contains several updated dependencies.

## Upgrading

- Updated protobuf dependency to >= 6.31.1 and < 8. Ensure that the generated code is compatible with the new range to
   avoid cross-version incompatibilities.
- Updated frequenz-api-common package to >= 0.8.0 and < 0.9.0.

## New Features


## Bug Fixes

