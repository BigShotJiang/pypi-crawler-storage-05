============================================
 ``zope.component``: Module-level functions
============================================

This document provides a summary of the APIs available directly from
``zope.component``. For more details, see the remaining documentation.

.. These are generally explored in more detail in
   specific documentation, so default indexing should go
   to that instead of here.
.. automodule:: zope.component
   :noindex:
