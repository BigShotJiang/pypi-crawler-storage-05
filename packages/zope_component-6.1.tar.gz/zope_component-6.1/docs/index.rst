:mod:`zope.component`
=====================

Contents:

.. toctree::
   :maxdepth: 1

   changelog

.. toctree::
   :maxdepth: 2

   narr
   socketexample
   event
   factory
   persistentregistry
   zcml
   configure
   hooks
   testlayer
   api
   hacking

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
