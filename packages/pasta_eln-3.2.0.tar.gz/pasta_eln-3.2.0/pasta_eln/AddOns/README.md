# Notes on add-ons
These are very basic add-ons that allow to test the functionality and ensure that are there are a minimum number of
very well established package requirements. Typical add-ons have more complicated requirements.

Additionally, scientists should adopt, change the add-ons to their liking: hence these act as starting position.
