## 0.1.0

* Initial release: Flet-Extended-Interactive-Viewer is a Flet control that provides multiple customization options for displaying two-dimensional content.
