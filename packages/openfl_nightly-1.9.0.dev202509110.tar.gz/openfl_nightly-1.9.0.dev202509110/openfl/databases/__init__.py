# Copyright 2020-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0


from openfl.databases.persistent_db import PersistentTensorDB
from openfl.databases.tensor_db import TensorDB
