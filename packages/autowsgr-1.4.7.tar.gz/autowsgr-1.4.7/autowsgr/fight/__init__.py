from autowsgr.fight.battle import BattlePlan
from autowsgr.fight.decisive_battle import DecisiveBattle
from autowsgr.fight.exercise import NormalExercisePlan
from autowsgr.fight.normal_fight import NormalFightPlan
