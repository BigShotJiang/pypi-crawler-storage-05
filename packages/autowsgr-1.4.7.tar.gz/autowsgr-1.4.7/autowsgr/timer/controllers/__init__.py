from autowsgr.timer.controllers.android_controller import AndroidController
from autowsgr.timer.controllers.os_controller import MacController, OSController, WindowsController
