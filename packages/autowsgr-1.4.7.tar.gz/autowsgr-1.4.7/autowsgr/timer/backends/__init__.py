from autowsgr.timer.backends.ocr_backend import EasyocrBackend, OCRBackend, PaddleOCRBackend
