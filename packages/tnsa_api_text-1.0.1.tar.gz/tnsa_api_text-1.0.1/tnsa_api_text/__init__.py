"""
TNSA API Text - Minimal text generation client
"""

from .client import TNSA

__version__ = "1.0.1"
__all__ = ["TNSA"]