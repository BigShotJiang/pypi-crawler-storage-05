from .main import SatoriAdapter as SatoriAdapter
