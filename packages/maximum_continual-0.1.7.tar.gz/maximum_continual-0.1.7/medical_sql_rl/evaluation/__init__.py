"""Evaluation module for medical SQL RL environment"""
