# Tests for Maximum Continual Training library
