Changelog
=========


0.1.2 (2021-08-14)
------------------
- Fix release, README and windows CI. [Bruno Rocha]
- Release: version 0.1.0. [Bruno Rocha]


0.1.0 (2021-08-14)
------------------
- Add release command. [Bruno Rocha]
