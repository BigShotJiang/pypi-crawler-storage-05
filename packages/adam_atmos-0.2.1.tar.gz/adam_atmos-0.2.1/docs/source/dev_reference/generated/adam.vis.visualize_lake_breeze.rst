﻿adam.vis.visualize\_lake\_breeze
================================

.. currentmodule:: adam.vis

.. autofunction:: visualize_lake_breeze