# Configuration and constants
API_BASE_URL = "https://api.scrapegraphai.com/v1"
DEFAULT_HEADERS = {
    "accept": "application/json",
    "Content-Type": "application/json",
}
