"""Async API client for SEKO Pooldose."""
from .client import PooldoseClient

__version__ = "0.6.6"
__all__ = ["PooldoseClient"]
