"""claude-git - Track Claude Code changes in a shadow git worktree"""

__version__ = "0.1.0"
