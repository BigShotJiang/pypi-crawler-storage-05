# azure_carbon_tracker
A Python library that estimates the carbon emissions of the Azure Open AI service.
