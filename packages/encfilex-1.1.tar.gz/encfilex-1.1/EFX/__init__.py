# __init__.py
from .main import encrypt_file, decrypt_file

__all__ = ["encrypt_file", "decrypt_file"]
__version__ = "1.1"