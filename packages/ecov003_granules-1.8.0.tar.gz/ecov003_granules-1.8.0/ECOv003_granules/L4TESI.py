from .tiled_granule import ECOSTRESSTiledGranule

class L4TESI(ECOSTRESSTiledGranule):
    _PRIMARY_VARIABLE = "ESI"
    _PRODUCT_NAME = "L4T_ESI"
