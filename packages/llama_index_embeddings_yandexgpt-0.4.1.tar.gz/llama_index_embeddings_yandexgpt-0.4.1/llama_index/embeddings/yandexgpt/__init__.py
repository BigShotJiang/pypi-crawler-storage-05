from llama_index.embeddings.yandexgpt.base import YandexGPTEmbedding

__all__ = ["YandexGPTEmbedding"]
