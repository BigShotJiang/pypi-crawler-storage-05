try:
    from types import NoneType
except ImportError:
    NoneType = type(None)
