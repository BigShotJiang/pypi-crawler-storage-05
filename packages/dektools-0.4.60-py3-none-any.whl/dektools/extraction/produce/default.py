from .base import ProduceBase


class DefaultProduce(ProduceBase):
    pass
