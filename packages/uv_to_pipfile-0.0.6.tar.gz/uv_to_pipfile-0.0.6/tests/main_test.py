from __future__ import annotations


def test_main() -> None:
    assert True
