class StiConnectionInfo:
    """All database connection information taken from the connection string."""

    driver = ''
    host = ''
    port = 0
    database = ''
    userId = ''
    password = ''
    charset = ''
    privilege = ''