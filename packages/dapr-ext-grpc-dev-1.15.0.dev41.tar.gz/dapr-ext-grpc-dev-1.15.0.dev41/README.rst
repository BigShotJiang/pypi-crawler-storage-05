dapr-ext-grpc extension
=======================

|pypi|

.. |pypi| image:: https://badge.fury.io/py/dapr-ext-grpc.svg
   :target: https://pypi.org/project/dapr-ext-grpc/

This gRPC extension is used for gRPC appcallback

Installation
------------

::

    pip install dapr-ext-grpc

References
----------

* `Dapr <https://github.com/dapr/dapr>`_
* `Dapr Python-SDK <https://github.com/dapr/python-sdk>`_
