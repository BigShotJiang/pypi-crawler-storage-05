"""Web interface components for PromptBin."""

# Web interface will contain Flask app and assets
