"""MCP (Model Context Protocol) server implementation."""

from .server import main

__all__ = ["main"]
