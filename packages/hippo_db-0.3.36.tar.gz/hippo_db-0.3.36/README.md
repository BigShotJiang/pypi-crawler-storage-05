![hippo_logo](https://github.com/mwinokan/HIPPO/blob/main/logos/hippo_logo-05.png?raw=true)

HIPPO
=====

> 🦛 Hit Interaction Profiling for Procurement Optimisation

HIPPO is still in beta development and feedback is appreciated.

![GitHub Tag](https://img.shields.io/github/v/tag/mwinokan/hippo?include_prereleases&label=PyPI&link=https%3A%2F%2Fpypi.org%2Fproject%2Fhippo-db%2F)
![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/mwinokan/HIPPO/python-publish.yml?label=publish&link=https%3A%2F%2Fgithub.com%2Fmwinokan%2FHIPPO%2Factions%2Fworkflows%2Fpython-publish.yml)
![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/mwinokan/HIPPO/black.yml?label=lint&link=https%3A%2F%2Fgithub.com%2Fmwinokan%2FHIPPO%2Factions%2Fworkflows%2Fblack.yml)
[![Documentation Status](https://readthedocs.org/projects/hippo-db/badge/?version=latest)](https://hippo-docs.winokan.com/en/latest/?badge=latest)
![GitHub last commit](https://img.shields.io/github/last-commit/mwinokan/hippo)
![GitHub Issues or Pull Requests](https://img.shields.io/github/issues/mwinokan/hippo)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
