from django.apps import AppConfig


class Wagtail3DisplayConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wagtail_3display'
