# Basic Images for Testing

This folder contains a few safe, simple demo images you can use to test the server.
You can also add your own images here to try different augmentations.

⚠️ Please only use images you have rights to and trust
