# Rules

Get_rules shows how to get rules via API. e.g

```
python ./scripts/rules/get_rules.py --endpoint 'au' --rule-id='MATCH-S00663'
```

```
python ./scripts/get_rules.py --endpoint 'au' --query='name:contains("Cloudwatch")'
```
