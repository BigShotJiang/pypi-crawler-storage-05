"""
Command handling for the mochi-coco chat application.
"""

from .command_processor import CommandProcessor

__all__ = ["CommandProcessor"]
