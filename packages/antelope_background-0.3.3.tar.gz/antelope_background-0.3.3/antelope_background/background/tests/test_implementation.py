"""
How do we even test this?

test point: context conversion.. with synonym dict 0.2.0 that is now tuple-based; string concatenation fails
"""

