from .bm_static import TarjanBackground
from .check_terms import termination_test


class Background(TarjanBackground):
    pass


PROVIDERS = ['TarjanBackground', 'Background']
