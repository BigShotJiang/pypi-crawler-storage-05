# CDN tools

CDNtools is Xiaoyu's basic code modeling competetive protein dimerization networks, includes fast steady state calculation, dynamic ODE solving, and random network generation. All of these modules are arranged under a simple framework, using JSON files to describe reaction systems.
