# import sys
# print(sys.path)
# import sys
# sys.path.append('/Users/tangtang/opt/anaconda3/lib/python3.9/site-packages')
import AnChinSegmenter
print(AnChinSegmenter.__file__)