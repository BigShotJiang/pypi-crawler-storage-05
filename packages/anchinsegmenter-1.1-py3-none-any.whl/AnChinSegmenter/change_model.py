import torch
from pytorch_pretrained_bert import BertModel  # 原来加载用

# 加载原模型
checkpoint = torch.load("/Users/tangtang/Desktop/model.pt", map_location="cpu")

# 保存只包含 state_dict 和 spec，不包含类引用
torch.save({
    'spec': checkpoint['spec'],
    'state_dict': checkpoint['state_dict']
}, "./model/model.pt")


#上传到XuemeiTang/AnChinSegmenter-model
# from huggingface_hub import HfApi

# api = HfApi()
# repo_id = "XuemeiTang/AnChinSegmenter-model"

# api.upload_file(
#     path_or_fileobj="model.pt",  # 或 model.pt
#     path_in_repo="model.pt",  # 仓库里保存的文件名
#     repo_id=repo_id,
#     token="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"
# )

