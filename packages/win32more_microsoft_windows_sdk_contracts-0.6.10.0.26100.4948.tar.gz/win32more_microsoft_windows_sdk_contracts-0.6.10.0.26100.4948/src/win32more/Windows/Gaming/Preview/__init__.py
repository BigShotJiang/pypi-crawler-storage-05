from __future__ import annotations
from win32more.winrt.prelude import *
import win32more.Windows.Gaming.Preview
GamesEnumerationContract: UInt32 = 131072


make_ready(__name__)
