# miresearchui

Very basic user interface to project subjects.

An overview of all subjects is shown with columns: 
ID, Name, DOS, Age, Open (open allows to view subj specific data)

Click on a subject ot open to perform subject specific actions

## RUN

```bash

hurahura -UI -UI_port 8080
```

Then view at:
http://localhost:8080

