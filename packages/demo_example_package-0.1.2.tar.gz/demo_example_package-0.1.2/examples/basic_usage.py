"""Basic usage example for demo-example-package."""


def main() -> None:
    """Main function demonstrating basic usage."""


if __name__ == "__main__":
    main()
