# Changelog

## [0.1.2](https://github.com/serafinovsky/demo-example-package/compare/demo-example-package-v0.1.1...demo-example-package-v0.1.2) (2025-09-08)


### Bug Fixes

* **deps:** bump the all-pip-deps group with 4 updates ([d0ebf4a](https://github.com/serafinovsky/demo-example-package/commit/d0ebf4a7144371f6c02299865bae5a73a09c7068))
* **deps:** bump the all-pip-deps group with 4 updates ([78ebc10](https://github.com/serafinovsky/demo-example-package/commit/78ebc107f0a9149f98051ce68e566cf84e868801))

## [0.1.1](https://github.com/serafinovsky/demo-example-package/compare/demo-example-package-v0.1.0...demo-example-package-v0.1.1) (2025-09-08)


### Bug Fixes

* **deps:** bump the all-pip-deps group with 4 updates ([f94597f](https://github.com/serafinovsky/demo-example-package/commit/f94597f7eb65b08149cc083c3991ff02de43f376))
* **deps:** bump the all-pip-deps group with 4 updates ([fa7e0ed](https://github.com/serafinovsky/demo-example-package/commit/fa7e0edce58455d66f35405aba63ed9931575438))
* Test publish ([#10](https://github.com/serafinovsky/demo-example-package/issues/10)) ([b0df475](https://github.com/serafinovsky/demo-example-package/commit/b0df475093de815f7219082f7c854ef086428ab8))
