"""
CLI commands for Datacompose.
"""
