# simple_add_tesfahiwet

A simple example Python package that provides a function to add two numbers.

## Installation

```bash
pip install simple_add_tesfahiwet
```

## Usage

```python
from simple_add import add_numbers

print(add_numbers(2, 3))  # Output: 5
```
