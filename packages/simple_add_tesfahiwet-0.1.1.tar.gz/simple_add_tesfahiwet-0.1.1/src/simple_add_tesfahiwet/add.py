def add_numbers(a: int, b: int) -> int:
    """Return the sum of two numbers."""
    return a + b
