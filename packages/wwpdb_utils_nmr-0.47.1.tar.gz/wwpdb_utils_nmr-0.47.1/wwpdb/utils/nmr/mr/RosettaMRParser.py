# Generated from RosettaMRParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,64,491,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,
        5,0,84,8,0,10,0,12,0,87,9,0,1,0,1,0,1,1,1,1,5,1,93,8,1,10,1,12,1,
        96,9,1,1,1,1,1,1,2,4,2,101,8,2,11,2,12,2,102,1,3,1,3,1,3,1,3,1,3,
        1,3,1,3,1,4,4,4,113,8,4,11,4,12,4,114,1,5,1,5,1,5,1,5,1,5,1,5,1,
        5,1,5,1,5,1,6,4,6,127,8,6,11,6,12,6,128,1,7,1,7,1,7,1,7,1,7,1,7,
        1,7,1,7,1,7,1,7,1,7,1,8,4,8,143,8,8,11,8,12,8,144,1,9,1,9,1,9,1,
        9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,
        10,4,10,167,8,10,11,10,12,10,168,1,11,1,11,1,11,1,11,1,11,1,11,1,
        11,1,11,1,11,1,11,1,12,4,12,182,8,12,11,12,12,12,183,1,13,1,13,1,
        13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,14,4,14,199,8,
        14,11,14,12,14,200,1,15,1,15,1,15,1,15,1,15,1,15,1,16,4,16,210,8,
        16,11,16,12,16,211,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,18,4,18,
        222,8,18,11,18,12,18,223,1,19,1,19,1,19,1,19,1,19,1,20,4,20,232,
        8,20,11,20,12,20,233,1,21,1,21,1,21,1,21,1,21,1,22,4,22,242,8,22,
        11,22,12,22,243,1,23,1,23,1,23,1,23,3,23,250,8,23,1,23,1,23,4,23,
        254,8,23,11,23,12,23,255,1,23,1,23,1,24,1,24,1,24,1,24,1,24,1,24,
        1,24,1,24,1,24,1,24,3,24,270,8,24,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,3,25,281,8,25,1,25,1,25,5,25,285,8,25,10,25,12,25,
        288,9,25,1,25,1,25,1,25,1,25,1,25,1,25,3,25,296,8,25,1,25,1,25,5,
        25,300,8,25,10,25,12,25,303,9,25,1,25,1,25,1,25,1,25,1,25,1,25,1,
        25,3,25,312,8,25,1,25,1,25,5,25,316,8,25,10,25,12,25,319,9,25,1,
        25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,4,
        25,334,8,25,11,25,12,25,335,1,25,1,25,1,25,1,25,1,25,1,25,3,25,344,
        8,25,1,25,1,25,1,25,1,25,1,25,1,25,4,25,352,8,25,11,25,12,25,353,
        1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,1,25,1,25,4,25,374,8,25,11,25,12,25,375,1,25,1,25,
        1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,5,25,390,8,25,
        10,25,12,25,393,9,25,4,25,395,8,25,11,25,12,25,396,3,25,399,8,25,
        1,25,1,25,1,25,1,25,1,25,1,25,3,25,407,8,25,1,25,1,25,1,25,1,25,
        1,25,3,25,414,8,25,1,25,1,25,1,25,1,25,5,25,420,8,25,10,25,12,25,
        423,9,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,4,25,432,8,25,11,25,
        12,25,433,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,4,25,445,
        8,25,11,25,12,25,446,3,25,449,8,25,1,25,3,25,452,8,25,1,26,4,26,
        455,8,26,11,26,12,26,456,1,27,1,27,1,27,1,27,1,27,1,27,1,28,4,28,
        466,8,28,11,28,12,28,467,1,29,1,29,1,29,1,30,4,30,474,8,30,11,30,
        12,30,475,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,32,1,32,
        1,33,1,33,1,33,0,0,34,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,
        32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,0,9,1,0,60,
        62,1,1,64,64,2,0,1,2,9,9,1,0,3,4,3,0,18,18,25,25,39,40,3,0,21,22,
        26,26,46,46,2,0,23,23,43,43,2,0,31,31,44,45,1,0,50,51,540,0,85,1,
        0,0,0,2,90,1,0,0,0,4,100,1,0,0,0,6,104,1,0,0,0,8,112,1,0,0,0,10,
        116,1,0,0,0,12,126,1,0,0,0,14,130,1,0,0,0,16,142,1,0,0,0,18,146,
        1,0,0,0,20,166,1,0,0,0,22,170,1,0,0,0,24,181,1,0,0,0,26,185,1,0,
        0,0,28,198,1,0,0,0,30,202,1,0,0,0,32,209,1,0,0,0,34,213,1,0,0,0,
        36,221,1,0,0,0,38,225,1,0,0,0,40,231,1,0,0,0,42,235,1,0,0,0,44,241,
        1,0,0,0,46,249,1,0,0,0,48,269,1,0,0,0,50,448,1,0,0,0,52,454,1,0,
        0,0,54,458,1,0,0,0,56,465,1,0,0,0,58,469,1,0,0,0,60,473,1,0,0,0,
        62,477,1,0,0,0,64,486,1,0,0,0,66,488,1,0,0,0,68,84,3,2,1,0,69,84,
        3,4,2,0,70,84,3,8,4,0,71,84,3,12,6,0,72,84,3,16,8,0,73,84,3,20,10,
        0,74,84,3,24,12,0,75,84,3,28,14,0,76,84,3,32,16,0,77,84,3,36,18,
        0,78,84,3,40,20,0,79,84,3,44,22,0,80,84,3,52,26,0,81,84,3,56,28,
        0,82,84,3,60,30,0,83,68,1,0,0,0,83,69,1,0,0,0,83,70,1,0,0,0,83,71,
        1,0,0,0,83,72,1,0,0,0,83,73,1,0,0,0,83,74,1,0,0,0,83,75,1,0,0,0,
        83,76,1,0,0,0,83,77,1,0,0,0,83,78,1,0,0,0,83,79,1,0,0,0,83,80,1,
        0,0,0,83,81,1,0,0,0,83,82,1,0,0,0,84,87,1,0,0,0,85,83,1,0,0,0,85,
        86,1,0,0,0,86,88,1,0,0,0,87,85,1,0,0,0,88,89,5,0,0,1,89,1,1,0,0,
        0,90,94,5,54,0,0,91,93,7,0,0,0,92,91,1,0,0,0,93,96,1,0,0,0,94,92,
        1,0,0,0,94,95,1,0,0,0,95,97,1,0,0,0,96,94,1,0,0,0,97,98,7,1,0,0,
        98,3,1,0,0,0,99,101,3,6,3,0,100,99,1,0,0,0,101,102,1,0,0,0,102,100,
        1,0,0,0,102,103,1,0,0,0,103,5,1,0,0,0,104,105,7,2,0,0,105,106,5,
        55,0,0,106,107,5,50,0,0,107,108,5,55,0,0,108,109,5,50,0,0,109,110,
        3,50,25,0,110,7,1,0,0,0,111,113,3,10,5,0,112,111,1,0,0,0,113,114,
        1,0,0,0,114,112,1,0,0,0,114,115,1,0,0,0,115,9,1,0,0,0,116,117,7,
        3,0,0,117,118,5,55,0,0,118,119,5,50,0,0,119,120,5,55,0,0,120,121,
        5,50,0,0,121,122,5,55,0,0,122,123,5,50,0,0,123,124,3,50,25,0,124,
        11,1,0,0,0,125,127,3,14,7,0,126,125,1,0,0,0,127,128,1,0,0,0,128,
        126,1,0,0,0,128,129,1,0,0,0,129,13,1,0,0,0,130,131,5,5,0,0,131,132,
        5,55,0,0,132,133,5,50,0,0,133,134,5,55,0,0,134,135,5,50,0,0,135,
        136,5,55,0,0,136,137,5,50,0,0,137,138,5,55,0,0,138,139,5,50,0,0,
        139,140,3,50,25,0,140,15,1,0,0,0,141,143,3,18,9,0,142,141,1,0,0,
        0,143,144,1,0,0,0,144,142,1,0,0,0,144,145,1,0,0,0,145,17,1,0,0,0,
        146,147,5,6,0,0,147,148,5,55,0,0,148,149,5,50,0,0,149,150,5,55,0,
        0,150,151,5,50,0,0,151,152,5,55,0,0,152,153,5,50,0,0,153,154,5,55,
        0,0,154,155,5,50,0,0,155,156,5,55,0,0,156,157,5,50,0,0,157,158,5,
        55,0,0,158,159,5,50,0,0,159,160,5,55,0,0,160,161,5,50,0,0,161,162,
        5,55,0,0,162,163,5,50,0,0,163,164,3,50,25,0,164,19,1,0,0,0,165,167,
        3,22,11,0,166,165,1,0,0,0,167,168,1,0,0,0,168,166,1,0,0,0,168,169,
        1,0,0,0,169,21,1,0,0,0,170,171,5,7,0,0,171,172,5,55,0,0,172,173,
        5,55,0,0,173,174,5,55,0,0,174,175,5,55,0,0,175,176,3,64,32,0,176,
        177,3,64,32,0,177,178,3,64,32,0,178,179,3,50,25,0,179,23,1,0,0,0,
        180,182,3,26,13,0,181,180,1,0,0,0,182,183,1,0,0,0,183,181,1,0,0,
        0,183,184,1,0,0,0,184,25,1,0,0,0,185,186,5,8,0,0,186,187,5,55,0,
        0,187,188,5,50,0,0,188,189,5,55,0,0,189,190,5,55,0,0,190,191,5,55,
        0,0,191,192,5,50,0,0,192,193,3,64,32,0,193,194,3,64,32,0,194,195,
        3,64,32,0,195,196,3,50,25,0,196,27,1,0,0,0,197,199,3,30,15,0,198,
        197,1,0,0,0,199,200,1,0,0,0,200,198,1,0,0,0,200,201,1,0,0,0,201,
        29,1,0,0,0,202,203,5,10,0,0,203,204,5,55,0,0,204,205,5,50,0,0,205,
        206,5,55,0,0,206,207,3,50,25,0,207,31,1,0,0,0,208,210,3,34,17,0,
        209,208,1,0,0,0,210,211,1,0,0,0,211,209,1,0,0,0,211,212,1,0,0,0,
        212,33,1,0,0,0,213,214,5,11,0,0,214,215,5,50,0,0,215,216,5,55,0,
        0,216,217,5,50,0,0,217,218,5,50,0,0,218,219,3,50,25,0,219,35,1,0,
        0,0,220,222,3,38,19,0,221,220,1,0,0,0,222,223,1,0,0,0,223,221,1,
        0,0,0,223,224,1,0,0,0,224,37,1,0,0,0,225,226,5,12,0,0,226,227,5,
        50,0,0,227,228,5,50,0,0,228,229,3,64,32,0,229,39,1,0,0,0,230,232,
        3,42,21,0,231,230,1,0,0,0,232,233,1,0,0,0,233,231,1,0,0,0,233,234,
        1,0,0,0,234,41,1,0,0,0,235,236,5,13,0,0,236,237,5,50,0,0,237,238,
        5,55,0,0,238,239,3,64,32,0,239,43,1,0,0,0,240,242,3,46,23,0,241,
        240,1,0,0,0,242,243,1,0,0,0,243,241,1,0,0,0,243,244,1,0,0,0,244,
        45,1,0,0,0,245,250,5,14,0,0,246,250,5,15,0,0,247,248,5,16,0,0,248,
        250,5,50,0,0,249,245,1,0,0,0,249,246,1,0,0,0,249,247,1,0,0,0,250,
        253,1,0,0,0,251,254,3,48,24,0,252,254,3,46,23,0,253,251,1,0,0,0,
        253,252,1,0,0,0,254,255,1,0,0,0,255,253,1,0,0,0,255,256,1,0,0,0,
        256,257,1,0,0,0,257,258,5,17,0,0,258,47,1,0,0,0,259,270,3,6,3,0,
        260,270,3,10,5,0,261,270,3,14,7,0,262,270,3,18,9,0,263,270,3,22,
        11,0,264,270,3,26,13,0,265,270,3,30,15,0,266,270,3,34,17,0,267,270,
        3,38,19,0,268,270,3,42,21,0,269,259,1,0,0,0,269,260,1,0,0,0,269,
        261,1,0,0,0,269,262,1,0,0,0,269,263,1,0,0,0,269,264,1,0,0,0,269,
        265,1,0,0,0,269,266,1,0,0,0,269,267,1,0,0,0,269,268,1,0,0,0,270,
        49,1,0,0,0,271,272,7,4,0,0,272,273,3,66,33,0,273,274,3,66,33,0,274,
        449,1,0,0,0,275,276,5,27,0,0,276,277,3,66,33,0,277,278,3,66,33,0,
        278,280,3,66,33,0,279,281,3,66,33,0,280,279,1,0,0,0,280,281,1,0,
        0,0,281,286,1,0,0,0,282,285,5,55,0,0,283,285,3,66,33,0,284,282,1,
        0,0,0,284,283,1,0,0,0,285,288,1,0,0,0,286,284,1,0,0,0,286,287,1,
        0,0,0,287,449,1,0,0,0,288,286,1,0,0,0,289,290,5,19,0,0,290,291,3,
        66,33,0,291,292,3,66,33,0,292,293,3,66,33,0,293,295,3,66,33,0,294,
        296,3,66,33,0,295,294,1,0,0,0,295,296,1,0,0,0,296,301,1,0,0,0,297,
        300,5,55,0,0,298,300,3,66,33,0,299,297,1,0,0,0,299,298,1,0,0,0,300,
        303,1,0,0,0,301,299,1,0,0,0,301,302,1,0,0,0,302,449,1,0,0,0,303,
        301,1,0,0,0,304,305,5,20,0,0,305,306,3,66,33,0,306,307,3,66,33,0,
        307,308,3,66,33,0,308,309,3,66,33,0,309,311,3,66,33,0,310,312,3,
        66,33,0,311,310,1,0,0,0,311,312,1,0,0,0,312,317,1,0,0,0,313,316,
        5,55,0,0,314,316,3,66,33,0,315,313,1,0,0,0,315,314,1,0,0,0,316,319,
        1,0,0,0,317,315,1,0,0,0,317,318,1,0,0,0,318,449,1,0,0,0,319,317,
        1,0,0,0,320,321,7,5,0,0,321,322,3,66,33,0,322,323,3,66,33,0,323,
        324,3,66,33,0,324,449,1,0,0,0,325,326,7,6,0,0,326,327,3,66,33,0,
        327,328,3,66,33,0,328,329,3,66,33,0,329,330,3,66,33,0,330,449,1,
        0,0,0,331,333,5,24,0,0,332,334,3,66,33,0,333,332,1,0,0,0,334,335,
        1,0,0,0,335,333,1,0,0,0,335,336,1,0,0,0,336,449,1,0,0,0,337,338,
        5,28,0,0,338,339,3,66,33,0,339,340,3,66,33,0,340,343,5,55,0,0,341,
        342,5,29,0,0,342,344,3,66,33,0,343,341,1,0,0,0,343,344,1,0,0,0,344,
        449,1,0,0,0,345,346,5,30,0,0,346,351,5,50,0,0,347,348,3,66,33,0,
        348,349,3,66,33,0,349,350,3,66,33,0,350,352,1,0,0,0,351,347,1,0,
        0,0,352,353,1,0,0,0,353,351,1,0,0,0,353,354,1,0,0,0,354,449,1,0,
        0,0,355,356,7,7,0,0,356,357,3,66,33,0,357,358,3,66,33,0,358,359,
        3,66,33,0,359,360,3,66,33,0,360,361,3,66,33,0,361,362,3,66,33,0,
        362,449,1,0,0,0,363,364,5,32,0,0,364,449,3,66,33,0,365,449,5,33,
        0,0,366,367,5,34,0,0,367,368,3,66,33,0,368,369,3,50,25,0,369,449,
        1,0,0,0,370,371,5,35,0,0,371,373,5,50,0,0,372,374,3,50,25,0,373,
        372,1,0,0,0,374,375,1,0,0,0,375,373,1,0,0,0,375,376,1,0,0,0,376,
        449,1,0,0,0,377,378,5,36,0,0,378,398,5,55,0,0,379,380,3,66,33,0,
        380,381,3,66,33,0,381,382,3,66,33,0,382,399,1,0,0,0,383,384,5,37,
        0,0,384,385,3,66,33,0,385,386,3,66,33,0,386,394,3,66,33,0,387,391,
        5,55,0,0,388,390,3,66,33,0,389,388,1,0,0,0,390,393,1,0,0,0,391,389,
        1,0,0,0,391,392,1,0,0,0,392,395,1,0,0,0,393,391,1,0,0,0,394,387,
        1,0,0,0,395,396,1,0,0,0,396,394,1,0,0,0,396,397,1,0,0,0,397,399,
        1,0,0,0,398,379,1,0,0,0,398,383,1,0,0,0,399,449,1,0,0,0,400,401,
        5,38,0,0,401,402,3,66,33,0,402,403,3,66,33,0,403,404,3,66,33,0,404,
        406,3,66,33,0,405,407,3,66,33,0,406,405,1,0,0,0,406,407,1,0,0,0,
        407,449,1,0,0,0,408,409,5,41,0,0,409,410,3,66,33,0,410,411,3,66,
        33,0,411,413,3,66,33,0,412,414,5,42,0,0,413,412,1,0,0,0,413,414,
        1,0,0,0,414,449,1,0,0,0,415,416,5,47,0,0,416,417,3,66,33,0,417,421,
        3,66,33,0,418,420,3,66,33,0,419,418,1,0,0,0,420,423,1,0,0,0,421,
        419,1,0,0,0,421,422,1,0,0,0,422,449,1,0,0,0,423,421,1,0,0,0,424,
        425,5,48,0,0,425,431,5,50,0,0,426,427,3,66,33,0,427,428,3,66,33,
        0,428,429,3,66,33,0,429,430,3,66,33,0,430,432,1,0,0,0,431,426,1,
        0,0,0,432,433,1,0,0,0,433,431,1,0,0,0,433,434,1,0,0,0,434,449,1,
        0,0,0,435,436,5,49,0,0,436,444,5,50,0,0,437,438,3,66,33,0,438,439,
        3,66,33,0,439,440,3,66,33,0,440,441,3,66,33,0,441,442,3,66,33,0,
        442,443,3,66,33,0,443,445,1,0,0,0,444,437,1,0,0,0,445,446,1,0,0,
        0,446,444,1,0,0,0,446,447,1,0,0,0,447,449,1,0,0,0,448,271,1,0,0,
        0,448,275,1,0,0,0,448,289,1,0,0,0,448,304,1,0,0,0,448,320,1,0,0,
        0,448,325,1,0,0,0,448,331,1,0,0,0,448,337,1,0,0,0,448,345,1,0,0,
        0,448,355,1,0,0,0,448,363,1,0,0,0,448,365,1,0,0,0,448,366,1,0,0,
        0,448,370,1,0,0,0,448,377,1,0,0,0,448,400,1,0,0,0,448,408,1,0,0,
        0,448,415,1,0,0,0,448,424,1,0,0,0,448,435,1,0,0,0,449,451,1,0,0,
        0,450,452,3,2,1,0,451,450,1,0,0,0,451,452,1,0,0,0,452,51,1,0,0,0,
        453,455,3,54,27,0,454,453,1,0,0,0,455,456,1,0,0,0,456,454,1,0,0,
        0,456,457,1,0,0,0,457,53,1,0,0,0,458,459,5,50,0,0,459,460,5,55,0,
        0,460,461,5,50,0,0,461,462,5,55,0,0,462,463,3,64,32,0,463,55,1,0,
        0,0,464,466,3,58,29,0,465,464,1,0,0,0,466,467,1,0,0,0,467,465,1,
        0,0,0,467,468,1,0,0,0,468,57,1,0,0,0,469,470,5,50,0,0,470,471,5,
        50,0,0,471,59,1,0,0,0,472,474,3,62,31,0,473,472,1,0,0,0,474,475,
        1,0,0,0,475,473,1,0,0,0,475,476,1,0,0,0,476,61,1,0,0,0,477,478,7,
        2,0,0,478,479,5,55,0,0,479,480,5,50,0,0,480,481,5,55,0,0,481,482,
        5,55,0,0,482,483,5,50,0,0,483,484,5,55,0,0,484,485,3,50,25,0,485,
        63,1,0,0,0,486,487,7,8,0,0,487,65,1,0,0,0,488,489,7,8,0,0,489,67,
        1,0,0,0,44,83,85,94,102,114,128,144,168,183,200,211,223,233,243,
        249,253,255,269,280,284,286,295,299,301,311,315,317,335,343,353,
        375,391,396,398,406,413,421,433,446,448,451,456,467,475
    ]

class RosettaMRParser ( Parser ):

    grammarFileName = "RosettaMRParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'AtomPair'", "'NamedAtomPair'", "'Angle'", 
                     "'NamedAngle'", "'Dihedral'", "'DihedralPair'", "'CoordinateConstraint'", 
                     "'LocalCoordinateConstraint'", "'AmbiguousNMRDistance'", 
                     "'SiteConstraint'", "'SiteConstraintResidues'", "'MinResidueAtomicDistance'", 
                     "'BigBin'", "'MultiConstraint'", "'AmbiguousConstraint'", 
                     "'KofNConstraint'", "'END'", "'CIRCULARHARMONIC'", 
                     "'PERIODICBOUNDED'", "'OFFSETPERIODICBOUNDED'", "'AMBERPERIODIC'", 
                     "'CHARMMPERIODIC'", "'CIRCULARSIGMOIDAL'", "'CIRCULARSPLINE'", 
                     "'HARMONIC'", "'FLAT_HARMONIC'", "'BOUNDED'", "'GAUSSIANFUNC'", 
                     "'WEIGHT'", "'SOGFUNC'", "'MIXTUREFUNC'", "'CONSTANTFUNC'", 
                     "'IDENTITY'", "'SCALARWEIGHTEDFUNC'", "'SUMFUNC'", 
                     "'SPLINE'", "'NONE'", "'FADE'", "'SIGMOID'", "'SQUARE_WELL'", 
                     "'SQUARE_WELL2'", "'DEGREES'", "'LINEAR_PENALTY'", 
                     "'KARPLUS'", "'SOEDINGFUNC'", "'TOPOUT'", "'ETABLE'", 
                     "'USOG'", "'SOG'" ]

    symbolicNames = [ "<INVALID>", "AtomPair", "NamedAtomPair", "Angle", 
                      "NamedAngle", "Dihedral", "DihedralPair", "CoordinateConstraint", 
                      "LocalCoordinateConstraint", "AmbiguousNMRDistance", 
                      "SiteConstraint", "SiteConstraintResidues", "MinResidueAtomicDistance", 
                      "BigBin", "MultiConstraint", "AmbiguousConstraint", 
                      "KofNConstraint", "END", "CIRCULARHARMONIC", "PERIODICBOUNDED", 
                      "OFFSETPERIODICBOUNDED", "AMBERPERIODIC", "CHARMMPERIODIC", 
                      "CIRCULARSIGMOIDAL", "CIRCULARSPLINE", "HARMONIC", 
                      "FLAT_HARMONIC", "BOUNDED", "GAUSSIANFUNC", "WEIGHT", 
                      "SOGFUNC", "MIXTUREFUNC", "CONSTANTFUNC", "IDENTITY", 
                      "SCALARWEIGHTEDFUNC", "SUMFUNC", "SPLINE", "NONE", 
                      "FADE", "SIGMOID", "SQUARE_WELL", "SQUARE_WELL2", 
                      "DEGREES", "LINEAR_PENALTY", "KARPLUS", "SOEDINGFUNC", 
                      "TOPOUT", "ETABLE", "USOG", "SOG", "Integer", "Float", 
                      "SHARP_COMMENT", "EXCLM_COMMENT", "COMMENT", "Simple_name", 
                      "SPACE", "ENCLOSE_COMMENT", "SECTION_COMMENT", "LINE_COMMENT", 
                      "Atom_pair_selection", "Atom_selection", "Any_name", 
                      "SPACE_CM", "RETURN_CM" ]

    RULE_rosetta_mr = 0
    RULE_comment = 1
    RULE_atom_pair_restraints = 2
    RULE_atom_pair_restraint = 3
    RULE_angle_restraints = 4
    RULE_angle_restraint = 5
    RULE_dihedral_restraints = 6
    RULE_dihedral_restraint = 7
    RULE_dihedral_pair_restraints = 8
    RULE_dihedral_pair_restraint = 9
    RULE_coordinate_restraints = 10
    RULE_coordinate_restraint = 11
    RULE_local_coordinate_restraints = 12
    RULE_local_coordinate_restraint = 13
    RULE_site_restraints = 14
    RULE_site_restraint = 15
    RULE_site_residues_restraints = 16
    RULE_site_residues_restraint = 17
    RULE_min_residue_atomic_distance_restraints = 18
    RULE_min_residue_atomic_distance_restraint = 19
    RULE_big_bin_restraints = 20
    RULE_big_bin_restraint = 21
    RULE_nested_restraints = 22
    RULE_nested_restraint = 23
    RULE_any_restraint = 24
    RULE_func_type_def = 25
    RULE_rdc_restraints = 26
    RULE_rdc_restraint = 27
    RULE_disulfide_bond_linkages = 28
    RULE_disulfide_bond_linkage = 29
    RULE_atom_pair_w_chain_restraints = 30
    RULE_atom_pair_w_chain_restraint = 31
    RULE_number = 32
    RULE_number_f = 33

    ruleNames =  [ "rosetta_mr", "comment", "atom_pair_restraints", "atom_pair_restraint", 
                   "angle_restraints", "angle_restraint", "dihedral_restraints", 
                   "dihedral_restraint", "dihedral_pair_restraints", "dihedral_pair_restraint", 
                   "coordinate_restraints", "coordinate_restraint", "local_coordinate_restraints", 
                   "local_coordinate_restraint", "site_restraints", "site_restraint", 
                   "site_residues_restraints", "site_residues_restraint", 
                   "min_residue_atomic_distance_restraints", "min_residue_atomic_distance_restraint", 
                   "big_bin_restraints", "big_bin_restraint", "nested_restraints", 
                   "nested_restraint", "any_restraint", "func_type_def", 
                   "rdc_restraints", "rdc_restraint", "disulfide_bond_linkages", 
                   "disulfide_bond_linkage", "atom_pair_w_chain_restraints", 
                   "atom_pair_w_chain_restraint", "number", "number_f" ]

    EOF = Token.EOF
    AtomPair=1
    NamedAtomPair=2
    Angle=3
    NamedAngle=4
    Dihedral=5
    DihedralPair=6
    CoordinateConstraint=7
    LocalCoordinateConstraint=8
    AmbiguousNMRDistance=9
    SiteConstraint=10
    SiteConstraintResidues=11
    MinResidueAtomicDistance=12
    BigBin=13
    MultiConstraint=14
    AmbiguousConstraint=15
    KofNConstraint=16
    END=17
    CIRCULARHARMONIC=18
    PERIODICBOUNDED=19
    OFFSETPERIODICBOUNDED=20
    AMBERPERIODIC=21
    CHARMMPERIODIC=22
    CIRCULARSIGMOIDAL=23
    CIRCULARSPLINE=24
    HARMONIC=25
    FLAT_HARMONIC=26
    BOUNDED=27
    GAUSSIANFUNC=28
    WEIGHT=29
    SOGFUNC=30
    MIXTUREFUNC=31
    CONSTANTFUNC=32
    IDENTITY=33
    SCALARWEIGHTEDFUNC=34
    SUMFUNC=35
    SPLINE=36
    NONE=37
    FADE=38
    SIGMOID=39
    SQUARE_WELL=40
    SQUARE_WELL2=41
    DEGREES=42
    LINEAR_PENALTY=43
    KARPLUS=44
    SOEDINGFUNC=45
    TOPOUT=46
    ETABLE=47
    USOG=48
    SOG=49
    Integer=50
    Float=51
    SHARP_COMMENT=52
    EXCLM_COMMENT=53
    COMMENT=54
    Simple_name=55
    SPACE=56
    ENCLOSE_COMMENT=57
    SECTION_COMMENT=58
    LINE_COMMENT=59
    Atom_pair_selection=60
    Atom_selection=61
    Any_name=62
    SPACE_CM=63
    RETURN_CM=64

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Rosetta_mrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(RosettaMRParser.EOF, 0)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.CommentContext,i)


        def atom_pair_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Atom_pair_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Atom_pair_restraintsContext,i)


        def angle_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Angle_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Angle_restraintsContext,i)


        def dihedral_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Dihedral_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Dihedral_restraintsContext,i)


        def dihedral_pair_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Dihedral_pair_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Dihedral_pair_restraintsContext,i)


        def coordinate_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Coordinate_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Coordinate_restraintsContext,i)


        def local_coordinate_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Local_coordinate_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Local_coordinate_restraintsContext,i)


        def site_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Site_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Site_restraintsContext,i)


        def site_residues_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Site_residues_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Site_residues_restraintsContext,i)


        def min_residue_atomic_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Min_residue_atomic_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Min_residue_atomic_distance_restraintsContext,i)


        def big_bin_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Big_bin_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Big_bin_restraintsContext,i)


        def nested_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Nested_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Nested_restraintsContext,i)


        def rdc_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Rdc_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Rdc_restraintsContext,i)


        def disulfide_bond_linkages(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Disulfide_bond_linkagesContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Disulfide_bond_linkagesContext,i)


        def atom_pair_w_chain_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Atom_pair_w_chain_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Atom_pair_w_chain_restraintsContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_rosetta_mr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRosetta_mr" ):
                listener.enterRosetta_mr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRosetta_mr" ):
                listener.exitRosetta_mr(self)




    def rosetta_mr(self):

        localctx = RosettaMRParser.Rosetta_mrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_rosetta_mr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 85
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 19140298416455678) != 0):
                self.state = 83
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 68
                    self.comment()
                    pass

                elif la_ == 2:
                    self.state = 69
                    self.atom_pair_restraints()
                    pass

                elif la_ == 3:
                    self.state = 70
                    self.angle_restraints()
                    pass

                elif la_ == 4:
                    self.state = 71
                    self.dihedral_restraints()
                    pass

                elif la_ == 5:
                    self.state = 72
                    self.dihedral_pair_restraints()
                    pass

                elif la_ == 6:
                    self.state = 73
                    self.coordinate_restraints()
                    pass

                elif la_ == 7:
                    self.state = 74
                    self.local_coordinate_restraints()
                    pass

                elif la_ == 8:
                    self.state = 75
                    self.site_restraints()
                    pass

                elif la_ == 9:
                    self.state = 76
                    self.site_residues_restraints()
                    pass

                elif la_ == 10:
                    self.state = 77
                    self.min_residue_atomic_distance_restraints()
                    pass

                elif la_ == 11:
                    self.state = 78
                    self.big_bin_restraints()
                    pass

                elif la_ == 12:
                    self.state = 79
                    self.nested_restraints()
                    pass

                elif la_ == 13:
                    self.state = 80
                    self.rdc_restraints()
                    pass

                elif la_ == 14:
                    self.state = 81
                    self.disulfide_bond_linkages()
                    pass

                elif la_ == 15:
                    self.state = 82
                    self.atom_pair_w_chain_restraints()
                    pass


                self.state = 87
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 88
            self.match(RosettaMRParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(RosettaMRParser.COMMENT, 0)

        def RETURN_CM(self):
            return self.getToken(RosettaMRParser.RETURN_CM, 0)

        def EOF(self):
            return self.getToken(RosettaMRParser.EOF, 0)

        def Atom_pair_selection(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Atom_pair_selection)
            else:
                return self.getToken(RosettaMRParser.Atom_pair_selection, i)

        def Atom_selection(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Atom_selection)
            else:
                return self.getToken(RosettaMRParser.Atom_selection, i)

        def Any_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Any_name)
            else:
                return self.getToken(RosettaMRParser.Any_name, i)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)




    def comment(self):

        localctx = RosettaMRParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_comment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 90
            self.match(RosettaMRParser.COMMENT)
            self.state = 94
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 8070450532247928832) != 0):
                self.state = 91
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 8070450532247928832) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 96
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 97
            _la = self._input.LA(1)
            if not(_la==-1 or _la==64):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atom_pair_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def atom_pair_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Atom_pair_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Atom_pair_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_atom_pair_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom_pair_restraints" ):
                listener.enterAtom_pair_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom_pair_restraints" ):
                listener.exitAtom_pair_restraints(self)




    def atom_pair_restraints(self):

        localctx = RosettaMRParser.Atom_pair_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_atom_pair_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 100 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 99
                    self.atom_pair_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 102 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atom_pair_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def AtomPair(self):
            return self.getToken(RosettaMRParser.AtomPair, 0)

        def NamedAtomPair(self):
            return self.getToken(RosettaMRParser.NamedAtomPair, 0)

        def AmbiguousNMRDistance(self):
            return self.getToken(RosettaMRParser.AmbiguousNMRDistance, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_atom_pair_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom_pair_restraint" ):
                listener.enterAtom_pair_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom_pair_restraint" ):
                listener.exitAtom_pair_restraint(self)




    def atom_pair_restraint(self):

        localctx = RosettaMRParser.Atom_pair_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_atom_pair_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 104
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 518) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 105
            self.match(RosettaMRParser.Simple_name)
            self.state = 106
            self.match(RosettaMRParser.Integer)
            self.state = 107
            self.match(RosettaMRParser.Simple_name)
            self.state = 108
            self.match(RosettaMRParser.Integer)
            self.state = 109
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Angle_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def angle_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Angle_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Angle_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_angle_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngle_restraints" ):
                listener.enterAngle_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngle_restraints" ):
                listener.exitAngle_restraints(self)




    def angle_restraints(self):

        localctx = RosettaMRParser.Angle_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_angle_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 112 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 111
                    self.angle_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 114 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Angle_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def Angle(self):
            return self.getToken(RosettaMRParser.Angle, 0)

        def NamedAngle(self):
            return self.getToken(RosettaMRParser.NamedAngle, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_angle_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngle_restraint" ):
                listener.enterAngle_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngle_restraint" ):
                listener.exitAngle_restraint(self)




    def angle_restraint(self):

        localctx = RosettaMRParser.Angle_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_angle_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 116
            _la = self._input.LA(1)
            if not(_la==3 or _la==4):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 117
            self.match(RosettaMRParser.Simple_name)
            self.state = 118
            self.match(RosettaMRParser.Integer)
            self.state = 119
            self.match(RosettaMRParser.Simple_name)
            self.state = 120
            self.match(RosettaMRParser.Integer)
            self.state = 121
            self.match(RosettaMRParser.Simple_name)
            self.state = 122
            self.match(RosettaMRParser.Integer)
            self.state = 123
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def dihedral_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Dihedral_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Dihedral_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_dihedral_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_restraints" ):
                listener.enterDihedral_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_restraints" ):
                listener.exitDihedral_restraints(self)




    def dihedral_restraints(self):

        localctx = RosettaMRParser.Dihedral_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_dihedral_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 125
                    self.dihedral_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 128 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Dihedral(self):
            return self.getToken(RosettaMRParser.Dihedral, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_dihedral_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_restraint" ):
                listener.enterDihedral_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_restraint" ):
                listener.exitDihedral_restraint(self)




    def dihedral_restraint(self):

        localctx = RosettaMRParser.Dihedral_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_dihedral_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 130
            self.match(RosettaMRParser.Dihedral)
            self.state = 131
            self.match(RosettaMRParser.Simple_name)
            self.state = 132
            self.match(RosettaMRParser.Integer)
            self.state = 133
            self.match(RosettaMRParser.Simple_name)
            self.state = 134
            self.match(RosettaMRParser.Integer)
            self.state = 135
            self.match(RosettaMRParser.Simple_name)
            self.state = 136
            self.match(RosettaMRParser.Integer)
            self.state = 137
            self.match(RosettaMRParser.Simple_name)
            self.state = 138
            self.match(RosettaMRParser.Integer)
            self.state = 139
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_pair_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def dihedral_pair_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Dihedral_pair_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Dihedral_pair_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_dihedral_pair_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_pair_restraints" ):
                listener.enterDihedral_pair_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_pair_restraints" ):
                listener.exitDihedral_pair_restraints(self)




    def dihedral_pair_restraints(self):

        localctx = RosettaMRParser.Dihedral_pair_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_dihedral_pair_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 142 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 141
                    self.dihedral_pair_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 144 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,6,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_pair_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DihedralPair(self):
            return self.getToken(RosettaMRParser.DihedralPair, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_dihedral_pair_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_pair_restraint" ):
                listener.enterDihedral_pair_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_pair_restraint" ):
                listener.exitDihedral_pair_restraint(self)




    def dihedral_pair_restraint(self):

        localctx = RosettaMRParser.Dihedral_pair_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_dihedral_pair_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 146
            self.match(RosettaMRParser.DihedralPair)
            self.state = 147
            self.match(RosettaMRParser.Simple_name)
            self.state = 148
            self.match(RosettaMRParser.Integer)
            self.state = 149
            self.match(RosettaMRParser.Simple_name)
            self.state = 150
            self.match(RosettaMRParser.Integer)
            self.state = 151
            self.match(RosettaMRParser.Simple_name)
            self.state = 152
            self.match(RosettaMRParser.Integer)
            self.state = 153
            self.match(RosettaMRParser.Simple_name)
            self.state = 154
            self.match(RosettaMRParser.Integer)
            self.state = 155
            self.match(RosettaMRParser.Simple_name)
            self.state = 156
            self.match(RosettaMRParser.Integer)
            self.state = 157
            self.match(RosettaMRParser.Simple_name)
            self.state = 158
            self.match(RosettaMRParser.Integer)
            self.state = 159
            self.match(RosettaMRParser.Simple_name)
            self.state = 160
            self.match(RosettaMRParser.Integer)
            self.state = 161
            self.match(RosettaMRParser.Simple_name)
            self.state = 162
            self.match(RosettaMRParser.Integer)
            self.state = 163
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Coordinate_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def coordinate_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Coordinate_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Coordinate_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_coordinate_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCoordinate_restraints" ):
                listener.enterCoordinate_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCoordinate_restraints" ):
                listener.exitCoordinate_restraints(self)




    def coordinate_restraints(self):

        localctx = RosettaMRParser.Coordinate_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_coordinate_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 166 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 165
                    self.coordinate_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 168 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Coordinate_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CoordinateConstraint(self):
            return self.getToken(RosettaMRParser.CoordinateConstraint, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.NumberContext,i)


        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_coordinate_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCoordinate_restraint" ):
                listener.enterCoordinate_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCoordinate_restraint" ):
                listener.exitCoordinate_restraint(self)




    def coordinate_restraint(self):

        localctx = RosettaMRParser.Coordinate_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_coordinate_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170
            self.match(RosettaMRParser.CoordinateConstraint)
            self.state = 171
            self.match(RosettaMRParser.Simple_name)
            self.state = 172
            self.match(RosettaMRParser.Simple_name)
            self.state = 173
            self.match(RosettaMRParser.Simple_name)
            self.state = 174
            self.match(RosettaMRParser.Simple_name)
            self.state = 175
            self.number()
            self.state = 176
            self.number()
            self.state = 177
            self.number()
            self.state = 178
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Local_coordinate_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def local_coordinate_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Local_coordinate_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Local_coordinate_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_local_coordinate_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLocal_coordinate_restraints" ):
                listener.enterLocal_coordinate_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLocal_coordinate_restraints" ):
                listener.exitLocal_coordinate_restraints(self)




    def local_coordinate_restraints(self):

        localctx = RosettaMRParser.Local_coordinate_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_local_coordinate_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 181 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 180
                    self.local_coordinate_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 183 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Local_coordinate_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LocalCoordinateConstraint(self):
            return self.getToken(RosettaMRParser.LocalCoordinateConstraint, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.NumberContext,i)


        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_local_coordinate_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLocal_coordinate_restraint" ):
                listener.enterLocal_coordinate_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLocal_coordinate_restraint" ):
                listener.exitLocal_coordinate_restraint(self)




    def local_coordinate_restraint(self):

        localctx = RosettaMRParser.Local_coordinate_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_local_coordinate_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 185
            self.match(RosettaMRParser.LocalCoordinateConstraint)
            self.state = 186
            self.match(RosettaMRParser.Simple_name)
            self.state = 187
            self.match(RosettaMRParser.Integer)
            self.state = 188
            self.match(RosettaMRParser.Simple_name)
            self.state = 189
            self.match(RosettaMRParser.Simple_name)
            self.state = 190
            self.match(RosettaMRParser.Simple_name)
            self.state = 191
            self.match(RosettaMRParser.Integer)
            self.state = 192
            self.number()
            self.state = 193
            self.number()
            self.state = 194
            self.number()
            self.state = 195
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Site_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def site_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Site_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Site_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_site_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSite_restraints" ):
                listener.enterSite_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSite_restraints" ):
                listener.exitSite_restraints(self)




    def site_restraints(self):

        localctx = RosettaMRParser.Site_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_site_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 198 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 197
                    self.site_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 200 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Site_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SiteConstraint(self):
            return self.getToken(RosettaMRParser.SiteConstraint, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_site_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSite_restraint" ):
                listener.enterSite_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSite_restraint" ):
                listener.exitSite_restraint(self)




    def site_restraint(self):

        localctx = RosettaMRParser.Site_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_site_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202
            self.match(RosettaMRParser.SiteConstraint)
            self.state = 203
            self.match(RosettaMRParser.Simple_name)
            self.state = 204
            self.match(RosettaMRParser.Integer)
            self.state = 205
            self.match(RosettaMRParser.Simple_name)
            self.state = 206
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Site_residues_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def site_residues_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Site_residues_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Site_residues_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_site_residues_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSite_residues_restraints" ):
                listener.enterSite_residues_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSite_residues_restraints" ):
                listener.exitSite_residues_restraints(self)




    def site_residues_restraints(self):

        localctx = RosettaMRParser.Site_residues_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_site_residues_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 209 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 208
                    self.site_residues_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 211 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,10,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Site_residues_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SiteConstraintResidues(self):
            return self.getToken(RosettaMRParser.SiteConstraintResidues, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def Simple_name(self):
            return self.getToken(RosettaMRParser.Simple_name, 0)

        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_site_residues_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSite_residues_restraint" ):
                listener.enterSite_residues_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSite_residues_restraint" ):
                listener.exitSite_residues_restraint(self)




    def site_residues_restraint(self):

        localctx = RosettaMRParser.Site_residues_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_site_residues_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 213
            self.match(RosettaMRParser.SiteConstraintResidues)
            self.state = 214
            self.match(RosettaMRParser.Integer)
            self.state = 215
            self.match(RosettaMRParser.Simple_name)
            self.state = 216
            self.match(RosettaMRParser.Integer)
            self.state = 217
            self.match(RosettaMRParser.Integer)
            self.state = 218
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Min_residue_atomic_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def min_residue_atomic_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Min_residue_atomic_distance_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Min_residue_atomic_distance_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_min_residue_atomic_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMin_residue_atomic_distance_restraints" ):
                listener.enterMin_residue_atomic_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMin_residue_atomic_distance_restraints" ):
                listener.exitMin_residue_atomic_distance_restraints(self)




    def min_residue_atomic_distance_restraints(self):

        localctx = RosettaMRParser.Min_residue_atomic_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_min_residue_atomic_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 221 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 220
                    self.min_residue_atomic_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 223 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,11,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Min_residue_atomic_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MinResidueAtomicDistance(self):
            return self.getToken(RosettaMRParser.MinResidueAtomicDistance, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def number(self):
            return self.getTypedRuleContext(RosettaMRParser.NumberContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_min_residue_atomic_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMin_residue_atomic_distance_restraint" ):
                listener.enterMin_residue_atomic_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMin_residue_atomic_distance_restraint" ):
                listener.exitMin_residue_atomic_distance_restraint(self)




    def min_residue_atomic_distance_restraint(self):

        localctx = RosettaMRParser.Min_residue_atomic_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_min_residue_atomic_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 225
            self.match(RosettaMRParser.MinResidueAtomicDistance)
            self.state = 226
            self.match(RosettaMRParser.Integer)
            self.state = 227
            self.match(RosettaMRParser.Integer)
            self.state = 228
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Big_bin_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def big_bin_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Big_bin_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Big_bin_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_big_bin_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBig_bin_restraints" ):
                listener.enterBig_bin_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBig_bin_restraints" ):
                listener.exitBig_bin_restraints(self)




    def big_bin_restraints(self):

        localctx = RosettaMRParser.Big_bin_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_big_bin_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 231 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 230
                    self.big_bin_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 233 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,12,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Big_bin_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BigBin(self):
            return self.getToken(RosettaMRParser.BigBin, 0)

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def Simple_name(self):
            return self.getToken(RosettaMRParser.Simple_name, 0)

        def number(self):
            return self.getTypedRuleContext(RosettaMRParser.NumberContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_big_bin_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBig_bin_restraint" ):
                listener.enterBig_bin_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBig_bin_restraint" ):
                listener.exitBig_bin_restraint(self)




    def big_bin_restraint(self):

        localctx = RosettaMRParser.Big_bin_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_big_bin_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 235
            self.match(RosettaMRParser.BigBin)
            self.state = 236
            self.match(RosettaMRParser.Integer)
            self.state = 237
            self.match(RosettaMRParser.Simple_name)
            self.state = 238
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Nested_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def nested_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Nested_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Nested_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_nested_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNested_restraints" ):
                listener.enterNested_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNested_restraints" ):
                listener.exitNested_restraints(self)




    def nested_restraints(self):

        localctx = RosettaMRParser.Nested_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_nested_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 241 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 240
                    self.nested_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 243 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,13,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Nested_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def END(self):
            return self.getToken(RosettaMRParser.END, 0)

        def MultiConstraint(self):
            return self.getToken(RosettaMRParser.MultiConstraint, 0)

        def AmbiguousConstraint(self):
            return self.getToken(RosettaMRParser.AmbiguousConstraint, 0)

        def any_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Any_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Any_restraintContext,i)


        def nested_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Nested_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Nested_restraintContext,i)


        def KofNConstraint(self):
            return self.getToken(RosettaMRParser.KofNConstraint, 0)

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_nested_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNested_restraint" ):
                listener.enterNested_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNested_restraint" ):
                listener.exitNested_restraint(self)




    def nested_restraint(self):

        localctx = RosettaMRParser.Nested_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_nested_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 249
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [14]:
                self.state = 245
                self.match(RosettaMRParser.MultiConstraint)
                pass
            elif token in [15]:
                self.state = 246
                self.match(RosettaMRParser.AmbiguousConstraint)
                pass
            elif token in [16]:
                self.state = 247
                self.match(RosettaMRParser.KofNConstraint)
                self.state = 248
                self.match(RosettaMRParser.Integer)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 253 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 253
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]:
                    self.state = 251
                    self.any_restraint()
                    pass
                elif token in [14, 15, 16]:
                    self.state = 252
                    self.nested_restraint()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 255 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 131070) != 0)):
                    break

            self.state = 257
            self.match(RosettaMRParser.END)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Any_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def atom_pair_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Atom_pair_restraintContext,0)


        def angle_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Angle_restraintContext,0)


        def dihedral_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Dihedral_restraintContext,0)


        def dihedral_pair_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Dihedral_pair_restraintContext,0)


        def coordinate_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Coordinate_restraintContext,0)


        def local_coordinate_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Local_coordinate_restraintContext,0)


        def site_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Site_restraintContext,0)


        def site_residues_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Site_residues_restraintContext,0)


        def min_residue_atomic_distance_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Min_residue_atomic_distance_restraintContext,0)


        def big_bin_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Big_bin_restraintContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_any_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAny_restraint" ):
                listener.enterAny_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAny_restraint" ):
                listener.exitAny_restraint(self)




    def any_restraint(self):

        localctx = RosettaMRParser.Any_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_any_restraint)
        try:
            self.state = 269
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2, 9]:
                self.enterOuterAlt(localctx, 1)
                self.state = 259
                self.atom_pair_restraint()
                pass
            elif token in [3, 4]:
                self.enterOuterAlt(localctx, 2)
                self.state = 260
                self.angle_restraint()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 3)
                self.state = 261
                self.dihedral_restraint()
                pass
            elif token in [6]:
                self.enterOuterAlt(localctx, 4)
                self.state = 262
                self.dihedral_pair_restraint()
                pass
            elif token in [7]:
                self.enterOuterAlt(localctx, 5)
                self.state = 263
                self.coordinate_restraint()
                pass
            elif token in [8]:
                self.enterOuterAlt(localctx, 6)
                self.state = 264
                self.local_coordinate_restraint()
                pass
            elif token in [10]:
                self.enterOuterAlt(localctx, 7)
                self.state = 265
                self.site_restraint()
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 8)
                self.state = 266
                self.site_residues_restraint()
                pass
            elif token in [12]:
                self.enterOuterAlt(localctx, 9)
                self.state = 267
                self.min_residue_atomic_distance_restraint()
                pass
            elif token in [13]:
                self.enterOuterAlt(localctx, 10)
                self.state = 268
                self.big_bin_restraint()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Func_type_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number_f(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Number_fContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Number_fContext,i)


        def BOUNDED(self):
            return self.getToken(RosettaMRParser.BOUNDED, 0)

        def PERIODICBOUNDED(self):
            return self.getToken(RosettaMRParser.PERIODICBOUNDED, 0)

        def OFFSETPERIODICBOUNDED(self):
            return self.getToken(RosettaMRParser.OFFSETPERIODICBOUNDED, 0)

        def CIRCULARSPLINE(self):
            return self.getToken(RosettaMRParser.CIRCULARSPLINE, 0)

        def GAUSSIANFUNC(self):
            return self.getToken(RosettaMRParser.GAUSSIANFUNC, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def SOGFUNC(self):
            return self.getToken(RosettaMRParser.SOGFUNC, 0)

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def CONSTANTFUNC(self):
            return self.getToken(RosettaMRParser.CONSTANTFUNC, 0)

        def IDENTITY(self):
            return self.getToken(RosettaMRParser.IDENTITY, 0)

        def SCALARWEIGHTEDFUNC(self):
            return self.getToken(RosettaMRParser.SCALARWEIGHTEDFUNC, 0)

        def func_type_def(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Func_type_defContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,i)


        def SUMFUNC(self):
            return self.getToken(RosettaMRParser.SUMFUNC, 0)

        def SPLINE(self):
            return self.getToken(RosettaMRParser.SPLINE, 0)

        def FADE(self):
            return self.getToken(RosettaMRParser.FADE, 0)

        def SQUARE_WELL2(self):
            return self.getToken(RosettaMRParser.SQUARE_WELL2, 0)

        def ETABLE(self):
            return self.getToken(RosettaMRParser.ETABLE, 0)

        def USOG(self):
            return self.getToken(RosettaMRParser.USOG, 0)

        def SOG(self):
            return self.getToken(RosettaMRParser.SOG, 0)

        def CIRCULARHARMONIC(self):
            return self.getToken(RosettaMRParser.CIRCULARHARMONIC, 0)

        def HARMONIC(self):
            return self.getToken(RosettaMRParser.HARMONIC, 0)

        def SIGMOID(self):
            return self.getToken(RosettaMRParser.SIGMOID, 0)

        def SQUARE_WELL(self):
            return self.getToken(RosettaMRParser.SQUARE_WELL, 0)

        def AMBERPERIODIC(self):
            return self.getToken(RosettaMRParser.AMBERPERIODIC, 0)

        def CHARMMPERIODIC(self):
            return self.getToken(RosettaMRParser.CHARMMPERIODIC, 0)

        def FLAT_HARMONIC(self):
            return self.getToken(RosettaMRParser.FLAT_HARMONIC, 0)

        def TOPOUT(self):
            return self.getToken(RosettaMRParser.TOPOUT, 0)

        def CIRCULARSIGMOIDAL(self):
            return self.getToken(RosettaMRParser.CIRCULARSIGMOIDAL, 0)

        def LINEAR_PENALTY(self):
            return self.getToken(RosettaMRParser.LINEAR_PENALTY, 0)

        def MIXTUREFUNC(self):
            return self.getToken(RosettaMRParser.MIXTUREFUNC, 0)

        def KARPLUS(self):
            return self.getToken(RosettaMRParser.KARPLUS, 0)

        def SOEDINGFUNC(self):
            return self.getToken(RosettaMRParser.SOEDINGFUNC, 0)

        def comment(self):
            return self.getTypedRuleContext(RosettaMRParser.CommentContext,0)


        def NONE(self):
            return self.getToken(RosettaMRParser.NONE, 0)

        def WEIGHT(self):
            return self.getToken(RosettaMRParser.WEIGHT, 0)

        def DEGREES(self):
            return self.getToken(RosettaMRParser.DEGREES, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_func_type_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunc_type_def" ):
                listener.enterFunc_type_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunc_type_def" ):
                listener.exitFunc_type_def(self)




    def func_type_def(self):

        localctx = RosettaMRParser.Func_type_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_func_type_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 448
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [18, 25, 39, 40]:
                self.state = 271
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1649301258240) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 272
                self.number_f()
                self.state = 273
                self.number_f()
                pass
            elif token in [27]:
                self.state = 275
                self.match(RosettaMRParser.BOUNDED)
                self.state = 276
                self.number_f()
                self.state = 277
                self.number_f()
                self.state = 278
                self.number_f()
                self.state = 280
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
                if la_ == 1:
                    self.state = 279
                    self.number_f()


                self.state = 286
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,20,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 284
                        self._errHandler.sync(self)
                        token = self._input.LA(1)
                        if token in [55]:
                            self.state = 282
                            self.match(RosettaMRParser.Simple_name)
                            pass
                        elif token in [50, 51]:
                            self.state = 283
                            self.number_f()
                            pass
                        else:
                            raise NoViableAltException(self)
                 
                    self.state = 288
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,20,self._ctx)

                pass
            elif token in [19]:
                self.state = 289
                self.match(RosettaMRParser.PERIODICBOUNDED)
                self.state = 290
                self.number_f()
                self.state = 291
                self.number_f()
                self.state = 292
                self.number_f()
                self.state = 293
                self.number_f()
                self.state = 295
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
                if la_ == 1:
                    self.state = 294
                    self.number_f()


                self.state = 301
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,23,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 299
                        self._errHandler.sync(self)
                        token = self._input.LA(1)
                        if token in [55]:
                            self.state = 297
                            self.match(RosettaMRParser.Simple_name)
                            pass
                        elif token in [50, 51]:
                            self.state = 298
                            self.number_f()
                            pass
                        else:
                            raise NoViableAltException(self)
                 
                    self.state = 303
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,23,self._ctx)

                pass
            elif token in [20]:
                self.state = 304
                self.match(RosettaMRParser.OFFSETPERIODICBOUNDED)
                self.state = 305
                self.number_f()
                self.state = 306
                self.number_f()
                self.state = 307
                self.number_f()
                self.state = 308
                self.number_f()
                self.state = 309
                self.number_f()
                self.state = 311
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
                if la_ == 1:
                    self.state = 310
                    self.number_f()


                self.state = 317
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,26,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 315
                        self._errHandler.sync(self)
                        token = self._input.LA(1)
                        if token in [55]:
                            self.state = 313
                            self.match(RosettaMRParser.Simple_name)
                            pass
                        elif token in [50, 51]:
                            self.state = 314
                            self.number_f()
                            pass
                        else:
                            raise NoViableAltException(self)
                 
                    self.state = 319
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,26,self._ctx)

                pass
            elif token in [21, 22, 26, 46]:
                self.state = 320
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 70368817577984) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 321
                self.number_f()
                self.state = 322
                self.number_f()
                self.state = 323
                self.number_f()
                pass
            elif token in [23, 43]:
                self.state = 325
                _la = self._input.LA(1)
                if not(_la==23 or _la==43):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 326
                self.number_f()
                self.state = 327
                self.number_f()
                self.state = 328
                self.number_f()
                self.state = 329
                self.number_f()
                pass
            elif token in [24]:
                self.state = 331
                self.match(RosettaMRParser.CIRCULARSPLINE)
                self.state = 333 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 332
                        self.number_f()

                    else:
                        raise NoViableAltException(self)
                    self.state = 335 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,27,self._ctx)

                pass
            elif token in [28]:
                self.state = 337
                self.match(RosettaMRParser.GAUSSIANFUNC)
                self.state = 338
                self.number_f()
                self.state = 339
                self.number_f()
                self.state = 340
                self.match(RosettaMRParser.Simple_name)
                self.state = 343
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==29:
                    self.state = 341
                    self.match(RosettaMRParser.WEIGHT)
                    self.state = 342
                    self.number_f()


                pass
            elif token in [30]:
                self.state = 345
                self.match(RosettaMRParser.SOGFUNC)
                self.state = 346
                self.match(RosettaMRParser.Integer)
                self.state = 351 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 347
                        self.number_f()
                        self.state = 348
                        self.number_f()
                        self.state = 349
                        self.number_f()

                    else:
                        raise NoViableAltException(self)
                    self.state = 353 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,29,self._ctx)

                pass
            elif token in [31, 44, 45]:
                self.state = 355
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 52778705616896) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 356
                self.number_f()
                self.state = 357
                self.number_f()
                self.state = 358
                self.number_f()
                self.state = 359
                self.number_f()
                self.state = 360
                self.number_f()
                self.state = 361
                self.number_f()
                pass
            elif token in [32]:
                self.state = 363
                self.match(RosettaMRParser.CONSTANTFUNC)
                self.state = 364
                self.number_f()
                pass
            elif token in [33]:
                self.state = 365
                self.match(RosettaMRParser.IDENTITY)
                pass
            elif token in [34]:
                self.state = 366
                self.match(RosettaMRParser.SCALARWEIGHTEDFUNC)
                self.state = 367
                self.number_f()
                self.state = 368
                self.func_type_def()
                pass
            elif token in [35]:
                self.state = 370
                self.match(RosettaMRParser.SUMFUNC)
                self.state = 371
                self.match(RosettaMRParser.Integer)
                self.state = 373 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 372
                        self.func_type_def()

                    else:
                        raise NoViableAltException(self)
                    self.state = 375 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,30,self._ctx)

                pass
            elif token in [36]:
                self.state = 377
                self.match(RosettaMRParser.SPLINE)
                self.state = 378
                self.match(RosettaMRParser.Simple_name)
                self.state = 398
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [50, 51]:
                    self.state = 379
                    self.number_f()
                    self.state = 380
                    self.number_f()
                    self.state = 381
                    self.number_f()
                    pass
                elif token in [37]:
                    self.state = 383
                    self.match(RosettaMRParser.NONE)
                    self.state = 384
                    self.number_f()
                    self.state = 385
                    self.number_f()
                    self.state = 386
                    self.number_f()
                    self.state = 394 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while True:
                        self.state = 387
                        self.match(RosettaMRParser.Simple_name)
                        self.state = 391
                        self._errHandler.sync(self)
                        _alt = self._interp.adaptivePredict(self._input,31,self._ctx)
                        while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                            if _alt==1:
                                self.state = 388
                                self.number_f() 
                            self.state = 393
                            self._errHandler.sync(self)
                            _alt = self._interp.adaptivePredict(self._input,31,self._ctx)

                        self.state = 396 
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if not (_la==55):
                            break

                    pass
                else:
                    raise NoViableAltException(self)

                pass
            elif token in [38]:
                self.state = 400
                self.match(RosettaMRParser.FADE)
                self.state = 401
                self.number_f()
                self.state = 402
                self.number_f()
                self.state = 403
                self.number_f()
                self.state = 404
                self.number_f()
                self.state = 406
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,34,self._ctx)
                if la_ == 1:
                    self.state = 405
                    self.number_f()


                pass
            elif token in [41]:
                self.state = 408
                self.match(RosettaMRParser.SQUARE_WELL2)
                self.state = 409
                self.number_f()
                self.state = 410
                self.number_f()
                self.state = 411
                self.number_f()
                self.state = 413
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==42:
                    self.state = 412
                    self.match(RosettaMRParser.DEGREES)


                pass
            elif token in [47]:
                self.state = 415
                self.match(RosettaMRParser.ETABLE)
                self.state = 416
                self.number_f()
                self.state = 417
                self.number_f()
                self.state = 421
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,36,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 418
                        self.number_f() 
                    self.state = 423
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,36,self._ctx)

                pass
            elif token in [48]:
                self.state = 424
                self.match(RosettaMRParser.USOG)
                self.state = 425
                self.match(RosettaMRParser.Integer)
                self.state = 431 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 426
                        self.number_f()
                        self.state = 427
                        self.number_f()
                        self.state = 428
                        self.number_f()
                        self.state = 429
                        self.number_f()

                    else:
                        raise NoViableAltException(self)
                    self.state = 433 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,37,self._ctx)

                pass
            elif token in [49]:
                self.state = 435
                self.match(RosettaMRParser.SOG)
                self.state = 436
                self.match(RosettaMRParser.Integer)
                self.state = 444 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 437
                        self.number_f()
                        self.state = 438
                        self.number_f()
                        self.state = 439
                        self.number_f()
                        self.state = 440
                        self.number_f()
                        self.state = 441
                        self.number_f()
                        self.state = 442
                        self.number_f()

                    else:
                        raise NoViableAltException(self)
                    self.state = 446 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,38,self._ctx)

                pass
            else:
                raise NoViableAltException(self)

            self.state = 451
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,40,self._ctx)
            if la_ == 1:
                self.state = 450
                self.comment()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rdc_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def rdc_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Rdc_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Rdc_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_rdc_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRdc_restraints" ):
                listener.enterRdc_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRdc_restraints" ):
                listener.exitRdc_restraints(self)




    def rdc_restraints(self):

        localctx = RosettaMRParser.Rdc_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_rdc_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 454 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 453
                    self.rdc_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 456 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,41,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rdc_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def number(self):
            return self.getTypedRuleContext(RosettaMRParser.NumberContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_rdc_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRdc_restraint" ):
                listener.enterRdc_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRdc_restraint" ):
                listener.exitRdc_restraint(self)




    def rdc_restraint(self):

        localctx = RosettaMRParser.Rdc_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_rdc_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 458
            self.match(RosettaMRParser.Integer)
            self.state = 459
            self.match(RosettaMRParser.Simple_name)
            self.state = 460
            self.match(RosettaMRParser.Integer)
            self.state = 461
            self.match(RosettaMRParser.Simple_name)
            self.state = 462
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Disulfide_bond_linkagesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def disulfide_bond_linkage(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Disulfide_bond_linkageContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Disulfide_bond_linkageContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_disulfide_bond_linkages

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDisulfide_bond_linkages" ):
                listener.enterDisulfide_bond_linkages(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDisulfide_bond_linkages" ):
                listener.exitDisulfide_bond_linkages(self)




    def disulfide_bond_linkages(self):

        localctx = RosettaMRParser.Disulfide_bond_linkagesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_disulfide_bond_linkages)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 465 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 464
                    self.disulfide_bond_linkage()

                else:
                    raise NoViableAltException(self)
                self.state = 467 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,42,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Disulfide_bond_linkageContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_disulfide_bond_linkage

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDisulfide_bond_linkage" ):
                listener.enterDisulfide_bond_linkage(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDisulfide_bond_linkage" ):
                listener.exitDisulfide_bond_linkage(self)




    def disulfide_bond_linkage(self):

        localctx = RosettaMRParser.Disulfide_bond_linkageContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_disulfide_bond_linkage)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 469
            self.match(RosettaMRParser.Integer)
            self.state = 470
            self.match(RosettaMRParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atom_pair_w_chain_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def atom_pair_w_chain_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Atom_pair_w_chain_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Atom_pair_w_chain_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_atom_pair_w_chain_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom_pair_w_chain_restraints" ):
                listener.enterAtom_pair_w_chain_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom_pair_w_chain_restraints" ):
                listener.exitAtom_pair_w_chain_restraints(self)




    def atom_pair_w_chain_restraints(self):

        localctx = RosettaMRParser.Atom_pair_w_chain_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_atom_pair_w_chain_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 473 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 472
                    self.atom_pair_w_chain_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 475 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,43,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atom_pair_w_chain_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def AtomPair(self):
            return self.getToken(RosettaMRParser.AtomPair, 0)

        def NamedAtomPair(self):
            return self.getToken(RosettaMRParser.NamedAtomPair, 0)

        def AmbiguousNMRDistance(self):
            return self.getToken(RosettaMRParser.AmbiguousNMRDistance, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_atom_pair_w_chain_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom_pair_w_chain_restraint" ):
                listener.enterAtom_pair_w_chain_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom_pair_w_chain_restraint" ):
                listener.exitAtom_pair_w_chain_restraint(self)




    def atom_pair_w_chain_restraint(self):

        localctx = RosettaMRParser.Atom_pair_w_chain_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_atom_pair_w_chain_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 477
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 518) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 478
            self.match(RosettaMRParser.Simple_name)
            self.state = 479
            self.match(RosettaMRParser.Integer)
            self.state = 480
            self.match(RosettaMRParser.Simple_name)
            self.state = 481
            self.match(RosettaMRParser.Simple_name)
            self.state = 482
            self.match(RosettaMRParser.Integer)
            self.state = 483
            self.match(RosettaMRParser.Simple_name)
            self.state = 484
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(RosettaMRParser.Float, 0)

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = RosettaMRParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 486
            _la = self._input.LA(1)
            if not(_la==50 or _la==51):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Number_fContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(RosettaMRParser.Float, 0)

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_number_f

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber_f" ):
                listener.enterNumber_f(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber_f" ):
                listener.exitNumber_f(self)




    def number_f(self):

        localctx = RosettaMRParser.Number_fContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_number_f)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 488
            _la = self._input.LA(1)
            if not(_la==50 or _la==51):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





