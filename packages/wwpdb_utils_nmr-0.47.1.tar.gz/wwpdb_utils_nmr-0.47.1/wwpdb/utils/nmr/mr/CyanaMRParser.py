# Generated from CyanaMRParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,58,611,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,46,
        7,46,2,47,7,47,2,48,7,48,2,49,7,49,1,0,1,0,4,0,103,8,0,11,0,12,0,
        104,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,
        1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,5,0,134,8,0,10,0,
        12,0,137,9,0,1,0,1,0,1,1,1,1,5,1,143,8,1,10,1,12,1,146,9,1,1,1,1,
        1,1,2,4,2,151,8,2,11,2,12,2,152,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,
        3,3,163,8,3,1,3,3,3,166,8,3,1,3,3,3,169,8,3,1,3,3,3,172,8,3,1,3,
        3,3,175,8,3,1,4,4,4,178,8,4,11,4,12,4,179,1,5,1,5,1,5,1,5,1,5,1,
        5,3,5,188,8,5,1,5,1,5,1,5,3,5,193,8,5,1,5,3,5,196,8,5,1,6,4,6,199,
        8,6,11,6,12,6,200,1,6,1,6,1,6,4,6,206,8,6,11,6,12,6,207,1,7,1,7,
        1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,3,8,226,
        8,8,1,9,4,9,229,8,9,11,9,12,9,230,1,9,1,9,1,9,4,9,236,8,9,11,9,12,
        9,237,1,10,1,10,1,10,1,10,1,10,1,11,1,11,1,11,1,11,1,11,1,11,1,11,
        1,11,1,12,4,12,254,8,12,11,12,12,12,255,1,13,1,13,1,13,3,13,261,
        8,13,1,13,1,13,1,13,1,13,1,13,1,13,4,13,269,8,13,11,13,12,13,270,
        1,14,4,14,274,8,14,11,14,12,14,275,1,15,1,15,1,15,3,15,281,8,15,
        1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,4,15,291,8,15,11,15,12,15,
        292,1,16,4,16,296,8,16,11,16,12,16,297,1,17,1,17,1,17,3,17,303,8,
        17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,4,17,314,8,17,11,
        17,12,17,315,1,18,4,18,319,8,18,11,18,12,18,320,1,19,1,19,1,19,1,
        19,3,19,327,8,19,1,19,1,19,1,19,1,19,1,19,4,19,334,8,19,11,19,12,
        19,335,1,20,4,20,339,8,20,11,20,12,20,340,1,21,1,21,1,21,1,21,3,
        21,347,8,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,4,21,356,8,21,11,
        21,12,21,357,1,22,4,22,361,8,22,11,22,12,22,362,1,23,1,23,1,23,1,
        23,3,23,369,8,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,4,23,379,
        8,23,11,23,12,23,380,1,24,4,24,384,8,24,11,24,12,24,385,1,25,1,25,
        1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,26,4,26,398,8,26,11,26,12,26,
        399,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,3,27,412,8,
        27,1,27,3,27,415,8,27,1,28,4,28,418,8,28,11,28,12,28,419,1,29,1,
        29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,3,29,432,8,29,1,29,3,
        29,435,8,29,1,30,4,30,438,8,30,11,30,12,30,439,1,31,1,31,1,31,1,
        31,1,31,1,31,1,31,1,31,1,31,1,31,3,31,452,8,31,1,31,3,31,455,8,31,
        1,32,4,32,458,8,32,11,32,12,32,459,1,33,1,33,1,33,1,33,1,33,1,33,
        1,33,3,33,469,8,33,1,33,1,33,1,33,3,33,474,8,33,1,33,3,33,477,8,
        33,1,34,4,34,480,8,34,11,34,12,34,481,1,35,1,35,1,35,1,35,1,35,1,
        35,3,35,490,8,35,1,35,3,35,493,8,35,1,35,3,35,496,8,35,1,35,3,35,
        499,8,35,1,35,3,35,502,8,35,1,36,1,36,1,36,1,37,1,37,1,37,3,37,510,
        8,37,1,37,1,37,1,37,3,37,515,8,37,1,37,1,37,1,37,3,37,520,8,37,1,
        37,1,37,1,37,3,37,525,8,37,1,37,1,37,1,37,1,38,1,38,1,38,1,38,1,
        38,1,38,1,39,1,39,1,39,1,39,1,40,1,40,5,40,542,8,40,10,40,12,40,
        545,9,40,1,40,1,40,1,41,1,41,1,42,1,42,5,42,553,8,42,10,42,12,42,
        556,9,42,1,42,1,42,1,43,1,43,1,43,1,43,1,44,1,44,1,44,3,44,567,8,
        44,1,44,1,44,4,44,571,8,44,11,44,12,44,572,1,45,1,45,1,45,1,45,4,
        45,579,8,45,11,45,12,45,580,1,45,1,45,1,46,1,46,1,46,3,46,588,8,
        46,1,46,1,46,4,46,592,8,46,11,46,12,46,593,1,47,1,47,1,47,1,47,1,
        47,4,47,601,8,47,11,47,12,47,602,1,47,1,47,1,48,1,48,1,49,1,49,1,
        49,0,0,50,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,
        40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,
        84,86,88,90,92,94,96,98,0,5,1,1,33,33,1,0,9,10,2,0,52,52,54,54,1,
        0,2,4,2,0,1,1,26,26,668,0,135,1,0,0,0,2,140,1,0,0,0,4,150,1,0,0,
        0,6,154,1,0,0,0,8,177,1,0,0,0,10,181,1,0,0,0,12,198,1,0,0,0,14,209,
        1,0,0,0,16,214,1,0,0,0,18,228,1,0,0,0,20,239,1,0,0,0,22,244,1,0,
        0,0,24,253,1,0,0,0,26,257,1,0,0,0,28,273,1,0,0,0,30,277,1,0,0,0,
        32,295,1,0,0,0,34,299,1,0,0,0,36,318,1,0,0,0,38,322,1,0,0,0,40,338,
        1,0,0,0,42,342,1,0,0,0,44,360,1,0,0,0,46,364,1,0,0,0,48,383,1,0,
        0,0,50,387,1,0,0,0,52,397,1,0,0,0,54,401,1,0,0,0,56,417,1,0,0,0,
        58,421,1,0,0,0,60,437,1,0,0,0,62,441,1,0,0,0,64,457,1,0,0,0,66,461,
        1,0,0,0,68,479,1,0,0,0,70,483,1,0,0,0,72,503,1,0,0,0,74,506,1,0,
        0,0,76,529,1,0,0,0,78,535,1,0,0,0,80,539,1,0,0,0,82,548,1,0,0,0,
        84,550,1,0,0,0,86,559,1,0,0,0,88,563,1,0,0,0,90,574,1,0,0,0,92,584,
        1,0,0,0,94,595,1,0,0,0,96,606,1,0,0,0,98,608,1,0,0,0,100,134,5,5,
        0,0,101,103,5,6,0,0,102,101,1,0,0,0,103,104,1,0,0,0,104,102,1,0,
        0,0,104,105,1,0,0,0,105,134,1,0,0,0,106,134,3,2,1,0,107,134,3,4,
        2,0,108,134,3,24,12,0,109,134,3,28,14,0,110,134,3,32,16,0,111,134,
        3,36,18,0,112,134,3,40,20,0,113,134,3,44,22,0,114,134,3,48,24,0,
        115,134,3,52,26,0,116,134,3,56,28,0,117,134,3,60,30,0,118,134,3,
        8,4,0,119,134,3,64,32,0,120,134,3,12,6,0,121,134,3,18,9,0,122,134,
        3,68,34,0,123,134,3,72,36,0,124,134,3,74,37,0,125,134,3,76,38,0,
        126,134,3,78,39,0,127,134,3,80,40,0,128,134,3,82,41,0,129,134,3,
        84,42,0,130,134,3,86,43,0,131,134,3,88,44,0,132,134,3,92,46,0,133,
        100,1,0,0,0,133,102,1,0,0,0,133,106,1,0,0,0,133,107,1,0,0,0,133,
        108,1,0,0,0,133,109,1,0,0,0,133,110,1,0,0,0,133,111,1,0,0,0,133,
        112,1,0,0,0,133,113,1,0,0,0,133,114,1,0,0,0,133,115,1,0,0,0,133,
        116,1,0,0,0,133,117,1,0,0,0,133,118,1,0,0,0,133,119,1,0,0,0,133,
        120,1,0,0,0,133,121,1,0,0,0,133,122,1,0,0,0,133,123,1,0,0,0,133,
        124,1,0,0,0,133,125,1,0,0,0,133,126,1,0,0,0,133,127,1,0,0,0,133,
        128,1,0,0,0,133,129,1,0,0,0,133,130,1,0,0,0,133,131,1,0,0,0,133,
        132,1,0,0,0,134,137,1,0,0,0,135,133,1,0,0,0,135,136,1,0,0,0,136,
        138,1,0,0,0,137,135,1,0,0,0,138,139,5,0,0,1,139,1,1,0,0,0,140,144,
        5,8,0,0,141,143,5,31,0,0,142,141,1,0,0,0,143,146,1,0,0,0,144,142,
        1,0,0,0,144,145,1,0,0,0,145,147,1,0,0,0,146,144,1,0,0,0,147,148,
        7,0,0,0,148,3,1,0,0,0,149,151,3,6,3,0,150,149,1,0,0,0,151,152,1,
        0,0,0,152,150,1,0,0,0,152,153,1,0,0,0,153,5,1,0,0,0,154,155,5,2,
        0,0,155,156,5,26,0,0,156,157,3,98,49,0,157,158,5,2,0,0,158,159,5,
        26,0,0,159,160,3,98,49,0,160,162,3,96,48,0,161,163,3,96,48,0,162,
        161,1,0,0,0,162,163,1,0,0,0,163,165,1,0,0,0,164,166,3,96,48,0,165,
        164,1,0,0,0,165,166,1,0,0,0,166,168,1,0,0,0,167,169,3,96,48,0,168,
        167,1,0,0,0,168,169,1,0,0,0,169,171,1,0,0,0,170,172,3,96,48,0,171,
        170,1,0,0,0,171,172,1,0,0,0,172,174,1,0,0,0,173,175,3,96,48,0,174,
        173,1,0,0,0,174,175,1,0,0,0,175,7,1,0,0,0,176,178,3,10,5,0,177,176,
        1,0,0,0,178,179,1,0,0,0,179,177,1,0,0,0,179,180,1,0,0,0,180,9,1,
        0,0,0,181,182,5,2,0,0,182,183,5,26,0,0,183,184,5,26,0,0,184,185,
        3,96,48,0,185,187,3,96,48,0,186,188,3,96,48,0,187,186,1,0,0,0,187,
        188,1,0,0,0,188,192,1,0,0,0,189,190,5,11,0,0,190,191,5,12,0,0,191,
        193,5,2,0,0,192,189,1,0,0,0,192,193,1,0,0,0,193,195,1,0,0,0,194,
        196,5,13,0,0,195,194,1,0,0,0,195,196,1,0,0,0,196,11,1,0,0,0,197,
        199,3,14,7,0,198,197,1,0,0,0,199,200,1,0,0,0,200,198,1,0,0,0,200,
        201,1,0,0,0,201,205,1,0,0,0,202,206,5,5,0,0,203,206,3,2,1,0,204,
        206,3,16,8,0,205,202,1,0,0,0,205,203,1,0,0,0,205,204,1,0,0,0,206,
        207,1,0,0,0,207,205,1,0,0,0,207,208,1,0,0,0,208,13,1,0,0,0,209,210,
        5,2,0,0,210,211,3,96,48,0,211,212,3,96,48,0,212,213,5,2,0,0,213,
        15,1,0,0,0,214,215,5,2,0,0,215,216,5,26,0,0,216,217,5,26,0,0,217,
        218,5,2,0,0,218,219,5,26,0,0,219,220,5,26,0,0,220,221,3,96,48,0,
        221,222,3,96,48,0,222,223,3,96,48,0,223,225,5,2,0,0,224,226,3,96,
        48,0,225,224,1,0,0,0,225,226,1,0,0,0,226,17,1,0,0,0,227,229,3,20,
        10,0,228,227,1,0,0,0,229,230,1,0,0,0,230,228,1,0,0,0,230,231,1,0,
        0,0,231,235,1,0,0,0,232,236,5,5,0,0,233,236,3,2,1,0,234,236,3,22,
        11,0,235,232,1,0,0,0,235,233,1,0,0,0,235,234,1,0,0,0,236,237,1,0,
        0,0,237,235,1,0,0,0,237,238,1,0,0,0,238,19,1,0,0,0,239,240,5,2,0,
        0,240,241,3,96,48,0,241,242,3,96,48,0,242,243,5,2,0,0,243,21,1,0,
        0,0,244,245,5,2,0,0,245,246,5,26,0,0,246,247,5,26,0,0,247,248,3,
        96,48,0,248,249,3,96,48,0,249,250,3,96,48,0,250,251,5,2,0,0,251,
        23,1,0,0,0,252,254,3,26,13,0,253,252,1,0,0,0,254,255,1,0,0,0,255,
        253,1,0,0,0,255,256,1,0,0,0,256,25,1,0,0,0,257,258,5,2,0,0,258,260,
        5,26,0,0,259,261,3,2,1,0,260,259,1,0,0,0,260,261,1,0,0,0,261,268,
        1,0,0,0,262,263,5,26,0,0,263,264,5,2,0,0,264,265,5,26,0,0,265,266,
        5,26,0,0,266,269,3,96,48,0,267,269,3,2,1,0,268,262,1,0,0,0,268,267,
        1,0,0,0,269,270,1,0,0,0,270,268,1,0,0,0,270,271,1,0,0,0,271,27,1,
        0,0,0,272,274,3,30,15,0,273,272,1,0,0,0,274,275,1,0,0,0,275,273,
        1,0,0,0,275,276,1,0,0,0,276,29,1,0,0,0,277,278,5,2,0,0,278,280,5,
        26,0,0,279,281,3,2,1,0,280,279,1,0,0,0,280,281,1,0,0,0,281,290,1,
        0,0,0,282,283,5,26,0,0,283,284,5,2,0,0,284,285,5,26,0,0,285,286,
        5,26,0,0,286,287,3,96,48,0,287,288,3,96,48,0,288,291,1,0,0,0,289,
        291,3,2,1,0,290,282,1,0,0,0,290,289,1,0,0,0,291,292,1,0,0,0,292,
        290,1,0,0,0,292,293,1,0,0,0,293,31,1,0,0,0,294,296,3,34,17,0,295,
        294,1,0,0,0,296,297,1,0,0,0,297,295,1,0,0,0,297,298,1,0,0,0,298,
        33,1,0,0,0,299,300,5,2,0,0,300,302,5,26,0,0,301,303,3,2,1,0,302,
        301,1,0,0,0,302,303,1,0,0,0,303,313,1,0,0,0,304,305,5,26,0,0,305,
        306,5,2,0,0,306,307,5,26,0,0,307,308,5,26,0,0,308,309,3,96,48,0,
        309,310,3,96,48,0,310,311,3,96,48,0,311,314,1,0,0,0,312,314,3,2,
        1,0,313,304,1,0,0,0,313,312,1,0,0,0,314,315,1,0,0,0,315,313,1,0,
        0,0,315,316,1,0,0,0,316,35,1,0,0,0,317,319,3,38,19,0,318,317,1,0,
        0,0,319,320,1,0,0,0,320,318,1,0,0,0,320,321,1,0,0,0,321,37,1,0,0,
        0,322,323,5,2,0,0,323,324,5,26,0,0,324,326,5,26,0,0,325,327,3,2,
        1,0,326,325,1,0,0,0,326,327,1,0,0,0,327,333,1,0,0,0,328,329,5,2,
        0,0,329,330,5,26,0,0,330,331,5,26,0,0,331,334,3,96,48,0,332,334,
        3,2,1,0,333,328,1,0,0,0,333,332,1,0,0,0,334,335,1,0,0,0,335,333,
        1,0,0,0,335,336,1,0,0,0,336,39,1,0,0,0,337,339,3,42,21,0,338,337,
        1,0,0,0,339,340,1,0,0,0,340,338,1,0,0,0,340,341,1,0,0,0,341,41,1,
        0,0,0,342,343,5,2,0,0,343,344,5,26,0,0,344,346,5,26,0,0,345,347,
        3,2,1,0,346,345,1,0,0,0,346,347,1,0,0,0,347,355,1,0,0,0,348,349,
        5,2,0,0,349,350,5,26,0,0,350,351,5,26,0,0,351,352,3,96,48,0,352,
        353,3,96,48,0,353,356,1,0,0,0,354,356,3,2,1,0,355,348,1,0,0,0,355,
        354,1,0,0,0,356,357,1,0,0,0,357,355,1,0,0,0,357,358,1,0,0,0,358,
        43,1,0,0,0,359,361,3,46,23,0,360,359,1,0,0,0,361,362,1,0,0,0,362,
        360,1,0,0,0,362,363,1,0,0,0,363,45,1,0,0,0,364,365,5,2,0,0,365,366,
        5,26,0,0,366,368,5,26,0,0,367,369,3,2,1,0,368,367,1,0,0,0,368,369,
        1,0,0,0,369,378,1,0,0,0,370,371,5,2,0,0,371,372,5,26,0,0,372,373,
        5,26,0,0,373,374,3,96,48,0,374,375,3,96,48,0,375,376,3,96,48,0,376,
        379,1,0,0,0,377,379,3,2,1,0,378,370,1,0,0,0,378,377,1,0,0,0,379,
        380,1,0,0,0,380,378,1,0,0,0,380,381,1,0,0,0,381,47,1,0,0,0,382,384,
        3,50,25,0,383,382,1,0,0,0,384,385,1,0,0,0,385,383,1,0,0,0,385,386,
        1,0,0,0,386,49,1,0,0,0,387,388,7,1,0,0,388,389,5,26,0,0,389,390,
        5,2,0,0,390,391,5,26,0,0,391,392,5,26,0,0,392,393,5,2,0,0,393,394,
        5,26,0,0,394,395,3,96,48,0,395,51,1,0,0,0,396,398,3,54,27,0,397,
        396,1,0,0,0,398,399,1,0,0,0,399,397,1,0,0,0,399,400,1,0,0,0,400,
        53,1,0,0,0,401,402,5,2,0,0,402,403,5,26,0,0,403,404,5,26,0,0,404,
        405,5,26,0,0,405,406,5,2,0,0,406,407,5,26,0,0,407,408,5,26,0,0,408,
        409,5,26,0,0,409,411,3,96,48,0,410,412,3,96,48,0,411,410,1,0,0,0,
        411,412,1,0,0,0,412,414,1,0,0,0,413,415,3,96,48,0,414,413,1,0,0,
        0,414,415,1,0,0,0,415,55,1,0,0,0,416,418,3,58,29,0,417,416,1,0,0,
        0,418,419,1,0,0,0,419,417,1,0,0,0,419,420,1,0,0,0,420,57,1,0,0,0,
        421,422,5,26,0,0,422,423,5,2,0,0,423,424,5,26,0,0,424,425,5,26,0,
        0,425,426,5,26,0,0,426,427,5,2,0,0,427,428,5,26,0,0,428,429,5,26,
        0,0,429,431,3,96,48,0,430,432,3,96,48,0,431,430,1,0,0,0,431,432,
        1,0,0,0,432,434,1,0,0,0,433,435,3,96,48,0,434,433,1,0,0,0,434,435,
        1,0,0,0,435,59,1,0,0,0,436,438,3,62,31,0,437,436,1,0,0,0,438,439,
        1,0,0,0,439,437,1,0,0,0,439,440,1,0,0,0,440,61,1,0,0,0,441,442,5,
        26,0,0,442,443,5,26,0,0,443,444,5,2,0,0,444,445,5,26,0,0,445,446,
        5,26,0,0,446,447,5,26,0,0,447,448,5,2,0,0,448,449,5,26,0,0,449,451,
        3,96,48,0,450,452,3,96,48,0,451,450,1,0,0,0,451,452,1,0,0,0,452,
        454,1,0,0,0,453,455,3,96,48,0,454,453,1,0,0,0,454,455,1,0,0,0,455,
        63,1,0,0,0,456,458,3,66,33,0,457,456,1,0,0,0,458,459,1,0,0,0,459,
        457,1,0,0,0,459,460,1,0,0,0,460,65,1,0,0,0,461,462,5,26,0,0,462,
        463,5,2,0,0,463,464,5,26,0,0,464,465,5,26,0,0,465,466,3,96,48,0,
        466,468,3,96,48,0,467,469,3,96,48,0,468,467,1,0,0,0,468,469,1,0,
        0,0,469,473,1,0,0,0,470,471,5,11,0,0,471,472,5,12,0,0,472,474,5,
        2,0,0,473,470,1,0,0,0,473,474,1,0,0,0,474,476,1,0,0,0,475,477,5,
        13,0,0,476,475,1,0,0,0,476,477,1,0,0,0,477,67,1,0,0,0,478,480,3,
        70,35,0,479,478,1,0,0,0,480,481,1,0,0,0,481,479,1,0,0,0,481,482,
        1,0,0,0,482,69,1,0,0,0,483,484,5,2,0,0,484,485,5,26,0,0,485,486,
        5,26,0,0,486,487,5,26,0,0,487,489,3,96,48,0,488,490,3,96,48,0,489,
        488,1,0,0,0,489,490,1,0,0,0,490,492,1,0,0,0,491,493,3,96,48,0,492,
        491,1,0,0,0,492,493,1,0,0,0,493,495,1,0,0,0,494,496,3,96,48,0,495,
        494,1,0,0,0,495,496,1,0,0,0,496,498,1,0,0,0,497,499,3,96,48,0,498,
        497,1,0,0,0,498,499,1,0,0,0,499,501,1,0,0,0,500,502,3,96,48,0,501,
        500,1,0,0,0,501,502,1,0,0,0,502,71,1,0,0,0,503,504,5,14,0,0,504,
        505,5,15,0,0,505,73,1,0,0,0,506,509,5,16,0,0,507,508,5,34,0,0,508,
        510,5,38,0,0,509,507,1,0,0,0,509,510,1,0,0,0,510,511,1,0,0,0,511,
        514,5,40,0,0,512,513,5,36,0,0,513,515,5,38,0,0,514,512,1,0,0,0,514,
        515,1,0,0,0,515,516,1,0,0,0,516,519,5,39,0,0,517,518,5,35,0,0,518,
        520,5,38,0,0,519,517,1,0,0,0,519,520,1,0,0,0,520,521,1,0,0,0,521,
        524,5,40,0,0,522,523,5,37,0,0,523,525,5,38,0,0,524,522,1,0,0,0,524,
        525,1,0,0,0,525,526,1,0,0,0,526,527,5,39,0,0,527,528,5,42,0,0,528,
        75,1,0,0,0,529,530,5,17,0,0,530,531,5,26,0,0,531,532,5,2,0,0,532,
        533,5,26,0,0,533,534,5,2,0,0,534,77,1,0,0,0,535,536,5,18,0,0,536,
        537,5,44,0,0,537,538,5,46,0,0,538,79,1,0,0,0,539,543,5,19,0,0,540,
        542,5,48,0,0,541,540,1,0,0,0,542,545,1,0,0,0,543,541,1,0,0,0,543,
        544,1,0,0,0,544,546,1,0,0,0,545,543,1,0,0,0,546,547,5,50,0,0,547,
        81,1,0,0,0,548,549,5,21,0,0,549,83,1,0,0,0,550,554,5,20,0,0,551,
        553,5,48,0,0,552,551,1,0,0,0,553,556,1,0,0,0,554,552,1,0,0,0,554,
        555,1,0,0,0,555,557,1,0,0,0,556,554,1,0,0,0,557,558,5,50,0,0,558,
        85,1,0,0,0,559,560,5,22,0,0,560,561,5,44,0,0,561,562,5,46,0,0,562,
        87,1,0,0,0,563,564,5,23,0,0,564,566,5,26,0,0,565,567,3,2,1,0,566,
        565,1,0,0,0,566,567,1,0,0,0,567,570,1,0,0,0,568,571,3,90,45,0,569,
        571,3,2,1,0,570,568,1,0,0,0,570,569,1,0,0,0,571,572,1,0,0,0,572,
        570,1,0,0,0,572,573,1,0,0,0,573,89,1,0,0,0,574,575,5,24,0,0,575,
        576,5,54,0,0,576,578,5,55,0,0,577,579,5,54,0,0,578,577,1,0,0,0,579,
        580,1,0,0,0,580,578,1,0,0,0,580,581,1,0,0,0,581,582,1,0,0,0,582,
        583,5,57,0,0,583,91,1,0,0,0,584,585,5,23,0,0,585,587,5,26,0,0,586,
        588,3,2,1,0,587,586,1,0,0,0,587,588,1,0,0,0,588,591,1,0,0,0,589,
        592,3,94,47,0,590,592,3,2,1,0,591,589,1,0,0,0,591,590,1,0,0,0,592,
        593,1,0,0,0,593,591,1,0,0,0,593,594,1,0,0,0,594,93,1,0,0,0,595,596,
        5,25,0,0,596,597,7,2,0,0,597,600,5,55,0,0,598,599,5,54,0,0,599,601,
        5,53,0,0,600,598,1,0,0,0,601,602,1,0,0,0,602,600,1,0,0,0,602,603,
        1,0,0,0,603,604,1,0,0,0,604,605,5,57,0,0,605,95,1,0,0,0,606,607,
        7,3,0,0,607,97,1,0,0,0,608,609,7,4,0,0,609,99,1,0,0,0,79,104,133,
        135,144,152,162,165,168,171,174,179,187,192,195,200,205,207,225,
        230,235,237,255,260,268,270,275,280,290,292,297,302,313,315,320,
        326,333,335,340,346,355,357,362,368,378,380,385,399,411,414,419,
        431,434,439,451,454,459,468,473,476,481,489,492,495,498,501,509,
        514,519,524,543,554,566,570,572,580,587,591,593,602
    ]

class CyanaMRParser ( Parser ):

    grammarFileName = "CyanaMRParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'NOEUPP'", "'NOELOW'", "'TYPE'", "<INVALID>", 
                     "'OR'", "'SSBOND'", "<INVALID>", "'HBOND'", "'LINK'", 
                     "<INVALID>", "'VAR'", "'UNSET'", "<INVALID>", "'PRINT'", 
                     "'RESIDUE'", "'MAPPING'", "'AMBIG'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'ATOM1'", "'ATOM2'", "'RESIDUE1'", 
                     "'RESIDUE2'" ]

    symbolicNames = [ "<INVALID>", "Ambig_code", "Integer", "Float", "Float_DecimalComma", 
                      "Orientation_header", "Tensor_header", "SMCLN_COMMENT", 
                      "COMMENT", "NoeUpp", "NoeLow", "Type", "Equ_op", "Or", 
                      "Ssbond", "Ssbond_resids", "Hbond", "Link", "Atom_stereo", 
                      "Var", "Unset", "SetVar", "Print", "Residue", "Mapping", 
                      "Ambig", "Simple_name", "SPACE", "ENCLOSE_COMMENT", 
                      "SECTION_COMMENT", "LINE_COMMENT", "Any_name", "SPACE_CM", 
                      "RETURN_CM", "Atom1", "Atom2", "Residue1", "Residue2", 
                      "Equ_op_HB", "Integer_HB", "Simple_name_HB", "SPACE_HB", 
                      "RETURN_HB", "LINE_COMMENT_HB", "Double_quote_string", 
                      "SPACE_PR", "RETURN_PR", "LINE_COMMENT_PR", "Simple_name_VA", 
                      "SPACE_VA", "RETURN_VA", "LINE_COMMENT_VA", "Ambig_code_MP", 
                      "Integer_MP", "Simple_name_MP", "Equ_op_MP", "SPACE_MP", 
                      "RETURN_MP", "LINE_COMMENT_MP" ]

    RULE_cyana_mr = 0
    RULE_comment = 1
    RULE_distance_restraints = 2
    RULE_distance_restraint = 3
    RULE_torsion_angle_restraints = 4
    RULE_torsion_angle_restraint = 5
    RULE_rdc_restraints = 6
    RULE_rdc_parameter = 7
    RULE_rdc_restraint = 8
    RULE_pcs_restraints = 9
    RULE_pcs_parameter = 10
    RULE_pcs_restraint = 11
    RULE_fixres_distance_restraints = 12
    RULE_fixres_distance_restraint = 13
    RULE_fixresw_distance_restraints = 14
    RULE_fixresw_distance_restraint = 15
    RULE_fixresw2_distance_restraints = 16
    RULE_fixresw2_distance_restraint = 17
    RULE_fixatm_distance_restraints = 18
    RULE_fixatm_distance_restraint = 19
    RULE_fixatmw_distance_restraints = 20
    RULE_fixatmw_distance_restraint = 21
    RULE_fixatmw2_distance_restraints = 22
    RULE_fixatmw2_distance_restraint = 23
    RULE_qconvr_distance_restraints = 24
    RULE_qconvr_distance_restraint = 25
    RULE_distance_w_chain_restraints = 26
    RULE_distance_w_chain_restraint = 27
    RULE_distance_w_chain2_restraints = 28
    RULE_distance_w_chain2_restraint = 29
    RULE_distance_w_chain3_restraints = 30
    RULE_distance_w_chain3_restraint = 31
    RULE_torsion_angle_w_chain_restraints = 32
    RULE_torsion_angle_w_chain_restraint = 33
    RULE_cco_restraints = 34
    RULE_cco_restraint = 35
    RULE_ssbond_macro = 36
    RULE_hbond_macro = 37
    RULE_link_statement = 38
    RULE_stereoassign_macro = 39
    RULE_declare_variable = 40
    RULE_set_variable = 41
    RULE_unset_variable = 42
    RULE_print_macro = 43
    RULE_unambig_atom_name_mapping = 44
    RULE_mapping_list = 45
    RULE_ambig_atom_name_mapping = 46
    RULE_ambig_list = 47
    RULE_number = 48
    RULE_gen_atom_name = 49

    ruleNames =  [ "cyana_mr", "comment", "distance_restraints", "distance_restraint", 
                   "torsion_angle_restraints", "torsion_angle_restraint", 
                   "rdc_restraints", "rdc_parameter", "rdc_restraint", "pcs_restraints", 
                   "pcs_parameter", "pcs_restraint", "fixres_distance_restraints", 
                   "fixres_distance_restraint", "fixresw_distance_restraints", 
                   "fixresw_distance_restraint", "fixresw2_distance_restraints", 
                   "fixresw2_distance_restraint", "fixatm_distance_restraints", 
                   "fixatm_distance_restraint", "fixatmw_distance_restraints", 
                   "fixatmw_distance_restraint", "fixatmw2_distance_restraints", 
                   "fixatmw2_distance_restraint", "qconvr_distance_restraints", 
                   "qconvr_distance_restraint", "distance_w_chain_restraints", 
                   "distance_w_chain_restraint", "distance_w_chain2_restraints", 
                   "distance_w_chain2_restraint", "distance_w_chain3_restraints", 
                   "distance_w_chain3_restraint", "torsion_angle_w_chain_restraints", 
                   "torsion_angle_w_chain_restraint", "cco_restraints", 
                   "cco_restraint", "ssbond_macro", "hbond_macro", "link_statement", 
                   "stereoassign_macro", "declare_variable", "set_variable", 
                   "unset_variable", "print_macro", "unambig_atom_name_mapping", 
                   "mapping_list", "ambig_atom_name_mapping", "ambig_list", 
                   "number", "gen_atom_name" ]

    EOF = Token.EOF
    Ambig_code=1
    Integer=2
    Float=3
    Float_DecimalComma=4
    Orientation_header=5
    Tensor_header=6
    SMCLN_COMMENT=7
    COMMENT=8
    NoeUpp=9
    NoeLow=10
    Type=11
    Equ_op=12
    Or=13
    Ssbond=14
    Ssbond_resids=15
    Hbond=16
    Link=17
    Atom_stereo=18
    Var=19
    Unset=20
    SetVar=21
    Print=22
    Residue=23
    Mapping=24
    Ambig=25
    Simple_name=26
    SPACE=27
    ENCLOSE_COMMENT=28
    SECTION_COMMENT=29
    LINE_COMMENT=30
    Any_name=31
    SPACE_CM=32
    RETURN_CM=33
    Atom1=34
    Atom2=35
    Residue1=36
    Residue2=37
    Equ_op_HB=38
    Integer_HB=39
    Simple_name_HB=40
    SPACE_HB=41
    RETURN_HB=42
    LINE_COMMENT_HB=43
    Double_quote_string=44
    SPACE_PR=45
    RETURN_PR=46
    LINE_COMMENT_PR=47
    Simple_name_VA=48
    SPACE_VA=49
    RETURN_VA=50
    LINE_COMMENT_VA=51
    Ambig_code_MP=52
    Integer_MP=53
    Simple_name_MP=54
    Equ_op_MP=55
    SPACE_MP=56
    RETURN_MP=57
    LINE_COMMENT_MP=58

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Cyana_mrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(CyanaMRParser.EOF, 0)

        def Orientation_header(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Orientation_header)
            else:
                return self.getToken(CyanaMRParser.Orientation_header, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_restraintsContext,i)


        def fixres_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixres_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixres_distance_restraintsContext,i)


        def fixresw_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixresw_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixresw_distance_restraintsContext,i)


        def fixresw2_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixresw2_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixresw2_distance_restraintsContext,i)


        def fixatm_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatm_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatm_distance_restraintsContext,i)


        def fixatmw_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatmw_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatmw_distance_restraintsContext,i)


        def fixatmw2_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatmw2_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatmw2_distance_restraintsContext,i)


        def qconvr_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Qconvr_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Qconvr_distance_restraintsContext,i)


        def distance_w_chain_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain_restraintsContext,i)


        def distance_w_chain2_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain2_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain2_restraintsContext,i)


        def distance_w_chain3_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain3_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain3_restraintsContext,i)


        def torsion_angle_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Torsion_angle_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Torsion_angle_restraintsContext,i)


        def torsion_angle_w_chain_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Torsion_angle_w_chain_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Torsion_angle_w_chain_restraintsContext,i)


        def rdc_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Rdc_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Rdc_restraintsContext,i)


        def pcs_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Pcs_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Pcs_restraintsContext,i)


        def cco_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Cco_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Cco_restraintsContext,i)


        def ssbond_macro(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Ssbond_macroContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Ssbond_macroContext,i)


        def hbond_macro(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Hbond_macroContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Hbond_macroContext,i)


        def link_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Link_statementContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Link_statementContext,i)


        def stereoassign_macro(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Stereoassign_macroContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Stereoassign_macroContext,i)


        def declare_variable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Declare_variableContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Declare_variableContext,i)


        def set_variable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Set_variableContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Set_variableContext,i)


        def unset_variable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Unset_variableContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Unset_variableContext,i)


        def print_macro(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Print_macroContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Print_macroContext,i)


        def unambig_atom_name_mapping(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Unambig_atom_name_mappingContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Unambig_atom_name_mappingContext,i)


        def ambig_atom_name_mapping(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Ambig_atom_name_mappingContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Ambig_atom_name_mappingContext,i)


        def Tensor_header(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Tensor_header)
            else:
                return self.getToken(CyanaMRParser.Tensor_header, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_cyana_mr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCyana_mr" ):
                listener.enterCyana_mr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCyana_mr" ):
                listener.exitCyana_mr(self)




    def cyana_mr(self):

        localctx = CyanaMRParser.Cyana_mrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_cyana_mr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 135
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 83838820) != 0):
                self.state = 133
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                if la_ == 1:
                    self.state = 100
                    self.match(CyanaMRParser.Orientation_header)
                    pass

                elif la_ == 2:
                    self.state = 102 
                    self._errHandler.sync(self)
                    _alt = 1
                    while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                        if _alt == 1:
                            self.state = 101
                            self.match(CyanaMRParser.Tensor_header)

                        else:
                            raise NoViableAltException(self)
                        self.state = 104 
                        self._errHandler.sync(self)
                        _alt = self._interp.adaptivePredict(self._input,0,self._ctx)

                    pass

                elif la_ == 3:
                    self.state = 106
                    self.comment()
                    pass

                elif la_ == 4:
                    self.state = 107
                    self.distance_restraints()
                    pass

                elif la_ == 5:
                    self.state = 108
                    self.fixres_distance_restraints()
                    pass

                elif la_ == 6:
                    self.state = 109
                    self.fixresw_distance_restraints()
                    pass

                elif la_ == 7:
                    self.state = 110
                    self.fixresw2_distance_restraints()
                    pass

                elif la_ == 8:
                    self.state = 111
                    self.fixatm_distance_restraints()
                    pass

                elif la_ == 9:
                    self.state = 112
                    self.fixatmw_distance_restraints()
                    pass

                elif la_ == 10:
                    self.state = 113
                    self.fixatmw2_distance_restraints()
                    pass

                elif la_ == 11:
                    self.state = 114
                    self.qconvr_distance_restraints()
                    pass

                elif la_ == 12:
                    self.state = 115
                    self.distance_w_chain_restraints()
                    pass

                elif la_ == 13:
                    self.state = 116
                    self.distance_w_chain2_restraints()
                    pass

                elif la_ == 14:
                    self.state = 117
                    self.distance_w_chain3_restraints()
                    pass

                elif la_ == 15:
                    self.state = 118
                    self.torsion_angle_restraints()
                    pass

                elif la_ == 16:
                    self.state = 119
                    self.torsion_angle_w_chain_restraints()
                    pass

                elif la_ == 17:
                    self.state = 120
                    self.rdc_restraints()
                    pass

                elif la_ == 18:
                    self.state = 121
                    self.pcs_restraints()
                    pass

                elif la_ == 19:
                    self.state = 122
                    self.cco_restraints()
                    pass

                elif la_ == 20:
                    self.state = 123
                    self.ssbond_macro()
                    pass

                elif la_ == 21:
                    self.state = 124
                    self.hbond_macro()
                    pass

                elif la_ == 22:
                    self.state = 125
                    self.link_statement()
                    pass

                elif la_ == 23:
                    self.state = 126
                    self.stereoassign_macro()
                    pass

                elif la_ == 24:
                    self.state = 127
                    self.declare_variable()
                    pass

                elif la_ == 25:
                    self.state = 128
                    self.set_variable()
                    pass

                elif la_ == 26:
                    self.state = 129
                    self.unset_variable()
                    pass

                elif la_ == 27:
                    self.state = 130
                    self.print_macro()
                    pass

                elif la_ == 28:
                    self.state = 131
                    self.unambig_atom_name_mapping()
                    pass

                elif la_ == 29:
                    self.state = 132
                    self.ambig_atom_name_mapping()
                    pass


                self.state = 137
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 138
            self.match(CyanaMRParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(CyanaMRParser.COMMENT, 0)

        def RETURN_CM(self):
            return self.getToken(CyanaMRParser.RETURN_CM, 0)

        def EOF(self):
            return self.getToken(CyanaMRParser.EOF, 0)

        def Any_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Any_name)
            else:
                return self.getToken(CyanaMRParser.Any_name, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)




    def comment(self):

        localctx = CyanaMRParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_comment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 140
            self.match(CyanaMRParser.COMMENT)
            self.state = 144
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==31:
                self.state = 141
                self.match(CyanaMRParser.Any_name)
                self.state = 146
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 147
            _la = self._input.LA(1)
            if not(_la==-1 or _la==33):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_restraints" ):
                listener.enterDistance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_restraints" ):
                listener.exitDistance_restraints(self)




    def distance_restraints(self):

        localctx = CyanaMRParser.Distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 149
                    self.distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 152 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def gen_atom_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_atom_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_atom_nameContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_restraint" ):
                listener.enterDistance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_restraint" ):
                listener.exitDistance_restraint(self)




    def distance_restraint(self):

        localctx = CyanaMRParser.Distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 154
            self.match(CyanaMRParser.Integer)
            self.state = 155
            self.match(CyanaMRParser.Simple_name)
            self.state = 156
            self.gen_atom_name()
            self.state = 157
            self.match(CyanaMRParser.Integer)
            self.state = 158
            self.match(CyanaMRParser.Simple_name)
            self.state = 159
            self.gen_atom_name()
            self.state = 160
            self.number()
            self.state = 162
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.state = 161
                self.number()


            self.state = 165
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.state = 164
                self.number()


            self.state = 168
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                self.state = 167
                self.number()


            self.state = 171
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                self.state = 170
                self.number()


            self.state = 174
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
            if la_ == 1:
                self.state = 173
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Torsion_angle_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def torsion_angle_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Torsion_angle_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Torsion_angle_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_torsion_angle_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTorsion_angle_restraints" ):
                listener.enterTorsion_angle_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTorsion_angle_restraints" ):
                listener.exitTorsion_angle_restraints(self)




    def torsion_angle_restraints(self):

        localctx = CyanaMRParser.Torsion_angle_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_torsion_angle_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 176
                    self.torsion_angle_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 179 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,10,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Torsion_angle_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def Type(self):
            return self.getToken(CyanaMRParser.Type, 0)

        def Equ_op(self):
            return self.getToken(CyanaMRParser.Equ_op, 0)

        def Or(self):
            return self.getToken(CyanaMRParser.Or, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_torsion_angle_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTorsion_angle_restraint" ):
                listener.enterTorsion_angle_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTorsion_angle_restraint" ):
                listener.exitTorsion_angle_restraint(self)




    def torsion_angle_restraint(self):

        localctx = CyanaMRParser.Torsion_angle_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_torsion_angle_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 181
            self.match(CyanaMRParser.Integer)
            self.state = 182
            self.match(CyanaMRParser.Simple_name)
            self.state = 183
            self.match(CyanaMRParser.Simple_name)
            self.state = 184
            self.number()
            self.state = 185
            self.number()
            self.state = 187
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.state = 186
                self.number()


            self.state = 192
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 189
                self.match(CyanaMRParser.Type)
                self.state = 190
                self.match(CyanaMRParser.Equ_op)
                self.state = 191
                self.match(CyanaMRParser.Integer)


            self.state = 195
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==13:
                self.state = 194
                self.match(CyanaMRParser.Or)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rdc_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def rdc_parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Rdc_parameterContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Rdc_parameterContext,i)


        def Orientation_header(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Orientation_header)
            else:
                return self.getToken(CyanaMRParser.Orientation_header, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def rdc_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Rdc_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Rdc_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_rdc_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRdc_restraints" ):
                listener.enterRdc_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRdc_restraints" ):
                listener.exitRdc_restraints(self)




    def rdc_restraints(self):

        localctx = CyanaMRParser.Rdc_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_rdc_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 198 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 197
                    self.rdc_parameter()

                else:
                    raise NoViableAltException(self)
                self.state = 200 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,14,self._ctx)

            self.state = 205 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 205
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [5]:
                        self.state = 202
                        self.match(CyanaMRParser.Orientation_header)
                        pass
                    elif token in [8]:
                        self.state = 203
                        self.comment()
                        pass
                    elif token in [2]:
                        self.state = 204
                        self.rdc_restraint()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 207 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,16,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rdc_parameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_rdc_parameter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRdc_parameter" ):
                listener.enterRdc_parameter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRdc_parameter" ):
                listener.exitRdc_parameter(self)




    def rdc_parameter(self):

        localctx = CyanaMRParser.Rdc_parameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_rdc_parameter)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 209
            self.match(CyanaMRParser.Integer)
            self.state = 210
            self.number()
            self.state = 211
            self.number()
            self.state = 212
            self.match(CyanaMRParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rdc_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_rdc_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRdc_restraint" ):
                listener.enterRdc_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRdc_restraint" ):
                listener.exitRdc_restraint(self)




    def rdc_restraint(self):

        localctx = CyanaMRParser.Rdc_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_rdc_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 214
            self.match(CyanaMRParser.Integer)
            self.state = 215
            self.match(CyanaMRParser.Simple_name)
            self.state = 216
            self.match(CyanaMRParser.Simple_name)
            self.state = 217
            self.match(CyanaMRParser.Integer)
            self.state = 218
            self.match(CyanaMRParser.Simple_name)
            self.state = 219
            self.match(CyanaMRParser.Simple_name)
            self.state = 220
            self.number()
            self.state = 221
            self.number()
            self.state = 222
            self.number()
            self.state = 223
            self.match(CyanaMRParser.Integer)
            self.state = 225
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.state = 224
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pcs_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def pcs_parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Pcs_parameterContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Pcs_parameterContext,i)


        def Orientation_header(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Orientation_header)
            else:
                return self.getToken(CyanaMRParser.Orientation_header, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def pcs_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Pcs_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Pcs_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_pcs_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPcs_restraints" ):
                listener.enterPcs_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPcs_restraints" ):
                listener.exitPcs_restraints(self)




    def pcs_restraints(self):

        localctx = CyanaMRParser.Pcs_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_pcs_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 228 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 227
                    self.pcs_parameter()

                else:
                    raise NoViableAltException(self)
                self.state = 230 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,18,self._ctx)

            self.state = 235 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 235
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [5]:
                        self.state = 232
                        self.match(CyanaMRParser.Orientation_header)
                        pass
                    elif token in [8]:
                        self.state = 233
                        self.comment()
                        pass
                    elif token in [2]:
                        self.state = 234
                        self.pcs_restraint()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 237 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,20,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pcs_parameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_pcs_parameter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPcs_parameter" ):
                listener.enterPcs_parameter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPcs_parameter" ):
                listener.exitPcs_parameter(self)




    def pcs_parameter(self):

        localctx = CyanaMRParser.Pcs_parameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_pcs_parameter)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 239
            self.match(CyanaMRParser.Integer)
            self.state = 240
            self.number()
            self.state = 241
            self.number()
            self.state = 242
            self.match(CyanaMRParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pcs_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_pcs_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPcs_restraint" ):
                listener.enterPcs_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPcs_restraint" ):
                listener.exitPcs_restraint(self)




    def pcs_restraint(self):

        localctx = CyanaMRParser.Pcs_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_pcs_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 244
            self.match(CyanaMRParser.Integer)
            self.state = 245
            self.match(CyanaMRParser.Simple_name)
            self.state = 246
            self.match(CyanaMRParser.Simple_name)
            self.state = 247
            self.number()
            self.state = 248
            self.number()
            self.state = 249
            self.number()
            self.state = 250
            self.match(CyanaMRParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixres_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixres_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixres_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixres_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixres_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixres_distance_restraints" ):
                listener.enterFixres_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixres_distance_restraints" ):
                listener.exitFixres_distance_restraints(self)




    def fixres_distance_restraints(self):

        localctx = CyanaMRParser.Fixres_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_fixres_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 253 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 252
                    self.fixres_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 255 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,21,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixres_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixres_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixres_distance_restraint" ):
                listener.enterFixres_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixres_distance_restraint" ):
                listener.exitFixres_distance_restraint(self)




    def fixres_distance_restraint(self):

        localctx = CyanaMRParser.Fixres_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_fixres_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 257
            self.match(CyanaMRParser.Integer)
            self.state = 258
            self.match(CyanaMRParser.Simple_name)
            self.state = 260
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
            if la_ == 1:
                self.state = 259
                self.comment()


            self.state = 268 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 268
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [26]:
                        self.state = 262
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 263
                        self.match(CyanaMRParser.Integer)
                        self.state = 264
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 265
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 266
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 267
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 270 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,24,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixresw_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixresw_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixresw_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixresw_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixresw_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixresw_distance_restraints" ):
                listener.enterFixresw_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixresw_distance_restraints" ):
                listener.exitFixresw_distance_restraints(self)




    def fixresw_distance_restraints(self):

        localctx = CyanaMRParser.Fixresw_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_fixresw_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 273 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 272
                    self.fixresw_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 275 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,25,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixresw_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixresw_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixresw_distance_restraint" ):
                listener.enterFixresw_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixresw_distance_restraint" ):
                listener.exitFixresw_distance_restraint(self)




    def fixresw_distance_restraint(self):

        localctx = CyanaMRParser.Fixresw_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_fixresw_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 277
            self.match(CyanaMRParser.Integer)
            self.state = 278
            self.match(CyanaMRParser.Simple_name)
            self.state = 280
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
            if la_ == 1:
                self.state = 279
                self.comment()


            self.state = 290 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 290
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [26]:
                        self.state = 282
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 283
                        self.match(CyanaMRParser.Integer)
                        self.state = 284
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 285
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 286
                        self.number()
                        self.state = 287
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 289
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 292 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,28,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixresw2_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixresw2_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixresw2_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixresw2_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixresw2_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixresw2_distance_restraints" ):
                listener.enterFixresw2_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixresw2_distance_restraints" ):
                listener.exitFixresw2_distance_restraints(self)




    def fixresw2_distance_restraints(self):

        localctx = CyanaMRParser.Fixresw2_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_fixresw2_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 295 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 294
                    self.fixresw2_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 297 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,29,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixresw2_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixresw2_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixresw2_distance_restraint" ):
                listener.enterFixresw2_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixresw2_distance_restraint" ):
                listener.exitFixresw2_distance_restraint(self)




    def fixresw2_distance_restraint(self):

        localctx = CyanaMRParser.Fixresw2_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_fixresw2_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 299
            self.match(CyanaMRParser.Integer)
            self.state = 300
            self.match(CyanaMRParser.Simple_name)
            self.state = 302
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,30,self._ctx)
            if la_ == 1:
                self.state = 301
                self.comment()


            self.state = 313 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 313
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [26]:
                        self.state = 304
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 305
                        self.match(CyanaMRParser.Integer)
                        self.state = 306
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 307
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 308
                        self.number()
                        self.state = 309
                        self.number()
                        self.state = 310
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 312
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 315 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,32,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatm_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixatm_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatm_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatm_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatm_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatm_distance_restraints" ):
                listener.enterFixatm_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatm_distance_restraints" ):
                listener.exitFixatm_distance_restraints(self)




    def fixatm_distance_restraints(self):

        localctx = CyanaMRParser.Fixatm_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_fixatm_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 318 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 317
                    self.fixatm_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 320 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,33,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatm_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatm_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatm_distance_restraint" ):
                listener.enterFixatm_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatm_distance_restraint" ):
                listener.exitFixatm_distance_restraint(self)




    def fixatm_distance_restraint(self):

        localctx = CyanaMRParser.Fixatm_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_fixatm_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 322
            self.match(CyanaMRParser.Integer)
            self.state = 323
            self.match(CyanaMRParser.Simple_name)
            self.state = 324
            self.match(CyanaMRParser.Simple_name)
            self.state = 326
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,34,self._ctx)
            if la_ == 1:
                self.state = 325
                self.comment()


            self.state = 333 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 333
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [2]:
                        self.state = 328
                        self.match(CyanaMRParser.Integer)
                        self.state = 329
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 330
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 331
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 332
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 335 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,36,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatmw_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixatmw_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatmw_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatmw_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatmw_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatmw_distance_restraints" ):
                listener.enterFixatmw_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatmw_distance_restraints" ):
                listener.exitFixatmw_distance_restraints(self)




    def fixatmw_distance_restraints(self):

        localctx = CyanaMRParser.Fixatmw_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_fixatmw_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 338 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 337
                    self.fixatmw_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 340 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,37,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatmw_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatmw_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatmw_distance_restraint" ):
                listener.enterFixatmw_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatmw_distance_restraint" ):
                listener.exitFixatmw_distance_restraint(self)




    def fixatmw_distance_restraint(self):

        localctx = CyanaMRParser.Fixatmw_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_fixatmw_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 342
            self.match(CyanaMRParser.Integer)
            self.state = 343
            self.match(CyanaMRParser.Simple_name)
            self.state = 344
            self.match(CyanaMRParser.Simple_name)
            self.state = 346
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,38,self._ctx)
            if la_ == 1:
                self.state = 345
                self.comment()


            self.state = 355 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 355
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [2]:
                        self.state = 348
                        self.match(CyanaMRParser.Integer)
                        self.state = 349
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 350
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 351
                        self.number()
                        self.state = 352
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 354
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 357 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,40,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatmw2_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixatmw2_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatmw2_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatmw2_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatmw2_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatmw2_distance_restraints" ):
                listener.enterFixatmw2_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatmw2_distance_restraints" ):
                listener.exitFixatmw2_distance_restraints(self)




    def fixatmw2_distance_restraints(self):

        localctx = CyanaMRParser.Fixatmw2_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_fixatmw2_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 360 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 359
                    self.fixatmw2_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 362 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,41,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatmw2_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatmw2_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatmw2_distance_restraint" ):
                listener.enterFixatmw2_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatmw2_distance_restraint" ):
                listener.exitFixatmw2_distance_restraint(self)




    def fixatmw2_distance_restraint(self):

        localctx = CyanaMRParser.Fixatmw2_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_fixatmw2_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 364
            self.match(CyanaMRParser.Integer)
            self.state = 365
            self.match(CyanaMRParser.Simple_name)
            self.state = 366
            self.match(CyanaMRParser.Simple_name)
            self.state = 368
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,42,self._ctx)
            if la_ == 1:
                self.state = 367
                self.comment()


            self.state = 378 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 378
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [2]:
                        self.state = 370
                        self.match(CyanaMRParser.Integer)
                        self.state = 371
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 372
                        self.match(CyanaMRParser.Simple_name)
                        self.state = 373
                        self.number()
                        self.state = 374
                        self.number()
                        self.state = 375
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 377
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 380 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,44,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Qconvr_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def qconvr_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Qconvr_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Qconvr_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_qconvr_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQconvr_distance_restraints" ):
                listener.enterQconvr_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQconvr_distance_restraints" ):
                listener.exitQconvr_distance_restraints(self)




    def qconvr_distance_restraints(self):

        localctx = CyanaMRParser.Qconvr_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_qconvr_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 383 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 382
                    self.qconvr_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 385 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,45,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Qconvr_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self):
            return self.getTypedRuleContext(CyanaMRParser.NumberContext,0)


        def NoeUpp(self):
            return self.getToken(CyanaMRParser.NoeUpp, 0)

        def NoeLow(self):
            return self.getToken(CyanaMRParser.NoeLow, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_qconvr_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQconvr_distance_restraint" ):
                listener.enterQconvr_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQconvr_distance_restraint" ):
                listener.exitQconvr_distance_restraint(self)




    def qconvr_distance_restraint(self):

        localctx = CyanaMRParser.Qconvr_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_qconvr_distance_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 387
            _la = self._input.LA(1)
            if not(_la==9 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 388
            self.match(CyanaMRParser.Simple_name)
            self.state = 389
            self.match(CyanaMRParser.Integer)
            self.state = 390
            self.match(CyanaMRParser.Simple_name)
            self.state = 391
            self.match(CyanaMRParser.Simple_name)
            self.state = 392
            self.match(CyanaMRParser.Integer)
            self.state = 393
            self.match(CyanaMRParser.Simple_name)
            self.state = 394
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def distance_w_chain_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain_restraints" ):
                listener.enterDistance_w_chain_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain_restraints" ):
                listener.exitDistance_w_chain_restraints(self)




    def distance_w_chain_restraints(self):

        localctx = CyanaMRParser.Distance_w_chain_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_distance_w_chain_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 397 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 396
                    self.distance_w_chain_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 399 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,46,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain_restraint" ):
                listener.enterDistance_w_chain_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain_restraint" ):
                listener.exitDistance_w_chain_restraint(self)




    def distance_w_chain_restraint(self):

        localctx = CyanaMRParser.Distance_w_chain_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_distance_w_chain_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 401
            self.match(CyanaMRParser.Integer)
            self.state = 402
            self.match(CyanaMRParser.Simple_name)
            self.state = 403
            self.match(CyanaMRParser.Simple_name)
            self.state = 404
            self.match(CyanaMRParser.Simple_name)
            self.state = 405
            self.match(CyanaMRParser.Integer)
            self.state = 406
            self.match(CyanaMRParser.Simple_name)
            self.state = 407
            self.match(CyanaMRParser.Simple_name)
            self.state = 408
            self.match(CyanaMRParser.Simple_name)
            self.state = 409
            self.number()
            self.state = 411
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,47,self._ctx)
            if la_ == 1:
                self.state = 410
                self.number()


            self.state = 414
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,48,self._ctx)
            if la_ == 1:
                self.state = 413
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain2_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def distance_w_chain2_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain2_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain2_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain2_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain2_restraints" ):
                listener.enterDistance_w_chain2_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain2_restraints" ):
                listener.exitDistance_w_chain2_restraints(self)




    def distance_w_chain2_restraints(self):

        localctx = CyanaMRParser.Distance_w_chain2_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_distance_w_chain2_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 417 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 416
                    self.distance_w_chain2_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 419 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,49,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain2_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain2_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain2_restraint" ):
                listener.enterDistance_w_chain2_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain2_restraint" ):
                listener.exitDistance_w_chain2_restraint(self)




    def distance_w_chain2_restraint(self):

        localctx = CyanaMRParser.Distance_w_chain2_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_distance_w_chain2_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 421
            self.match(CyanaMRParser.Simple_name)
            self.state = 422
            self.match(CyanaMRParser.Integer)
            self.state = 423
            self.match(CyanaMRParser.Simple_name)
            self.state = 424
            self.match(CyanaMRParser.Simple_name)
            self.state = 425
            self.match(CyanaMRParser.Simple_name)
            self.state = 426
            self.match(CyanaMRParser.Integer)
            self.state = 427
            self.match(CyanaMRParser.Simple_name)
            self.state = 428
            self.match(CyanaMRParser.Simple_name)
            self.state = 429
            self.number()
            self.state = 431
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,50,self._ctx)
            if la_ == 1:
                self.state = 430
                self.number()


            self.state = 434
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,51,self._ctx)
            if la_ == 1:
                self.state = 433
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain3_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def distance_w_chain3_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain3_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain3_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain3_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain3_restraints" ):
                listener.enterDistance_w_chain3_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain3_restraints" ):
                listener.exitDistance_w_chain3_restraints(self)




    def distance_w_chain3_restraints(self):

        localctx = CyanaMRParser.Distance_w_chain3_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_distance_w_chain3_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 437 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 436
                    self.distance_w_chain3_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 439 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,52,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain3_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain3_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain3_restraint" ):
                listener.enterDistance_w_chain3_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain3_restraint" ):
                listener.exitDistance_w_chain3_restraint(self)




    def distance_w_chain3_restraint(self):

        localctx = CyanaMRParser.Distance_w_chain3_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_distance_w_chain3_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 441
            self.match(CyanaMRParser.Simple_name)
            self.state = 442
            self.match(CyanaMRParser.Simple_name)
            self.state = 443
            self.match(CyanaMRParser.Integer)
            self.state = 444
            self.match(CyanaMRParser.Simple_name)
            self.state = 445
            self.match(CyanaMRParser.Simple_name)
            self.state = 446
            self.match(CyanaMRParser.Simple_name)
            self.state = 447
            self.match(CyanaMRParser.Integer)
            self.state = 448
            self.match(CyanaMRParser.Simple_name)
            self.state = 449
            self.number()
            self.state = 451
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,53,self._ctx)
            if la_ == 1:
                self.state = 450
                self.number()


            self.state = 454
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,54,self._ctx)
            if la_ == 1:
                self.state = 453
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Torsion_angle_w_chain_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def torsion_angle_w_chain_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Torsion_angle_w_chain_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Torsion_angle_w_chain_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_torsion_angle_w_chain_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTorsion_angle_w_chain_restraints" ):
                listener.enterTorsion_angle_w_chain_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTorsion_angle_w_chain_restraints" ):
                listener.exitTorsion_angle_w_chain_restraints(self)




    def torsion_angle_w_chain_restraints(self):

        localctx = CyanaMRParser.Torsion_angle_w_chain_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_torsion_angle_w_chain_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 457 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 456
                    self.torsion_angle_w_chain_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 459 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,55,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Torsion_angle_w_chain_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def Type(self):
            return self.getToken(CyanaMRParser.Type, 0)

        def Equ_op(self):
            return self.getToken(CyanaMRParser.Equ_op, 0)

        def Or(self):
            return self.getToken(CyanaMRParser.Or, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_torsion_angle_w_chain_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTorsion_angle_w_chain_restraint" ):
                listener.enterTorsion_angle_w_chain_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTorsion_angle_w_chain_restraint" ):
                listener.exitTorsion_angle_w_chain_restraint(self)




    def torsion_angle_w_chain_restraint(self):

        localctx = CyanaMRParser.Torsion_angle_w_chain_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_torsion_angle_w_chain_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 461
            self.match(CyanaMRParser.Simple_name)
            self.state = 462
            self.match(CyanaMRParser.Integer)
            self.state = 463
            self.match(CyanaMRParser.Simple_name)
            self.state = 464
            self.match(CyanaMRParser.Simple_name)
            self.state = 465
            self.number()
            self.state = 466
            self.number()
            self.state = 468
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,56,self._ctx)
            if la_ == 1:
                self.state = 467
                self.number()


            self.state = 473
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 470
                self.match(CyanaMRParser.Type)
                self.state = 471
                self.match(CyanaMRParser.Equ_op)
                self.state = 472
                self.match(CyanaMRParser.Integer)


            self.state = 476
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==13:
                self.state = 475
                self.match(CyanaMRParser.Or)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cco_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def cco_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Cco_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Cco_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_cco_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCco_restraints" ):
                listener.enterCco_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCco_restraints" ):
                listener.exitCco_restraints(self)




    def cco_restraints(self):

        localctx = CyanaMRParser.Cco_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_cco_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 479 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 478
                    self.cco_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 481 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,59,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cco_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self):
            return self.getToken(CyanaMRParser.Integer, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_cco_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCco_restraint" ):
                listener.enterCco_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCco_restraint" ):
                listener.exitCco_restraint(self)




    def cco_restraint(self):

        localctx = CyanaMRParser.Cco_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_cco_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 483
            self.match(CyanaMRParser.Integer)
            self.state = 484
            self.match(CyanaMRParser.Simple_name)
            self.state = 485
            self.match(CyanaMRParser.Simple_name)
            self.state = 486
            self.match(CyanaMRParser.Simple_name)
            self.state = 487
            self.number()
            self.state = 489
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,60,self._ctx)
            if la_ == 1:
                self.state = 488
                self.number()


            self.state = 492
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,61,self._ctx)
            if la_ == 1:
                self.state = 491
                self.number()


            self.state = 495
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,62,self._ctx)
            if la_ == 1:
                self.state = 494
                self.number()


            self.state = 498
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,63,self._ctx)
            if la_ == 1:
                self.state = 497
                self.number()


            self.state = 501
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,64,self._ctx)
            if la_ == 1:
                self.state = 500
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ssbond_macroContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Ssbond(self):
            return self.getToken(CyanaMRParser.Ssbond, 0)

        def Ssbond_resids(self):
            return self.getToken(CyanaMRParser.Ssbond_resids, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_ssbond_macro

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSsbond_macro" ):
                listener.enterSsbond_macro(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSsbond_macro" ):
                listener.exitSsbond_macro(self)




    def ssbond_macro(self):

        localctx = CyanaMRParser.Ssbond_macroContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_ssbond_macro)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 503
            self.match(CyanaMRParser.Ssbond)
            self.state = 504
            self.match(CyanaMRParser.Ssbond_resids)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Hbond_macroContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Hbond(self):
            return self.getToken(CyanaMRParser.Hbond, 0)

        def Simple_name_HB(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name_HB)
            else:
                return self.getToken(CyanaMRParser.Simple_name_HB, i)

        def Integer_HB(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer_HB)
            else:
                return self.getToken(CyanaMRParser.Integer_HB, i)

        def RETURN_HB(self):
            return self.getToken(CyanaMRParser.RETURN_HB, 0)

        def Atom1(self):
            return self.getToken(CyanaMRParser.Atom1, 0)

        def Equ_op_HB(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Equ_op_HB)
            else:
                return self.getToken(CyanaMRParser.Equ_op_HB, i)

        def Residue1(self):
            return self.getToken(CyanaMRParser.Residue1, 0)

        def Atom2(self):
            return self.getToken(CyanaMRParser.Atom2, 0)

        def Residue2(self):
            return self.getToken(CyanaMRParser.Residue2, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_hbond_macro

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHbond_macro" ):
                listener.enterHbond_macro(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHbond_macro" ):
                listener.exitHbond_macro(self)




    def hbond_macro(self):

        localctx = CyanaMRParser.Hbond_macroContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_hbond_macro)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 506
            self.match(CyanaMRParser.Hbond)
            self.state = 509
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==34:
                self.state = 507
                self.match(CyanaMRParser.Atom1)
                self.state = 508
                self.match(CyanaMRParser.Equ_op_HB)


            self.state = 511
            self.match(CyanaMRParser.Simple_name_HB)
            self.state = 514
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 512
                self.match(CyanaMRParser.Residue1)
                self.state = 513
                self.match(CyanaMRParser.Equ_op_HB)


            self.state = 516
            self.match(CyanaMRParser.Integer_HB)
            self.state = 519
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 517
                self.match(CyanaMRParser.Atom2)
                self.state = 518
                self.match(CyanaMRParser.Equ_op_HB)


            self.state = 521
            self.match(CyanaMRParser.Simple_name_HB)
            self.state = 524
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==37:
                self.state = 522
                self.match(CyanaMRParser.Residue2)
                self.state = 523
                self.match(CyanaMRParser.Equ_op_HB)


            self.state = 526
            self.match(CyanaMRParser.Integer_HB)
            self.state = 527
            self.match(CyanaMRParser.RETURN_HB)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Link_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Link(self):
            return self.getToken(CyanaMRParser.Link, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name)
            else:
                return self.getToken(CyanaMRParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_link_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLink_statement" ):
                listener.enterLink_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLink_statement" ):
                listener.exitLink_statement(self)




    def link_statement(self):

        localctx = CyanaMRParser.Link_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_link_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 529
            self.match(CyanaMRParser.Link)
            self.state = 530
            self.match(CyanaMRParser.Simple_name)
            self.state = 531
            self.match(CyanaMRParser.Integer)
            self.state = 532
            self.match(CyanaMRParser.Simple_name)
            self.state = 533
            self.match(CyanaMRParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Stereoassign_macroContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Atom_stereo(self):
            return self.getToken(CyanaMRParser.Atom_stereo, 0)

        def Double_quote_string(self):
            return self.getToken(CyanaMRParser.Double_quote_string, 0)

        def RETURN_PR(self):
            return self.getToken(CyanaMRParser.RETURN_PR, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_stereoassign_macro

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStereoassign_macro" ):
                listener.enterStereoassign_macro(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStereoassign_macro" ):
                listener.exitStereoassign_macro(self)




    def stereoassign_macro(self):

        localctx = CyanaMRParser.Stereoassign_macroContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_stereoassign_macro)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 535
            self.match(CyanaMRParser.Atom_stereo)
            self.state = 536
            self.match(CyanaMRParser.Double_quote_string)
            self.state = 537
            self.match(CyanaMRParser.RETURN_PR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Declare_variableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Var(self):
            return self.getToken(CyanaMRParser.Var, 0)

        def RETURN_VA(self):
            return self.getToken(CyanaMRParser.RETURN_VA, 0)

        def Simple_name_VA(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name_VA)
            else:
                return self.getToken(CyanaMRParser.Simple_name_VA, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_declare_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclare_variable" ):
                listener.enterDeclare_variable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclare_variable" ):
                listener.exitDeclare_variable(self)




    def declare_variable(self):

        localctx = CyanaMRParser.Declare_variableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_declare_variable)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 539
            self.match(CyanaMRParser.Var)
            self.state = 543
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==48:
                self.state = 540
                self.match(CyanaMRParser.Simple_name_VA)
                self.state = 545
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 546
            self.match(CyanaMRParser.RETURN_VA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Set_variableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SetVar(self):
            return self.getToken(CyanaMRParser.SetVar, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_set_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSet_variable" ):
                listener.enterSet_variable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSet_variable" ):
                listener.exitSet_variable(self)




    def set_variable(self):

        localctx = CyanaMRParser.Set_variableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_set_variable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 548
            self.match(CyanaMRParser.SetVar)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Unset_variableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Unset(self):
            return self.getToken(CyanaMRParser.Unset, 0)

        def RETURN_VA(self):
            return self.getToken(CyanaMRParser.RETURN_VA, 0)

        def Simple_name_VA(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name_VA)
            else:
                return self.getToken(CyanaMRParser.Simple_name_VA, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_unset_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnset_variable" ):
                listener.enterUnset_variable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnset_variable" ):
                listener.exitUnset_variable(self)




    def unset_variable(self):

        localctx = CyanaMRParser.Unset_variableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_unset_variable)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 550
            self.match(CyanaMRParser.Unset)
            self.state = 554
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==48:
                self.state = 551
                self.match(CyanaMRParser.Simple_name_VA)
                self.state = 556
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 557
            self.match(CyanaMRParser.RETURN_VA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Print_macroContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Print(self):
            return self.getToken(CyanaMRParser.Print, 0)

        def Double_quote_string(self):
            return self.getToken(CyanaMRParser.Double_quote_string, 0)

        def RETURN_PR(self):
            return self.getToken(CyanaMRParser.RETURN_PR, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_print_macro

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrint_macro" ):
                listener.enterPrint_macro(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrint_macro" ):
                listener.exitPrint_macro(self)




    def print_macro(self):

        localctx = CyanaMRParser.Print_macroContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_print_macro)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 559
            self.match(CyanaMRParser.Print)
            self.state = 560
            self.match(CyanaMRParser.Double_quote_string)
            self.state = 561
            self.match(CyanaMRParser.RETURN_PR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Unambig_atom_name_mappingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Residue(self):
            return self.getToken(CyanaMRParser.Residue, 0)

        def Simple_name(self):
            return self.getToken(CyanaMRParser.Simple_name, 0)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def mapping_list(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Mapping_listContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Mapping_listContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_unambig_atom_name_mapping

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnambig_atom_name_mapping" ):
                listener.enterUnambig_atom_name_mapping(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnambig_atom_name_mapping" ):
                listener.exitUnambig_atom_name_mapping(self)




    def unambig_atom_name_mapping(self):

        localctx = CyanaMRParser.Unambig_atom_name_mappingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_unambig_atom_name_mapping)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 563
            self.match(CyanaMRParser.Residue)
            self.state = 564
            self.match(CyanaMRParser.Simple_name)
            self.state = 566
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,71,self._ctx)
            if la_ == 1:
                self.state = 565
                self.comment()


            self.state = 570 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 570
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [24]:
                        self.state = 568
                        self.mapping_list()
                        pass
                    elif token in [8]:
                        self.state = 569
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 572 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,73,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mapping_listContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Mapping(self):
            return self.getToken(CyanaMRParser.Mapping, 0)

        def Simple_name_MP(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name_MP)
            else:
                return self.getToken(CyanaMRParser.Simple_name_MP, i)

        def Equ_op_MP(self):
            return self.getToken(CyanaMRParser.Equ_op_MP, 0)

        def RETURN_MP(self):
            return self.getToken(CyanaMRParser.RETURN_MP, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_mapping_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapping_list" ):
                listener.enterMapping_list(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapping_list" ):
                listener.exitMapping_list(self)




    def mapping_list(self):

        localctx = CyanaMRParser.Mapping_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_mapping_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 574
            self.match(CyanaMRParser.Mapping)
            self.state = 575
            self.match(CyanaMRParser.Simple_name_MP)
            self.state = 576
            self.match(CyanaMRParser.Equ_op_MP)
            self.state = 578 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 577
                self.match(CyanaMRParser.Simple_name_MP)
                self.state = 580 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==54):
                    break

            self.state = 582
            self.match(CyanaMRParser.RETURN_MP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ambig_atom_name_mappingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Residue(self):
            return self.getToken(CyanaMRParser.Residue, 0)

        def Simple_name(self):
            return self.getToken(CyanaMRParser.Simple_name, 0)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def ambig_list(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Ambig_listContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Ambig_listContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_ambig_atom_name_mapping

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAmbig_atom_name_mapping" ):
                listener.enterAmbig_atom_name_mapping(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAmbig_atom_name_mapping" ):
                listener.exitAmbig_atom_name_mapping(self)




    def ambig_atom_name_mapping(self):

        localctx = CyanaMRParser.Ambig_atom_name_mappingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_ambig_atom_name_mapping)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 584
            self.match(CyanaMRParser.Residue)
            self.state = 585
            self.match(CyanaMRParser.Simple_name)
            self.state = 587
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,75,self._ctx)
            if la_ == 1:
                self.state = 586
                self.comment()


            self.state = 591 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 591
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [25]:
                        self.state = 589
                        self.ambig_list()
                        pass
                    elif token in [8]:
                        self.state = 590
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 593 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,77,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ambig_listContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Ambig(self):
            return self.getToken(CyanaMRParser.Ambig, 0)

        def Equ_op_MP(self):
            return self.getToken(CyanaMRParser.Equ_op_MP, 0)

        def RETURN_MP(self):
            return self.getToken(CyanaMRParser.RETURN_MP, 0)

        def Simple_name_MP(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name_MP)
            else:
                return self.getToken(CyanaMRParser.Simple_name_MP, i)

        def Ambig_code_MP(self):
            return self.getToken(CyanaMRParser.Ambig_code_MP, 0)

        def Integer_MP(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer_MP)
            else:
                return self.getToken(CyanaMRParser.Integer_MP, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_ambig_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAmbig_list" ):
                listener.enterAmbig_list(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAmbig_list" ):
                listener.exitAmbig_list(self)




    def ambig_list(self):

        localctx = CyanaMRParser.Ambig_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_ambig_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 595
            self.match(CyanaMRParser.Ambig)
            self.state = 596
            _la = self._input.LA(1)
            if not(_la==52 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 597
            self.match(CyanaMRParser.Equ_op_MP)
            self.state = 600 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 598
                self.match(CyanaMRParser.Simple_name_MP)
                self.state = 599
                self.match(CyanaMRParser.Integer_MP)
                self.state = 602 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==54):
                    break

            self.state = 604
            self.match(CyanaMRParser.RETURN_MP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(CyanaMRParser.Float, 0)

        def Float_DecimalComma(self):
            return self.getToken(CyanaMRParser.Float_DecimalComma, 0)

        def Integer(self):
            return self.getToken(CyanaMRParser.Integer, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = CyanaMRParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 606
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 28) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Gen_atom_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self):
            return self.getToken(CyanaMRParser.Simple_name, 0)

        def Ambig_code(self):
            return self.getToken(CyanaMRParser.Ambig_code, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_gen_atom_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGen_atom_name" ):
                listener.enterGen_atom_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGen_atom_name" ):
                listener.exitGen_atom_name(self)




    def gen_atom_name(self):

        localctx = CyanaMRParser.Gen_atom_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_gen_atom_name)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 608
            _la = self._input.LA(1)
            if not(_la==1 or _la==26):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





