# Generated from XeasyPKParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,44,295,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,1,0,3,0,40,8,0,
        1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,5,0,53,8,0,10,0,12,0,
        56,9,0,1,0,1,0,3,0,60,8,0,1,0,1,0,1,1,1,1,1,1,1,1,1,2,1,2,1,2,1,
        2,1,3,1,3,4,3,74,8,3,11,3,12,3,75,1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,
        5,1,5,1,5,1,5,1,6,1,6,4,6,91,8,6,11,6,12,6,92,1,6,1,6,1,7,1,7,4,
        7,99,8,7,11,7,12,7,100,1,7,1,7,1,8,1,8,4,8,107,8,8,11,8,12,8,108,
        1,9,1,9,1,9,1,9,1,9,3,9,116,8,9,1,9,1,9,1,9,3,9,121,8,9,1,9,1,9,
        1,9,1,9,1,9,3,9,128,8,9,1,9,3,9,131,8,9,1,9,1,9,1,9,3,9,136,8,9,
        3,9,138,8,9,1,9,1,9,1,9,3,9,143,8,9,1,9,3,9,146,8,9,1,9,1,9,1,9,
        3,9,151,8,9,5,9,153,8,9,10,9,12,9,156,9,9,1,10,1,10,4,10,160,8,10,
        11,10,12,10,161,1,11,1,11,1,11,1,11,1,11,1,11,3,11,170,8,11,1,11,
        1,11,1,11,3,11,175,8,11,1,11,1,11,1,11,1,11,1,11,1,11,3,11,183,8,
        11,1,11,3,11,186,8,11,1,11,1,11,1,11,3,11,191,8,11,3,11,193,8,11,
        1,11,1,11,1,11,1,11,3,11,199,8,11,1,11,3,11,202,8,11,1,11,1,11,1,
        11,3,11,207,8,11,5,11,209,8,11,10,11,12,11,212,9,11,1,12,1,12,4,
        12,216,8,12,11,12,12,12,217,1,13,1,13,1,13,1,13,1,13,1,13,1,13,3,
        13,227,8,13,1,13,1,13,1,13,3,13,232,8,13,1,13,1,13,1,13,1,13,1,13,
        1,13,1,13,3,13,241,8,13,1,13,3,13,244,8,13,1,13,1,13,1,13,3,13,249,
        8,13,3,13,251,8,13,1,13,1,13,1,13,1,13,1,13,3,13,258,8,13,1,13,3,
        13,261,8,13,1,13,1,13,1,13,3,13,266,8,13,5,13,268,8,13,10,13,12,
        13,271,9,13,1,14,1,14,1,15,1,15,1,16,1,16,1,17,1,17,1,17,3,17,282,
        8,17,3,17,284,8,17,1,18,1,18,5,18,288,8,18,10,18,12,18,291,9,18,
        1,18,1,18,1,18,0,0,19,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,
        32,34,36,0,5,1,1,17,17,1,0,9,10,2,0,9,11,15,15,2,0,9,9,15,15,1,1,
        44,44,337,0,39,1,0,0,0,2,63,1,0,0,0,4,67,1,0,0,0,6,71,1,0,0,0,8,
        79,1,0,0,0,10,84,1,0,0,0,12,88,1,0,0,0,14,96,1,0,0,0,16,106,1,0,
        0,0,18,110,1,0,0,0,20,159,1,0,0,0,22,163,1,0,0,0,24,215,1,0,0,0,
        26,219,1,0,0,0,28,272,1,0,0,0,30,274,1,0,0,0,32,276,1,0,0,0,34,283,
        1,0,0,0,36,285,1,0,0,0,38,40,5,17,0,0,39,38,1,0,0,0,39,40,1,0,0,
        0,40,54,1,0,0,0,41,53,3,2,1,0,42,53,3,4,2,0,43,53,3,6,3,0,44,53,
        3,8,4,0,45,53,3,10,5,0,46,53,3,12,6,0,47,53,3,14,7,0,48,53,3,16,
        8,0,49,53,3,20,10,0,50,53,3,24,12,0,51,53,5,17,0,0,52,41,1,0,0,0,
        52,42,1,0,0,0,52,43,1,0,0,0,52,44,1,0,0,0,52,45,1,0,0,0,52,46,1,
        0,0,0,52,47,1,0,0,0,52,48,1,0,0,0,52,49,1,0,0,0,52,50,1,0,0,0,52,
        51,1,0,0,0,53,56,1,0,0,0,54,52,1,0,0,0,54,55,1,0,0,0,55,59,1,0,0,
        0,56,54,1,0,0,0,57,60,5,17,0,0,58,60,3,36,18,0,59,57,1,0,0,0,59,
        58,1,0,0,0,59,60,1,0,0,0,60,61,1,0,0,0,61,62,5,0,0,1,62,1,1,0,0,
        0,63,64,5,1,0,0,64,65,5,20,0,0,65,66,5,22,0,0,66,3,1,0,0,0,67,68,
        5,2,0,0,68,69,5,23,0,0,69,70,5,25,0,0,70,5,1,0,0,0,71,73,5,3,0,0,
        72,74,5,26,0,0,73,72,1,0,0,0,74,75,1,0,0,0,75,73,1,0,0,0,75,76,1,
        0,0,0,76,77,1,0,0,0,77,78,5,28,0,0,78,7,1,0,0,0,79,80,5,5,0,0,80,
        81,5,29,0,0,81,82,5,30,0,0,82,83,5,32,0,0,83,9,1,0,0,0,84,85,5,6,
        0,0,85,86,5,33,0,0,86,87,5,35,0,0,87,11,1,0,0,0,88,90,5,7,0,0,89,
        91,5,36,0,0,90,89,1,0,0,0,91,92,1,0,0,0,92,90,1,0,0,0,92,93,1,0,
        0,0,93,94,1,0,0,0,94,95,5,38,0,0,95,13,1,0,0,0,96,98,5,8,0,0,97,
        99,5,39,0,0,98,97,1,0,0,0,99,100,1,0,0,0,100,98,1,0,0,0,100,101,
        1,0,0,0,101,102,1,0,0,0,102,103,5,41,0,0,103,15,1,0,0,0,104,107,
        3,18,9,0,105,107,3,36,18,0,106,104,1,0,0,0,106,105,1,0,0,0,107,108,
        1,0,0,0,108,106,1,0,0,0,108,109,1,0,0,0,109,17,1,0,0,0,110,111,5,
        9,0,0,111,112,3,28,14,0,112,113,3,28,14,0,113,115,5,9,0,0,114,116,
        5,15,0,0,115,114,1,0,0,0,115,116,1,0,0,0,116,117,1,0,0,0,117,118,
        3,30,15,0,118,120,3,30,15,0,119,121,5,15,0,0,120,119,1,0,0,0,120,
        121,1,0,0,0,121,122,1,0,0,0,122,137,3,32,16,0,123,138,7,0,0,0,124,
        125,3,34,17,0,125,127,3,34,17,0,126,128,5,9,0,0,127,126,1,0,0,0,
        127,128,1,0,0,0,128,130,1,0,0,0,129,131,5,9,0,0,130,129,1,0,0,0,
        130,131,1,0,0,0,131,135,1,0,0,0,132,136,5,17,0,0,133,136,3,36,18,
        0,134,136,5,0,0,1,135,132,1,0,0,0,135,133,1,0,0,0,135,134,1,0,0,
        0,136,138,1,0,0,0,137,123,1,0,0,0,137,124,1,0,0,0,138,154,1,0,0,
        0,139,140,3,34,17,0,140,142,3,34,17,0,141,143,5,9,0,0,142,141,1,
        0,0,0,142,143,1,0,0,0,143,145,1,0,0,0,144,146,5,9,0,0,145,144,1,
        0,0,0,145,146,1,0,0,0,146,150,1,0,0,0,147,151,5,17,0,0,148,151,3,
        36,18,0,149,151,5,0,0,1,150,147,1,0,0,0,150,148,1,0,0,0,150,149,
        1,0,0,0,151,153,1,0,0,0,152,139,1,0,0,0,153,156,1,0,0,0,154,152,
        1,0,0,0,154,155,1,0,0,0,155,19,1,0,0,0,156,154,1,0,0,0,157,160,3,
        22,11,0,158,160,3,36,18,0,159,157,1,0,0,0,159,158,1,0,0,0,160,161,
        1,0,0,0,161,159,1,0,0,0,161,162,1,0,0,0,162,21,1,0,0,0,163,164,5,
        9,0,0,164,165,3,28,14,0,165,166,3,28,14,0,166,167,3,28,14,0,167,
        169,5,9,0,0,168,170,5,15,0,0,169,168,1,0,0,0,169,170,1,0,0,0,170,
        171,1,0,0,0,171,172,3,30,15,0,172,174,3,30,15,0,173,175,5,15,0,0,
        174,173,1,0,0,0,174,175,1,0,0,0,175,176,1,0,0,0,176,192,3,32,16,
        0,177,193,7,0,0,0,178,179,3,34,17,0,179,180,3,34,17,0,180,182,3,
        34,17,0,181,183,5,9,0,0,182,181,1,0,0,0,182,183,1,0,0,0,183,185,
        1,0,0,0,184,186,5,9,0,0,185,184,1,0,0,0,185,186,1,0,0,0,186,190,
        1,0,0,0,187,191,5,17,0,0,188,191,3,36,18,0,189,191,5,0,0,1,190,187,
        1,0,0,0,190,188,1,0,0,0,190,189,1,0,0,0,191,193,1,0,0,0,192,177,
        1,0,0,0,192,178,1,0,0,0,193,210,1,0,0,0,194,195,3,34,17,0,195,196,
        3,34,17,0,196,198,3,34,17,0,197,199,5,9,0,0,198,197,1,0,0,0,198,
        199,1,0,0,0,199,201,1,0,0,0,200,202,5,9,0,0,201,200,1,0,0,0,201,
        202,1,0,0,0,202,206,1,0,0,0,203,207,5,17,0,0,204,207,3,36,18,0,205,
        207,5,0,0,1,206,203,1,0,0,0,206,204,1,0,0,0,206,205,1,0,0,0,207,
        209,1,0,0,0,208,194,1,0,0,0,209,212,1,0,0,0,210,208,1,0,0,0,210,
        211,1,0,0,0,211,23,1,0,0,0,212,210,1,0,0,0,213,216,3,26,13,0,214,
        216,3,36,18,0,215,213,1,0,0,0,215,214,1,0,0,0,216,217,1,0,0,0,217,
        215,1,0,0,0,217,218,1,0,0,0,218,25,1,0,0,0,219,220,5,9,0,0,220,221,
        3,28,14,0,221,222,3,28,14,0,222,223,3,28,14,0,223,224,3,28,14,0,
        224,226,5,9,0,0,225,227,5,15,0,0,226,225,1,0,0,0,226,227,1,0,0,0,
        227,228,1,0,0,0,228,229,3,30,15,0,229,231,3,30,15,0,230,232,5,15,
        0,0,231,230,1,0,0,0,231,232,1,0,0,0,232,233,1,0,0,0,233,250,3,32,
        16,0,234,251,7,0,0,0,235,236,3,34,17,0,236,237,3,34,17,0,237,238,
        3,34,17,0,238,240,3,34,17,0,239,241,5,9,0,0,240,239,1,0,0,0,240,
        241,1,0,0,0,241,243,1,0,0,0,242,244,5,9,0,0,243,242,1,0,0,0,243,
        244,1,0,0,0,244,248,1,0,0,0,245,249,5,17,0,0,246,249,3,36,18,0,247,
        249,5,0,0,1,248,245,1,0,0,0,248,246,1,0,0,0,248,247,1,0,0,0,249,
        251,1,0,0,0,250,234,1,0,0,0,250,235,1,0,0,0,251,269,1,0,0,0,252,
        253,3,34,17,0,253,254,3,34,17,0,254,255,3,34,17,0,255,257,3,34,17,
        0,256,258,5,9,0,0,257,256,1,0,0,0,257,258,1,0,0,0,258,260,1,0,0,
        0,259,261,5,9,0,0,260,259,1,0,0,0,260,261,1,0,0,0,261,265,1,0,0,
        0,262,266,5,17,0,0,263,266,3,36,18,0,264,266,5,0,0,1,265,262,1,0,
        0,0,265,263,1,0,0,0,265,264,1,0,0,0,266,268,1,0,0,0,267,252,1,0,
        0,0,268,271,1,0,0,0,269,267,1,0,0,0,269,270,1,0,0,0,270,27,1,0,0,
        0,271,269,1,0,0,0,272,273,7,1,0,0,273,29,1,0,0,0,274,275,7,2,0,0,
        275,31,1,0,0,0,276,277,7,3,0,0,277,33,1,0,0,0,278,284,5,9,0,0,279,
        281,5,15,0,0,280,282,5,9,0,0,281,280,1,0,0,0,281,282,1,0,0,0,282,
        284,1,0,0,0,283,278,1,0,0,0,283,279,1,0,0,0,284,35,1,0,0,0,285,289,
        5,12,0,0,286,288,5,42,0,0,287,286,1,0,0,0,288,291,1,0,0,0,289,287,
        1,0,0,0,289,290,1,0,0,0,290,292,1,0,0,0,291,289,1,0,0,0,292,293,
        7,4,0,0,293,37,1,0,0,0,46,39,52,54,59,75,92,100,106,108,115,120,
        127,130,135,137,142,145,150,154,159,161,169,174,182,185,190,192,
        198,201,206,210,215,217,226,231,240,243,248,250,257,260,265,269,
        281,283,289
    ]

class XeasyPKParser ( Parser ):

    grammarFileName = "XeasyPKParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "'#FORMAT'", 
                     "<INVALID>", "'#INAME'", "'#CYANAFORMAT'", "'#SPECTRUM'", 
                     "'#TOLERANCE'" ]

    symbolicNames = [ "<INVALID>", "Num_of_dim", "Num_of_peaks", "Format", 
                      "XEASY_WO_FORMAT", "Iname", "Cyana_format", "Spectrum", 
                      "Tolerance", "Integer", "Float", "Real", "COMMENT", 
                      "EXCLM_COMMENT", "SMCLN_COMMENT", "Simple_name", "SPACE", 
                      "RETURN", "SECTION_COMMENT", "LINE_COMMENT", "Integer_ND", 
                      "SPACE_ND", "RETURN_ND", "Integer_NP", "SPACE_NP", 
                      "RETURN_NP", "Simple_name_FO", "SPACE_FO", "RETURN_FO", 
                      "Integer_IN", "Simple_name_IN", "SPACE_IN", "RETURN_IN", 
                      "Simple_name_CY", "SPACE_CY", "RETURN_CY", "Simple_name_SP", 
                      "SPACE_SP", "RETURN_SP", "Float_TO", "TOACE_TO", "RETURN_TO", 
                      "Any_name", "SPACE_CM", "RETURN_CM" ]

    RULE_xeasy_pk = 0
    RULE_dimension = 1
    RULE_peak = 2
    RULE_format = 3
    RULE_iname = 4
    RULE_cyana_format = 5
    RULE_spectrum = 6
    RULE_tolerance = 7
    RULE_peak_list_2d = 8
    RULE_peak_2d = 9
    RULE_peak_list_3d = 10
    RULE_peak_3d = 11
    RULE_peak_list_4d = 12
    RULE_peak_4d = 13
    RULE_position = 14
    RULE_number = 15
    RULE_type_code = 16
    RULE_assign = 17
    RULE_comment = 18

    ruleNames =  [ "xeasy_pk", "dimension", "peak", "format", "iname", "cyana_format", 
                   "spectrum", "tolerance", "peak_list_2d", "peak_2d", "peak_list_3d", 
                   "peak_3d", "peak_list_4d", "peak_4d", "position", "number", 
                   "type_code", "assign", "comment" ]

    EOF = Token.EOF
    Num_of_dim=1
    Num_of_peaks=2
    Format=3
    XEASY_WO_FORMAT=4
    Iname=5
    Cyana_format=6
    Spectrum=7
    Tolerance=8
    Integer=9
    Float=10
    Real=11
    COMMENT=12
    EXCLM_COMMENT=13
    SMCLN_COMMENT=14
    Simple_name=15
    SPACE=16
    RETURN=17
    SECTION_COMMENT=18
    LINE_COMMENT=19
    Integer_ND=20
    SPACE_ND=21
    RETURN_ND=22
    Integer_NP=23
    SPACE_NP=24
    RETURN_NP=25
    Simple_name_FO=26
    SPACE_FO=27
    RETURN_FO=28
    Integer_IN=29
    Simple_name_IN=30
    SPACE_IN=31
    RETURN_IN=32
    Simple_name_CY=33
    SPACE_CY=34
    RETURN_CY=35
    Simple_name_SP=36
    SPACE_SP=37
    RETURN_SP=38
    Float_TO=39
    TOACE_TO=40
    RETURN_TO=41
    Any_name=42
    SPACE_CM=43
    RETURN_CM=44

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Xeasy_pkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(XeasyPKParser.EOF, 0)

        def RETURN(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.RETURN)
            else:
                return self.getToken(XeasyPKParser.RETURN, i)

        def dimension(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.DimensionContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.DimensionContext,i)


        def peak(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.PeakContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.PeakContext,i)


        def format_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.FormatContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.FormatContext,i)


        def iname(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.InameContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.InameContext,i)


        def cyana_format(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.Cyana_formatContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.Cyana_formatContext,i)


        def spectrum(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.SpectrumContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.SpectrumContext,i)


        def tolerance(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.ToleranceContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.ToleranceContext,i)


        def peak_list_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.Peak_list_2dContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.Peak_list_2dContext,i)


        def peak_list_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.Peak_list_3dContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.Peak_list_3dContext,i)


        def peak_list_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.Peak_list_4dContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.Peak_list_4dContext,i)


        def comment(self):
            return self.getTypedRuleContext(XeasyPKParser.CommentContext,0)


        def getRuleIndex(self):
            return XeasyPKParser.RULE_xeasy_pk

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterXeasy_pk" ):
                listener.enterXeasy_pk(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitXeasy_pk" ):
                listener.exitXeasy_pk(self)




    def xeasy_pk(self):

        localctx = XeasyPKParser.Xeasy_pkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_xeasy_pk)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 39
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.state = 38
                self.match(XeasyPKParser.RETURN)


            self.state = 54
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 52
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                    if la_ == 1:
                        self.state = 41
                        self.dimension()
                        pass

                    elif la_ == 2:
                        self.state = 42
                        self.peak()
                        pass

                    elif la_ == 3:
                        self.state = 43
                        self.format_()
                        pass

                    elif la_ == 4:
                        self.state = 44
                        self.iname()
                        pass

                    elif la_ == 5:
                        self.state = 45
                        self.cyana_format()
                        pass

                    elif la_ == 6:
                        self.state = 46
                        self.spectrum()
                        pass

                    elif la_ == 7:
                        self.state = 47
                        self.tolerance()
                        pass

                    elif la_ == 8:
                        self.state = 48
                        self.peak_list_2d()
                        pass

                    elif la_ == 9:
                        self.state = 49
                        self.peak_list_3d()
                        pass

                    elif la_ == 10:
                        self.state = 50
                        self.peak_list_4d()
                        pass

                    elif la_ == 11:
                        self.state = 51
                        self.match(XeasyPKParser.RETURN)
                        pass

             
                self.state = 56
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

            self.state = 59
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [17]:
                self.state = 57
                self.match(XeasyPKParser.RETURN)
                pass
            elif token in [12]:
                self.state = 58
                self.comment()
                pass
            elif token in [-1]:
                pass
            else:
                pass
            self.state = 61
            self.match(XeasyPKParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DimensionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Num_of_dim(self):
            return self.getToken(XeasyPKParser.Num_of_dim, 0)

        def Integer_ND(self):
            return self.getToken(XeasyPKParser.Integer_ND, 0)

        def RETURN_ND(self):
            return self.getToken(XeasyPKParser.RETURN_ND, 0)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_dimension

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDimension" ):
                listener.enterDimension(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDimension" ):
                listener.exitDimension(self)




    def dimension(self):

        localctx = XeasyPKParser.DimensionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_dimension)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 63
            self.match(XeasyPKParser.Num_of_dim)
            self.state = 64
            self.match(XeasyPKParser.Integer_ND)
            self.state = 65
            self.match(XeasyPKParser.RETURN_ND)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PeakContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Num_of_peaks(self):
            return self.getToken(XeasyPKParser.Num_of_peaks, 0)

        def Integer_NP(self):
            return self.getToken(XeasyPKParser.Integer_NP, 0)

        def RETURN_NP(self):
            return self.getToken(XeasyPKParser.RETURN_NP, 0)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_peak

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak" ):
                listener.enterPeak(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak" ):
                listener.exitPeak(self)




    def peak(self):

        localctx = XeasyPKParser.PeakContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_peak)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 67
            self.match(XeasyPKParser.Num_of_peaks)
            self.state = 68
            self.match(XeasyPKParser.Integer_NP)
            self.state = 69
            self.match(XeasyPKParser.RETURN_NP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FormatContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Format(self):
            return self.getToken(XeasyPKParser.Format, 0)

        def RETURN_FO(self):
            return self.getToken(XeasyPKParser.RETURN_FO, 0)

        def Simple_name_FO(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.Simple_name_FO)
            else:
                return self.getToken(XeasyPKParser.Simple_name_FO, i)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_format

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFormat" ):
                listener.enterFormat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFormat" ):
                listener.exitFormat(self)




    def format_(self):

        localctx = XeasyPKParser.FormatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_format)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 71
            self.match(XeasyPKParser.Format)
            self.state = 73 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 72
                self.match(XeasyPKParser.Simple_name_FO)
                self.state = 75 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==26):
                    break

            self.state = 77
            self.match(XeasyPKParser.RETURN_FO)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Iname(self):
            return self.getToken(XeasyPKParser.Iname, 0)

        def Integer_IN(self):
            return self.getToken(XeasyPKParser.Integer_IN, 0)

        def Simple_name_IN(self):
            return self.getToken(XeasyPKParser.Simple_name_IN, 0)

        def RETURN_IN(self):
            return self.getToken(XeasyPKParser.RETURN_IN, 0)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_iname

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIname" ):
                listener.enterIname(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIname" ):
                listener.exitIname(self)




    def iname(self):

        localctx = XeasyPKParser.InameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_iname)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 79
            self.match(XeasyPKParser.Iname)
            self.state = 80
            self.match(XeasyPKParser.Integer_IN)
            self.state = 81
            self.match(XeasyPKParser.Simple_name_IN)
            self.state = 82
            self.match(XeasyPKParser.RETURN_IN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cyana_formatContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Cyana_format(self):
            return self.getToken(XeasyPKParser.Cyana_format, 0)

        def Simple_name_CY(self):
            return self.getToken(XeasyPKParser.Simple_name_CY, 0)

        def RETURN_CY(self):
            return self.getToken(XeasyPKParser.RETURN_CY, 0)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_cyana_format

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCyana_format" ):
                listener.enterCyana_format(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCyana_format" ):
                listener.exitCyana_format(self)




    def cyana_format(self):

        localctx = XeasyPKParser.Cyana_formatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_cyana_format)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 84
            self.match(XeasyPKParser.Cyana_format)
            self.state = 85
            self.match(XeasyPKParser.Simple_name_CY)
            self.state = 86
            self.match(XeasyPKParser.RETURN_CY)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SpectrumContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Spectrum(self):
            return self.getToken(XeasyPKParser.Spectrum, 0)

        def RETURN_SP(self):
            return self.getToken(XeasyPKParser.RETURN_SP, 0)

        def Simple_name_SP(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.Simple_name_SP)
            else:
                return self.getToken(XeasyPKParser.Simple_name_SP, i)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_spectrum

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSpectrum" ):
                listener.enterSpectrum(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSpectrum" ):
                listener.exitSpectrum(self)




    def spectrum(self):

        localctx = XeasyPKParser.SpectrumContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_spectrum)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 88
            self.match(XeasyPKParser.Spectrum)
            self.state = 90 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 89
                self.match(XeasyPKParser.Simple_name_SP)
                self.state = 92 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==36):
                    break

            self.state = 94
            self.match(XeasyPKParser.RETURN_SP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ToleranceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Tolerance(self):
            return self.getToken(XeasyPKParser.Tolerance, 0)

        def RETURN_TO(self):
            return self.getToken(XeasyPKParser.RETURN_TO, 0)

        def Float_TO(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.Float_TO)
            else:
                return self.getToken(XeasyPKParser.Float_TO, i)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_tolerance

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTolerance" ):
                listener.enterTolerance(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTolerance" ):
                listener.exitTolerance(self)




    def tolerance(self):

        localctx = XeasyPKParser.ToleranceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_tolerance)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 96
            self.match(XeasyPKParser.Tolerance)
            self.state = 98 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 97
                self.match(XeasyPKParser.Float_TO)
                self.state = 100 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==39):
                    break

            self.state = 102
            self.match(XeasyPKParser.RETURN_TO)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def peak_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.Peak_2dContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.Peak_2dContext,i)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.CommentContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.CommentContext,i)


        def getRuleIndex(self):
            return XeasyPKParser.RULE_peak_list_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_2d" ):
                listener.enterPeak_list_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_2d" ):
                listener.exitPeak_list_2d(self)




    def peak_list_2d(self):

        localctx = XeasyPKParser.Peak_list_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_peak_list_2d)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 106 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 106
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [9]:
                        self.state = 104
                        self.peak_2d()
                        pass
                    elif token in [12]:
                        self.state = 105
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 108 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.Integer)
            else:
                return self.getToken(XeasyPKParser.Integer, i)

        def position(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.PositionContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.PositionContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.NumberContext,i)


        def type_code(self):
            return self.getTypedRuleContext(XeasyPKParser.Type_codeContext,0)


        def assign(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.AssignContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.AssignContext,i)


        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.Simple_name)
            else:
                return self.getToken(XeasyPKParser.Simple_name, i)

        def RETURN(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.RETURN)
            else:
                return self.getToken(XeasyPKParser.RETURN, i)

        def EOF(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.EOF)
            else:
                return self.getToken(XeasyPKParser.EOF, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.CommentContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.CommentContext,i)


        def getRuleIndex(self):
            return XeasyPKParser.RULE_peak_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_2d" ):
                listener.enterPeak_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_2d" ):
                listener.exitPeak_2d(self)




    def peak_2d(self):

        localctx = XeasyPKParser.Peak_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_peak_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 110
            self.match(XeasyPKParser.Integer)
            self.state = 111
            self.position()
            self.state = 112
            self.position()
            self.state = 113
            self.match(XeasyPKParser.Integer)
            self.state = 115
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
            if la_ == 1:
                self.state = 114
                self.match(XeasyPKParser.Simple_name)


            self.state = 117
            self.number()
            self.state = 118
            self.number()
            self.state = 120
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.state = 119
                self.match(XeasyPKParser.Simple_name)


            self.state = 122
            self.type_code()
            self.state = 137
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [-1, 17]:
                self.state = 123
                _la = self._input.LA(1)
                if not(_la==-1 or _la==17):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass
            elif token in [9, 15]:
                self.state = 124
                self.assign()
                self.state = 125
                self.assign()
                self.state = 127
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
                if la_ == 1:
                    self.state = 126
                    self.match(XeasyPKParser.Integer)


                self.state = 130
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==9:
                    self.state = 129
                    self.match(XeasyPKParser.Integer)


                self.state = 135
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [17]:
                    self.state = 132
                    self.match(XeasyPKParser.RETURN)
                    pass
                elif token in [12]:
                    self.state = 133
                    self.comment()
                    pass
                elif token in [-1]:
                    self.state = 134
                    self.match(XeasyPKParser.EOF)
                    pass
                else:
                    raise NoViableAltException(self)

                pass
            else:
                raise NoViableAltException(self)

            self.state = 154
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,18,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 139
                    self.assign()
                    self.state = 140
                    self.assign()
                    self.state = 142
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
                    if la_ == 1:
                        self.state = 141
                        self.match(XeasyPKParser.Integer)


                    self.state = 145
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==9:
                        self.state = 144
                        self.match(XeasyPKParser.Integer)


                    self.state = 150
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [17]:
                        self.state = 147
                        self.match(XeasyPKParser.RETURN)
                        pass
                    elif token in [12]:
                        self.state = 148
                        self.comment()
                        pass
                    elif token in [-1]:
                        self.state = 149
                        self.match(XeasyPKParser.EOF)
                        pass
                    else:
                        raise NoViableAltException(self)
             
                self.state = 156
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,18,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def peak_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.Peak_3dContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.Peak_3dContext,i)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.CommentContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.CommentContext,i)


        def getRuleIndex(self):
            return XeasyPKParser.RULE_peak_list_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_3d" ):
                listener.enterPeak_list_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_3d" ):
                listener.exitPeak_list_3d(self)




    def peak_list_3d(self):

        localctx = XeasyPKParser.Peak_list_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_peak_list_3d)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 159 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 159
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [9]:
                        self.state = 157
                        self.peak_3d()
                        pass
                    elif token in [12]:
                        self.state = 158
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 161 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,20,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.Integer)
            else:
                return self.getToken(XeasyPKParser.Integer, i)

        def position(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.PositionContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.PositionContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.NumberContext,i)


        def type_code(self):
            return self.getTypedRuleContext(XeasyPKParser.Type_codeContext,0)


        def assign(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.AssignContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.AssignContext,i)


        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.Simple_name)
            else:
                return self.getToken(XeasyPKParser.Simple_name, i)

        def RETURN(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.RETURN)
            else:
                return self.getToken(XeasyPKParser.RETURN, i)

        def EOF(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.EOF)
            else:
                return self.getToken(XeasyPKParser.EOF, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.CommentContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.CommentContext,i)


        def getRuleIndex(self):
            return XeasyPKParser.RULE_peak_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_3d" ):
                listener.enterPeak_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_3d" ):
                listener.exitPeak_3d(self)




    def peak_3d(self):

        localctx = XeasyPKParser.Peak_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_peak_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 163
            self.match(XeasyPKParser.Integer)
            self.state = 164
            self.position()
            self.state = 165
            self.position()
            self.state = 166
            self.position()
            self.state = 167
            self.match(XeasyPKParser.Integer)
            self.state = 169
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
            if la_ == 1:
                self.state = 168
                self.match(XeasyPKParser.Simple_name)


            self.state = 171
            self.number()
            self.state = 172
            self.number()
            self.state = 174
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
            if la_ == 1:
                self.state = 173
                self.match(XeasyPKParser.Simple_name)


            self.state = 176
            self.type_code()
            self.state = 192
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [-1, 17]:
                self.state = 177
                _la = self._input.LA(1)
                if not(_la==-1 or _la==17):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass
            elif token in [9, 15]:
                self.state = 178
                self.assign()
                self.state = 179
                self.assign()
                self.state = 180
                self.assign()
                self.state = 182
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,23,self._ctx)
                if la_ == 1:
                    self.state = 181
                    self.match(XeasyPKParser.Integer)


                self.state = 185
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==9:
                    self.state = 184
                    self.match(XeasyPKParser.Integer)


                self.state = 190
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [17]:
                    self.state = 187
                    self.match(XeasyPKParser.RETURN)
                    pass
                elif token in [12]:
                    self.state = 188
                    self.comment()
                    pass
                elif token in [-1]:
                    self.state = 189
                    self.match(XeasyPKParser.EOF)
                    pass
                else:
                    raise NoViableAltException(self)

                pass
            else:
                raise NoViableAltException(self)

            self.state = 210
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,30,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 194
                    self.assign()
                    self.state = 195
                    self.assign()
                    self.state = 196
                    self.assign()
                    self.state = 198
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
                    if la_ == 1:
                        self.state = 197
                        self.match(XeasyPKParser.Integer)


                    self.state = 201
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==9:
                        self.state = 200
                        self.match(XeasyPKParser.Integer)


                    self.state = 206
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [17]:
                        self.state = 203
                        self.match(XeasyPKParser.RETURN)
                        pass
                    elif token in [12]:
                        self.state = 204
                        self.comment()
                        pass
                    elif token in [-1]:
                        self.state = 205
                        self.match(XeasyPKParser.EOF)
                        pass
                    else:
                        raise NoViableAltException(self)
             
                self.state = 212
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,30,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def peak_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.Peak_4dContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.Peak_4dContext,i)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.CommentContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.CommentContext,i)


        def getRuleIndex(self):
            return XeasyPKParser.RULE_peak_list_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_4d" ):
                listener.enterPeak_list_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_4d" ):
                listener.exitPeak_list_4d(self)




    def peak_list_4d(self):

        localctx = XeasyPKParser.Peak_list_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_peak_list_4d)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 215 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 215
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [9]:
                        self.state = 213
                        self.peak_4d()
                        pass
                    elif token in [12]:
                        self.state = 214
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 217 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,32,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.Integer)
            else:
                return self.getToken(XeasyPKParser.Integer, i)

        def position(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.PositionContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.PositionContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.NumberContext,i)


        def type_code(self):
            return self.getTypedRuleContext(XeasyPKParser.Type_codeContext,0)


        def assign(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.AssignContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.AssignContext,i)


        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.Simple_name)
            else:
                return self.getToken(XeasyPKParser.Simple_name, i)

        def RETURN(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.RETURN)
            else:
                return self.getToken(XeasyPKParser.RETURN, i)

        def EOF(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.EOF)
            else:
                return self.getToken(XeasyPKParser.EOF, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(XeasyPKParser.CommentContext)
            else:
                return self.getTypedRuleContext(XeasyPKParser.CommentContext,i)


        def getRuleIndex(self):
            return XeasyPKParser.RULE_peak_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_4d" ):
                listener.enterPeak_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_4d" ):
                listener.exitPeak_4d(self)




    def peak_4d(self):

        localctx = XeasyPKParser.Peak_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_peak_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 219
            self.match(XeasyPKParser.Integer)
            self.state = 220
            self.position()
            self.state = 221
            self.position()
            self.state = 222
            self.position()
            self.state = 223
            self.position()
            self.state = 224
            self.match(XeasyPKParser.Integer)
            self.state = 226
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                self.state = 225
                self.match(XeasyPKParser.Simple_name)


            self.state = 228
            self.number()
            self.state = 229
            self.number()
            self.state = 231
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,34,self._ctx)
            if la_ == 1:
                self.state = 230
                self.match(XeasyPKParser.Simple_name)


            self.state = 233
            self.type_code()
            self.state = 250
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [-1, 17]:
                self.state = 234
                _la = self._input.LA(1)
                if not(_la==-1 or _la==17):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass
            elif token in [9, 15]:
                self.state = 235
                self.assign()
                self.state = 236
                self.assign()
                self.state = 237
                self.assign()
                self.state = 238
                self.assign()
                self.state = 240
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,35,self._ctx)
                if la_ == 1:
                    self.state = 239
                    self.match(XeasyPKParser.Integer)


                self.state = 243
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==9:
                    self.state = 242
                    self.match(XeasyPKParser.Integer)


                self.state = 248
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [17]:
                    self.state = 245
                    self.match(XeasyPKParser.RETURN)
                    pass
                elif token in [12]:
                    self.state = 246
                    self.comment()
                    pass
                elif token in [-1]:
                    self.state = 247
                    self.match(XeasyPKParser.EOF)
                    pass
                else:
                    raise NoViableAltException(self)

                pass
            else:
                raise NoViableAltException(self)

            self.state = 269
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,42,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 252
                    self.assign()
                    self.state = 253
                    self.assign()
                    self.state = 254
                    self.assign()
                    self.state = 255
                    self.assign()
                    self.state = 257
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,39,self._ctx)
                    if la_ == 1:
                        self.state = 256
                        self.match(XeasyPKParser.Integer)


                    self.state = 260
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==9:
                        self.state = 259
                        self.match(XeasyPKParser.Integer)


                    self.state = 265
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [17]:
                        self.state = 262
                        self.match(XeasyPKParser.RETURN)
                        pass
                    elif token in [12]:
                        self.state = 263
                        self.comment()
                        pass
                    elif token in [-1]:
                        self.state = 264
                        self.match(XeasyPKParser.EOF)
                        pass
                    else:
                        raise NoViableAltException(self)
             
                self.state = 271
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,42,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PositionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(XeasyPKParser.Float, 0)

        def Integer(self):
            return self.getToken(XeasyPKParser.Integer, 0)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_position

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPosition" ):
                listener.enterPosition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPosition" ):
                listener.exitPosition(self)




    def position(self):

        localctx = XeasyPKParser.PositionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_position)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 272
            _la = self._input.LA(1)
            if not(_la==9 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(XeasyPKParser.Float, 0)

        def Real(self):
            return self.getToken(XeasyPKParser.Real, 0)

        def Integer(self):
            return self.getToken(XeasyPKParser.Integer, 0)

        def Simple_name(self):
            return self.getToken(XeasyPKParser.Simple_name, 0)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = XeasyPKParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 274
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 36352) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Type_codeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self):
            return self.getToken(XeasyPKParser.Integer, 0)

        def Simple_name(self):
            return self.getToken(XeasyPKParser.Simple_name, 0)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_type_code

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterType_code" ):
                listener.enterType_code(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitType_code" ):
                listener.exitType_code(self)




    def type_code(self):

        localctx = XeasyPKParser.Type_codeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_type_code)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 276
            _la = self._input.LA(1)
            if not(_la==9 or _la==15):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self):
            return self.getToken(XeasyPKParser.Integer, 0)

        def Simple_name(self):
            return self.getToken(XeasyPKParser.Simple_name, 0)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_assign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssign" ):
                listener.enterAssign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssign" ):
                listener.exitAssign(self)




    def assign(self):

        localctx = XeasyPKParser.AssignContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_assign)
        try:
            self.state = 283
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [9]:
                self.enterOuterAlt(localctx, 1)
                self.state = 278
                self.match(XeasyPKParser.Integer)
                pass
            elif token in [15]:
                self.enterOuterAlt(localctx, 2)
                self.state = 279
                self.match(XeasyPKParser.Simple_name)
                self.state = 281
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,43,self._ctx)
                if la_ == 1:
                    self.state = 280
                    self.match(XeasyPKParser.Integer)


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(XeasyPKParser.COMMENT, 0)

        def RETURN_CM(self):
            return self.getToken(XeasyPKParser.RETURN_CM, 0)

        def EOF(self):
            return self.getToken(XeasyPKParser.EOF, 0)

        def Any_name(self, i:int=None):
            if i is None:
                return self.getTokens(XeasyPKParser.Any_name)
            else:
                return self.getToken(XeasyPKParser.Any_name, i)

        def getRuleIndex(self):
            return XeasyPKParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)




    def comment(self):

        localctx = XeasyPKParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_comment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 285
            self.match(XeasyPKParser.COMMENT)
            self.state = 289
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==42:
                self.state = 286
                self.match(XeasyPKParser.Any_name)
                self.state = 291
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 292
            _la = self._input.LA(1)
            if not(_la==-1 or _la==44):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





