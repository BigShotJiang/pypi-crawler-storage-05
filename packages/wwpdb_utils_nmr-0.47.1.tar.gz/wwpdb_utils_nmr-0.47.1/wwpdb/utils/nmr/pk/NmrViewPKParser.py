# Generated from NmrViewPKParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,37,494,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,1,0,3,0,40,8,0,
        1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,5,0,50,8,0,10,0,12,0,53,9,0,1,0,
        1,0,1,1,1,1,1,1,1,1,1,1,3,1,62,8,1,1,1,5,1,65,8,1,10,1,12,1,68,9,
        1,1,1,1,1,4,1,72,8,1,11,1,12,1,73,1,1,5,1,77,8,1,10,1,12,1,80,9,
        1,1,1,4,1,83,8,1,11,1,12,1,84,1,1,1,1,4,1,89,8,1,11,1,12,1,90,1,
        1,1,1,4,1,95,8,1,11,1,12,1,96,1,2,4,2,100,8,2,11,2,12,2,101,1,3,
        1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,
        1,3,3,3,122,8,3,1,3,1,3,3,3,126,8,3,1,3,4,3,129,8,3,11,3,12,3,130,
        1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,
        1,4,1,4,1,4,3,4,152,8,4,1,4,4,4,155,8,4,11,4,12,4,156,1,4,1,4,1,
        5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,
        5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,3,5,186,8,5,1,5,1,5,3,5,190,8,
        5,1,5,4,5,193,8,5,11,5,12,5,194,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,
        1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,
        1,6,1,6,3,6,223,8,6,1,6,4,6,226,8,6,11,6,12,6,227,1,6,1,6,1,7,1,
        7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,
        7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,264,
        8,7,1,7,1,7,3,7,268,8,7,1,7,4,7,271,8,7,11,7,12,7,272,1,8,1,8,1,
        8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,
        8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,3,8,308,
        8,8,1,8,4,8,311,8,8,11,8,12,8,312,1,8,1,8,1,9,1,9,1,9,1,9,1,9,1,
        9,1,9,1,9,1,9,1,9,1,9,1,9,3,9,329,8,9,1,9,1,9,3,9,333,8,9,1,9,4,
        9,336,8,9,11,9,12,9,337,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,
        1,10,1,10,1,10,1,10,1,10,3,10,353,8,10,1,10,4,10,356,8,10,11,10,
        12,10,357,1,10,1,10,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,
        1,11,1,11,1,11,1,11,1,11,1,11,1,11,3,11,378,8,11,1,11,1,11,3,11,
        382,8,11,1,11,4,11,385,8,11,11,11,12,11,386,1,12,1,12,1,12,1,12,
        1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,
        3,12,406,8,12,1,12,4,12,409,8,12,11,12,12,12,410,1,12,1,12,1,13,
        1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,
        1,13,1,13,1,13,1,13,1,13,1,13,3,13,435,8,13,1,13,1,13,3,13,439,8,
        13,1,13,4,13,442,8,13,11,13,12,13,443,1,14,1,14,1,14,1,14,1,14,1,
        14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,
        14,1,14,1,14,3,14,467,8,14,1,14,4,14,470,8,14,11,14,12,14,471,1,
        14,1,14,1,15,1,15,1,16,1,16,1,16,3,16,481,8,16,1,17,1,17,1,18,1,
        18,5,18,487,8,18,10,18,12,18,490,9,18,1,18,1,18,1,18,0,0,19,0,2,
        4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,0,3,1,1,10,10,2,
        0,30,31,34,34,2,0,2,3,8,8,524,0,39,1,0,0,0,2,56,1,0,0,0,4,99,1,0,
        0,0,6,103,1,0,0,0,8,132,1,0,0,0,10,160,1,0,0,0,12,196,1,0,0,0,14,
        231,1,0,0,0,16,274,1,0,0,0,18,316,1,0,0,0,20,339,1,0,0,0,22,361,
        1,0,0,0,24,388,1,0,0,0,26,414,1,0,0,0,28,445,1,0,0,0,30,475,1,0,
        0,0,32,480,1,0,0,0,34,482,1,0,0,0,36,484,1,0,0,0,38,40,5,10,0,0,
        39,38,1,0,0,0,39,40,1,0,0,0,40,51,1,0,0,0,41,50,3,2,1,0,42,50,3,
        6,3,0,43,50,3,10,5,0,44,50,3,14,7,0,45,50,3,18,9,0,46,50,3,22,11,
        0,47,50,3,26,13,0,48,50,5,10,0,0,49,41,1,0,0,0,49,42,1,0,0,0,49,
        43,1,0,0,0,49,44,1,0,0,0,49,45,1,0,0,0,49,46,1,0,0,0,49,47,1,0,0,
        0,49,48,1,0,0,0,50,53,1,0,0,0,51,49,1,0,0,0,51,52,1,0,0,0,52,54,
        1,0,0,0,53,51,1,0,0,0,54,55,5,0,0,1,55,1,1,0,0,0,56,57,5,1,0,0,57,
        58,5,14,0,0,58,59,5,15,0,0,59,61,5,16,0,0,60,62,5,17,0,0,61,60,1,
        0,0,0,61,62,1,0,0,0,62,66,1,0,0,0,63,65,5,33,0,0,64,63,1,0,0,0,65,
        68,1,0,0,0,66,64,1,0,0,0,66,67,1,0,0,0,67,69,1,0,0,0,68,66,1,0,0,
        0,69,71,3,4,2,0,70,72,5,33,0,0,71,70,1,0,0,0,72,73,1,0,0,0,73,71,
        1,0,0,0,73,74,1,0,0,0,74,78,1,0,0,0,75,77,5,30,0,0,76,75,1,0,0,0,
        77,80,1,0,0,0,78,76,1,0,0,0,78,79,1,0,0,0,79,82,1,0,0,0,80,78,1,
        0,0,0,81,83,5,33,0,0,82,81,1,0,0,0,83,84,1,0,0,0,84,82,1,0,0,0,84,
        85,1,0,0,0,85,86,1,0,0,0,86,88,3,4,2,0,87,89,5,33,0,0,88,87,1,0,
        0,0,89,90,1,0,0,0,90,88,1,0,0,0,90,91,1,0,0,0,91,92,1,0,0,0,92,94,
        3,4,2,0,93,95,5,33,0,0,94,93,1,0,0,0,95,96,1,0,0,0,96,94,1,0,0,0,
        96,97,1,0,0,0,97,3,1,0,0,0,98,100,3,30,15,0,99,98,1,0,0,0,100,101,
        1,0,0,0,101,99,1,0,0,0,101,102,1,0,0,0,102,5,1,0,0,0,103,104,5,18,
        0,0,104,105,5,19,0,0,105,106,5,20,0,0,106,107,5,21,0,0,107,108,5,
        22,0,0,108,109,5,23,0,0,109,110,5,24,0,0,110,111,5,18,0,0,111,112,
        5,19,0,0,112,113,5,20,0,0,113,114,5,21,0,0,114,115,5,22,0,0,115,
        116,5,23,0,0,116,117,5,24,0,0,117,118,5,25,0,0,118,119,5,26,0,0,
        119,121,5,27,0,0,120,122,5,28,0,0,121,120,1,0,0,0,121,122,1,0,0,
        0,122,123,1,0,0,0,123,125,5,29,0,0,124,126,5,10,0,0,125,124,1,0,
        0,0,125,126,1,0,0,0,126,128,1,0,0,0,127,129,3,8,4,0,128,127,1,0,
        0,0,129,130,1,0,0,0,130,128,1,0,0,0,130,131,1,0,0,0,131,7,1,0,0,
        0,132,133,5,2,0,0,133,134,3,36,18,0,134,135,3,34,17,0,135,136,3,
        34,17,0,136,137,3,34,17,0,137,138,5,8,0,0,138,139,3,32,16,0,139,
        140,3,36,18,0,140,141,3,36,18,0,141,142,3,34,17,0,142,143,3,34,17,
        0,143,144,3,34,17,0,144,145,5,8,0,0,145,146,3,32,16,0,146,147,3,
        36,18,0,147,148,3,34,17,0,148,149,3,34,17,0,149,151,5,2,0,0,150,
        152,3,36,18,0,151,150,1,0,0,0,151,152,1,0,0,0,152,154,1,0,0,0,153,
        155,5,2,0,0,154,153,1,0,0,0,155,156,1,0,0,0,156,154,1,0,0,0,156,
        157,1,0,0,0,157,158,1,0,0,0,158,159,7,0,0,0,159,9,1,0,0,0,160,161,
        5,18,0,0,161,162,5,19,0,0,162,163,5,20,0,0,163,164,5,21,0,0,164,
        165,5,22,0,0,165,166,5,23,0,0,166,167,5,24,0,0,167,168,5,18,0,0,
        168,169,5,19,0,0,169,170,5,20,0,0,170,171,5,21,0,0,171,172,5,22,
        0,0,172,173,5,23,0,0,173,174,5,24,0,0,174,175,5,18,0,0,175,176,5,
        19,0,0,176,177,5,20,0,0,177,178,5,21,0,0,178,179,5,22,0,0,179,180,
        5,23,0,0,180,181,5,24,0,0,181,182,5,25,0,0,182,183,5,26,0,0,183,
        185,5,27,0,0,184,186,5,28,0,0,185,184,1,0,0,0,185,186,1,0,0,0,186,
        187,1,0,0,0,187,189,5,29,0,0,188,190,5,10,0,0,189,188,1,0,0,0,189,
        190,1,0,0,0,190,192,1,0,0,0,191,193,3,12,6,0,192,191,1,0,0,0,193,
        194,1,0,0,0,194,192,1,0,0,0,194,195,1,0,0,0,195,11,1,0,0,0,196,197,
        5,2,0,0,197,198,3,36,18,0,198,199,3,34,17,0,199,200,3,34,17,0,200,
        201,3,34,17,0,201,202,5,8,0,0,202,203,3,32,16,0,203,204,3,36,18,
        0,204,205,3,36,18,0,205,206,3,34,17,0,206,207,3,34,17,0,207,208,
        3,34,17,0,208,209,5,8,0,0,209,210,3,32,16,0,210,211,3,36,18,0,211,
        212,3,36,18,0,212,213,3,34,17,0,213,214,3,34,17,0,214,215,3,34,17,
        0,215,216,5,8,0,0,216,217,3,32,16,0,217,218,3,36,18,0,218,219,3,
        34,17,0,219,220,3,34,17,0,220,222,5,2,0,0,221,223,3,36,18,0,222,
        221,1,0,0,0,222,223,1,0,0,0,223,225,1,0,0,0,224,226,5,2,0,0,225,
        224,1,0,0,0,226,227,1,0,0,0,227,225,1,0,0,0,227,228,1,0,0,0,228,
        229,1,0,0,0,229,230,7,0,0,0,230,13,1,0,0,0,231,232,5,18,0,0,232,
        233,5,19,0,0,233,234,5,20,0,0,234,235,5,21,0,0,235,236,5,22,0,0,
        236,237,5,23,0,0,237,238,5,24,0,0,238,239,5,18,0,0,239,240,5,19,
        0,0,240,241,5,20,0,0,241,242,5,21,0,0,242,243,5,22,0,0,243,244,5,
        23,0,0,244,245,5,24,0,0,245,246,5,18,0,0,246,247,5,19,0,0,247,248,
        5,20,0,0,248,249,5,21,0,0,249,250,5,22,0,0,250,251,5,23,0,0,251,
        252,5,24,0,0,252,253,5,18,0,0,253,254,5,19,0,0,254,255,5,20,0,0,
        255,256,5,21,0,0,256,257,5,22,0,0,257,258,5,23,0,0,258,259,5,24,
        0,0,259,260,5,25,0,0,260,261,5,26,0,0,261,263,5,27,0,0,262,264,5,
        28,0,0,263,262,1,0,0,0,263,264,1,0,0,0,264,265,1,0,0,0,265,267,5,
        29,0,0,266,268,5,10,0,0,267,266,1,0,0,0,267,268,1,0,0,0,268,270,
        1,0,0,0,269,271,3,16,8,0,270,269,1,0,0,0,271,272,1,0,0,0,272,270,
        1,0,0,0,272,273,1,0,0,0,273,15,1,0,0,0,274,275,5,2,0,0,275,276,3,
        36,18,0,276,277,3,34,17,0,277,278,3,34,17,0,278,279,3,34,17,0,279,
        280,5,8,0,0,280,281,3,32,16,0,281,282,3,36,18,0,282,283,3,36,18,
        0,283,284,3,34,17,0,284,285,3,34,17,0,285,286,3,34,17,0,286,287,
        5,8,0,0,287,288,3,32,16,0,288,289,3,36,18,0,289,290,3,36,18,0,290,
        291,3,34,17,0,291,292,3,34,17,0,292,293,3,34,17,0,293,294,5,8,0,
        0,294,295,3,32,16,0,295,296,3,36,18,0,296,297,3,36,18,0,297,298,
        3,34,17,0,298,299,3,34,17,0,299,300,3,34,17,0,300,301,5,8,0,0,301,
        302,3,32,16,0,302,303,3,36,18,0,303,304,3,34,17,0,304,305,3,34,17,
        0,305,307,5,2,0,0,306,308,3,36,18,0,307,306,1,0,0,0,307,308,1,0,
        0,0,308,310,1,0,0,0,309,311,5,2,0,0,310,309,1,0,0,0,311,312,1,0,
        0,0,312,310,1,0,0,0,312,313,1,0,0,0,313,314,1,0,0,0,314,315,7,0,
        0,0,315,17,1,0,0,0,316,317,5,18,0,0,317,318,5,19,0,0,318,319,5,20,
        0,0,319,320,5,21,0,0,320,321,5,18,0,0,321,322,5,19,0,0,322,323,5,
        20,0,0,323,324,5,21,0,0,324,325,5,25,0,0,325,326,5,26,0,0,326,328,
        5,27,0,0,327,329,5,28,0,0,328,327,1,0,0,0,328,329,1,0,0,0,329,330,
        1,0,0,0,330,332,5,29,0,0,331,333,5,10,0,0,332,331,1,0,0,0,332,333,
        1,0,0,0,333,335,1,0,0,0,334,336,3,20,10,0,335,334,1,0,0,0,336,337,
        1,0,0,0,337,335,1,0,0,0,337,338,1,0,0,0,338,19,1,0,0,0,339,340,5,
        2,0,0,340,341,3,36,18,0,341,342,3,34,17,0,342,343,3,34,17,0,343,
        344,3,34,17,0,344,345,3,36,18,0,345,346,3,34,17,0,346,347,3,34,17,
        0,347,348,3,34,17,0,348,349,3,34,17,0,349,350,3,34,17,0,350,352,
        5,2,0,0,351,353,3,36,18,0,352,351,1,0,0,0,352,353,1,0,0,0,353,355,
        1,0,0,0,354,356,5,2,0,0,355,354,1,0,0,0,356,357,1,0,0,0,357,355,
        1,0,0,0,357,358,1,0,0,0,358,359,1,0,0,0,359,360,7,0,0,0,360,21,1,
        0,0,0,361,362,5,18,0,0,362,363,5,19,0,0,363,364,5,20,0,0,364,365,
        5,21,0,0,365,366,5,18,0,0,366,367,5,19,0,0,367,368,5,20,0,0,368,
        369,5,21,0,0,369,370,5,18,0,0,370,371,5,19,0,0,371,372,5,20,0,0,
        372,373,5,21,0,0,373,374,5,25,0,0,374,375,5,26,0,0,375,377,5,27,
        0,0,376,378,5,28,0,0,377,376,1,0,0,0,377,378,1,0,0,0,378,379,1,0,
        0,0,379,381,5,29,0,0,380,382,5,10,0,0,381,380,1,0,0,0,381,382,1,
        0,0,0,382,384,1,0,0,0,383,385,3,24,12,0,384,383,1,0,0,0,385,386,
        1,0,0,0,386,384,1,0,0,0,386,387,1,0,0,0,387,23,1,0,0,0,388,389,5,
        2,0,0,389,390,3,36,18,0,390,391,3,34,17,0,391,392,3,34,17,0,392,
        393,3,34,17,0,393,394,3,36,18,0,394,395,3,34,17,0,395,396,3,34,17,
        0,396,397,3,34,17,0,397,398,3,36,18,0,398,399,3,34,17,0,399,400,
        3,34,17,0,400,401,3,34,17,0,401,402,3,34,17,0,402,403,3,34,17,0,
        403,405,5,2,0,0,404,406,3,36,18,0,405,404,1,0,0,0,405,406,1,0,0,
        0,406,408,1,0,0,0,407,409,5,2,0,0,408,407,1,0,0,0,409,410,1,0,0,
        0,410,408,1,0,0,0,410,411,1,0,0,0,411,412,1,0,0,0,412,413,7,0,0,
        0,413,25,1,0,0,0,414,415,5,18,0,0,415,416,5,19,0,0,416,417,5,20,
        0,0,417,418,5,21,0,0,418,419,5,18,0,0,419,420,5,19,0,0,420,421,5,
        20,0,0,421,422,5,21,0,0,422,423,5,18,0,0,423,424,5,19,0,0,424,425,
        5,20,0,0,425,426,5,21,0,0,426,427,5,18,0,0,427,428,5,19,0,0,428,
        429,5,20,0,0,429,430,5,21,0,0,430,431,5,25,0,0,431,432,5,26,0,0,
        432,434,5,27,0,0,433,435,5,28,0,0,434,433,1,0,0,0,434,435,1,0,0,
        0,435,436,1,0,0,0,436,438,5,29,0,0,437,439,5,10,0,0,438,437,1,0,
        0,0,438,439,1,0,0,0,439,441,1,0,0,0,440,442,3,28,14,0,441,440,1,
        0,0,0,442,443,1,0,0,0,443,441,1,0,0,0,443,444,1,0,0,0,444,27,1,0,
        0,0,445,446,5,2,0,0,446,447,3,36,18,0,447,448,3,34,17,0,448,449,
        3,34,17,0,449,450,3,34,17,0,450,451,3,36,18,0,451,452,3,34,17,0,
        452,453,3,34,17,0,453,454,3,34,17,0,454,455,3,36,18,0,455,456,3,
        34,17,0,456,457,3,34,17,0,457,458,3,34,17,0,458,459,3,36,18,0,459,
        460,3,34,17,0,460,461,3,34,17,0,461,462,3,34,17,0,462,463,3,34,17,
        0,463,464,3,34,17,0,464,466,5,2,0,0,465,467,3,36,18,0,466,465,1,
        0,0,0,466,467,1,0,0,0,467,469,1,0,0,0,468,470,5,2,0,0,469,468,1,
        0,0,0,470,471,1,0,0,0,471,469,1,0,0,0,471,472,1,0,0,0,472,473,1,
        0,0,0,473,474,7,0,0,0,474,29,1,0,0,0,475,476,7,1,0,0,476,31,1,0,
        0,0,477,481,5,3,0,0,478,481,5,8,0,0,479,481,3,36,18,0,480,477,1,
        0,0,0,480,478,1,0,0,0,480,479,1,0,0,0,481,33,1,0,0,0,482,483,7,2,
        0,0,483,35,1,0,0,0,484,488,5,11,0,0,485,487,5,35,0,0,486,485,1,0,
        0,0,487,490,1,0,0,0,488,486,1,0,0,0,488,489,1,0,0,0,489,491,1,0,
        0,0,490,488,1,0,0,0,491,492,5,37,0,0,492,37,1,0,0,0,43,39,49,51,
        61,66,73,78,84,90,96,101,121,125,130,151,156,185,189,194,222,227,
        263,267,272,307,312,328,332,337,352,357,377,381,386,405,410,434,
        438,443,466,471,480,488
    ]

class NmrViewPKParser ( Parser ):

    grammarFileName = "NmrViewPKParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'label'", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'dataset'", "'sw'", "'sf'", "'condition'", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "'vol'", "'int'", 
                     "'stat'", "'comment'", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'\\n'" ]

    symbolicNames = [ "<INVALID>", "Label", "Integer", "Float", "Real", 
                      "SHARP_COMMENT", "EXCLM_COMMENT", "SMCLN_COMMENT", 
                      "Simple_name", "SPACE", "RETURN", "L_brace", "SECTION_COMMENT", 
                      "LINE_COMMENT", "Dataset", "Sw", "Sf", "Condition", 
                      "L_name", "P_name", "W_name", "B_name", "E_name", 
                      "J_name", "U_name", "Vol", "Int", "Stat", "Comment", 
                      "Flag0", "Simple_name_LA", "Float_LA", "SPACE_LA", 
                      "SINGLE_NL_LA", "ENCLOSE_DATA_LA", "Any_name", "SPACE_CM", 
                      "R_brace" ]

    RULE_nmrview_pk = 0
    RULE_data_label = 1
    RULE_labels = 2
    RULE_peak_list_2d = 3
    RULE_peak_2d = 4
    RULE_peak_list_3d = 5
    RULE_peak_3d = 6
    RULE_peak_list_4d = 7
    RULE_peak_4d = 8
    RULE_peak_list_wo_eju_2d = 9
    RULE_peak_wo_eju_2d = 10
    RULE_peak_list_wo_eju_3d = 11
    RULE_peak_wo_eju_3d = 12
    RULE_peak_list_wo_eju_4d = 13
    RULE_peak_wo_eju_4d = 14
    RULE_label = 15
    RULE_jcoupling = 16
    RULE_number = 17
    RULE_enclose_data = 18

    ruleNames =  [ "nmrview_pk", "data_label", "labels", "peak_list_2d", 
                   "peak_2d", "peak_list_3d", "peak_3d", "peak_list_4d", 
                   "peak_4d", "peak_list_wo_eju_2d", "peak_wo_eju_2d", "peak_list_wo_eju_3d", 
                   "peak_wo_eju_3d", "peak_list_wo_eju_4d", "peak_wo_eju_4d", 
                   "label", "jcoupling", "number", "enclose_data" ]

    EOF = Token.EOF
    Label=1
    Integer=2
    Float=3
    Real=4
    SHARP_COMMENT=5
    EXCLM_COMMENT=6
    SMCLN_COMMENT=7
    Simple_name=8
    SPACE=9
    RETURN=10
    L_brace=11
    SECTION_COMMENT=12
    LINE_COMMENT=13
    Dataset=14
    Sw=15
    Sf=16
    Condition=17
    L_name=18
    P_name=19
    W_name=20
    B_name=21
    E_name=22
    J_name=23
    U_name=24
    Vol=25
    Int=26
    Stat=27
    Comment=28
    Flag0=29
    Simple_name_LA=30
    Float_LA=31
    SPACE_LA=32
    SINGLE_NL_LA=33
    ENCLOSE_DATA_LA=34
    Any_name=35
    SPACE_CM=36
    R_brace=37

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Nmrview_pkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(NmrViewPKParser.EOF, 0)

        def RETURN(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.RETURN)
            else:
                return self.getToken(NmrViewPKParser.RETURN, i)

        def data_label(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Data_labelContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Data_labelContext,i)


        def peak_list_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_list_2dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_list_2dContext,i)


        def peak_list_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_list_3dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_list_3dContext,i)


        def peak_list_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_list_4dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_list_4dContext,i)


        def peak_list_wo_eju_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_list_wo_eju_2dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_list_wo_eju_2dContext,i)


        def peak_list_wo_eju_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_list_wo_eju_3dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_list_wo_eju_3dContext,i)


        def peak_list_wo_eju_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_list_wo_eju_4dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_list_wo_eju_4dContext,i)


        def getRuleIndex(self):
            return NmrViewPKParser.RULE_nmrview_pk

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNmrview_pk" ):
                listener.enterNmrview_pk(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNmrview_pk" ):
                listener.exitNmrview_pk(self)




    def nmrview_pk(self):

        localctx = NmrViewPKParser.Nmrview_pkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_nmrview_pk)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 39
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.state = 38
                self.match(NmrViewPKParser.RETURN)


            self.state = 51
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 263170) != 0):
                self.state = 49
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                if la_ == 1:
                    self.state = 41
                    self.data_label()
                    pass

                elif la_ == 2:
                    self.state = 42
                    self.peak_list_2d()
                    pass

                elif la_ == 3:
                    self.state = 43
                    self.peak_list_3d()
                    pass

                elif la_ == 4:
                    self.state = 44
                    self.peak_list_4d()
                    pass

                elif la_ == 5:
                    self.state = 45
                    self.peak_list_wo_eju_2d()
                    pass

                elif la_ == 6:
                    self.state = 46
                    self.peak_list_wo_eju_3d()
                    pass

                elif la_ == 7:
                    self.state = 47
                    self.peak_list_wo_eju_4d()
                    pass

                elif la_ == 8:
                    self.state = 48
                    self.match(NmrViewPKParser.RETURN)
                    pass


                self.state = 53
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 54
            self.match(NmrViewPKParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Data_labelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Label(self):
            return self.getToken(NmrViewPKParser.Label, 0)

        def Dataset(self):
            return self.getToken(NmrViewPKParser.Dataset, 0)

        def Sw(self):
            return self.getToken(NmrViewPKParser.Sw, 0)

        def Sf(self):
            return self.getToken(NmrViewPKParser.Sf, 0)

        def labels(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.LabelsContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.LabelsContext,i)


        def Condition(self):
            return self.getToken(NmrViewPKParser.Condition, 0)

        def SINGLE_NL_LA(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.SINGLE_NL_LA)
            else:
                return self.getToken(NmrViewPKParser.SINGLE_NL_LA, i)

        def Simple_name_LA(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Simple_name_LA)
            else:
                return self.getToken(NmrViewPKParser.Simple_name_LA, i)

        def getRuleIndex(self):
            return NmrViewPKParser.RULE_data_label

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterData_label" ):
                listener.enterData_label(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitData_label" ):
                listener.exitData_label(self)




    def data_label(self):

        localctx = NmrViewPKParser.Data_labelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_data_label)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 56
            self.match(NmrViewPKParser.Label)
            self.state = 57
            self.match(NmrViewPKParser.Dataset)
            self.state = 58
            self.match(NmrViewPKParser.Sw)
            self.state = 59
            self.match(NmrViewPKParser.Sf)
            self.state = 61
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==17:
                self.state = 60
                self.match(NmrViewPKParser.Condition)


            self.state = 66
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==33:
                self.state = 63
                self.match(NmrViewPKParser.SINGLE_NL_LA)
                self.state = 68
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 69
            self.labels()
            self.state = 71 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 70
                    self.match(NmrViewPKParser.SINGLE_NL_LA)

                else:
                    raise NoViableAltException(self)
                self.state = 73 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

            self.state = 78
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 75
                self.match(NmrViewPKParser.Simple_name_LA)
                self.state = 80
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 82 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 81
                self.match(NmrViewPKParser.SINGLE_NL_LA)
                self.state = 84 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==33):
                    break

            self.state = 86
            self.labels()
            self.state = 88 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 87
                self.match(NmrViewPKParser.SINGLE_NL_LA)
                self.state = 90 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==33):
                    break

            self.state = 92
            self.labels()
            self.state = 94 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 93
                self.match(NmrViewPKParser.SINGLE_NL_LA)
                self.state = 96 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==33):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LabelsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def label(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.LabelContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.LabelContext,i)


        def getRuleIndex(self):
            return NmrViewPKParser.RULE_labels

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLabels" ):
                listener.enterLabels(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLabels" ):
                listener.exitLabels(self)




    def labels(self):

        localctx = NmrViewPKParser.LabelsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_labels)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 98
                self.label()
                self.state = 101 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 20401094656) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.L_name)
            else:
                return self.getToken(NmrViewPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.P_name)
            else:
                return self.getToken(NmrViewPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.W_name)
            else:
                return self.getToken(NmrViewPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.B_name)
            else:
                return self.getToken(NmrViewPKParser.B_name, i)

        def E_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.E_name)
            else:
                return self.getToken(NmrViewPKParser.E_name, i)

        def J_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.J_name)
            else:
                return self.getToken(NmrViewPKParser.J_name, i)

        def U_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.U_name)
            else:
                return self.getToken(NmrViewPKParser.U_name, i)

        def Vol(self):
            return self.getToken(NmrViewPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def peak_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_2dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_2dContext,i)


        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_list_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_2d" ):
                listener.enterPeak_list_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_2d" ):
                listener.exitPeak_list_2d(self)




    def peak_list_2d(self):

        localctx = NmrViewPKParser.Peak_list_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_peak_list_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 103
            self.match(NmrViewPKParser.L_name)
            self.state = 104
            self.match(NmrViewPKParser.P_name)
            self.state = 105
            self.match(NmrViewPKParser.W_name)
            self.state = 106
            self.match(NmrViewPKParser.B_name)
            self.state = 107
            self.match(NmrViewPKParser.E_name)
            self.state = 108
            self.match(NmrViewPKParser.J_name)
            self.state = 109
            self.match(NmrViewPKParser.U_name)
            self.state = 110
            self.match(NmrViewPKParser.L_name)
            self.state = 111
            self.match(NmrViewPKParser.P_name)
            self.state = 112
            self.match(NmrViewPKParser.W_name)
            self.state = 113
            self.match(NmrViewPKParser.B_name)
            self.state = 114
            self.match(NmrViewPKParser.E_name)
            self.state = 115
            self.match(NmrViewPKParser.J_name)
            self.state = 116
            self.match(NmrViewPKParser.U_name)
            self.state = 117
            self.match(NmrViewPKParser.Vol)
            self.state = 118
            self.match(NmrViewPKParser.Int)
            self.state = 119
            self.match(NmrViewPKParser.Stat)
            self.state = 121
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 120
                self.match(NmrViewPKParser.Comment)


            self.state = 123
            self.match(NmrViewPKParser.Flag0)
            self.state = 125
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 124
                self.match(NmrViewPKParser.RETURN)


            self.state = 128 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 127
                self.peak_2d()
                self.state = 130 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Integer)
            else:
                return self.getToken(NmrViewPKParser.Integer, i)

        def enclose_data(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Enclose_dataContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Enclose_dataContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.NumberContext,i)


        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Simple_name)
            else:
                return self.getToken(NmrViewPKParser.Simple_name, i)

        def jcoupling(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.JcouplingContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.JcouplingContext,i)


        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_2d" ):
                listener.enterPeak_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_2d" ):
                listener.exitPeak_2d(self)




    def peak_2d(self):

        localctx = NmrViewPKParser.Peak_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_peak_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 132
            self.match(NmrViewPKParser.Integer)
            self.state = 133
            self.enclose_data()
            self.state = 134
            self.number()
            self.state = 135
            self.number()
            self.state = 136
            self.number()
            self.state = 137
            self.match(NmrViewPKParser.Simple_name)
            self.state = 138
            self.jcoupling()
            self.state = 139
            self.enclose_data()
            self.state = 140
            self.enclose_data()
            self.state = 141
            self.number()
            self.state = 142
            self.number()
            self.state = 143
            self.number()
            self.state = 144
            self.match(NmrViewPKParser.Simple_name)
            self.state = 145
            self.jcoupling()
            self.state = 146
            self.enclose_data()
            self.state = 147
            self.number()
            self.state = 148
            self.number()
            self.state = 149
            self.match(NmrViewPKParser.Integer)
            self.state = 151
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 150
                self.enclose_data()


            self.state = 154 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 153
                self.match(NmrViewPKParser.Integer)
                self.state = 156 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 158
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.L_name)
            else:
                return self.getToken(NmrViewPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.P_name)
            else:
                return self.getToken(NmrViewPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.W_name)
            else:
                return self.getToken(NmrViewPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.B_name)
            else:
                return self.getToken(NmrViewPKParser.B_name, i)

        def E_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.E_name)
            else:
                return self.getToken(NmrViewPKParser.E_name, i)

        def J_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.J_name)
            else:
                return self.getToken(NmrViewPKParser.J_name, i)

        def U_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.U_name)
            else:
                return self.getToken(NmrViewPKParser.U_name, i)

        def Vol(self):
            return self.getToken(NmrViewPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def peak_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_3dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_3dContext,i)


        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_list_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_3d" ):
                listener.enterPeak_list_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_3d" ):
                listener.exitPeak_list_3d(self)




    def peak_list_3d(self):

        localctx = NmrViewPKParser.Peak_list_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_peak_list_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 160
            self.match(NmrViewPKParser.L_name)
            self.state = 161
            self.match(NmrViewPKParser.P_name)
            self.state = 162
            self.match(NmrViewPKParser.W_name)
            self.state = 163
            self.match(NmrViewPKParser.B_name)
            self.state = 164
            self.match(NmrViewPKParser.E_name)
            self.state = 165
            self.match(NmrViewPKParser.J_name)
            self.state = 166
            self.match(NmrViewPKParser.U_name)
            self.state = 167
            self.match(NmrViewPKParser.L_name)
            self.state = 168
            self.match(NmrViewPKParser.P_name)
            self.state = 169
            self.match(NmrViewPKParser.W_name)
            self.state = 170
            self.match(NmrViewPKParser.B_name)
            self.state = 171
            self.match(NmrViewPKParser.E_name)
            self.state = 172
            self.match(NmrViewPKParser.J_name)
            self.state = 173
            self.match(NmrViewPKParser.U_name)
            self.state = 174
            self.match(NmrViewPKParser.L_name)
            self.state = 175
            self.match(NmrViewPKParser.P_name)
            self.state = 176
            self.match(NmrViewPKParser.W_name)
            self.state = 177
            self.match(NmrViewPKParser.B_name)
            self.state = 178
            self.match(NmrViewPKParser.E_name)
            self.state = 179
            self.match(NmrViewPKParser.J_name)
            self.state = 180
            self.match(NmrViewPKParser.U_name)
            self.state = 181
            self.match(NmrViewPKParser.Vol)
            self.state = 182
            self.match(NmrViewPKParser.Int)
            self.state = 183
            self.match(NmrViewPKParser.Stat)
            self.state = 185
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 184
                self.match(NmrViewPKParser.Comment)


            self.state = 187
            self.match(NmrViewPKParser.Flag0)
            self.state = 189
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 188
                self.match(NmrViewPKParser.RETURN)


            self.state = 192 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 191
                self.peak_3d()
                self.state = 194 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Integer)
            else:
                return self.getToken(NmrViewPKParser.Integer, i)

        def enclose_data(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Enclose_dataContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Enclose_dataContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.NumberContext,i)


        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Simple_name)
            else:
                return self.getToken(NmrViewPKParser.Simple_name, i)

        def jcoupling(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.JcouplingContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.JcouplingContext,i)


        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_3d" ):
                listener.enterPeak_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_3d" ):
                listener.exitPeak_3d(self)




    def peak_3d(self):

        localctx = NmrViewPKParser.Peak_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_peak_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 196
            self.match(NmrViewPKParser.Integer)
            self.state = 197
            self.enclose_data()
            self.state = 198
            self.number()
            self.state = 199
            self.number()
            self.state = 200
            self.number()
            self.state = 201
            self.match(NmrViewPKParser.Simple_name)
            self.state = 202
            self.jcoupling()
            self.state = 203
            self.enclose_data()
            self.state = 204
            self.enclose_data()
            self.state = 205
            self.number()
            self.state = 206
            self.number()
            self.state = 207
            self.number()
            self.state = 208
            self.match(NmrViewPKParser.Simple_name)
            self.state = 209
            self.jcoupling()
            self.state = 210
            self.enclose_data()
            self.state = 211
            self.enclose_data()
            self.state = 212
            self.number()
            self.state = 213
            self.number()
            self.state = 214
            self.number()
            self.state = 215
            self.match(NmrViewPKParser.Simple_name)
            self.state = 216
            self.jcoupling()
            self.state = 217
            self.enclose_data()
            self.state = 218
            self.number()
            self.state = 219
            self.number()
            self.state = 220
            self.match(NmrViewPKParser.Integer)
            self.state = 222
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 221
                self.enclose_data()


            self.state = 225 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 224
                self.match(NmrViewPKParser.Integer)
                self.state = 227 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 229
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.L_name)
            else:
                return self.getToken(NmrViewPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.P_name)
            else:
                return self.getToken(NmrViewPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.W_name)
            else:
                return self.getToken(NmrViewPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.B_name)
            else:
                return self.getToken(NmrViewPKParser.B_name, i)

        def E_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.E_name)
            else:
                return self.getToken(NmrViewPKParser.E_name, i)

        def J_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.J_name)
            else:
                return self.getToken(NmrViewPKParser.J_name, i)

        def U_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.U_name)
            else:
                return self.getToken(NmrViewPKParser.U_name, i)

        def Vol(self):
            return self.getToken(NmrViewPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def peak_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_4dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_4dContext,i)


        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_list_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_4d" ):
                listener.enterPeak_list_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_4d" ):
                listener.exitPeak_list_4d(self)




    def peak_list_4d(self):

        localctx = NmrViewPKParser.Peak_list_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_peak_list_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 231
            self.match(NmrViewPKParser.L_name)
            self.state = 232
            self.match(NmrViewPKParser.P_name)
            self.state = 233
            self.match(NmrViewPKParser.W_name)
            self.state = 234
            self.match(NmrViewPKParser.B_name)
            self.state = 235
            self.match(NmrViewPKParser.E_name)
            self.state = 236
            self.match(NmrViewPKParser.J_name)
            self.state = 237
            self.match(NmrViewPKParser.U_name)
            self.state = 238
            self.match(NmrViewPKParser.L_name)
            self.state = 239
            self.match(NmrViewPKParser.P_name)
            self.state = 240
            self.match(NmrViewPKParser.W_name)
            self.state = 241
            self.match(NmrViewPKParser.B_name)
            self.state = 242
            self.match(NmrViewPKParser.E_name)
            self.state = 243
            self.match(NmrViewPKParser.J_name)
            self.state = 244
            self.match(NmrViewPKParser.U_name)
            self.state = 245
            self.match(NmrViewPKParser.L_name)
            self.state = 246
            self.match(NmrViewPKParser.P_name)
            self.state = 247
            self.match(NmrViewPKParser.W_name)
            self.state = 248
            self.match(NmrViewPKParser.B_name)
            self.state = 249
            self.match(NmrViewPKParser.E_name)
            self.state = 250
            self.match(NmrViewPKParser.J_name)
            self.state = 251
            self.match(NmrViewPKParser.U_name)
            self.state = 252
            self.match(NmrViewPKParser.L_name)
            self.state = 253
            self.match(NmrViewPKParser.P_name)
            self.state = 254
            self.match(NmrViewPKParser.W_name)
            self.state = 255
            self.match(NmrViewPKParser.B_name)
            self.state = 256
            self.match(NmrViewPKParser.E_name)
            self.state = 257
            self.match(NmrViewPKParser.J_name)
            self.state = 258
            self.match(NmrViewPKParser.U_name)
            self.state = 259
            self.match(NmrViewPKParser.Vol)
            self.state = 260
            self.match(NmrViewPKParser.Int)
            self.state = 261
            self.match(NmrViewPKParser.Stat)
            self.state = 263
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 262
                self.match(NmrViewPKParser.Comment)


            self.state = 265
            self.match(NmrViewPKParser.Flag0)
            self.state = 267
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 266
                self.match(NmrViewPKParser.RETURN)


            self.state = 270 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 269
                self.peak_4d()
                self.state = 272 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Integer)
            else:
                return self.getToken(NmrViewPKParser.Integer, i)

        def enclose_data(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Enclose_dataContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Enclose_dataContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.NumberContext,i)


        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Simple_name)
            else:
                return self.getToken(NmrViewPKParser.Simple_name, i)

        def jcoupling(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.JcouplingContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.JcouplingContext,i)


        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_4d" ):
                listener.enterPeak_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_4d" ):
                listener.exitPeak_4d(self)




    def peak_4d(self):

        localctx = NmrViewPKParser.Peak_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_peak_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 274
            self.match(NmrViewPKParser.Integer)
            self.state = 275
            self.enclose_data()
            self.state = 276
            self.number()
            self.state = 277
            self.number()
            self.state = 278
            self.number()
            self.state = 279
            self.match(NmrViewPKParser.Simple_name)
            self.state = 280
            self.jcoupling()
            self.state = 281
            self.enclose_data()
            self.state = 282
            self.enclose_data()
            self.state = 283
            self.number()
            self.state = 284
            self.number()
            self.state = 285
            self.number()
            self.state = 286
            self.match(NmrViewPKParser.Simple_name)
            self.state = 287
            self.jcoupling()
            self.state = 288
            self.enclose_data()
            self.state = 289
            self.enclose_data()
            self.state = 290
            self.number()
            self.state = 291
            self.number()
            self.state = 292
            self.number()
            self.state = 293
            self.match(NmrViewPKParser.Simple_name)
            self.state = 294
            self.jcoupling()
            self.state = 295
            self.enclose_data()
            self.state = 296
            self.enclose_data()
            self.state = 297
            self.number()
            self.state = 298
            self.number()
            self.state = 299
            self.number()
            self.state = 300
            self.match(NmrViewPKParser.Simple_name)
            self.state = 301
            self.jcoupling()
            self.state = 302
            self.enclose_data()
            self.state = 303
            self.number()
            self.state = 304
            self.number()
            self.state = 305
            self.match(NmrViewPKParser.Integer)
            self.state = 307
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 306
                self.enclose_data()


            self.state = 310 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 309
                self.match(NmrViewPKParser.Integer)
                self.state = 312 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 314
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_wo_eju_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.L_name)
            else:
                return self.getToken(NmrViewPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.P_name)
            else:
                return self.getToken(NmrViewPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.W_name)
            else:
                return self.getToken(NmrViewPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.B_name)
            else:
                return self.getToken(NmrViewPKParser.B_name, i)

        def Vol(self):
            return self.getToken(NmrViewPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def peak_wo_eju_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_wo_eju_2dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_wo_eju_2dContext,i)


        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_list_wo_eju_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_wo_eju_2d" ):
                listener.enterPeak_list_wo_eju_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_wo_eju_2d" ):
                listener.exitPeak_list_wo_eju_2d(self)




    def peak_list_wo_eju_2d(self):

        localctx = NmrViewPKParser.Peak_list_wo_eju_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_peak_list_wo_eju_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 316
            self.match(NmrViewPKParser.L_name)
            self.state = 317
            self.match(NmrViewPKParser.P_name)
            self.state = 318
            self.match(NmrViewPKParser.W_name)
            self.state = 319
            self.match(NmrViewPKParser.B_name)
            self.state = 320
            self.match(NmrViewPKParser.L_name)
            self.state = 321
            self.match(NmrViewPKParser.P_name)
            self.state = 322
            self.match(NmrViewPKParser.W_name)
            self.state = 323
            self.match(NmrViewPKParser.B_name)
            self.state = 324
            self.match(NmrViewPKParser.Vol)
            self.state = 325
            self.match(NmrViewPKParser.Int)
            self.state = 326
            self.match(NmrViewPKParser.Stat)
            self.state = 328
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 327
                self.match(NmrViewPKParser.Comment)


            self.state = 330
            self.match(NmrViewPKParser.Flag0)
            self.state = 332
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 331
                self.match(NmrViewPKParser.RETURN)


            self.state = 335 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 334
                self.peak_wo_eju_2d()
                self.state = 337 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_wo_eju_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Integer)
            else:
                return self.getToken(NmrViewPKParser.Integer, i)

        def enclose_data(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Enclose_dataContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Enclose_dataContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.NumberContext,i)


        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_wo_eju_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_wo_eju_2d" ):
                listener.enterPeak_wo_eju_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_wo_eju_2d" ):
                listener.exitPeak_wo_eju_2d(self)




    def peak_wo_eju_2d(self):

        localctx = NmrViewPKParser.Peak_wo_eju_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_peak_wo_eju_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 339
            self.match(NmrViewPKParser.Integer)
            self.state = 340
            self.enclose_data()
            self.state = 341
            self.number()
            self.state = 342
            self.number()
            self.state = 343
            self.number()
            self.state = 344
            self.enclose_data()
            self.state = 345
            self.number()
            self.state = 346
            self.number()
            self.state = 347
            self.number()
            self.state = 348
            self.number()
            self.state = 349
            self.number()
            self.state = 350
            self.match(NmrViewPKParser.Integer)
            self.state = 352
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 351
                self.enclose_data()


            self.state = 355 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 354
                self.match(NmrViewPKParser.Integer)
                self.state = 357 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 359
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_wo_eju_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.L_name)
            else:
                return self.getToken(NmrViewPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.P_name)
            else:
                return self.getToken(NmrViewPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.W_name)
            else:
                return self.getToken(NmrViewPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.B_name)
            else:
                return self.getToken(NmrViewPKParser.B_name, i)

        def Vol(self):
            return self.getToken(NmrViewPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def peak_wo_eju_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_wo_eju_3dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_wo_eju_3dContext,i)


        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_list_wo_eju_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_wo_eju_3d" ):
                listener.enterPeak_list_wo_eju_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_wo_eju_3d" ):
                listener.exitPeak_list_wo_eju_3d(self)




    def peak_list_wo_eju_3d(self):

        localctx = NmrViewPKParser.Peak_list_wo_eju_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_peak_list_wo_eju_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 361
            self.match(NmrViewPKParser.L_name)
            self.state = 362
            self.match(NmrViewPKParser.P_name)
            self.state = 363
            self.match(NmrViewPKParser.W_name)
            self.state = 364
            self.match(NmrViewPKParser.B_name)
            self.state = 365
            self.match(NmrViewPKParser.L_name)
            self.state = 366
            self.match(NmrViewPKParser.P_name)
            self.state = 367
            self.match(NmrViewPKParser.W_name)
            self.state = 368
            self.match(NmrViewPKParser.B_name)
            self.state = 369
            self.match(NmrViewPKParser.L_name)
            self.state = 370
            self.match(NmrViewPKParser.P_name)
            self.state = 371
            self.match(NmrViewPKParser.W_name)
            self.state = 372
            self.match(NmrViewPKParser.B_name)
            self.state = 373
            self.match(NmrViewPKParser.Vol)
            self.state = 374
            self.match(NmrViewPKParser.Int)
            self.state = 375
            self.match(NmrViewPKParser.Stat)
            self.state = 377
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 376
                self.match(NmrViewPKParser.Comment)


            self.state = 379
            self.match(NmrViewPKParser.Flag0)
            self.state = 381
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 380
                self.match(NmrViewPKParser.RETURN)


            self.state = 384 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 383
                self.peak_wo_eju_3d()
                self.state = 386 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_wo_eju_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Integer)
            else:
                return self.getToken(NmrViewPKParser.Integer, i)

        def enclose_data(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Enclose_dataContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Enclose_dataContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.NumberContext,i)


        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_wo_eju_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_wo_eju_3d" ):
                listener.enterPeak_wo_eju_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_wo_eju_3d" ):
                listener.exitPeak_wo_eju_3d(self)




    def peak_wo_eju_3d(self):

        localctx = NmrViewPKParser.Peak_wo_eju_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_peak_wo_eju_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 388
            self.match(NmrViewPKParser.Integer)
            self.state = 389
            self.enclose_data()
            self.state = 390
            self.number()
            self.state = 391
            self.number()
            self.state = 392
            self.number()
            self.state = 393
            self.enclose_data()
            self.state = 394
            self.number()
            self.state = 395
            self.number()
            self.state = 396
            self.number()
            self.state = 397
            self.enclose_data()
            self.state = 398
            self.number()
            self.state = 399
            self.number()
            self.state = 400
            self.number()
            self.state = 401
            self.number()
            self.state = 402
            self.number()
            self.state = 403
            self.match(NmrViewPKParser.Integer)
            self.state = 405
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 404
                self.enclose_data()


            self.state = 408 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 407
                self.match(NmrViewPKParser.Integer)
                self.state = 410 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 412
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_wo_eju_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.L_name)
            else:
                return self.getToken(NmrViewPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.P_name)
            else:
                return self.getToken(NmrViewPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.W_name)
            else:
                return self.getToken(NmrViewPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.B_name)
            else:
                return self.getToken(NmrViewPKParser.B_name, i)

        def Vol(self):
            return self.getToken(NmrViewPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def peak_wo_eju_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Peak_wo_eju_4dContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Peak_wo_eju_4dContext,i)


        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_list_wo_eju_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_wo_eju_4d" ):
                listener.enterPeak_list_wo_eju_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_wo_eju_4d" ):
                listener.exitPeak_list_wo_eju_4d(self)




    def peak_list_wo_eju_4d(self):

        localctx = NmrViewPKParser.Peak_list_wo_eju_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_peak_list_wo_eju_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 414
            self.match(NmrViewPKParser.L_name)
            self.state = 415
            self.match(NmrViewPKParser.P_name)
            self.state = 416
            self.match(NmrViewPKParser.W_name)
            self.state = 417
            self.match(NmrViewPKParser.B_name)
            self.state = 418
            self.match(NmrViewPKParser.L_name)
            self.state = 419
            self.match(NmrViewPKParser.P_name)
            self.state = 420
            self.match(NmrViewPKParser.W_name)
            self.state = 421
            self.match(NmrViewPKParser.B_name)
            self.state = 422
            self.match(NmrViewPKParser.L_name)
            self.state = 423
            self.match(NmrViewPKParser.P_name)
            self.state = 424
            self.match(NmrViewPKParser.W_name)
            self.state = 425
            self.match(NmrViewPKParser.B_name)
            self.state = 426
            self.match(NmrViewPKParser.L_name)
            self.state = 427
            self.match(NmrViewPKParser.P_name)
            self.state = 428
            self.match(NmrViewPKParser.W_name)
            self.state = 429
            self.match(NmrViewPKParser.B_name)
            self.state = 430
            self.match(NmrViewPKParser.Vol)
            self.state = 431
            self.match(NmrViewPKParser.Int)
            self.state = 432
            self.match(NmrViewPKParser.Stat)
            self.state = 434
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 433
                self.match(NmrViewPKParser.Comment)


            self.state = 436
            self.match(NmrViewPKParser.Flag0)
            self.state = 438
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 437
                self.match(NmrViewPKParser.RETURN)


            self.state = 441 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 440
                self.peak_wo_eju_4d()
                self.state = 443 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_wo_eju_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Integer)
            else:
                return self.getToken(NmrViewPKParser.Integer, i)

        def enclose_data(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.Enclose_dataContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.Enclose_dataContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewPKParser.NumberContext,i)


        def RETURN(self):
            return self.getToken(NmrViewPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewPKParser.RULE_peak_wo_eju_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_wo_eju_4d" ):
                listener.enterPeak_wo_eju_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_wo_eju_4d" ):
                listener.exitPeak_wo_eju_4d(self)




    def peak_wo_eju_4d(self):

        localctx = NmrViewPKParser.Peak_wo_eju_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_peak_wo_eju_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 445
            self.match(NmrViewPKParser.Integer)
            self.state = 446
            self.enclose_data()
            self.state = 447
            self.number()
            self.state = 448
            self.number()
            self.state = 449
            self.number()
            self.state = 450
            self.enclose_data()
            self.state = 451
            self.number()
            self.state = 452
            self.number()
            self.state = 453
            self.number()
            self.state = 454
            self.enclose_data()
            self.state = 455
            self.number()
            self.state = 456
            self.number()
            self.state = 457
            self.number()
            self.state = 458
            self.enclose_data()
            self.state = 459
            self.number()
            self.state = 460
            self.number()
            self.state = 461
            self.number()
            self.state = 462
            self.number()
            self.state = 463
            self.number()
            self.state = 464
            self.match(NmrViewPKParser.Integer)
            self.state = 466
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 465
                self.enclose_data()


            self.state = 469 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 468
                self.match(NmrViewPKParser.Integer)
                self.state = 471 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 473
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LabelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float_LA(self):
            return self.getToken(NmrViewPKParser.Float_LA, 0)

        def Simple_name_LA(self):
            return self.getToken(NmrViewPKParser.Simple_name_LA, 0)

        def ENCLOSE_DATA_LA(self):
            return self.getToken(NmrViewPKParser.ENCLOSE_DATA_LA, 0)

        def getRuleIndex(self):
            return NmrViewPKParser.RULE_label

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLabel" ):
                listener.enterLabel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLabel" ):
                listener.exitLabel(self)




    def label(self):

        localctx = NmrViewPKParser.LabelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_label)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 475
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 20401094656) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class JcouplingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(NmrViewPKParser.Float, 0)

        def Simple_name(self):
            return self.getToken(NmrViewPKParser.Simple_name, 0)

        def enclose_data(self):
            return self.getTypedRuleContext(NmrViewPKParser.Enclose_dataContext,0)


        def getRuleIndex(self):
            return NmrViewPKParser.RULE_jcoupling

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterJcoupling" ):
                listener.enterJcoupling(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitJcoupling" ):
                listener.exitJcoupling(self)




    def jcoupling(self):

        localctx = NmrViewPKParser.JcouplingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_jcoupling)
        try:
            self.state = 480
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [3]:
                self.enterOuterAlt(localctx, 1)
                self.state = 477
                self.match(NmrViewPKParser.Float)
                pass
            elif token in [8]:
                self.enterOuterAlt(localctx, 2)
                self.state = 478
                self.match(NmrViewPKParser.Simple_name)
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 3)
                self.state = 479
                self.enclose_data()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(NmrViewPKParser.Float, 0)

        def Integer(self):
            return self.getToken(NmrViewPKParser.Integer, 0)

        def Simple_name(self):
            return self.getToken(NmrViewPKParser.Simple_name, 0)

        def getRuleIndex(self):
            return NmrViewPKParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = NmrViewPKParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 482
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 268) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Enclose_dataContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brace(self):
            return self.getToken(NmrViewPKParser.L_brace, 0)

        def R_brace(self):
            return self.getToken(NmrViewPKParser.R_brace, 0)

        def Any_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewPKParser.Any_name)
            else:
                return self.getToken(NmrViewPKParser.Any_name, i)

        def getRuleIndex(self):
            return NmrViewPKParser.RULE_enclose_data

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnclose_data" ):
                listener.enterEnclose_data(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnclose_data" ):
                listener.exitEnclose_data(self)




    def enclose_data(self):

        localctx = NmrViewPKParser.Enclose_dataContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_enclose_data)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 484
            self.match(NmrViewPKParser.L_brace)
            self.state = 488
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==35:
                self.state = 485
                self.match(NmrViewPKParser.Any_name)
                self.state = 490
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 491
            self.match(NmrViewPKParser.R_brace)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





