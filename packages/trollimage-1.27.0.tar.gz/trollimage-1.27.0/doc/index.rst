TrollImage
==========

.. image:: _static/hayan.png

Get the source code here_ !

.. _here: http://github.com/pytroll/trollimage

Contents:

.. toctree::
   :maxdepth: 2

   installation
   colormap
   API <api/modules>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

