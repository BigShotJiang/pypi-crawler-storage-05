Trollimage
==========

.. image:: https://img.shields.io/pypi/v/trollimage.svg
    :target: https://pypi.python.org/pypi/trollimage/
    :alt: Version

.. image:: https://anaconda.org/conda-forge/trollimage/badges/version.svg
   :target: https://anaconda.org/conda-forge/trollimage/
   :alt: Conda-forge

.. image:: https://github.com/pytroll/trollimage/workflows/CI/badge.svg?branch=main
    :target: https://github.com/pytroll/trollimage/actions?query=workflow%3A%22CI%22
    :alt: GitHub Actions

.. image:: https://coveralls.io/repos/pytroll/trollimage/badge.png?branch=main
    :target: https://coveralls.io/r/pytroll/trollimage?branch=main
    :alt: Coverage

Imaging package for pytroll packages like
`SatPy <https://github.com/pytroll/satpy>`_.

