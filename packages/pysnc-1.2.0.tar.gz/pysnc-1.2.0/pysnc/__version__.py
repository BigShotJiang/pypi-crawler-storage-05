import importlib.metadata
__title__ = 'pysnc'
__version__ = importlib.metadata.version(__title__)
