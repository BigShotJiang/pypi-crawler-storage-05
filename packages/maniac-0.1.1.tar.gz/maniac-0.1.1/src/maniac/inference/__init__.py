"""Maniac inference module - Core client and utilities"""

from .client import Maniac

__all__ = ["Maniac"]