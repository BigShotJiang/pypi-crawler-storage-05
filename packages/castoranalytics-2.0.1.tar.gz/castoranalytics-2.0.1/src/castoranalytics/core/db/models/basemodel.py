from sqlalchemy.orm import declarative_base


BaseModel = declarative_base()