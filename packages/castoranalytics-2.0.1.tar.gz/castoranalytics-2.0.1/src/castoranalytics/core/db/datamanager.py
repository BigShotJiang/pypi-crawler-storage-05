from castoranalytics.core.singleton import singleton


@singleton
class DataManager:
    pass