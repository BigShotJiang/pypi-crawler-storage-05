"""Pytest setup."""

from pathlib import Path

data_folder = Path(__file__).parent / "data"
