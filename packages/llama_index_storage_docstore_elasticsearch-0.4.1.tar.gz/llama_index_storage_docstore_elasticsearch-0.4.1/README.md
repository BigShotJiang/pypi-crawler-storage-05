# LlamaIndex Docstore Integration: Elasticsearch
