from setuptools import setup, find_packages

setup(
    name="1joepie-prank",
    version="0.4.0",
    packages=find_packages(),
    description="Joepie's prank tools (safe but realistic)",
    author="Noah",
    #python_requires=">=3.8",
)
