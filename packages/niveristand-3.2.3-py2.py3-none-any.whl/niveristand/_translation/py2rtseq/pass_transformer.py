def pass_transformer(node, resources):
    return ""
