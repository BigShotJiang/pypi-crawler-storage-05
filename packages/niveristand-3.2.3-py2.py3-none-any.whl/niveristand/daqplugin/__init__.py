"""Module for NationalInstruments.VeriStand.DAQPlugin."""
### AUTO-GENERATED CODE - DO NOT MODIFY DIRECTLY ###

from ._auto_generated_classes import *
