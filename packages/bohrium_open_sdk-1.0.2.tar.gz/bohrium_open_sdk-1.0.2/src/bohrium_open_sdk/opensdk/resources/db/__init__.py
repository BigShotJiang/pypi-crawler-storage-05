# -*- coding: UTF-8 -*-
from .db import AppDB

__all__ = [
    "AppDB"
]
