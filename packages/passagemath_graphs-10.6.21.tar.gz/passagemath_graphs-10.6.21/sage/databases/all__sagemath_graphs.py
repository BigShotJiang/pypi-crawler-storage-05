# sage_setup: distribution = sagemath-graphs
