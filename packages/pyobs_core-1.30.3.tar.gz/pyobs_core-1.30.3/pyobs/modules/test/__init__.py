"""
Test modules.
TODO: write doc
"""

__title__ = "Test modules"

from .standalone import StandAlone
