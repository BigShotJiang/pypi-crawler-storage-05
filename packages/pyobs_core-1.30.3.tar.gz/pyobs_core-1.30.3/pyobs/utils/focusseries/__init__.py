"""
TODO: write docs
"""

__title__ = "Focus series"

from .base import FocusSeries
from .photometry import PhotometryFocusSeries
from .projection import ProjectionFocusSeries
