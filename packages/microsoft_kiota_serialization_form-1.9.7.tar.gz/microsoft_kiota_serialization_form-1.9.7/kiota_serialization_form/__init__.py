"""
Implementation of Kiota Serialization Interfaces for URI-Form encoded serialization
"""
from ._version import VERSION

__version__ = VERSION
