# Changelog

## 0.2.0 (2025-09-09)

Full Changelog: [v0.1.1...v0.2.0](https://github.com/limrun-inc/python-sdk/compare/v0.1.1...v0.2.0)

### Features

* **api:** manual updates ([9c3f233](https://github.com/limrun-inc/python-sdk/commit/9c3f2330f50cdeef71004c7ea10874cc4fc157d3))


### Chores

* update SDK settings ([eef22eb](https://github.com/limrun-inc/python-sdk/commit/eef22eba5f9ee08a1620cf7155306f01b9c0020c))

## 0.1.1 (2025-09-09)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/limrun-inc/python-sdk/compare/v0.1.0...v0.1.1)

### Chores

* update SDK settings ([e1a6a95](https://github.com/limrun-inc/python-sdk/commit/e1a6a95be568d7fd21fcbfeba3460b2934e84212))

## 0.1.0 (2025-09-08)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/limrun-inc/python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([77b548c](https://github.com/limrun-inc/python-sdk/commit/77b548ca5977d8155954a4ad2da14086ef66de59))


### Chores

* configure new SDK language ([2c6c2f5](https://github.com/limrun-inc/python-sdk/commit/2c6c2f56099811070dc4c137f4cdbad18ec5c5a6))
* update SDK settings ([905181c](https://github.com/limrun-inc/python-sdk/commit/905181c229934fd82579ea0364b5d34f05b89138))
