API
===

The API for FlexEval is still largely undocumented, although the package is not large.

A good place to start is with the Pydantic class :class:`~flexeval.schema.evalrun_schema.EvalRun`, which defines the inputs expected by FlexEval.

Packages:

.. autosummary::
   :toctree: generated
   :recursive:

   flexeval