.. _user_guide:

User guide
==========

Consult :ref:`getting_started` for information about :ref:`installation` and basic :ref:`getting-started-usage`.

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   motivation
   abstractions
   cli
   logging
   rubric_guide
