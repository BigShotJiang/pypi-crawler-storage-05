"""Input/output utilities, primarily for reading and writing the :mod:`~flexeval.schema` objects."""
