"""Built-in completion functions, function metrics, and rubric metrics."""
