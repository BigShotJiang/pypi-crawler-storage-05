def has_question_mark(text: str) -> bool:
    return "?" in text
