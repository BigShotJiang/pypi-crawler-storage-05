def collate_identity[T](batch: T) -> T:
    return batch
