# boot-loader

An async boot loader that scans your project, shows a spinner, loads Python & JSON files, and can start a Discord bot.

## Installation

```bash
pip install boot-loader
