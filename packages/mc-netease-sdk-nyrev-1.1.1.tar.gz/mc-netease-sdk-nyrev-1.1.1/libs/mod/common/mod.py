# -*- coding: utf-8 -*-
class Mod(object):
    @staticmethod
    def Binding(name, version=None):
        pass

    @staticmethod
    def InitClient():
        pass

    @staticmethod
    def DestroyClient():
        pass

    @staticmethod
    def InitServer():
        pass

    @staticmethod
    def DestroyServer():
        pass
