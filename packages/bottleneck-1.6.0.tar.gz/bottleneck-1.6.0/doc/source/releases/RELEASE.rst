
=============
Release Notes
=============

:titlesonly:

These are the major changes made in each release. For details of the changes
see the commit log at https://github.com/pydata/bottleneck

.. contents::
   :depth: 1
   :local:

.. include:: v1.4.0.rst

.. include:: v1.3.2.rst

.. include:: v1.3.1.rst

.. include:: v1.3.0.rst

.. include:: v1.2.1.rst

.. include:: v1.2.0.rst

.. include:: v1.1.0.rst

.. include:: v1.0.0.rst

.. include:: v0.8.0.rst

.. include:: v0.7.0.rst

.. include:: v0.6.0.rst

.. include:: v0.5.0.rst

.. include:: v0.4.3.rst

.. include:: v0.4.2.rst

.. include:: v0.4.1.rst

.. include:: v0.4.0.rst

.. include:: v0.3.0.rst

.. include:: v0.2.0.rst

.. include:: v0.1.0.rst
