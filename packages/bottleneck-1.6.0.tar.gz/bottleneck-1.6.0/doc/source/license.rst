Licenses
========
Bottleneck is distributed under a Simplified BSD license. Parts of NumPy and
SciPy, which have BSD licenses, are included in Bottleneck. The setuptools project has a MIT license and is used for configuration and installation.

Bottleneck License
~~~~~~~~~~~~~~~~~~
.. include:: ../../LICENSE


Other licenses
~~~~~~~~~~~~~~

NumPy License
-------------
.. include:: ../../LICENSES/NUMPY_LICENSE


SciPy License
-------------
.. include:: ../../LICENSES/SCIPY_LICENSE


Setuptools License
------------------
.. include:: ../../LICENSES/SETUPTOOLS_LICENSE
