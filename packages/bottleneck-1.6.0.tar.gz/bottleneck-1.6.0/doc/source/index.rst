==========
Bottleneck
==========

Fast NumPy array functions written in C.

.. toctree::
   :maxdepth: 2
   
   intro
   reference
   release
   license

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
