================================
 :mod:`zope.deferredimport` API
================================

.. automodule:: zope.deferredimport
   :members:
