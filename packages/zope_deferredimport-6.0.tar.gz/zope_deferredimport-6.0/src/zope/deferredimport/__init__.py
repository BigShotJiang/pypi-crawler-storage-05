from zope.deferredimport.deferredmodule import define
from zope.deferredimport.deferredmodule import defineFrom
from zope.deferredimport.deferredmodule import deprecated
from zope.deferredimport.deferredmodule import deprecatedFrom
from zope.deferredimport.deferredmodule import initialize


__all__ = (
    'initialize',
    'define',
    'defineFrom',
    'deprecated',
    'deprecatedFrom',
)
