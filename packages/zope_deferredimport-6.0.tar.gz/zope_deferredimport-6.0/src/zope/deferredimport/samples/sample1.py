print("Sampe 1 imported!")

x = 1


class C:
    y = 2


z = 3
q = 4
