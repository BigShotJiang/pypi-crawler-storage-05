import zope.deferredimport.sample5


def getone():
    return zope.deferredimport.sample5.one
