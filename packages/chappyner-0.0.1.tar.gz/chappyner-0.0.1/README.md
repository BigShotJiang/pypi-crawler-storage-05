# Chappyner
Chappyner allows to run http services on an HPC cluster.

TBC .....

## License
GPL3 or greater, to be added

## Authors
[Fabio Pitari](mailto:f.pitari@cineca.it?&subject=Chappyner), [Lucia Rodriguez Muñoz](mailto:l.rodriguezmunoz@cineca.it?&subject=Chappyner), [Antonio Memmolo](mailto:a.memmolo@cineca.it?&subject=Chappyner)
