# LlamaIndex Vector_Stores Integration: Cassandra
