from .bruce_uiautomation import WeChatAutomator
