from .xhs_core import XHSCrawler

__version__ = "1.0.0"
__all__ = ["XHSCrawler"]