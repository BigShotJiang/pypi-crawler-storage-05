from .detector import BannedWordsDetector
__all__ = ['BannedWordsDetector']
__version__ = "1.0.0"