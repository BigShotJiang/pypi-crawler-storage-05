def create_dot_mulch(target_dir, order_of_respect):
    pass

