"""Finland-specific recognizers."""

from .fi_personal_identity_code_recognizer import FiPersonalIdentityCodeRecognizer

__all__ = [
    "FiPersonalIdentityCodeRecognizer",
]
