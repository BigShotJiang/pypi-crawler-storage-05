"""Korea-specific recognizers."""

from .kr_rrn_recognizer import KrRrnRecognizer

__all__ = [
    "KrRrnRecognizer",
]
