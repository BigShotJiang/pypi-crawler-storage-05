"""Poland-specific recognizers."""

from .pl_pesel_recognizer import PlPeselRecognizer

__all__ = [
    "PlPeselRecognizer",
]
