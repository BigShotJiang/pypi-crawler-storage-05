"""
Context Engine MCP Server

A Model Context Protocol server for managing contextual flags
that enhance AI assistant capabilities.
"""

from .__version__ import __version__