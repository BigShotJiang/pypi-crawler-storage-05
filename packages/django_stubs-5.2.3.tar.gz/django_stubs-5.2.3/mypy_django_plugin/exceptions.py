class UnregisteredModelError(Exception):
    """The requested model is not registered"""
