Esta busca de informações a partir do cnpj é realizada com base no
provedor configurado na aba de configurações, vale ressaltar que o
provedor receitaws permite a realização de três consultas por minuto,
enquanto que o SERPRO é pago e permite consultas ilimitadas em seus
planos.
