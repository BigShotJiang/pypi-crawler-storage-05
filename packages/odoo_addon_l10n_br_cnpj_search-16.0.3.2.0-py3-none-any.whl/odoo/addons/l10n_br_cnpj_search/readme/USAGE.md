1.  Acesse Configurações
2.  Escolha um provedor para a busca
3.  Acesse Configurações \> Usuários e Empresas \> Empresas \> Criar ou
    acesse Contatos \> Criar
4.  Preencha os campos obrigatórios, insira no campo de CNPJ o CNPJ que
    deseja buscar e clique na lupa ao lado do campo para buscar
5.  O mesmo procedimento pode ser feito editando alguma empresa.
