# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import l10n_br_base_party_mixin
from . import res_config_settings
from . import cnpj_webservice
from . import res_company
