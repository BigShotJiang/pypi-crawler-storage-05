# `@basetenlabs/performance-client-darwin-universal`

This is the **universal-apple-darwin** binary for `@basetenlabs/performance-client`
