"""
ctxzz Profile Card
Atsushi Omata / ctxzz's animated terminal profile cards.
"""

__version__ = "1.0.0"
__author__ = "Atsushi Omata"
__email__ = "omata.atushi.open@gmail.com"