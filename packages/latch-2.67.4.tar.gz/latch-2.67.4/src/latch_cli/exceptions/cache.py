from typing import Dict, List, Tuple

_code_cache: Dict[Tuple[str, int], List[str]] = {}
