from streamlink.session.session import Streamlink
