Support
-------

If you think that Streamlink is useful and if you want to keep the project alive,
then please consider supporting its maintainers and contributors by sending a small and optionally recurring tip
via the available options listed on their GitHub profiles.

Your support is very much appreciated, thank you!


Useful links
============

- Streamlink's GitHub releases with the changelog summary and commit history of each release:

  https://github.com/streamlink/streamlink/releases

- Streamlink's monthly repository activity:

  https://github.com/streamlink/streamlink/pulse/monthly

- All Streamlink repositories:

  https://github.com/orgs/streamlink/repositories
