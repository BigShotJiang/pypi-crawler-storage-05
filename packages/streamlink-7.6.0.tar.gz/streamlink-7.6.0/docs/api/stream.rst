Stream
------

.. module:: streamlink.stream

All streams inherit from the :class:`Stream` base class.

.. autoclass:: Stream

.. autoclass:: MuxedStream

.. autoclass:: HTTPStream

.. autoclass:: HLSStream

.. autoclass:: MuxedHLSStream

.. autoclass:: DASHStream
