Session
-------

.. autoclass:: streamlink.session.Streamlink
    :member-order: bysource

.. autoclass:: streamlink.session.options.StreamlinkOptions

    .. automethod:: get
    .. automethod:: set

.. autoclass:: streamlink.session.plugins.StreamlinkPlugins
    :member-order: bysource
    :special-members: __getitem__, __setitem__, __delitem__, __contains__
