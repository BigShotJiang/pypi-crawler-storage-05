Webbrowser
----------

.. warning::

    The APIs of the ``streamlink.webbrowser`` package are considered unstable. Use at your own risk!

.. module:: streamlink.webbrowser

.. autoclass:: streamlink.webbrowser.cdp.client.CDPClient
.. autoclass:: streamlink.webbrowser.cdp.client.CDPClientSession
.. autoclass:: streamlink.webbrowser.cdp.client.CMRequestProxy
.. autoclass:: streamlink.webbrowser.cdp.connection.CDPBase
.. autoclass:: streamlink.webbrowser.cdp.connection.CDPConnection
.. autoclass:: streamlink.webbrowser.cdp.connection.CDPSession
.. autoclass:: streamlink.webbrowser.cdp.connection.CDPEventListener
.. autoclass:: streamlink.webbrowser.webbrowser.Webbrowser
.. autoclass:: streamlink.webbrowser.chromium.ChromiumWebbrowser
