===============
atsphinx-qrcode
===============

Render QRCode image on Sphinx document.

Getting started
===============

.. code:: console

   pip install atsphinx-qrcode

.. code:: python

   extensions = [
       ...,  # Your extensions
       "atsphinx.qrcode",
   ]
