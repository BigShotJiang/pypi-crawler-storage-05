===========
Change logs
===========

v0.1.0
======

:date: 2025-09-08 (Asia/Tokyo)

Initial commit.

Features
--------

* Render single sized QRCode.
