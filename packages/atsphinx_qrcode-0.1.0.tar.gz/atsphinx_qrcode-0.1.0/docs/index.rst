===============
atsphinx-qrcode
===============

.. container:: flex

    .. container:: size-1

        .. code-block:: rst

            .. qrcode::

                https://example.com

    .. container:: size-1

        .. qrcode::

            https://example.com

Overview
========

Simple Sphinx extension to render SVG of QRCode.

.. toctree::
   :maxdepth: 1

   guide
   changes
