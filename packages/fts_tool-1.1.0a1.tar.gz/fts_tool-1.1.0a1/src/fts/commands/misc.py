import fts

def cmd_version(args, logger):
    print(f"fts version {fts.__version__()}")
