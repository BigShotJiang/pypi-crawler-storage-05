def __version__():
    return "1.1.0-alpha1"