from src.abstract_paths import start_analyzer
