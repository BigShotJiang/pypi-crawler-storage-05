"""Allow for relative imports in `test_vendor.py`."""
