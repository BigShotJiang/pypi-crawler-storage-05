

from ._class3 import DataStock3 as DataStock
