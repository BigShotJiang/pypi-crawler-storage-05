# Do not edit, pipeline versioning governed by git tags!
__version__ = '0.0.49-1-g545b8a4'
