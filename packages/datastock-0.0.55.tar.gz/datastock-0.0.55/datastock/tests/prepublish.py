print('test import datastock')
import datastock as ds
print('import datastock ok')
