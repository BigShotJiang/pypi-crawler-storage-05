from ._queue import VideoCaptureQueue

__all__ = ["VideoCaptureQueue"]
