from .deprecated import deprecated
from .lru_cache import lru_cache

__all__ = ["deprecated", "lru_cache"]
