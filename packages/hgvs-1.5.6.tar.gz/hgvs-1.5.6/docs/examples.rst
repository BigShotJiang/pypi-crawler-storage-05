Examples
!!!!!!!!

The following examples are derived directly from IPython notebooks in the
hgvs source code `examples directory
<https://github.com/biocommons/hgvs/tree/master/examples>`_.

.. toctree::
  :glob:

  examples/*
