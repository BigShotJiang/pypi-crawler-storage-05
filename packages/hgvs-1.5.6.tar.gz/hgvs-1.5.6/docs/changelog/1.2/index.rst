1.2 Series
@@@@@@@@@@@@@@@@@@@@@@@@@@@@

.. warning::
   Python 2.7 versions of hgvs are now deprecated and will become
   unsupported on April 1, 2019.  See
   [Migrating-to-Python-3.6](https://github.com/biocommons/org/wiki/Migrating-to-Python-3.6).


.. toctree::
   :maxdepth: 1
	      
   1.2.5
   1.2.4
   1.2.3
   1.2.2
   1.2.1
   1.2.0
