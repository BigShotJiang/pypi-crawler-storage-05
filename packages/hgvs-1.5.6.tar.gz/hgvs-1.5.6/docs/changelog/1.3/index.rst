1.3 Series
@@@@@@@@@@@@@@@@@@@@@@@@@@@@

.. warning::
   Python 2.7 versions of hgvs are now obsolete.  The hgvs 1.3 series
   will not receive further updates.  See
   [Migrating-to-Python-3.6](https://github.com/biocommons/org/wiki/Migrating-to-Python-3.6).

.. toctree::
   :maxdepth: 1
	      
   1.3.0
