Variant Object Representation
.............................

:mod:`hgvs.edit`
^^^^^^^^^^^^^^^^

.. automodule:: hgvs.edit

:mod:`hgvs.hgvsposition`
^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: hgvs.hgvsposition

:mod:`hgvs.location`
^^^^^^^^^^^^^^^^^^^^

.. automodule:: hgvs.location

:mod:`hgvs.posedit`
^^^^^^^^^^^^^^^^^^^

.. automodule:: hgvs.posedit

:mod:`hgvs.sequencevariant`
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: hgvs.sequencevariant
