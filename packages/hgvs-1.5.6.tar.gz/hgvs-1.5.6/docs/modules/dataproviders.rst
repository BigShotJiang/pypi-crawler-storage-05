External Data Providers
.......................

:mod:`hgvs.dataproviders.interface`
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: hgvs.dataproviders.interface


:mod:`hgvs.dataproviders.uta`
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: hgvs.dataproviders.uta
