Configuration
.............

:mod:`hgvs.config`
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: hgvs.config


The defaults are:

.. literalinclude:: ../../src/hgvs/_data/defaults.ini
