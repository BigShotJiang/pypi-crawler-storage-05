Validation and Normalization
............................

:mod:`hgvs.validator`
^^^^^^^^^^^^^^^^^^^^^

.. automodule:: hgvs.validator


:mod:`hgvs.normalizer`
^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: hgvs.normalizer
