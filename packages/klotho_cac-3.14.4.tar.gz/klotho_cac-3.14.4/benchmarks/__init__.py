"""
Benchmarking infrastructure for Klotho graph classes performance measurement.

This module provides utilities for consistent benchmarking of graph operations
before and after RustworkX optimization refactoring.
""" 