"""
This module contains sample datasets

"""

from .loader_spxw import spxw

__all__ = ["spxw"]
