"""
Callable script wrapper for the
:py:func:`firewheel.cli.completion.get_total_model_components_size` function.
"""

from firewheel.cli.completion.actions import get_total_model_components_size

if __name__ == "__main__":
    get_total_model_components_size()
