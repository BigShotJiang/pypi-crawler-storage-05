Configuration
-------------

.. automodule:: firewheel.config
    :members:
    :undoc-members:
    :special-members:
    :private-members:
    :exclude-members: __dict__,__weakref__,__module__

.. automodule:: firewheel.config._config
    :members:
    :undoc-members:
    :special-members:
    :private-members:
    :exclude-members: __dict__,__weakref__,__module__
