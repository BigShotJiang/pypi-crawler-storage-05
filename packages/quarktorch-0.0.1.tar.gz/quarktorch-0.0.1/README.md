<center><h2>🚀 QuarkTorch: The smallest torch in the ML universe.</h2></center>


## Install

* Install from source (Recommend)

```bash
cd quarktorch
pip install -e .
```
* Install from PyPI
```bash
pip install quarktorch
```

## Quick Start


## 🌟Citation

```python
@article{guo2025quarktorch,
title={QuarkTorch: The smallest torch in the ML universe.},
author={Runke Zhong},
year={2025}
}
```
**保持热爱，奔赴星海！**

*这个世界上唯有两样东西能让我们的心灵感到深深的震撼：一是我们头上灿烂的星空，一是我们内心崇高的道德法则*

