from .containers import Container

container = Container()

__all__ = ["container"]