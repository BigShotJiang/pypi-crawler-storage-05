"""
A standalone API allowing communication with Imeon Energy inverters.
"""