import sys

from .server_min import main

sys.exit(main())
