__version__ = "2.1.2"  # follows PEP440
