"""Public API for the package."""

from .decorators import tool

__all__ = ["tool"]
