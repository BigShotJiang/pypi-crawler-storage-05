"""
提供各算法模块的测试功能
"""

from .test import test_module, test_io, test_script

# from .test_module import TestModule

from .testor import Testor

