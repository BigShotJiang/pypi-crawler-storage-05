# Encrep
# MIT license
# Copyright © 2025 Anatoly Petrov (petrov.projects@gmail.com)
# All rights reserved

from .main import app
app(prog_name="encrep")