# LlamaIndex Vector_Stores Integration: Tair
