from llama_index.vector_stores.tair.base import TairVectorStore

__all__ = ["TairVectorStore"]
