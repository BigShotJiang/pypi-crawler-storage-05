from pydantic import BaseModel


class NodeMeta(BaseModel):
    id: str
