from .config import get_fame_config

__all__ = ["get_fame_config"]
