import wbcrm.synchronization.activity.admin  # noqa
