"""
This module contains a functions that monkey patch third party dependencies in the one or other way.
"""

__license__ = "GNU Affero General Public License http://www.gnu.org/licenses/agpl.html"
