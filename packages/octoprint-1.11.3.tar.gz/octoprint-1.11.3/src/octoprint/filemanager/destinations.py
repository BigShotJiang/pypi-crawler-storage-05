__license__ = "GNU Affero General Public License http://www.gnu.org/licenses/agpl.html"


class FileDestinations:
    SDCARD = "sdcard"
    LOCAL = "local"
