from __future__ import annotations
from win32more.win32.prelude import *
import win32more.Windows.Win32.Storage.StructuredStorage
JET_API_PTR = UIntPtr
JET_HANDLE = UIntPtr
JET_TABLEID = UIntPtr


make_ready(__name__)
