## init
from llama_index.tools.bing_search.base import (
    ENDPOINT_BASE_URL,
    BingSearchToolSpec,
)

__all__ = ["BingSearchToolSpec", "ENDPOINT_BASE_URL"]
