# Citation Information

If you use this theory implementation in academic work, please cite:

Benjamin Brast-McKie. (2025). Bimodal: A semantic theory implementation for the
ModelChecker framework.

## Theory Implementation Notes

This theory implementation is part of the ModelChecker framework.
For more detailed information about the theory's mathematical foundations,
please include additional references here.
