"""
Version information for MCP Proxy Adapter.
"""

__version__ = "6.3.3"

