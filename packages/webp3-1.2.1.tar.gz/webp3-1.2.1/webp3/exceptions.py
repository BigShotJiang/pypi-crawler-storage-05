# SPDX-License-Identifier: WTFPL


class NotFound(Exception):
	pass


class Forbidden(Exception):
	pass
