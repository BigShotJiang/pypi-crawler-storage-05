from .video import VideoWrapper

__all__ = [
    "VideoWrapper",
]
