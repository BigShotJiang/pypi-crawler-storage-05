# Go2 Simple Locomotion Example

A simple training program for the Go2 robot, using Genesis Forge managed environment, and trained with the SKRL RL library.

## Install requirements

```bash
pip install skrl[torch] pyyaml
```
