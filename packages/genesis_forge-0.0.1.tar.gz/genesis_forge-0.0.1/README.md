<p align="center">
<img src="./images/logo_text.png" width="250" />
</p>

# Genesis Forge

A robotics RL training frameworks for Genesis inspired by Isaac Lab and Gymnasium. The goal of Genesis Forge is to give developers the tools they need to get training quickly, with less of the boilerplate setup.
