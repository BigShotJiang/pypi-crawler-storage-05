.. _whatsnew:

What's New
==========

These are new features and improvements of note in each release.

.. include:: releasenotes/0.7.0.rst

.. include:: releasenotes/0.6.1.rst

.. include:: releasenotes/0.6.0.rst

.. include:: releasenotes/0.5.3.rst

.. include:: releasenotes/0.5.2.rst

.. include:: releasenotes/0.5.1.rst

.. include:: releasenotes/0.5.0.rst

.. include:: releasenotes/0.4.0.rst

.. include:: releasenotes/0.3.0.rst

.. include:: releasenotes/0.2.0.rst

.. include:: releasenotes/0.1.9.rst

.. include:: releasenotes/0.1.8.rst

.. include:: releasenotes/0.1.7.rst

.. include:: releasenotes/beta.rst

.. include:: releasenotes/alpha.rst