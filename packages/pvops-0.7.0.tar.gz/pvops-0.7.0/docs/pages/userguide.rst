User Guide
==========================

.. toctree::
    :maxdepth: 1
    :caption: Getting Started
 
    installation


.. toctree::
    :maxdepth: 1
    :caption: Module Guides
 
    moduleguides/guide_text
    moduleguides/guide_text2time
    moduleguides/guide_timeseries
    moduleguides/guide_iv
    
.. toctree::
    :maxdepth: 1
    :caption: Abbreviations

    abbreviations
