API Documentation
==================

.. toctree::
   :maxdepth: 2

   apidoc/text
   apidoc/text2time
   apidoc/timeseries
   apidoc/iv
