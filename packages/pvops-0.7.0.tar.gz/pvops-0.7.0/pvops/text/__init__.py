"""
text module
"""

import pvops.text.classify
import pvops.text.defaults
import pvops.text.nlp_utils
import pvops.text.preprocess
import pvops.text.utils
import pvops.text.visualize