"""
Entry point for the Snib CLI tool.

Starts the CLI application.
"""

from .cli import app

if __name__ == "__main__":
    app()
