"""
Snib package.

Snib is a Python CLI tool to scan your projects and generate prompt-ready chunks for use with LLMs.
"""

__version__ = "0.4.4"
