# Logger

::: snib.logger.SnibLogger
    options:
        show_signature: true
        show_root_heading: true

::: snib.logger.ColoredFormatter
    options:
        show_signature: true
        show_root_heading: true

::: snib.logger.set_verbose
    options:
        show_signature: true
        show_root_heading: true