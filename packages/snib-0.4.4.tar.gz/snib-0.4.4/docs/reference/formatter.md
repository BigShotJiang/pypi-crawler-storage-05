# Formatter

::: snib.formatter.Formatter
    options:
        show_signature: true
        show_root_heading: true
