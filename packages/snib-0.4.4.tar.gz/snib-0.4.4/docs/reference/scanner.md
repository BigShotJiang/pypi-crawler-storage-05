# Scanner

::: snib.scanner.Scanner
    options:
        show_signature: true
        show_root_heading: true