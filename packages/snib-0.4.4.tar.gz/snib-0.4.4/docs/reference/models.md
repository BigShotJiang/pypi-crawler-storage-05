# Models

::: snib.models.FilterStats
    options:
        show_signature: true
        show_root_heading: true

::: snib.models.Section
    options:
        show_signature: true
        show_root_heading: true