# Utils

::: snib.utils.detect_pattern_conflicts
    options:
      show_signature: true
      show_root_heading: true

::: snib.utils.check_include_in_exclude
    options:
      show_signature: true
      show_root_heading: true

---

::: snib.utils.build_tree
    options:
      show_signature: true
      show_root_heading: true

::: snib.utils.format_size
    options:
      show_signature: true
      show_root_heading: true

---

::: snib.utils.get_task_choices
    options:
      show_signature: true
      show_root_heading: true

::: snib.utils.get_preset_choices
    options:
      show_signature: true
      show_root_heading: true
