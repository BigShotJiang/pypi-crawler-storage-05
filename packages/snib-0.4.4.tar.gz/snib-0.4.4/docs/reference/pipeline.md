# Pipeline

::: snib.pipeline.SnibPipeline
    options:
      show_signature: true
      show_root_heading: true