openstack.block_storage.v3.type
===============================

.. automodule:: openstack.block_storage.v3.type

The Type Class
--------------

The ``Type`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.type.Type
   :members:

The TypeEncryption Class
------------------------

The ``TypeEncryption`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.type.TypeEncryption
   :members:
