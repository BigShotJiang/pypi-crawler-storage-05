openstack.block_storage.v3.group_snapshot
=========================================

.. automodule:: openstack.block_storage.v3.group_snapshot

The GroupSnapshot Class
-----------------------

The ``GroupSnapshot`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.group_snapshot.GroupSnapshot
   :members:
