openstack.block_storage.v2.volume
=================================

.. automodule:: openstack.block_storage.v2.volume

The Volume Class
----------------

The ``Volume`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v2.volume.Volume
   :members:
