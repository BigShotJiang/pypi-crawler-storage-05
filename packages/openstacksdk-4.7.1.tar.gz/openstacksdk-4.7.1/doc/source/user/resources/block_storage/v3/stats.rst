openstack.block_storage.v3.stats
================================

.. automodule:: openstack.block_storage.v3.stats

The Pools Class
---------------

The ``Pools`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.stats.Pools
   :members:
