openstack.block_storage.v2.capabilities
=======================================

.. automodule:: openstack.block_storage.v2.capabilities

The Capabilities Class
----------------------

The ``Capabilities`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v2.capabilities.Capabilities
   :members:
