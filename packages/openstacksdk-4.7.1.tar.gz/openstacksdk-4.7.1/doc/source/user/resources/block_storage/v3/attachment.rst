openstack.block_storage.v3.attachment
=====================================

.. automodule:: openstack.block_storage.v3.attachment

The Volume Attachment Class
---------------------------

The ``Volume Attachment`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.attachment.Attachment
   :members: create, update, complete
