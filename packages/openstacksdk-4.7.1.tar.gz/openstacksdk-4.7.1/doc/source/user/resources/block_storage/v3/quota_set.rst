openstack.block_storage.v3.quota_set
====================================

.. automodule:: openstack.block_storage.v3.quota_set

The QuotaSet Class
------------------

The ``QuotaSet`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.quota_set.QuotaSet
   :members:
