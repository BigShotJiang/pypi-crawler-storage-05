openstack.block_storage.v2.service
==================================

.. automodule:: openstack.block_storage.v2.service

The Service Class
-----------------

The ``Service`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v2.service.Service
   :members:
