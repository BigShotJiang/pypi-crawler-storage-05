openstack.block_storage.v2.transfer
===================================

.. automodule:: openstack.block_storage.v2.transfer

The Volume Transfer Class
-------------------------

The ``Volume Transfer`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v2.transfer.Transfer
   :members:
