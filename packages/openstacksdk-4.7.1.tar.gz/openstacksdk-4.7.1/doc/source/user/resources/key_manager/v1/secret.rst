openstack.key_manager.v1.secret
===============================

.. automodule:: openstack.key_manager.v1.secret

The Secret Class
----------------

The ``Secret`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.key_manager.v1.secret.Secret
   :members:
