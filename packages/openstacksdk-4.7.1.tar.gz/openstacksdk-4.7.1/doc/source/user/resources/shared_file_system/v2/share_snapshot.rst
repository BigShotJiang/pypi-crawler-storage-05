openstack.shared_file_system.v2.share_snapshot
==============================================

.. automodule:: openstack.shared_file_system.v2.share_snapshot

The ShareSnapshot Class
-----------------------

The ``ShareSnapshot`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.share_snapshot.ShareSnapshot
   :members:
