openstack.shared_file_system.v2.share_network_subnet
====================================================

.. automodule:: openstack.shared_file_system.v2.share_network_subnet

The ShareNetworkSubnet Class
----------------------------

The ``ShareNetworkSubnet`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.share_network_subnet.ShareNetworkSubnet
   :members:
