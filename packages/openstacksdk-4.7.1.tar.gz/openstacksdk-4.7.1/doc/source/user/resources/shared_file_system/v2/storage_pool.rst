openstack.shared_file_system.v2.storage_pool
============================================

.. automodule:: openstack.shared_file_system.v2.storage_pool

The StoragePool Class
---------------------

The ``StoragePool`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.storage_pool.StoragePool
   :members:
