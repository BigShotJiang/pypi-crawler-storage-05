Shared File System service resources
====================================

.. toctree::
   :maxdepth: 1

   v2/availability_zone
   v2/storage_pool
   v2/limit
   v2/share
   v2/share_instance
   v2/share_network_subnet
   v2/share_snapshot
   v2/share_snapshot_instance
   v2/share_network
   v2/user_message
   v2/share_group
   v2/share_access_rule
   v2/share_group_snapshot
   v2/resource_locks
   v2/quota_class_set
