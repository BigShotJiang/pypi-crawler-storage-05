openstack.shared_file_system.v2.share_snapshot_instance
=======================================================

.. automodule:: openstack.shared_file_system.v2.share_snapshot_instance

The ShareSnapshotInstance Class
-------------------------------

The ``ShareSnapshotInstance`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.share_snapshot_instance.ShareSnapshotInstance
   :members:
