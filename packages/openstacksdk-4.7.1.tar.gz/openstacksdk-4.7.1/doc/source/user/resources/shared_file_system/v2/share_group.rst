openstack.shared_file_system.v2.share_group
===========================================

.. automodule:: openstack.shared_file_system.v2.share_group

The ShareGroup Class
--------------------

The ``ShareGroup`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.share_group.ShareGroup
   :members:
