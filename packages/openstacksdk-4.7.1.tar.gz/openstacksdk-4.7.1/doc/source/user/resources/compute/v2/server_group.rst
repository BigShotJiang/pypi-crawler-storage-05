openstack.compute.v2.server_group
=================================

.. automodule:: openstack.compute.v2.server_group

The ServerGroup Class
---------------------

The ``ServerGroup`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.server_group.ServerGroup
   :members:
