openstack.compute.v2.volume_attachment
======================================

.. automodule:: openstack.compute.v2.volume_attachment

The VolumeAttachment Class
--------------------------

The ``VolumeAttachment`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.volume_attachment.VolumeAttachment
   :members:
