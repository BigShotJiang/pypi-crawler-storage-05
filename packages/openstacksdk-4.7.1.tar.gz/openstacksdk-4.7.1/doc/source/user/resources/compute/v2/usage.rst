openstack.compute.v2.usage
==========================

.. automodule:: openstack.compute.v2.usage

The Usage Class
---------------

The ``Usage`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.usage.Usage
   :members:

The ServerUsage Class
---------------------

The ``ServerUsage`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.usage.ServerUsage
   :members:
