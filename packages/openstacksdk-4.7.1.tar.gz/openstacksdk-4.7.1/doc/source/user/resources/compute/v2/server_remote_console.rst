openstack.compute.v2.server_remote_console
==========================================

.. automodule:: openstack.compute.v2.server_remote_console

The ServerRemoteConsole Class
-----------------------------

The ``ServerRemoteConsole`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.server_remote_console.ServerRemoteConsole
   :members:
