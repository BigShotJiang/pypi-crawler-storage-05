openstack.compute.v2.aggregate
==============================

.. automodule:: openstack.compute.v2.aggregate

The Aggregate Class
-------------------

The ``Aggregate`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.aggregate.Aggregate
   :members:
