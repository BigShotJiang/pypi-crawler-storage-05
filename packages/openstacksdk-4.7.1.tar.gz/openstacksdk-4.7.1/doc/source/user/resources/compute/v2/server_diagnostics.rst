openstack.compute.v2.server_diagnostics
=======================================

.. automodule:: openstack.compute.v2.server_diagnostics

The ServerDiagnostics Class
---------------------------

The ``ServerDiagnostics`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.server_diagnostics.ServerDiagnostics
   :members:
