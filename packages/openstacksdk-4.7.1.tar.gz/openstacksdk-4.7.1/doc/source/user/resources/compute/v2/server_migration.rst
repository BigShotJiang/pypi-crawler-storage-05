openstack.compute.v2.server_migration
=====================================

.. automodule:: openstack.compute.v2.server_migration

The ServerMigration Class
-------------------------

The ``ServerMigration`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.server_migration.ServerMigration
   :members:
