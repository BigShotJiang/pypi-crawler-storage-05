openstack.compute.v2.console_auth_token
=======================================

.. automodule:: openstack.compute.v2.console_auth_token

The ServerRemoteConsole Class
-----------------------------

The ``ConsoleAuthToken`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.console_auth_token.ConsoleAuthToken
   :members:
