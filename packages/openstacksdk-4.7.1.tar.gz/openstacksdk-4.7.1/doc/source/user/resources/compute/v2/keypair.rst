openstack.compute.v2.keypair
============================

.. automodule:: openstack.compute.v2.keypair

The Keypair Class
-----------------

The ``Keypair`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.keypair.Keypair
   :members:
