openstack.network.v2.vpn_ipsec_policy
=====================================

.. automodule:: openstack.network.v2.vpn_ipsec_policy

The VpnIpsecPolicy Class
------------------------

The ``VpnIpsecPolicy`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.vpn_ipsec_policy.VpnIpsecPolicy
   :members:
