openstack.network.v2.sfc_service_graph
======================================

.. automodule:: openstack.network.v2.sfc_service_graph

The SfcServiceGraph Class
-------------------------

The ``SfcServiceGraph`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.sfc_service_graph.SfcServiceGraph
   :members:
