openstack.network.v2.network_segment_range
==========================================

.. automodule:: openstack.network.v2.network_segment_range

The NetworkSegmentRange Class
-----------------------------

The ``NetworkSegmentRange`` class inherits from :class:`~openstack.resource
.Resource`.

.. autoclass:: openstack.network.v2.network_segment_range.NetworkSegmentRange
   :members:
