openstack.network.v2.ndp_proxy
==============================

.. automodule:: openstack.network.v2.ndp_proxy

The NDPProxy Class
------------------

The ``NDPProxy`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.ndp_proxy.NDPProxy
   :members:
