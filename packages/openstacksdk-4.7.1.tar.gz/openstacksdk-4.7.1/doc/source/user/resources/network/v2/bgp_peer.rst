openstack.network.v2.bgp_peer
=============================

.. automodule:: openstack.network.v2.bgp_peer

The BgpPeer Class
-----------------

The ``BgpPeer`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.bgp_peer.BgpPeer
   :members:
