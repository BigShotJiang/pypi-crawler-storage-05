openstack.network.v2.qos_minimum_packet_rate_rule
=================================================

.. automodule:: openstack.network.v2.qos_minimum_packet_rate_rule

The QoSMinimumPacketRateRule Class
----------------------------------

The ``QoSMinimumPacketRateRule`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.qos_minimum_packet_rate_rule.QoSMinimumPacketRateRule
   :members:
