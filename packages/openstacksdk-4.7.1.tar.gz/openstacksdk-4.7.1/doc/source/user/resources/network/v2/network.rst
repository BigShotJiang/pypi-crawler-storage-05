openstack.network.v2.network
============================

.. automodule:: openstack.network.v2.network

The Network Class
-----------------

The ``Network`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.network.Network
   :members:
