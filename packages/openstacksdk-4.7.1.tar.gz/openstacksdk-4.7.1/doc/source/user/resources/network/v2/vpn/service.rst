openstack.network.v2.vpn_service
================================

.. automodule:: openstack.network.v2.vpn_service

The VpnService Class
--------------------

The ``VpnService`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.vpn_service.VpnService
   :members:
