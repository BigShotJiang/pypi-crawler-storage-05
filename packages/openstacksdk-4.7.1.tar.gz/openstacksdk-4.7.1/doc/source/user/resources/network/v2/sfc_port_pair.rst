openstack.network.v2.sfc_port_pair
==================================

.. automodule:: openstack.network.v2.sfc_port_pair

The SfcPortPair Class
---------------------

The ``SfcPortPair`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.sfc_port_pair.SfcPortPair
   :members:
