openstack.network.v2.qos_rule_type
==================================

.. automodule:: openstack.network.v2.qos_rule_type

The QoSRuleType Class
---------------------

The ``QoSRuleType`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.qos_rule_type.QoSRuleType
   :members:
