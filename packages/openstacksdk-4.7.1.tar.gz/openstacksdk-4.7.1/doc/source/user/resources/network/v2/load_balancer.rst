openstack.network.v2.load_balancer
==================================

.. automodule:: openstack.network.v2.load_balancer

The LoadBalancer Class
----------------------

The ``LoadBalancer`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.load_balancer.LoadBalancer
   :members:
