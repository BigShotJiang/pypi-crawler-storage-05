openstack.load_balancer.v2.quota
================================

.. automodule:: openstack.load_balancer.v2.quota

The Quota Class
---------------

The ``Quota`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.load_balancer.v2.quota.Quota
   :members:
