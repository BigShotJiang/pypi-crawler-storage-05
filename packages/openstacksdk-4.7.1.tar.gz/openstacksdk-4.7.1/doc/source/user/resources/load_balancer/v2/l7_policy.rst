openstack.load_balancer.v2.l7_policy
====================================

.. automodule:: openstack.load_balancer.v2.l7_policy

The L7Policy Class
------------------

The ``L7Policy`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.load_balancer.v2.l7_policy.L7Policy
   :members:
