openstack.load_balancer.v2.member
=================================

.. automodule:: openstack.load_balancer.v2.member

The Member Class
----------------

The ``Member`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.load_balancer.v2.member.Member
   :members:
