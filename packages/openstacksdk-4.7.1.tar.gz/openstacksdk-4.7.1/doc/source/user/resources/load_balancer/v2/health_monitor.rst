openstack.load_balancer.v2.health_monitor
=========================================

.. automodule:: openstack.load_balancer.v2.health_monitor

The HealthMonitor Class
-----------------------

The ``HealthMonitor`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.load_balancer.v2.health_monitor.HealthMonitor
   :members:
