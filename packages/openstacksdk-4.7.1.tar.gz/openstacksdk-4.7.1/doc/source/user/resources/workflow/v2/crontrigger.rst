openstack.workflow.v2.cron_trigger
==================================

.. automodule:: openstack.workflow.v2.cron_trigger

The CronTrigger Class
---------------------

The ``CronTrigger`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.workflow.v2.cron_trigger.CronTrigger
   :members:
