openstack.identity.v3.registered_limit
======================================

.. automodule:: openstack.identity.v3.registered_limit

The RegisteredLimit Class
-------------------------

The ``RegisteredLimit`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.registered_limit.RegisteredLimit
   :members:
