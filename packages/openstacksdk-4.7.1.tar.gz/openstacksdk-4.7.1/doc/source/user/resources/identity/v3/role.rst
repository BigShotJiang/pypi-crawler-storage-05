openstack.identity.v3.role
==========================

.. automodule:: openstack.identity.v3.role

The Role Class
--------------

The ``Role`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.role.Role
   :members:
