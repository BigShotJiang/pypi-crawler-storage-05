openstack.identity.v3.federation_protocol
=========================================

.. automodule:: openstack.identity.v3.federation_protocol

The FederationProtocol Class
----------------------------

The ``FederationProtocol`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.federation_protocol.FederationProtocol
   :members:
