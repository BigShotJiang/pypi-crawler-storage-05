openstack.identity.v3.role_system_group_assignment
==================================================

.. automodule:: openstack.identity.v3.role_system_group_assignment

The RoleSystemGroupAssignment Class
-----------------------------------

The ``RoleSystemGroupAssignment`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.role_system_group_assignment.RoleSystemGroupAssignment
   :members:
