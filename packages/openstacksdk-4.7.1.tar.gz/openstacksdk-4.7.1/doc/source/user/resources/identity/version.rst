openstack.identity.version
==========================

.. automodule:: openstack.identity.version

The Version Class
-----------------

The ``Version`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.version.Version
   :members:
