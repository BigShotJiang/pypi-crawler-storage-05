openstack.identity.v3.mapping
=============================

.. automodule:: openstack.identity.v3.mapping

The Mapping Class
-----------------

The ``Mapping`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.mapping.Mapping
   :members:
