openstack.identity.v3.role_system_user_assignment
=================================================

.. automodule:: openstack.identity.v3.role_system_user_assignment

The RoleSystemUserAssignment Class
----------------------------------

The ``RoleSystemUserAssignment`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.role_system_user_assignment.RoleSystemUserAssignment
   :members:
