openstack.identity.v3.role_domain_user_assignment
=================================================

.. automodule:: openstack.identity.v3.role_domain_user_assignment

The RoleDomainUserAssignment Class
----------------------------------

The ``RoleDomainUserAssignment`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.role_domain_user_assignment.RoleDomainUserAssignment
   :members:
