openstack.identity.v3.domain_config
===================================

.. automodule:: openstack.identity.v3.domain_config

The Domain Class
----------------

The ``DomainConfig`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.domain_config.DomainConfig
   :members:
