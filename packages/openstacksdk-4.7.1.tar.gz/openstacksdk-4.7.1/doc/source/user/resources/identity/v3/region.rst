openstack.identity.v3.region
============================

.. automodule:: openstack.identity.v3.region

The Region Class
----------------

The ``Region`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.region.Region
   :members:
