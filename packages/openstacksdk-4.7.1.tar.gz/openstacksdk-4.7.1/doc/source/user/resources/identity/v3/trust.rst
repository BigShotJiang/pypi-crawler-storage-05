openstack.identity.v3.trust
===========================

.. automodule:: openstack.identity.v3.trust

The Trust Class
---------------

The ``Trust`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.trust.Trust
   :members:
