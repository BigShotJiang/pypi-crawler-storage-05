Identity Resources
==================

Identity v2 Resources
---------------------
.. toctree::
   :maxdepth: 1
   :glob:

   v2/*

Identity v3 Resources
---------------------

.. toctree::
   :maxdepth: 1
   :glob:

   v3/*

Other Resources
---------------

.. toctree::
   :maxdepth: 1

   version
