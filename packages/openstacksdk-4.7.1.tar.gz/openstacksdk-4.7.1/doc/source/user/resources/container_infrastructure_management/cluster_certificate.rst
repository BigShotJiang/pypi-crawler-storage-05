openstack.container_infrastructure_management.v1.cluster_certificate
====================================================================

.. automodule:: openstack.container_infrastructure_management.v1.cluster_certificate

The Cluster Certificate Class
-----------------------------

The ``ClusterCertificate`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.container_infrastructure_management.v1.cluster_certificate.ClusterCertificate
   :members:
