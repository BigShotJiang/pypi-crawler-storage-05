openstack.container_infrastructure_management.v1.service
========================================================

.. automodule:: openstack.container_infrastructure_management.v1.service

The Service Class
-----------------

The ``Service`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.container_infrastructure_management.v1.service.Service
   :members:
