openstack.accelerator.v2.accelerator_request
============================================

.. automodule:: openstack.accelerator.v2.accelerator_request

The AcceleratorRequest Class
----------------------------

The ``AcceleratorRequest`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.accelerator.v2.accelerator_request.AcceleratorRequest
   :members:
