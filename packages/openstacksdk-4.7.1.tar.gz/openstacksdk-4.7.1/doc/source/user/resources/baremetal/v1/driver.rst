openstack.baremetal.v1.driver
=============================

.. automodule:: openstack.baremetal.v1.driver

The Driver Class
----------------

The ``Driver`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.driver.Driver
   :members:
