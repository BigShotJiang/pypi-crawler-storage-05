openstack.baremetal.v1.inspection_rules
=======================================

.. automodule:: openstack.baremetal.v1.inspection_rules

The InspectionRule Class
-------------------------

The ``InspectionRule`` class inherits
from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.inspection_rules.InspectionRule
   :members:
