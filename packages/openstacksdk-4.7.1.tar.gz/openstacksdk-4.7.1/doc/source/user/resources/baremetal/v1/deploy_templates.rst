openstack.baremetal.v1.deploy_templates
=======================================

.. automodule:: openstack.baremetal.v1.deploy_templates

The DeployTemplate Class
-------------------------

The ``DeployTemplate`` class inherits
from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.deploy_templates.DeployTemplate
   :members:
