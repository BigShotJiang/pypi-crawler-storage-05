openstack.baremetal.v1.conductor
================================

.. automodule:: openstack.baremetal.v1.conductor

The Conductor Class
-------------------

The ``Conductor`` class inherits
from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.conductor.Conductor
   :members:
