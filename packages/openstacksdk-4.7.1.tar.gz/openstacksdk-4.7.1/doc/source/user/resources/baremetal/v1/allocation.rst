openstack.baremetal.v1.Allocation
=================================

.. automodule:: openstack.baremetal.v1.allocation

The Allocation Class
--------------------

The ``Allocation`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.allocation.Allocation
   :members:
