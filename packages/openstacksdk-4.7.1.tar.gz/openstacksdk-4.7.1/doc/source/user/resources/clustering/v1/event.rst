openstack.clustering.v1.event
=============================

.. automodule:: openstack.clustering.v1.event

The Event Class
---------------

The ``Event`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.clustering.v1.event.Event
   :members:
