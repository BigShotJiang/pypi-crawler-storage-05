openstack.clustering.v1.policy_type
===================================

.. automodule:: openstack.clustering.v1.policy_type

The PolicyType Class
--------------------

The ``PolicyType`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.clustering.v1.policy_type.PolicyType
   :members:
