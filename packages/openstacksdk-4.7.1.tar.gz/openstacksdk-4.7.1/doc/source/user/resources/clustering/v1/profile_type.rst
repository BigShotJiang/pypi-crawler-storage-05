openstack.clustering.v1.profile_type
====================================

.. automodule:: openstack.clustering.v1.profile_type

The ProfileType Class
---------------------

The ``ProfileType`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.clustering.v1.profile_type.ProfileType
   :members:
