openstack.clustering.v1.build_info
==================================

.. automodule:: openstack.clustering.v1.build_info

The BuildInfo Class
-------------------

The ``BuildInfo`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.clustering.v1.build_info.BuildInfo
   :members:
