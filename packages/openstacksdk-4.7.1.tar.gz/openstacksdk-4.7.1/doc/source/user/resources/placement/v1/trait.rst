openstack.placement.v1.trait
============================

.. automodule:: openstack.placement.v1.trait

The Trait Class
---------------

The ``Trait`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.placement.v1.trait.Trait
   :members:
