Placement v1 Resources
======================

.. toctree::
   :maxdepth: 1

   v1/resource_class
   v1/resource_provider
   v1/resource_provider_inventory
   v1/trait
