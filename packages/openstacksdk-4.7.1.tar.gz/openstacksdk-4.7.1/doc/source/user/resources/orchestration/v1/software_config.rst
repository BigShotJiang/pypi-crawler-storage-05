openstack.orchestration.v1.software_config
==========================================

.. automodule:: openstack.orchestration.v1.software_config

The SoftwareConfig Class
------------------------

The ``SoftwareConfig`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.orchestration.v1.software_config.SoftwareConfig
   :members:
