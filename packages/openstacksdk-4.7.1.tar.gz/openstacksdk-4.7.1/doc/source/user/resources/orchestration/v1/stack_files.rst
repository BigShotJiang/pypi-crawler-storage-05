openstack.orchestration.v1.stack_files
======================================

.. automodule:: openstack.orchestration.v1.stack_files

The StackFiles Class
--------------------

The ``StackFiles`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.orchestration.v1.stack_files.StackFiles
   :members:
