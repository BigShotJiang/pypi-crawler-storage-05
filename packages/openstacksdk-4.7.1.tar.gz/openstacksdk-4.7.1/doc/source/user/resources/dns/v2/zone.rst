openstack.dns.v2.zone
==============================

.. automodule:: openstack.dns.v2.zone

The Zone Class
--------------

The ``DNS`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.dns.v2.zone.Zone
   :members:
