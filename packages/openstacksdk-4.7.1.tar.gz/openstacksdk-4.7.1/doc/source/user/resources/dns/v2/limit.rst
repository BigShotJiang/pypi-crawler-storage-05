openstack.dns.v2.limit
======================

.. automodule:: openstack.dns.v2.limit

The Limit Class
---------------

The ``Limit`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.dns.v2.limit.Limit
   :members:
