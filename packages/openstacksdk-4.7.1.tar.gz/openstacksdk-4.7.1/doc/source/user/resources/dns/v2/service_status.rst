openstack.dns.v2.service_status
===============================

.. automodule:: openstack.dns.v2.service_status

The ServiceStatus Class
-----------------------

The ``ServiceStatus`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.dns.v2.service_status.ServiceStatus
   :members:
