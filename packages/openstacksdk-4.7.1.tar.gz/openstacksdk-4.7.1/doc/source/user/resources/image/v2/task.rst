openstack.image.v2.task
=======================

.. automodule:: openstack.image.v2.task

The Task Class
--------------

The ``Task`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.image.v2.task.Task
   :members:
