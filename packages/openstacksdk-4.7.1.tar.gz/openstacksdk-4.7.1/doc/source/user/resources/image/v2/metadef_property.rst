openstack.image.v2.metadef_property
===================================

.. automodule:: openstack.image.v2.metadef_property

The MetadefProperty Class
-------------------------

The ``MetadefProperty`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.image.v2.metadef_property.MetadefProperty
   :members:
