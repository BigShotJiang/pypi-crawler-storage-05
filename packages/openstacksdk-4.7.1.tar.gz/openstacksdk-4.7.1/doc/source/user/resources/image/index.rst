Image Resources
===============

Image v1 Resources
------------------

.. toctree::
   :maxdepth: 1

   v1/image

Image v2 Resources
------------------

.. toctree::
   :maxdepth: 1

   v2/image
   v2/member
   v2/metadef_namespace
   v2/metadef_object
   v2/metadef_resource_type
   v2/metadef_property
   v2/metadef_schema
   v2/task
   v2/service_info
