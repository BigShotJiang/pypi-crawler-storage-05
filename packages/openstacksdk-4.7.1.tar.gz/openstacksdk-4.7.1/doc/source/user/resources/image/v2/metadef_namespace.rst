openstack.image.v2.metadef_namespace
=====================================

.. automodule:: openstack.image.v2.metadef_namespace

The MetadefNamespace Class
----------------------------

The ``MetadefNamespace`` class inherits
from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.image.v2.metadef_namespace.MetadefNamespace
   :members:
