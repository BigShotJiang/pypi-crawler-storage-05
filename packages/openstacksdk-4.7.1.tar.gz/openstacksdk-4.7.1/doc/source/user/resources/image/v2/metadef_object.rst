openstack.image.v2.metadef_object
==================================

.. automodule:: openstack.image.v2.metadef_object

The MetadefObject Class
------------------------

The ``MetadefObject`` class inherits
from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.image.v2.metadef_object.MetadefObject
   :members:
