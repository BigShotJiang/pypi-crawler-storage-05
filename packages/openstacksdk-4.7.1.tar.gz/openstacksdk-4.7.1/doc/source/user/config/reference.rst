=============
API Reference
=============

.. module:: openstack.config
   :synopsis: OpenStack client configuration

.. autoclass:: openstack.config.OpenStackConfig
   :members:
   :inherited-members:

.. autoclass:: openstack.config.cloud_region.CloudRegion
   :members:
   :inherited-members:
