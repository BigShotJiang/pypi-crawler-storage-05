========================================
Testing applications using OpenStack SDK
========================================

.. toctree::
   :maxdepth: 1

   fakes
