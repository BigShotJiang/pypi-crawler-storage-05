Fakes
=====

.. automodule:: openstack.test.fakes
   :members:
