Localização do módulo portal
