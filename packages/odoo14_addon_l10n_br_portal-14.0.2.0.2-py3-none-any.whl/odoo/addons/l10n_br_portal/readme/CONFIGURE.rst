To configure this module, you need to do nothing
