This module will be installed automatically by Odoo if the modules
**account_statement_import_file** and **account_reconcile_oca** are
installed.
