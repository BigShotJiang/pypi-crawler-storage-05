# hatch-lerchs-grossmann

[![PyPI - Version](https://img.shields.io/pypi/v/hatch-lerchs-grossmann.svg)](https://pypi.org/project/hatch-lerchs-grossmann)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/hatch-lerchs-grossmann.svg)](https://pypi.org/project/hatch-lerchs-grossmann)

---

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install py-lerchs-grossmann
```

## License

`hatch-lerchs-grossmann` is distributed under the terms of the [BSD-3-Clause](https://spdx.org/licenses/BSD-3-Clause.html) license.
