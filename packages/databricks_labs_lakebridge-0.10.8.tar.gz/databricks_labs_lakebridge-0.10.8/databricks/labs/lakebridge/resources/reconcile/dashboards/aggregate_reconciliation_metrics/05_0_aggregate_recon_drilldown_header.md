# Drill Down
### The Aggregates Reconcile details table contains all the sample records information of mismatches and missing entries.
