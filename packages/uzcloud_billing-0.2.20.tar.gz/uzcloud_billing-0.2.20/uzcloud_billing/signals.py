from django.dispatch import Signal

balance_filled_signal = Signal()
payment_completed_signal = Signal()
