# Changelog

## [0.2.2] - 2025-05-23

### Fixed

- Coverage badge

## [0.2.1] - 2025-05-23

### Added

- More tests

### Changed

- README.md

## [0.2.0] - 2025-05-13

### Added

- Changelog
- E2E tests
- Geolocation and User Agent type parameters to universal scraper

### Changed

- Descriptions for tools
- Descriptions for tool parameters
- Default values for tool parameters

### Removed

- WebUnblocker tool
- Parse parameter for universal scraper
