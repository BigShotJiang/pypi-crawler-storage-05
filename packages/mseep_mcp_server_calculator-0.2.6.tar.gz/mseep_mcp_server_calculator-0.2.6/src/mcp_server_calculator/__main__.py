from mcp_server_calculator import main

main()
