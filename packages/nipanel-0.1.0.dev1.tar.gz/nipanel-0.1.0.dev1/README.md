# Table of Contents

- [Table of Contents](#table-of-contents)
- [About](#about)
  - [Operating System Support](#operating-system-support)
  - [Python Version Support](#python-version-support)

# About

`nipanel` is a Python package that provides support for creating and controlling measurement and visualization panels.

NI created and supports this package.

## Operating System Support

`nipanel` supports Windows and Linux operating systems.

## Python Version Support

`nipanel` supports CPython 3.9+.
