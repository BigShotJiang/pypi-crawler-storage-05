from mcp.server.fastmcp import FastMCP

# Create the main MCP instance
mcp = FastMCP("tinyurl-mcp")
