========================================================================
 ``zope.component.persistentregistry``: Persistent Component Management
========================================================================

Persistent component management allows persistent management of
components.  From a usage point of view, there shouldn't be any new
behavior.

See :mod:`zope.component.persistentregistry` for API details.
