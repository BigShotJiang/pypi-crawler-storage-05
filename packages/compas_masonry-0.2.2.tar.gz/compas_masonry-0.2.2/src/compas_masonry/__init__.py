__version__ = "0.2.2"

__all_plugins__ = ["compas_masonry.scene"]
