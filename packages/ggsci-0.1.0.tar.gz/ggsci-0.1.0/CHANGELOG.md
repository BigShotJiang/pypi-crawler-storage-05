# Changelog

## py-ggsci 0.1.0

### New features

- Port four experimental color scales for plotnine from the R package ggsci.
  - Add palette functions for direct color access.
  - Support alpha transparency for all scales.
  - Reverse parameter for continuous scales.
  - British spelling aliases.
