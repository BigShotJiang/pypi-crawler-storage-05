"""YNAB Amazon Categorizer - Automatically categorize Amazon transactions in YNAB."""

__version__ = "1.0.0"
__author__ = "dizzlkheinz"
__description__ = (
    "Automatically categorize Amazon transactions in YNAB with rich item information"
)
