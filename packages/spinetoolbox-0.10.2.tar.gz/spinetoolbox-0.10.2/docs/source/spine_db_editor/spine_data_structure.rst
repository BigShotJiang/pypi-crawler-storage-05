********************
Spine data structure
********************

.. contents::
   :local:

Documentation for the Spine data structure can be found `here
<https://github.com/energy-modelling-workbench/spine-data-model#spine-data-model>`_.
