.. _Whats new:

***********
What's New?
***********

Here's the Changelog for Spine Toolbox.

.. include:: ../../CHANGELOG.md
   :literal:
