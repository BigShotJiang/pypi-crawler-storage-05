.. include:: ../README.rst

.. toctree::
   :maxdepth: 1

   interfaces


.. toctree::
   :maxdepth: 2

   changelog

Development
===========

zope.browser is hosted at GitHub:

    https://github.com/zopefoundation/zope.browser/



Project URLs
============

* https://pypi.python.org/pypi/zope.browser       (PyPI entry and downloads)


====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
