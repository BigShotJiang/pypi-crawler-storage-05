"""SDWire CLI package initialization."""

from sdwire import main

__all__ = ["main"]
