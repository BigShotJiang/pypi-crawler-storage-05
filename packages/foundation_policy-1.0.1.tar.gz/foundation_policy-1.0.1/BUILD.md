```
git submodule update --init -- blob
./build.sh
```