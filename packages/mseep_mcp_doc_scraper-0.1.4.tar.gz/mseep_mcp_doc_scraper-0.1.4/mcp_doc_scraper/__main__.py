from mcp_doc_scraper import serve
import asyncio

asyncio.run(serve())
