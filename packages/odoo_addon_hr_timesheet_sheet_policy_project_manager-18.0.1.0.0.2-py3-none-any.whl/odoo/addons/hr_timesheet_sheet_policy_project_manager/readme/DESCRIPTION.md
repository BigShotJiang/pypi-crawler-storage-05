This module allows setting Department Manager as Reviewer on Timesheet
Sheets.
