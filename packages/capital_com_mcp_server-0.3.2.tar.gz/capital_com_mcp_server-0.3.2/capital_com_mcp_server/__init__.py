"""Capital.com MCP Server package."""
