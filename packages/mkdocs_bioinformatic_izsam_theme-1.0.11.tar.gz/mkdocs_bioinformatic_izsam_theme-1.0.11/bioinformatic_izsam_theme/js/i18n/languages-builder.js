wiki.languages = {};
/**
 * English
 * 
 */
//@include ./en.js
/**
 * Italiano
 * 
 */
//@include ./it.js