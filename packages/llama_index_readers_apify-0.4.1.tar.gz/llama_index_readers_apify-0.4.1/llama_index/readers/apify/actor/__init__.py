"""Init file."""

from llama_index.readers.apify.actor.base import ApifyActor

__all__ = ["ApifyActor"]
