"""Init file."""

from llama_index.readers.apify.dataset.base import ApifyDataset

__all__ = ["ApifyDataset"]
