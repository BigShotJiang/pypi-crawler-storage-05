#!/usr/bin/env python3
from .osaca import main

main()
