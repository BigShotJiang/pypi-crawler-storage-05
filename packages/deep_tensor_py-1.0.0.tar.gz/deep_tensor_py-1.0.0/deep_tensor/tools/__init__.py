from .f_divergences import compute_f_divergence
from .verification import check_finite