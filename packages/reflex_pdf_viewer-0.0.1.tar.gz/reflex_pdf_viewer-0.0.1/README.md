# pdf-viewer

A Reflex custom component pdf-viewer.

## Installation

```bash
pip install reflex-pdf-viewer
```
