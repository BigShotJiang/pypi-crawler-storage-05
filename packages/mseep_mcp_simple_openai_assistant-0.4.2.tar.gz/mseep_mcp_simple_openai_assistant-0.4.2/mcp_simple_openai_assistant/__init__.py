"""A simple MCP server for interacting with OpenAI assistants."""

# This file can be empty. Its presence indicates that this directory is a Python package.