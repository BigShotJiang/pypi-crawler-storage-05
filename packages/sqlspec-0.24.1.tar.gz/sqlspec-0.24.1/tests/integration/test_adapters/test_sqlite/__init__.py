"""Integration tests for SQLite adapter."""
