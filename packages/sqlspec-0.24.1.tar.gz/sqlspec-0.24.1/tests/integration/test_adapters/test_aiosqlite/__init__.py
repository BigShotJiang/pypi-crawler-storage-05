"""AIOSQLite integration tests."""
