"""Integration tests for SQLSpec loader module.

Tests for SQL file loading integration with real file system,
storage backends, and cache systems.
"""
