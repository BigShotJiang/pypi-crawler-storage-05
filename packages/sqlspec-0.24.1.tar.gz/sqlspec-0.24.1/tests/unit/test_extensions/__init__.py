"""Extension unit tests."""
