"""Litestar extension unit tests."""
