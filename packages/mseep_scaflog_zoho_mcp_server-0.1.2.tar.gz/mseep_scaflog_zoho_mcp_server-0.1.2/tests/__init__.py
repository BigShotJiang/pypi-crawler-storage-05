# tests/__init__.py

# import pytest

# @pytest.fixture(scope="module")
# def mock_server():
#     return ZohoCreatorServer()
