# ZenquotesApp MCP Server

An MCP Server for the ZenquotesApp API.

## 🛠️ Tool List

This is automatically generated from OpenAPI schema for the ZenquotesApp API.


| Tool | Description |
|------|-------------|
| `get_quote` | Fetches a random inspirational quote from the Zen Quotes API. |
