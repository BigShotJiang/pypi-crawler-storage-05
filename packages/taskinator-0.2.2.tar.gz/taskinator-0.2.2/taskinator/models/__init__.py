"""
Data models for Taskinator.
"""
