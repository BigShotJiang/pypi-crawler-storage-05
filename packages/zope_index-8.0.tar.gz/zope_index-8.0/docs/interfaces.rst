============
 Interfaces
============

.. automodule:: zope.index.interfaces
