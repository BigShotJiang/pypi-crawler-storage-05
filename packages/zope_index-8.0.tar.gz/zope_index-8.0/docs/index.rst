.. include:: ../README.rst

Contents:

.. toctree::
   :maxdepth: 2

   interfaces
   field
   keyword
   topic
   text
   changelog

====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
