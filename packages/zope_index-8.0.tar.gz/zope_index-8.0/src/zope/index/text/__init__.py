from zope.index.text.textindex import TextIndex  # noqa: F401 unused
