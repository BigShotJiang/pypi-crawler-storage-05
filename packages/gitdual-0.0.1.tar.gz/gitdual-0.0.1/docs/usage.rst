=====
Usage
=====

To use gitdual in a project::

    import gitdual
