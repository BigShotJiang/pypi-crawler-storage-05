=======
History
=======

0.0.1 (2025-09-10)
------------------

* First release on PyPI.
