# dagster-k8s

The docs for `dagster-k8s` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-k8s).
