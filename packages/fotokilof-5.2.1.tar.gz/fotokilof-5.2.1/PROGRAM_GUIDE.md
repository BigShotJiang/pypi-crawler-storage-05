# FotoKilof guide

## How to add new conversion

### ini_read.py
- add function for reading config file
  
### ini_save.py
- add function for saving config file

### convert_wand.py
- add function for making conversion

### Fotokilof.py
- add call of conversion into apply_all_button(),
- add function convert_XYZ_button() - call conversion,
- add call into ini_read_wraper() - to read config file,
- add into ini_save() - to save parameters into config file,
- add into tools_set*() - to hide or show converter,
- add variable img_XYZ_on into global variables,
- add coverter into frame_tools_set - for tools selection,
- add frame with tool into First column,
- add toolTips for every widgets.
