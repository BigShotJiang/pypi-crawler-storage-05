* `Engenere <https://engenere.one>`_:

  * Felipe Motter Pereira <felipe@engenere.one>
  * Antônio S. Pereira Neto <neto@engenere.one>

* `Akretion <https://akretion.com/pt-BR>`_:

  * Magno Barcelo da Costa <magno.costa@akretion.com.br>
