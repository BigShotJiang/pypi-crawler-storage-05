# Aplicación de Ventas

Este paquete proporciona funcionalidades para gestionar ventas, incluyendo el cálculo de precios, impuestos y descuentos.

## Instalación

Para instalar el paquete, usa:

```bash
pip install .
