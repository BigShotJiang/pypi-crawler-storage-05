from .detection_server import DetectionServer
from .base_task import BaseTask