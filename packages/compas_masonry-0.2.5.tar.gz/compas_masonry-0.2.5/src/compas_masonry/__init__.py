__version__ = "0.2.5"

__all_plugins__ = ["compas_masonry.scene"]
