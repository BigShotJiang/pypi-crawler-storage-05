These files are auto-generated. **Do not edit**!

Use `make generate` to update the schema (e.g. support new/modified queries & mutations).