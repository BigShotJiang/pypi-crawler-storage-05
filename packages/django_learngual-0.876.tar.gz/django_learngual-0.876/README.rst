====================================
Learngual Django
====================================

.. image:: https://img.shields.io/pypi/v/your-package.svg
    :target: https://pypi.python.org/pypi/your-package

.. image:: https://img.shields.io/travis/your-username/your-package.svg
    :target: https://travis-ci.org/your-username/your-package

Overview
--------

Learngual is a Python package that provides helper functions for learngual.

Features
--------

.. - [Feature 1]
.. - [Feature 2]
.. - [Feature 3]
.. - ...

Installation
------------

You can install Your Django Package Name using pip:

.. code-block:: bash

    $ pip install django-learngual

Usage
-----

.. [Provide examples and code snippets demonstrating how to use your package.]


License
-------

Django Learngual  is licensed under the MIT.

Contact
-------

If you have any questions, suggestions, or feedback, please feel free to contact us at support@learngual.com.

