
class ToolkitError(Exception):
    """Generic errors."""
    pass
