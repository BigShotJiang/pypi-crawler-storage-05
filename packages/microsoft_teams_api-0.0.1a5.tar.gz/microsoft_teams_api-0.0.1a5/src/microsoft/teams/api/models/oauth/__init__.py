"""
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the MIT License.
"""

from .oauth_card import OAuthCard

__all__ = ["OAuthCard"]
