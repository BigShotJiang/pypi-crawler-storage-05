"""
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the MIT License.
"""

from .o365_connector_card_action_query import O365ConnectorCardActionQuery

__all__ = ["O365ConnectorCardActionQuery"]
