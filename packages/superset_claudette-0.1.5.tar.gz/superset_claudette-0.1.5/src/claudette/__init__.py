"""Claudette - Superset multi-environment workflow manager."""

__version__ = "0.1.5"
