"""
SwiftLens MCP Server Package
Provides semantic Swift code understanding tools for AI models
"""

from ._version import __version__

__all__ = ["__version__"]
