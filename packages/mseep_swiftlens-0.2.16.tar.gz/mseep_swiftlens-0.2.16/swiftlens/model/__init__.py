"""Data models package for Swift Context MCP Server."""
