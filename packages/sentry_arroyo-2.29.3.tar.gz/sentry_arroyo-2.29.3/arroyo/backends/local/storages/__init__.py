from arroyo.backends.local.storages.abstract import MessageStorage

__all__ = [
    "MessageStorage",
]
