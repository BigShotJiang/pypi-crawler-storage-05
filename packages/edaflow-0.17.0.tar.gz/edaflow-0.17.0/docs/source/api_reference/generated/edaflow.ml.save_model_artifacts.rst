﻿edaflow.ml.save\_model\_artifacts
=================================

.. currentmodule:: edaflow.ml

.. autofunction:: save_model_artifacts