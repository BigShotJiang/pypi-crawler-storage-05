﻿edaflow.visualize\_histograms
=============================

.. currentmodule:: edaflow

.. autofunction:: visualize_histograms