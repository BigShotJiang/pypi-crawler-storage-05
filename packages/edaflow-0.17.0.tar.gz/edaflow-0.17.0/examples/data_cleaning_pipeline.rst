.. Example: Data Cleaning Pipeline
.. See docs/source/examples/data_cleaning_pipeline.rst for full content
