.. Example: Basic EDA Workflow
.. See docs/source/examples/basic_eda_workflow.rst for full content
