.. Example: Advanced Visualization
.. See docs/source/examples/advanced_visualization.rst for full content
