# SQLAI

**SQLAI** is a command-line tool that uses generative AI (Google Gemini, OpenAI, etc.) to help you interact with SQL queries. It can explain, validate, and improve SQL queries, leveraging the power of modern AI models.

---

## Features

- **Explain** Explains in plain English what SQL query does.
- **Validate** check for general correctness.
- **Improve**: Suggest improvements to your SQL queries.
- **Configure**: Choose your AI provider, API key, model and SQL dialect.
- **Simple CLI**: Easy-to-use command-line interface.

---

## Local Development

To set up your development environment and use the CLI tool while working on the project:

### 1. Clone the repository

```bash
git clone https://github.com/alexanderbrueck/sqlai.git
cd sqlai
```

### 2. Install in editable mode

From the project root, run:

```bash
pip install -e .
```

- The `-e .` flag installs your package in "editable" mode, so changes to the code are immediately reflected without reinstalling.
- All required dependencies will be installed automatically, as they are specified in `setup.py` (`install_requires`).  
- **You do not need to run `pip install -r requirements.txt` separately.**

---

## Quick Start

1. **Configure your AI provider and credentials:**

   ```bash
   sqlai set_config
   ```

   You’ll be prompted for:
   - AI provider (e.g., `gemini`, `openai`)
   - API key
   - Model name (e.g., `gemini-1.5-flash`)

2. **Analyze a SQL file:**

   ```bash
   sqlai run path/to/your_query.sql
   ```

   You will be shown several actions (explain, validate, ...), and you can select one interactively.

3. **Show your current configuration:**

   ```bash
   sqlai show_config
   ```

---

## Example Usage

```bash
sqlai set_config
sqlai run my_query.sql
```

---

## Requirements

- Python 3.7+
- [google-generativeai](https://pypi.org/project/google-generativeai/)
- [tomli](https://pypi.org/project/tomli/)
- [tomli-w](https://pypi.org/project/tomli-w/)

Install all dependencies via:

```bash
pip install -r requirements.txt
```

---

## Publishing to PyPI

To publish `sqlai` to [PyPI](https://pypi.org/):

1. **Update your version number** in `setup.py` or `pyproject.toml`. Each upload requires a unique version.
2. **Build the package:**

   ```bash
   python -m pip install --upgrade build
   python -m build
   ```

   This will create a `dist/` directory with `.tar.gz` and `.whl` files.

3. **Get a PyPI API token:**
   - Go to [PyPI Account > API tokens](https://pypi.org/manage/account/#api-tokens)
   - Create a new token (for your project or your whole account) and copy it.

4. **Upload using Twine:**

   Install twine if you haven’t:

   ```bash
   python -m pip install --upgrade twine
   ```

   Then upload:

   ```bash
   python -m twine upload dist/*
   ```

   When prompted, paste your API token (it starts with `pypi-...`).

   *Tip: To avoid pasting your token every time, you can save it in your `~/.pypirc`.*

5. **Verify upload:**

   Try installing from PyPI:

   ```bash
   pip install sqlai
   ```

### (Optional) Test on TestPyPI

Before publishing to the main PyPI, you can test your package on [TestPyPI](https://test.pypi.org/):

```bash
python -m twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ sqlai
```

---

## License

MIT License. See [LICENSE](LICENSE) for details.

---

## Notes

- Only `.sql` files are supported.
- Your credentials are stored in `~/.sqlai/config.toml`.

---

## Contributing

Pull requests and feedback are welcome! Please open an issue or PR to discuss changes or suggestions.