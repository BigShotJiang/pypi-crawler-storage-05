"""ChemShell AiiDA plugin."""

from importlib.metadata import version

__version__ = version("aiida-chemshell")
