"""A module for Bear Utils, providing various utilities and tools."""
