================
SLEPc for Python
================

.. include:: abstract.txt

.. include:: toctree.txt

.. include:: links.txt
