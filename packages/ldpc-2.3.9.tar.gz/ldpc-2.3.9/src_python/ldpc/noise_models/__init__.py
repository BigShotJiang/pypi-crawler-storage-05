from ldpc.noise_models.bsc import generate_bsc_error
