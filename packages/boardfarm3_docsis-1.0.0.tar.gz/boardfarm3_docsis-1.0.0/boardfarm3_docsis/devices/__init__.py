"""Boardfarm DOCSIS devices package."""
