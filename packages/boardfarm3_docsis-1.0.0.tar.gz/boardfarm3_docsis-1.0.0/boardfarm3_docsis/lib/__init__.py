"""Boardfarm DOCSIS library package."""
