"""Boardfarm DOCSIS templates package."""
