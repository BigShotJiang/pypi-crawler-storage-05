"""An add-on to boardfarm that contains DOCSIS specific libraries."""

__version__ = "1.0.0"
