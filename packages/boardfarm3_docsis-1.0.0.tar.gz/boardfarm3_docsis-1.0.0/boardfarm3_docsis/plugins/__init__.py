"""Boardfarm plugins for DOCSIS devices."""
