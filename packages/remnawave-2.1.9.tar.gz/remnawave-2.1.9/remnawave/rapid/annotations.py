from rapid_api_client import Body


class AttributeBody(Body):
    pass
