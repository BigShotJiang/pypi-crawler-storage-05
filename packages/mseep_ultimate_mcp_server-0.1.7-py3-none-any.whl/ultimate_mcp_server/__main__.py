"""Main entry point for Ultimate MCP Server CLI."""
from ultimate_mcp_server.cli import cli

if __name__ == "__main__":
    cli() 