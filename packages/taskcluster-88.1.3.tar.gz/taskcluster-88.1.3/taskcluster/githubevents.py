# stub to support existing import paths
from .generated.githubevents import *  # NOQA
