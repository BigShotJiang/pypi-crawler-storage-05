#!/usr/bin/env python3

from . service import run

run()