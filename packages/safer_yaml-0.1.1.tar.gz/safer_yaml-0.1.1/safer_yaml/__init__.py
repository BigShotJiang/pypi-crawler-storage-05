from .safer_yaml import load, loads, dump, dumps
__all__ = ("load", "loads", "dump", "dumps")
