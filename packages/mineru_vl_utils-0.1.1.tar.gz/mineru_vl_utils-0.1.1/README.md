# mineru-vl-utils

## Usage

### Installation

```bash
pip install mineru-vl-utils
```

### Code Demo

```python
from mineru_vl_utils import MinerUClient

```