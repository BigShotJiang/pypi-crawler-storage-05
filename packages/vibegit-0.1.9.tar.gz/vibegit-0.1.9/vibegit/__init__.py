"""VibeGit - Your AI-Powered Git Housekeeper."""
