from species.core.species_init import SpeciesInit
from ._version import __version__

__author__ = "Tomas Stolker"
__license__ = "MIT"
__maintainer__ = "Tomas Stolker"
__email__ = "stolker@strw.leidenuniv.nl"
