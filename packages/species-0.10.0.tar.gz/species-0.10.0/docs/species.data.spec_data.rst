species.data.spec\_data package
===============================

Submodules
----------

species.data.spec\_data.add\_spec\_data module
----------------------------------------------

.. automodule:: species.data.spec_data.add_spec_data
   :members:
   :undoc-members:
   :show-inheritance:

species.data.spec\_data.spec\_allers2013 module
-----------------------------------------------

.. automodule:: species.data.spec_data.spec_allers2013
   :members:
   :undoc-members:
   :show-inheritance:

species.data.spec\_data.spec\_bonnefoy2014 module
-------------------------------------------------

.. automodule:: species.data.spec_data.spec_bonnefoy2014
   :members:
   :undoc-members:
   :show-inheritance:

species.data.spec\_data.spec\_irtf module
-----------------------------------------

.. automodule:: species.data.spec_data.spec_irtf
   :members:
   :undoc-members:
   :show-inheritance:

species.data.spec\_data.spec\_kesseli2017 module
------------------------------------------------

.. automodule:: species.data.spec_data.spec_kesseli2017
   :members:
   :undoc-members:
   :show-inheritance:

species.data.spec\_data.spec\_spex module
-----------------------------------------

.. automodule:: species.data.spec_data.spec_spex
   :members:
   :undoc-members:
   :show-inheritance:

species.data.spec\_data.spec\_vega module
-----------------------------------------

.. automodule:: species.data.spec_data.spec_vega
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: species.data.spec_data
   :members:
   :undoc-members:
   :show-inheritance:
