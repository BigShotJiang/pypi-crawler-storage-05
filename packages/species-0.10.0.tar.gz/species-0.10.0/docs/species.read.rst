species.read package
====================

Submodules
----------

species.read.read\_calibration module
-------------------------------------

.. automodule:: species.read.read_calibration
   :members:
   :undoc-members:
   :show-inheritance:

species.read.read\_color module
-------------------------------

.. automodule:: species.read.read_color
   :members:
   :undoc-members:
   :show-inheritance:

species.read.read\_filter module
--------------------------------

.. automodule:: species.read.read_filter
   :members:
   :undoc-members:
   :show-inheritance:

species.read.read\_isochrone module
-----------------------------------

.. automodule:: species.read.read_isochrone
   :members:
   :undoc-members:
   :show-inheritance:

species.read.read\_model module
-------------------------------

.. automodule:: species.read.read_model
   :members:
   :undoc-members:
   :show-inheritance:

species.read.read\_object module
--------------------------------

.. automodule:: species.read.read_object
   :members:
   :undoc-members:
   :show-inheritance:

species.read.read\_planck module
--------------------------------

.. automodule:: species.read.read_planck
   :members:
   :undoc-members:
   :show-inheritance:

species.read.read\_radtrans module
----------------------------------

.. automodule:: species.read.read_radtrans
   :members:
   :undoc-members:
   :show-inheritance:

species.read.read\_spectrum module
----------------------------------

.. automodule:: species.read.read_spectrum
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: species.read
   :members:
   :undoc-members:
   :show-inheritance:
