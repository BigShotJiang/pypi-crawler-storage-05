species.data.isochrone\_data package
====================================

Submodules
----------

species.data.isochrone\_data.add\_isochrone module
--------------------------------------------------

.. automodule:: species.data.isochrone_data.add_isochrone
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_ames module
---------------------------------------------

.. automodule:: species.data.isochrone_data.iso_ames
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_atmo module
---------------------------------------------

.. automodule:: species.data.isochrone_data.iso_atmo
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_baraffe2015 module
----------------------------------------------------

.. automodule:: species.data.isochrone_data.iso_baraffe2015
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_btsettl module
------------------------------------------------

.. automodule:: species.data.isochrone_data.iso_btsettl
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_chabrier2023 module
-----------------------------------------------------

.. automodule:: species.data.isochrone_data.iso_chabrier2023
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_linder2019 module
---------------------------------------------------

.. automodule:: species.data.isochrone_data.iso_linder2019
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_manual module
-----------------------------------------------

.. automodule:: species.data.isochrone_data.iso_manual
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_marleau module
------------------------------------------------

.. automodule:: species.data.isochrone_data.iso_marleau
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_nextgen module
------------------------------------------------

.. automodule:: species.data.isochrone_data.iso_nextgen
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_parsec module
-----------------------------------------------

.. automodule:: species.data.isochrone_data.iso_parsec
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_saumon2008 module
---------------------------------------------------

.. automodule:: species.data.isochrone_data.iso_saumon2008
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_sonora\_bobcat module
-------------------------------------------------------

.. automodule:: species.data.isochrone_data.iso_sonora_bobcat
   :members:
   :undoc-members:
   :show-inheritance:

species.data.isochrone\_data.iso\_sonora\_diamondback module
------------------------------------------------------------

.. automodule:: species.data.isochrone_data.iso_sonora_diamondback
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: species.data.isochrone_data
   :members:
   :undoc-members:
   :show-inheritance:
