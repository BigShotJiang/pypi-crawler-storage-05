species.data package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   species.data.companion_data
   species.data.filter_data
   species.data.isochrone_data
   species.data.misc_data
   species.data.model_data
   species.data.phot_data
   species.data.spec_data

Submodules
----------

species.data.database module
----------------------------

.. automodule:: species.data.database
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: species.data
   :members:
   :undoc-members:
   :show-inheritance:
