species.data.companion\_data package
====================================

Submodules
----------

species.data.companion\_data.companion\_spectra module
------------------------------------------------------

.. automodule:: species.data.companion_data.companion_spectra
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: species.data.companion_data
   :members:
   :undoc-members:
   :show-inheritance:
