.. _contributing:

Contributing
============

Contributions are welcome so please consider `forking <https://help.github.com/en/articles/fork-a-repo>`_ the repository and creating a `pull request <https://github.com/tomasstolker/species/pulls>`_. Bug reports and feature requests can be provided by creating an `issue <https://github.com/tomasstolker/species/issues>`_ on the Github page.
