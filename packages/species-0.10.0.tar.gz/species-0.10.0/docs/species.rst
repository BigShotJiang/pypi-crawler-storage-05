species package
===============

Subpackages
-----------

.. toctree::

    species.core
    species.data
    species.fit
    species.phot
    species.plot
    species.read
    species.util

Module contents
---------------

.. automodule:: species
    :members:
    :undoc-members:
    :show-inheritance:
