species.fit package
===================

Submodules
----------

species.fit.compare\_spectra module
-----------------------------------

.. automodule:: species.fit.compare_spectra
   :members:
   :undoc-members:
   :show-inheritance:

species.fit.emission\_line module
---------------------------------

.. automodule:: species.fit.emission_line
   :members:
   :undoc-members:
   :show-inheritance:

species.fit.fit\_evolution module
---------------------------------

.. automodule:: species.fit.fit_evolution
   :members:
   :undoc-members:
   :show-inheritance:

species.fit.fit\_model module
-----------------------------

.. automodule:: species.fit.fit_model
   :members:
   :undoc-members:
   :show-inheritance:

species.fit.fit\_spectrum module
--------------------------------

.. automodule:: species.fit.fit_spectrum
   :members:
   :undoc-members:
   :show-inheritance:

species.fit.retrieval module
----------------------------

.. automodule:: species.fit.retrieval
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: species.fit
   :members:
   :undoc-members:
   :show-inheritance:
