species.data.phot\_data package
===============================

Submodules
----------

species.data.phot\_data.phot\_jwst\_ydwarfs module
--------------------------------------------------

.. automodule:: species.data.phot_data.phot_jwst_ydwarfs
   :members:
   :undoc-members:
   :show-inheritance:

species.data.phot\_data.phot\_leggett module
--------------------------------------------

.. automodule:: species.data.phot_data.phot_leggett
   :members:
   :undoc-members:
   :show-inheritance:

species.data.phot\_data.phot\_vlm\_plx module
---------------------------------------------

.. automodule:: species.data.phot_data.phot_vlm_plx
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: species.data.phot_data
   :members:
   :undoc-members:
   :show-inheritance:
