species.data.misc\_data package
===============================

Submodules
----------

species.data.misc\_data.accretion\_data module
----------------------------------------------

.. automodule:: species.data.misc_data.accretion_data
   :members:
   :undoc-members:
   :show-inheritance:

species.data.misc\_data.dust\_data module
-----------------------------------------

.. automodule:: species.data.misc_data.dust_data
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: species.data.misc_data
   :members:
   :undoc-members:
   :show-inheritance:
