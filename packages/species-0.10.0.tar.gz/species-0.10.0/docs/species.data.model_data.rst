species.data.model\_data package
================================

Submodules
----------

species.data.model\_data.custom\_model module
---------------------------------------------

.. automodule:: species.data.model_data.custom_model
   :members:
   :undoc-members:
   :show-inheritance:

species.data.model\_data.model\_spectra module
----------------------------------------------

.. automodule:: species.data.model_data.model_spectra
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: species.data.model_data
   :members:
   :undoc-members:
   :show-inheritance:
