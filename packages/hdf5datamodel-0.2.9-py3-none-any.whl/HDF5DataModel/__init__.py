from HDF5DataModel.version import __version__
