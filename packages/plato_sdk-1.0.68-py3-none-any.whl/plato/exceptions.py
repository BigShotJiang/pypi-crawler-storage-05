class PlatoClientError(Exception):
    """Base exception for errors raised by the Plato client."""
    pass

