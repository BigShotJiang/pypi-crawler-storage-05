"""Core CLI application setup and entry point."""
