"""Version information for context-engine-mcp."""

__version__ = "2.1.0"
