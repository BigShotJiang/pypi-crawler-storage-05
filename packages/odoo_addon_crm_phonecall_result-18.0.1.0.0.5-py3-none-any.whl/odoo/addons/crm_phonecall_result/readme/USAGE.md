To use this module, you need to:

1. In CRM > Configuration > Calls, you can define new phone call results.
