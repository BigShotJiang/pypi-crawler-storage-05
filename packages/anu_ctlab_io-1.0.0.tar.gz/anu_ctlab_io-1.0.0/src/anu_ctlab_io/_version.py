import importlib.metadata

version: str = importlib.metadata.version("anu_ctlab_io")
