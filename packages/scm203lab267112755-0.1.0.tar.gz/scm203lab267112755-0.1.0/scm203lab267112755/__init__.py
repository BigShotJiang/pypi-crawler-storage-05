from .lab2mod167112755 import secant, false_position
from .lab2mod267112755 import runge_kutta2, runge_kutta3

__all__ = ["secant","false_position","runge_kutta2","runge_kutta3"]