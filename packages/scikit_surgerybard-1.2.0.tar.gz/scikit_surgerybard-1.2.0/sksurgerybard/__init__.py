# coding=utf-8
"""scikit-surgerybard"""

from . import _version
__version__ = _version.get_versions()['version']
