class AnilibriaException(Exception):
    pass

class AnilibriaValidationException(AnilibriaException):
    pass