User conducted the test manually using playwright codegen. Resulting code:

```python
{current_recording_code}
```