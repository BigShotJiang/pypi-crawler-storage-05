"""OpenAI connector package."""

from .connector import OpenAIConnector

__all__ = ["OpenAIConnector"]
