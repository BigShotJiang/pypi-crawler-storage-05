# __init__.py
__version__ = "0.1.0"

from .core import hello as hello
from .payroll import Payroll as Payroll
