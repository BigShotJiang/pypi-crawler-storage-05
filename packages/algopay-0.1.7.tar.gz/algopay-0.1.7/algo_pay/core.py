# algopay/core.py


def hello():
    return "Welcome to algopay!"
