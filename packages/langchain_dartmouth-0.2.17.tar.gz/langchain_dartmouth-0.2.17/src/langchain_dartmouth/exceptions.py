class ModelNotFoundError(Exception):
    pass


class InvalidKeyError(KeyError):
    pass
