from ._version import __version__

__version__ = __version__
