import sys

import cartography.cli

if __name__ == "__main__":
    sys.exit(cartography.cli.main())
