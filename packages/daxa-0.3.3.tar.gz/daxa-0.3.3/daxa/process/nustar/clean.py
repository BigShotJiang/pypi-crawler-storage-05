#  This code is a part of the Democratising Archival X-ray Astronomy (DAXA) module.
#  Last modified by David J Turner (turne540@msu.edu) 08/11/2024, 15:40. Copyright (c) The Contributors

# TODO HERE WILL GO THE LEVEL 2 (I THINK?) CLEANING FUNCTION, TO REMOVE ALL THE BAD EVENTS FROM THE VARIOUS
#  OBSERVING MODES (02, 03, etc.) THAT NUSTAR HAS - ALSO DO SOLAR FLARE CLEANING HERE