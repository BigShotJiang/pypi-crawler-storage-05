from .framed import FramedImage
from .framed import Volume
from .framed import Slice
from .framed import cast_image
