==
IO
==

.. currentmodule:: surfa

.. autosummary::
    :toctree: api/

    load_volume
    load_slice
    load_overlay
    load_mesh
    load_affine
    load_label_lookup
    io.fsio.load_surface_label
    io.check_file_readability
