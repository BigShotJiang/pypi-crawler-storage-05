=============
Visualization
=============

.. currentmodule:: surfa

FreeView Wrapping
~~~~~~~~~~~~~~~~~
.. autosummary::
    :toctree: api/

    vis.Freeview
    vis.freeview.FreeviewAnnot
    vis.freeview.FreeviewOverlay
    vis.fv
