===========
Image Array
===========

.. currentmodule:: surfa

.. autosummary::
    :toctree: api/

    Volume
    Slice
