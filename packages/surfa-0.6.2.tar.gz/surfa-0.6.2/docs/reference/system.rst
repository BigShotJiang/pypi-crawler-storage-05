================
System Utilities
================

.. currentmodule:: surfa

.. autosummary::
    :toctree: api/

    system.run
    system.collect_output
    system.readlines
    system.fatal
    system.vmpeak
    system.hostname
