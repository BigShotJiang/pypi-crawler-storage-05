..
    Copyright (C) 2020, 2023 Graz University of Technology.

    invenio-records-lom is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

License
=======

.. include:: ../LICENSE

.. note::
    In applying this license, Tu Graz does not waive the privileges and immunities
    granted to it by virtue of its status as an Intergovernmental Organization or
    submit itself to any jurisdiction.
