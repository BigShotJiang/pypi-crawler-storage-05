declare namespace _default {
    const ANIMATING: number;
    const INTERACTING: number;
}
export default _default;
//# sourceMappingURL=ViewHint.d.ts.map