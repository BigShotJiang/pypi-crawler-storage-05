from django.apps import AppConfig


class TaxonProfilesConfig(AppConfig):
    name = 'app_kit.features.taxon_profiles'
