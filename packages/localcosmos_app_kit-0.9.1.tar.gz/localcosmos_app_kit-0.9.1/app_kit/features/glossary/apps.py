from django.apps import AppConfig


class GlossaryConfig(AppConfig):
    name = 'app_kit.features.glossary'
