from django.apps import AppConfig


class NatureGuidesConfig(AppConfig):
    name = 'app_kit.features.nature_guides'
