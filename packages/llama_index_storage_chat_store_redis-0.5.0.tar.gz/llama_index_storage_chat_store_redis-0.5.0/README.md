# LlamaIndex Chat_Store Integration: Redis Chat Store
