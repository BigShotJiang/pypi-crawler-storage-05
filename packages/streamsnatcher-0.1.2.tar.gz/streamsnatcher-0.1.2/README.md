[![Chat-GPT-Image-Sep-13-2025-05-31-00-AM.png](https://i.postimg.cc/65Fg3xzg/Chat-GPT-Image-Sep-13-2025-05-31-00-AM.png)](https://postimg.cc/xcytx7w3)



# StreamSnatcher 🎧⚡

**StreamSnatcher** is a lightweight Python tool for ripping, capturing, and saving streams with style.  
Fast, simple, and designed to just work — no bloat, no fuss.

---

## 🚀 Features
- 🔥 Quick and reliable stream capture
- 🐍 Pure Python (no heavy dependencies)
- 🛠 Easy CLI interface (`streamsnatcher`)
- ✅ Tested on Linux, macOS, and Windows

---

## 📦 Installation
Install directly from PyPI:

```bash
pip install streamsnatcher
````

Or install from source:

```bash
git clone https://github.com/youruser/streamsnatcher.git
cd streamsnatcher
pip install .
```

---

## 🖥 Usage

Run via CLI after installation:

```bash
streamsnatcher <url_or_stream>
```

Example:

```bash
streamsnatcher https://example.com/live/stream.m3u8
```

Output will be saved in the current directory.

---

## 🧪 Development

Clone the repo and install dependencies:

```bash
git clone https://github.com/youruser/streamsnatcher.git
cd streamsnatcher
pip install -r requirements.txt
```

Run tests:

```bash
pytest
```

---

## 📜 License

StreamSnatcher is released under the **Private License**.
See [LICENSE.md](LICENSE.md) for details.

---

## 🤝 Contributing

Pull requests are welcome! Open an issue for bugs, features, or discussion.

---

## 🌐 Links

* **PyPI:** [StreamSnatcher on PyPI](https://pypi.org/project/streamsnatcher/)
* **GitHub:** [StreamSnatcher Repository](https://github.com/74Thirsty/streamsnatcher)

