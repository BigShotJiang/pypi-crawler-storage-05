# Hello World Test Package

A simple hello world package for testing PyPI uploads.

## Installation

```bash
pip install hello-world-test-pkg
```

## Usage

```python
from hello_world import hello
print(hello())
```