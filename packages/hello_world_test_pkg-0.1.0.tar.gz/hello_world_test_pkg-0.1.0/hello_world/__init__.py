def hello():
    return "Hello, World!"

__version__ = "0.1.0"