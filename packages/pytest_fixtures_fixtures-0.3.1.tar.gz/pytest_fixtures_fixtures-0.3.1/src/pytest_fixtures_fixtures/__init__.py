"""Handy fixtures to access your fixtures."""

from .parametrize import parametrize_from_fixture

__version__ = "0.3.1"

__all__ = ["parametrize_from_fixture"]
