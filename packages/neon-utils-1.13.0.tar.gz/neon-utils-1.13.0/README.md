# Neon Skill Utilities
Collection of generic utilities used within Neon Core and Skills.
Contains utilities for running Neon Skills on Mycroft and OVOS.

Location information provided by [OpenStreetMap](https://openstreetmap.org/copyright).