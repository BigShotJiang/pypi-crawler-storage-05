{%
  include-markdown "../CONTRIBUTING.md"
%}
