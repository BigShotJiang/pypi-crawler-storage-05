from __future__ import absolute_import, division, print_function, unicode_literals

from ..common import __version__, deprecated

deprecated.module(__name__)
__all__ = ("__version__",)
