from __future__ import absolute_import, division, print_function, unicode_literals

from applitools.common import deprecated
from applitools.common.fluent.check_settings import CheckSettings, CheckSettingsValues

deprecated.module(__name__)
__all__ = "CheckSettings", "CheckSettingsValues"
