#!/bin/bash
dls-pmac-control.py -n 8 -o ts -s bl08i-nt-tserv-01 -p 7022
