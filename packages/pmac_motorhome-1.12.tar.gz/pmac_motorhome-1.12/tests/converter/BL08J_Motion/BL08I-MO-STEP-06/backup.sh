dls-pmac-analyse.py --pmac=BL08J-MO-STEP-06 --ts=bl08i-nt-tserv-01:7022 --checkpositions --backup=backup --resultsdir=backup
