dls-pmac-analyse.py --pmac=BL99P-MO-STEP-02 --ts=bl99p-nt-tserv-01:7002 --checkpositions --backup=backup --resultsdir=backup
