#!/bin/bash
dls-pmac-control.py -n 8 -o ts -s bl08j-mo-tserv-01 -p 7004
