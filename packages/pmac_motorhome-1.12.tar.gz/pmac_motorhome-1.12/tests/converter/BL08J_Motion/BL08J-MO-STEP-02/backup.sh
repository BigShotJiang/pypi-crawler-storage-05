dls-pmac-analyse.py --pmac=BL08J-MO-STEP-02 --ts=bl08j-mo-tserv-01:7004 --checkpositions --backup=backup --resultsdir=backup
