dls-pmac-analyse.py --pmac=BL08J-MO-STEP-07 --ts=bl08i-nt-tserv-01:7023 --checkpositions --backup=backup --resultsdir=backup
