# Reference

Technical reference material including APIs and release notes.

```{toctree}
:maxdepth: 1
:glob:

reference/external
reference/internal

API <_api/pmac_motorhome>
genindex
Release Notes <https://github.com/DiamondLightSource/pmac_motorhome/releases>
```
