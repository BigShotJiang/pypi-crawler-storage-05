Control System Integration
===========================

.. _Homing_API:

Homing API
----------

The Homing PLCs generated using pmac_homing have a simple API which uses
P Variables to control and monitor the homing procedure.

TODO Elaborate
TODO include details of debugging mode

EPICS Support in pmac module
----------------------------

TODO - discuss what we have in pmacUtil and get it ported to pmac!
