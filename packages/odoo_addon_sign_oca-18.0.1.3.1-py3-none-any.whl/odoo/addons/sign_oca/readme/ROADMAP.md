## Tasks

- Ensure that the signature is inalterable. Maybe we might need to use
  some tools like endevise or pyHanko with a certificate. Signer can be
  authenticated using OTP.
