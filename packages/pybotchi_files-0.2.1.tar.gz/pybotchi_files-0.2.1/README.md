# PyBotchi Files

Dedicated agents for file/s content extraction and manipulation.

## Feel free to override/extend it's functionality to cater your requirements.

# Example Usage

- [FastAPI](https://github.com/amadolid/pybotchi/blob/master/agents/pybotchi-files/example_usage.py)
  - > uvicorn example_usage:app
