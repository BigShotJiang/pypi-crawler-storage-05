"""Install `cookit[playwright,loguru]` before import this module."""

from .router import (
    log_router_err as log_router_err,
)
