"""Install `cookit[playwright,jinja]` before import this module."""

from .base import (
    make_template_renderer as make_template_renderer,
)
