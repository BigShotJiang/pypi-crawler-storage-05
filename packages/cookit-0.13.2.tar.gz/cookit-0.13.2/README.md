<!-- markdownlint-disable MD033 MD036 MD041 -->

<div align="center">

_Logo 征集中_

# Cookit

_✨ 自用工具集 ✨_

<img src="https://img.shields.io/badge/python-3.10+-blue.svg" alt="python">
<a href="https://github.com/astral-sh/uv">
  <img src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json" alt="uv">
</a>
<a href="https://wakatime.com/badge/user/b61b0f9a-f40b-4c82-bc51-0a75c67bfccf/project/018e2a1e-94fe-4cd2-941c-8a606b671263">
  <img src="https://wakatime.com/badge/user/b61b0f9a-f40b-4c82-bc51-0a75c67bfccf/project/018e2a1e-94fe-4cd2-941c-8a606b671263.svg" alt="wakatime">
</a>

<br />

<a href="https://pydantic.dev">
  <img src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/lgc-NB2Dev/readme/main/template/pyd-v1-or-v2.json" alt="Pydantic Version 1 Or 2" >
</a>
<a href="./LICENSE">
  <img src="https://img.shields.io/github/license/lgc2333/cookit.svg" alt="license">
</a>
<a href="https://pypi.python.org/pypi/cookit">
  <img src="https://img.shields.io/pypi/v/cookit.svg" alt="pypi">
</a>
<a href="https://pypi.python.org/pypi/cookit">
  <img src="https://img.shields.io/pypi/dm/cookit" alt="pypi download">
</a>

</div>

## 📖 介绍

暂无

## 💿 安装

_可选依赖请自行查看 `pyproject.toml`_

```bash
pip install cookit[all]
```

## 📞 联系

QQ：3076823485  
Telegram：[@lgc2333](https://t.me/lgc2333)  
吹水群：[168603371](https://qm.qq.com/q/EikuZ5sP4G)  
邮箱：<lgc2333@126.com>

<!-- ## 💡 鸣谢 -->

## 💰 赞助

**[赞助我](https://blog.lgc2333.top/donate)**

感谢大家的赞助！你们的赞助将是我继续创作的动力！

## 📝 更新日志

暂无
