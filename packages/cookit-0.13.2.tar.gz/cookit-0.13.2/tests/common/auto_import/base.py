counter = 0


def add_counter():
    global counter
    counter += 1


def get_counter():
    return counter
