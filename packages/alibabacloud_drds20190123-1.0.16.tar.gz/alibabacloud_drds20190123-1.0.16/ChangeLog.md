2025-03-11 Version: 1.0.15
- Update API DescribeDrdsInstance: update response param.
- Update API DescribeDrdsInstances: update param RegionId.
- Update API DescribeDrdsRdsInstances: update response param.
- Update API DescribeDrdsSlowSqls: add param RegionId.


2024-04-24 Version: 1.0.14
- Update API DescribeDbInstances: update response param.
- Update API DescribeDrdsInstances: update param RegionId.
- Update API DescribeDrdsInstances: update response param.
- Update API ListTagResources: add param AccessKeyId.


2024-01-24 Version: 1.0.13
- Generated python 2019-01-23 for Drds.

2023-11-06 Version: 1.0.12
- Generated python 2019-01-23 for Drds.

2022-01-07 Version: 1.0.11
- Fixed some bugs.

2021-12-07 Version: 1.0.10
- Fixed some bugs.

2021-12-06 Version: 1.0.9
- Fixed some bugs.

2021-11-22 Version: 1.0.8
- Fixed some bugs.

2021-11-18 Version: 1.0.7
- Fixed some bugs.

2021-11-18 Version: 1.0.6
- Fixed some bugs.

2021-11-17 Version: 1.0.5
- Fixed some bugs.

2021-10-27 Version: 1.0.4
- Fix some problem.

2021-05-23 Version: 1.0.3
- New API- GetDrdsDbRdsRelationInfo, which can get private RDS list under certain DB out of DRDS instance ID and DB name.

2021-05-14 Version: 1.0.2
- Support Private RDS management through OpenAPI.
- ManagePrivateRds to do RDS information query and some management.
- DescribeDrdsRdsInstances to find RDS under a certain DRDS instance.
- UpdatePrivateRdsClass to Upgrade or Downgrade your Private RDS class.

2021-03-30 Version: 1.0.1
- Generated python 2019-01-23 for Drds.

2020-12-30 Version: 1.0.0
- AMP Version Change.

2020-12-30 Version: 1.0.0
- AMP Version Change.

2020-12-30 Version: 1.0.0
- AMP Version Change.

2020-12-30 Version: 1.0.0
- AMP Version Change.

