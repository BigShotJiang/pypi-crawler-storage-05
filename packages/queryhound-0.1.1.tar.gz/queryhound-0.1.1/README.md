# QueryHound 🐾

QueryHound sniffs out slow queries, COLLSCANs, and other patterns in MongoDB logs. Run `qh --help` to get started.
