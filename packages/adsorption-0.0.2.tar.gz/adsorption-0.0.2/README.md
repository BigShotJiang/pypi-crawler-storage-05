# Adsorption

[![Pypi version](https://img.shields.io/pypi/v/adsorption)](https://pypi.org/project/adsorption/)
[![PyPI Downloads](https://static.pepy.tech/badge/adsorption)](https://pepy.tech/projects/adsorption)

The Adsorption package is a Python package for the adsorption of molecules on clusters or surfaces.
