from adsorption.optmization import AdsorptionOpt as Adsorption  # noqa: D104

__all__ = ["Adsorption"]
