from mcp_server_code_assist import main

main()
