"""
Main entry point for MCP Windows Website Downloader server
"""
from .server import main

if __name__ == '__main__':
    main()