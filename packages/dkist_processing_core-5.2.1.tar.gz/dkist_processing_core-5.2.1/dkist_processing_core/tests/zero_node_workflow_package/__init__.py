"""Workflow with zero nodes."""
