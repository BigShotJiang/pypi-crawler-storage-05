Goal: {goal}
Webpage ARIA tree:
```xml
{accessibility_tree}
```
