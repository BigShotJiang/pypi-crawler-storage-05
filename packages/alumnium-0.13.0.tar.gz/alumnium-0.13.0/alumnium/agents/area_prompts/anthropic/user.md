Given the following XML UI tree:
```xml
{accessibility_tree}
```
Identify the ID of the container element for the following scope: {description}
