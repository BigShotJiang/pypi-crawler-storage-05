Goal: {goal}
Step: {step}
Webpage ARIA tree:
```xml
{accessibility_tree}
```
