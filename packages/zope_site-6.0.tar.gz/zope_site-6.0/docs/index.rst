.. include:: ../README.rst

Contents:

.. toctree::
   :maxdepth: 2

   site
   api
   changelog


Development
===========

zope.site is hosted at GitHub:

    https://github.com/zopefoundation/zope.site/

Project URLs
============

* http://pypi.python.org/pypi/zope.site       (PyPI entry and downloads)


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
