# BBB. Remove in Version 5.0
from zope.deprecation import moved


moved('zope.component', 'Version 5.0')
