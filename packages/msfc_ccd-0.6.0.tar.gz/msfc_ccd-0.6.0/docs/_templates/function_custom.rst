{{ name | escape | underline}}

.. currentmodule:: {{ module }}

.. autofunction:: {{ fullname }}