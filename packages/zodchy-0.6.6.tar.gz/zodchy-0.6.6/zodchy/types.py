import typing

Empty = typing.NewType('Empty', object)
Skip = typing.NewType('Skip', object)
