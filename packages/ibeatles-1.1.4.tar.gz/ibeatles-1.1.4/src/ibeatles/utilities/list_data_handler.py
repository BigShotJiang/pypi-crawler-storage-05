class ListDataHandler:
    def __init__(self, parent=None):
        self.parent = parent

    def right_click(self, position=None):
        self.position = position
