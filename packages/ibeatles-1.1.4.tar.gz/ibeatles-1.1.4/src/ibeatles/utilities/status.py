class Status:
    not_run_yet = 0
    in_progress = 1
    completed = 2
