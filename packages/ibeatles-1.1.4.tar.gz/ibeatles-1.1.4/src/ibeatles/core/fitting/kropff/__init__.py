"""Kropff fitting module."""
