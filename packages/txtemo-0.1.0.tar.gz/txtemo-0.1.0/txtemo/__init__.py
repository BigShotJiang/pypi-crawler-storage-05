from .model import predict
