from datetime import datetime

__version__ = datetime.now().strftime("%Y.%m.%d.%H%M")
