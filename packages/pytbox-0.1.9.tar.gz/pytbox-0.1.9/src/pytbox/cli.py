#!/usr/bin/env python3
"""
Pytbox 命令行工具 - 入口文件（保持向后兼容）
"""

from pytbox.cli import main

if __name__ == "__main__":
    main()