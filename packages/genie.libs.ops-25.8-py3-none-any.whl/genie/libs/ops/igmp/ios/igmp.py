'''
IGMP Genie Ops Object for IOS - CLI.
'''
from ..iosxe.igmp import Igmp as IgmpXE

class Igmp(IgmpXE):
    pass