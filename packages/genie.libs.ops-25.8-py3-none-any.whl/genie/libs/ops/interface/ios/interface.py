''' 
Interface Genie Ops Object for IOS - CLI.
'''

import re

# iosxe interface ops
from ..iosxe.interface import Interface as InterfaceXE


class Interface(InterfaceXE):
    '''Interface Genie Ops Object'''
    pass