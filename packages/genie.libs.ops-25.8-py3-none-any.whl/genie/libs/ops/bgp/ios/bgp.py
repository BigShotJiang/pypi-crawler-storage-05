'''
BGP Genie Ops Object for IOS - CLI.
'''
from ..iosxe.bgp import Bgp as BgpXE

class Bgp(BgpXE):
    pass