'''
Dot1x Genie Ops Object for IOS - CLI.
'''
from ..iosxe.dot1x import Dot1X as Dot1XXE

class Dot1X(Dot1XXE):
    pass