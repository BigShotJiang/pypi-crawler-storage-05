'''
Mld Genie Ops Object for IOS - CLI.
'''
from ..iosxe.mld import Mld as MldXE

class Mld(MldXE):
    pass