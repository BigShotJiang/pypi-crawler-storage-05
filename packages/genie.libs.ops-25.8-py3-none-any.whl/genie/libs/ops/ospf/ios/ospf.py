'''
OSPF Genie Ops Object for IOS - CLI
'''
from ..iosxe.ospf import Ospf as OspfXE

class Ospf(OspfXE):
    pass