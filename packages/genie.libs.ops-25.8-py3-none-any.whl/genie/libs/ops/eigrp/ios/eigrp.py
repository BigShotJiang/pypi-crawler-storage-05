# Genie
from genie.ops.base import Base

# IOSXE Ops
from genie.libs.ops.eigrp.iosxe.eigrp import Eigrp as EigrpXE

class Eigrp(EigrpXE):
    '''
        Eigrp Ops Object
    '''
    pass
