from genie.ops.base import Base

class Lisp(Base):
    exclude = []