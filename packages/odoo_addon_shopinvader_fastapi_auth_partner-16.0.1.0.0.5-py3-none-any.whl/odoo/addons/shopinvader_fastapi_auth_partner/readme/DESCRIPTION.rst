This module provides the ``auth_jwt_authenticated_or_anonymous_partner`` and
``auth_jwt_authenticated_or_anonymous_partner_auto_create`` FastAPI dependencies.
