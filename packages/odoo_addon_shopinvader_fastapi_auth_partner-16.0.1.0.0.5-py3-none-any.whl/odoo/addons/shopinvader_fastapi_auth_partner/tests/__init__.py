from . import test_auth_partner_or_anonymous
