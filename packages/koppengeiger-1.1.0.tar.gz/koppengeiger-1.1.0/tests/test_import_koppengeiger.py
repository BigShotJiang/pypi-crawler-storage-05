def test_import_koppengeiger():
    import koppengeiger
