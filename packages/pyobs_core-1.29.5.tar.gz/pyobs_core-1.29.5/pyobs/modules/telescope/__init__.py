"""
Modules for telescopes.
TODO: write doc
"""

__title__ = "Telescopes"

from .basetelescope import BaseTelescope
from .dummytelescope import DummyTelescope
