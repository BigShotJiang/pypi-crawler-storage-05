"""Utility functions and helpers."""
