"""OpenAPI specification handling and validation."""
