"""Core framework utilities and configuration."""
