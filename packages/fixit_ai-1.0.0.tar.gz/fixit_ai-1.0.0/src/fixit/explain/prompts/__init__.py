"""LLM prompt templates for analysis."""
