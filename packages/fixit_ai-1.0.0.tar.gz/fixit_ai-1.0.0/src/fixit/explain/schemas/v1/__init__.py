"""Version 1 schema definitions."""
