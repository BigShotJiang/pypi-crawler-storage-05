"""JSON schemas for structured LLM output validation."""
