- Go to **Inventory \> Configuration \> Settings \> Traceability**, and
  activate option **Lots & Serial Numbers** in order to manage lots in
  your instance.
- Go to **Sales \> Products \> Products** and select Product Type as **Goods** check
  that the product has **Track Inventory** set to **By lots** or to
  **By Unique Serial Number** (in the General Information tab) and
  **Invoicing Policy** set to **Delivered quantities** (in the
  General Information tab) **Invoicing Policy** set to
  **Delivered quantities** (in the Sales tab)
