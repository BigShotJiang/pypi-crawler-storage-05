- Create and validate a sale order
- Set *Lots/Serial Numbers* on the delivered lines by clicking on the
  button *Register lots, packs, location*
- After creating the invoice, the *Lots/Serial Numbers* are displayed in
  the *Production Lots* on the invoice line form and in *formatted note*
  field on the invoice report, and, in case **Tracking** has been
  selected to **By lots**, their corresponding delivered quantities will
  be displad as well.
