def sum_addition(a, b):
    return a + b

class methTrick:
    def __init__(self, value):
        self.value = value

    def double(self):
        return self.value * 2
