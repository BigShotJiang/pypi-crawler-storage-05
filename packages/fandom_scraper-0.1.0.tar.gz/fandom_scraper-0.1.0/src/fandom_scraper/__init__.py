def main() -> None:
    print("Hello from fandom-scraper!")
