RoleUser
--------

.. automodule:: UserKit.RoleUser
