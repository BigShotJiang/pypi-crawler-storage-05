UserManagerToFile
-----------------

.. automodule:: UserKit.UserManagerToFile
