.. _ref-userkit:

UserKit
=======

.. toctree::
   :maxdepth: 2
   :caption: The UserKit plug-in contains the following classes:

   hierrole
   role
   roleuser
   roleusermanager
   roleusermanagermixin
   roleusermanagertofile
   user
   usermanager
   usermanagertofile
