UserManager
-----------

.. automodule:: UserKit.UserManager
