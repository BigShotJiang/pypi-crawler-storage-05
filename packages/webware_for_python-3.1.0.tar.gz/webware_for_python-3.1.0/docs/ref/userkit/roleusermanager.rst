RoleUserManager
---------------

.. automodule:: UserKit.RoleUserManager
