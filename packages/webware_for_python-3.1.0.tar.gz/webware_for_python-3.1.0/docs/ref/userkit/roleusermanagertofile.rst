RoleUserManagerToFile
---------------------

.. automodule:: UserKit.RoleUserManagerToFile
