HierRole
--------

.. automodule:: UserKit.HierRole
