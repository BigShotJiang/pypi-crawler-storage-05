Role
----

.. automodule:: UserKit.Role
