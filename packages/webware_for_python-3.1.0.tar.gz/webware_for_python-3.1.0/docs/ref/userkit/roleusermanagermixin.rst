RoleUserManagerMixIn
--------------------

.. automodule:: UserKit.RoleUserManagerMixIn
