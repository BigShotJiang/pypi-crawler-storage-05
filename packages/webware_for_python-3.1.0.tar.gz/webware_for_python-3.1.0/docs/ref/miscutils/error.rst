Error
-----

.. automodule:: MiscUtils.Error
   :no-inherited-members:
