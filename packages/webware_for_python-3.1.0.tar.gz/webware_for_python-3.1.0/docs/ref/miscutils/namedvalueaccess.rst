NamedValueAccess
----------------

.. automodule:: MiscUtils.NamedValueAccess
