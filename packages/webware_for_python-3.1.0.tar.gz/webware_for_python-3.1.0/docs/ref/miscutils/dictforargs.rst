DictForArgs
-----------

.. automodule:: MiscUtils.DictForArgs
