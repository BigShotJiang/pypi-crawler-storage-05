DateInterval
------------

.. automodule:: MiscUtils.DateInterval
