Funcs
-----

.. automodule:: MiscUtils.Funcs
