PickleCache
-----------

.. automodule:: MiscUtils.PickleCache
