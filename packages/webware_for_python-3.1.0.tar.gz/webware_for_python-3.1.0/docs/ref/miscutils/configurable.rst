Configurable
------------

.. automodule:: MiscUtils.Configurable
