MixIn
-----

.. automodule:: MiscUtils.MixIn
