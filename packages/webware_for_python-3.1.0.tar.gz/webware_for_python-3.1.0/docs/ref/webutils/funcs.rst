Funcs
-----

.. automodule:: WebUtils.Funcs
