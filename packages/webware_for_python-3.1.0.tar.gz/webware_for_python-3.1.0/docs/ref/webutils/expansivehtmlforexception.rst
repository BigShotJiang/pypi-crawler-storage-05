ExpansiveHTMLForException
-------------------------

.. automodule:: WebUtils.ExpansiveHTMLForException
