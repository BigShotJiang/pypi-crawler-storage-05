HTMLForException
----------------

.. automodule:: WebUtils.HTMLForException
