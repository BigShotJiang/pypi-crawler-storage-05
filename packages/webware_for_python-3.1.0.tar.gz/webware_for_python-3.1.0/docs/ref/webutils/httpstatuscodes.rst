HTTPStatusCodes
---------------

.. automodule:: WebUtils.HTTPStatusCodes
