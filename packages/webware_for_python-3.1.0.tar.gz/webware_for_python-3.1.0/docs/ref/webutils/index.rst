.. _ref-webutils:

WebUtils
========

.. toctree::
   :maxdepth: 2
   :caption: The WebUtils package contains:

   expansivehtmlforexception
   fieldstorage
   funcs
   htmlforexception
   htmltag
   httpstatuscodes
