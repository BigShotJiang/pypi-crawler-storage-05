StreamReader
------------

.. automodule:: PSP.StreamReader
