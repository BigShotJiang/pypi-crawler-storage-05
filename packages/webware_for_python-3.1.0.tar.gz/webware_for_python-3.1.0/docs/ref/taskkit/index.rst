.. _ref-taskkit:

TaskKit
=======

.. toctree::
   :maxdepth: 2
   :caption: The TaskKit plug-in contains the following classes:

   scheduler
   task
   taskhandler
