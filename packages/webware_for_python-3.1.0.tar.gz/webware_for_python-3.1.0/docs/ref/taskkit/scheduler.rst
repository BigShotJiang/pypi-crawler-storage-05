Scheduler
---------

.. automodule:: TaskKit.Scheduler
