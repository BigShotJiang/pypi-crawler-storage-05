HTTPResponse
------------

.. automodule:: HTTPResponse
