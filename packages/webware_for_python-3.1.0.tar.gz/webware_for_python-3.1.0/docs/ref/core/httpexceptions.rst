HTTPExceptions
--------------

.. automodule:: HTTPExceptions
