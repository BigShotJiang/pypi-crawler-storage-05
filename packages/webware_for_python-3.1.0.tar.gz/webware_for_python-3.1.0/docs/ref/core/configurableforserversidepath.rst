ConfigurableForServerSidePath
-----------------------------

.. automodule:: ConfigurableForServerSidePath
