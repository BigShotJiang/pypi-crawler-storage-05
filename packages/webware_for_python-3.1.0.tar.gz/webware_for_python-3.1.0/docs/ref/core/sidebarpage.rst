SidebarPage
-----------

.. automodule:: SidebarPage
