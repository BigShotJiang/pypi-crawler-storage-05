SessionMemcachedStore
---------------------

.. automodule:: SessionMemcachedStore
