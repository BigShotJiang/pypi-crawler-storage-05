SessionMemoryStore
------------------

.. automodule:: SessionMemoryStore
