Cookie
------

.. automodule:: Cookie
