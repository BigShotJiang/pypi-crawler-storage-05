SessionFileStore
----------------

.. automodule:: SessionFileStore
