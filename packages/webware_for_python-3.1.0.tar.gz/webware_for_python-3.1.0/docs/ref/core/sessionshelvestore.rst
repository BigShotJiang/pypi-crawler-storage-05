SessionShelveStore
------------------

.. automodule:: SessionShelveStore
