SessionRedisStore
-----------------

.. automodule:: SessionRedisStore
