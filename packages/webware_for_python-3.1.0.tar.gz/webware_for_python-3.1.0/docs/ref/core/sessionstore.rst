SessionStore
------------

.. automodule:: SessionStore
