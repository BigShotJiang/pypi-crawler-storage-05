"""Webware SessionStore tests"""
