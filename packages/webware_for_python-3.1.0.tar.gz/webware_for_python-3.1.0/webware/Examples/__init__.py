"""Main Examples context"""
