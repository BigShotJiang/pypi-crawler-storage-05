name = 'WebUtils'

synopsis = (
    "WebUtils contains functions for common web related programming tasks"
    " such as encoding/decoding HTML, etc.")
