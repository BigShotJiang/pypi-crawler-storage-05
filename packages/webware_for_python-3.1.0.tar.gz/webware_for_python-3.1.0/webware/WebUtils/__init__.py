"""WebUtils for Webware for Python"""

__all__ = ['HTMLForException', 'HTTPStatusCodes', 'HTMLTag', 'Funcs']


def installInWebware(_application):
    pass
