name = 'MiscUtils'

status = 'stable'

synopsis = (
    "MiscUtils provides support classes and functions to Webware"
    " that aren't necessarily web-related and that don't fit into one of"
    " the other plug-ins. There is plenty of useful reusable code here.")
