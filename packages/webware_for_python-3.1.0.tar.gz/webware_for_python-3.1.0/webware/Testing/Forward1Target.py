from Testing.DebugPage import DebugPage


class Forward1Target(DebugPage):
    pass
