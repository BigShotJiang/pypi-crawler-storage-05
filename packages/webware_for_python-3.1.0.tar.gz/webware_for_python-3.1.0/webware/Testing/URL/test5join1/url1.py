# pylint: disable=unused-import
from Testing.URL.util import Inspector as url1  # noqa: F401
