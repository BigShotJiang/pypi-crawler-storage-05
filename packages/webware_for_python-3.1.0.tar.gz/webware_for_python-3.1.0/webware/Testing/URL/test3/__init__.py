# URL/test3

from URLParser import URLParameterParser

urlParserHook = URLParameterParser()
