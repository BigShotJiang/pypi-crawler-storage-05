# pylint: disable=unused-import
from Testing.URL.util import Inspector as url2  # noqa: F401
