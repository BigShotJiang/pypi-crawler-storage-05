# pylint: disable=unused-import
from Testing.URL.util import Inspector as Main  # noqa: F401
