"""TaskKit Plug-in for Webware for Python"""


def installInWebware(_application):
    pass
