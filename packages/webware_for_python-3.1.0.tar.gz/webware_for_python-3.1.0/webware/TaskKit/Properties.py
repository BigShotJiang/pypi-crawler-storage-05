name = 'TaskKit'

status = 'stable'

synopsis = (
    "TaskKit provides a framework for the scheduling and management"
    " of tasks which can be triggered periodically or at specific times.")
