name = 'UserKit'

synopsis = (
    "UserKit provides for the management of users"
    " including passwords, user data, server-side archiving and caching.")
