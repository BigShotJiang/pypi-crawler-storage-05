from setuptools import setup, find_packages

setup(
    name="1joepie-prank",
    version="0.2.0",
    packages=find_packages(),
    description="Joepie's fun prank tools (fake hacker screens)",
    author="Noah",
)
