#
# PROGRAM: CONJUNO
# MODULE : _version
#

version_info = (0, 1, 9)
__version__ = ".".join(map(str, version_info))
