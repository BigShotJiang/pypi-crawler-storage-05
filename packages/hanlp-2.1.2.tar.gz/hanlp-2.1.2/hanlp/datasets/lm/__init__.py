# -*- coding:utf-8 -*-
# Author: hankcs
# Date: 2020-06-05 21:41

_PTB_HOME = 'http://www.fit.vutbr.cz/~imikolov/rnnlm/simple-examples.tgz#'
PTB_TOKEN_TRAIN = _PTB_HOME + 'data/ptb.train.txt'
PTB_TOKEN_DEV = _PTB_HOME + 'data/ptb.valid.txt'
PTB_TOKEN_TEST = _PTB_HOME + 'data/ptb.test.txt'

PTB_CHAR_TRAIN = _PTB_HOME + 'data/ptb.char.train.txt'
PTB_CHAR_DEV = _PTB_HOME + 'data/ptb.char.valid.txt'
PTB_CHAR_TEST = _PTB_HOME + 'data/ptb.char.test.txt'
