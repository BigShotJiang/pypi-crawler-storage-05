# -*- coding:utf-8 -*-
# Author: hankcs
# Date: 2019-12-28 19:26

__version__ = '2.1.2'
"""HanLP version"""


class NotCompatible(Exception):
    pass
