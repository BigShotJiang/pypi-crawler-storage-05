# -*- coding:utf-8 -*-
# Author: hankcs
# Date: 2019-12-28 19:10
from hanlp.pretrained import tok
from hanlp.pretrained import dep
from hanlp.pretrained import sdp
from hanlp.pretrained import glove
from hanlp.pretrained import pos
from hanlp.pretrained import rnnlm
from hanlp.pretrained import word2vec
from hanlp.pretrained import ner
from hanlp.pretrained import classifiers
from hanlp.pretrained import fasttext
from hanlp.pretrained import mtl
from hanlp.pretrained import eos
from hanlp.pretrained import sts
from hanlp.pretrained import constituency
from hanlp.pretrained import amr
from hanlp.pretrained import amr2text
from hanlp.pretrained import srl

# Will be filled up during runtime
ALL = {}
