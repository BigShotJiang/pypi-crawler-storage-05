#!/usr/bin/env python3
"""Command-line entry point for Redshift MCP Server."""
from redshift_mcp_server.server import main

if __name__ == "__main__":
    main()