#!/usr/bin/env python3
"""Model Context Protocol server for Amazon Redshift."""

__version__ = "0.1.0"