# MyST file

(myst-label)=

## subheading

{literalref}`link text <myst-label>`

{literalref}`myst-label`

{literalref}`MyST to rST <rst-label>`

<!-- These ones should *not* get resolved by the `lrd` domain -->

()[myst-label]

{ref}`myst-label`
