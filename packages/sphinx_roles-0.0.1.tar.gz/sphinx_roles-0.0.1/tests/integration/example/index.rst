.. _rst-label:

Test doc
========

:spellexception:`i can spel`

:none:`This does nothing!`

:literalref:`external link <https://github.com/canonical/sphinx-roles>`

:literalref:`internal same page <rst-label>`

:literalref:`internal other page <other-file>`

:literalref:`rST to MyST <myst-label>`

.. toctree::
    :hidden:

    other-file
    myst-file
