 uv add pillow
 uv add numpy
 uv add opencv-python
 uv add requests
 uv add console
 uv add pyqt6
 uv add astropy
 uv add click
