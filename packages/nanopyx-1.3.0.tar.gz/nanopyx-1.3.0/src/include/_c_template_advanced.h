#ifndef _C_TEMPLATE_ADVANCED_H
#define _C_TEMPLATE_ADVANCED_H

void _c_template_advanced(float* image);

#endif