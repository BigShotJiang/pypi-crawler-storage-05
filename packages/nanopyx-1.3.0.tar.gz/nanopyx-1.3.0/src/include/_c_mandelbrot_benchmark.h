#ifndef _C_MANDELBROT_BENCHMARK_H
#define _C_MANDELBROT_BENCHMARK_H

int _c_mandelbrot(float row, float col);

# endif
