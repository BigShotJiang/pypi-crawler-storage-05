# Alen's Importers

# Python

To run Python code, run with `uv`:

```sh
uv run python <file.py>
```

# Testing

To execute tests, run:
```sh
uv run pytest
```
