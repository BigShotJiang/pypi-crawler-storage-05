The Judicial Committee of the Privy Council is the highest court of appeal for many countries in the Commonwealth, UK territories and military sovereign base areas. It also deals with appeals from ecclesiastical courts.

This court began to regularly transfer judgments to The National Archives in 2022. The oldest judgment from this court included in Find Case Law is from {start_year}.

You can read more about it on the [Judicial Committee of the Privy Council website](https://www.jcpc.uk/about/role-of-the-jcpc.html){target="\_blank"}.
