The General Regulatory Chamber handles appeals against decisions made by various government regulatory bodies. These appeals cover a range of sectors including charities, community rights, environment, electronic communications, postal services, estate agents, exam boards, food safety, gambling, immigration services, information rights, pensions regulation and more.

This tribunal began to regularly transfer decisions to The National Archives in 2022. The oldest decision from this tribunal included in Find Case Law is from {start_year}.

You can read more about the General Regulatory Chamber on the [HM Courts and Tribunals website](https://www.gov.uk/courts-tribunals/first-tier-tribunal-general-regulatory-chamber){target="\_blank"}.
