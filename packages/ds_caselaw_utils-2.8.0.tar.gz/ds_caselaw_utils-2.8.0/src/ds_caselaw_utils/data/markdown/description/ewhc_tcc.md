The Technology and Construction Court is a specialist court within the King’s Bench Division of the High court. It is also one of the Business and Property Courts. It specialises in disputes relating to buildings, engineering and technology. It hears cases involving contract disputes, professional negligence, insurance disputes, procurement and more. It typically handles cases over £250,000.

This court began to regularly transfer judgments to The National Archives in 2022. The oldest judgment from this court included in Find Case Law is from {start_year}.

You can read more about it on the link on the [HM Courts and Tribunals Service website](https://www.gov.uk/government/organisations/hm-courts-and-tribunals-service/about){target="\_blank"}.
