The High Court deals at first instance with all high value and high importance civil law (non-criminal) cases, and also has a supervisory jurisdiction over all subordinate courts and tribunals, with a few statutory exceptions. The High court has three divisions, King’s/Queen’s Bench, Family and Chancery Divisions.

You can [read more about the High court on the judiciary website](https://www.judiciary.uk/structure-of-courts-and-tribunals-system/){target="\_blank"}.
