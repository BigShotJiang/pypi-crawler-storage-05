"""Tests for utility functions."""
