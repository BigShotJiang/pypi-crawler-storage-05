"""
EvoTool - Evolutionary Optimization Toolkit

A Python library for evolutionary optimization applications with GPU acceleration support.
"""

__version__ = "0.1.0b1"
__author__ = "Ping Guo"