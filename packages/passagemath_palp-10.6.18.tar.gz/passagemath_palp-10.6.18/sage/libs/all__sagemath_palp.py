# sage_setup: distribution = sagemath-palp
