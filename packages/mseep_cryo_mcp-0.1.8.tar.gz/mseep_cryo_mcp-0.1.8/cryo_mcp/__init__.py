"""
Cryo MCP Server - Query Ethereum blockchain data using cryo and MCP
"""

__version__ = "0.1.4"
