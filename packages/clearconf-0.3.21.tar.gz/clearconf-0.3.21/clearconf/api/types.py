class Hidden:
    pass

class Prompt:
    pass