import __main__
import collections
import inspect
import json
import copy

from .meta import MetaBaseConfig

class BaseConfig(metaclass=MetaBaseConfig):
    pass