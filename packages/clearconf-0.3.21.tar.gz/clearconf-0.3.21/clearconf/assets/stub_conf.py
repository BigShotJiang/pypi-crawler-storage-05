"""This is an example of how a Config looks like.
    You can remove the parts that you don't need and add
    new sections as you please."""

from clearconf import BaseConfig


class Config(BaseConfig):
    pass
