__version__ = "0.2.0"

from .main import (
    FixedLossWeighter,
    PDLossWeighter,
    PLossWeighter,
    LinearTrajectoryTarget,
    ConstantTarget,
    RelativeTarget,
    Target,
)
