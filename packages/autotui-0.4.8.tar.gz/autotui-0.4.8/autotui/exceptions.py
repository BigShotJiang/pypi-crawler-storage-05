class AutoTUIException(RuntimeError):
    pass
