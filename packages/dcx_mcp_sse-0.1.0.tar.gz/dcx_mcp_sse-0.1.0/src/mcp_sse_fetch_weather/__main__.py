from mcp_sse_fetch_weather import main

main()