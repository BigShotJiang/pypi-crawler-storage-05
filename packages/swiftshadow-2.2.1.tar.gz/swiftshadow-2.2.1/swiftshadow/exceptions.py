class UnsupportedProxyProtocol(Exception):
    """Exception raised when a unsupported proxy protocol is intialised."""

    pass
