# CacheData Model
::: swiftshadow.models.CacheData
