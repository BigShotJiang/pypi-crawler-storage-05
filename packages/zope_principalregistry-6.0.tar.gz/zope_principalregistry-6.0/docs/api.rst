===============
 API Reference
===============

Registry
========

.. automodule:: zope.principalregistry.principalregistry

ZCML Directives
===============

.. automodule:: zope.principalregistry.metadirectives
.. automodule:: zope.principalregistry.metaconfigure
