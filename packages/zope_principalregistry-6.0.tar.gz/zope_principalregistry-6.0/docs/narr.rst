.. include:: ../src/zope/principalregistry/README.rst
