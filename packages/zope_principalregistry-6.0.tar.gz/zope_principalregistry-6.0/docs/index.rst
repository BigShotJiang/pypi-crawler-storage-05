.. include:: ../README.rst

.. toctree::
   :maxdepth: 2

   narr
   api


.. toctree::
   :maxdepth: 2

   changelog

Development
===========

zope.principalregistry is hosted at GitHub:

    https://github.com/zopefoundation/zope.principalregistry/



Project URLs
============

* https://pypi.python.org/pypi/zope.principalregistry       (PyPI entry and downloads)


====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
