"""Tests for the packager module."""
