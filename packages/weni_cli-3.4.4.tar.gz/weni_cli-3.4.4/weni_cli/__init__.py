"""
Weni CLI
"""
