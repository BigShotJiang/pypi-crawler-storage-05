Layers
======


.. automodule:: apax.layers.activation
    :members:

.. automodule:: apax.layers.empirical
    :members:

.. automodule:: apax.layers.initializers
    :members:

.. automodule:: apax.layers.masking
    :members:

.. automodule:: apax.layers.ntk_linear
    :members:

.. automodule:: apax.layers.properties
    :members:

.. automodule:: apax.layers.readout
    :members:

.. automodule:: apax.layers.scaling
    :members:
