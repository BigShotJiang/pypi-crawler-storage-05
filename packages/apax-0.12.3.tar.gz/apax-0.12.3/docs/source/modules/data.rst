Data Pipeline
==============

:mod:`apax.data`

.. automodule:: apax.data.preprocessing
    :members:

.. automodule:: apax.data.initialization
    :members:

.. automodule:: apax.data.input_pipeline
    :members:

.. automodule:: apax.data.statistics
    :members:
