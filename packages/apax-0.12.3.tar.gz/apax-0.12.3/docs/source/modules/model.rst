Model
=====

.. automodule:: apax.model.builder
    :members:

.. automodule:: apax.model.gmnn
    :members:
