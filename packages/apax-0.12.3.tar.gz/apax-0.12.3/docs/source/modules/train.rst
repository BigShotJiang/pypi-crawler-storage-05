Training
========

.. automodule:: apax.train.callbacks
    :members:

.. automodule:: apax.train.checkpoints
    :members:

.. automodule:: apax.train.eval
    :members:

.. automodule:: apax.train.loss
    :members:

.. automodule:: apax.train.metrics
    :members:

.. automodule:: apax.train.run
    :members:

.. automodule:: apax.train.trainer
    :members:
