Batch Active Learning
=====================

.. automodule:: apax.bal.api
    :members:

.. automodule:: apax.bal.feature_maps
    :members:

.. automodule:: apax.bal.kernel
    :members:

.. automodule:: apax.bal.selection
    :members:

.. automodule:: apax.bal.transforms
    :members:
