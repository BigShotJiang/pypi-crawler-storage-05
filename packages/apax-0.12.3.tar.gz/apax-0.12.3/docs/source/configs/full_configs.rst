.. _train_config:

===============
Training Config
===============

Full config can be downloaded :download:`here <../../../apax/cli/templates/train_config_full.yaml>`.

.. include:: ../../../apax/cli/templates/train_config_full.yaml
    :literal:

.. _md_config:

=========================
Molecular Dynamics Config
=========================

Full config can be downloaded :download:`here <../../../apax/cli/templates/md_config_minimal.yaml>`.

.. include:: ../../../apax/cli/templates/md_config_minimal.yaml
    :literal:
