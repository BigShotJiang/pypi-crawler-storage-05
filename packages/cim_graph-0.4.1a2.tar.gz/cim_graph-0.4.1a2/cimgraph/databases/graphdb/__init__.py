from cimgraph.databases.graphdb.graphdb import GraphDBConnection
