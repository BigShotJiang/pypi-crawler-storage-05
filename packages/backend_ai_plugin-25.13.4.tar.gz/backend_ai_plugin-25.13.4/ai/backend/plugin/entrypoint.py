from __future__ import annotations

import ast
import collections
import configparser
import itertools
import logging
import os
import sys
import zipfile
from importlib.metadata import EntryPoint, entry_points
from pathlib import Path
from typing import Iterable, Iterator, Optional

log = logging.getLogger(__spec__.name)


def scan_entrypoints(
    group_name: str,
    allowlist: Optional[set[str]] = None,
    blocklist: Optional[set[str]] = None,
) -> Iterator[EntryPoint]:
    if blocklist is None:
        blocklist = set()
    existing_names: dict[str, EntryPoint] = {}

    prepare_wheelhouse()
    for entrypoint in itertools.chain(
        scan_entrypoint_from_buildscript(group_name),
        scan_entrypoint_from_package_metadata(group_name),
    ):
        if allowlist is not None and not match_plugin_list(entrypoint.value, allowlist):
            continue
        if match_plugin_list(entrypoint.value, blocklist):
            continue
        if existing_entrypoint := existing_names.get(entrypoint.name, None):
            if existing_entrypoint.value == entrypoint.value:
                # Allow if the same plugin is scanned multiple times.
                # This may happen if:
                # - A plugin is installed via `./py -m pip install -e ...`
                # - The unified venv is re-exported *without* `./py -m pip uninstall ...`.
                # - Adding PYTHONPATH with plugin src directories in `./py` results in
                #   *duplicate* scan results from the remaining `.egg-info` directory (pkg metadata)
                #   and the `setup.cfg` scan results.
                # TODO: compare the plugin versions as well? (need to remember version with entrypoints)
                continue
            else:
                raise RuntimeError(
                    f"Detected a duplicate plugin entrypoint name {entrypoint.name!r} "
                    f"from {existing_entrypoint.value} and {entrypoint.value}",
                )
        existing_names[entrypoint.name] = entrypoint
        yield entrypoint


def match_plugin_list(entry_path: str, plugin_list: set[str]) -> bool:
    """
    Checks if the given module attribute reference is in the plugin_list.
    The plugin_list items are assumeed to be prefixes of package import paths
    or the package namespaces.
    """
    mod_path = entry_path.partition(":")[0]
    for block_pattern in plugin_list:
        if mod_path.startswith(block_pattern + ".") or mod_path == block_pattern:
            return True
    return False


def scan_entrypoint_from_package_metadata(group_name: str) -> Iterator[EntryPoint]:
    log.debug("scan_entrypoint_from_package_metadata(%r)", group_name)

    yield from entry_points().select(group=group_name)


_default_glob_excluded_patterns = [
    "ai/backend/webui",
    "ai/backend/web/static",
    "ai/backend/runner",
    "ai/backend/kernel",
    "wheelhouse",
    "tools",
]

_optimized_glob_search_patterns = {
    # These patterns only apply to scanning BUILD files in dev setups and pex distributions.
    # They do not affect standard package entrypoint searches.
    # NOTE: most entrypoint declaration in BUILD files are in the package's top-level only!
    "backendai_cli_v10": ["ai/backend/*", "ai/backend/appproxy/*"],
    "backendai_network_manager_v1": ["ai/backend/*"],
    "backendai_event_dispatcher_v20": ["ai/backend/*", "ai/backend/appproxy/*"],
    "backendai_stats_monitor_v20": ["ai/backend/*", "ai/backend/appproxy/*"],
    "backendai_error_monitor_v20": ["ai/backend/*", "ai/backend/appproxy/*"],
    "backendai_hook_v20": ["ai/backend/*"],
    "backendai_webapp_v20": ["ai/backend/*"],
    "backendai_scheduler_v10": ["ai/backend/manager"],
    "backendai_agentselector_v10": ["ai/backend/manager"],
}


def _glob(
    base_path: Path,
    filename: str,
    excluded_patterns: Iterable[str],
    match_patterns: Iterable[str] | None = None,
) -> Iterator[Path]:
    q: collections.deque[tuple[Path, bool]] = collections.deque()
    assert base_path.is_dir()
    q.append((base_path, False))
    while q:
        search_path, suffix_match = q.pop()

        # Check if current directory matches any pattern and we should yield files from it
        current_matches = False
        if match_patterns is not None:
            current_matches = any(search_path.match(pattern) for pattern in match_patterns)

        for item in search_path.iterdir():
            if item.is_dir():
                if item.name == "__pycache__":
                    continue
                if item.name.startswith("."):
                    continue
                if any(item.match(pattern) for pattern in excluded_patterns):
                    continue

                # Determine if we should queue this directory
                should_queue = False
                new_suffix_match = False

                if match_patterns is None:
                    # No patterns specified - queue all non-excluded directories
                    should_queue = True
                    new_suffix_match = False
                elif not suffix_match:
                    # Haven't found a matching directory yet - check if this one matches
                    if any(item.match(pattern) for pattern in match_patterns):
                        should_queue = True
                        new_suffix_match = True
                    else:
                        # Keep searching - queue without suffix match
                        should_queue = True
                        new_suffix_match = False
                else:
                    # Already found a matching directory - only queue if this also matches
                    if any(item.match(pattern) for pattern in match_patterns):
                        should_queue = True
                        new_suffix_match = True

                if should_queue:
                    q.append((item, new_suffix_match))
            else:
                if item.name == filename:
                    # Yield file if no patterns or current directory matches
                    if match_patterns is None or current_matches:
                        yield item


def scan_entrypoint_from_buildscript(group_name: str) -> Iterator[EntryPoint]:
    entrypoints = {}
    # Scan self-exported entrypoints when executed via pex.
    ai_backend_ns_path = Path(__file__).parent.parent
    log.debug(
        "scan_entrypoint_from_buildscript(%r): Namespace path: %s", group_name, ai_backend_ns_path
    )
    match_patterns = _optimized_glob_search_patterns.get(group_name, None)
    # First, it is invoked in PEX or temporary test environment generated by Pantsbuild.
    # In the test environment, BUILD files are NOT copied, so the plugin discovery will rely on the
    # followed build-root search below.
    for buildscript_path in _glob(
        ai_backend_ns_path, "BUILD", _default_glob_excluded_patterns, match_patterns
    ):
        for entrypoint in extract_entrypoints_from_buildscript(group_name, buildscript_path):
            entrypoints[entrypoint.name] = entrypoint
    if os.environ.get("SCIE", None) is None:
        # Override with the entrypoints found in the current build-root directory.
        try:
            build_root = find_build_root()
        except ValueError:
            pass
        else:
            src_path = build_root / "src"
            log.debug("scan_entrypoint_from_buildscript(%r): current src: %s", group_name, src_path)
            for buildscript_path in _glob(
                src_path, "BUILD", _default_glob_excluded_patterns, match_patterns
            ):
                for entrypoint in extract_entrypoints_from_buildscript(
                    group_name, buildscript_path
                ):
                    entrypoints[entrypoint.name] = entrypoint
    else:
        log.debug(
            "scan_entrypoint_from_buildscript(%r): skipping 'src' when executed inside the SCIE environment",
            group_name,
        )
    yield from entrypoints.values()


def scan_entrypoint_from_plugin_checkouts(group_name: str) -> Iterator[EntryPoint]:
    entrypoints = {}
    try:
        build_root = find_build_root()
    except ValueError:
        pass
    else:
        plugins_path = build_root / "plugins"
        log.debug(
            "scan_entrypoint_from_plugin_checkouts(%r): plugin parent dir: %s",
            group_name,
            plugins_path,
        )
        # For cases when plugins use Pants
        for buildscript_path in _glob(plugins_path, "BUILD", _default_glob_excluded_patterns):
            for entrypoint in extract_entrypoints_from_buildscript(group_name, buildscript_path):
                entrypoints[entrypoint.name] = entrypoint
        # For cases when plugins use standard setup.cfg
        for setup_cfg_path in _glob(plugins_path, "setup.cfg", _default_glob_excluded_patterns):
            for entrypoint in extract_entrypoints_from_setup_cfg(group_name, setup_cfg_path):
                if entrypoint.name not in entrypoints:
                    entrypoints[entrypoint.name] = entrypoint
        # TODO: implement pyproject.toml scanner
    yield from entrypoints.values()


def prepare_wheelhouse(base_dir: Path | None = None) -> None:
    if base_dir is None:
        base_dir = Path.cwd()
    for whl_path in (base_dir / "wheelhouse").glob("*.whl"):
        extracted_path = whl_path.with_suffix("")  # strip the extension
        log.debug("prepare_wheelhouse(): loading %s", whl_path)
        if not extracted_path.exists():
            with zipfile.ZipFile(whl_path, "r") as z:
                z.extractall(extracted_path)
        decoded_path = os.fsdecode(extracted_path)
        if decoded_path not in sys.path:
            sys.path.append(decoded_path)


def find_build_root(path: Optional[Path] = None) -> Path:
    if env_build_root := os.environ.get("BACKEND_BUILD_ROOT", None):
        return Path(env_build_root)
    cwd = Path.cwd() if path is None else path
    while True:
        if (cwd / "BUILD_ROOT").exists():
            return cwd
        cwd = cwd.parent
        if cwd.parent == cwd:
            # reached the root directory
            break
    raise ValueError("Could not find the build root directory")


def extract_entrypoints_from_buildscript(
    group_name: str,
    buildscript_path: Path,
) -> Iterator[EntryPoint]:
    try:
        tree = ast.parse(buildscript_path.read_bytes())
    except IsADirectoryError:
        # In macOS, "build" directories generated by build scripts of vendored repositories
        # are indistinguishable with "BUILD" files because macOS' default filesystem setting
        # ignores the cases of filenames.
        # Let's simply skip over in such cases.
        return
    for node in tree.body:
        if (
            isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Call)
            and isinstance(node.value.func, ast.Name)
            and node.value.func.id == "python_distribution"
        ):
            for kwarg in node.value.keywords:
                if kwarg.arg == "entry_points":
                    raw_data = ast.literal_eval(kwarg.value)
                    for key, raw_entry_points in raw_data.items():
                        if key != group_name:
                            continue
                        for name, ref in raw_entry_points.items():
                            try:
                                yield EntryPoint(name=name, value=ref, group=group_name)
                            except ValueError:
                                pass


def extract_entrypoints_from_setup_cfg(
    group_name: str,
    setup_cfg_path: Path,
) -> Iterator[EntryPoint]:
    cfg = configparser.ConfigParser()
    cfg.read(setup_cfg_path)
    raw_data = cfg.get("options.entry_points", group_name, fallback="").strip()
    if not raw_data:
        return
    data = {
        k.strip(): v.strip()
        for k, v in (line.split("=", maxsplit=1) for line in raw_data.splitlines())
    }
    for name, ref in data.items():
        yield EntryPoint(name=name, value=ref, group=group_name)
