from typing import Optional

from thestage.services.core_files.config_entity import ConfigEntity

APP_CONFIG: Optional[ConfigEntity] = None
