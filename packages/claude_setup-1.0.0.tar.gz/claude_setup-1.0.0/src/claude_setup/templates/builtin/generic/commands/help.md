---
description: Show available commands and usage
---

# Available Commands

Display all available commands with descriptions and usage examples.

Show:
1. Built-in Claude commands
2. Project-specific commands  
3. Custom agent commands

Provide helpful examples for common workflows.