"""Template management for Claude Setup."""

from claude_setup.templates.manager import Template, TemplateManager

__all__ = ["TemplateManager", "Template"]
