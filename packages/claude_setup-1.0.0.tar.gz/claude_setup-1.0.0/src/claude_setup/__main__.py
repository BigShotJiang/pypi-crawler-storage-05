"""Entry point for claude-setup CLI."""

import sys

from claude_setup.cli import main

if __name__ == "__main__":
    sys.exit(main())
