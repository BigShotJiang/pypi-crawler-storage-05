"""Agent generation for Claude Setup."""

from claude_setup.agents.generator import ConfigGenerator

__all__ = ["ConfigGenerator"]
