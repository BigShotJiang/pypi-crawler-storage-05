import sys


sys.ps1 = 'debug> '
