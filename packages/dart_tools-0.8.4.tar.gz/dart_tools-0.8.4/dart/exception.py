class DartException(Exception):
    pass


class OrderException(Exception):
    pass
