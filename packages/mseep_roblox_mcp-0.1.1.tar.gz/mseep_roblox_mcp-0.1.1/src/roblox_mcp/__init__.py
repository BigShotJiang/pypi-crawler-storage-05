"""Roblox Studio integration through the Model Context Protocol."""

__version__ = "0.1.0"
 
# Expose key classes/functions if needed later
# from .server import ...
# from .roblox_client import RobloxClient 