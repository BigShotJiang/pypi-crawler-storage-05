from dlt.cli._dlt import main

if __name__ == "__main__":
    main()
