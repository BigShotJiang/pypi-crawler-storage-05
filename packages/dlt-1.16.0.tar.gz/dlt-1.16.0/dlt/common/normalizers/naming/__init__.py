from .naming import NamingConvention

__all__ = ["NamingConvention"]
