from .core import Game
from .objects import Cube
