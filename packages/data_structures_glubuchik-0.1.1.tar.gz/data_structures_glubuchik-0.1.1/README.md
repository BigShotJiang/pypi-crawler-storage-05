# data_structures

simple implementations of data structures in python
