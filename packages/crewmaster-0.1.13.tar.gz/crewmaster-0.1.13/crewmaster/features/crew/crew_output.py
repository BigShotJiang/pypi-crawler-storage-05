from ..collaborator import (
    CollaboratorOutput
)

CrewOutput = CollaboratorOutput
