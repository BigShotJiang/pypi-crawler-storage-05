"""
The agent is the abstraction for a collaborator specialized as an agent.

"""

from .agent_base import (
    AgentBase,
)

__all__ = [
    "AgentBase",
]
