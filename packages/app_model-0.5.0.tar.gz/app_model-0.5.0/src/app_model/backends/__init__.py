"""Adapters for using the app_model with various backends."""

# TODO: make a `use_app()` like adapter to easily switch?
