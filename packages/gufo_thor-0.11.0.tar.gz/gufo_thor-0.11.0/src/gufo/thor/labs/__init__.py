"""Lab routers implementations."""
