"""
targets module.

Targets are the drivers which itermediates
with the orchestrator.

The following targets are supported out of the box:

* compose - docker compose target
"""
