"""SimpleTuner - Diffusion training made easy."""

__version__ = "2.2.1"
