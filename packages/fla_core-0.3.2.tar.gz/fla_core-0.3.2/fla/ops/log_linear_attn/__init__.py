# -*- coding: utf-8 -*-

from .chunk import chunk_log_linear_attn

__all__ = [
    'chunk_log_linear_attn',
]
