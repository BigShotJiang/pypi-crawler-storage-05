# -*- coding: utf-8 -*-

from .parallel import parallel_path_attn

__all__ = [
    'parallel_path_attn'
]
