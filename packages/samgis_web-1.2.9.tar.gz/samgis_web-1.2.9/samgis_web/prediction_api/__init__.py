"""functions useful to handle machine learning models"""
