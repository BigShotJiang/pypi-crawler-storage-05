from django.test import TestCase


class SpireChildAppIntelligenceServiceTestCase(TestCase):
    def setUp(self):
        super().setUp()
