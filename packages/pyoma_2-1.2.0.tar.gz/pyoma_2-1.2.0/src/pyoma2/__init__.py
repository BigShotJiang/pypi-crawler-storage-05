from .support.utils.logging_handler import configure_logging

configure_logging()
