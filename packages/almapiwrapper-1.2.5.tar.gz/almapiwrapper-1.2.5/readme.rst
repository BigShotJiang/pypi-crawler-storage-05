**********************************
Almapi Wrapper documentation |doc|
**********************************

This python module is a tool to use Alma APIs. it manages the logs and the
backup of the records.

* Author: Raphaël Rey (raphael.rey@slsp.ch)
* Year: 2025
* Version: 1.2.5
* License: GNU General Public License v3.0
* `Documentation <https://almapi-wrapper.readthedocs.io/en/latest/>`_

.. |doc| image:: https://readthedocs.org/projects/almapi-wrapper/badge/?version=latest
    :target: https://almapi-wrapper.readthedocs.io/en/latest/?badge=latest
    :alt: Documentation Status