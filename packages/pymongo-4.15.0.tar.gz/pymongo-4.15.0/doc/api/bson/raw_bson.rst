:mod:`raw_bson` -- Tools for representing raw BSON documents.
=============================================================
.. automodule:: bson.raw_bson
   :synopsis: Tools for representing raw BSON documents.
   :members:
