:mod:`command_cursor` -- Tools for iterating over MongoDB command results
=========================================================================

.. automodule:: pymongo.command_cursor
   :synopsis: Tools for iterating over MongoDB command results
   :members:
