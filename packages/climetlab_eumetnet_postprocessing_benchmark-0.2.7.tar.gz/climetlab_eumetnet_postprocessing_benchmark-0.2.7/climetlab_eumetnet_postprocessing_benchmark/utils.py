
import datetime


def convert_to_datetime(t):
    return datetime.datetime(t.year, t.month, t.day, t.hour)
