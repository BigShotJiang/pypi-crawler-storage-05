from syngen.ml.strategies.strategies import (  # noqa: F401;
    Strategy,
    TrainStrategy,
    InferStrategy
)
