"""unichunking settings."""

from .unisettings import unisettings

__all__ = [
    "unisettings",
]
