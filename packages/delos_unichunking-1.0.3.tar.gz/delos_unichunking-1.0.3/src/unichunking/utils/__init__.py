"""Package for the logger."""

from .logger import logger

__all__ = [
    "logger",
]
