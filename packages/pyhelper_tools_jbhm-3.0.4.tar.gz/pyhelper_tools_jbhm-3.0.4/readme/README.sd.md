# مددگار لائبريري

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE) [![PyPI](https://img.shields.io/pypi/v/pyhelper-tools-jbhm?style=for-the-badge&label=PyPI&color=blue)](https://pypi.org/project/pyhelper-tools-jbhm/)

## 🌍 دستياب ٻوليون

PYELEEELERE ** 131 ٻولين تائين تعمير ٿيل ترجمن لاء آفر پيش ڪري ٿو ** شامل آهن:

[![en](https://img.shields.io/badge/lang-en-red.svg)](readme/README.md) [![es](https://img.shields.io/badge/lang-es-yellow.svg)](readme/README.es.md) π_16 (`set_language() (`set_language() (`set_language() π_16s_ [![sv](https://img.shields.io/badge/lang-sv-blue.svg)](readme/README.sv.md) q_16_ π_161  
[![ja](https://img.shields.io/badge/lang-ja-red.svg)](readme/README.ja.md) [![ar](https://img.shields.io/badge/lang-ar-brown.svg)](readme/README.ar.md) [![af](https://img.shields.io/badge/lang-af-orange.svg)](readme/README.af.md) [![ay](https://img.shields.io/badge/lang-ay-brown.svg)](readme/README.ay.md) [![bm](https://img.shields.io/badge/lang-bm-darkgreen.svg)](readme/README.bm.md) [![ay](https://img.shields.io/badge/lang-ay-brown.svg)](readme/README.ay.md) [![ay](https://img.shields.io/badge/lang-ay-brown.svg)](readme/README.ay.md) [![bm](https://img.shields.io/badge/lang-bm-darkgreen.svg)](readme/README.bm.md)  
[![eu](https://img.shields.io/badge/lang-eu-pink.svg)](readme/README.eu.md) [![be](https://img.shields.io/badge/lang-be-darkblue.svg)](readme/README.be.md) [![bho](https://img.shields.io/badge/lang-bho-orange.svg)](readme/README.bho.md) `python
from helper import set_language

set_language("en")  # English
set_language("es")  # Spanish
set_language("fr")  # French
set_language("de")  # German
set_language("ru")  # Russian
set_language("tr")  # Turkish
set_language("zh")  # Chinese
set_language("it")  # Italian
set_language("pt")  # Portuguese
set_language("sv")  # Swedish
set_language("ja")  # Japanese
set_language("ar")  # Arabic
...
` π_14s_ `python
from helper import set_language

set_language("en")  # English
set_language("es")  # Spanish
set_language("fr")  # French
set_language("de")  # German
set_language("ru")  # Russian
set_language("tr")  # Turkish
set_language("zh")  # Chinese
set_language("it")  # Italian
set_language("pt")  # Portuguese
set_language("sv")  # Swedish
set_language("ja")  # Japanese
set_language("ar")  # Arabic
...
` `python
from helper import set_language

set_language("en")  # English
set_language("es")  # Spanish
set_language("fr")  # French
set_language("de")  # German
set_language("ru")  # Russian
set_language("tr")  # Turkish
set_language("zh")  # Chinese
set_language("it")  # Italian
set_language("pt")  # Portuguese
set_language("sv")  # Swedish
set_language("ja")  # Japanese
set_language("ar")  # Arabic
...
` `python
from helper import set_language

set_language("en")  # English
set_language("es")  # Spanish
set_language("fr")  # French
set_language("de")  # German
set_language("ru")  # Russian
set_language("tr")  # Turkish
set_language("zh")  # Chinese
set_language("it")  # Italian
set_language("pt")  # Portuguese
set_language("sv")  # Swedish
set_language("ja")  # Japanese
set_language("ar")  # Arabic
...
` `python
from helper import set_language

set_language("en")  # English
set_language("es")  # Spanish
set_language("fr")  # French
set_language("de")  # German
set_language("ru")  # Russian
set_language("tr")  # Turkish
set_language("zh")  # Chinese
set_language("it")  # Italian
set_language("pt")  # Portuguese
set_language("sv")  # Swedish
set_language("ja")  # Japanese
set_language("ar")  # Arabic
...
` π_14  
[![hr](https://img.shields.io/badge/lang-hr-blue.svg)](readme/README.hr.md) q_139_ [![da](https://img.shields.io/badge/lang-da-purple.svg)](readme/README.da.md) [![doi](https://img.shields.io/badge/lang-doi-brown.svg)](readme/README.doi.md) [![et](https://img.shields.io/badge/lang-et-blue.svg)](readme/README.et.md) [![et](https://img.shields.io/badge/lang-et-blue.svg)](readme/README.et.md) `` [![tl](https://img.shields.io/badge/lang-tl-purple.svg)](readme/README.tl.md)  
[![fi](https://img.shields.io/badge/lang-fi-blue.svg)](readme/README.fi.md) [![fy](https://img.shields.io/badge/lang-fy-orange.svg)](readme/README.fy.md) [![gl](https://img.shields.io/badge/lang-gl-green.svg)](readme/README.gl.md) [![ka](https://img.shields.io/badge/lang-ka-red.svg)](readme/README.ka.md) π_12. [![ht](https://img.shields.io/badge/lang-ht-green.svg)](readme/README.ht.md)121_ π_121  
[![iw](https://img.shields.io/badge/lang-iw-purple.svg)](readme/README.iw.md) [![hi](https://img.shields.io/badge/lang-hi-orange.svg)](readme/README.hi.md) [![hu](https://img.shields.io/badge/lang-hu-blue.svg)](readme/README.hu.md) [![is](https://img.shields.io/badge/lang-is-red.svg)](readme/README.is.md) [![id](https://img.shields.io/badge/lang-id-green.svg)](readme/README.id.md) [![jw](https://img.shields.io/badge/lang-jw-red.svg)](readme/README.jw.md) [![id](https://img.shields.io/badge/lang-id-green.svg)](readme/README.id.md) π __113  
[![kn](https://img.shields.io/badge/lang-kn-purple.svg)](readme/README.kn.md) [![kk](https://img.shields.io/badge/lang-kk-orange.svg)](readme/README.kk.md) π_1107_ q_103_ [![ku](https://img.shields.io/badge/lang-ku-green.svg)](readme/README.ku.md) [![ku](https://img.shields.io/badge/lang-ku-green.svg)](readme/README.ku.md) [![ky](https://img.shields.io/badge/lang-ky-red.svg)](readme/README.ky.md) q_101_  
[![lo](https://img.shields.io/badge/lang-lo-purple.svg)](readme/README.lo.md) Π q_99_98_ [![lt](https://img.shields.io/badge/lang-lt-red.svg)](readme/README.lt.md)96 [![mk](https://img.shields.io/badge/lang-mk-green.svg)](readme/README.mk.md) [![mk](https://img.shields.io/badge/lang-mk-green.svg)](readme/README.mk.md) [![mg](https://img.shields.io/badge/lang-mg-red.svg)](readme/README.mg.md) q_93_91_  
[![ms](https://img.shields.io/badge/lang-ms-purple.svg)](readme/README.ms.md) [![ml](https://img.shields.io/badge/lang-ml-orange.svg)](readme/README.ml.md)88_86_ ```python
from helper import run

run("./path/to/my_script.py")
#Show gui pop up with results
```8_8_8_ [![my](https://img.shields.io/badge/lang-my-green.svg)](readme/README.my.md) [![ne](https://img.shields.io/badge/lang-ne-blue.svg)](readme/README.ne.md)82_80_ [![or](https://img.shields.io/badge/lang-or-purple.svg)](readme/README.or.md)  
[![om](https://img.shields.io/badge/lang-om-orange.svg)](readme/README.om.md) ```
helper/
├── core.py
├── __init__.py
├── lang/
│   ├── en.json
│   ├── es.json
│   └── ... (100+ files)
└── submodules/
    ├── graph.py
    ├── statics.py
    ├── utils.py
    ├── caller.py
    ├── checker.py
    ├── manager.py
    ├── pyswitch.py
    ├── shared.py
    └── DBManager.py
```7_7_7_ ```
helper/
├── core.py
├── __init__.py
├── lang/
│   ├── en.json
│   ├── es.json
│   └── ... (100+ files)
└── submodules/
    ├── graph.py
    ├── statics.py
    ├── utils.py
    ├── caller.py
    ├── checker.py
    ├── manager.py
    ├── pyswitch.py
    ├── shared.py
    └── DBManager.py
```7_7_7_7_7_7_7_7_7_7_7_7_7_7_7_7_7_7_7_7_7_7_7_7_ q_71_ ```
helper/
├── core.py
├── __init__.py
├── lang/
│   ├── en.json
│   ├── es.json
│   └── ... (100+ files)
└── submodules/
    ├── graph.py
    ├── statics.py
    ├── utils.py
    ├── caller.py
    ├── checker.py
    ├── manager.py
    ├── pyswitch.py
    ├── shared.py
    └── DBManager.py
```7_7_ q_71_  
[![sd](https://img.shields.io/badge/lang-sd-green.svg)](readme/README.sd.md) [![sk](https://img.shields.io/badge/lang-sk-red.svg)](readme/README.sk.md) 66_66 [![sk](https://img.shields.io/badge/lang-sk-red.svg)](readme/README.sk.md) π_ π_ π_ π_ q_60_ π_s_60_ q  
[![th](https://img.shields.io/badge/lang-th-blue.svg)](readme/README.th.md) [![ti](https://img.shields.io/badge/lang-ti-red.svg)](readme/README.ti.md)55_ Π π_ π_ π_ π_ π_ π_ q_s_48_ q_48_ q_49_  
[![xh](https://img.shields.io/badge/lang-xh-red.svg)](readme/README.xh.md) [![yi](https://img.shields.io/badge/lang-yi-purple.svg)](readme/README.yi.md) License [![zu](https://img.shields.io/badge/lang-zu-green.svg)](readme/README.zu.md)

---


## 🚀 انسٽاليشن

PYPI کان انسٽال ٿيل:

```bash
pip install pyhelper-tools-jbhm
```

---

## 📖 جائزو

** Pyhelper ** هڪ ورسٽيل آهي هڪ ورسٽيليل q_41_ ٽولڪٽ، بصري تجزيو، بصريات، شمارياتي آپريشن، ۽ افاديت جو ڪم فلوز *.  
اهو بي ترتيب طور تي علمي، تحقيق، تحقيق ۽فته پروجيڪٽ ۾ ضم ڪري ٿو، توهان کي بوائلپلليٽ ڪوڊ بدران بصيرت جي بدران ڌيان ڏيڻ جي اجازت ڏين ٿا.

اهم فائدا
- 🧮 تعمير ٿيل ** شماريات ۽ رياضي جي افاديت ** 
- 📊 آسان استعمال ** ڊيٽا جي بصري طور تي لفافر ** 
- 🗂 هينڊي ** فائل سنڀالڻ ۽ ڳولا ** 
- 🔍 ** نحو جي تصديق ** Python فائلن لاء
- 🌍 ** گهڻن ٻولي جي سپورٽ ** استعمال ٿيندڙ ترجمن سان
- 🚀 ** فاسٽ پروٽوٽائپنگ ** * ** ۽ ** تعليم *** ** 

---

## ✨ اهم خاصيتون

### 📊 ڊيٽا جو تصور
- بار چارٽ: افقي ۽ عمودي (`hbar`, `vbar`)  
- تقسيم پلاٽ: هسٽري گرامس (`histo`)، باڪس پلاٽ (`boxplot`)، KED پلاٽ (`kdeplot`)  
- تقابلي پلاٽ: وائلن، سوارن، پٽي پلاٽ  
رابطي جو تجزيو: Hotmapss (`heatmap`)، اسڪرپٽ پلاٽ (`scatter`)  
- ترقي يافته نظارا: جوڑوں پلاٽ، گڏيل پلاٽ، ريگريشن پلاٽ  
ڊيٽا ٽيبلز: فارميٽ ٽيبل ڏيکاري ٿو (`table`)  

### 📈 شمارياتي تجزيو
- ** مرڪزي رجحان ** : مطلب (`get_media`)، وچين (`get_median`)، موڊ (`get_moda`)  
- ** منتشر ** : حد (`get_rank`)، ويڪر (`get_var`)، معياري انحراف (`get_desv`)  
- ** تجزيو ** : منتشر رپورٽون (`disp`)، عقرون، عام طور تي، مشروط ٽرانسفارم  
** ** ٻاهرين ڳولا **: IQR ۽ Z-سکور جا طريقا  

### 🗂️ فائل جو انتظام
- `call()` (auto-detect CSV, JSON, XML, etc.) سان سمارٽ دريافت  
- ملٽي فارميٽ سپورٽ (CSV, JSON, XML, PDF, spatial data)  
- SQL ڊيٽابيس جو انتظام `DataBase` ڪلاس سان  
- تبديليء جي افاديت (`convert_file`)  

### 🛠️ ڊولپر اوزارن
- سوئچ سسٽم (`Switch`, `AsyncSwitch`)  
- نحو چڪاس (`check_syntax`, `PythonFileChecker`)  
- امير غلطي رپورٽنگ (multi-language)  
- ضم ٿيل مددگار سسٽم (`help`)  

### 🌍 انٽرنيشنلائيزيشن
- 100+ تعمير ٿيل ترجما  
- ڪسٽم ترجمو لوڊ ڪريو  
- رن ٽائيم زبان سوئچنگ (`set_language()1_14_14_13_


### بنيادي شماريات
```python
import helper as hp

data = [1, 2, 2, 3, 4, 5]

print(hp.get_media(data))   # Mean
print(hp.get_median(data))  # Median
print(hp.get_moda(data))    # Mode
```

### بصري
```python
import helper as hp

df = hp.pd.DataFrame({"values": [5, 3, 7, 2, 9]})
hp.histo(df, "values", bins=5, title="Sample Histogram")
```

### فائل سنڀالڻ
```python
from helper import call

data = call(name="my_data", type="csv")  # Finds and loads a CSV file automatically
```

### ڪسٽم ترجما
```python
from helper import load_user_translations

# Load custom translations from lang.json
load_user_translations("custom/lang.json")
```

### نحو جي تصديق
```python
from helper import run

run("./path/to/my_script.py")
#Show gui pop up with results
```

---

## 📂 پروجيڪٽ جوڙجڪ

```
helper/
├── core.py
├── __init__.py
├── lang/
│   ├── en.json
│   ├── es.json
│   └── ... (100+ files)
└── submodules/
    ├── graph.py
    ├── statics.py
    ├── utils.py
    ├── caller.py
    ├── checker.py
    ├── manager.py
    ├── pyswitch.py
    ├── shared.py
    └── DBManager.py
```

---

## 📜 License

اهو منصوبو جاري ڪيل آهي ** MIT π_4 _ ** .  
تفصيل لاء [LICENSE](LICENSE) فائل ڏسو.

---

## 🔮 روڊ ميپ

- اضافي بصريات جا قسم

- وڌايل ڊيٽابيس سپورٽ (NoSQL, graph databases)

- مشين سکيا انضمام

ويب تي ٻڌل انٽرفيس

- پلگ ان سسٽم

---

⚡ توهان جي Python ڪم ڪار فلوز سان تيار ڪرڻ لاء تيار آهيو ** pyheler ** ؟ ا today ڳولڻ شروع ڪيو!