# ياردەمچى كۇتۇپخانا

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE) [![PyPI](https://img.shields.io/pypi/v/pyhelper-tools-jbhm?style=for-the-badge&label=PyPI&color=blue)](https://pypi.org/project/pyhelper-tools-jbhm/)

## بار

Pheelper تەمىنلىگەن ** 131 خىل تىلنىڭ ** 131 خىل تىلدا تەمىنلەنگەن.

[![en](https://img.shields.io/badge/lang-en-red.svg)](readme/README.md) [![es](https://img.shields.io/badge/lang-es-yellow.svg)](readme/README.es.md) π__168_ [![ru](https://img.shields.io/badge/lang-ru-purple.svg)](readme/README.ru.md) [![ru](https://img.shields.io/badge/lang-ru-purple.svg)](readme/README.ru.md) [![zh](https://img.shields.io/badge/lang-zh-black.svg)](readme/README.zh.md) [![zh](https://img.shields.io/badge/lang-zh-black.svg)](readme/README.zh.md) [![it](https://img.shields.io/badge/lang-it-lightgrey.svg)](readme/README.it.md) [![pt](https://img.shields.io/badge/lang-pt-brightgreen.svg)](readme/README.pt.md) [![pt](https://img.shields.io/badge/lang-pt-brightgreen.svg)](readme/README.pt.md) [![sv](https://img.shields.io/badge/lang-sv-blue.svg)](readme/README.sv.md)  
[![ja](https://img.shields.io/badge/lang-ja-red.svg)](readme/README.ja.md) [![ar](https://img.shields.io/badge/lang-ar-brown.svg)](readme/README.ar.md) [![sq](https://img.shields.io/badge/lang-sq-blue.svg)](readme/README.sq.md) [![sq](https://img.shields.io/badge/lang-sq-blue.svg)](readme/README.sq.md) [![as](https://img.shields.io/badge/lang-as-purple.svg)](readme/README.as.md) [![as](https://img.shields.io/badge/lang-as-purple.svg)](readme/README.as.md) [![as](https://img.shields.io/badge/lang-as-purple.svg)](readme/README.as.md) [![as](https://img.shields.io/badge/lang-as-purple.svg)](readme/README.as.md) [![ay](https://img.shields.io/badge/lang-ay-brown.svg)](readme/README.ay.md) [![ay](https://img.shields.io/badge/lang-ay-brown.svg)](readme/README.ay.md) [![ay](https://img.shields.io/badge/lang-ay-brown.svg)](readme/README.ay.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![bm](https://img.shields.io/badge/lang-bm-darkgreen.svg)](readme/README.bm.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![bm](https://img.shields.io/badge/lang-bm-darkgreen.svg)](readme/README.bm.md)  
[![eu](https://img.shields.io/badge/lang-eu-pink.svg)](readme/README.eu.md) [![be](https://img.shields.io/badge/lang-be-darkblue.svg)](readme/README.be.md) [![bho](https://img.shields.io/badge/lang-bho-orange.svg)](readme/README.bho.md) [![bho](https://img.shields.io/badge/lang-bho-orange.svg)](readme/README.bho.md) [![ca](https://img.shields.io/badge/lang-ca-yellow.svg)](readme/README.ca.md) [![ca](https://img.shields.io/badge/lang-ca-yellow.svg)](readme/README.ca.md) [![ca](https://img.shields.io/badge/lang-ca-yellow.svg)](readme/README.ca.md) π__143_ [![ny](https://img.shields.io/badge/lang-ny-red.svg)](readme/README.ny.md) [![ny](https://img.shields.io/badge/lang-ny-red.svg)](readme/README.ny.md) [![ny](https://img.shields.io/badge/lang-ny-red.svg)](readme/README.ny.md) [![ny](https://img.shields.io/badge/lang-ny-red.svg)](readme/README.ny.md) [![ny](https://img.shields.io/badge/lang-ny-red.svg)](readme/README.ny.md) π__141_  
π_1440_ π__139_ [![doi](https://img.shields.io/badge/lang-doi-brown.svg)](readme/README.doi.md) [![nl](https://img.shields.io/badge/lang-nl-orange.svg)](readme/README.nl.md) [![nl](https://img.shields.io/badge/lang-nl-orange.svg)](readme/README.nl.md) [![et](https://img.shields.io/badge/lang-et-blue.svg)](readme/README.et.md) [![et](https://img.shields.io/badge/lang-et-blue.svg)](readme/README.et.md) [![ee](https://img.shields.io/badge/lang-ee-red.svg)](readme/README.ee.md) [![tl](https://img.shields.io/badge/lang-tl-purple.svg)](readme/README.tl.md)  
[![fi](https://img.shields.io/badge/lang-fi-blue.svg)](readme/README.fi.md) [![fy](https://img.shields.io/badge/lang-fy-orange.svg)](readme/README.fy.md) [![ka](https://img.shields.io/badge/lang-ka-red.svg)](readme/README.ka.md) [![ka](https://img.shields.io/badge/lang-ka-red.svg)](readme/README.ka.md) [![gu](https://img.shields.io/badge/lang-gu-orange.svg)](readme/README.gu.md) [![gu](https://img.shields.io/badge/lang-gu-orange.svg)](readme/README.gu.md) [![ht](https://img.shields.io/badge/lang-ht-green.svg)](readme/README.ht.md) [![ht](https://img.shields.io/badge/lang-ht-green.svg)](readme/README.ht.md) [![ht](https://img.shields.io/badge/lang-ht-green.svg)](readme/README.ht.md) [![ha](https://img.shields.io/badge/lang-ha-blue.svg)](readme/README.ha.md) [![ht](https://img.shields.io/badge/lang-ht-green.svg)](readme/README.ht.md) [![ht](https://img.shields.io/badge/lang-ht-green.svg)](readme/README.ht.md)  
[![iw](https://img.shields.io/badge/lang-iw-purple.svg)](readme/README.iw.md) [![hi](https://img.shields.io/badge/lang-hi-orange.svg)](readme/README.hi.md) [![hmn](https://img.shields.io/badge/lang-hmn-green.svg)](readme/README.hmn.md) [![is](https://img.shields.io/badge/lang-is-red.svg)](readme/README.is.md) [![is](https://img.shields.io/badge/lang-is-red.svg)](readme/README.is.md) [![ilo](https://img.shields.io/badge/lang-ilo-orange.svg)](readme/README.ilo.md) [![ilo](https://img.shields.io/badge/lang-ilo-orange.svg)](readme/README.ilo.md) [![id](https://img.shields.io/badge/lang-id-green.svg)](readme/README.id.md) [![ga](https://img.shields.io/badge/lang-ga-blue.svg)](readme/README.ga.md) [![ga](https://img.shields.io/badge/lang-ga-blue.svg)](readme/README.ga.md)  
[![kn](https://img.shields.io/badge/lang-kn-purple.svg)](readme/README.kn.md) [![kk](https://img.shields.io/badge/lang-kk-orange.svg)](readme/README.kk.md) [![km](https://img.shields.io/badge/lang-km-green.svg)](readme/README.km.md) [![rw](https://img.shields.io/badge/lang-rw-blue.svg)](readme/README.rw.md) [![gom](https://img.shields.io/badge/lang-gom-red.svg)](readme/README.gom.md) [![kri](https://img.shields.io/badge/lang-kri-orange.svg)](readme/README.kri.md) [![kri](https://img.shields.io/badge/lang-kri-orange.svg)](readme/README.kri.md) [![ku](https://img.shields.io/badge/lang-ku-green.svg)](readme/README.ku.md) [![ku](https://img.shields.io/badge/lang-ku-green.svg)](readme/README.ku.md) [![ckb](https://img.shields.io/badge/lang-ckb-blue.svg)](readme/README.ckb.md) [![ky](https://img.shields.io/badge/lang-ky-red.svg)](readme/README.ky.md)  
[![lo](https://img.shields.io/badge/lang-lo-purple.svg)](readme/README.lo.md) [![la](https://img.shields.io/badge/lang-la-orange.svg)](readme/README.la.md) [![lv](https://img.shields.io/badge/lang-lv-green.svg)](readme/README.lv.md) π_ &97_ π_ &95_ [![lg](https://img.shields.io/badge/lang-lg-purple.svg)](readme/README.lg.md) [![mk](https://img.shields.io/badge/lang-mk-green.svg)](readme/README.mk.md) [![mk](https://img.shields.io/badge/lang-mk-green.svg)](readme/README.mk.md) [![mai](https://img.shields.io/badge/lang-mai-blue.svg)](readme/README.mai.md) [![mg](https://img.shields.io/badge/lang-mg-red.svg)](readme/README.mg.md) [![mg](https://img.shields.io/badge/lang-mg-red.svg)](readme/README.mg.md)  
[![ms](https://img.shields.io/badge/lang-ms-purple.svg)](readme/README.ms.md) [![ml](https://img.shields.io/badge/lang-ml-orange.svg)](readme/README.ml.md) [![mi](https://img.shields.io/badge/lang-mi-blue.svg)](readme/README.mi.md) [![mi](https://img.shields.io/badge/lang-mi-blue.svg)](readme/README.mi.md) [![lus](https://img.shields.io/badge/lang-lus-purple.svg)](readme/README.lus.md) [![mn](https://img.shields.io/badge/lang-mn-orange.svg)](readme/README.mn.md) [![my](https://img.shields.io/badge/lang-my-green.svg)](readme/README.my.md) [![my](https://img.shields.io/badge/lang-my-green.svg)](readme/README.my.md) [![ne](https://img.shields.io/badge/lang-ne-blue.svg)](readme/README.ne.md) π_814_ [![or](https://img.shields.io/badge/lang-or-purple.svg)](readme/README.or.md)  
π______78_ π__76_ π__74_ π__73_ π__73_ [![nso](https://img.shields.io/badge/lang-nso-red.svg)](readme/README.nso.md) [![st](https://img.shields.io/badge/lang-st-purple.svg)](readme/README.st.md) [![st](https://img.shields.io/badge/lang-st-purple.svg)](readme/README.st.md) [![st](https://img.shields.io/badge/lang-st-purple.svg)](readme/README.st.md) [![st](https://img.shields.io/badge/lang-st-purple.svg)](readme/README.st.md) [![st](https://img.shields.io/badge/lang-st-purple.svg)](readme/README.st.md) [![st](https://img.shields.io/badge/lang-st-purple.svg)](readme/README.st.md)  
[![sd](https://img.shields.io/badge/lang-sd-green.svg)](readme/README.sd.md) [![si](https://img.shields.io/badge/lang-si-blue.svg)](readme/README.si.md) π__63_ [![su](https://img.shields.io/badge/lang-su-green.svg)](readme/README.su.md) π__63_ π__62_ [![ta](https://img.shields.io/badge/lang-ta-purple.svg)](readme/README.ta.md) π_09_ [![tt](https://img.shields.io/badge/lang-tt-orange.svg)](readme/README.tt.md)  
[![th](https://img.shields.io/badge/lang-th-blue.svg)](readme/README.th.md) [![ti](https://img.shields.io/badge/lang-ti-red.svg)](readme/README.ti.md) π__54_ π__54_ π__52_ π__51_ π__54_ π__54_ π__48_ π__48_ π__48_ π__48_  
[![xh](https://img.shields.io/badge/lang-xh-red.svg)](readme/README.xh.md) π__45_ π__44_ π__43_

---


## 🚀 قاچىلاش

PYP دىن قاچىلاڭ:

```bash
pip install pyhelper-tools-jbhm
```

---

## 📖 ئومۇمىي كۆرۈنۈش

** فېرلېر خانىم ** سانلىق مەلۇمات ئانالىزى ئۈچۈن لايىھەلەنگەن π____41_ قورال سۈيى, ئۇ تەسۋىرلەش, ستاتىستىكىلىق مەشغۇلاتلار ۋە پايدىلىق خىزمەت مەيدانى.  
بۇ ئىلمىي, تەتقىقات ۋە كەسپىي تۈرلەرگە نىسبەتەن ئۇنۋانىغا ئايلىنىدۇ, سىز چوقۇم ئەھمىيەتسىز ئەمەس.

مۇھىم ئەۋزەللىكلەر:
- 🧮 قۇرۇلغان ** ستاتىستىكا ۋە ماتېماتىكا ئەسلىھەلىرى ** 
- 📊 ENTOW-TOW-DIFAIP DIFT UFA USE VIGHT VIGHTION FORDURES **
- 🗂 Handy ** ھۆججەت بىر تەرەپ قىلىش ۋە ئىزدەش ** 
- 🔍 ** گرامماتىكىلىق دەلىللەش * Python ھۆججىتى ئۈچۈن *
- 🌍 * ** كۆپ تىلدىكى قوللاش ** تەييارلىق
- 🚀 ** ئۈچۈن ئەلالاشتۇرۇلغان ** تېز ئىنكاس **

---

## ✨ ئاچقۇچلۇق ئىقتىدارلار

### 📊 سانلىق مەلۇمات تەسۋىرلەش
- تاياقچە دىئاگرامما: توغرىسىغا ۋە تىك π__39_  
- تەقسىمات نۇقۇتلىرى: Hottogroms π___38_, ساندۇق يەرلىرى (`boxplot`)  
- سېلىشتۇرۇش قولتۇقى: ساۋاق, Swarm, Strals Plots  
- باغلاش ئانالىزى: Heatemps π__35_, تارقاق يەرلەر π__34_  
- ئىلغار تەسەۋۋۇر: Pair slots, بىرلەشمە پىلانلار, چېكىنىش پولت  
- سانلىق مەلۇمات جەدۋىلى: فورماتلانغان جەدۋەل (`table`)  

### ستاتىستىكىلىق تەھلىل
- ** مەركىزىي خۇرېلى: ARTIMELY π__32_, mearian π__31_, Mode (`get_moda`)  
- ** تارقىتىش ** : دائىرە (`get_rank`), variance (`get_var`), ئۆلچەملىك ياتلىشىش π__27_  
- ** تەھلىل: تارقاق دوكلات π_226_, IQR ھېسابلاش, نورماللاشتۇرۇش, شەرتلىك ئۆزگەرتىش قاتارلىقلار  
- ** سىرتقى بايقاش ** : iqr ۋە Z-نومۇر ئۇسۇللىرى  

### 🗂️ ھۆججەت باشقۇرۇش
- π_225_ π__24_ بىلەن Smart بايقاش  
- كۆپ فورماتنى قوللاش (CSV, JSON, XML, PDF, spatial data)  
- SQL ساندان باشقۇرۇش `DataBase` دەرسلىكى بىلەن  
- ئايلاندۇرۇش ئەسلىھەلىرى (`convert_file`)  

### 🛠️ ئاچقۇچى قوراللىرى
- پروگرامما تۈزلەڭلىك (`Switch`, `AsyncSwitch`)  
- subtax تەكشۈرۈش (`check_syntax`, `PythonFileChecker`)  
- مول خاتالىق (multi-language)  
- بىرلەشتۈرۈلگەن ياردەم سىستېمىسى (`help`)  

### 🌍 خەلقئارالىق يەتكۈزۈش
- ئىچىگە ئورۇنلاشتۇرۇلغان 100+  
- ئىختىيارى تەرجىمىلەرنى يۈكلەڭ  
- ئىجرا ۋاقتى تىل ئالماشتۇرۇش (`set_language()15_ "`python
from helper import set_language

set_language("en")  # English
set_language("es")  # Spanish
set_language("fr")  # French
set_language("de")  # German
set_language("ru")  # Russian
set_language("tr")  # Turkish
set_language("zh")  # Chinese
set_language("it")  # Italian
set_language("pt")  # Portuguese
set_language("sv")  # Swedish
set_language("ja")  # Japanese
set_language("ar")  # Arabic
...
`13_


### ئاساسىي ستاتىستىكىسى
```python
import helper as hp

data = [1, 2, 2, 3, 4, 5]

print(hp.get_media(data))   # Mean
print(hp.get_median(data))  # Median
print(hp.get_moda(data))    # Mode
```

### تەسۋىرلەش
```python
import helper as hp

df = hp.pd.DataFrame({"values": [5, 3, 7, 2, 9]})
hp.histo(df, "values", bins=5, title="Sample Histogram")
```

### ھۆججەت بىر تەرەپ قىلىش
```python
from helper import call

data = call(name="my_data", type="csv")  # Finds and loads a CSV file automatically
```

### خاس بەلگىلەر
```python
from helper import load_user_translations

# Load custom translations from lang.json
load_user_translations("custom/lang.json")
```

### syntax دەلىللەش
```python
from helper import run

run("./path/to/my_script.py")
#Show gui pop up with results
```

---

## 📂 تۈر قۇرۇلمىسى

π__7_

---

## 📜 License

بۇ تۈر ** [![ts](https://img.shields.io/badge/lang-ts-purple.svg)](readme/README.ts.md) π ** _ **.  
تەپسىلاتلار ئۈچۈن π____3_ ھۆججىتىنى كۆرۈڭ.

---

## 🔮 يول خەرىتىسى

- قوشۇمچە كۆرۈنۈش تىپلىرى

- سانداننى قوللاش (NoSQL, graph databases)

- ماشىنا ئۆگىنىش بىرلەشتۈرۈش

- تورنى ئاساس قىلغان كۆرۈنمە يۈزى

- قىستۇرما سىستېمىسى

---

⚡ ** pyhelper بىلەن Python خىزمەت يۈكىڭىزنى پارچىلاشقا تەييارمەن ** ? بۈگۈن ئۈستىدە ئىزاھلاشقا باشلاڭ!