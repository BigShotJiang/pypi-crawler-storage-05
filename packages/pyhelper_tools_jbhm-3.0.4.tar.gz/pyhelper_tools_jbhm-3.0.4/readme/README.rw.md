# Umufasha

Π_172_ [![PyPI](https://img.shields.io/pypi/v/pyhelper-tools-jbhm?style=for-the-badge&label=PyPI&color=blue)](https://pypi.org/project/pyhelper-tools-jbhm/)

## indimi zihari

Pyhelper itanga ibisobanuro-mubuhinduzi kugeza kuri ** 131h ** harimo:

[![en](https://img.shields.io/badge/lang-en-red.svg)](readme/README.md) [![es](https://img.shields.io/badge/lang-es-yellow.svg)](readme/README.es.md) Π_1168_ [![de](https://img.shields.io/badge/lang-de-green.svg)](readme/README.de.md) [![ru](https://img.shields.io/badge/lang-ru-purple.svg)](readme/README.ru.md) [![zh](https://img.shields.io/badge/lang-zh-black.svg)](readme/README.zh.md) [![pt](https://img.shields.io/badge/lang-pt-brightgreen.svg)](readme/README.pt.md) [![sv](https://img.shields.io/badge/lang-sv-blue.svg)](readme/README.sv.md)  
Π_1160_ [![ar](https://img.shields.io/badge/lang-ar-brown.svg)](readme/README.ar.md) [![af](https://img.shields.io/badge/lang-af-orange.svg)](readme/README.af.md) [![sq](https://img.shields.io/badge/lang-sq-blue.svg)](readme/README.sq.md) [![am](https://img.shields.io/badge/lang-am-green.svg)](readme/README.am.md) [![as](https://img.shields.io/badge/lang-as-purple.svg)](readme/README.as.md) [![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme/README.az.md) [![bm](https://img.shields.io/badge/lang-bm-darkgreen.svg)](readme/README.bm.md)  
Π_1550_ [![be](https://img.shields.io/badge/lang-be-darkblue.svg)](readme/README.be.md) [![bn](https://img.shields.io/badge/lang-bn-teal.svg)](readme/README.bn.md) [![bho](https://img.shields.io/badge/lang-bho-orange.svg)](readme/README.bho.md) [![bs](https://img.shields.io/badge/lang-bs-purple.svg)](readme/README.bm.md) [![bg](https://img.shields.io/badge/lang-bg-green.svg)](readme/README.bg.md) [![ny](https://img.shields.io/badge/lang-ny-red.svg)](readme/README.ny.md) [![co](https://img.shields.io/badge/lang-co-green.svg)](readme/README.co.md)  
.  
Π_  
Π_120_ [![hi](https://img.shields.io/badge/lang-hi-orange.svg)](readme/README.hi.md) [![hmn](https://img.shields.io/badge/lang-hmn-green.svg)](readme/README.hmn.md) [![hu](https://img.shields.io/badge/lang-hu-blue.svg)](readme/README.hu.md) Π_116_ [![ilo](https://img.shields.io/badge/lang-ilo-orange.svg)](readme/README.ilo.md) [![ga](https://img.shields.io/badge/lang-ga-blue.svg)](readme/README.ga.md) [![jw](https://img.shields.io/badge/lang-jw-red.svg)](readme/README.jw.md)  
Π_110_ [![kk](https://img.shields.io/badge/lang-kk-orange.svg)](readme/README.kk.md) [![km](https://img.shields.io/badge/lang-km-green.svg)](readme/README.km.md) [![rw](https://img.shields.io/badge/lang-rw-blue.svg)](readme/README.rw.md) Π_106_ [![ku](https://img.shields.io/badge/lang-ku-green.svg)](readme/README.ku.md) [![ky](https://img.shields.io/badge/lang-ky-red.svg)](readme/README.ky.md)  
Π_100_ [![la](https://img.shields.io/badge/lang-la-orange.svg)](readme/README.la.md) [![lv](https://img.shields.io/badge/lang-lv-green.svg)](readme/README.lv.md) [![ln](https://img.shields.io/badge/lang-ln-blue.svg)](readme/README.ln.md) [![lt](https://img.shields.io/badge/lang-lt-red.svg)](readme/README.lt.md) [![lb](https://img.shields.io/badge/lang-lb-orange.svg)](readme/README.lb.md) [![mai](https://img.shields.io/badge/lang-mai-blue.svg)](readme/README.mai.md) [![mg](https://img.shields.io/badge/lang-mg-red.svg)](readme/README.mg.md)  
Π_90_ [![ml](https://img.shields.io/badge/lang-ml-orange.svg)](readme/README.ml.md) Π_88_ [![mi](https://img.shields.io/badge/lang-mi-blue.svg)](readme/README.mi.md) [![mr](https://img.shields.io/badge/lang-mr-red.svg)](readme/README.mr.md) [![my](https://img.shields.io/badge/lang-my-green.svg)](readme/README.my.md) [![no](https://img.shields.io/badge/lang-no-red.svg)](readme/README.no.md) [![or](https://img.shields.io/badge/lang-or-purple.svg)](readme/README.or.md)  
Π_79_ [![ps](https://img.shields.io/badge/lang-ps-green.svg)](readme/README.ps.md) [![fa](https://img.shields.io/badge/lang-fa-blue.svg)](readme/README.fa.md) [![qu](https://img.shields.io/badge/lang-qu-red.svg)](readme/README.qu.md) [![ro](https://img.shields.io/badge/lang-ro-purple.svg)](readme/README.ro.md) [![sm](https://img.shields.io/badge/lang-sm-orange.svg)](readme/README.sm.md) [![nso](https://img.shields.io/badge/lang-nso-red.svg)](readme/README.nso.md) [![sn](https://img.shields.io/badge/lang-sn-orange.svg)](readme/README.sn.md)  
Π_68_ [![si](https://img.shields.io/badge/lang-si-blue.svg)](readme/README.si.md) [![sk](https://img.shields.io/badge/lang-sk-red.svg)](readme/README.sk.md) [![sl](https://img.shields.io/badge/lang-sl-purple.svg)](readme/README.sl.md) [![so](https://img.shields.io/badge/lang-so-orange.svg)](readme/README.so.md) [![su](https://img.shields.io/badge/lang-su-green.svg)](readme/README.su.md) [![ta](https://img.shields.io/badge/lang-ta-purple.svg)](readme/README.ta.md) [![te](https://img.shields.io/badge/lang-te-green.svg)](readme/README.te.md)  
Π_57_ [![ti](https://img.shields.io/badge/lang-ti-red.svg)](readme/README.ti.md) [![ts](https://img.shields.io/badge/lang-ts-purple.svg)](readme/README.ts.md) Π_54_ [![ak](https://img.shields.io/badge/lang-ak-green.svg)](readme/README.ak.md) [![uk](https://img.shields.io/badge/lang-uk-blue.svg)](readme/README.uk.md) [![uz](https://img.shields.io/badge/lang-uz-orange.svg)](readme/README.uz.md) [![cy](https://img.shields.io/badge/lang-cy-blue.svg)](readme/README.cy.md)  
Π_46_ [![yi](https://img.shields.io/badge/lang-yi-purple.svg)](readme/README.yi.md) [![yo](https://img.shields.io/badge/lang-yo-orange.svg)](readme/README.yo.md) [![zu](https://img.shields.io/badge/lang-zu-green.svg)](readme/README.zu.md)

---


## 🚀 Kwishyiriraho

Shyira muri Pypi:

```bash
pip install pyhelper-tools-jbhm
```

---

## 📖 Incamake

** PyHelper ** ni umurongo Python igitabo cyagenewe koroshya * gusesengura amakuru, ibikorwa byibarurishamibare, hamwe nibikorwa byibarurishamina, hamwe nibikorwa byakazi **.  
Ifatanije mu buryo butagira uruhare mu masomo, ubushakashatsi, n'imishinga y'umwuga, ikwemerera kwibanda ku bushishozi aho kuba code ya boilerlonte.

Ibyiza Byingenzi:
- 🧮 Mubarurishamize na ** hamwe na Math Utishoboye ** 
- 📊 Biroroshye-gukoresha ** Ibisobanuro Ibipfunyika ** 
- 🗂 Handy ** Gukoresha dosiye no gushakisha ** 
- 🔍 ** Kwemeza ** kuri Python dosiye
- 🌍 ** Inkunga myinshi y'ururimi ** hamwe na-gukoresha-ibisobanuro
- 🚀 Inoze kuri ** Prototyping ** na ** Uburezi ** 

---

## ✨ Ibiranga Urufunguzo

### 📊 Amashusho Yerekana
- Imbonerahamwe ya Bar: Horizontal & Vertical (`hbar`, `vbar`)  
- Ibibanza byo gukwirakwiza: Histogramu Π_38_, Agasanduku Plots (`boxplot`), Plots ya KDE (`kdeplot`)  
- Ibibanza bigereranya: Violon, Swingm, Ibibanza byambukiranya  
- Isesengura rifitanye isano: Ubushyuhe (`heatmap`), Gukwirakwiza Ibibanza (`scatter`)  
- Isuzuma ryambere: Ibibanza bibiri, ibibanza bihuriweho, imiyoboro  
- Imbonerahamwe yamakuru: Imbonerahamwe ya Imbonerahamwe Yerekana Π_33_  

### 📈 Isesengura ryibarurishamibare
- ** Amasezerano yo hagati ** : Gusobanura (`get_media`), Mediani π__31_, Mode Π_30_  
- ** Gutata Imana ** : Intera Π__29_, itandukaniro (`get_var`), gutandukana bisanzwe (`get_desv`)  
- ** Isesengura ** : Gutandukanya Raporo Π_26_, Kubara IQR, Ibisanzwe, Guhindura Ibisanzwe  
- ** Gumenya Byoroheje ** : Uburyo bwa IQR na Z-amanota  

### 🗂️ Ubuyobozi bwa dosiye
- Guvumburana ubwenge hamwe na `call()` (auto-detect CSV, JSON, XML, etc.)  
- Inkunga-Yumuhanda Π_23_  
- Gucunga Ububiko bwa SQL hamwe na `DataBase`  
- Guhindura Ibikorwa Π_21_  

### 🛠️ Ibikoresho byabateza imbere
- Hindura Sisitemu Π_20_  
- Kugenzura Syntax (`check_syntax`, `PythonFileChecker`)  
- Raporo Yuzuye Ikosa Π_18_  
- Gufasha Gufasha Sisitemu Π_17_  

### 🌍 International
- 100+ Yubatswe-mu busobanuro  
- Fungura ibisobanuro byihariye  
- Ururimi Runtime Guhindura (`set_language() `)  
- Automatic English fallback  

---

## Dependencies (handled automatically):

- pandas, numpy (data manipulation)

- matplotlib, seaborn (visualization)

- scikit-learn (statistics)

- sqlalchemy (database)

- geopandas (spatial data)

---

## 🔧 Usage Examples

### Set language 

**support for up to 131 languages** 
``[![ilo](https://img.shields.io/badge/lang-ilo-orange.svg)](readme/README.ilo.md) π_11


### imibare mibi
Π_12_

### Reba
Π_11_

### dosiye
Π_10_

### Ubusobanuro bwihariye
Π_9_

### Syntax Kwemeza
Π_8_

---

## 📂 Imiterere yumushinga

Π_7_

---

## 📜 License

Uyu mushinga utanga uruhushya munsi ya ** MIT π_4 _*.  
Reba [LICENSE](LICENSE) dosiye kugirango ubone ibisobanuro.

---

## 🔮 Garhamap

- ubwoko bwinyongera

- Inkunga Yagutse Ububiko Π_2_

- Kwishyira hamwe kwizihiza

- Imigaragarire ishingiye ku rubuga

- Sisitemu ya Plugin

---

Witegure cyane Π_1_ / akazi kakazi hamwe na ** pyhelper ** ? Tangira Gushakisha Uyu munsi!