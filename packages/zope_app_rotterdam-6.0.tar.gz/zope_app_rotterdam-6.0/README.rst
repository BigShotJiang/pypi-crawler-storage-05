This package provides an advanced skin for the Zope 3 ZMI.
