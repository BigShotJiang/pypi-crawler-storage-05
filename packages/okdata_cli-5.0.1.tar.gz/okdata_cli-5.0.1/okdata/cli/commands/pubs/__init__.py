from okdata.cli.commands.pubs.pubs import PubsCommand

__all__ = ["PubsCommand"]
