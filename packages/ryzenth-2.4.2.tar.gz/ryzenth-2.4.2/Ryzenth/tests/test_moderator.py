"""API is disabled move to domain new

from Ryzenth import ApiKeyFrom


def test_moderator():
    ryz = ApiKeyFrom(..., is_ok=True)
    result = ryz._sync.moderator.aigen_image_check(
            text="ok test",
            version="v2",
            is_loads=True,
            dot_access=False
    )
    assert result is not None
"""
