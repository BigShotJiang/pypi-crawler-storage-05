# Reference

::: imxInsights.file.singleFileImx.imxSingleFile

::: imxInsights.file.singleFileImx.imxSituation

::: imxInsights.file.singleFileImx.imxSituationEnum

