# Reference

::: imxInsights.exceptions.customException

::: imxInsights.exceptions.exceptionLevels
