# Reference

::: imxInsights.exceptions.exceptionHandler
