"""Package for managing optional dependencies."""
