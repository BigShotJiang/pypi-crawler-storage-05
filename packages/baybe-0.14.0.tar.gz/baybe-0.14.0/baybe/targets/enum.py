"""Target-related enumerations."""

from baybe.targets._deprecated import TargetMode, TargetTransformation  # noqa: F401
