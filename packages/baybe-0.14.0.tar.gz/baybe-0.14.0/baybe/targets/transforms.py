"""Deprecated!"""

from baybe.targets._deprecated import (  # noqa: F401
    bell_transform,
    linear_transform,
    triangular_transform,
)
