"""Collection of small utilities."""

from baybe.utils.basic import register_hooks

__all__ = [
    "register_hooks",
]
