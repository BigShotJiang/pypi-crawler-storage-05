"""Gaussian process surrogates."""

from baybe.surrogates.gaussian_process.core import GaussianProcessSurrogate

__all__ = [
    "GaussianProcessSurrogate",
]
