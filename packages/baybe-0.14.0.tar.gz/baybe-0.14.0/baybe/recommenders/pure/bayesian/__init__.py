"""Bayesian recommenders."""

from baybe.recommenders.pure.bayesian.botorch import BotorchRecommender

__all__ = [
    "BotorchRecommender",
]
