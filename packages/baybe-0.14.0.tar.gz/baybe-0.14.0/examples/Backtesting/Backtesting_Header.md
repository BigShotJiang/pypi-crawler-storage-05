# Backtesting

These examples demonstrate BayBE's
{doc}`Backtesting </userguide/simulation>` capabilities.