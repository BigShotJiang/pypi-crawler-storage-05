# Custom Surrogates

These examples demonstrate how to use custom pre-trained [ONNX](https://onnx.ai) surrogate models.