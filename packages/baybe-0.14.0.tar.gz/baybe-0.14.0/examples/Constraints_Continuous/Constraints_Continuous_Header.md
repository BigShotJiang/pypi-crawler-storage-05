# Constraints Continuous

These examples demonstrate how
{ref}`Continuous Parameter Constraints <userguide/constraints:continuous constraints>`
can be applied to continuous and hybrid search spaces.