# Basics

These examples demonstrate the most basic aspects of BayBE: How to set up a
{doc}`Campaign </userguide/campaigns>` and how to configure an optimization
{doc}`Recommender </userguide/recommenders>`.