# Multi-Armed Bandit

These examples demonstrate BayBE's Multi-Armed Bandit Capabilities.