# Transformations

These examples demonstrate BayBE's transformation functionality.