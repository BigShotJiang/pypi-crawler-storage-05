# Mixtures

These examples demonstrate how to set up mixture use cases in the traditional as well
as in the slot-based representation.