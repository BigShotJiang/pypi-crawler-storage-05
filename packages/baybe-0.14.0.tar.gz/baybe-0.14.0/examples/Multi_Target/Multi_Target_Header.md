# Multi Target

These examples demonstrate BayBE's
{doc}`Multi-Target Capabilities </userguide/objectives>`.