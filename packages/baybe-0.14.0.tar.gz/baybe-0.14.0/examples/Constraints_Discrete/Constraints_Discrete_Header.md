# Constraints Discrete

These examples demonstrate how
{ref}`Discrete Parameter Constraints <userguide/constraints:discrete constraints>`
can be applied to discrete search spaces.