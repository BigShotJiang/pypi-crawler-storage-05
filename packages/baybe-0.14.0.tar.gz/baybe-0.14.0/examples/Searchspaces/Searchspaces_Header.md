# Searchspaces

These examples demonstrate various ways to configure
{doc}`Search Spaces </userguide/searchspace>`.