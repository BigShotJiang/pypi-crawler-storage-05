# Custom Hooks

These examples demonstrate how to register custom hooks using the 
{func}`register_hooks <baybe.utils.basic.register_hooks>` utility.