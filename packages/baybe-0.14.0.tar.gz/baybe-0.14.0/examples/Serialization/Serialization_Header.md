# Serialization

These examples demonstrate BayBE's (de-)serialization capabilities.