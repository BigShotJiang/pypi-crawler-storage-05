```{include} ../../CONTRIBUTING.md
:relative-docs: docs/
```