"""Test alternative ways of creation not considered in the strategies."""
