"""Utilities for data handling."""

from pathlib import Path

DATA_PATH = Path(__file__).parent
