"""Benchmark results."""

from benchmarks.result.metadata import ResultMetadata
from benchmarks.result.result import Result

__all__ = ["Result", "ResultMetadata"]
