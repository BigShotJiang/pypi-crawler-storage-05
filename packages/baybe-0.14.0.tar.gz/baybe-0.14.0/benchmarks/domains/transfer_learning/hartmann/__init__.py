"""Synthetic transfer learning benchmarks based on the Hartmann function."""
