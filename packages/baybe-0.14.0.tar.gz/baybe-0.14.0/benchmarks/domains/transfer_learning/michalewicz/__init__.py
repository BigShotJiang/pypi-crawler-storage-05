"""Benchmarking functions for the Michalewicz function."""
