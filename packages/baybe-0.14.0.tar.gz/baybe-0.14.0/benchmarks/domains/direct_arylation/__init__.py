"""The direct arylation benchmark configuration."""
