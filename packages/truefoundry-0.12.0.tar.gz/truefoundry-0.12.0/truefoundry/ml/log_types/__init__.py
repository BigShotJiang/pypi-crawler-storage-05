from truefoundry.ml.log_types.image import Image
from truefoundry.ml.log_types.plot import Plot

__all__ = ["Image", "Plot"]
