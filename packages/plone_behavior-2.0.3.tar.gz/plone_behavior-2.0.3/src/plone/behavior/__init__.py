# Convenience import
from plone.behavior.annotation import AnnotationStorage  # noqa

import logging


logger = logging.getLogger("plone.behavior")
