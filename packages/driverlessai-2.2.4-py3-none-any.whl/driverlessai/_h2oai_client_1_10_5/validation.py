"""Type validation for _h2oai_client_1_10_5."""


def validate_toml(value, name):
    # We don't want to depend on toml so we validate it only on the server.
    pass
