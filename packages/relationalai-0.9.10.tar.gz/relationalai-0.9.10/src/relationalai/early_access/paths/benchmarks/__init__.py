# __init__.py for rpq module

from .grid_graph import create_labeled_grid

__all__ = ["create_labeled_grid"]
