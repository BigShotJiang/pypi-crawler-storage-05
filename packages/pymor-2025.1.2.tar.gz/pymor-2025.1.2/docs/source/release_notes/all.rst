.. _release_notes:

*************
Release Notes
*************

.. include:: 2025.1.rst
.. include:: 2024.2.rst
.. include:: 2024.1.rst
.. include:: 2023.2.rst
.. include:: 2023.1.rst
.. include:: 2022.2.rst
.. include:: 2022.1.rst
.. include:: 2021.2.rst
.. include:: 2021.1.rst
.. include:: 2020.2.rst
.. include:: 2020.1.rst
.. include:: 2019.2.rst
.. include:: 0.5.rst
.. include:: 0.4.rst
.. include:: 0.3.rst
