# Bibliography

<!-- see https://sphinxcontrib-bibtex.readthedocs.io/en/latest/usage.html for options -->

```{eval-rst}
.. bibliography::
```
