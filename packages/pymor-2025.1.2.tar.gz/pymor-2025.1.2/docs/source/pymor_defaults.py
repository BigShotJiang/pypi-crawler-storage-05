d = {'pymor.discretizers.builtin.gui.jupyter.get_visualizer.backend': 'k3d',
     'pymor.discretizers.builtin.gui.jupyter.kthreed.visualize_k3d.background_color': 0xfff2cc}
