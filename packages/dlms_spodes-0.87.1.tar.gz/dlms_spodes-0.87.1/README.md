# DlmsStringValues
Constant names with several translator language for use in DLMS projects. Class, Attribute, Method, CommonDataType, Emun, RelationToObis, StructFields, ArbiterActors
Public:
py setup.py sdist
twine upload dist\*