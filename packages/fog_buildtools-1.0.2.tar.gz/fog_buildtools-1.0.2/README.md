# buildtools

Common functions used for building GOG Galaxy 2.0 plugins.
