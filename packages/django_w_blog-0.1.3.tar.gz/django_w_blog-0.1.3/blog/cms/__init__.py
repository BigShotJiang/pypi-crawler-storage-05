"""Django blog Content Management System"""
