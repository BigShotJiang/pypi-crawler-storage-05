"""Django Blog: A reusable blog app powered by Python, Django, DRF, Wagtail CMS, TailwindCSS and DaisyUI."""
