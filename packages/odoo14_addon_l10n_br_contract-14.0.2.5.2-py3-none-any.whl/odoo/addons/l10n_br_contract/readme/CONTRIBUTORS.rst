* `KMEE <https://www.kmee.com.br>`_:

  * Luis Otavio Malta Conceição <luis.malta@kmee.com.br>
  * Gabriel Cardoso de Faria <gabriel.cardoso@kmee.com.br>

* `Akretion <https://akretion.com/pt-BR>`_:

  * Renato Lima <renato.lima@akretion.com.br>

* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>
