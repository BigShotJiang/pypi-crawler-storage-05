"""
Global settings for the CARLA Driving Simulator.
"""

# Debug mode flag
DEBUG_MODE = False
