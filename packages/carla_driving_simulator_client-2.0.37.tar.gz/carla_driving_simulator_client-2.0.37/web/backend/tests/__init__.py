"""
Tests for web backend package.
"""
