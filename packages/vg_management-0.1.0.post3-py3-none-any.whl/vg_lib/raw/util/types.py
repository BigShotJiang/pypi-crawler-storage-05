from typing import \
    List, \
    Tuple


ErrorList = Tuple[bool, List[str]]
