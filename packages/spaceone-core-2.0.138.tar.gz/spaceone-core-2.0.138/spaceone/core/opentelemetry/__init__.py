from spaceone.core.opentelemetry.tracer import set_tracer
from spaceone.core.opentelemetry.metrics import set_metric
