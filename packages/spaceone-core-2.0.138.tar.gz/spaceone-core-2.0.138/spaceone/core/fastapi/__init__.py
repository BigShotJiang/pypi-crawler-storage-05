from spaceone.core.fastapi.server import serve

__all__ = ['serve']

