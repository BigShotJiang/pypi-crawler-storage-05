"""GitAI - Generate Conventional Commit messages and changelog sections using AI."""

__version__ = "1.0.0"
