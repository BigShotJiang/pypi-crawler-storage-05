"""Tests for GitAI."""
