=====================
 Expression Compiler
=====================

.. autoclass:: zope.tales.tales.ExpressionEngine

.. autofunction:: zope.tales.engine.DefaultEngine

.. data:: zope.tales.engine.Engine

   An instance of the default engine (:func:`DefaultEngine`) that can
   be used for simple shared cases
