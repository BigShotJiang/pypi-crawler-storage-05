# SPDX-FileCopyrightText: 2025-present Francesco Ballardin <francesco.ballardin@gmail.com>
#
# SPDX-License-Identifier: GPL-3.0-only
__version__ = "0.1.1"
__author__ = 'Francesco Ballardin'
