Examples

This folder will contain runnable examples once the core logic is implemented.
For now, see the CLI help:

```
furlang2p --help
```
