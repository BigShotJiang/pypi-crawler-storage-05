"""CLI package (skeleton)."""

from __future__ import annotations

from .app import cli, main

__all__ = ["cli", "main"]
