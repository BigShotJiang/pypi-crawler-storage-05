"""Packaged data for FurlanG2P."""

__all__: list[str] = []
