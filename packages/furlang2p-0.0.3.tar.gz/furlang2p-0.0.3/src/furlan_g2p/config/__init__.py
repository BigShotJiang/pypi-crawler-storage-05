"""Config data structures and loading utilities (skeleton)."""

from __future__ import annotations

__all__: list[str] = []
