# MyDb2
MyDb2 slack bot

## Dependencies:

### Env Vars you must have set before running:
```
* DB2_INSTANCE_HOST=<Db2 instance host>
* DB2_INSTANCE_PORT=<Db2 instance port>
* DB2_INSTANCE_USERNAME=<Db2 instance username>
* DB2_INSTANCE_PW=<Db2 instance pw>
* FYRE_USER_NAME=<Fyre username(we use `db2-infra`)>
* FYRE_API_KEY=<In 1pass>
* JENKINS_API_TOKEN=<API key for jenkins user email>
* W3_ID=<used for Jenkins connection. we use `db2-infra@ca.ibm.com`>
* GH_PERSONAL_ACCESS_TOKEN=<In 1pass>
* SLACK_BOT_TOKEN=<Can be found in the slack applications page under db2-infra slack id>
```

### Packages:
* Using Python 3.6.9
* pip
* python-devel system package

  To get this package:

        Ububtu: sudo apt-get install python-devel

        Rhel: sudo yum install python-devel

        Fedora: sudo dnf install python2-devel

        OpenSUSE: sudo zypper in python-devel


Dependencies you can only get from github.ibm.com:
* Fyre module: https://github.ibm.com/jtiefenb/fyre-api
* slavectl: https://github.ibm.com/DB2/slavectl


Otherwise, all dependencies can be found in the requirements file. To install, run: `pip install -r ./requirements.txt`


## Contributing

### Adding new commands
  The slackbot calls the function `handler` in the file `<command>_handler.py` when a command is passed in.

*To add new commands:*
  1) Add the command name to the `VALID_COMMANDS` list in ./db2buildbot.py
  2) Create a new file `./handlers/<command>_handler.py`
  3) In `<command>_handler.py`, create a function called `handler()`
      * This function is the function that will get called when your command is run. From there you can organize what you want your command to do. Any argument parsing should happen here.
