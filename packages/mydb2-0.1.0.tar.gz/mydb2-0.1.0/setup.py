from setuptools import setup, find_packages

setup(
    name="mydb2",
    version="0.1.0",
    author="Stefan Patroi",
    author_email="stefan.patroi@ibm.com",
    description="mydb2, slackbot for db2 developers",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(where="src"),   # look inside src/
    package_dir={"": "src"},               # root package dir = src
    include_package_data=True,
    install_requires=[
        "Fyre==0.1.2",
        #"fyre-api @ git+https://github.ibm.com/jtiefenb/fyre-api.git@master",
        "ibm_db==3.2.6",
        "jenkinsapi==0.3.15",
        "prettytable==3.16.0",
        "PyGithub==2.7.0",
        "python_ldap==3.4.4",
        "Requests==2.32.5",
        "setuptools==80.9.0",
        "slack_sdk==3.36.0",
        "aiohttp>=3.8.0",          
        "websockets>=10.0",
        "Unidecode==1.4.0",
        "urllib3==1.26.16"
    ],
    entry_points={
        "console_scripts": [
            "mydb2=mydb2.db2buildbot:main",  
        ],
        "console_scripts": [
            "setup-mydb2-env=mydb2.run_env_setup:main",
        ]
    },
    python_requires=">=3.9",
    zip_safe=False,
)
