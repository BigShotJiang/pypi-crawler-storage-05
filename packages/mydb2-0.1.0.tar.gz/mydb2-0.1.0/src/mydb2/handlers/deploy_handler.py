'''
This module handles the `deploy` command and all its options
Supported by ../helpers/deploy_helpers.py
'''
import shlex
import sys
from mydb2.helpers import argparse_helper as argparse, help_command_strings as HelpStrings, common as CommonHelpers, my_authentication as Auth, github_helpers as github, db2_helpers, fyre_wrapper as fyre, Bot, bluepages_helper, slack_helpers, deploy_helpers
from argparse import RawTextHelpFormatter

import logging

def _initialize_parser():
    '''
     Parser for the deploy command.
    '''
    deploy_parser = argparse.ArgumentParser(
        prog='deploy',
        description='Deploy DB2 Dev environments autonomously.',
        add_help=False,
        formatter_class=RawTextHelpFormatter
    )

    ###
    # Required options
    ###
    required_options = deploy_parser.add_argument_group('REQUIRED arguments')
    required_options.add_argument(
        '-lu',
        '--ldap-username',
        dest='ldap_username',
        help='For UNIX: Your Markham LDAP username.\nFor Windows: Your CanLab username.\n'
             'Used as the login user to access your VM.',
        required=True
    )

    optional_options = deploy_parser.add_argument_group('OPTIONAL arguments')

    optional_options.add_argument(
        '-t',
        '--github-access-token',
        dest='github_access_token',
        required=False,
        help='Your Github user access token.'
    )
    optional_options.add_argument(
        '-p',
        '--platform',
        dest='platform',
        help='VM platform. Defaults to x86.',
        default='x86',
        choices=['x86', 'zlinux', 'power', 'aix'],
        required=False
    )
    optional_options.add_argument(
        '-o',
        '--operating-system',
        dest='operating_system',
        # help=argparse.SUPPRESS,
        help='OS for dev environment. Default is RHEL 9.4.',
        default='Redhat 9.4',
        choices=['Redhat 8.10', 'Redhat 9.4', 'Windows 2022', 'AIX 7.3', *deploy_helpers.ALCATRAZ_OS],
        required=False
    )
    optional_options.add_argument(
        '-s',
        '--vm-size',
        dest='size',
        help="""Size of the VM. Default is m(Medium).\nSize mappings are as follows:
        s -> 8CPU, 16GB
        m -> 16CPU, 16GB
        l -> 16CPU, 32GB [RESTRICTED]""",
        default='m',
        choices=['s', 'm', 'l'],
        required=False
    )
    optional_options.add_argument(
        '-c',
        '--containerized-environment',
        dest='containerized_environment',
        help=argparse.SUPPRESS,
        action='store_true',
        required=False
    )
    optional_options.add_argument(
        '--pub-ssh-key',
        dest='pub_ssh_key',
        help=argparse.SUPPRESS,
        required=False
    )
    optional_options.add_argument(
        '--install',
        dest='install_team',
        help=argparse.SUPPRESS,
        action='store_true',
        required=False,
        default=False
    )
    optional_options.add_argument(
        '--alcatraz',
        dest='alcatraz_confirmation',
        # help=argparse.SUPPRESS,
        help="""Use this flag when deploying a system with an OS that's no longer supported.""",
        action='store_true',
        required=False
    )
    optional_options.add_argument(
        '-pg',
        '--product-group',
        dest='product_group',
        help=argparse.SUPPRESS,
        choices=['db2-luw', 'db2-infrastructure'],
        default='db2-infrastructure',
        type=str,
        required=False
    )
    optional_options.add_argument(
        '-gu',
        '--github-username',
        dest='github_username',
        help=argparse.SUPPRESS,
        required=False
    )
    optional_options.add_argument(
        '--skip-ldap-verification',
        dest='skip_ldap_verification',
        help=argparse.SUPPRESS,
        # help="Using this flag will skip the LDAP username verification.",
        action='store_true',
        required=False
    )
    optional_options.add_argument(
        '--fyre3',
        dest='fyre3',
        help=argparse.SUPPRESS,
        action='store_true',
        required=False
    )

    return deploy_parser

PARSER = _initialize_parser()

def handler(event, user_email, bot):
    '''
     Handle deploy command
    '''
    command = event["text"]
    split_command = command.split()
    response = ""


    if not deploy_helpers.ALLOW_DEPLOYS: raise github.GheEmailNotPublicError(deploy_helpers.DISALLOWED_DEPLOYS_MESSAGE)

    # Checks that the command received is a supported command
    if (len(split_command) < 2) or (split_command[1].lower() == "help"):
        Bot.log_event(user_email, event)
        response = "``` {} \n```".format(PARSER.format_help())
    else:
        # AUTHENTICATION
        # Will raise UnauthorizedUserError if the user is not authorized
        Auth.authenticate_user(user_email)
        # Parse arguments from user command
        command_args = PARSER.parse_known_args(shlex.split(command))[0]
        if not (command_args.ldap_username):
            raise Bot.UserError("You must provide an LDAP username using -lu or --ldap-username")
        if (not command_args.alcatraz_confirmation and not command_args.github_access_token):
            raise Bot.UserError("You must provide you GitHub access token using -t or --github-access-token")
        # random suffix to make hostnames unique
        random_suffix = CommonHelpers.generate_random_suffix(5)
        github_username = command_args.github_username if command_args.github_username else github.get_ghe_username_from_email(user_email)
        ldap_user = CommonHelpers.parse_link_from_message(command_args.ldap_username)
        domain_specific_attributes = deploy_helpers.get_domain_specific_attributes(user_email)
        deploy_helpers.validate_user_inputs(
            ldap_user,
            user_email,
            command_args.github_access_token,
            (command_args.operating_system in deploy_helpers.ALCATRAZ_OS or command_args.alcatraz_confirmation) and not (command_args.operating_system in deploy_helpers.ALCATRAZ_GIT_OS),
            command_args.operating_system
        )
        fqdn = None
        hardware_type = 'Fyre V1'
        configuration_type = 'native'

        #RHEL 9 POWER limited options
        # if command_args.platform == 'power' and 'Redhat 9' in command_args.operating_system:
        #     raise deploy_helpers.MutuallyExclusiveOptionsError(deploy_helpers.LIMITED_TICKET_DEPLOY_MESSAGE)

        #if os level is blocked (Alcatraz and aix not handled here)
        if command_args.platform != 'aix' and command_args.operating_system in deploy_helpers.BLOCKED_DEPLOY_OS and command_args.operating_system not in deploy_helpers.ALCATRAZ_OS:
            raise github.GheEmailNotPublicError(deploy_helpers.BLOCKED_DEPLOY_MESSAGE)
        
        #AIX related blocks
        if command_args.operating_system != 'AIX 7.2' and command_args.operating_system in deploy_helpers.ALCATRAZ_OS and not command_args.alcatraz_confirmation:
            raise deploy_helpers.MutuallyExclusiveOptionsError("You have attempted to deploy an operating system that's only available under the alcatraz systems without confirming that you're attempting an Alcatraz deploy. Please choose another Operating system or provide the `--alcatraz` flag to confirm your OS selection.")

        # Override [container/Windows/AIX/Alcatraz]-specific arguments
        if command_args.operating_system in deploy_helpers.ALCATRAZ_OS and command_args.alcatraz_confirmation:
            platform = command_args.platform
            operating_system = command_args.operating_system
            hardware_type = "Leased Dev System"
            configuration_type = "user_access"

            slack_helpers.send_slack_message(
                bot.slack_messaging_client,
                channel=event["channel"],
                text="Alcatraz system checkout - Ignored deployment flags(if provided): Size"
            ) 
        elif command_args.operating_system not in deploy_helpers.ALCATRAZ_OS and command_args.alcatraz_confirmation:
            raise deploy_helpers.MutuallyExclusiveOptionsError(
                "You may not deploy a {} VM in alcatraz.\n Supported os includes: {}".format(
                    command_args.operating_system,
                    deploy_helpers.ALCATRAZ_OS
                )
            )
        elif command_args.platform == "aix" and command_args.alcatraz_confirmation:
            platform = command_args.platform
            operating_system = "AIX 7.2"
            hardware_type = "Leased Dev System"
            configuration_type = "user_access"

            slack_helpers.send_slack_message(
                bot.slack_messaging_client,
                channel=event["channel"],
                text="AIX platform deployment - Ignored deployment flags(if provided): OS, Size"
            )
        elif command_args.platform == "aix" or command_args.operating_system == "AIX 7.2" or command_args.operating_system == "AIX 7.3":
            platform = "aix"
            if command_args.operating_system not in ["AIX 7.2", "AIX 7.3"]:
                operating_system = "AIX 7.3"
            else:
                operating_system = command_args.operating_system
            hardware_type = "Leased Dev System"
            configuration_type = "user_setup"

            slack_helpers.send_slack_message(
                bot.slack_messaging_client,
                channel=event["channel"],
                text="AIX platform deployment - Ignored deployment flags(if provided): OS(non-aix), Size"
            )
        elif command_args.containerized_environment:
            platform = "x86"
            operating_system = "Redhat 7.9"
            fqdn_nodename = "x86"
            configuration_type = "containerized"

            slack_helpers.send_slack_message(
                bot.slack_messaging_client,
                channel=event["channel"],
                text=("Containerized deployment - Ignored deployment flags(if provided): "
                      "platform, OS")
            )
        elif command_args.operating_system in deploy_helpers.NTX_OS:  
            operating_system = command_args.operating_system
            if command_args.fyre3:
                hardware_type = "Fyre V3"
                configuration_type = "native"
                product_group = 3
                platform = "ntx64"  
                fqdn_nodename = "ntx64"
                slack_helpers.send_slack_message(
                    bot.slack_messaging_client,
                    channel=event["channel"],
                    text="Fyre3 deployment for {} deploy on {} platform".format(
                        operating_system,
                        platform
                    )
                )
            else:
                # Fyre1 deployment
                hardware_type = "Fyre V1"
                platform = "x64"  
                fqdn_nodename = "ntx64"
                slack_helpers.send_slack_message(
                    bot.slack_messaging_client,
                    channel=event["channel"],
                    text="Fyre1 deployment for {} deploy on {} platform".format(
                        operating_system,
                        platform
                    )
                )

            slack_helpers.send_slack_message(
                bot.slack_messaging_client,
                channel=event["channel"],
                text="Windows deployment - Ignored deployment flags(if provided): platform"
            )
        elif command_args.operating_system == "Redhat 8.10" and not command_args.platform == "x86":
            raise deploy_helpers.MutuallyExclusiveOptionsError(
                "You may not deploy a {} VM on the {} platform.".format(
                    command_args.operating_system,
                    command_args.platform
                )
            )

        elif command_args.operating_system == "Redhat 9.4" and command_args.platform in ["x86", "power", "zlinux"]:

            operating_system = command_args.operating_system
            fqdn_nodename = command_args.platform
            platform = command_args.platform
            if command_args.fyre3 and command_args.platform in ["x86", "zlinux", ]:
                # Fyre3 deployment
                hardware_type = "Fyre V3"

            elif command_args.platform == "power":
                hardware_type = "Fyre V3"
            else:
                # Fyre V1 deployment
                hardware_type = "Fyre V1"
                
            configuration_type = "native"
            product_group = 3 if platform == "x86" else 570

            if hardware_type == "Fyre V3":
                slack_helpers.send_slack_message(
                    bot.slack_messaging_client,
                    channel=event["channel"],
                    text="Fyre3 deployment for {} deploy on {} platform".format(
                        operating_system,
                        platform
                    )
                )
            else:
                slack_helpers.send_slack_message(
                    bot.slack_messaging_client,
                    channel=event["channel"],
                    text="Fyre V1 deployment for {} deploy on {} platform".format(
                        operating_system,
                        platform
                    )
                )

        else:
            platform = command_args.platform
            operating_system = command_args.operating_system
            fqdn_nodename = command_args.platform

        # Override [platform/domain]-specific product group
        if platform in ["zlinux", "power"]:
            plat = platform[0]
        else:
            plat = "x" if command_args.product_group == "db2-infrastructure" else "p"

        if hardware_type == "Leased Dev System":
            product_group = -1
        elif plat in domain_specific_attributes["product_group_ids"]:
            product_group = domain_specific_attributes["product_group_ids"][plat]
        else:
            product_group = domain_specific_attributes["product_group_ids"]["default"]


        if command_args.size not in domain_specific_attributes["vm_sizes"]:
            raise deploy_helpers.InvalidSizeSelection(
                "The size selection you have chosen is restricted. The following are the VM size "
                "options available to you: {}".format(str(domain_specific_attributes["vm_sizes"]))
            )

        # log event
        Bot.log_event(user_email, event, parsed_arguments_dict=command_args.__dict__)

        # Checks to make sure that the user has sufficient quota
        if(not db2_helpers.has_sufficient_quota(bot.db2_conn,
                                                bot.DB2_DEV_USERS_TABLE,
                                                bot.DB2_DEV_ENVIRONMENTS_TABLE,
                                                user_email)):
            Bot.log("DEBUG", "Insufficient quota. Pipeline not kicked off.")
            response = HelpStrings.INSUFFICIENT_QUOTA_MESSAGE
        else:

            if hardware_type == "Leased Dev System":
                # Reserve one of the available systems
                vacant_hosts = db2_helpers.get_vacant_hosts_from_dev_pool(
                    bot.db2_conn,
                    lease_table_name=bot.DEV_SYSTEM_POOL_TABLE_NAME,
                    os=operating_system,
                    config_type=configuration_type,
                    platform=platform
                )
                Bot.log("DEBUG", vacant_hosts)
                if not vacant_hosts:
                    Bot.log("DEBUG", "Cannot find vacant host of the following type:")
                    raise deploy_helpers.NoVacantHostsFound(HelpStrings.NO_VACANT_HOSTS_FOUND_ERROR)

                fqdn_to_reserve = vacant_hosts[0]['FQDN']

                db2_helpers.reserve_host_for_user(
                    bot.db2_conn,
                    lease_table_name=bot.DEV_SYSTEM_POOL_TABLE_NAME,
                    user_email=user_email,
                    fqdn=fqdn_to_reserve
                )
                fqdn = fqdn_to_reserve
            elif hardware_type == "Fyre V3":
                fqdn = CommonHelpers.generate_fqdn(
                    user_email,
                    random_suffix,
                    platform,
                    operating_system,
                    product_group,
                    True
                )
            else:
                fqdn = CommonHelpers.generate_fqdn(
                    user_email,
                    random_suffix,
                    fqdn_nodename,
                    operating_system,
                    product_group,
                    False
                )
            
            params = {
                'GITHUB_ACCESS_TOKEN': command_args.github_access_token,
                'GITHUB_USERNAME': github_username,
                'USER_EMAIL': user_email,
                'REMOTE_USERNAME': ldap_user,
                'PLATFORM': platform,
                'OS': operating_system,
                'VM_SIZE': command_args.size,
                'PRODUCT_GROUP': product_group,
                'SLACK_CHANNEL_ID': event["channel"],
                'HOSTNAME_SUFFIX': random_suffix,
                'CONTAINERIZED_DEPLOY': command_args.containerized_environment,
                'CONFIGURATION_TYPE': configuration_type,
                'HARDWARE_TYPE': hardware_type,
                'INSTALL_TEAM': command_args.install_team,
                'FQDN': fqdn,
                'PUB_SSH_KEY': command_args.pub_ssh_key
            }

            Bot.log("DEBUG", "Sufficient Quota, kicking off jenkins pipeline")



            if bot.jenkins_conn.build_deploy_job(params):
                response += ("Your deployment request has been submitted. You will be notified "
                            "when the deploy starts and again when the environment is ready.\n"
                            "Your FQDN is: `{}`".format(fqdn))
                if hardware_type == "Leased Dev System":
                    response += ("\nPlease note that *this system is leased to you and will be used by other developers after you*, "
                                 "and as such, you will NOT have root access on the host.\n"
                                 "Please use the destroy command to *return the system as soon as you finish working on your item*.")
            else:
                response += ("The API call to kick off your deploy failed(10 times!). If you're "
                            "sure that jenkins isn't down, feel free to try again or ask about "
                            "this in #db2-on-git")
            Bot.log("DEBUG", "Jenkins Pipeline kicked off.")

    return response
