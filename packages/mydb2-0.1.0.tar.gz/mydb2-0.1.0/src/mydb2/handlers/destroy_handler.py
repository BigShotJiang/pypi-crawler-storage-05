'''
 This module handles all invocations of the `destroy` command
'''
import shlex
import sys
import logging
from mydb2.helpers import argparse_helper as argparse, help_command_strings as HelpStrings, common as CommonHelpers, my_authentication as Auth, github_helpers as github, db2_helpers, fyre_wrapper as fyre, Bot, bluepages_helper, slack_helpers

def handler(event, user_email, bot):
    '''
     This function is the entrypoint to the `destroy` command. On invocation, the bot calls this
     function (after the very basic parsing in the main `handler` function in db2buildbot.py).
    '''
    command = event["text"]
    split_command = command.split()
    logging.basicConfig(filename='slackbot.log', level=logging.INFO)

    # Checks that the command received is a supported command
    if (len(split_command) < 2) or (split_command[1].lower() == "help"):
        #logging
        Bot.log_event(user_email, event)
        response = "```  {} ```".format(bot.parsers["DESTROY"].format_help())
    else:
        # Parse arguments from user command
        command_args = bot.parsers["MAIN"].parse_known_args(shlex.split(command))[0]
        parsed_fqdn = CommonHelpers.parse_link_from_message(command_args.fqdn)

        CommonHelpers.validate_machine_ownership(
            bot.db2_conn,
            bot.DB2_DEV_ENVIRONMENTS_TABLE,
            user_email,
            parsed_fqdn
        )

        vm_attributes = db2_helpers.get_vm_attributes(
            bot.db2_conn,
            parsed_fqdn,
            bot.DB2_DEV_ENVIRONMENTS_TABLE
        )
        cluster_name = vm_attributes["CLUSTER_NAME"]


        #logging
        Bot.log_event(user_email, event, parsed_arguments_dict=command_args.__dict__)

        if vm_attributes["HARDWARE_TYPE"] in ["Fyre V1", "Leased Dev System", "Fyre V3"]:
            params = {
                'FQDN': parsed_fqdn,
                'CLUSTERNAME': cluster_name,
                "SLACK_CHANNEL_ID": event["channel"],
                'DEV_USER': vm_attributes['CONFIGURED_USER'],
                "HARDWARE_TYPE": vm_attributes["HARDWARE_TYPE"],
                "CONFIGURATION_TYPE": vm_attributes["CONFIGURATION_TYPE"],
                "USER_EMAIL": vm_attributes["OWNER_EMAIL"]

            }

            logging_message = "------------ Params passed to destroy job: ------------\n"
            for param in params: logging_message += f"{param}: {params[param]}\n"

            if bot.jenkins_conn.build_destroy_job(params):
                response = "Your VM deletion request has been submitted."
            else:
                response = ("The API call to kick off the deletion of your VM failed(10 times!). "
                            "If you're sure that jenkins isn't down, feel free to try again or ask "
                            "about this in #db2-on-git")
        else:
            raise CommonHelpers.NoHardwareAPIError("Unrecognized VM Type. Please open a RIOT-Ticket or post to #db2-on-git for help.")

    return response
