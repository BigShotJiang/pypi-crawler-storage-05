import shlex
import sys
import logging
import requests
import os
from mydb2.helpers import argparse_helper as argparse, help_command_strings as HelpStrings, common as CommonHelpers, my_authentication as Auth, github_helpers as github, db2_helpers, fyre_wrapper as fyre, Bot, bluepages_helper, slack_helpers


def handler(event, user_email, bot):
    '''
     Handles invocation of the *reboot* command
    '''
    command = event["text"]
    split_command = command.split()
    logging.basicConfig(filename='slackbot.log', level=logging.INFO)

    # Checks that the command received is a supported command
    if (len(split_command) < 2) or (split_command[1].lower() == "help"):
        logging.info("-----------------\nTimestamp: {}\n".format(event["ts"]) +
                     "Message: {}\n".format(command) +
                     "User Email: {}\n-----------------".format(user_email))
        response = "```  {} ```".format(bot.parsers["REBOOT"].format_help())
    else:
        # Parse arguments from user command
        command_args = bot.parsers["MAIN"].parse_known_args(shlex.split(command))[0]
        broken_down_fqdn = CommonHelpers.breakdown_fqdn(command_args.fqdn)
        parsed_fqdn = CommonHelpers.parse_link_from_message(command_args.fqdn)
        CommonHelpers.validate_machine_ownership(
            bot.db2_conn,
            bot.DB2_DEV_ENVIRONMENTS_TABLE,
            user_email,
            parsed_fqdn
        )

        vm_attributes = db2_helpers.get_vm_attributes(
            bot.db2_conn,
            parsed_fqdn,
            bot.DB2_DEV_ENVIRONMENTS_TABLE
        )
        if not vm_attributes["HARDWARE_TYPE"] in ["Fyre V1", "Fyre V3"]:
            raise CommonHelpers.NoHardwareAPIError("This VM is not a Fyre VM, and therefore does "
                                                   "not have this capability.")

        cluster_name = vm_attributes["CLUSTER_NAME"]

        if vm_attributes["HARDWARE_TYPE"] == "Fyre V1":
            cluster_name = vm_attributes["CLUSTER_NAME"]
            bot.fyre_conn.reboot(name=cluster_name)

            logging.info("Fyre V1 request sent for VM reboot.")
            response = "Your Fyre V1 VM reboot has been initiated."

        elif vm_attributes["HARDWARE_TYPE"] == "Fyre V3":
            action = "reboot"
            response = CommonHelpers.action_fyre3_host(action, parsed_fqdn, event, command, command_args, cluster_name, user_email, Bot.log_details)

        else:
            raise CommonHelpers.NoHardwareAPIError("To reboot, please open a RIOT-Ticket")

    return response
