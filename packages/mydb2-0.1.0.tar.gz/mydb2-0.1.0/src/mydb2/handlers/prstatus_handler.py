import shlex
import sys
import logging
from mydb2.helpers import argparse_helper as argparse, help_command_strings as HelpStrings, common as CommonHelpers, my_authentication as Auth, github_helpers as github, db2_helpers, fyre_wrapper as fyre, Bot, bluepages_helper, slack_helpers




def handler(event, user_email, BOT):

    command = event["text"]
    split_command = command.split()
    logging.basicConfig(filename='slackbot.log', level=logging.INFO)

    if (len(split_command) < 2) or (split_command[1] == "help"):
        logging.info("-----------------\nTimestamp: " + event["ts"] + "\n" +
                     "Message: "  + command + "\n" +
                     "User Email: " + user_email + "\n-----------------")
        response = "```  {} ```".format(BOT.parsers["PRSTATUS"].format_help())
    else:
        # Authentication
        # Will raise UnauthorizedUserError if user is not a committer
        Auth.authenticate_committer(user_email)

        # Parse arguments from user command
        command_args = BOT.parsers["MAIN"].parse_known_args(shlex.split(command))[0]
        # log event
        logging.info("-----------------\nTimestamp: " + event["ts"] + "\n" +
                     "Message: " + command + "\n" +
                     "USER_EMAIL: " + user_email + "\n" +
                     "PR Number: " + str(command_args.pr_number) + "\n" +
                     "Status: " + command_args.status + "\n" +
                     "SLACK_CHANNEL_ID: " + event["channel"] + "\n" +
                     "-----------------")
        github.update_pr_check_status(int(command_args.pr_number),
                                      command_args.status, command_args.context)
        response = "PR check status update complete."

    return response
