import shlex
import sys
from mydb2.helpers import argparse_helper as argparse, help_command_strings as HelpStrings, common as CommonHelpers, my_authentication as Auth, github_helpers as github, db2_helpers, fyre_wrapper as fyre, Bot, bluepages_helper, slack_helpers
import logging
import os
import requests

def handler(event, user_email, BOT):
    command = event["text"]
    split_command = command.split()
    logging.basicConfig(filename='slackbot.log', level=logging.INFO)

    # Checks that the command received is a supported command
    if (len(split_command) < 2) or (split_command[1].lower() == "help"):
        logging.info("-----------------\nTimestamp: " + event["ts"] + "\n" +
                     "Message: "  + command + "\n" +
                     "User Email: " + user_email + "\n-----------------")
        response = "```  {} ```".format(BOT.parsers["BOOT"].format_help())
    else:
        # Parse arguments from user command
        command_args = BOT.parsers["MAIN"].parse_known_args(shlex.split(command))[0]
        logging.info(command_args)
        parsed_fqdn = CommonHelpers.parse_link_from_message(command_args.fqdn)
        broken_down_fqdn = CommonHelpers.breakdown_fqdn(command_args.fqdn)
        CommonHelpers.validate_machine_ownership(
            BOT.db2_conn,
            BOT.DB2_DEV_ENVIRONMENTS_TABLE,
            user_email,
            parsed_fqdn
        )

        vm_attributes = db2_helpers.get_vm_attributes(
            BOT.db2_conn,
            parsed_fqdn,
            BOT.DB2_DEV_ENVIRONMENTS_TABLE
        )
        if not vm_attributes["HARDWARE_TYPE"] in ["Fyre V1", "Fyre V3"]:
            raise CommonHelpers.NoHardwareAPIError("This VM is not a Fyre VM, and therefore does "
                                                   "not have this capability.")

        cluster_name = vm_attributes["CLUSTER_NAME"]

        #logging
        logging.info("-----------------\nTimestamp: " + event["ts"] + "\n" +
                     "Message: " + command + "\n" +
                     "FQDN: " + command_args.fqdn + "\n" +
                     "Cluster Name: " + cluster_name + "\n" +
                     "USER_EMAIL: " + user_email + "\n" +
                     "HOSTNAME_SUFFIX: " + broken_down_fqdn[1] + "\n" +
                     "SLACK_CHANNEL_ID: " + event["channel"] + "\n" +
                     "-----------------")

        logging.info("""Params passed to boot job:
                        USER_EMAIL: {}
                        HOSTNAME_SUFFIX: {}
                        NODENAME: {}
                        SLACK_CHANNEL_ID: {}
                        -----------------""".format(user_email,
                                                    broken_down_fqdn[1],
                                                    broken_down_fqdn[2],
                                                    event["channel"])
                    )
        logging.info("Cluster name parsed: {}".format(cluster_name))
        if vm_attributes["HARDWARE_TYPE"] == "Fyre V1":
            cluster_name = vm_attributes["CLUSTER_NAME"]
            BOT.fyre_conn.boot(name=cluster_name)
            logging.info("Fyre V1 request sent for VM boot.")
            response = "Your Fyre V1 VM boot has been initiated."

        elif vm_attributes["HARDWARE_TYPE"] == "Fyre V3":
            action = "boot"
            response = CommonHelpers.action_fyre3_host(action, parsed_fqdn, event, command, command_args, cluster_name, user_email, Bot.log_details)

        else:
            raise CommonHelpers.NoHardwareAPIError("To boot, please open a RIOT-Ticket")

    return response
