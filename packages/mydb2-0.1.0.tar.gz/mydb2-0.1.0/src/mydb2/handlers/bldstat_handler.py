'''
 BLDSTAT Command
'''
import sys
import os
import shlex
from mydb2.helpers import argparse_helper as argparse, help_command_strings as HelpStrings, common as CommonHelpers, my_authentication as Auth, github_helpers as github, db2_helpers, fyre_wrapper as fyre, Bot, bluepages_helper, slack_helpers, bldstat_helper


DEFAULT_BUILDS_LIMIT = 15

def _initialize_parser():
    '''
     Parser for the bldstat command.
    '''
    bldstat_parser = argparse.ArgumentParser(
        description='Get information on db2 builds and their statuses',
        prog='bldstat',
        conflict_handler='resolve',
        add_help=False
    )

    bldstat_parser.add_argument(
        '-i',
        '--build-id',
        dest='build_id',
        type=int,
        help='Build ID.',
        required=False
    )
    bldstat_parser.add_argument(
        '-a',
        '--build-author',
        dest='author',
        help='Build author.',
        required=False
    )
    bldstat_parser.add_argument(
        '-t',
        '--build-type',
        dest='build_type',
        choices=['cust',
                 'debug'],
        help='Build type, customer vs debug.',
        required=False
    )
    bldstat_parser.add_argument(
        '--build-signature',
        dest='signature',
        help='Build signature.',
        required=False
    )
    bldstat_parser.add_argument(
        '--level',
        dest='level',
        help='Build level.',
        required=False
    )
    bldstat_parser.add_argument(
        '--build-source',
        dest='source',
        choices=['dev', 'pr', 'ci', 'prod', 'sb', 'pr-sb', 'pr-sb-prod'],
        help='Where the build was built.',
        required=False
    )
    bldstat_parser.add_argument(
        '--platform',
        dest='platform',
        choices=['aix32',
                 'aix64',
                 'linux390',
                 'linux390x64',
                 'linuxamd64',
                 'linuxia32',
                 'linuxia64',
                 'linuxppc32',
                 'linuxppc64',
                 'linuxppc64le',
                 'nt32',
                 'ntx64',
                 'darwin64'],
                help='Build platform.',
                required=False
    )
    bldstat_parser.add_argument(
        '--project',
        dest='project',
        help='Build project.',
        required=False
    )
    bldstat_parser.add_argument(
        '--operating-system',
        dest='OS',
        help='Build operating system.',
        required=False
    )
    bldstat_parser.add_argument(
        '--git-repo',
        dest='git_repo',
        help='Github repo where the build code resides.',
        required=False
    )
    bldstat_parser.add_argument(
        '--git-branch',
        dest='git_branch',
        help='Github branch the build was based from.',
        required=False
    )
    bldstat_parser.add_argument(
        '--file-path',
        dest='file_path',
        help='Path to build file.',
        required=False
    )
    bldstat_parser.add_argument(
        '--file-repo',
        dest='file_repo',
        help='Which artifactory repo the build was uploaded to.',
        choices=['db2-private', 'db2-public'],
        required=False
    )
    bldstat_parser.add_argument(
        '--commit-id',
        dest='commit_id',
        help='ID of the build commit in github.',
        required=False
    )
    bldstat_parser.add_argument(
        '--pr-number',
        dest='pr_number',
        type=int,
        help='Pull request number to reference in github.',
        required=False
    )
    bldstat_parser.add_argument(
        '--stage',
        dest='stage',
        help='Filter builds by a stage that has been reached. This includes builds that have moved on to other stages(packaging, etc).'
    )
    bldstat_parser.add_argument(
        '--status',
        dest='status',
        default='success',
        choices=['success', 'failure', 'pending', 'running'],
        help=('The status of the --stage that is filtered by. This option is ignored if the '
              '`--stage` option is not specified. If no `--status` is specified, the default value'
              ' is "success"')
    )
    bldstat_parser.add_argument(
        '--all-statuses',
        dest='all_statuses',
        action='store_true',
        help='Show all statuses for the resulting build.'
             'Only applies when there is only 1 build returned.'
    )
    bldstat_parser.add_argument(
        '--all-files',
        dest='all_files',
        action='store_true',
        help='Show all files for the resulting build.'
             'Only applies when there is only 1 build returned.'
    )
    bldstat_parser.add_argument(
        '-l',
        '--limit',
        type=int,
        dest='limit',
        default=DEFAULT_BUILDS_LIMIT,
        help='Limit the number of builds returned.'
             'By default, bldstat will return the latest {} builds.'.format(DEFAULT_BUILDS_LIMIT)
    )
    bldstat_parser.add_argument(
        '--bigsql-version',
        dest='bigsql_version',
        help='Version of BigSQL associated with the engine.',
        required=False
    )

    return bldstat_parser

PARSER = _initialize_parser()
BLDSTAT_API_INSTANCE = bldstat_helper.BldstatsAPI(os.environ.get('GH_PERSONAL_ACCESS_TOKEN'))
VALID_BUILD_STATUS_FIELDS = ['build_id',
                             'stage',
                             'stage_status',
                             'status_timestamp',
                             'additional_status_info']
VALID_BUILD_FILE_FIELDS = ['build_id',
                           'file_name',
                           'file_path',
                           'file_repo',
                           'file_checksum',
                           'file_timestamp',
                           'additional_file_info']
CRITICAL_COLUMNS = ['BUILD_ID',
                    'PROJECT',
                    'PLATFORM',
                    'LEVEL',
                    'COMMIT_ID',
                    'PUBLISH_DATE',
                    'STAGE']

def handler(event, user_email, bot):
    '''
     Handler for all bldstat commands.
     Params:
        - event: The event returned from the slack RTM api
        - user_email: email of the user who submitted the command
        - bot: Bot instance that holds some program-wide constants.
    '''

    command = event["text"]
    split_command = command.split()
    response_statuses = None
    response_files = None

    if (len(split_command) > 1) and (split_command[1] == "help"):
        ### Universal Logging bot-wide
        Bot.log_event(user_email, event)
        response_builds = "```{}```".format(PARSER.format_help())
    else:
        # Parse arguments from user command
        command_args = PARSER.parse_args(shlex.split(command)[1:])
        args_dict = command_args.__dict__
        if command_args.author:
            args_dict['author'] = CommonHelpers.parse_email(args_dict['author'])

        ### Universal Logging bot-wide
        Bot.log_event(user_email, event, args_dict)

        bldstat_result = BLDSTAT_API_INSTANCE.get_build_info(args_dict)['builds']
        note = ""

        response_builds = "```{}```".format(
            bldstat_helper.print_builds_list(bldstat_result, CRITICAL_COLUMNS)
        )

        if args_dict["all_statuses"]:
            if len(bldstat_result) != 1:
                note += "\nBy default, only the latest {} builds are ".format(DEFAULT_BUILDS_LIMIT)
                note += "shown. To change this behaviour, try using the -l/--limit option."
                note += "\nYou may only print all statuses when only 1 build is fetched."
                note += " Try filtering by -i/--build-id."
            else:
                # Store the retrieved results in a separate var then delete them from the
                # results so that they don't print with the build info
                statuses = bldstat_result[0]['statuses']
                del bldstat_result[0]['statuses']

                res = bldstat_helper.print_builds_list(bldstat_result, CRITICAL_COLUMNS)
                res += "\n"
                response_statuses = '```{}```'.format(
                    bldstat_helper.print_aux_list(statuses, VALID_BUILD_STATUS_FIELDS)
                )

        if args_dict["all_files"]:
            if len(bldstat_result) != 1:
                note += "\nBy default, only the latest {} builds are ".format(DEFAULT_BUILDS_LIMIT)
                note += "shown. To change this behaviour, try using the -l/--limit option."
                note += "\nYou may only print all files when only 1 build is fetched."
                note += " Try filtering by -i/--build-id."
            else:
                # Store the retrieved results in a separate var then delete them from the
                # results so that they don't print with the build info
                files = bldstat_result[0]['files']
                del bldstat_result[0]['files']

                res = bldstat_helper.print_builds_list(bldstat_result, CRITICAL_COLUMNS)
                res += "\n"
                response_files = '```{}```'.format(
                    bldstat_helper.print_aux_list(files, VALID_BUILD_FILE_FIELDS)
                )

        else:
            note += "\nBy default, only the latest {} builds are ".format(DEFAULT_BUILDS_LIMIT)
            note += "shown. To change this behaviour, try using the -l/--limit option."

            if len(bldstat_result) > 1:
                note += "\nFor more details on a specific build, "
                note += "use `-i/--build-id <BUILD_ID>` to filter by build name"

        response_builds += note

    #response = '``` ```'.join(response[i:i+3900] for i in range(0, len(response), 3900))

    return [response_builds, response_statuses, response_files]
