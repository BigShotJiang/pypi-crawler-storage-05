import shlex
import sys
from mydb2.slavectl import slavectl as slavectl_util
from mydb2.helpers import my_authentication as Auth
import logging



def handler(event, user_email, BOT):
    command = event["text"]
    split_command = command.split()
    logging.basicConfig(filename='slackbot.log', level=logging.INFO)


    # Checks that the command received is a supported command
    if (len(split_command) < 2) or split_command[1] == "help":
        logging.info("""-----------------
                     Timestamp: {}
                     Message: {}
                     User Email: {}""".format(event["ts"], command, user_email))

        response = "``` {} \n```".format(BOT.parsers["REGR"].format_help())
    elif (len(split_command) < 2) or split_command[1] == "deploy":
        # IF HELP MESSAGE
        if (len(split_command) < 3) or (split_command[2] == "help"):
            logging.info("""-----------------
                         Timestamp: {}
                         Message: {}
                         User Email: {}""".format(event["ts"], command, user_email))

            response = "``` {} \n```".format(BOT.parsers["REGR_DEPLOY"].format_help())

        else:
            # AUTHENTICATION
            # Will raise UnauthorizedUserError if the user is not authorized
            Auth.authenticate_slave_creator(user_email)

            # Parse arguments from user command
            command_args = BOT.parsers["MAIN"].parse_known_args(shlex.split(command))[0]

            # Override Zlinux specific product group
            if command_args.platform == "zlinux":
                product_group = "Db2 - LUWonZ"
            else:
                product_group = command_args.product_group
            # product_group = command_args.product_group

            if product_group == "Db2 - Infrastructure":
                name_prefix = "db2i-" + command_args.name
            else:
                name_prefix = command_args.name

            # log event
            logging.info("-----------------\nTimestamp: " + event["ts"] + "\n" +
                         "USER_EMAIL: " + user_email + "\n" +
                         "COUNT: " + str(command_args.count) + "\n" +
                         "PLATFORM: " + command_args.platform + "\n" +
                         "OS: " + command_args.operating_system + "\n" +
                         "VM_SIZE: " + command_args.vm_size.lower() + "\n" +
                         "START_INDEX: " + str(command_args.start_index) + "\n" +
                         "SLACK_CHANNEL_ID: " + event["channel"] + "\n" +
                         "CODEBASE: " + command_args.codebase + "\n" +
                         "GIVEN NAME: " + name_prefix + "\n" +
                         "PRODUCT_GROUP: {}\n".format(product_group) +
                         "SITE: {}\n".format(command_args.deployment_site) +
                         "-----------------")



            logging.debug("Calling slave creation script...")
            response = slavectl_util.deploy_slaves(JENKINS_CONNECTION=BOT.jenkins_conn.jenkins_conn,
                                                   platform=command_args.platform,
                                                   operating_system=command_args.operating_system,
                                                   size=command_args.vm_size,
                                                   name_prefix=name_prefix,
                                                   count=command_args.count,
                                                   codebase=command_args.codebase,
                                                   starting_index=command_args.start_index,
                                                   slack_thread_id=event["channel"],
                                                   test=command_args.test_slave,
                                                   site=command_args.deployment_site,
                                                   product_group_name=product_group)

    # Return the response that is generated in the selected command
    return response
