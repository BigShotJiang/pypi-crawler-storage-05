'''
 The `user` tool suite provides a handful of admin tools to the Db2 git pilot admins that allow
 the admins to:
    1) Onboard a new user to the pilot
    2) Remove a user from the pilot
    3) Bump(increment) a user's quota
    4) Set a user's quota to a custom account
'''
from mydb2.helpers import bluepages_helper as bluepages, argparse_helper as argparse, help_command_strings as HelpStrings, common, my_authentication as Auth, github_helpers as github, db2_helpers, fyre_wrapper as fyre, Bot, bluepages_helper, slack_helpers, users_helper
import shlex
from mydb2.utils import find_slack
import logging
BOT_INSTANCE = Bot.BotModel()
DEVELOPERS_TABLE = BOT_INSTANCE.DB2_DEV_USERS_TABLE

def _initialize_parser():
    '''
     Parser for the onboard command.
    '''

    user_main_parser = argparse.ArgumentParser(
        description='Pilot user management command.',
        add_help=False,
        conflict_handler='resolve'
    )
    user_subparsers = user_main_parser.add_subparsers(
        help='Available Tools',
        dest='user_subcommand'
    )

    '''
    ########################################
    ############# SUBCOMMANDS ##############
    ########################################
    '''

    '''
    ####################
    ##### ONBOARD ######
    ####################
    '''
    onboard_parser = user_subparsers.add_parser(
        'onboard',
        prog='onboard',
        description='Onboard users to the Db2 git pilot.',
        help='For usage documentation, message "user onboard help"',
        add_help=False
    )

    ###
    # Required options
    ###
    required_onboard_options = onboard_parser.add_argument_group('REQUIRED arguments')
    required_onboard_options.add_argument(
        '-e',
        '--user-emails',
        dest='user_emails',
        required=True,
        help='A comma separated list of the emails of all the users to be onboarded to Git.'
    )

    ###
    # Optional options
    ###
    optional_onboard_options = onboard_parser.add_argument_group('OPTIONAL arguments')
    optional_onboard_options.add_argument(
        '-q',
        '--dev-env-quota',
        dest='quota',
        help='Quota to assign to this user. Defaults to 5.',
        default=5,
        type=argparse.check_whole_number,
        required=False
    )
    optional_onboard_options.add_argument(
        '-d',
        '--domain',
        dest='domain',
        type=db2_development_domain,
        help='The db2 domain this pilot member belongs to.',
        required=False
    )

    '''
    ####################
    ###### REMOVE ######
    ####################
    '''
    remove_parser = user_subparsers.add_parser(
        'remove',
        prog='remove',
        description='Remove users from the Db2 git pilot.',
        help='Not yet implemented.',
  #      help='For usage documentation, message "user remove help"',
        add_help=False
    )
    ###
    # Required options
    ###
    required_remove_options = remove_parser.add_argument_group('REQUIRED arguments')
    required_remove_options.add_argument(
        '-e',
        '--user-email',
        dest='user_email',
        required=True,
        help='The email of the user to remove.'
    )

    '''
    ####################
    ##### setquota #####
    ####################
    '''
    setquota_parser = user_subparsers.add_parser(
        'setquota',
        prog='setquota',
        description="Set a user's quota to a custom amount.",
        # help='For usage documentation, message "user setquota help"',
        help='Not yet implemented.',
        add_help=False
    )

    '''
    ####################
    ##### getquota #####
    ####################
    '''
    setquota_parser = user_subparsers.add_parser(
        'getquota',
        prog='getquota',
        description="Get a user's quota.",
        # help='For usage documentation, message "user getquota help"',
        help='Not yet implemented.',
        add_help=False
    )

    '''
    ####################
    #### bumpquota #####
    ####################
    '''
    bumpquota_parser = user_subparsers.add_parser(
        'bumpquota',
        prog='bumpquota',
        description="Increment a user's dev env quota.",
        # help='For usage documentation, message "user bumpquota help"',
        help='Not yet implemented.',
        add_help=False
    )

    '''
    ####################
    ###### lookup ######
    ####################
    '''
    lookup_parser = user_subparsers.add_parser(
        'lookup',
        prog='lookup',
        description="Find user's ID across services using 1 service ID",
        help='For usage documentation, message "user lookup help"',
        add_help=False
    )

    ###
    # Required options
    ###
    required_lookup_options = lookup_parser.add_argument_group('REQUIRED arguments')

    required_lookup_options.add_argument(
        '-t',
        '--lookup-type',
        dest='lookup_type',
        choices=['email', 'markham-ldap', 'git-user'],
        required=True,
        help='The type of lookup keys being supplied'
    )
    required_lookup_options.add_argument(
        '-k',
        '--keys',
        dest='user_keys',
        nargs='+',
        required=True,
        help=('A list of the keys used to lookup the users. ie list of emails/IDs/etc separated'
              'by a space')
    )

    required_lookup_options.add_argument(
        '-a',
        '--attributes',
        dest='attributes',
        nargs='+',
        choices=['slack-user', 'git-user', 'email', 'markham-ldap'],
        required=True,
        help='A list of the user attributes to be fetched about this user. Separated by a space'
    )


    ###
    # Optional options
    ###
    optional_lookup_options = lookup_parser.add_argument_group('OPTIONAL arguments')
    optional_lookup_options.add_argument(
        '--no-formatting',
        dest='no_formatting',
        help='Flag to skip the table formatting for the results',
        action='store_true',
        required=False
    )
    optional_lookup_options.add_argument(
        '-d',
        '--delimiter',
        dest='delimiter',
        help='Delimiter of returned results IF `--no-formatting` is passed in',
        default=', ',
        required=False
    )

    return {
        "USER": user_main_parser,
        "ONBOARD": onboard_parser,
        "REMOVE": remove_parser,
        "SETQUOTA": setquota_parser,
        "BUMPQUOTA": bumpquota_parser,
        "LOOKUP": lookup_parser
    }

def db2_development_domain(domain_team):
    '''
     This function validates the given github domain to ensure that such team exists
    '''
    if domain_team not in VALID_GIT_DOMAIN_TEAMS:
        raise TypeError("{} is an invalid Github team for a Db2"
                        "development domain.".format(domain_team))
    return domain_team

PARSER = _initialize_parser()
VALID_USER_SUBCOMMANDS = ["onboard", "remove", "setquota", "bumpquota", 'lookup']
VALID_GIT_DOMAIN_TEAMS = [
    'domain-ai-database',
    'domain-availability',
    'domain-bigsql',
    'domain-bigsql-DV',
    'domain-build',
    'domain-catalog-services',
    'domain-cde-storage',
    'domain-client',
    'domain-cloud',
    'domain-connectivity-and-extenders',
    'domain-containerization',
    'domain-content',
    'domain-dataManagement',
    'domain-datamanagement-bps-db2dart',
    'domain-datamanagement-dms-xml',
    'domain-datamanagement-dmu-amt',
    'domain-datamanagement-ixm-mdc-atm-abp',
    'domain-datamanagement-bps-db2dart',
    'domain-datamanagement-oss',
    'domain-datamanagement-pd',
    'domain-db2-graph',
    'domain-db2-rest',
    'domain-db2family-products',
    'domain-db2rest',
    'domain-deployment',
    'domain-dv',
    'domain-federation',
    'domain-fvt',
    'domain-infrastructure',
    'domain-ml-indatabase',
    'domain-ml-optimizer',
    'domain-nlv',
    'domain-optimizer-qrw',
    'domain-pmodel-wlm',
    'domain-pqa',
    'domain-purescale',
    'domain-release',
    'domain-replication',
    'domain-runtime',
    'domain-sap',
    'domain-security',
    'domain-sirius',
    'domain-sqlcompatibility',
    'domain-support',
    'domain-svt',
    'domain-ui',
    'domain-wh-console'
]
USERS_API_INSTANCE = users_helper.UsersAPI()

def slack_updates(email):
    slack_channel = find_slack.get_channel_id_from_email(email)
    if not slack_channel:
        warning_text = "`WARNING`: Could not find a Slack channel for {}. ".format(email)
        warning_text += "Please ensure that the user has a Slack account.\n"
        Bot.log("WARNING", "Could not find a Slack channel for {}.".format(email))
    else:
        Bot.log("INFO", "Found Slack channel for {}: {}".format(email, slack_channel))
    find_slack.update_dev_db(
            email,
            slack_channel
        )

def handler(event, user_email, bot):
    '''
     This function will handle the user command. It will call the appropriate function to handle the
     request based on the subcommand provided.
    '''

    def onboard(command_args):
        '''
         This function will handle the onboard command and perform all the needed steps to add a
         user to the db2 git pilot. These steps include:
            1) Adding that user to the git_pilot github team
            2) Adding that user into the developers table and giving them dev env quota
            3) Adding that user to the appropriate artifactory bluegroups so the user may view/push
               builds in artifactory
         Parameters:
            - emails_to_onboard :list: - list of emails to be onboarded
            - user_quota :int: - the amount of quota to give the emails being onboarded
            - user_domain :string: - the db2 development domain of the users to be onboarded
        '''
        # AUTHENTICATION
        # Will raise UnauthorizedUserError if the user is not authorized
        Auth.authenticate_pilot_admin(user_email)

        warning_text = ""
        results = ""
        #log_event(user_email, event, parsed_arguments_dict=command_args.__dict__)


        emails_to_onboard = []
        for unparsed_email in command_args.user_emails.split(','):
            emails_to_onboard.append(common.parse_email(unparsed_email))
        Bot.log("INFO", "Emails to onboard: {}.".format(emails_to_onboard))

        if not command_args.domain:
            warning_text += ("`WARNING`: You haven't specified a domain. Please ensure that you add"
                             " this user to the appropriate domain team in Github.\n")
        for email_to_onboard in emails_to_onboard:
            try:
                Bot.log("INFO", "Adding user to the pilot github team.")
                # Add the user to the git_pilot github team
                github.add_user_to_git_pilot(email_to_onboard)
                Bot.log("INFO", "User added to github team.")
                if command_args.domain:
                    Bot.log("INFO", "Adding user to the {} domain.".format(command_args.domain))
                    github.add_user_to_team(email_to_onboard, command_args.domain)
                    Bot.log("INFO", "User added to github team.")

                # this function will check if the user is in the developers
                # table and insert them into if it not.
                Bot.log("INFO", db2_helpers.insert_into_developers_table(BOT_INSTANCE.db2_conn,
                                                                         DEVELOPERS_TABLE,
                                                                         email_to_onboard.lower(),
                                                                         command_args.quota))

                Bot.log("INFO", "Adding user bluegroups.")
                bluepages.add_user_to_git_pilot_bluegroups(email_to_onboard)
                Bot.log("INFO", "User added to the bluegroups.")
                results += "{} has been onboarded successfully.\n".format(email_to_onboard)

                Bot.log("DEBUG", "User onboarded successfully.")
                slack_updates(email_to_onboard)
            except Exception as e:
                results += f"`ERROR` Failed to onboard {email_to_onboard}. Exception: {str(e)}\n"
                Bot.log("ERROR", f"Failed to onboard {email_to_onboard}. Exception: {str(e)}")

        return warning_text + results

    def remove():
        pass
    def setquota():
        pass
    def getquota():
        pass
    def bumpquota():
        pass
    def lookup(command_args):
        Bot.log("INFO", "Looking up user.")
        lookup_results = []
        parsed_keys = []

        print(str(command_args.attributes))
        for key in command_args.user_keys:
            parsed_key = common.parse_email(key)
            parsed_keys.append(parsed_key)

            lookup_results.append(USERS_API_INSTANCE.lookup_user(
                command_args.lookup_type,
                parsed_key,
                command_args.attributes
            ))

        if command_args.no_formatting:
            return users_helper.print_lookup_results(
                lookup_results,
                command_args.attributes,
                command_args.delimiter
            )

        return users_helper.pretty_print_lookup_results(
            lookup_results,
            command_args.attributes,
            parsed_keys
        )

    command = event["text"]
    split_command = command.split()
    subhandlers = {
        "onboard": onboard,
        "remove": remove,
        "setquota": setquota,
        "getquota": getquota,
        "bumpquota": bumpquota,
        "lookup": lookup
    }

    # Checks that the command received is a supported command
    if ((len(split_command) < 2) or
            (split_command[1].lower() == "help") or
            (split_command[1] not in VALID_USER_SUBCOMMANDS)):
        Bot.log("INFO", "Event logged.")
        response = "``` {} \n```".format(PARSER["USER"].format_help())
    elif (len(split_command) < 3) or (split_command[2].lower() == "help"):
        response = "``` {} \n```".format(PARSER[split_command[1].upper()].format_help())
    else:
        command_args = PARSER[split_command[1].upper()].parse_known_args(shlex.split(command))[0]

        Bot.log("INFO", "Event logged.")
        response = subhandlers[split_command[1]](command_args)

    return response
