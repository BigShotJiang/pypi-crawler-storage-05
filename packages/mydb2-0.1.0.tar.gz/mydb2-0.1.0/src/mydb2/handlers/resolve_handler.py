"""
Handler for the 'resolve' command.
"""
import shlex
import argparse
from mydb2.helpers import argparse_helper as argparse, help_command_strings as HelpStrings, common as CommonHelpers, my_authentication as Auth, github_helpers as github, db2_helpers, fyre_wrapper as fyre, Bot, bluepages_helper, slack_helpers

# Initialize the argument parser
def _initialize_parser():
    parser = argparse.ArgumentParser(
        prog="resolve",
        description="Mark outstanding failures as resolved by removing them from the database.",
        add_help=False,
        conflict_handler="resolve"
    )

    parser.add_argument(
        "-f",
        "--failure-ids",
        dest="failure_ids",
        #nargs="+",
        required=False,
        metavar="FAILURE_ID_LIST",
        help="A comma-separated list of failure IDs to resolve. Example: 'id1,id2,id3'."
    )

    parser.add_argument(
        "-g",
        "--group-id",
        dest="group_id",
        required=False,
        metavar="GROUP_ID_LIST",
        help="A comma-separated list of group IDs to resolve. Example: 'group1,group2'."
    )

    return parser

PARSER = _initialize_parser()

def handler(event, user_email, bot_model):
    """
    Processes the 'resolve' command.

    Args:
        event (dict): The Slack event data.
        user_email (str): The email of the user issuing the command.
        bot_model (BotModel): The bot model instance.

    Returns:
        str: Response message to be sent back to the user.
    """
    command = event["text"]
    split_command = command.split()
    results = ""

    # Checks that the command received is a supported command
    if (len(split_command) < 2) or (split_command[1].lower() == "help"):
        Bot.log_event(user_email, event)
        results = "``` {} \n```".format(PARSER.format_help())
    else:
        # AUTHENTICATION
        # Will raise UnauthorizedUserError if the user is not authorized
        Auth.authenticate_pilot_admin(user_email)

        # Parse the arguments using argparse
        try:
            command_args = PARSER.parse_known_args(shlex.split(command))[0]
        except argparse.ArgumentParserError as e:
            return f"Error parsing arguments: {str(e)}"

        results = ""

        # Update the handler logic to handle both groupID and failureIDs
        if command_args.group_id:
            group_ids = [gid.strip() for gid in command_args.group_id.split(',')]
            for group_id in group_ids:
                try:
                    if db2_helpers.validate_group_id(bot_model.db2_conn, group_id):
                        db2_helpers.remove_failures_by_group_id(bot_model.db2_conn, group_id)
                        results += f"All failures associated with Group ID {group_id} have been successfully resolved.\n"
                    else:
                        results += f"Group ID {group_id} does not exist in the database.\n"
                except Exception as e:
                    results += f"Failed to resolve Group ID {group_id}: {str(e)}\n"

        if command_args.failure_ids:
            failure_ids = [fid.strip() for fid in command_args.failure_ids.split(',')]
            for failure_id in failure_ids:
                try:
                    if db2_helpers.validate_failure_id(bot_model.db2_conn, failure_id):
                        db2_helpers.remove_failure(bot_model.db2_conn, failure_id)
                        results += f"Failure ID {failure_id} has been successfully resolved.\n"
                    else:
                        results += f"Failure ID {failure_id} does not exist in the database.\n"
                except Exception as e:
                    results += f"Failed to resolve Failure ID {failure_id}: {str(e)}\n"

    return results
