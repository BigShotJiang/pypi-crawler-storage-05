from mydb2.helpers import help_command_strings as BotStrings


def handler(event, user_email, bot):
    return BotStrings.GENERIC_HELP_MESSAGE
