import shlex
import argparse
import sys
from prettytable import PrettyTable
import logging
from mydb2.helpers import db2_helpers, Bot, common
import os
import re
import requests

JUMPBOX_LIST = os.environ.get('JUMPBOXES')

VALID_VM_DETAILS = [
    'site_name',
    'platform',
    'privateip',
    'publicip',
    'state',
    'status',
    'memory',
    'cpu'
]

def prettify_vm_details(vm_details, valid_columns=VALID_VM_DETAILS):
    response = PrettyTable(padding_width=5)
    response.field_names = ['Machine Detail', 'Value']
    response.title = ("Machine Info")

    for key in vm_details:
        if key in valid_columns:
            response.add_row([key, vm_details[key]])

    response = "```\n" + response.get_string() + "\n```"

    return response

def _initialize_parser():
    tmp_list_parser = argparse.ArgumentParser(
        description='List all your VMs or the details of a specific VM.',
        add_help=False,
        prog='list',
        conflict_handler='resolve'
    )
    tmp_list_parser.add_argument('-f',
                                 '--fqdn',
                                 dest='fqdn',
                                 help='Specify a vm to get detailed information on.',
                                 type=str,
                                 required=False)
    return tmp_list_parser


LIST_PARSER = _initialize_parser()

def handler(event, user_email, BOT):
    command = event["text"]
    split_command = command.split()
    logging.basicConfig(filename='slackbot.log', level=logging.INFO)
    args = LIST_PARSER.parse_known_args(shlex.split(command))[0]
    parsed_fqdn = common.parse_link_from_message(args.fqdn)


    #logging
    logging.info("-----------------\nTimestamp: " + event["ts"] + "\n" +
                 "Message: " + command + "\n" +
                 "USER_EMAIL: " + user_email + "\n" +
                 "SLACK_CHANNEL_ID: " + event["channel"] + "\n" +
                 "-----------------")

    # Checks that the command received is a supported command
    if (len(split_command) > 1) and (split_command[1].lower() == "help"):
        response = "``` {} \n```".format(LIST_PARSER.format_help())
    else:
        if args.fqdn:
            vm_attributes = db2_helpers.get_vm_attributes(
                BOT.db2_conn,
                parsed_fqdn,
                BOT.DB2_DEV_ENVIRONMENTS_TABLE
            )
            print(f"attr: {vm_attributes}")
            if not vm_attributes["HARDWARE_TYPE"] == "Fyre V1":
                raise common.NoHardwareAPIError("This VM is not a Fyre VM, and therefore does not "
                                                "have this capability.")

            cluster_name = vm_attributes["CLUSTER_NAME"]
            print(f"cname: {cluster_name}")
            machine_details = BOT.fyre_conn.info(cluster_name)[0]

            response = prettify_vm_details(machine_details)
        else:
            all_user_vms = db2_helpers.list_by_owner(
                BOT.db2_conn,
                BOT.DB2_DEV_ENVIRONMENTS_TABLE,
                user_email
            )

            response = PrettyTable(padding_width=5)
            response.field_names = ['Machine', 'VM State', 'Deploy Status', 'Machine Type', 'OS']
            response.title = ("Number of Machines: {}     Quota: {}".format(
                str(len(all_user_vms)),
                str(db2_helpers.get_user_machine_quota(BOT.db2_conn,
                                                       BOT.DB2_DEV_USERS_TABLE,
                                                       user_email))
            ))
            display_jumpbox = False
            
            if all_user_vms:
                for vm in all_user_vms:
                    vm_state = None
                    deploy_status = vm["DEPLOY_STATUS"]
                    machinetype = None

                    if re.search(r'-cc-dev', vm["FQDN"]) or re.search(r'db2lnx-git-v115', vm["FQDN"]) or re.search(r'db2ppcle-git-v115', vm["FQDN"]) or re.search(r'db2zlinux-git-v115', vm["FQDN"]):
                        display_jumpbox = True
                        vm_state = "N/A"
                        response.add_row([
                            vm["FQDN"],
                            vm_state,
                            deploy_status,
                            'Alcatraz',
                            vm["OS"]
                        ])
                    else:
                        if deploy_status == "Success" and vm["HARDWARE_TYPE"] == "Fyre V1":
                            vm_state = BOT.fyre_conn.info(vm["CLUSTER_NAME"])[0]["state"]
                            machinetype = "Regular Fyre"

                        elif deploy_status == "Success" and vm["HARDWARE_TYPE"] == "Fyre V3":
                            machinetype = "Special Fyre Lease"
                            api_url = "https://ocpapi.svl.ibm.com/v1/vm/{}/status".format(vm["FQDN"])
                            # Retrieve the API token from environment variables
                            api_token = os.getenv("FYRE_API_KEY")
                            if not api_token:
                                logging.error("Fyre API token is not set in environment variables.")
                                return "Fyre API token is missing. Please contact support."

                            # Basic authentication credentials
                            auth = ("db2-infra", api_token)
                            vm_state = requests.get(api_url, auth=auth, verify=False).json().get("last_os_state", "Unknown")

                        response.add_row([
                            vm["FQDN"],
                            vm_state,
                            deploy_status,
                            machinetype or vm["HARDWARE_TYPE"],
                            vm["OS"]
                        ])
            
            response.sortby = "Machine Type"

            if display_jumpbox:
                response = "```\n" + response.get_string() + "\n\nOne or more of the machines in your list is a Git/ClearCase (CC) based machine in the Alcatraz environment." \
                        "\nTo access these machines, you must first log in with your LDAP ID to one of the jumpboxes," \
                        "\nthen ssh from the jumpbox to your reserved Alcatraz machine. \n\nAlcatraz Jumpboxes: " + JUMPBOX_LIST + "\n```"
            else:
                response = "```\n" + response.get_string() + "\n```"

    return response
