'''
    An interface that allows Db2 RIOT to manage(deploy/destroy) slaves with ease.
'''
#!/usr/bin/env python
import os
import argparse
import sys
import requests # for the Validate cluster names function
from jenkinsapi.jenkins import Jenkins


# JENKINS constants
JENKINS_API_TOKEN = os.environ['JENKINS_API_TOKEN']
JENKINS_API_EMAIL = os.environ['W3_ID']
JENKINS_URL = "https://hyc-db2-riot-jenkins.swg-devops.com"
DEPLOYMENT_JOB_NAME = "RIOT_Deploy_Slave"

class ClusterNameUnavailable(Exception):
    '''
     Error to throw if a clustername isn't available in Fyre
    '''
    pass


def initialize_parser():
    '''
     Define parser for cli tool. Used in __main__ but can also be used in any interface
     that uses this tool
    '''

    # Instantiate the argument parser for deploy commands
    tmp_main_parser = argparse.ArgumentParser(description='Tool to manage Db2 RIOT slaves.')

    subparsers = tmp_main_parser.add_subparsers(help='Command parser', dest='command')
    tmp_deploy_parser = subparsers.add_parser('deploy',
                                              prog='deploy',
                                              description='Tool to deploy Db2 RIOT slaves autonomously.',
                                              help='Deploy help')

    tmp_deploy_parser.add_argument('-c',
                                   '--count',
                                   dest='count',
                                   default=1,
                                   type=_check_positive,
                                   required=False,
                                   help='The number of instances to deploy with this configuration.')
    tmp_deploy_parser.add_argument('-i',
                                   '--start-index',
                                   dest='start_index',
                                   default=1,
                                   type=_check_positive,
                                   required=False,
                                   help='The index at which to start enumerating.')
    tmp_deploy_parser.add_argument('-p', '--platform',
                                   dest='platform',
                                   help='VM platform. Defaults to x86. Enter x64 for Windows, power for power, and zlinux for zlinux.',
                                   default='x86',
                                   choices=['x86', 'x64', 'power', 'zlinux'],
                                   required=False)
    tmp_deploy_parser.add_argument('-o',
                                   '--operating-system',
                                   dest='operating_system',
                                   help='OS for dev environment. Default is RHEL 7.5. See list of accepted options here: https://fyre.ibm.com/help#fyre-os',
                                   default='Redhat 7.5',
                                   required=False)
    tmp_deploy_parser.add_argument('-n',
                                   '--name',
                                   dest='name',
                                   help='Name prefix of slave group. Each slave will be appended by a number ranging from 1 to <count>',
                                   required=True)
    tmp_deploy_parser.add_argument('-s',
                                   '--size',
                                   dest='vm_size',
                                   help='VM Size.',
                                   default='l',
                                   choices=['s', 'm', 'l', 'x'],
                                   required=False)
    tmp_deploy_parser.add_argument('--codebase',
                                   dest='codebase',
                                   help='Codebase for slave.',
                                   default='git',
                                   choices=['cc', 'git'],
                                   required=False)
    tmp_deploy_parser.add_argument('--test',
                                   dest='test_slave',
                                   help='Should this slaves be registered in the slave db.',
                                   default='yes',
                                   choices=['yes', 'no'],
                                   required=False)
    tmp_deploy_parser.add_argument('--slack-thread-id',
                                   dest='slack_thread_id',
                                   help='Slack ID to send notify when updates are available.',
                                   default='',
                                   required=False)

    return (tmp_main_parser,
            tmp_deploy_parser)


def _check_positive(value):
    ivalue = int(value)
    if ivalue <= 0:
        raise argparse.ArgumentTypeError("%s is an invalid positive int value" % value)
    return ivalue

def validate_cluster_names(given_name, codebase, count):
    '''
        This functions queries the clustername against the fyre backend to see if the name passed
        is valid
    '''

    count = int(count)

    print("Validating slave clusternames:")
    for i in range(1, count+1):
        name_to_check = "{}-{}-{}".format(given_name, codebase, str(i))
        request_endpoint = "https://fyre.svl.ibm.com/embers/checkprefix?prefix={}".format(name_to_check)
        response = requests.get(request_endpoint)
        print("{}...{}".format(name_to_check, response.content))
        if response.content == "no":
            raise ClusterNameUnavailable("That cluster name is taken. Please try a different one.")

    return True

def deploy_slaves(JENKINS_CONNECTION, platform, operating_system, size, name_prefix, count, starting_index, codebase, slack_thread_id, test, product_group_name):
    #validate_cluster_names(name_prefix, codebase, count)

    return_string = ""

    # Truncate the given name to 10 chars if it is higher than that limit
    if len(name_prefix) > 10:
        truncated_name = name_prefix[:10]
        return_string += "`Warning`: The machine name was truncated to `{}` because it was too long.\n".format(truncated_name)
    else:
        truncated_name = name_prefix


    params = {'PLATFORM': platform,
              'OS': operating_system,
              'VM_SIZE': size,
              'CLUSTERNAME_PREFIX': truncated_name,
              'SLACK_CHANNEL_ID': slack_thread_id,
              'CODEBASE': codebase,
              'COUNT': count,
              'START_INDEX': starting_index,
              'TEST': test,
              'PRODUCT_GROUP_NAME': product_group_name}

    Jenkins.build_job(JENKINS_CONNECTION, DEPLOYMENT_JOB_NAME, params)

    return_string += "Your slave creation job has been kicked off."

    return return_string

def main(args=None):
    '''
     Main.
    '''

    if args is None:
        args = sys.argv[1:]


    try:

        # Start Jenkins Connection
        JENKINS_CONN = Jenkins(JENKINS_URL, JENKINS_API_EMAIL, JENKINS_API_TOKEN)


        MAIN_PARSER, DEPLOY_PARSER = initialize_parser()

        ARGS = MAIN_PARSER.parse_args()

        if ARGS.command == "deploy":
            deploy_slaves(JENKINS_CONNECTION=JENKINS_CONN,
                          platform=ARGS.platform,
                          operating_system=ARGS.operating_system,
                          size=ARGS.vm_size,
                          name_prefix=ARGS.name,
                          count=ARGS.count,
                          starting_index=ARGS.start_index,
                          codebase=ARGS.codebase,
                          slack_thread_id=ARGS.slack_thread_id,
                          test=ARGS.test_slave)
        elif ARGS.command == "destroy":
            pass
        else:
            print("Should never get here.")
            exit(1)

    except ClusterNameUnavailable as err:
        print(err.message)
        exit(1)


if __name__ == "__main__":
    main()
