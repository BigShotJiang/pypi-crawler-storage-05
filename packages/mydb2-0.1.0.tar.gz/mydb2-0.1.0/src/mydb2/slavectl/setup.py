'''
 Easy install script for this tool as a cli
'''
from os import path
from codecs import open
from setuptools import setup, find_packages

SCRIPT_PATH = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(SCRIPT_PATH, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()


setup(
    name='slavectl',
    version='0.1.3',
    packages=find_packages(),
    include_package_data=True,
    install_requires=['argparse',
                      'jenkinsapi',
                      'requests'],
    description="Tool to create/destroy db2 regression slaves.",
    long_description=long_description,
    entry_points={
        'console_scripts': [
            'slavectl = slavectl.__main__:main'
        ]
    },
    author="Hussein Fahmy",
    author_email='hussein.fahmy1@ibm.com'
)
