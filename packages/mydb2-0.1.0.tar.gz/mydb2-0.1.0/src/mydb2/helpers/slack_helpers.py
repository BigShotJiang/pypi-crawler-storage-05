"""
    Module for helper functions specific to slack.
"""
import urllib
import time

# SLACK constants
BOT_ALERTS_CHANNEL_ID = "CKWH2QN86"

def get_email_from_slack_id(slack_client, user_id):
    """
        Get user email from their slack ID
    """
    slack_response = slack_client.users_profile_get(
        user=user_id,
    )
    return slack_response["profile"]["email"]


def send_slack_message(slack_conn, text=None, channel=None, thread=None,
    link_names=False, retries=5):
    '''
     This custom slack send function will send a slack message but add some retry logic around the
     failures to avoid crashing and dropeed resopnse messages
    '''
    try_count = 0
    msg_sent = False

    if not text or not channel:
        raise ValueError("Must provide `text` and `channel` args.")


    while not msg_sent and try_count < retries:
        try:
            try_count += 1
            slack_conn.chat_postMessage(
                channel=channel,
                text=text,
                link_names=link_names
            )
            msg_sent = True
        except urllib.error.URLError:
            msg_sent = False
            send_slack_message(
                slack_conn,
                text="Failed to send a message - Retrying in 3 seconds",
                channel=BOT_ALERTS_CHANNEL_ID
            )
            time.sleep(2)


def slack_message_complex(message_tuple_list, channel, thread=None):
    '''
     This function will send a message to the user.
     Not the most elegant implementation, but it has some needed logic to keep it backwards
     compatible with the old way of sending messages.
     Params:
        - messages :list: - a list of tuples. Each tuple consists of (1 string, a list of strings)
                  Each string in the list is a message to send, each list of strings in that
                  respective tuple is a list of messages to post in the thread of the initial
                  message.

     Sample input:
     slack_message(
        [
            ("Hello, World", ["These", "messages", "go", "to", "the", "thread."]),
            ("Second message", ["These", "messages", "go", "to", "the", "second", "thread."])
        ],
        CHANNEL_ID,
        THREAD_TS
     )
    '''
    if isinstance(message_tuple_list, list):
        for message_object in message_tuple_list:
            if isinstance(message_object, tuple):
                message, thread_messages = message_object
            else:
                message = message_object
                thread_messages = []

            slack_response = BOT_MODEL.slack_web_client.chat_postMessage(
                channel=channel["channel"],
                text=message,
                thread_ts=thread
            )

            for thread_message in thread_messages:
                if thread:
                    print("WARNING: Because this message was sent to a thread, the thread_messages "
                          "printed alongside the regular messages as it is not possible to "
                          "sub-thread an existing thread.")
                BOT_MODEL.slack_web_client.chat_postMessage(
                    channel=channel["channel"],
                    text=thread_message,
                    thread_ts=thread or slack_response["event_ts"]
                )



    else:
        BOT_MODEL.slack_web_client.chat_postMessage(
            channel=channel["channel"],
            text=message_tuple_list,
            thread_ts=thread
        )