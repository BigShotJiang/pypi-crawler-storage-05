"""
 Classes for interfacing with a generic API
"""

import requests
try:
    import requests.packages.urllib3 as urllib3
except ImportError:
    import urllib3

# Suppress InsecureRequestWarning when calling API that does not require
# authentication.
urllib3.disable_warnings()

class API(object):
    """Generic API with generic error class."""

    class APIError(RuntimeError):
        """Generic RuntimeError class."""

    def __init__(self, base_url, username=None, secret=None, token=None):
        """Initializes the Sessions object.

        Keyword arguments:
        base_url -- base API URL without endpoints
        username -- username for API authentication (default None)
        secret   -- secret for API authentication (default None)
        token    -- Authorization token for token auth (default None)


        Python convention dictates that basic auth takes precendence over token authentication.
        Therefore if you define a username/pw AND a security token, the token will be overriden.
        """
        if base_url is None:
            raise API.APIError("No base URL was specified")
        self._base_url = base_url
        self._session = requests.Session()
        if username and secret:
            self._session.auth = (username, secret)
        if token:
            self._session.headers['Authorization'] = "token " + token

    def send_request(self, endpoint, method='GET', parameters=None,
                     req_data=None, paginate=False):
        """Returns response of request sent to provided endpoint.

        Keyword arguments:
        endpoint   -- target endpoint of the API
        method     -- HTTP method (default 'GET')
        parameters -- in-line parameters (default None)
        req_data   -- JSON request data (default None)
        paginate   -- whether to traverse pages of the response (default False)
        """
        resp = {}
        response = None
        try:
            if self._base_url is None:
                raise API.APIError("No base URL for API request specified.")

            url = '/'.join(filter(None, (self._base_url, endpoint)))

            response = self._session.request(
                method,
                url,
                params=parameters,
                json=req_data,
                verify=False
            )

            if (response.status_code == requests.codes.ok or
                    response.status_code == 201):
                resp = response.json()
                while paginate and 'next' in response.links.keys():
                    response = self._session.request(method,
                                                     response.links['next']['url'])
                    resp.extend(response.json())
            else:
                response.raise_for_status()
        except requests.exceptions.RequestException:
            return response.status_code if not isinstance(response.status_code,
                                                          (type(None))) else 500
        return resp
