'''
 Sub-class the fyre module I was using from:
    https://github.ibm.com/jtiefenb/fyre-api/blob/master/fyre/fyre.py
 Mainly because I wanted async requests and that module was hardcoded to wait for all requests to
 complete
'''
import fyre

class Fyre(fyre.Fyre):
    def dasBoot(self, cmd, name, node_type='cluster', sync=False):

        if cmd not in ('boot', 'reboot', 'shutdown'):
            raise fyre.Fyre.FyreError('Invalid boot cmd: {0}'.format(cmd))

        if name is None:
            raise fyre.Fyre.FyreError('Name must be specified')

        if node_type not in ('cluster', 'node'):
            raise fyre.Fyre.FyreError('Invalid node type: {0}'.format(node_type))

        params = {'operation' : cmd}

        if node_type == 'cluster':
            params['cluster_name'] = name
        else:
            params['node_name'] = name

        res = self.__sendRequest('GET', params)

        if cmd in  ('boot', 'reboot'):
            req_state = 'running'
        elif cmd == 'shutdown':
            req_state = 'shutdown'

        if sync:
            self.waitOnBootCompletion(name, node_type, req_state)
