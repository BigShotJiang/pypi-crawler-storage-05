'''
 Subclassed argparse to make proper use of exceptions
 and raise them when necessary instead of just exiting
'''
import argparse

class ArgumentParser(argparse.ArgumentParser):
    '''
     Raise an exception with the exit message instead of printing and exiting.
     This allows the slackbot to catch the exception with the error message and giving the user
     that feedback instead of just giving a generic error.
    '''
    def exit(self, status=0, message=None):
        raise ArgumentParserError(message)

def check_positive(value):
    ivalue = int(value)
    if ivalue <= 0:
        raise argparse.ArgumentTypeError("%s is an invalid positive int value" % value)
    return ivalue

def check_whole_number(value):
    ivalue = int(value)
    if ivalue < 0:
        raise argparse.ArgumentTypeError("%s is an invalid positive int value" % value)
    return ivalue

SUPPRESS = argparse.SUPPRESS

'''
 EXCEPTIONS
'''
class ArgumentParserError(Exception):
    pass
