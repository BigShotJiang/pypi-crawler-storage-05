'''
    Module to authenticate users for the slackbot.
    Currently authenticating against a team in GHE but if that changes this file will as well.
    Calls `is_user_in_team` from the github helpers module
'''
from mydb2.helpers import github_helpers as github
from mydb2.helpers import common

def authenticate_user(user_email):
    '''
        Authenticates user against GHE team for git pilot
    '''
    if not github.is_user_in_team(user_email, common.GH_ORG, common.GH_PILOT_TEAM_ID):
        raise UnauthorizedUserError(
            "Sorry, you are not authorized for this action. "
            "To perform this action, you must have Db2 Git Development access."
            "Please open a RIOT-Ticket here: https://github.ibm.com/DB2/RIOT-tickets/ and use"
            "the _*Git Access Request*_ Template."
        )
    return True

def authenticate_slave_creator(user_email):
    '''
        Authenticates user against GHE team for git pilot
    '''
    if not github.is_user_in_team(user_email, common.GH_ORG, common.GH_SLAVE_CREATOR_TEAM_ID):
        raise UnauthorizedUserError("Sorry, you are not authorized to deploy regression workers.")
    return True

def authenticate_committer(user_email):
    '''
        Authenticates user against GHE team for Db2 committers
    '''
    if not github.is_user_in_team(user_email, common.GH_ORG, common.GH_COMMITTERS_TEAM_ID):
        raise UnauthorizedUserError(
            "Sorry, you are not authorized for this action. "
            "To perform this action, you must be a Db2 committer."
        )
    return True

def authenticate_pilot_admin(user_email):
    '''
        Authenticates user against GHE team for Db2 git pilot admins
    '''
    if not github.is_user_in_team(user_email, common.GH_ORG, common.GH_PILOT_ADMIN_TEAM_ID):
        raise UnauthorizedUserError(
            "Sorry, you are not authorized for this action. "
            "To perform this action, you must be a Db2 git pilot admin."
        )
    return True


'''
 EXCEPTIONS
'''
class Error(Exception):
    """Base class for other exceptions"""

class UnauthorizedUserError(Error):
    """Raised when the input value is too small"""
