'''
 Module to help with users service interactions.
 Consists of:
    - Includes a wrapper class that calls the users service endpoints
    - Helper functions to action the output we get from the users service
'''

from prettytable import PrettyTable
from mydb2.helpers import Bot
from mydb2.helpers.api import API
from mydb2.helpers.common import MICROSERVICE_CLUSTER_ADDRESS



class UsersAPI(API):
    """Class to query the Bldstats API."""

    def __init__(self):
        """Initializes the Bldstats API."""
        super(UsersAPI, self).__init__(MICROSERVICE_CLUSTER_ADDRESS)

    def lookup_user(self, lookup_type, key, attributes):
        """Returns builds filtered by the provided parameters.

        Keyword arguments:
        params -- parameters to filter the /builds endpoint by
        """
        return self.send_request(f'users/lookup/{lookup_type}/{key}?attributes=' +
                                 "&attributes=".join(attributes))

def pretty_print_lookup_results(lookup_results, attributes_fetched, keys):
    '''
     Returns a string of Table-formatted lookup results
    '''
    index = 0
    warning = ""
    print(f"KEYS: {keys}")

    result_table = PrettyTable(padding_width=2)
    result_table.title = ("Lookup Results")

    Bot.log("DEBUG", str(lookup_results))

    for result in lookup_results:
        if result['status'] == 'success':
            result_table.field_names = ['key', *lookup_results[0]['user'].keys()]
            row = [keys[index]]
            for attribute in result['user']:
                if attribute == "slack-user":
                    row.append("@{}/{}".format(
                        result['user'][attribute]['value']['handle'],
                        result['user'][attribute]['value']['identifying_name']
                    ))
                else:
                    row.append(result['user'][attribute]['value'])

        else:
            warning += f"{result['value']}\n"

        result_table.add_row(row)
        index += 1

    warning = "\n`Warnings:`\n{}".format(warning) if warning else ""
    print(f"```{result_table.get_string()}```" + warning)
    return f"```{result_table.get_string()}```" + warning

def print_lookup_results(lookup_results, attributes_fetched, delimiter):
    '''
     Returns a string with unformatted lookup results
    '''
    final_string = ""
    results_aggregated = {}
    for attribute in attributes_fetched:
        if attribute == "slack-user":
            results_aggregated["slack_handle"] = []
            results_aggregated["slack_identifying_name"] = []
        else:
            results_aggregated[attribute] = []

    for result in lookup_results:
        if result['status'] == "success":
            for attribute in result['user'].keys():
                if result['user'][attribute]['status'] == "success":
                    if attribute == "slack-user":
                        results_aggregated["slack_handle"].append(
                            result['user'][attribute]['value']['handle']
                        )
                        results_aggregated["slack_identifying_name"].append(
                            result['user'][attribute]['value']['identifying_name']
                        )
                    else:
                        results_aggregated[attribute].append(result['user'][attribute]['value'])

    for attribute in results_aggregated:
        final_string += "{}:\n{}\n\n".format(
            attribute,
            delimiter.join(results_aggregated[attribute])
        )

    return final_string
