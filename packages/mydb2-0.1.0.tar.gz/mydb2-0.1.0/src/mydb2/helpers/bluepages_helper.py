'''
 Wrapper for bluepages actions
'''
import os
import json
import requests
from mydb2.helpers import Bot

W3_USER = os.environ.get('W3_ID')
W3_PASS = os.environ.get('W3_PW')
BLUEPAGES_TOKEN = os.environ.get('BLUEPAGES_TOKEN')


BLUEPAGES_URL = 'https://bluepages.ibm.com/tools/groups/protect/groups.wss'
#BLUEPAGES_URL = 'https://w3.api.ibm.com/common/run/tools/groups/protect/groups.wss'
BLUEPAGES_API_URL = 'https://w3.api.ibm.com/common/run/bluepages'
BLUEPAGES_ADD_MEMBER_URL = ''.join([BLUEPAGES_URL,
                                    '?gName={}&task=Members&mebox={}&Select=Add+Members&API=1'])
BLUEPAGES_DEL_MEMBER_URL = ''.join([BLUEPAGES_URL,
                                    '?gName={}&task=DelMem&mebox={}&Delete=Delete+checked&API=1'])

ARTIFACTORY_BLUEGROUPS = ['afaas-soft-db2ongit-write',
                          'afaas-hyc-db2-dev-read',
                          'afaas-hyc-db2-qa-team-read']

def get_bluepages_profile(email):
    '''
     Returns all bluepages information about a given user

     PARAMS:
        - email :str: - The email address of the user in question
    '''
    Bot.log("INFO", "Getting bluepages profile for {}".format(email))
    bluepages_profile_url = '{}/userid/{}/*?client_id={}'.format(
        BLUEPAGES_API_URL,
        email,
        BLUEPAGES_TOKEN
    )
    bluepages_result = requests.request('GET', bluepages_profile_url).content
    Bot.log("INFO", "Request completed successfully")
    Bot.log("DEBUG", "Profile fetched: {}".format(str(bluepages_result)))

    return json.loads(bluepages_result)['search']['entry'][0]

def get_bluepages_uid(email):
    '''
     Finds the UID of a user from their email address

     PARAMS:
        - email :str: - The email address of the user in question
    '''
    Bot.log("INFO", "Getting UID for {} from bluepages".format(email))
    profile = get_bluepages_profile(email)

    for attribute in profile['attribute']:
        if attribute['name'] == 'uid':
            Bot.log("INFO", "Found UID for {}, UID is {}".format(email, attribute['value']))
            return attribute['value']

    Bot.log("ERROR", "Unable to find UID for {}, throwing an error".format(email))
    raise BluepagesError("Something went wrong when trying to find this email in bluepages. "
                         "Please reach out to @hussein")

def add_user_to_bluegroup(email, bluegroup):
    '''
     Add a user to a bluegroup based on user email and bluegroup name
    '''
    try:
        Bot.log("INFO", "Adding {} to the bluegroup {}".format(email, bluegroup))
        Bot.log("DEBUG", "Request address: {}".format(
            BLUEPAGES_ADD_MEMBER_URL.format(bluegroup, get_bluepages_uid(email)[0])
        ))
        request = requests.request(
            'GET',
            BLUEPAGES_ADD_MEMBER_URL.format(bluegroup, get_bluepages_uid(email)[0]),
            auth=requests.auth.HTTPBasicAuth(W3_USER, W3_PASS)
        )
        Bot.log("INFO", "Request completed. Request status code: {}".format(request.status_code))

        # Will raise an exception if the request status code is bad
        request.raise_for_status()
    except BaseException:
        raise BluepagesError("Something went wrong when trying to add this user to the Artifactory "
                             "Bluegroups. Please reach out to @hussein")

def add_user_to_git_pilot_bluegroups(email):
    '''
     Add a user to the bluegroups that control artifactory repo access for Db2 git development
    '''
    try:
        for team in ARTIFACTORY_BLUEGROUPS:
            add_user_to_bluegroup(email, team)
    except BaseException:
        raise BluepagesError("Something went wrong when trying to add this user to the "
                             "Artifactory Bluegroups. Please reach out to @hussein")

def remove_user_from_bluegroup(email, bluegroup):
    '''
     Remove a user from a bluegroup based on user email and bluegroup name
    '''
    try:
        Bot.log("INFO", "Removing {} from the {} bluegroup".format(email, bluegroup))
        request = requests.request(
            'GET',
            BLUEPAGES_DEL_MEMBER_URL.format(bluegroup, get_bluepages_uid(email)),
            auth=requests.auth.HTTPBasicAuth(W3_USER, W3_PASS)
        )
        Bot.log("DEBUG", request.content)
        Bot.log("INFO", "Request status: {}".format(request.status_code))
        if request.status_code != 200:
            raise BluepagesError()
    except BaseException:
        raise BluepagesError("Something went wrong when trying to remove this user from the "
                             "Artifactory Bluegroups. Please reach out to @hussein")

def remove_user_from_git_pilot_bluegroups(email):
    '''
     Remove a user from the bluegroups that control artifactory repo access for Db2 git development
    '''
    try:
        for team in ARTIFACTORY_BLUEGROUPS:
            remove_user_from_bluegroup(email, team)
    except BaseException:
        raise BluepagesError("Something went wrong when trying to remove this user from the "
                             "Artifactory Bluegroups. Please reach out to @hussein")


'''
 EXCEPTIONS
'''
class BluepagesError(Bot.BotError):
    """Raised when the input value is too small"""
