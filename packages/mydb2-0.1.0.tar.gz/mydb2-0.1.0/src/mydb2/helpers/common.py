'''
    Module of a variety of helper functions that might be useful in more than 1 module
'''
import random
import string
from mydb2.helpers import deploy_helpers, db2_helpers, Bot, slack_helpers as slack
import logging
import os
import requests
import time
import slack_sdk

MICROSERVICE_CLUSTER_ADDRESS = "http://microservice.apps.db2infrastructure.cp.fyre.ibm.com"

GH_COMMITTERS_TEAM_ID = 28704
GH_PILOT_TEAM_ID = 30122
GH_SLAVE_CREATOR_TEAM_ID = 31351
GH_PILOT_ADMIN_TEAM_ID = 38954
GH_ORG = "DB2" # ORG name
slack_bot_token = os.getenv("MYDB2_BOT_TOKEN")

slack_messaging_client = slack_sdk.WebClient(
        slack_bot_token,
        timeout=30
    )

def generate_random_suffix(length):
    """
        Generate random assortment of lowercase letters and numbers
    """
    letters_and_digits = string.ascii_lowercase + string.digits
    return ''.join(random.choice(letters_and_digits) for i in range(length))


def parse_email(email):
    """
        Strips the <mailto:> link from the email
    """

    try:
        email_split = email.split(":")[1]
        email_split = email_split.split("|")[0]
        return email_split
    except IndexError:
        return email

def parse_domain_prefix_from_email(email):
    """
        Parses the domain prefix of the hostname from the email
        Ex. Jon.Doe1@ibm.com -> JonDoe1
    """
    email = email.split("@")[0]
    email = email.replace(".", "")
    email = email.replace("-", "")
    email = email.replace("_", "")
    return email

def parse_domain_prefix_from_fqdn(fqdn):
    """
        Strips the -XXXXX-x86/p/z.fyre.ibm.com from vm hostname
        Ex. JonDoe1-SDJ32-x86.fyre.ibm.com -> JohnDoe1
    """
    fqdn = fqdn.split("|")[1]
    fqdn = fqdn.partition("-")[0]
    return fqdn

def parse_hostname_from_fqdn(fqdn):
    """
        Strips the '-1.fyre.ibm.com' from vm fqdn
        Ex. JonDoe1-SDJ32-x86.fyre.ibm.com -> JohnDoe1-SDJ32-x86
    """
    fqdn = fqdn.split("|")[1]
    fqdn = fqdn.partition(".")[0]
    return fqdn

def generate_fqdn(email, random_suffix, platform, operating_system, prod_group, fyre3):
    '''
        Creates FQDN from email, cluster suffix, and platform
    '''
    print ("Generating FQDN for email: {}, random_suffix: {}, platform: {}, operating_system: {}, prod_group: {}".format(
        email, random_suffix, platform, operating_system, prod_group))
    
    fqdn = ""
    if prod_group == 243:
        fqdn += "db2i-"
    if ("indows" in operating_system):
        fqdn += random_suffix
        fqdn += "-" + parse_domain_prefix_from_email(email) + "-" + platform
    else:
        fqdn += parse_domain_prefix_from_email(email)
        fqdn += "-" + random_suffix + "-" + platform
    
    if (operating_system == "Redhat 9.4" and (platform == "power")) or (fyre3 and (platform == "x86" or platform == "zlinux") and operating_system == "Redhat 9.4"):
        domain = ".dev.fyre.ibm.com"
    elif "indows" in operating_system and fyre3:
        domain = ".dev.fyre.ibm.com"
    else:
        domain = ".fyre.ibm.com"
    fqdn += domain

    return fqdn


def breakdown_fqdn(fqdn):
    '''
        TODO: this whole function needs re-doing. Instead of splitting on `-`, i should get the
        suffix and fyre.ibm.com then if the suffix is 6 chars, that makes it windows(5 chars + 1).
        But this is all rushed because of the fyre cell stuff....

        Breaks down FQDN -> clustername prefix, clustername suffix, and nodename(platform)
        husseinfahmy1-abcde-x.fyre.ibm.com -> (husseinfahmy1, abcde, x)
    '''

    cluster_prefix = ""
    cluster_suffix = ""
    nodename = ""

    hostname = parse_hostname_from_fqdn(fqdn)
    split_hostname = hostname.split("-")

    if split_hostname[0] == "db2i":
        cluster_prefix += "db2i-"
        hostname = hostname.replace("db2i-", "")
        split_hostname = hostname.split("-")

    if len(split_hostname) < 3:
        cluster_prefix += split_hostname[0]
        cluster_suffix += split_hostname[1][:5]
        nodename += "1"
    else:
        cluster_prefix += split_hostname[0]
        cluster_suffix += split_hostname[1]
        nodename += split_hostname[2]

    return cluster_prefix, cluster_suffix, nodename

def validate_machine_ownership(db2_conn, env_table_name, user_email, machine_fqdn):
    '''
     This function validates that this user owns this machine.
     Will raise VmOwnershipError if the user does not own the vm
    '''

    machine_owner = db2_helpers.get_machine_owner(db2_conn, env_table_name, machine_fqdn)

    if not user_email.lower() == machine_owner.lower():
        print("User Email:: {}\n Machine Owner Email: {}".format(
            user_email.lower(),
            machine_owner.lower()
            ))
        raise VmOwnershipError("You may not perform this action on a machine you do not own.")
    return True

def parse_link_from_message(message):
    """
        Strips the <mailto:> link from the email
    """
    message = str(message).split("|")[0]
    message = str(message).replace("<http://", "")
    message = str(message).replace(">", "")

    return message

def sanitize_bot_input(message):
    '''
     This function removes all slack formatting that the user might have entered
     unknowingly as input to the bot.
    '''
    message = message.replace('`', '')
    message = message.replace('*', '')
  #  message = message.replace('_', '')
    return message

def action_fyre3_host(action, parsed_fqdn, event, command, command_args, cluster_name, user_email, log_details):
    """
    Perform an action (e.g., reboot, shutdown, boot) on a Fyre V3 host.

    Parameters:
        action (str): The action to perform (e.g., "reboot", "shutdown", "boot").
        parsed_fqdn (str): The fully qualified domain name of the host.
        event (dict): The event data.
        command (str): The command issued.
        command_args (Namespace): Parsed command arguments.
        cluster_name (str): The cluster name.
        user_email (str): The user's email.
        broken_down_fqdn (tuple): Breakdown of the FQDN.
        log_details (function): Function to log details.

    Returns:
        str: Response message.
    """
    api_url = f"https://ocpapi.svl.ibm.com/v1/vm/{parsed_fqdn}/{action}"

    # Retrieve the API token from environment variables
    api_token = os.getenv("FYRE_API_KEY")
    if not api_token:
        logging.error("Fyre API token is not set in environment variables.")
        return "Fyre API token is missing. Please contact support."

    # Basic authentication credentials
    auth = ("db2-infra", api_token)

    # Log the API call for debugging purposes
    logging.debug(f"Making API call to: {api_url} with auth: ('db2-infra', '****')")

    try:
        # Make the API call with PUT method
        response = requests.put(api_url, auth=auth, verify=False)

        # Log the API response for debugging purposes
        logging.info(f"API Response: {response.status_code}, {response.text}")

        # Check for successful response
        if response.status_code in [200, 202]:
            log_details(event, command, command_args, cluster_name, user_email, parsed_fqdn)
            logging.info(f"Fyre V3 request sent for VM {action}.")
            response_data = response.json()
            if response_data.get("status") == "success":
                slack.send_slack_message(
                    slack_conn=slack_messaging_client, 
                    text=f"Your Fyre V3 VM {action} request was submitted successfully. You will be notified when the action is complete.",
                    channel=event["channel"],
                    link_names=True  
                )
        else:
            logging.warning(f"Initial API call to {action} Fyre V3 VM failed. Status Code: {response.status_code}, Response: {response.text}")

        # Proceed to poll the status regardless of the initial API call result
        desired_state = "running" if (action == "boot" or action == "reboot") else "shutdown"
        return poll_fyre3_status(parsed_fqdn, desired_state)

    except requests.RequestException as e:
        logging.error(f"Error occurred while making API call: {e}")
        return f"An error occurred while trying to {action} the VM. Please try again later."

def poll_fyre3_status(parsed_fqdn, desired_state):
    """
    Poll the Fyre V3 `/status` endpoint until the desired state is reached.

    Parameters:
        parsed_fqdn (str): The fully qualified domain name of the host.
        desired_state (str): The desired state (e.g., "running", "shutdown").
        user_email (str): The user's email for logging and notifications.

    Returns:
        str: Notification message when the desired state is reached.
    """
    api_url = f"https://ocpapi.svl.ibm.com/v1/vm/{parsed_fqdn}/status"

    # Retrieve the API token from environment variables
    api_token = os.getenv("FYRE_API_KEY")
    if not api_token:
        logging.error("Fyre API token is not set in environment variables.")
        return "Fyre API token is missing. Please contact support."

    auth = ("db2-infra", api_token)

    max_retries = 60  # Maximum number of retries for API calls
    retries = 0

    while retries < max_retries:
        try:
            # Make the API call to check the status
            response = requests.get(api_url, auth=auth, verify=False)

            if response.status_code == 200:
                response_data = response.json()
                status = response_data.get("status")
                last_os_state = response_data.get("last_os_state")

                # Log the current status
                logging.info(f"Polling status: {status}, last_os_state: {last_os_state}")

                # Check if the desired state is reached
                if status == "no requests in progress" and last_os_state == desired_state:
                    logging.info(f"VM {parsed_fqdn} has reached the desired state: {desired_state}")
                    return f"Your Fyre V3 VM: {parsed_fqdn} has successfully reached the state: {desired_state}"

            else:
                logging.warning(f"Failed to poll status. Status Code: {response.status_code}, Response: {response.text}")
                return f"Error: Unable to poll the VM status for {parsed_fqdn}."

        except requests.RequestException as e:
            logging.error(f"Error occurred while polling status: {e}")

        # Increment the retry counter
        retries += 1

        # Wait before polling again
        time.sleep(3)

    logging.error(f"Polling exceeded maximum retries ({max_retries}). VM {parsed_fqdn} did not reach the desired state: {desired_state}")
    return f"Error: VM {parsed_fqdn} did not reach the desired state: {desired_state} within the allowed time."

'''
 EXCEPTIONS
'''
class Error(Exception):
    """Base class for other exceptions"""

class VmOwnershipError(Error):
    """Raised when the input value is too small"""

class NoHardwareAPIError(Bot.BotError):
    '''
     This error is raised when a user attempts an action that requires the Fyre API on a non-Fyre VM
    '''
