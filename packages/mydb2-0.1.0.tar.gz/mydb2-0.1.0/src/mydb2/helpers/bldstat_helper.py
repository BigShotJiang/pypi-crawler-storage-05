"""
 Classes for interfacing with a generic API and the bldstats API.
"""

import datetime
from prettytable import PrettyTable
from mydb2.helpers.api import API
from mydb2.helpers.common import MICROSERVICE_CLUSTER_ADDRESS

#### GLOBAL VARS START
# I order the build attributes in this list in the order I want them to be printed
ORDERED_BUILD_FIELDS = [
    "BUILD_ID",
    "PROJECT",
    "PLATFORM",
    "OS",
    "SOURCE",
    "TYPE",
    "COMPILER",
    "AUTHOR",
    "LEVEL",
    "SIGNATURE",
    "PUBLISH_DATE",
    "ADDITIONAL_BUILD_INFO",
    "STAGE",
    "STAGE_STATUS",
    "STATUS_TIMESTAMP",
    "PR_NUMBER",
    "COMMIT_ID",
    "OEMTOOLS_PR_NUMBER",
    "OEMTOOLS_COMMIT_ID",
    "GIT_BRANCH",
    "GIT_REPO",
    "FILE_CHECKSUM",
    "FILE_REPO",
    "FILE_PATH",
    "BIGSQL_VERSION"
]
#### GLOBAL VARS END


class BldstatsAPI(API):
    """Class to query the Bldstats API."""

    def __init__(self, ghe_token):
        """Initializes the Bldstats API."""
        super(BldstatsAPI, self).__init__(MICROSERVICE_CLUSTER_ADDRESS, token=ghe_token)

    def get_build_info(self, params):
        """Returns builds filtered by the provided parameters.

        Keyword arguments:
        params -- parameters to filter the /builds endpoint by
        """
        return self.send_request('builds', parameters=params)

    def insert_build(self, config):
        """Inserts new build information into the Bldstats database.

        Keyword arguments:
        config -- JSON of key-value pairs to insert
        """
        return self.send_request('builds', 'POST', req_data=config)

    def update_column(self, build_id, column_name, column_value):
        """Updates column name with provided column value for a specified build.

        Keyword arguments:
        build_id     -- ID of the build
        column_name  -- column name to update
        column_value -- new value for the column
        """
        config = {
            "build_id":build_id,
            "column_name":column_name,
            "column_value":column_value
        }

        return self.send_request('builds', 'PUT', req_data=config)

def print_builds_list(builds_list, columns_to_print):
    '''
     Given a list of commit statuses, this function will prettify them in a table and
     print the table
    '''

    if not builds_list:
        table_columns = columns_to_print
    else:
        table_columns = [column for column in columns_to_print if column in builds_list[0].keys()]

    if len(builds_list) != 1:
        table = PrettyTable(padding_width=2)
        table.field_names = table_columns
        table.title = ("Builds Matching Filter Criteria")
        for build in builds_list:
            row = []

            for item in table_columns:
                if item in build:
                    try:
                        timestamp = datetime.datetime.strptime(build[item], '%Y-%m-%dT%H:%M:%S.%fZ')
                        row.append(timestamp.strftime('%Y-%m-%d %H:%M Z'))
                    except (ValueError, TypeError):
                        row.append(build[item])
            table.add_row(row)
    else:
        table = PrettyTable(padding_width=5)
        table = PrettyTable(padding_width=2)
        table.field_names = ['Build Attribute', 'Value']
        table.title = (builds_list[0]['BUILD_ID'])
        for build_attribute in ORDERED_BUILD_FIELDS:
            try:
                table.add_row([build_attribute, builds_list[0][build_attribute]])
            except KeyError:
                # Expect to hit this error whenever the bldstat result doesn't have a column in the
                # ORDERED_BUILD_FIELDS list. This will happen when the user filters by status
                # because those results don't include a stage & status since those are known.
                pass

    return table.get_string()

def print_aux_list(status_list, valid_status_fields):
    '''
     Given a list of commit statuses, this function will prettify them in a table and
     print the table
    '''

    table = PrettyTable(padding_width=5)
    table = PrettyTable(padding_width=2)
    table.field_names = valid_status_fields
    table.title = (status_list[0]['BUILD_ID'])
    for status in status_list:
        row = []

        for column_name in valid_status_fields:
            try:
                timestamp = datetime.datetime.strptime(
                    [status[column_name.upper()]][0],
                    '%Y-%m-%dT%H:%M:%S.%fZ'
                )
                row.append(timestamp.strftime('%Y-%m-%d %H:%M Z'))
            except (ValueError, TypeError):
                row.append([status[column_name.upper()]][0])

        table.add_row(row)

    return table.get_string()
