GETTING_STARTED_DOCS_LINK = "https://pages.github.ibm.com/DB2/db2-dev-playbook/devflow/getting-started"

GENERIC_HELP_MESSAGE = """To get started, check out this wiki: {}
If you're ready to try me out, here are the available commands:
```

+------------------------------------------------------------------------------+
|                       Available commands                                     |
+----------------+-------------------------------------------+-----------------+
|     Command    |  Description                              | Documentation   |
+----------------+-------------------------------------------+-----------------+
|     bldstat    |  View build statuses                      |  *bldstat help* |
|      boot      |  Start up a machine that's currently down |   *boot help*   |
|     deploy     |  Deploy a new development environment     |  *deploy help*  |
|     destroy    |  Destroy a development machine            |  *destroy help* |
|      list      |  List all machines                        |   *list help*   |
|     reboot     |  Reboot a machine                         |  *reboot help*  |
|      user      |  Perform admin actions on git pilot users |   *user help*   |
|    shutdown    |  Shutdown a machine that's running        | *shutdown help* |
+----------------+-------------------------------------------+-----------------+
```""".format(GETTING_STARTED_DOCS_LINK)

INSUFFICIENT_QUOTA_MESSAGE = """It looks like you've reached your machine quota.
To view your current machines, message `list`."""

INVALID_COMMAND = """I've encountered an error while processing your command. If this persists,
please reach out for help in #db2-on-git."""

UNAUTHORIZED_DEPLOY_STRING = """Sorry, you are not authorized to deploy."""

UNAUTHORIZED_PRSTATUS_STRING = """Sorry, you are not authorized to modify PR status checks."""

GHE_EMAIL_NOT_PUBLIC_STRING = """It seems your github email is not publicly viewable.
Please go to https://github.ibm.com/settings/profile and make sure that your `Public email` is the same as your slack email."""

API_CALL_ERROR = "There was a network error when processing your command, please try again."

COMMAND_NOT_FOUND_ERROR = "Error! Command not found. To see a list of supported commands, please message `help`"

INSUFFICIENT_TOKEN_SCOPE_ERROR = ("This Github Personal Access Token does not have the required "
                                  "permission scopes for this operation.\nFor instructions on how "
                                  "to create a Github Personal Access Token, check out the "
                                  "<{}|Getting Started> doc.".format(GETTING_STARTED_DOCS_LINK))

INVALID_TOKEN_ERROR = ("The token you provided is invalid, please try again with a valid token. "
                       "For instructions on how to create a Github Personal Access Token, check"
                       "out the <{}|Getting Started> doc.".format(GETTING_STARTED_DOCS_LINK))

NO_VACANT_HOSTS_FOUND_ERROR = ("Looks like there are no hosts available for lease matching this "
                               "configuration. Please try again later.")
