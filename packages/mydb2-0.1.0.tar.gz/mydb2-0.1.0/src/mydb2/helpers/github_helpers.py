'''
    Module to help with common github actions through the PyGithub module
'''
import os
import logging
from github import Github, GithubException
from mydb2.helpers import common
from mydb2.helpers import help_command_strings
from mydb2.helpers import Bot


GH_PERSONAL_ACCESS_TOKEN = os.environ.get('GH_PERSONAL_ACCESS_TOKEN')
GH_BASE_URL = "https://github.ibm.com/api/v3"
GITHUB_CONN = Github(base_url=GH_BASE_URL,
                     login_or_token=GH_PERSONAL_ACCESS_TOKEN)
ORG_NAME = "DB2"
REPO_NAME = "db2"

logging.basicConfig(filename='slackbot.log', level=logging.INFO)


def is_user_in_team(user_email, org_name, team_id):
    '''
        Check if a user is in the passed in team
    '''
    user_profile = None
    org = GITHUB_CONN.get_organization(org_name)
    team = org.get_team(team_id)
    user_profile = _get_member_from_email(user_email)
    if user_profile:
        return team.has_in_members(user_profile)
    return False

def get_ghe_username_from_email(user_email):
    '''
     Gets the users github username based on their slack email.
     Will raise GheEmailNotPublicError if the user does not publicly show their email on ghe
    '''
    return _get_member_from_email(user_email).login

def _get_member_from_email(user_email):
    users_result = GITHUB_CONN.search_users(user_email + " in:email")
    for user in users_result:
        if user is not None and user.email.lower() == user_email.lower() and user.type == "User":
            return user
    raise GheEmailNotPublicError(help_command_strings.GHE_EMAIL_NOT_PUBLIC_STRING)

def update_pr_check_status(pr_number, status='success', context=None):
    '''
        Function to update a PR's check status
    '''

    if context is None:
        contexts = _get_pr_status_contexts(pr_number)
    else:
        contexts = [context]

    repo = GITHUB_CONN.get_repo(ORG_NAME + "/" + REPO_NAME)
    pull_request = _get_pr_from_number(pr_number)


    head_commit_sha = repo.get_commit(pull_request.head.sha)
    logging.info("Head Commit Sha: %s", head_commit_sha)

    logging.info("About to update the following contexts: %s", str(contexts))

    if not contexts:
        raise NoContextToUpdateError("No existing contexts to update on that PR. Please use --context/-c to specify a context to create.")

    for single_context in contexts:
        head_commit_sha.create_status(
            state=status,
            description="Status manually set through slackbot.",
            context=single_context
        )

def _get_pr_from_number(pr_number):
    repo = GITHUB_CONN.get_repo(ORG_NAME + "/" + REPO_NAME)
    return repo.get_pull(pr_number)

def _get_pr_status_contexts(pr_number):
    '''
     This function will get all the status checks on a PR and return all the different contexts.
     Useful for setting a PR as succesful
    '''
    list_of_contexts = []

    repo = GITHUB_CONN.get_repo(ORG_NAME + "/" + REPO_NAME)
    pull_request = _get_pr_from_number(pr_number)
    pr_head_commit = repo.get_commit(pull_request.head.sha)
    pr_head_contexts = pr_head_commit.get_combined_status()

    for status in pr_head_contexts.statuses:
        if status.context not in list_of_contexts:
            list_of_contexts.append(status.context)

    return list_of_contexts

def _add_user_to_team_by_id(user_email, team_id):
    '''
     Add github user to any github Db2 team. Requires user email.
    '''
    org = GITHUB_CONN.get_organization(ORG_NAME)
    team = org.get_team(team_id)
    user_profile = _get_member_from_email(user_email)

    team.add_membership(user_profile)
    return True

def _remove_user_from_team_by_id(user_email, team_id):
    '''
     Remove Github user from any github Db2 team. Requires user email.
    '''
    org = GITHUB_CONN.get_organization(ORG_NAME)
    team = org.get_team(team_id)
    user_profile = _get_member_from_email(user_email)

    team.remove_membership(user_profile)
    return True

def _add_user_to_team_by_name(user_email, team_name):
    '''
     Add github user to any github Db2 team. Requires user email.
    '''
    org = GITHUB_CONN.get_organization(ORG_NAME)
    team = org.get_team_by_slug(team_name)
    user_profile = _get_member_from_email(user_email)

    team.add_membership(user_profile)
    return True

def _remove_user_from_team_by_name(user_email, team_name):
    '''
     Remove github user from any github Db2 team. Requires user email.
    '''
    org = GITHUB_CONN.get_organization(ORG_NAME)
    team = org.get_team_by_slug(team_name)
    user_profile = _get_member_from_email(user_email)

    team.remove_membership(user_profile)
    return True

def add_user_to_git_pilot(user_email):
    '''
     Add user to the git_pilot github team
    '''
    return _add_user_to_team_by_id(user_email, common.GH_PILOT_TEAM_ID)

def remove_user_from_git_pilot(user_email):
    '''
     Remove user from the git_pilot github team
    '''
    return _remove_user_from_team_by_id(user_email, common.GH_PILOT_TEAM_ID)

def add_user_to_team(user_email, team_name):
    '''
     Adds a user to a github team.
     Params:
        - user_email :str:
        - team_name :str:
    '''
    return _add_user_to_team_by_name(user_email, team_name)

def remove_user_from_team(user_email, team_name):
    '''
     Removes a user from a github team.
     Params:
        - user_email :str:
        - team_name :str:
    '''
    return _remove_user_from_team_by_name(user_email, team_name)

def _get_repo(repo_owner_email, repo_name):
    '''
     Returns the repository details for any repo given the repo owner(ORG/Username) and repo name
    '''

    user_profile = _get_member_from_email(repo_owner_email)

    return user_profile.get_repo(repo_name)

def get_db2_fork(owner_email):
    '''
     Returns all available info about the user's Db2 repo Fork
    '''

    try:
        user_profile = _get_member_from_email(owner_email)

        return user_profile.get_repo(REPO_NAME)
    except GithubException:
        raise NoDb2ForkError("You do not have a Fork of the Db2 Repo. Please follow the "
                             "<{}|Getting Started> Documentation before deploying a Dev "
                             "VM.".format(help_command_strings.GETTING_STARTED_DOCS_LINK))

def get_ghe_token_permission_scopes(ghe_pat):
    '''
     Given a user's API token, this function will get its permission scopes
    '''
    try:
        return Github(
            base_url=GH_BASE_URL,
            login_or_token=ghe_pat).get_organization(ORG_NAME)._requester.__dict__["oauth_scopes"]

    except GithubException:
        raise InvalidTokenError(help_command_strings.INVALID_TOKEN_ERROR)

'''
 EXCEPTIONS
'''
class GithubErrors(Bot.BotError):
    """Base class for other exceptions"""

class GheEmailNotPublicError(GithubErrors):
    """Raised when the input value is too small"""

class NoContextToUpdateError(GithubErrors):
    "Raised when the user does not give a context to update in a PR and one does not already exist"

class NoDb2ForkError(GithubErrors):
    '''
     Raised when the user does not have a Fork of the Db2 repo, which would otherwise lead to a
     deploy failure
    '''

class InvalidTokenError(GithubErrors):
    '''
     Raised when the user's personal access token is wrong (bad credentials)
    '''

class InsufficientTokenScopeError(GithubErrors):
    '''
     Raised when the user's personal access token is valid, but does not have the required scopes
    '''
