'''
This module interfaces with the Markham LDAP server. Its primary purpose
'''
import ldap
import mydb2.helpers.Bot as Bot


LDAP_SERVER_ADDRESS = 'ldap://ldap.canlab.ibm.com'


LDAPSEARCH_USERNAME = ''
LDAPSEARCH_PW = ''
BASEDN = ""
RETRIEVE_ATTRIBUTES = None

def _ldapsearch(ldap_server, ldapsearch_username, ldapsearch_pw, basedn, search_filter_criteria):
    '''
     This function will LDAP search a given ldap server using the parameters passed in, it'll wait
     for the results to return and return them.
    '''

    ldap_conn = ldap.initialize(ldap_server)
    ldap_conn.simple_bind(ldapsearch_username, ldapsearch_pw)

    ldap_search_result = ldap_conn.search_s(basedn, ldap.SCOPE_SUBTREE, search_filter_criteria, [])
    Bot.log("DEBUG", "LDAP Search result: {}".format(ldap_search_result))

    if not ldap_search_result:
        raise LDAPUserNotFoundException("Unable to find the LDAP username provided. Please try "
                                        "again with a valid LDAP username.")

    return ldap_search_result[0][1]




def get_ldap_user_profile(ldap_username):
    '''
     Given an LDAP username, this function will search for the username and return the profile if
     found
    '''
    return _ldapsearch(
        LDAP_SERVER_ADDRESS,
        LDAPSEARCH_USERNAME,
        LDAPSEARCH_PW,
        "ou=People,ou=markham,o=ibm.com",
        "(&(objectclass=person)(uid={}))".format(ldap_username)
    )

class LDAPUserNotFoundException(Bot.BotError):
    '''
     Error to be raised when the LDAP username provided by the user does cannot be found
    '''
