import os
import sys
import logging
import slack_sdk
from slack_sdk.rtm import RTMClient
from jenkinsapi.jenkins import Jenkins
import ibm_db
from mydb2.helpers import argparse_helper as argparse, help_command_strings as HelpStrings, common as CommonHelpers, my_authentication as Auth, github_helpers as github, fyre_wrapper as fyre, jenkins_helper
# from boot_handler import handler as boot_handler
# from deploy_handler import handler as deploy_handler
# from destroy_handler import handler as destroy_handler
# from help_handler import handler as help_handler
# from list_handler import handler as list_handler
# from prstatus_handler import handler as prstatus_handler
# from reboot_handler import handler as reboot_handler
# from regr_handler import handler as regr_handler
# from shutdown_handler import handler as shutdown_handler
# from user_handler import handler as user_handler




LOGGING_FILE_PATH = "./slackbot.log"

logging.basicConfig(
    filename=LOGGING_FILE_PATH,
    format='%(asctime)s | %(name)s | %(levelname)-8s | %(message)s',
    level=logging.INFO,
    datefmt='%Y-%m-%d %H:%M:%S'
)



class BotModel:
    # Db2 Connection Constant
    # Make sure to export the credentials before running this script
    DB2_HOST = os.environ.get('DB2_INSTANCE_HOST')
    DB2_PORT = os.environ.get('DB2_INSTANCE_PORT')
    DB2_USERNAME = os.environ.get('DB2_INSTANCE_USERNAME')
    DB2_PW = os.environ.get('DB2_INSTANCE_PW')
    DB2_DEV_ENVIRONMENTS_TABLE = "DEV_ENVIRONMENTS"
    DEV_SYSTEM_POOL_TABLE_NAME = "DEV_SYSTEM_POOL"
    DB2_DEV_USERS_TABLE = "DEVELOPERS"
    DB2_BUILDS_TABLE = "BUILDS"

    # Slack Connection Tokens
    MYDB2_BOT_TOKEN = os.environ.get('MYDB2_BOT_TOKEN')
    MYDB2_USER_TOKEN = os.environ.get('MYDB2_USER_TOKEN')


    def __init__(self):

        self.db2_conn = ibm_db.connect(
            'DATABASE=BLUDB;'
            'HOSTNAME={HOSTNAME};'
            'PORT={PORT};'
            'PROTOCOL=TCPIP;'
            'UID={USER};'
            'PWD={PW};'.format(
                HOSTNAME=self.DB2_HOST,
                PORT=self.DB2_PORT,
                USER=self.DB2_USERNAME,
                PW=self.DB2_PW
            ), '', ''
        )

        # Start Jenkins Connection
        self.jenkins_conn = jenkins_helper.JenkinsConnection({
            "jenkins_url":  os.environ.get('JENKINS_URL'),
            "jenkins_email": os.environ.get('W3_ID'),
            "jenkins_token": os.environ.get('JENKINS_API_TOKEN'),
            "deploy_job": os.environ.get('deploy_job'),
            "destroy_job": os.environ.get('destroy_job'),
            "alcatraz_destroy_job": os.environ.get('alcatraz_destroy_job'),
            "user_cleanup_job": os.environ.get('user_cleanup_job')
        })

        # instantiate Slack client
        self.slack_rtm_client = slack_sdk.rtm.RTMClient(token=self.MYDB2_BOT_TOKEN)
        self.slack_messaging_client = slack_sdk.WebClient(
            self.MYDB2_BOT_TOKEN,
            timeout=30
        )
        self.slack_api_client = slack_sdk.WebClient(
            self.MYDB2_USER_TOKEN,
            timeout=30
        )


        # The way the Fyre package works is that it looks for ENV FYRE_USER_NAME and FYRE_API_KEY
        # for creds. This is a convenient way to do things as it makes hiding creds even easier than
        # me having to manually import env vars like I do at the top of the script
        self.fyre_conn = fyre.Fyre()

        self.parsers = _initialize_parser()

    def refresh_db2_conn(self):
        '''
         Close the Db2 connection and open a new one.
         This is needed because the Db2 connection fails and causes errors if it persists for too
         long
        '''

        if not ibm_db.active(self.db2_conn):
            self.db2_conn = ibm_db.connect(
                'DATABASE=BLUDB;'
                'HOSTNAME={HOSTNAME};'
                'PORT={PORT};'
                'PROTOCOL=TCPIP;'
                'UID={USER};'
                'PWD={PW};'.format(
                    HOSTNAME=self.DB2_HOST,
                    PORT=self.DB2_PORT,
                    USER=self.DB2_USERNAME,
                    PW=self.DB2_PW
                ), '', ''
            )
        return True

def log_event(user_email, msg_event, parsed_arguments_dict={}):
    '''
    This function is used for all logging throughout the slackbot in order to keep things
    uniform.

    Will actually implement later...one thing at a time
    '''

    logging.info("\n----------------------------------------")
    logging.info("Timestamp: %s", msg_event["ts"])
    logging.info("Message: %s", msg_event["text"])
    logging.info("USER_EMAIL: %s", user_email)

    for key in parsed_arguments_dict:
        logging.info("%s: %s", key, parsed_arguments_dict[key])

    logging.info("SLACK_CHANNEL_ID: %s", msg_event["channel"])
    logging.info("----------------------------------------\n")

def log(debug_level, text):
    '''
    Slackbot-wide logging.
    Params:
        - debug_level :str: - dictate the level of logging.
            Choices:
                * "DEBUG": logging.debug,
                * "INFO": logging.info,
                * "WARINNG": logging.warning,
                * "ERROR": logging.error,
                * "CRITICAL": logging.critical,
        - text :str: - text to be logged
    '''
    debug_level_map = {
        "DEBUG": logging.debug,
        "INFO": logging.info,
        "WARNING": logging.warning,
        "ERROR": logging.error,
        "CRITICAL": logging.critical,
    }

    debug_level_map[debug_level](text)

def _initialize_parser():
    '''
     Initializes Argparse parsers for all the bot's commands.
    '''

    tmp_main_parser = argparse.ArgumentParser(
        description='Multi-function tool for DB2 developers.',
        add_help=False,
        # conflict_handler='resolve'
    )
    tool_subparsers = tmp_main_parser.add_subparsers(
        help='Available Tools',
        dest='tool'
    )



    '''
     ####################################################################################
     ################################    DEV COMMANDS    ################################
     ####################################################################################
    '''

    # Instantiate the argument parser for deploy commands
    dev_deploy_parser = tool_subparsers.add_parser(
        'deploy',
        prog='deploy',
        description='Deploy DB2 Dev environments autonomously.',
        help='Deploy a new Db2 dev environment',
        add_help=False
    )

    dev_deploy_parser.set_defaults(
        # handler=deploy_handler
    )

    ####################################################

    # Instantiate the argument parser for destroy commands
    dev_destroy_parser = tool_subparsers.add_parser(
        'destroy',
        prog='destroy',
        description='Destroy DB2 Dev environments.',
        help='Destroy existing Db2 dev environment',
        add_help=False
    )
    destroy_required_options = dev_destroy_parser.add_argument_group('REQUIRED arguments')
    destroy_required_options.add_argument(
        '-f',
        '--fqdn',
        dest='fqdn',
        help='FQDN of the machine to be deleted',
        required=True
    )
    dev_destroy_parser.set_defaults(
        # handler=destroy_handler
    )


    dev_reboot_parser = tool_subparsers.add_parser(
        'reboot',
        prog='reboot',
        description='Hard reboot Fyre VMs through the API.',
        help='Hard reboot the stack in fyre',
        add_help=False
    )
    dev_reboot_parser.add_argument(
        '-f',
        '--fqdn',
        dest='fqdn',
        help='FQDN of the VM to be rebooted',
        required=True
    )
    dev_reboot_parser.set_defaults(
        # handler=reboot_handler
    )

    dev_boot_parser = tool_subparsers.add_parser(
        'boot',
        prog='boot',
        description='Boot Fyre VMs through the API.',
        help='Boot the VM',
        add_help=False
    )
    dev_boot_parser.add_argument(
        '-f',
        '--fqdn',
        dest='fqdn',
        help='FQDN of the VM to be booted',
        required=True
    )
    dev_boot_parser.set_defaults(
        # handler=boot_handler
    )

    dev_shutdown_parser = tool_subparsers.add_parser(
        'shutdown',
        prog='shutdown',
        description='Shutdown VMs through the API.',
        help='Shutdown the VM',
        add_help=False
    )
    dev_shutdown_parser.add_argument(
        '-f',
        '--fqdn',
        dest='fqdn',
        help='FQDN of the VM to be shut down',
        required=True
    )
    dev_shutdown_parser.set_defaults(
        # handler=shutdown_handler
    )


    '''
     ####################################################################################
     #####################################    REGR    ###################################
     ####################################################################################
    '''

    tmp_regr_parser = tool_subparsers.add_parser(
        'regr',
        prog='regr',
        description='Tool to manage db2 regr workers.',
        help='regr help',
        add_help=False)

    tmp_regr_subparsers = tmp_regr_parser.add_subparsers(
        help='Available regr commands:',
        dest='command'
    )


    # Instantiate the argument parser for deploy commands
    regr_deploy_parser = tmp_regr_subparsers.add_parser(
        'deploy',
        prog='regr deploy',
        description='Deploy DB2 Dev environments autonomously.',
        help='Create a new regr worker',
        add_help=False)
    regr_deploy_parser.add_argument(
        '-c',
        '--count',
        dest='count',
        default=1,
        type=argparse.check_positive,
        required=False,
        help='The number of instances to deploy with this configuration. Defaults to 1.'
    )
    regr_deploy_parser.add_argument(
        '-i',
        '--start-index',
        dest='start_index',
        default=1,
        type=argparse.check_positive,
        required=False,
        help='The number of instances to deploy with this configuration. Defaults to 1.'
    )
    regr_deploy_parser.add_argument(
        '-p', '--platform',
        dest='platform',
        help='VM platform. Defaults to x86. Enter x for X86, p for Power, and z for ZLinux',
        default='x86',
        choices=['x86', 'power', 'zlinux'],
        required=False
    )
    regr_deploy_parser.add_argument(
        '-o',
        '--operating-system',
        dest='operating_system',
        help='OS for dev environment. Default is RHEL 7.5.'
             'See list of accepted options here:\nhttps://fyre.ibm.com/help#fyre-os',
        default='Redhat 7.7',
        required=False
    )
    regr_deploy_parser.add_argument(
        '-n',
        '--name',
        dest='name',
        help='Name prefix of regr worker batch.'
             'Each worker will be appended by a number ranging from 1 to <count>.'
             'Max of 10 characters. Will be truncated to 10 chars otherwise.',
        required=True
    )
    regr_deploy_parser.add_argument(
        '-s',
        '--size',
        dest='vm_size',
        help='VM Size. Defaults to x',
        default='x',
        choices=['s', 'm', 'l', 'x'],
        required=False
    )
    regr_deploy_parser.add_argument(
        '--codebase',
        dest='codebase',
        help='Codebase for the worker. Defaults to git',
        default='git',
        choices=['cc', 'git'],
        required=False
    )
    regr_deploy_parser.add_argument(
        '--test',
        '-t',
        dest='test_slave',
        help='Is this a test deploy?',
        default='no',
        choices=['yes', 'no'],
        required=False
    )
    regr_deploy_parser.add_argument(
        '--product-group',
        '-pg',
        dest='product_group',
        help='Which product group to deploy the worker(s) to. This will be overridden if'
             'the workers are zlinux.',
        default='Db2 - Infrastructure',
        choices=['Db2 - LUW', 'Db2 - Infrastructure', 'Db2 - LUWonZ'],
        required=False
    )
    regr_deploy_parser.add_argument(
        '--deployment-site',
        dest="deployment_site",
        help="Which geographical site to deploy the VMs under",
        choices=['svl', 'tor'],
        default='svl',
        required=False
    )
    regr_deploy_parser.set_defaults(
        # handler=regr_handler
    )

    '''
     ####################################################################################
     ###################################    PRSTATUS    #################################
     ####################################################################################
    '''
    tmp_prstatus_parser = tool_subparsers.add_parser(
        'prstatus',
        prog='prstatus',
        description='Manage DB2 PR status.',
        help='prstatus help',
        add_help=False
    )

    tmp_prstatus_parser.add_argument(
        '-n',
        '--number',
        dest='pr_number',
        type=argparse.check_positive,
        help='PR number to set status for.',
        required=True
    )
    tmp_prstatus_parser.add_argument(
        '-s',
        '--status',
        dest='status',
        help='Status to set for PR head commit. Defaults to success.',
        default='success',
        choices=['success', 'failure', 'pending'],
        required=False
    )
    tmp_prstatus_parser.add_argument(
        '-c',
        '--context',
        dest='context',
        help='Context of status check to update.',
        required=False
    )
    tmp_prstatus_parser.set_defaults(
        # handler=prstatus_handler
    )

    '''
     ####################################################################################
     ##################################    BLDSTAT    ###################################
     ####################################################################################
    '''
    tmp_bldstat_parser = tool_subparsers.add_parser(
        'bldstat',
        prog='bldstat',
        description='Tool to check the status of a Db2 build.',
        help='bldstat help',
        add_help=False
    )
    tmp_bldstat_parser.set_defaults(
        # handler=bldstat_handler
    )

    '''
     ####################################################################################
     ####################################    USER    ####################################
     ####################################################################################
    '''
    # Instantiate the argument parser for deploy commands
    user_parser = tool_subparsers.add_parser(
        'user',
        prog='user',
        description='Admin tools for Git pilot users.',
        help='Admin tools for Git pilot users.',
        add_help=False
    )
    user_parser.set_defaults(
        # handler=user_handler
    )

    parsers = {
        "MAIN": tmp_main_parser,
        "DEPLOY": dev_deploy_parser,
        "DESTROY": dev_destroy_parser,
        "REBOOT": dev_reboot_parser,
        "BOOT": dev_boot_parser,
        "SHUTDOWN": dev_shutdown_parser,
        "REGR": tmp_regr_parser,
        "REGR_DEPLOY": regr_deploy_parser,
        "PRSTATUS": tmp_prstatus_parser,
        "BLDSTAT": tmp_bldstat_parser,
        "USER": user_parser
    }

    return parsers

'''
 EXCEPTIONS
'''
class BotError(Exception):
    """Base Error class for other bot exceptions"""

class UserError(BotError):
    '''
     Generic error to be raised when the user has incorrectly used a command/option
    '''

def log_details(event, command, command_args, cluster_name, user_email, broken_down_fqdn):
    logging.info("-----------------")
    logging.info("Timestamp: {}".format(event["ts"]))
    logging.info("Message: {}".format(command))
    logging.info("FQDN: {}".format(command_args.fqdn))
    logging.info("Cluster Name: {}".format(cluster_name))
    logging.info("USER_EMAIL: {}".format(user_email))
    logging.info("HOSTNAME_SUFFIX: {}".format(broken_down_fqdn[1]))
    logging.info("SLACK_CHANNEL_ID: {}".format(event["channel"]))
    logging.info("-----------------")
    logging.info("Params passed to reboot job:")
    logging.info("USER_EMAIL: {}".format(user_email))
    logging.info("HOSTNAME_SUFFIX: {}".format(broken_down_fqdn[1]))
    logging.info("NODENAME: {}".format(broken_down_fqdn[2]))
    logging.info("SLACK_CHANNEL_ID: {}".format(event["channel"]))
    logging.info("-----------------")

