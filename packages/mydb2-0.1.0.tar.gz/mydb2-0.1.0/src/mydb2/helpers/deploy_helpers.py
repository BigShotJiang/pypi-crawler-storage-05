'''
 Constants and Functions used in the handling of deploy commands
'''
from mydb2.helpers import github_helpers as github
from mydb2.helpers import Bot
from mydb2.helpers import ldap_helpers
from mydb2.helpers import help_command_strings
import re

'''
 Constants
'''
#Block all deploys
ALLOW_DEPLOYS = True
#Update slack link to current post before turning off
DISALLOWED_DEPLOYS_MESSAGE = ("Sorry, the deployment feature has been disabled temporarily "
                              "disabled. Please see #db2-dev-communication for more information: "
                              "https://ibm-analytics.slack.com/archives/CUL1X069J/p1683219531212489")
#Block specific OS levels
BLOCKED_DEPLOY_OS = [] # 'Redhat 7.9', 'Redhat 8.4', 'Windows 2012', 'Windows 2012 nt32', *deploy_helpers.ALCATRAZ_OS
#Update slack link to current post before turning off
BLOCKED_DEPLOY_MESSAGE = ("Sorry, the deployment of this OS is disabled temporarily"
                              "Please see #db2-dev-communication for more information: "
                              "https://ibm-analytics.slack.com/archives/CUL1X069J/p1683219531212489")
                           
REQUIRED_GITHUB_TOKEN_SCOPES = ['admin:public_key']

ALCATRAZ_OS = ['SLES 10.4', 'SLES 11.4', 'AIX 6.1', 'AIX 7.2', 'Redhat 7.9']
ALCATRAZ_GIT_OS = ['Redhat 7.9']
NTX_OS = {
    'Windows 2022': {
    }
}

DOMAIN_SPECIFIC_ATTRIBUTES = {
    "support_domain": {
        "product_group_ids": {
            "default": 238
        },
        "vm_sizes": ['s', 'm'],
        "github_team_id": 41763
    },
    "data_virtualization_domain": {
        "product_group_ids": {
            "default": 41
        },
        "vm_sizes": ['s', 'm', 'l'],
        "github_team_id": 59658
    },
    "big_sql_domain": {
        "product_group_ids": {
            "default": 2
        },
        "vm_sizes": ['s', 'm', 'l'],
        "github_team_id": 96474
    },
    "data_replication_domain": {
        "product_group_ids": {
            "default": 11
        },
        "vm_sizes": ['s', 'm'],
        "github_team_id": 38599
    },
    "db2_on_cloud_domain": {
        "product_group_ids": {
            "default": 3
        },
        "vm_sizes": ['s', 'm', 'l'],
        "github_team_id": 44989
    },
    # The value for x below should be 600. When the db2 infrastructure cell in
    # Fyre has filled up, we swap to 3 (Db2 LUW)
    "default_attributes": {
        "product_group_ids": {
            "x": 243,
            "z": 224,
            "default": 3
        },
        "vm_sizes": ['s', 'm']
    }
}

#MARKHAM_LDAP_OS = ['Redhat 7.6', 'Redhat 7.9']
'''
 Functions
'''
def get_domain_specific_attributes(user_email):
    '''
     Determines if a user belongs to a domain that provisions out of their own product group in
    '''
    for domain in DOMAIN_SPECIFIC_ATTRIBUTES:
        if "github_team_id" in DOMAIN_SPECIFIC_ATTRIBUTES[domain] and github.is_user_in_team(user_email, github.ORG_NAME, DOMAIN_SPECIFIC_ATTRIBUTES[domain]["github_team_id"]):
            return DOMAIN_SPECIFIC_ATTRIBUTES[domain]

    return DOMAIN_SPECIFIC_ATTRIBUTES["default_attributes"]

def validate_user_inputs(username, user_email, ghe_token, skip_token_verification, operating_system):
    '''
     This function performs all checks on user input to validate it. This includes:
        - Ensure the user has a Db2 fork in Github
        - Ensure their LDAP username is valid
        - Ensure their GHE Personal Acces Token has the necessary scopes
    '''
    if not skip_token_verification:
        # Make sure the user has forked Db2 on Github
        github.get_db2_fork(user_email)

        # Make sure the GHE Personal Access Token provided has the admin:public_key scope
        validate_user_token_scopes(ghe_token, REQUIRED_GITHUB_TOKEN_SCOPES)

    Bot.log("INFO", f"Validating user inputs for OS: {operating_system}")
    if operating_system in NTX_OS:
        Bot.log("INFO", f"Validating CanLab username: {username} for OS: {operating_system}")
        validate_canlab(username)
    else:
        Bot.log("INFO", f"Validating LDAP username: {username} for OS: {operating_system}")
        validate_user_ldap_username(username, user_email)

def validate_user_ldap_username(user_ldap_username, user_email):
    '''
     Gets user LDAP profile and makes sure the email matches the user slack email
    '''
    allowed_length = 8
    pattern = r'^[A-Za-z0-9_.]{{1,{}}}$'.format(allowed_length)
    Bot.log("INFO", f"Validating username: {user_ldap_username} against pattern: {pattern}")
    if not re.fullmatch(pattern, user_ldap_username):
        Bot.log("INFO", "This LDAP username is not in a valid format...")
        raise InvalidLdapUsername("It looks like the LDAP username you provided is not in a valid format. Please use your exact 'Markham LDAP' username.")

    ldap_profile = ldap_helpers.get_ldap_user_profile(user_ldap_username)
    slack_email = user_email.upper()
    ldap_email = ldap_profile["mail"][0].upper().decode()

    Bot.log("INFO", f"User email from Slack: {user_email}\nUser Email from LDAP: {ldap_profile['mail'][0]}")

    if ldap_email != slack_email:
        Bot.log("INFO", f"This user does not own the LDAP username they provided")
        Bot.log("INFO", f"User slack email: {slack_email}\n LDAP owner email: {ldap_email}")
        raise InvalidLdapUsername("It looks like you're not the owner of the LDAP username you've "
                                  "provided. Please try the deploy command again with your LDAP "
                                  "username.")
    return True


def validate_canlab(username):
    '''
     Validates the CanLab username provided by the user
    '''
    allowed_length = 70
    pattern = r'^[A-Za-z0-9_.]{{1,{}}}$'.format(allowed_length)
    Bot.log("INFO", f"Validating username: {username} against pattern: {pattern}")
    if not re.fullmatch(pattern, username):
        Bot.log("INFO", "This CanLab username is not in a valid format...")
        raise InvalidLdapUsername("It looks like the CanLab username you provided is not in a valid format. Please use your exact 'CANADA LAB Active Directory' username.")
    return True

def validate_user_token_scopes(ghe_pat, required_scopes): 
    '''
     Given a user's API token, this function will get its permission scope and verify that the token
     has each of the required scopes that are passed in as a parameter

     Args:
       - ghe_pat: GHE Personal access token of user
       - required_scopes: A list of scopes required for the token to be valid
    '''

    token_permission_scopes = github.get_ghe_token_permission_scopes(ghe_pat)

    for scope in required_scopes:
        if scope not in token_permission_scopes:
            error_message = ("{}\nThe required scopes for this action are: `{required_scopes}`\n"
                             "The scopes assigned to this token are: `{present_scopes}`".format(
                                 help_command_strings.INSUFFICIENT_TOKEN_SCOPE_ERROR,
                                 required_scopes=str(required_scopes),
                                 present_scopes=str(token_permission_scopes)
                             ))
            raise github.InsufficientTokenScopeError(error_message)

    return True

LIMITED_TICKET_DEPLOY_MESSAGE = ("The deploy selection is a limited resource and you are asked to open a RIOT-Ticket(https://github.ibm.com/DB2/RIOT-tickets) stating business justification for why it is needed, along with the expected timeframe.")

INVALID_DEPLOY_OPTION = ("The deploy selection is not offered by MyDb2. Please refer to `deploy help` to view available deploy selections. ")

class InvalidSizeSelection(Bot.BotError):
    '''
     Error to be raised when a developer has tried to deploy a VM with an invalid Size option
    '''

class InvalidLdapUsername(Bot.BotError):
    '''
     Error to be raised when a developer's given ldap profile doesn't match their slack email
    '''

class NoVacantHostsFound(Bot.BotError):
    '''
     Error to be raised when a developer's given ldap profile doesn't match their slack email
    '''

class MutuallyExclusiveOptionsError(Bot.BotError):
    '''
     Error to be raised when a developer's given ldap profile doesn't match their slack email
    '''
