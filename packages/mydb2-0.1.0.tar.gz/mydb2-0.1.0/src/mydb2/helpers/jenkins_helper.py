'''
 Wrapper for the any Jenkins interactions this slackbot has
'''
import sys
import traceback
from jenkinsapi.jenkins import Jenkins, JenkinsAPIException
import requests
import mydb2.helpers.Bot as Bot


class JenkinsConnection():
    '''
     Connection to the Jenkins server
    '''
    def __init__(self, jenkins_config):
        self.jenkins_conn = Jenkins(
            jenkins_config['jenkins_url'],
            jenkins_config['jenkins_email'],
            jenkins_config['jenkins_token'],
            timeout=60
        )
        self.deploy_job = jenkins_config['deploy_job']
        self.destroy_job = jenkins_config['destroy_job']
        self.alcatraz_destroy_job = jenkins_config['alcatraz_destroy_job']
        self.user_cleanup_job = jenkins_config['user_cleanup_job']

    def _build_job(self, job, job_params, num_retries=10):
        '''
         This job will build any jenkins job based on the job name passed.

         Arguments:
            - job :str: - Name of job to build
            - job_params :dict: - dict of parameters to pass to job
            - num_retries :int: (optional) - number of retries for the API call in case it fails
        '''
        api_call_attempts = 0
        try_request_again = True
        while try_request_again:
            try:
                api_call_attempts += 1
                Jenkins.build_job(self.jenkins_conn, job, job_params)
                try_request_again = False
                return True
            except (requests.exceptions.RequestException, JenkinsAPIException):
                if api_call_attempts < num_retries+1:
                    Bot.log("ERROR", "Build request to Jenkins failed: {}\nRetrying...".format(
                        traceback.format_exc()
                    ))
                else:
                    try_request_again = False
                    Bot.log("ERROR", "Failed to make the API call to Jenkins {} times in a row. "
                            "Giving up.".format(api_call_attempts))
                    return False

    def build_deploy_job(self, job_params):
        '''
         This functions builds the Dev deployment pipeline job. It returns True/False based on
         whether the API call was successful or not.

         Args:
            - job_params :dict: - dictionary of parameters to pass to the jenkins job
        '''
        return self._build_job(self.deploy_job, job_params)

    def build_destroy_job(self, job_params):
        '''
         This functions builds the destroy-environment job. It returns True/False based on
         whether the API call was successful or not.

         Args:
            - job_params :dict: - dictionary of parameters to pass to the jenkins job
        '''
        if job_params['CONFIGURATION_TYPE'] == 'user_access':
            return self._build_job(self.alcatraz_destroy_job, job_params)
        return self._build_job(self.destroy_job, job_params)

    def build_user_cleanup_job(self, job_params):
        '''
         This functions builds the destroy-environment job. It returns True/False based on
         whether the API call was successful or not.

         Args:
            - job_params :dict: - dictionary of parameters to pass to the jenkins job
        '''
        return self._build_job(self.user_cleanup_job, job_params)
