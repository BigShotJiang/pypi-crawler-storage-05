'''
 Interactions with the Db2 backend
'''
import ibm_db
from mydb2.helpers import Bot

def fetch_results(command):
    '''
     Fetches the results from a Db2 SELECT query into a list of dicts where each dict is a row
    '''
    ret = []
    result = ibm_db.fetch_assoc(command)
    while result:
        # This builds a list in memory. Theoretically, if there's a lot of rows,
        # we could run out of memory. In practice, I've never had that happen.
        # If it's ever a problem, you could use
        #     yield result
        # Then this function would become a generator. You lose the ability to access
        # results by index or slice them or whatever, but you retain
        # the ability to iterate on them.
        ret.append(result)
        result = ibm_db.fetch_assoc(command)
    return ret  # Ditch this line if you choose to use a generator.

def list_by_owner(db2_conn, env_table_name, owner_email):
    '''
        List all environments that a user owns
    '''
    query = ("SELECT FQDN, DEPLOY_STATUS, HARDWARE_TYPE, CLUSTER_NAME, OS FROM {} WHERE UPPER(OWNER_EMAIL)=UPPER('{}') AND "
             "DEPLOY_STATUS IN ('Success', 'Building...', 'Transferred');".format(
                 env_table_name,
                 owner_email
             ))
    Bot.log("DEBUG", "SQL Query: {}".format(query))
    return fetch_results(ibm_db.exec_immediate(db2_conn, query))

def insert_into_developers_table(db2_conn, dev_table_name, dev_email, quota=3):
    '''
     insert into developers table if they're not already there
    '''
    query = "SELECT 1 FROM {} WHERE UPPER(DEV_EMAIL)=UPPER('{}');".format(dev_table_name, dev_email)
    Bot.log("DEBUG", "SQL Query: {}".format(query))
    developer_exists = fetch_results(ibm_db.exec_immediate(db2_conn, query))
    Bot.log("DEBUG", "Result of the query to see if the developer is in the DEVELOPERS "
            "table: {}".format(developer_exists))
    # if there does not exist a record with that email
    if not developer_exists:
        Bot.log("DEBUG", "Developer not in DEVELOPERS table, inserting them...")
        #insert new record
        query = "INSERT INTO {}(DEV_EMAIL, MACHINE_QUOTA) VALUES('{}', '{}');".format(
            dev_table_name,
            dev_email.lower(),
            str(quota)
        )
        Bot.log("DEBUG", "SQL Query: {}".format(query))
        return ibm_db.exec_immediate(db2_conn, query)

    return "User already in developers table"

def get_machine_owner(db2_conn, env_table_name, host_fqdn):
    '''
     Queries the DEV_ENVIRONMENTS table in the backend to get the owner_email of the host provided
    '''
    query = (f"SELECT owner_email FROM {env_table_name} WHERE UPPER(FQDN)=UPPER('{host_fqdn}');")
    Bot.log("DEBUG", "SQL Query: {}".format(query))
    return str(fetch_results(ibm_db.exec_immediate(db2_conn, query))[0]["OWNER_EMAIL"])

def get_machine_count_by_owner(db2_conn, env_table_name, owner_email):
    '''
     Queries the DEV_ENVIRONMENTS table in the backend to see how many machines a user owns
    '''
    query = ("SELECT COUNT FROM {} WHERE UPPER(OWNER_EMAIL)=UPPER('{}') AND DEPLOY_STATUS IN "
             "('Success', 'Building...', 'Transferred');".format(env_table_name, owner_email))
    Bot.log("DEBUG", "SQL Query: {}".format(query))
    return int(fetch_results(ibm_db.exec_immediate(db2_conn, query))[0]["1"])

def get_user_machine_quota(db2_conn, dev_table_name, dev_email):
    '''
     Get's a user's quota from the DEVELOPERS table in the backend
    '''
    query = "SELECT MACHINE_QUOTA FROM {} WHERE UPPER(DEV_EMAIL)=UPPER('{}');".format(
        dev_table_name,
        dev_email
    )
    Bot.log("DEBUG", "SQL Query: {}".format(query))
    return fetch_results(ibm_db.exec_immediate(db2_conn, query))[0]["MACHINE_QUOTA"]

def has_sufficient_quota(db2_conn, dev_table_name, env_table_name, user_email):
    '''
     Returns T/F based on whether the user has sufficient quota for 1 more deploy.
     That is, if the # of machines the user already owns is < the user's quota allowance
    '''
    return (get_machine_count_by_owner(db2_conn, env_table_name, user_email) <
            get_user_machine_quota(db2_conn, dev_table_name, user_email))

def get_vm_attributes(db2_conn, fqdn, env_table_name):
    '''
     Given the fqdn of a git dev VM, this function will return all stored info about VM in the
     Db2 Infra backend
    '''
    query = ("SELECT * from {} WHERE FQDN='{}' ".format(env_table_name, fqdn))
    Bot.log("DEBUG", "SQL Query: {}".format(query))
    return fetch_results(ibm_db.exec_immediate(db2_conn, query))[0]

def get_user_reserved_hosts(db2_conn, lease_table_name=None, user_email=None):
    '''
     Queries the MyDb2 backend tables and returns all the hosts reserved for the user provided
    '''
    query = (f"SELECT * FROM {lease_table_name} where STATUS='Reserved' and "
             f"OCCUPANT_EMAIL='{user_email}';")
    return fetch_results(ibm_db.exec_immediate(db2_conn, query))

def get_vacant_hosts_from_dev_pool(db2_conn, lease_table_name=None, os=None, config_type=None, platform=None):
    '''
     Queries the MyDb2 backend tables and returns all the vacant hosts
    '''
    query = (f"SELECT * FROM {lease_table_name} where STATUS='Vacant' AND OS='{os}' "
            f"AND REQUIRED_SYSTEM_CONFIGURATION='{config_type}' AND PLATFORM='{platform}' ORDER BY CHECKOUT_TIME ASC;")
    Bot.log("INFO", "SQL Query: {}".format(query))
    return fetch_results(ibm_db.exec_immediate(db2_conn, query))

def reserve_host_for_user(db2_conn, lease_table_name=None, user_email=None, fqdn=None):
    '''
     Marks host as reserved for user.
    '''
    query = (f"UPDATE {lease_table_name} SET OCCUPANT_EMAIL='{user_email}', STATUS='Reserved' "
             f"where FQDN='{fqdn}' AND STATUS='Vacant';")

    Bot.log("INFO", "SQL Query: {}".format(query))
    return ibm_db.exec_immediate(db2_conn, query)

def remove_failure(db2_conn, failure_id):
    '''
     Removes a failure from the database by its ID.
    '''
    query = f"DELETE FROM DEPLOY_FAILURES WHERE FAILURE_ID='{failure_id}';"
    Bot.log("DEBUG", "SQL Query: {}".format(query))
    return ibm_db.exec_immediate(db2_conn, query)

def validate_failure_id(db2_conn, failure_id):
    '''
     Validates that the failure ID provided exists in the database.
     Returns True if it exists, False otherwise.
    '''
    query = f"SELECT count(*) FROM DEPLOY_FAILURES WHERE FAILURE_ID='{failure_id}';"
    Bot.log("DEBUG", "SQL Query: {}".format(query))
    result = fetch_results(ibm_db.exec_immediate(db2_conn, query))
    if result and isinstance(result, list):
        count = result[0].get('1')  # Extract the count value from the first dictionary
        if count == 1:
            Bot.log("DEBUG", "Failure ID {} exists in the database.".format(failure_id))
            return True
        else:
            Bot.log("DEBUG", "Failure ID {} does not exist in the database.".format(failure_id))
            return False
    else:
        Bot.log("DEBUG", "Unexpected result format for failure ID validation: {}".format(result))
        return False

def validate_group_id(db2_conn, group_id):
    '''
     Validates that the group ID provided exists in the database.
     Returns True if it exists, False otherwise.
    '''
    query = f"SELECT count(*) FROM DEPLOY_FAILURES WHERE GROUP_ID='{group_id}';"
    Bot.log("DEBUG", "SQL Query: {}".format(query))
    result = fetch_results(ibm_db.exec_immediate(db2_conn, query))
    if result and isinstance(result, list):
        count = result[0].get('1')  # Extract the count value from the first dictionary
        if count >= 1:
            Bot.log("DEBUG", "Group ID {} exists in the database.".format(group_id))
            return True
        else:
            Bot.log("DEBUG", "Group ID {} does not exist in the database.".format(group_id))
            return False
    else:
        Bot.log("DEBUG", "Unexpected result format for group ID validation: {}".format(result))
        return False

def remove_failures_by_group_id(db2_conn, group_id):
    '''
     Removes all failures associated with a group ID from the database.
    '''
    query = f"DELETE FROM DEPLOY_FAILURES WHERE GROUP_ID='{group_id}';"
    Bot.log("DEBUG", "SQL Query: {}".format(query))
    return ibm_db.exec_immediate(db2_conn, query)
    
def __validate_db2_connection(db2_conn):
    '''
     This function runs a basic command that will never fail against the database to test the
     connection. If the query fails, then we know that there is an issue with the Db2 connection.
    '''
    try:
        Bot.log("INFO", "Validating Db2 connection.")
        query = "SELECT 1 FROM SYSIBM.SYSDUMMY1;"
        Bot.log("DEBUG", "SQL Query: {}".format(query))
        # results = fetch_results(ibm_db.exec_immediate(db2_conn, query))
        ibm_db.exec_immediate(db2_conn, query)
        Bot.log("INFO", "Db2 connection is valid.")
    except Exception:
        '''
         Will only get here if the command fails, indicating that there's a connection issue.
         Unfortunately, we need to catch `Exception` as the Db2 driver does not raise a more
         specific exception than that.
        '''
        raise Db2ConnectionClosedError("The Db2 connection has dropped. Restarting bot.")

class Db2ConnectionClosedError(Bot.BotError):
    """This error is thrown when a Db2 query returns that the connection to the DB has dropped"""
