from subprocess import run
from time import sleep

file_path = "./db2buildbot.py" 

restart_timer = 2
def start_script():
    try:
        # Make sure 'python' command is available
        print("MyDb2 has been started by the always-up script.")
        run(file_path, check=True) 
    except:
        # Script crashed, lets restart it!
        handle_crash()

def handle_crash():
    sleep(restart_timer)  # Restarts the script after 2 seconds
    start_script()


if __name__ == "__main__":
    start_script()
