#!/usr/bin/python3
"""
    Slackbot used as an interface in an automated solution to order DB2 Dev
    environments through slack.

    Author: Hussein Fahmy - hussein.fahmy1@ibm.com
"""
import os
import time
import sys
import traceback
from socket import error as SocketError
import requests
from unidecode import unidecode
import urllib
import slack_sdk
from slack_sdk.rtm import RTMClient
from mydb2.helpers import argparse_helper as argparse, help_command_strings as HelpStrings, common as CommonHelpers, my_authentication as Auth, github_helpers as github, db2_helpers, fyre_wrapper as fyre, Bot, bluepages_helper, slack_helpers
from mydb2.handlers import help_handler, list_handler, deploy_handler, destroy_handler, reboot_handler, boot_handler, shutdown_handler, regr_handler, prstatus_handler, bldstat_handler, user_handler, resolve_handler

BOT_MODEL = Bot.BotModel()

VALID_COMMANDS = ['deploy',
                  'destroy',
                  'list',
                  'reboot',
                  'boot',
                  'shutdown',
                  'regr',
                  'prstatus',
                  'bldstat',
                  'user',
                  'help',
                  'resolve']




@slack_sdk.rtm.RTMClient.run_on(event='message')
def parse_bot_commands(**payload):
    """
        Parses a list of events coming from the Slack RTM API to find bot commands.
        Only parses messages that are DM'd to the bot.
    """
    event = payload["data"]
    # Checks to make sure that the message was sent by a user, not a bot
    if not "subtype" in event and not "bot_profile" in event:
        # Checks that the message was received from a DM
        #if event["channel"][0] == "D":    
        if event["channel"] == "D08RTRRR5C0":
            event["text"] = unidecode(event["text"])
            event["text"] = CommonHelpers.sanitize_bot_input(event["text"])
            try:
                handle_command(event)
            except (Auth.UnauthorizedUserError,
                    CommonHelpers.VmOwnershipError,
                    github.GheEmailNotPublicError,
                    github.NoContextToUpdateError,
                    argparse.ArgumentParserError,
                    bluepages_helper.BluepagesError,
                    Bot.BotError) as err:
                # log event
                Bot.log_event(
                    "Email Unavailable when logging caught exceptions.",
                    event,
                    {}
                )
                Bot.log("INFO", "Error occurred: {}".format(str(err)))
                # Notify user of their error
                slack_helpers.send_slack_message(
                    BOT_MODEL.slack_messaging_client,
                    channel=event["channel"],
                    text=str(err)
                )
            except requests.exceptions.RequestException as err:

                Bot.log("ERROR", "API request failed to connect.")
                Bot.log("ERROR", "Error: {}".format(str(err)))
                Bot.log("ERROR", traceback.format_exc())
                Bot.log_event(
                    "Email Unavailable when logging caught exceptions.",
                    event,
                    {}
                )

                print(traceback.format_exc())
                # Notify user of their error
                slack_helpers.send_slack_message(
                    BOT_MODEL.slack_messaging_client,
                    channel=event["channel"],
                    text=HelpStrings.API_CALL_ERROR
                )
            except (slack_sdk.errors.SlackClientError, SocketError) as err:
                # This exception catches Slack API failure exceptions...this happens
                # frequently. Up to 3-4 times a day on a bad day
                Bot.log("CRITICAL", 'Caught websocket disconnect, reconnecting...')
                Bot.log("CRITICAL", err)
                Bot.log("CRITICAL", traceback.format_exc())
                # this api call is to alert myself on slack that the api crashed
                slack_helpers.send_slack_message(
                    BOT_MODEL.slack_messaging_client,
                    channel=slack_helpers.BOT_ALERTS_CHANNEL_ID,
                    text="RTM Crashed. Restarting..."
                )
                # Re-execute this script. For some reason, if I just reconnect to the API it drops
                # a lot more frequently than if I restart the script altogether
                os.execl("./db2buildbot.py MyDb2 has started - Internal auto-restart", *sys.argv)
            except KeyboardInterrupt:
                Bot.log("INFO", 'Slackbot manually restarted.')
                print('Slackbot manually restarted...standby while the bot restarts.')
                slack_helpers.send_slack_message(
                    BOT_MODEL.slack_messaging_client,
                    channel=slack_helpers.BOT_ALERTS_CHANNEL_ID,
                    text="MyDb2 has been manually restarted...standby while the bot restarts."
                )
                # Restart the bot
                os.execl("./db2buildbot.py MyDb2 has started - Internal auto-restart", *sys.argv)
            except BaseException as err:
                # Catch ALL exceptions so that the bot never dies
                Bot.log("ERROR", "Error-causing event: \n{}".format(event))
                Bot.log("ERROR", err)
                Bot.log("ERROR", traceback.format_exc())
                print(err)
                Bot.log("ERROR", "Ignoring the exit and sending output to user if relevant.")

                # Message the user that their message caused an error
                # 99% of the failures this catches are caused by bad commands
                # that the users sent and argparse caught
                if event:
                    print("ERROR EVENT:")
                    print(type(event))
                    print(event)
                    slack_helpers.send_slack_message(
                        BOT_MODEL.slack_messaging_client,
                        channel=event["channel"],
                        text=str(err)
                    )
                # I set the channel to none in case I fall into some endless
                # loop of errors live I've seen before from RTM api crashing
                event = None

                print(type(err).__name__)
                print(err.__class__.__name__)



def handle_command(event):
    """
        Handles command once the command is validated
    """
    # Finds and executes the given command, filling in response
    command = event["text"]
    response = None
    split_command = command.split()
    BOT_MODEL.refresh_db2_conn()
    user_email = slack_helpers.get_email_from_slack_id(BOT_MODEL.slack_api_client, event["user"])

    if split_command[0] in VALID_COMMANDS:
        '''
         If the command passed is valid, this code will call the `handler` function from the module
         of the command called
        '''

        Bot.log("INFO", "Valid command")

        appropriate_handler = getattr(globals()[split_command[0]+"_handler"], 'handler')
        response = appropriate_handler(event, user_email, BOT_MODEL)

        # response = BOT_MODEL.parsers[split_command[0]].handler(event, user_email, BOT_MODEL)
    else:
        Bot.log("INFO", "-----------------")
        Bot.log_event(user_email, event, {})
        Bot.log("INFO", "-----------------")
        response = HelpStrings.COMMAND_NOT_FOUND_ERROR

    Bot.log("INFO", "---------- BOT RESPONSE -----------\n{}".format(response))

    # Sends the response back to the channel
    if isinstance(response, list):
        for message in response:
            if message:
                slack_helpers.send_slack_message(
                    BOT_MODEL.slack_messaging_client,
                    channel=event["channel"],
                    text=message,
                    link_names=False
                )
    else:
        slack_helpers.send_slack_message(
            BOT_MODEL.slack_messaging_client,
            channel=event["channel"],
            text=response,
            link_names=False
        )
        
def main():
    SUCCESSFUL_START = False
    # The way the Fyre package works is that it looks for ENV FYRE_USER_NAME and FYRE_API_KEY
    # for creds. This is a convenient way to do things as it makes hiding creds even easier than
    # me having to manually import env vars like I do at the top of the script
    FYRE_CONN = fyre.Fyre()
    BOT_MODEL = Bot.BotModel()

    print("MyDb2 Started")
    Bot.logging.info("MyDb2 has started")
    slack_helpers.send_slack_message(
        BOT_MODEL.slack_messaging_client,
        channel=slack_helpers.BOT_ALERTS_CHANNEL_ID,
        text=' '.join(sys.argv[1:]) or 'MyDb2 has been started manually.'
    )

    while not SUCCESSFUL_START:
        try:
            BOT_MODEL.slack_rtm_client.start()
            SUCCESSFUL_START = True
        except urllib.error.URLError:
            SUCCESSFUL_START = False
            slack_helpers.send_slack_message(
                BOT_MODEL.slack_messaging_client,
                channel=slack_helpers.BOT_ALERTS_CHANNEL_ID,
                text="Failed to start MyDb2 - Retrying in 3 seconds"
            )
            time.sleep(3)
