import os
import time
from slack_sdk import WebClient
import subprocess
import json
import ibm_db

SLACK_BOT_TOKEN = os.environ.get("MYDB2_BOT_TOKEN")
if not SLACK_BOT_TOKEN:
    raise RuntimeError("MYDB2_BOT_TOKEN environment variable is not set.")

client = WebClient(token=SLACK_BOT_TOKEN)

DB2_HOST = os.environ.get('DB2_INSTANCE_HOST')
DB2_PORT = os.environ.get('DB2_INSTANCE_PORT')
DB2_USERNAME = os.environ.get('DB2_INSTANCE_USERNAME')
DB2_PW = os.environ.get('DB2_INSTANCE_PW')

if not all([DB2_HOST, DB2_PORT, DB2_USERNAME, DB2_PW]):
    raise RuntimeError("One or more required DB2 environment variables are not set.")

DB2_CONN = ibm_db.connect(
    'DATABASE=BLUDB;'
    'HOSTNAME=' + DB2_HOST + ';'
    'PORT=' + DB2_PORT + ';'
    'PROTOCOL=TCPIP;'
    'UID=' + DB2_USERNAME + ';'
    'PWD=' + DB2_PW + ';', '', ''
)
DEV_TABLE = "DEVELOPERS"

def get_userID_from_email(email):
    """
    Returns the Slack user ID for a given email address.
    """
    if not email:
        print("Email is None or empty.")
        return None
    try:
        while True:
            response = client.users_lookupByEmail(email=email)
            if response.get("ok"):
                return response["user"].get("id")
            elif response.get("error") == "ratelimited":
                print("Rate limited while looking up user by email. Retrying...")
                time.sleep(60)  # Wait for 60 seconds before retrying
            else:
                print(f"Error looking up user by email {email}: {response.get('error')}")
                return None
    except Exception as e:
        print(f"Error looking up user by email {email}: {e}")
        return None

def update_dev_db(email, channel_id):
    """
    Updates the development database with the Slack DM channel ID to email mapping.
    """
    lower_email = email.lower()
    query = f"UPDATE {DEV_TABLE} SET slack_channel_id = '{channel_id}' WHERE lower(dev_email) = '{lower_email}'"
    try:
        return ibm_db.exec_immediate(DB2_CONN, query)
    except Exception as e:
        print(f"Error updating dev_db for email {email}: {e}")
        return None


def get_channel_id_from_email(email):
    """
    Returns the Slack DM channel ID for a given email address, or None if not found.
    """
    email = email.lower()  # Ensure email is lowercase to avoid case sensitivity issues
    user_id = get_userID_from_email(email)
    if not user_id:
        print(f"Could not find user ID for email: {email}")
        return None
    try:
        while True:
            response = client.conversations_open(users=user_id)
            if response.get("ok"):
                return response["channel"].get("id")
            elif response.get("error") == "ratelimited":
                print("Rate limited while opening conversation. Retrying...")
                time.sleep(60)  # Wait for 60 seconds before retrying
            else:
                print(f"Error opening conversation for user {user_id}: {response.get('error')}")
                return None
    except Exception as e:
        print(f"Error getting channel for user {user_id}: {e}")
        return None
    
def update_nulls_in_dev_table(email):
    """
    Updates the development table to set slack_channel_id to the appropriate channel ID where it is currently NULL.
    """
    channel_id = get_channel_id_from_email(email)
    if not channel_id:
        print(f"Could not find channel ID for email: {email}")
        return None
    query = f"UPDATE {DEV_TABLE} SET slack_channel_id = '{channel_id}' WHERE slack_channel_id IS NULL AND lower(dev_email) = '{email.lower()}'"
    try:
        return ibm_db.exec_immediate(DB2_CONN, query)
    except Exception as e:
        print(f"Error updating slack_channel_id for email {email}: {e}")
        return None

def get_all_dev_emails():
    """
    Returns a list of all developer emails from the development table.
    """
    try:
        query = f"SELECT dev_email FROM {DEV_TABLE} where slack_channel_id IS NULL"
        stmt = ibm_db.exec_immediate(DB2_CONN, query)
        emails = []
        while True:
            row = ibm_db.fetch_assoc(stmt)
            if not row:
                break
            emails.append(row['DEV_EMAIL'])
        print(emails)
        return emails
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return []

def main():
    print("Connecting to the database...")
    if not DB2_CONN:
        print("Error connecting to the database.")
        return
    print("Connected to the database successfully.")
    print("Updating Slack channel IDs in the development table...")
    emails = get_all_dev_emails()
    if not emails:
        print("No developer emails found in the development table.")
        ibm_db.close(DB2_CONN)
        return
    for email in emails:
        update_nulls_in_dev_table(email)
    print("All Slack channel IDs updated successfully.")
    ibm_db.close(DB2_CONN)

if __name__ == "__main__":
    main()