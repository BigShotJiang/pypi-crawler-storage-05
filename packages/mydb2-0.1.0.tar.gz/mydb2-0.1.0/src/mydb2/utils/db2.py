#!/usr/bin/env python
'''
 This model is poorly named, its purpose is to handle Db2 interactions for the MyDb2 backend.
'''
import os
import sys
import argparse
import ibm_db
import uuid

# Connection Constant
# Make sure to export the credentials before running this script
DB2_HOST = os.environ.get('DB2_INSTANCE_HOST')
DB2_PORT = os.environ.get('DB2_INSTANCE_PORT')
DB2_USERNAME = os.environ.get('DB2_INSTANCE_USERNAME')
DB2_PW = os.environ.get('DB2_INSTANCE_PW')
INVENTORY_TABLE_NAME = "DEV_ENVIRONMENTS"
DELETED_INVENTORY_TABLE_NAME = "DELETED_DEV_ENVIRONMENTS"
DEV_SYSTEM_POOL_TABLE = "DEV_SYSTEM_POOL"
CHECKOUT_HISTORY_TABLE = "CHECKOUT_HISTORY"
PIPELINE_STATUS_TABLE = "DESTROY_PIPELINE_STATUS"

DB2_CONN = ibm_db.connect(
    'DATABASE=BLUDB;'
    'HOSTNAME=' + DB2_HOST + ';'
    'PORT=' + DB2_PORT + ';'
    'PROTOCOL=TCPIP;'
    'UID=' + DB2_USERNAME + ';'
    'PWD=' + DB2_PW + ';', '', ''
)

def _craft_insert_query(table_name, insert_args_dict, valid_column_names=None):
    '''
     Given a table name and list of columns and their values, this function will craft a query that
     will insert a record into the table using the columns/values provided.
    '''
    first_column = True

    first_half = "INSERT INTO {} (".format(table_name)
    second_half = " VALUES ("

    for key in insert_args_dict:
        if not valid_column_names or key in valid_column_names and insert_args_dict[key]:

            if not first_column:
                first_half += ", "
                second_half += ", "

            first_half += "{}".format(key)
            second_half += "'{}'".format(insert_args_dict[key])
            first_column = False

    first_half += ")"
    second_half += ")"

    return first_half + second_half

def db2_insert(arguments):
    '''
     Uses the query generated from _craft_insert_query() to insert entries into the inventory table
    '''
    query = _craft_insert_query(
        arguments.inv_table_name,
        {
            "owner_email": arguments.owner_email,
            "deploy_status": arguments.deploy_status,
            "fqdn": arguments.fqdn,
            "hostname": arguments.hostname,
            "cluster_name": arguments.cluster_name,
            "node_name": arguments.node_name,
            "node_count": arguments.node_count,
            "node_size": arguments.node_size,
            "node_cpu_count": arguments.node_cpu_count,
            "node_ram": arguments.node_ram,
            "node_disk_size": arguments.node_disk_size,
            "os": arguments.os,
            "platform": arguments.platform,
            "site": arguments.site,
            "product_group_id": arguments.product_group_id,
            "configuration_type": arguments.config_type,
            "configured_user": arguments.configured_user,
            "hardware_type": arguments.hardware_type
        }
    )

    print("SQL INSERT QUERY: {}".format(query))
    return ibm_db.exec_immediate(DB2_CONN, query)

def db2_update_status(arguments):
    '''
     This function updates an inventory record's status
    '''
    query = "Update {} SET DEPLOY_STATUS = '{}' WHERE FQDN='{}';".format(
        INVENTORY_TABLE_NAME,
        arguments.status,
        arguments.fqdn
    )

    return ibm_db.exec_immediate(DB2_CONN, query)

def db2_update_vmid(arguments):
    '''
     This function updates an inventory record's VM ID for Fyre 3 VMs
    '''
    query = "Update {} SET vm_id = '{}' WHERE FQDN='{}';".format(
        INVENTORY_TABLE_NAME,
        arguments.vm_id,
        arguments.fqdn
    )

    return ibm_db.exec_immediate(DB2_CONN, query)

def db2_get_vmid(arguments):
    '''
     This function gets the vm id in order to interact with the Fyre 3 API
    '''
    query = "SELECT VM_ID FROM {} WHERE FQDN='{}' FETCH FIRST ROW ONLY;".format(
        INVENTORY_TABLE_NAME,
        arguments.fqdn
    )
    stmt = ibm_db.exec_immediate(DB2_CONN, query)
    while ibm_db.fetch_row(stmt) != False:
        return ibm_db.result(stmt, "VM_ID")

def db2_delete(arguments):
    '''
     This function will delete a record from the Inventory table
    '''
    query = "DELETE FROM {} WHERE FQDN='{}';".format(INVENTORY_TABLE_NAME, arguments.fqdn)
    return ibm_db.exec_immediate(DB2_CONN, query)

def get_user_from_fqdn(fqdn):
    '''
     This function will return the user that owns a machine based on its FQDN
    '''
    query = "SELECT OWNER_EMAIL FROM {} WHERE FQDN='{}' FETCH FIRST ROW ONLY;".format(
        INVENTORY_TABLE_NAME,
        fqdn
    )
    stmt = ibm_db.exec_immediate(DB2_CONN, query)
    while ibm_db.fetch_row(stmt) != False:
        return ibm_db.result(stmt, "OWNER_EMAIL")
    
def set_pipeline_to_completed(arguments):
    '''
     This function will set the pipeline status to completed in the inventory table
    '''
    query = ("UPDATE {} SET STATUS = 'Completed' WHERE FQDN='{}'".format(
        PIPELINE_STATUS_TABLE,
        arguments.fqdn
    ))
    return ibm_db.exec_immediate(DB2_CONN, query)

def set_pipeline_to_started(arguments):
    '''
     This function will set the pipeline status to started in the inventory table
    '''
    status_id = str(uuid.uuid4())  # Generate a unique status ID using UUID
    user = get_user_from_fqdn(arguments.fqdn)
    query = ("INSERT INTO {} (FQDN, STATUS, DESTROY_TIME, USER) VALUES ('{}', 'Started', CURRENT_TIMESTAMP, '{}')".format(
        PIPELINE_STATUS_TABLE,
        arguments.fqdn,
        user
    ))
    return ibm_db.exec_immediate(DB2_CONN, query)

def update_status(arguments):
    '''
     This function will update the status of a machine to released or leased based on the provided argument.
    '''
    if arguments.leased_system_value:
        query = "UPDATE {} SET STATUS = 'Released', OCCUPANT_EMAIL = '' WHERE FQDN='{}';".format(
            DEV_SYSTEM_POOL_TABLE,
            arguments.fqdn
        )
        result1 = ibm_db.exec_immediate(DB2_CONN, query)

    query2 = ("UPDATE {} SET DEPLOY_STATUS = 'Released', OWNER_EMAIL = '' WHERE FQDN='{}'".format(
        INVENTORY_TABLE_NAME,
        arguments.fqdn
    ))
    result2 = ibm_db.exec_immediate(DB2_CONN, query2)

    return result1, result2

def move_inventory_record(arguments):
    '''
     This function will move a record from 1 table to another table
    '''
    query = ("INSERT INTO {}(OWNER_EMAIL, DEPLOY_STATUS, FQDN, HOSTNAME, CLUSTER_NAME, NODE_NAME, "
             "NODE_COUNT, NODE_SIZE, NODE_CPU_COUNT, NODE_RAM, NODE_DISK_SIZE, OS, PLATFORM, SITE, "
             "DEPLOY_DATE, PRODUCT_GROUP_ID, CONFIGURATION_TYPE, CONFIGURED_USER, HARDWARE_TYPE, VM_ID) "
             "SELECT * FROM {} WHERE FQDN='{}'".format(
                 arguments.dest_table,
                 arguments.source_table,
                 arguments.fqdn
             ))
    print("SQL Query: {}".format(query))
    return ibm_db.exec_immediate(DB2_CONN, query)

def checkout_dev_system(arguments):
    '''
     This function will mark a host as checked out in the table tracking the dev system pool.
     It will also add a record to the CHECKOUT_HISTORY table.
    '''
    find_reserved_host_query = ("SELECT count(*) from {table} where STATUS='Reserved' AND "
                                "FQDN='{fqdn}' AND OCCUPANT_EMAIL='{email}'".format(
                                    table=arguments.dev_pool_table,
                                    fqdn=arguments.fqdn,
                                    email=arguments.occupant_email
                                ))
    reserved_host_count = int(ibm_db.fetch_assoc(
                             ibm_db.exec_immediate(DB2_CONN, find_reserved_host_query)
                          )['1'])

    if reserved_host_count != 1:
        print("Query to find reserved host count: {}".format(find_reserved_host_query))
        print("Reserved host count for {}: {}".format(
            arguments.occupant_email,
            reserved_host_count)
        )
        sys.exit("You can only have 1 reserved host at a time. "
                 "Exiting as you have {} reserved hosts.".format(reserved_host_count))


    checkout_query = ("UPDATE {table} SET STATUS='Occupied', OCCUPANT_USERNAME='{user}', "
             "OCCUPANT_SLACK_CHANNEL_ID='{slack}', LEASE_DURATION={duration}, "
             "CHECKOUT_TIME=CURRENT TIMESTAMP where FQDN='{fqdn}' AND STATUS='Reserved' AND "
             "OCCUPANT_EMAIL='{email}'".format(
                 table=arguments.dev_pool_table,
                 email=arguments.occupant_email,
                 user=arguments.occupant_user,
                 slack=arguments.occupant_slack_channel_id,
                 duration=arguments.lease_duration,
                 fqdn=arguments.fqdn
             ))
    print("Checkout SQL Query: {}".format(checkout_query))
    ibm_db.exec_immediate(DB2_CONN, checkout_query)

    checkout_history_query = _craft_insert_query(
        CHECKOUT_HISTORY_TABLE,
        {
            'FQDN': arguments.fqdn,
            'STATE': 'Active',
            'OCCUPANT_EMAIL': arguments.occupant_email
        }
    )
    print("Checkout History SQL Query: {}".format(checkout_history_query))
    ibm_db.exec_immediate(DB2_CONN, checkout_history_query)

def checkin_dev_system(arguments):
    '''
     This function will mark a dev system as VACANT indicating that it may now be checked out again,
     and it will set the CHECKIN_TIMESTAMP value in the checkout history table
    '''
    query = ("UPDATE {table} SET STATUS='Vacant', OCCUPANT_EMAIL='', "
             "OCCUPANT_SLACK_CHANNEL_ID=NULL, CHECKOUT_TIME=NULL, LEASE_DURATION=NULL where "
             "FQDN='{fqdn}' and STATUS in ('Occupied', 'Reserved', 'Released')".format(
                 table=arguments.dev_pool_table,
                 fqdn=arguments.fqdn
             ))

    print("Checkin SQL Query: {}".format(query))
    ibm_db.exec_immediate(DB2_CONN, query)

    checkout_history_query = ("UPDATE {table} SET STATE='Returned', CHECKIN_TIMESTAMP=CURRENT "
                              "TIMESTAMP WHERE FQDN='{fqdn}' AND STATE='Active'".format(
                                table=CHECKOUT_HISTORY_TABLE,
                                fqdn=arguments.fqdn
                              ))
    print("Checkout history SQL Query: {}".format(checkout_history_query))
    ibm_db.exec_immediate(DB2_CONN, checkout_history_query)


if __name__ == "__main__":
    # Parser stuff is for command line options, pretty self explanatory
    MAIN_PARSER = argparse.ArgumentParser(description='Wrapper for db2 python lib.')
    MAIN_PARSER.add_argument(
        '-c',
        '--command',
        dest='command',
        choices=['insert', 'update', 'updatevm', 'getvmid', 'delete', 'move', 'checkout', 'checkin', 'setpipeline', 'updatestatus', 'completepipeline'],
        required=True,
        help='Tell the tool which command you want to use'
    )

    INSERT_PARSER = argparse.ArgumentParser(description='Tool to help with inserting into Db2 db.')
    INSERT_PARSER.add_argument('--owner-email', dest='owner_email', required=True)
    INSERT_PARSER.add_argument('--deploy-status', dest='deploy_status', required=True)
    INSERT_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    INSERT_PARSER.add_argument('--hostname', dest='hostname', required=True)
    INSERT_PARSER.add_argument('--cluster-name', dest='cluster_name', required=True)
    INSERT_PARSER.add_argument('--node-name', dest='node_name', required=True)
    INSERT_PARSER.add_argument('--node-count', dest='node_count', required=True)
    INSERT_PARSER.add_argument('--node-size', dest='node_size', required=True)
    INSERT_PARSER.add_argument('--node-cpu-count', dest='node_cpu_count', required=True)
    INSERT_PARSER.add_argument('--node-ram', dest='node_ram', required=True)
    INSERT_PARSER.add_argument('--node-disk-size', dest='node_disk_size', required=True)
    INSERT_PARSER.add_argument('--os', dest='os', required=True)
    INSERT_PARSER.add_argument('--platform', dest='platform', required=True)
    INSERT_PARSER.add_argument('--site', dest='site', required=True)
    INSERT_PARSER.add_argument('--product-group-id', dest='product_group_id', required=True)
    INSERT_PARSER.add_argument('--configuration-type', dest='config_type', required=True)
    INSERT_PARSER.add_argument('--hardware-type', dest='hardware_type', required=True)
    INSERT_PARSER.add_argument(
        '--configured-user',
        dest='configured_user',
        required=False,
        default=""
    )
    INSERT_PARSER.add_argument(
        '--inv-table-name',
        dest='inv_table_name',
        default=INVENTORY_TABLE_NAME,
        required=False
    )
    INSERT_PARSER.set_defaults(
        handler=db2_insert
    )


    UPDATE_PARSER = argparse.ArgumentParser(description='Tool to help with update Db2 db.')
    UPDATE_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    UPDATE_PARSER.add_argument('--status', dest='status', required=True)
    UPDATE_PARSER.set_defaults(
        handler=db2_update_status
    )

    UPDATE_VM_PARSER = argparse.ArgumentParser(description='Tool to help with updating the VM id.')
    UPDATE_VM_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    UPDATE_VM_PARSER.add_argument('--vmid', dest='vm_id', required=True)
    UPDATE_VM_PARSER.set_defaults(
        handler=db2_update_vmid
    )

    GET_VM_PARSER = argparse.ArgumentParser(description='Tool to help with getting the VM id.')
    GET_VM_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    GET_VM_PARSER.set_defaults(
        handler=db2_get_vmid
    )


    DELETE_PARSER = argparse.ArgumentParser(description='Tool to help with deleting from Db2 db.')
    DELETE_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    DELETE_PARSER.set_defaults(
        handler=db2_delete
    )

    MOVE_PARSER = argparse.ArgumentParser(description='Tool to move deleted hosts to another table')
    MOVE_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    MOVE_PARSER.add_argument(
        '--source-table',
        dest='source_table',
        default=INVENTORY_TABLE_NAME,
        required=False
    )
    MOVE_PARSER.add_argument(
        '--dest-table',
        dest='dest_table',
        default=DELETED_INVENTORY_TABLE_NAME,
        required=False
    )
    MOVE_PARSER.set_defaults(
        handler=move_inventory_record
    )

    CHECKOUT_PARSER = argparse.ArgumentParser(description='Tool to checkout dev systems from ')
    CHECKOUT_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    CHECKOUT_PARSER.add_argument(
        '--dev-pool-table',
        dest='dev_pool_table',
        default=DEV_SYSTEM_POOL_TABLE,
        required=False
    )
    CHECKOUT_PARSER.add_argument(
        '--occupant-email',
        dest='occupant_email',
        help='Email for the user checking out the system',
        required=True
    )
    CHECKOUT_PARSER.add_argument(
        '--occupant-username',
        dest='occupant_user',
        help='LDAP username for the user checking out the system',
        required=True
    )
    CHECKOUT_PARSER.add_argument(
        '--slack-channel-id',
        dest='occupant_slack_channel_id',
        help='Slack channel ID for the user checking out the system',
        required=True
    )
    CHECKOUT_PARSER.add_argument(
        '--duration',
        dest='lease_duration',
        help='Lease duration (hours)',
        type=int,
        required=True
    )
    CHECKOUT_PARSER.set_defaults(
        handler=checkout_dev_system
    )


    CHECKIN_PARSER = argparse.ArgumentParser(description='Tool to checkout dev systems from ')
    CHECKIN_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    CHECKIN_PARSER.add_argument(
        '--dev-pool-table',
        dest='dev_pool_table',
        default=DEV_SYSTEM_POOL_TABLE,
        required=False
    )
    CHECKIN_PARSER.set_defaults(
        handler=checkin_dev_system
    )

    SETPIPELINE_PARSER = argparse.ArgumentParser(description='Tool to set the pipeline status to started.')
    SETPIPELINE_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    SETPIPELINE_PARSER.set_defaults(
        handler=set_pipeline_to_started
    )

    COMPLETEPIPELINE_PARSER = argparse.ArgumentParser(description='Tool to set the pipeline status to completed.')
    COMPLETEPIPELINE_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    COMPLETEPIPELINE_PARSER.set_defaults(
        handler=set_pipeline_to_completed
    )


    UPDATESTATUS_PARSER = argparse.ArgumentParser(description='Tool to update the status of a machine.')
    UPDATESTATUS_PARSER.add_argument('--fqdn', dest='fqdn', required=True)
    UPDATESTATUS_PARSER.add_argument('--lease', dest='leased_system_value', required=True, default=False)
    UPDATESTATUS_PARSER.set_defaults(
        handler=update_status
    )

    MAIN_ARGS, REMAINING_ARGS = MAIN_PARSER.parse_known_args()

    command_parser = {
        "insert": INSERT_PARSER,
        'update': UPDATE_PARSER,
        "updatevm": UPDATE_VM_PARSER,
        "getvmid": GET_VM_PARSER,
        'delete': DELETE_PARSER,
        'move': MOVE_PARSER,
        'checkout': CHECKOUT_PARSER,
        'checkin': CHECKIN_PARSER,
        'setpipeline': SETPIPELINE_PARSER,
        'updatestatus': UPDATESTATUS_PARSER,
        'completepipeline': COMPLETEPIPELINE_PARSER
    }

    args, ignored_args = command_parser[MAIN_ARGS.command.lower()].parse_known_args(REMAINING_ARGS)
    results = args.handler(args)
    print(results or "Transaction Completed")
