#!/usr/bin/env python3
'''
 This script is written to run as part of the automated access revocation for MyDb2 checked out
 development systems. At the time of writing this, devs can only check out AIX hosts, but this
 should work with any system in the table you give it(provided you're following the same table
 definition).

 IMPORTANT: All time data for MyDb2 is stored in UTC(GMT), and as such, any scripting needs to use
            that timezone as well.
'''
import os
import datetime
import time
import urllib
import requests
import argparse
import ibm_db
import slack_sdk
from jenkinsapi.jenkins import Jenkins, JenkinsAPIException

# Connection Constants
# Make sure to export the credentials before running this script
DB2_HOST = os.environ.get('DB2_INSTANCE_HOST')
DB2_PORT = os.environ.get('DB2_INSTANCE_PORT')
DB2_USERNAME = os.environ.get('DB2_INSTANCE_USERNAME')
DB2_PW = os.environ.get('DB2_INSTANCE_PW')
DEV_SYSTEM_POOL_TABLE = "DEV_SYSTEM_POOL"
DB2_CONN = ibm_db.connect(
    'DATABASE=BLUDB;'
    'HOSTNAME=' + DB2_HOST + ';'
    'PORT=' + DB2_PORT + ';'
    'PROTOCOL=TCPIP;'
    'UID=' + DB2_USERNAME + ';'
    'PWD=' + DB2_PW + ';', '', ''
)

JENKINS_URL = 'https://hyc-db2-riot-jenkins.swg-devops.com'
W3_ID = 'db2infra@ca.ibm.com'
JENKINS_SYSTEM_CLEANUP_JOB_NAME = ""

arg_parser = argparse.ArgumentParser()
arg_parser.add_argument(
    '--slack-token',
    dest='slack_bot_token',
    required=True,
    help='The slack token to be used for the slack alerts. Needs to be the Bot token(xoxb-*).'
)
arg_parser.add_argument(
    '--jenkins-token',
    dest='jenkins_token',
    required=True,
    help='The Jenkins token to be used to build Jenkins jobs.'
)

WARNING_WINDOW_HOURS = 24
NOW = datetime.datetime.utcnow()


def _build_job(jenkins_conn, job, job_params, num_retries=10):
    '''
     This job will build any jenkins job based on the job name passed.

     Arguments:
        - job :str: - Name of job to build
        - job_params :dict: - dict of parameters to pass to job
        - num_retries :int: (optional) - number of retries for the API call in case it fails
    '''
    api_call_attempts = 0
    try_request_again = True
    while try_request_again:
        try:
            api_call_attempts += 1
            Jenkins.build_job(jenkins_conn, job, job_params)
            try_request_again = False
            return True
        except (requests.exceptions.RequestException, JenkinsAPIException):
            if api_call_attempts < num_retries+1:
                print("Build request to Jenkins failed, retrying...")
            else:
                try_request_again = False
                print("Failed to make the API call to Jenkins {} times in a row. "
                        "Giving up.".format(api_call_attempts))
                return False

def fetch_results(command):
    '''
     Fetches the results from a Db2 SELECT query into a list of dicts where each dict is a row
    '''
    ret = []
    result = ibm_db.fetch_assoc(command)
    while result:
        # This builds a list in memory. Theoretically, if there's a lot of rows,
        # we could run out of memory. In practice, I've never had that happen.
        # If it's ever a problem, you could use
        #     yield result
        # Then this function would become a generator. You lose the ability to access
        # results by index or slice them or whatever, but you retain
        # the ability to iterate on them.
        ret.append(result)
        result = ibm_db.fetch_assoc(command)
    return ret  # Ditch this line if you choose to use a generator.

def get_leased_hosts(db2_conn, lease_table_name=None):
    '''
     Queries the MyDb2 backend tables and returns all the hosts that are currently checked out
    '''
    query = f"SELECT * FROM {lease_table_name} where STATUS='Occupied';"
    return fetch_results(ibm_db.exec_immediate(db2_conn, query))

def warn_expiry(slack_channel_id=None, username=None, fqdn=None, expiry_time=None):
    '''
     Sends the user a slack message warning them that their VM lease will expire soon
    '''
    send_slack_message(
        slack_messaging_client,
        text=f"Heads up - Your access to {username}@{fqdn} will be revoked at: {expiry_time} GMT",
        channel=slack_channel_id
    )
    print("Sent slack message ")

    _build_job(
        jenkins,
        JENKINS_SYSTEM_CLEANUP_JOB_NAME,
        {},
        num_retries=10
    )
    print("Jenkins job built.")


def return_expired_host(slack_channel_id=None, username=None, fqdn=None):
    '''
     Does the following:
        1. Kicks off a Jenkins job that will revoke the user's access to the host, clean up the
           host, and marks the host as vacant once again.
        2. Notifies the user that their lease has expired and their access has been revoked.
    '''
    send_slack_message(
        slack_messaging_client,
        text=(f"Heads up - Your access to {username}@{fqdn} is being revoked as the lease period "
              "has expired. Your access has been revoked."),
        channel=slack_channel_id
    )
    print("Sent slack message ")


def send_slack_message(slack_conn, text=None, channel=None, link_names=False, retries=5):
    '''
     This custom slack send function will send a slack message but add some retry logic around the
     failures to avoid crashing and dropeed resopnse messages
    '''
    try_count = 0
    msg_sent = False

    if not text or not channel:
        raise ValueError("Must provide `text` and `channel` args.")


    while not msg_sent and try_count < retries:
        try:
            try_count += 1
            slack_conn.chat_postMessage(
                channel=channel,
                text=text,
                link_names=link_names
            )
            msg_sent = True
        except urllib.error.URLError:
            msg_sent = False
            print("Failed to send a message - Retrying in 2 seconds")
            time.sleep(2)


if __name__ == "__main__":

    args = arg_parser.parse_args()
    slack_messaging_client = slack_sdk.WebClient(
        args.slack_bot_token,
        timeout=30
    )


    jenkins = Jenkins(
        JENKINS_URL,
        W3_ID,
        args.jenkins_token
    )




    for host in get_leased_hosts(DB2_CONN, lease_table_name=DEV_SYSTEM_POOL_TABLE):
        host_lease_duration_datetime = datetime.timedelta(hours=host["LEASE_DURATION"])
        host_expiration_datetime = host["CHECKOUT_TIME"] + host_lease_duration_datetime
        warning_datetime = host_expiration_datetime - datetime.timedelta(hours=WARNING_WINDOW_HOURS)

        print(f"--------- Host: {host} -----------")
        print(f"CHECKOUT_TIME: {host['CHECKOUT_TIME']}")
        print(f"LEASE_DURATION: {host['LEASE_DURATION']}")
        print(f"EXPIRATION DATE: {host_expiration_datetime}")
        print(f"WARNING_DATE: {warning_datetime}")
        print(f"CURRENT_TIME: {NOW}")
        if host_expiration_datetime < NOW:
            return_expired_host(
                slack_channel_id=host["OCCUPANT_SLACK_CHANNEL_ID"],
                username=host["OCCUPANT_USERNAME"],
                fqdn=host["FQDN"]
            )
        elif warning_datetime < NOW < host_expiration_datetime:
            warn_expiry(
                slack_channel_id=host["OCCUPANT_SLACK_CHANNEL_ID"],
                username=host["OCCUPANT_USERNAME"],
                fqdn=host["FQDN"],
                expiry_time=host_expiration_datetime
            )
        else:
            print(f"The host - {host['FQDN']} - does not need a warning/expiry notice.")
