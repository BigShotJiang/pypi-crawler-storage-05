import ibm_db
import os
import argparse
import sys

DB2_HOST = os.environ.get('DB2_INSTANCE_HOST')
DB2_PORT = os.environ.get('DB2_INSTANCE_PORT')
DB2_USERNAME = os.environ.get('DB2_INSTANCE_USERNAME')
DB2_PW = os.environ.get('DB2_INSTANCE_PW')
DB2_CONN = ibm_db.connect(
    'DATABASE=BLUDB;'
    'HOSTNAME=' + DB2_HOST + ';'
    'PORT=' + DB2_PORT + ';'
    'PROTOCOL=TCPIP;'
    'UID=' + DB2_USERNAME + ';'
    'PWD=' + DB2_PW + ';', '', ''
)

# Parse command-line arguments
parser = argparse.ArgumentParser(description="Insert failure details into the database.")
parser.add_argument('--fqdn', required=True, help='Fully Qualified Domain Name')
parser.add_argument('--os', required=True, help='Operating System')
parser.add_argument('--platform', required=True, help='Platform')
parser.add_argument('--timestamp', required=True, help='Timestamp of the failure')
parser.add_argument('--failure', required=True, help='Failure message')
parser.add_argument('--failure-id', required=True, help='Failure ID')
parser.add_argument('--jenkins-link', required=True, help='Jenkins build link')

print(f"DEBUG: Raw arguments received: {sys.argv}")
args = parser.parse_args()

print(f"DEBUG: Parsed arguments - FQDN: {args.fqdn}, OS: {args.os}, Platform: {args.platform}, Timestamp: {args.timestamp}, Failure: {args.failure}, Failure ID: {args.failure_id}, Jenkins Link: {args.jenkins_link}")

def insert_failure_to_db(fqdn, os, platform, timestamp, failure, failure_id, jenkins_link):
    """
    Inserts a failure event into the database.

    Args:
        fqdn (str): Fully Qualified Domain Name.
        os (str): Operating System.
        platform (str): Platform.
        timestamp (str): Timestamp of the failure.
        failure (str): Failure message.
        failure_id (str): Failure ID.
        jenkins_link (str): Link to the Jenkins build.

    Returns:
        None
    """
    print(f"Inserting failure for FQDN: {fqdn}, OS: {os}, Platform: {platform}, Timestamp: {timestamp}, Failure: {failure}, Failure ID: {failure_id}, Jenkins Link: {jenkins_link}")
    try:
        query = "INSERT INTO DEPLOY_FAILURES (FQDN, OS, PLATFORM, TIME, FAILURE, FAILURE_ID, JENKINS_LINK) VALUES ('{fqdn}', '{os}', '{platform}', '{timestamp}', '{failure}', '{failure_id}', '{jenkins_link}')".format(fqdn=fqdn, os=os, platform=platform, timestamp=timestamp, failure=failure, failure_id=failure_id, jenkins_link=jenkins_link)
        print(query)
        ibm_db.exec_immediate(DB2_CONN, query)
    except Exception as e:
        print(f"Error logging failure to DB: {e}")


def assign_group_id(failure_id):
    """
    Assigns a group ID to a failure based on the combination of OS, platform, and failure message.

    Args:
        failure_id (str): Failure ID.

    Returns:
        None
    """
    find_info_query = "SELECT OS, PLATFORM, FAILURE FROM DEPLOY_FAILURES WHERE FAILURE_ID = '{failure_id}'".format(failure_id=failure_id)
    stmt = ibm_db.exec_immediate(DB2_CONN, find_info_query)
    result = ibm_db.fetch_tuple(stmt)

    if result:
        curr_os, curr_platform, curr_failure = result
        print(f"DEBUG: Found OS: {curr_os}, Platform: {curr_platform}, Failure: {curr_failure} for FAILURE_ID: {failure_id}")

        # Check if the combination exists in the database
        exists_query = "SELECT GROUP_ID FROM DEPLOY_FAILURES WHERE OS = '{os}' AND PLATFORM = '{platform}' AND FAILURE = '{failure}'".format(os=curr_os, platform=curr_platform, failure=curr_failure)
        stmt = ibm_db.exec_immediate(DB2_CONN, exists_query)
        group_id_result = ibm_db.fetch_tuple(stmt)
        print(f"DEBUG: Found GROUP_ID: {group_id_result} for OS: {curr_os}, Platform: {curr_platform}, Failure: {curr_failure}")

        if group_id_result and group_id_result[0]:
            group_id = group_id_result[0]
            print(f"DEBUG: Found existing group ID: {group_id} for OS: {curr_os}, Platform: {curr_platform}, Failure: {curr_failure}")
            update_query = "UPDATE DEPLOY_FAILURES SET GROUP_ID = '{group_id}' WHERE FAILURE_ID = '{failure_id}'".format(group_id=group_id, failure_id=failure_id)
            ibm_db.exec_immediate(DB2_CONN, update_query)
        else:
            group_id = generate_group_id()
            print(f"DEBUG: Generated new group ID: {group_id} for OS: {curr_os}, Platform: {curr_platform}, Failure: {curr_failure}")
            update_query = "UPDATE DEPLOY_FAILURES SET GROUP_ID = '{group_id}' WHERE FAILURE_ID = '{failure_id}'".format(group_id=group_id, failure_id=failure_id)
            ibm_db.exec_immediate(DB2_CONN, update_query)
    else:
        print(f"DEBUG: No matching failure found for FAILURE_ID: {failure_id}")

def generate_group_id():
    """
    Generates a new group ID for a failure event.

    Returns:
        str: A new group ID.
    """
    import uuid
    return str(uuid.uuid4())

def main(): 
    insert_failure_to_db(args.fqdn, args.os, args.platform, args.timestamp, args.failure, args.failure_id, args.jenkins_link)
    assign_group_id(args.failure_id)
    ibm_db.close(DB2_CONN)

if __name__ == "__main__":
    main()


