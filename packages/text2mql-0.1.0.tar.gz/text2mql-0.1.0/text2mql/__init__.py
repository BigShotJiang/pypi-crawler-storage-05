"""
text2mql - Memory Query Language

A language designed for querying memory within the text2memory ecosystem.
"""

__version__ = '0.1.0'
