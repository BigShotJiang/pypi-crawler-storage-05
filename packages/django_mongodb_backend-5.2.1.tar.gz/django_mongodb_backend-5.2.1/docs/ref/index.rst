=============
API reference
=============

.. toctree::
   :maxdepth: 2

   models/index
   forms
   contrib/index
   database
   django-admin
   utils
