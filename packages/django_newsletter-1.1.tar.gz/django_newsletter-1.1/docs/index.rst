.. django-newsletter documentation master file, created by
   sphinx-quickstart on Wed Nov 13 13:53:07 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to django-newsletter's documentation!
=============================================
Django app for managing multiple mass-mailing lists with both
plaintext as well as HTML templates with rich text widget
integration, images and a smart queueing system all right from
the admin interface.

.. toctree::
   :maxdepth: 2

   installation
   settings
   usage
   templates
   reference
   upgrading

* `Changes <https://github.com/jazzband/django-newsletter/blob/master/CHANGES.rst>`_ (GitHub)
* `Contributors <https://github.com/jazzband/django-newsletter/blob/master/AUTHORS.rst>`_ (GitHub)
