.. _reference:

============================================
Reference
============================================

For now, this documentation is automatically generated from the
source code.

Models
------
.. image:: graph_models.*

.. automodule:: newsletter.models

Forms
-----
.. automodule:: newsletter.forms

Views
-----
.. automodule:: newsletter.views
    :undoc-members:
