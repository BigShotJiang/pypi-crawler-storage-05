mod chapel;
mod course_grades;
mod course_schedule;
mod graduation_requirements;
mod lecture_assessment;
mod personal_course_schedule;
mod scholarships;
mod student_information;
