========
Appendix
========

References
==========
* `Redis rate limiting pattern #2 <http://redis.io/commands/INCR>`_
* `DomainTools redis rate limiter <https://github.com/DomainTools/rate-limit>`_
* `limits: python rate limiting utilities <https://limits.readthedocs.org>`_

.. include:: ../../CONTRIBUTIONS.rst
