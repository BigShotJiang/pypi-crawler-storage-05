from . import multicompany_easy_creation
from . import mail_compose_message
from . import partner_mail_list_wizard
