import setuptools

setuptools.setup(
    name="odoo_addon_energy_communities_mass_mailing",
    setup_requires=['setuptools-odoo'],
    odoo_addon=True,
)
