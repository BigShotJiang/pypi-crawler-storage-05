from django.contrib import admin
from .models import DatabaseCred

# Register your models here.
admin.site.register(DatabaseCred)