# Copyright 2016-2020 Dirk Thomas
# Licensed under the Apache License, Version 2.0

__version__ = "0.1.0"

from .argument_parser import TopLevelWorkspaceArgumentParserDecorator
