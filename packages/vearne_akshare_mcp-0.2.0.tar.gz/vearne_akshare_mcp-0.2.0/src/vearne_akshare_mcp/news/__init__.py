"""新闻模块"""

from .scraper import get_cn_news, get_hk_news

__all__ = ["get_cn_news", "get_hk_news"]
