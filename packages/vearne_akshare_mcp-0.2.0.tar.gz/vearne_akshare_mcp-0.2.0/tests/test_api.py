from vearne_akshare_mcp import cn, hk, us, get_cn_news, get_hk_news

if __name__ == "__main__":
    # print(cn.calculate_value("601818"))
    print(get_cn_news("SH600519"))
    # print(get_hk_news("00700"))

