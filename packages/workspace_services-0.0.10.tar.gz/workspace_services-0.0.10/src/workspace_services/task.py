# TODO: 实现 task 服务, 预加载所有 task 的 settings
