"""Top-level package for clustools.

A lightweight Python package providing essential clustering utilities for clustering workflows.
"""

__author__ = """Pablo Solís-Fernández"""
__email__ = "psolsfer@gmail.com"
__version__ = "0.1.0"
