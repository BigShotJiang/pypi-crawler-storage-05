"""
Talkaholic submodule for reservoir datasets
"""

from .reservoir import Reservoir

__all__ = ['Reservoir']
