SCHEMA_REGISTRY_HOST: str = "http://localhost"
SCHEMA_REGISTRY_PORT: int = 8081

BOOTSTRAP_SERVER: str = "localhost"
BOOTSTRAP_PORT: int = 9092


NEXUS_URL: str = "https://nexus.k8s-analytics.ostrovok.in/#browse/browse:datacontract_pypi"