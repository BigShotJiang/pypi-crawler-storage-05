# Developers' setup

1. Clone the repository
1. Install requirements

```bash
git clone https://github.com/postralai/masquerade.git
pip install -e .
```
