"""
MCP Server для интеграции с LightRAG API.
"""

__version__ = "0.1.0"
