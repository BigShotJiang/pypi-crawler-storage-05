from .__API__.compiler import compile
from .__API__.installer import pyipack
