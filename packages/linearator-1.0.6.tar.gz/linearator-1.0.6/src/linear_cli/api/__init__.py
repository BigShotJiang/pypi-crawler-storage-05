"""API module for Linear GraphQL client."""
