NO_REPLACEMENT = object()
