from latch_cli.services.register.register import (
    build_image,
    print_and_write_build_logs,
    register,
)
