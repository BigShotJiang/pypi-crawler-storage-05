"""Test data generator for the NRL project."""

__version__ = "0.1.0"
