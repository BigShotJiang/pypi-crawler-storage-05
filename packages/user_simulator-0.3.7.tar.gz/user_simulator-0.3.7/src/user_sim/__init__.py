# from .cli.sensei_chat import main as sensei_chat_main
# from .cli.sensei_check import main as sensei_check_main
# from .cli.init_project import main as init_project_main
# from .cli.validation_check import main as validation_check_main
# from .cli.gen_user_profile import main as gen_user_profile_main
#
#
# __all__ = [
#     "sensei_chat_main",
#     "sensei_check_main",
#     "init_project_main",
#     "validation_check_main",
#     "gen_user_profile_main"
# ]