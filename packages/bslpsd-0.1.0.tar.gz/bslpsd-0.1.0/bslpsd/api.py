import os
import numpy as np
import torch
from torch import nn
from matplotlib import colors
import matplotlib.pyplot as plt
from decimal import getcontext, Decimal
import datetime
import ast

class NeuralNetwork(nn.Module):
    def __init__(self, dims):
        super().__init__()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(dims[0] * dims[1], 512),
            nn.ReLU(),
            nn.Linear(512, 512),
            nn.ReLU(),
            nn.Linear(512, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.linear_relu_stack(x)

model_dictionary = {
    "HHN": ["broadband", "models/broadband_model_weights.pth", "(122, 151)"],
    "HHE": ["broadband", "models/broadband_model_weights.pth", "(122, 151)"],
    "HHZ": ["broadband", "models/broadband_model_weights.pth", "(122, 151)"],
    "HNN": ["strong motion", "models/strong_motion_model_weights.pth", "(114, 131)"],
    "HNE": ["strong motion", "models/strong_motion_model_weights.pth", "(114, 131)"], 
    "HNZ": ["strong motion", "models/strong_motion_model_weights.pth", "(114, 131)"], 
    "DP1": ["geophone", "models/geophone_model_weights.pth", "(124, 151)"],
    "DP2": ["geophone", "models/geophone_model_weights.pth", "(124, 151)"], 
    "DP3": ["geophone", "models/geophone_model_weights.pth", "(124, 151)"] 
} 

axis_dict = {
    "broadband": (-1.69897, 2.854109, -200.0, -50.0),
    "strong motion": (-1.69897, 2.553079, -150.0, -20.0),
    "geophone": (-2.096910, 2.531426, -200.0, -50.0)
}

def load_model(weights_path: str, dims: tuple) -> NeuralNetwork:
    model = NeuralNetwork(dims)
    model.load_state_dict(torch.load(weights_path))
    return model

def get_score_from_model(model: NeuralNetwork, filename: str) -> str:
    with open(filename, 'rb') as f:
        try:
            byteData = f.read()
            data = np.fromstring(byteData.decode(), sep =' ')
        except Exception as e:
            print(f"Error reading file {filename}: {e}")
            return "3"
        reduced_data = data[2::3]
        ml_data = torch.tensor(reduced_data).float()
        raw_result = model(ml_data).item()
        return raw_result

def get_sensor(filename: str) -> list[str]:
    file_array = filename.split('.')
    sensor_abbrev = file_array[3]
    sensor = model_dictionary.get(sensor_abbrev, ["unknown"])
    return sensor

def score(filename: str, directory: str) -> str:
    sensor = get_sensor(filename)
    if sensor == "unknown":
        return "error, unknown model"
    error_bool = False
    dims = ast.literal_eval(sensor[2])
    score = get_score_from_model(load_model(sensor[1], dims), filename)
    if float(score) < 0 or float(score) > 1:
        print(f"Error: Score {score} out of bounds for file {filename}")
        error_bool = True
        score = "2"
    if not error_bool:
        print(f"Score for {filename} using {sensor[0]} model is: {score}")
        plot(filename, dims, score, directory)
    return score

def plot(filename: str, dims: tuple, raw_result: str, dir_bin: str) -> None:
    bin_file = os.path.join(dir_bin, "bin")
    ok_file = os.path.join(bin_file, "ok")
    good_file = os.path.join(bin_file, "good")
    bad_file = os.path.join(bin_file, "bad")
    if not os.path.exists(bin_file):
        os.mkdir(bin_file)
    if not os.path.exists(ok_file):
        os.mkdir(ok_file)
    if not os.path.exists(good_file):
        os.mkdir(good_file)
    if not os.path.exists(bad_file):
        os.mkdir(bad_file)
    with open(filename, 'rb') as f:
        byteData = f.read()
        data = np.fromstring(byteData.decode(), sep =' ')
    sensor = get_sensor(filename)
    data = np.reshape(data, (dims[0] * dims[1], 3))
    data = np.swapaxes(data, 0, 1)
    x = data[0].reshape(dims)
    y = data[1].reshape(dims)
    z = data[2].reshape(dims)
    fig, ax = plt.subplots()
    rainbow = colors.LinearSegmentedColormap.from_list(name="rainbow", colors=['white', 'magenta', 'blue', 'cyan', 'lime', 'yellow', 'orange', 'red'])
    c = ax.pcolormesh(x, y, z, cmap=rainbow, vmin=0, vmax=0.30)
    ax.set_title(filename)
    result = round_to_sig_figs(raw_result, 3)
    ax.set_xlabel(result)
    ax.axis(axis_dict[sensor[0]])
    fig.colorbar(c, ax=ax)
    filename_array = filename.split('.')
    file_date = day_to_date(int(filename_array[5]), int(filename_array[4]))
    sensor = model_dictionary.get(filename_array[3], ["unknown"])[0]
    if float(result) < 0.4:
        dest_bin = good_file
    elif float(result) < 0.7:
        dest_bin = ok_file
    else:
        dest_bin = bad_file
    image_name = f"{filename_array[0]}.{filename_array[1]}.{sensor}.{file_date}"
    plt.savefig(f"{dest_bin}/{image_name}.png")
    plt.close()
    return None

def round_to_sig_figs(num: str, sig_figs: int) -> str:
    if num == 0:
        return '0'
    getcontext().prec = sig_figs
    d_num = Decimal(str(num))
    exponent = d_num.adjusted() - (sig_figs - 1)
    quantizer = Decimal('1e' + str(exponent))
    rounded_num = d_num.quantize(quantizer)
    return f"{rounded_num:f}"

def day_to_date(day_of_year: int, year: int) -> str:
    if not 1 <= day_of_year <= 366:
        return "Invalid day of year. Please enter a value between 1 and 366."
    try:
        date_string = f"{day_of_year} {year}"
        date_object = datetime.datetime.strptime(date_string, "%j %Y")
        formatted_date = date_object.strftime("%m.%d.%Y")
        return formatted_date
    except ValueError as e:
        return f"Error converting date: {e}"
