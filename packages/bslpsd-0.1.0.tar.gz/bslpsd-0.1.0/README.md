# bsl-psd-api
API Calls for BSL PSD project


Install Dependencies with:
pip install -r requirements.txt