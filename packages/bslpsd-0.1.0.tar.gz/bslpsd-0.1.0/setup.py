from setuptools import setup, find_packages

setup(
    name='bslpsd',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'torch',
        'matplotlib',
        'scikit-image'
    ],
    description='A package for scoring and analyzing broadband, strong motion, and geophone data.',
    author='Predicate-dev',
    author_email='your_email@example.com',
    url='https://github.com/Predicate-dev/bsl-psd-api',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
)
