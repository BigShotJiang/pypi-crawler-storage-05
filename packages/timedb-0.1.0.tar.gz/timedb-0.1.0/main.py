def main():
    print("Hello from timedb!")


if __name__ == "__main__":
    main()
