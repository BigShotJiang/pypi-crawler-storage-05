__version__ = "0.3.0"

__all_plugins__ = ["compas_masonry.scene"]
