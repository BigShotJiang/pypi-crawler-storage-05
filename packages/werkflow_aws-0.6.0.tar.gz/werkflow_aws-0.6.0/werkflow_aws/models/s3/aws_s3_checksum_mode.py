from typing import Literal

AWSS3ChecksumMode = Literal['ENABLED', 'DISABLED']