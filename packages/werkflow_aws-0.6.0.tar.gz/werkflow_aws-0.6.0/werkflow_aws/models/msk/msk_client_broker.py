from typing import Literal


MSKClientBroker = Literal[
    'TLS',
    'TLS_PLAINTEXT',
    'PLAINTEXT',
]