from pydantic import BaseModel


class AthenaDeleteNamedQueryResponse(BaseModel):
    pass