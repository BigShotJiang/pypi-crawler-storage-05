# export
from .managedata import ManageData

__all__ = [
    'ManageData'
]
