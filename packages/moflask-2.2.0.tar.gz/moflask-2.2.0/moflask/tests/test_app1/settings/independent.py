"""Entirely independent config file."""

A = "Independent settings"
