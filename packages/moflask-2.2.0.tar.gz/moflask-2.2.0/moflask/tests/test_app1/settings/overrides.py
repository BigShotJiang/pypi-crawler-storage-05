"""Most specific settings for config tests."""

# pylint: disable=wildcard-import,unused-wildcard-import

from moflask.tests.test_app1.settings.base import *

A = "My override setting"
