"""Settings files for the test_app1."""
