"""Default settings for config tests."""

A = "My default setting"
B = "base only"
TEST_A = "My default test setting"
