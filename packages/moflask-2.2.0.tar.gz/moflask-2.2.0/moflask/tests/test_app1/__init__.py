"""Test app for config tests."""
