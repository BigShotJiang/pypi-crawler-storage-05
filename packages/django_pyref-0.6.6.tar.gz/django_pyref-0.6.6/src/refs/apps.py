from django.apps import AppConfig


class RefsConfig(AppConfig):
    name = "refs"
