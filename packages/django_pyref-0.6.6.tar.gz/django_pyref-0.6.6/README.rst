============
django-pyref
============

The project, django-pyref, defines a Django app, refs, to create references for
scientific databases.  The goal of the app is to create a referencing system
where an administrator can obtain the full citation of an article from its
Digital Object Identifier (DOI). The stored references can be output in HTML,
BibTeX and JSON format.
