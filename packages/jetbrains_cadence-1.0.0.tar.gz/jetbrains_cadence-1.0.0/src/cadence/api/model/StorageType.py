from enum import Enum


class StorageType(str, Enum):
    DEFAULT = "DEFAULT"
    CUSTOM = "CUSTOM"
