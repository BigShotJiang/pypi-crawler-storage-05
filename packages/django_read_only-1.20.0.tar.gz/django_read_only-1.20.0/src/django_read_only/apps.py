from __future__ import annotations

from django_read_only import DjangoReadOnlyAppConfig  # noqa: F401
