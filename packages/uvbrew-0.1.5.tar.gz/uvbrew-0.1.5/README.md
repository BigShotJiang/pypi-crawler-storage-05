uvbrew
======

create homebrew formulae from a uv package.

uses `uv export --format=pylock.toml` with `--no-dev` as default.


## todo

- [ ] improve tests with `project.scripts` instead of `meta.name`
- [ ] hosting url
