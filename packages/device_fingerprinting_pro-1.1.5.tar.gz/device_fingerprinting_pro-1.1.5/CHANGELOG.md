# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.4] - 2024-01-20

### Enhanced
- Made documentation sound more natural and human-written
- Simplified technical jargon to be more approachable
- Updated package description to be more conversational
- Improved explanations of quantum cryptography benefits

### Documentation
- Rewrote PQC sections to explain "why you should care" in plain English
- Added relatable analogies and real-world examples
- Made technical features more accessible to general audience

## [1.1.3] - 2024-01-20

### Enhanced
- Added prominent Post-Quantum Cryptography (PQC) documentation
- Updated README with confirmed PQC implementation details
- Enhanced package description to highlight quantum-resistant security
- Added PQC-related keywords for better discoverability

### Documentation
- Documented NIST-standardized ML-DSA (Dilithium) implementation
- Added quantum threat protection examples
- Included PQC verification instructions
- Enhanced both GitHub and PyPI documentation with PQC features

## [1.1.2] - 2024-01-20

### Fixed
- PyPI package display issues with Mermaid diagrams
- Created PyPI-compatible README without diagram syntax
- Improved text-based documentation formatting for package managers

### Enhanced
- Better PyPI package presentation with readable documentation
- Text-based architecture descriptions replacing visual diagrams
- Improved compatibility across different documentation viewers

## [1.1.1] - 2024-01-20

### Enhanced
- Improved PyPI package metadata and keywords
- Enhanced package description for better discoverability
- Added comprehensive project URLs (changelog, source, tracker)
- Added maintainer information for better package management

### Updated
- Package metadata for improved PyPI presentation
- Keywords for better search visibility
- Project URL structure for easier navigation

## [1.1.0] - 2024-01-20

### Added
- Comprehensive README with architectural diagrams
- Threat model and security analysis documentation
- PyPI package statistics and metrics
- Cross-platform compatibility documentation
- Enhanced error handling and logging

### Enhanced
- Human-friendly documentation throughout codebase
- Natural language code comments and docstrings
- Improved code readability and maintainability

### Fixed
- Mermaid diagram syntax errors in README
- Documentation accuracy and consistency
- Package metadata and configuration

## [1.0.0] - 2024-01-19

### Added
- Initial release of device fingerprinting library
- Core hardware detection functionality
- Cross-platform support (Windows, macOS, Linux)
- Basic security features and privacy considerations
- PyPI package publishing capability
