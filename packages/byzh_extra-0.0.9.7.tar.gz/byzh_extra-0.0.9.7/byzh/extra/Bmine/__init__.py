from .screenshot import get_screenshot, get_screenshot_for_Xidian

__all__ = ['get_screenshot', 'get_screenshot_for_Xidian']