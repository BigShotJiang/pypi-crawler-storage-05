"""
MCP Analytics API
企业级使用数据收集和分析API服务
"""

__version__ = "1.0.0"
__author__ = "Frontend Dev Assistant Team"