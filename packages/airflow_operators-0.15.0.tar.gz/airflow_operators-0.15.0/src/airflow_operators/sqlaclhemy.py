"""
For backward compatibility
"""

from .sqlalchemy import SQLAlchemySessionOperator  # noqa
