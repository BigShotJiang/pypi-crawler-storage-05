#. Create a Manufacturing Order.
#. Confirm it.
#. Click on the "Split" button.
#. Choose the desired split options.
#. Confirm.
