At Delinea we value transparency and clarity in our communications, respect, and integrity in our relationships.

Our Code of Conduct outlines our expectations from the contributors and maintainers of this repository.
You can [read the full Code of Conduct here](https://github.com/DelineaXPM/.github/blob/main/CODE_OF_CONDUCT.md).
