"""The Delinea Secret Server Python SDK"""

__version__ = "2.0.0"
