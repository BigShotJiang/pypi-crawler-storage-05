# from damei.nn.uaii.registry import *


from hai.uaii.registry import MODULES, SCRIPTS, IOS, init_register, InitRegister
