# SideValidator
![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)

Add some Qt input validator.

## 📦 Installation
```bash
pip install EasyValidator
```

## 📜 Changelog
See [CHANGELOG.md](https://github.com/qiufengcute/EasyValidator/blob/main/CHANGELOG.md)
