from .schema import NetboxSecretsQuery

schema = [NetboxSecretsQuery]
