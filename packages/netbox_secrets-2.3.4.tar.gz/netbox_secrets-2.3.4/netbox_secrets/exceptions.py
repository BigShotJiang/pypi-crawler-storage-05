class InvalidKey(Exception):
    """
    Raised when a provided key is invalid.
    """

    pass
