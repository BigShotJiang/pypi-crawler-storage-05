from ai_infra.llm import Models, Providers

MODEL = str(Models.openai.default.value)
PROVIDER = str(Providers.openai)