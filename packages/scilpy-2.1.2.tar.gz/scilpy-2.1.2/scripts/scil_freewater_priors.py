#! /usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Synonym for scil_NODDI_priors.py
"""

from scripts.scil_NODDI_priors import main as noddi_priors_main


def main():
    noddi_priors_main()


if __name__ == "__main__":
    main()
