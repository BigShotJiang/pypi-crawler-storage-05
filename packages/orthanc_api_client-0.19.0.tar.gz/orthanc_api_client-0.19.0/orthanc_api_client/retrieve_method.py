from strenum import StrEnum

class RetrieveMethod(StrEnum):

    MOVE = 'C_MOVE'
    GET = 'C-GET'
