# population-error
Small jax-based python package for computing error in Monte Carlo approximate population inference
