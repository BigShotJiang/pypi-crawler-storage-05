# Contributors

* varioustoxins [g.s.thompson@kent.ac.uk](mailto:g.s.thompson@kent.ac.uk) - overall architecture and impementation
* Esther Ackah - original work on MARS export and import as a final year undergraduate at the University of Kent
* Taylor Sharp - initial work on RDC export from ccpn analysis during a taught MSc final year project at the University of Kent
