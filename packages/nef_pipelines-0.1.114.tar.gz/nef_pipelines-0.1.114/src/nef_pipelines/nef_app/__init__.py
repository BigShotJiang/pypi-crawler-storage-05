# the root of the type app hierarchy

app = None
