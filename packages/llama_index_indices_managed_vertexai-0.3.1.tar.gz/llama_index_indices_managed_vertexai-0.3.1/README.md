# LlamaIndex Managed Integration: Vertex AI

[LlamaIndex on Vertex AI for RAG](https://cloud.google.com/vertex-ai/generative-ai/docs/llamaindex-on-vertexai) is a managed RAG service on Google Cloud Vertex AI.

Refer to the [official documentation](https://cloud.google.com/vertex-ai/generative-ai/docs/llamaindex-on-vertexai) and [API reference](https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/rag-api) for more information.
