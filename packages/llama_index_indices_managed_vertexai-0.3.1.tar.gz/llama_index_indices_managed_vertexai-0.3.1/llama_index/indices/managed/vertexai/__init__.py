from llama_index.indices.managed.vertexai.base import VertexAIIndex
from llama_index.indices.managed.vertexai.retriever import VertexAIRetriever

__all__ = ["VertexAIIndex", "VertexAIRetriever"]
