class TestInstallSolver:
    pass