from . import main

if __name__ == "__main__":
    main.mcp_server.run(transport="stdio")
