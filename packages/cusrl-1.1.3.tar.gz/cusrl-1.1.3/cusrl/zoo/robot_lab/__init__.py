import cusrl.zoo.robot_lab.quadruped  # noqa: F401
