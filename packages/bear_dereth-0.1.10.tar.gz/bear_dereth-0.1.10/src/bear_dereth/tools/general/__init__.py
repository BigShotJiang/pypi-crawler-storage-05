"""A set of general tools and utilities for Bear Dereth projects."""
