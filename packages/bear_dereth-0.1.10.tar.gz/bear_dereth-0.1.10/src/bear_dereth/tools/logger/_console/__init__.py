from .console_override import LogConsole

__all__ = ["LogConsole"]
