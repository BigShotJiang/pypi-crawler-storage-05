"""A simple logger setup."""
