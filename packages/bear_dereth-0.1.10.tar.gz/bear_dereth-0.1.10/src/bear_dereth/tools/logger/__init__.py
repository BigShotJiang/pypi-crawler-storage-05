"""A module providing a Rich-based printer for colorful console output."""

from .config import Container, container

__all__ = ["Container", "container"]
