"""Graphics related utilities for Bear Utils."""
