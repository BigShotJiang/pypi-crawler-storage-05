Adds a menu item and some views to navigate through Purchase Order
lines.
