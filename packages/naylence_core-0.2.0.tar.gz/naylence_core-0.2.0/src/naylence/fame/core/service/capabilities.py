SINK_CAPABILITY = "fame.capability.sink"
AGENT_CAPABILITY = "fame.capability.agent"
MCP_HOST_CAPABILITY = "fame.capability.mcp-host"
