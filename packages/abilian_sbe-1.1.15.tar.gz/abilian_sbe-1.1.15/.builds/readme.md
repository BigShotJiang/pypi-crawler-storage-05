Build profiles for build.sr.ht (Sourcehut builds).
