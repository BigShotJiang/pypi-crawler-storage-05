# Copyright (c) 2012-2024, Abilian SAS

from __future__ import annotations

from abilian.web.assets.extension import AssetManager

asset_manager = AssetManager()
