# Copyright (c) 2012-2024, Abilian SAS

"""WebDAV interface to the document repository."""

from __future__ import annotations

from .views import webdav
