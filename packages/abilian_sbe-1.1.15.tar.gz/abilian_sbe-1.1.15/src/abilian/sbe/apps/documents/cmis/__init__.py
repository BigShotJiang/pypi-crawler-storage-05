# Copyright (c) 2012-2024, Abilian SAS

"""CMIS (REST aka AtomPub bind) interface to the document repository."""

from __future__ import annotations

from . import atompub
