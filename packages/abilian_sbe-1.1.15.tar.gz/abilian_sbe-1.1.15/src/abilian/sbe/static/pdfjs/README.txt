These files come from the pdf.js project.

TODO: properly manage using npm or bower.

