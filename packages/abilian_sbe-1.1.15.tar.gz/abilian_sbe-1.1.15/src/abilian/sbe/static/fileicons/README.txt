Icons from:

http://www.splitbrain.org/projects/file_icons

