This directory structure is intended to mimick the recommandations of the
SMACSS book (see: http://smacss.com/book/resources ) i.e. to categorize CSS
rules into 5 categories:

1. Base
2. Layout
3. Module
4. State
5. Theme