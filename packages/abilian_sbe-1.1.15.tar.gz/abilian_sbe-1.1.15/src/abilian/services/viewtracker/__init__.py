# Copyright (c) 2012-2024, Abilian SAS

from __future__ import annotations

from .service import viewtracker

__all__ = ["viewtracker"]
