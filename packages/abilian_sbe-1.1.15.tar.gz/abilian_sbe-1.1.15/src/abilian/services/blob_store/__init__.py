# Copyright (c) 2012-2024, Abilian SAS

""""""

from __future__ import annotations

from .service import blob_store, session_blob_store

__all__ = ["blob_store", "session_blob_store"]
