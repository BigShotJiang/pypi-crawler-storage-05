"""Create an application instance."""

from __future__ import annotations

from abilian.sbe.app import create_app

app = create_app()
