# Copyright (c) 2012-2024, Abilian SAS

""""""

from __future__ import annotations

from .extension import Admin
from .panel import AdminPanel

__all__ = ["Admin", "AdminPanel"]
