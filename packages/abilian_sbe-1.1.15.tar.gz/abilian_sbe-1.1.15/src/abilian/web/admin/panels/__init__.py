# Copyright (c) 2012-2024, Abilian SAS

"""Core panels."""

from __future__ import annotations
