# This makes 'graficos' a Python package.
