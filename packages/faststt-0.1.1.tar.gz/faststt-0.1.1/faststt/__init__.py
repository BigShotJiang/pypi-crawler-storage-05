from .faststt import FastSTT

__version__ = "0.1.1"