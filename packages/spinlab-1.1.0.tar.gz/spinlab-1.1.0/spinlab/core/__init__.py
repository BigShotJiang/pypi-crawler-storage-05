"""Modules related to the definition of the spindata class"""

from .data import SpinData
from .util import *
from .ufunc import *
