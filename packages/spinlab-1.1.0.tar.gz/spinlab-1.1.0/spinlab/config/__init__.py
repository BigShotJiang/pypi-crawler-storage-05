"""Modules containing the SpinLab Python configuration"""
