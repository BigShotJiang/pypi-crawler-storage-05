"""Matplotlib widgets for processing and to increase usability of the SpinLab package"""

from .align_widget import align_widget
from .phase_widget import phase_widget
