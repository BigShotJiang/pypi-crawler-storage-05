# apmodel
ActivityStreams 2.0 and nodeinfo 2.0/2.1 implementation for Python.
## Other ActivityPub Tools
- [apsig: Signature implementation used in ActivityPub](https://github.com/AmaseCocoa/apsig)
- [apkit: Powerful Toolkit for ActivityPub Implementations](https://github.com/AmaseCocoa/apkit)
## Links
- [Official Fedi Account](https://hollo.amase.cc/@apkit)