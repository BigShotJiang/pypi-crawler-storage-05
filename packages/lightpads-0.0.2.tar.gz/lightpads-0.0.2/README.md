# lightpads-py
Python client library for controlling Lightpads™ interactive play systems — set colors, detect pad hits, and build custom games.
