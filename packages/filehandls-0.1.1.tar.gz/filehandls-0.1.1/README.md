# filehandls

A simple Python library to handle files (read, write, delete, exists).

## Install
```bash
pip install filehandls
