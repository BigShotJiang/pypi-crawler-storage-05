"""
Admin API package for rate limiting management.
"""

from .api import create_admin_app

__all__ = [
    "create_admin_app",
]
