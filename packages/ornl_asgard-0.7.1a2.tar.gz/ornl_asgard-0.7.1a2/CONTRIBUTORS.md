
Miroslav Stoyanov (Oak Ridge National Lab)
- Project lead since 2023

Stefan Schnake (Oak Ridge National Lab)
- Software and method developer

Eirik Endeve (Oak Ridge National Lab)
- Software and method developer

Cory Hauck (Oak Ridge National Lab)
- Software and method developer

Steven Hahn (Oak Ridge National Lab)
- Software developer

## past developers

Coleman Kendrick (Oak Ridge National Lab)
- Computer scientist

Eduardo D'Azevedo (Oak Ridge National Lab)
- Method development

Wael Elwasif (Oak Ridge National Lab)
- Computer scientist

David L. Green (Oak Ridge National Lab)
- Principal investigator and project lead (until 2023)

M. Graham Lopez (Oak Ridge National Lab)
- Lead software engineer

Hao Lu (Oak Ridge National Lab)
- Postdoc

B. Tyler McDaniel (University of Tennessee/Oak Ridge National Lab)
- Developer

Adam McDaniel (Oak Ridge National Lab)
- Intern

Lin Mu (University of Georgia/Oak Ridge National Lab)
- Method development

Timothy Younkin (University of Tennessee/Oak Ridge National Lab)
- Postdoc

Harry Hughes (Oak Ridge National Lab)
- Developer

Brian Friesen (Lawrence Berkeley National Lab)
- NERSC performance consultant
