
import numpy as np
import asgard

# import matplotlib.pyplot as plt

# put testing code here
if __name__ == '__main__':
    pass
