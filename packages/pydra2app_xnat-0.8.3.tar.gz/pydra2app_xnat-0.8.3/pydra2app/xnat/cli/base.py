from pydra2app.core.cli import ext


@ext.group(name="xnat")
def xnat_group():
    pass
