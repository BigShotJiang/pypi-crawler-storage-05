# CSVExportDetailsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**csv_export_id** | **float** |  | 
**filename** | **str** |  | 
**date_created** | **datetime** |  | 
**csv_export_status** | [**CSVExportStatusResponse**](CSVExportStatusResponse.md) |  | 
**csv_export_status_string** | **str** |  | 
**filters** | **object** |  | 
**csv_export_type** | [**CSVExportTypeResponse**](CSVExportTypeResponse.md) |  | 
**csv_export_type_string** | **str** |  | 
**export_description** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

