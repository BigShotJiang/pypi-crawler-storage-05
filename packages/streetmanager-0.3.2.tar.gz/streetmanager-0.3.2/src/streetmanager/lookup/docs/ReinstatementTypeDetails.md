# ReinstatementTypeDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reinstatement_type_code** | [**ReinstatementTypeCodeResponse**](ReinstatementTypeCodeResponse.md) |  | 
**reinstatement_type_code_string** | **str** |  | 
**reinstatement_type_location_text** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

