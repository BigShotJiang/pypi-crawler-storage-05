# WorkUpdateResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rows** | [**list[WorkUpdateSummaryResponse]**](WorkUpdateSummaryResponse.md) |  | 
**next_update** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

