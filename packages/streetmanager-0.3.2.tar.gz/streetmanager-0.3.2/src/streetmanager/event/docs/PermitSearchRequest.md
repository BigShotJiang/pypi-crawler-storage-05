# PermitSearchRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**work_reference_numbers** | **list[str]** | Array values must be unique Must not contain null or undefined values Array max length 1000 Work reference numbers have a max length 24 characters | [optional] 
**next_cursor** | **float** |  | [optional] 
**page_size** | **float** | Minimum value of 100 Maximum value of 500 Must be an integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

