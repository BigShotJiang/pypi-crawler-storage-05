# PermitCondition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**condition** | [**PermitConditionTypeResponse**](PermitConditionTypeResponse.md) |  | 
**condition_string** | **str** |  | 
**comment** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

