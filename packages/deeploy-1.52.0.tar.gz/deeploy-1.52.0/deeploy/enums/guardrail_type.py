from enum import Enum


class GuardrailType(Enum):
    """Class that contains type of guardrail"""

    REGEX = 'regex' 