from enum import Enum


class PredictionVersion(Enum):
    V1 = 1
    V2 = 2
