from enum import Enum


class AuthType(Enum):
    BASIC = 0
    TOKEN = 1
    ALL = 2
