"""
XDMoD Python MCP Server

A Model Context Protocol server for accessing XDMoD (XD Metrics on Demand) 
data using Python's data analytics framework for better data manipulation 
and user-specific queries.
"""

__version__ = "0.1.0"