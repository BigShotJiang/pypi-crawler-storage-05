"""Version compatibility checks for Griptape Nodes 0.40.0."""
