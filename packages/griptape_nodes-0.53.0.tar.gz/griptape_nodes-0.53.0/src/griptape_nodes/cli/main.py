"""Main CLI application using typer."""

import sys
from pathlib import Path

import typer
from rich.console import Console

# Add current directory to path for imports to work
sys.path.append(str(Path.cwd()))

from griptape_nodes.cli.commands import config, engine, init, libraries, self

console = Console()

app = typer.Typer(
    name="griptape-nodes",
    help="Griptape Nodes Engine CLI",
    no_args_is_help=False,
    rich_markup_mode="rich",
    invoke_without_command=True,
)

# Add subcommands
app.command("init", help="Initialize engine configuration.")(init.init_command)
app.add_typer(config.app, name="config")
app.add_typer(self.app, name="self")
app.add_typer(libraries.app, name="libraries")
app.command("engine")(engine.engine_command)


@app.callback()
def main(
    ctx: typer.Context,
    no_update: bool = typer.Option(  # noqa: FBT001
        False, "--no-update", help="Skip the auto-update check."
    ),
) -> None:
    """Griptape Nodes Engine CLI."""
    if ctx.invoked_subcommand is None:
        # Default to engine command when no subcommand is specified
        engine.engine_command(no_update=no_update)


if __name__ == "__main__":
    app()
