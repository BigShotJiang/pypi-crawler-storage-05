# sage_setup: distribution = sagemath-nauty
# delvewheel: patch

from sage.all__sagemath_graphs import *
