=====
Usage
=====

To use s1swotcolocs in a project::

    import s1swotcolocs
