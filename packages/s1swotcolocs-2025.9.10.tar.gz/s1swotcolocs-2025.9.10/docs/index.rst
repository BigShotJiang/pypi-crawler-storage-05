Welcome to s1swotcolocs's documentation!
========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   usage
   notebooks/illustration_seastate_coloc
   api
   contributing
   authors
   history


Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
