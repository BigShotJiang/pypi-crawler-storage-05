"""Unit test package for s1swotcolocs."""
