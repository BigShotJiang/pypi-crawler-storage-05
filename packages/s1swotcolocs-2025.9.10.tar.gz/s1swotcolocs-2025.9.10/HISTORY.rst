=======
History
=======

2025.6.13 (2025-06-13)
------------------

* First release on PyPI.
