"""uvnote: Stateless, deterministic notebooks with uv and Markdown."""

__version__ = "0.1.0"
