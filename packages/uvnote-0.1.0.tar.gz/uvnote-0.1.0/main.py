"""uvnote main entry point for development."""

from uvnote.cli import main

if __name__ == "__main__":
    main()
