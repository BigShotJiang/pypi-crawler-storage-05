## 1.1.5 (2025-09-09)


- Upgrade-step to clean authentic users
  [remdub]


## 1.1.4 (2025-08-28)


- You should rerun migration as many times as you want.
  [bsuttor]


## 1.1.3 (2025-08-28)


- Check if realm exists and environment variables are set before migration
  [remdub]


## 1.1.2 (2025-08-27)


- Add fogrot local roles on migration to Keycloak.
  [bsuttor & remdub]

## 1.1.1 (2025-08-26)


- Migrate users form Authentic to Keycloal OIDC plugin.
  [bsuttor]


## 1.1.0 (2025-07-10)


- Migrate authentic to keycloak


## 1.0.0 (2025-03-31)
