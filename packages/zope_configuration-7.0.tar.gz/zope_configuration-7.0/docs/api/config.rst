===========================
 zope.configuration.config
===========================

.. automodule:: zope.configuration.config
