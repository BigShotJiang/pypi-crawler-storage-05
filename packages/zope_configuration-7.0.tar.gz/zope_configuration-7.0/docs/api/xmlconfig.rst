==============================
 zope.configuration.xmlconfig
==============================

.. automodule:: zope.configuration.xmlconfig
