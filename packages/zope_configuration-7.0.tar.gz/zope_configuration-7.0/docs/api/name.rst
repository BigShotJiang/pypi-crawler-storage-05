=========================
 zope.configuration.name
=========================

.. automodule:: zope.configuration.name
