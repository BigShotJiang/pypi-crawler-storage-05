===============================
 zope.configuration.exceptions
===============================

.. automodule:: zope.configuration.exceptions
