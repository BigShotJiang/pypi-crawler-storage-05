from zope.configuration.tests import bad  # pylint:disable=unused-import
