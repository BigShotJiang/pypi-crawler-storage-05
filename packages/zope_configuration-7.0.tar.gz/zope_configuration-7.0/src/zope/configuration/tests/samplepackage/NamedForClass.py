# Test the "repeat" feature of zope.configuration.name.resolve.
class NamedForClass:
    pass
