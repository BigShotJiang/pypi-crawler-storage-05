/*
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

function goBack() {
    window.history.back();
}