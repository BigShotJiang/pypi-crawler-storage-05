import torch
from . import _C, ops
from .ops import local_corr