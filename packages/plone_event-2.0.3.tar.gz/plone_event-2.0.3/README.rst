Introduction
============

Event/Calendaring related infrastructure. Recurrence calculation tools based on
RFC2445 and timedelta recurrence rules, timezone tools and date conversion
tools.

Parts of this package derived from Products.DateRecurringIndex.
