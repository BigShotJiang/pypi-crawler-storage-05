from dataclasses import dataclass


@dataclass
class Location:
    id: int
    name: str