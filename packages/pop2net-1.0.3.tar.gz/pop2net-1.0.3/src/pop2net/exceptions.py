"""Contains all exceptions of this package."""


class Pop2netException(Exception):  # noqa: N818
    """Base class for all exceptions in Pop2net."""

    pass
