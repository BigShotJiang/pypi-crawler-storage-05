"""Module to create fake SOEP data."""
