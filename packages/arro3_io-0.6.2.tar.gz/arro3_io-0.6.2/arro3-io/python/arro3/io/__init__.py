from ._io import *
from ._io import ___version, store

__version__: str = ___version()
