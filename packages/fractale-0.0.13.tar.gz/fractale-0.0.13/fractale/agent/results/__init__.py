from .agent import ResultAgent, ResultParser

assert ResultAgent, ResultParser
