from .transform import FluxTransformer as Transformer

assert Transformer
