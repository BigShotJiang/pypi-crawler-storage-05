from .transform import MoabTransformer as Transformer

assert Transformer
