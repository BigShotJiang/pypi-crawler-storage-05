fractale_dir = ".fractale"
valid_settings = {"sharedfs", "stage"}
sharedfs = True
solver_backends = ["database", "graph"]
solver_backend_default = "graph"
