from sqlalchemy.orm import DeclarativeBase


class AnswersBase(DeclarativeBase):
    pass
