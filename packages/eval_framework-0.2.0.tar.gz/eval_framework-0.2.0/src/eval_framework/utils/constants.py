from pathlib import Path

RED = "\033[91m"
YELLOW = "\033[93m"
MAGENTA = "\033[1;35;40m"
RESET = "\033[0m"
GREEN = "\033[92m"

ROOT_DIR = Path(__file__).parents[2]
