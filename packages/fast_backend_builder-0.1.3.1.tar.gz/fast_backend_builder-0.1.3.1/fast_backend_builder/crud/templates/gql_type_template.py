from typing import Optional
import strawberry

'''List of Types'''
@strawberry.type
class _MODEL_Response:
    id: Optional[str]
    '''FIELDS'''