#!/usr/bin/env python3
"""Entry point for the fixit package."""

from fixit.cli.main import app

if __name__ == "__main__":
    app()
