*******************
NeXpy Example Files
*******************

The following files are included in the NeXpy distribution and may be 
accessed from the Help menu or downloaded from the `Github repository
<https://github.com/nexpy/nexpy/tree/main/src/nexpy/examples>`_.

Example data
============

.. include:: ../../src/nexpy/examples/README.rst

Example plugins
===============

.. include:: ../../src/nexpy/examples/plugins/README.rst

Example scripts
===============

.. include:: ../../src/nexpy/examples/scripts/README.rst
