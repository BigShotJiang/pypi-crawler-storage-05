#!/bin/bash

$PYTHON setup.py install --single-version-externally-managed --record installed_files.txt
