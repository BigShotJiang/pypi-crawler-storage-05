.. restructured text format

------------------------------
About these example data files
------------------------------

These files are examples of data files that may be read by **NeXpy**.

==================  ==========  ===================================
file                type        description
==================  ==========  ===================================
example.nxs         NeXus HDF5  2-D NeXus sine wave example
chopper.nxs         NeXus HDF5  2-D time-of-flight neutron chopper 
                                spectrometer
==================  ==========  ===================================
