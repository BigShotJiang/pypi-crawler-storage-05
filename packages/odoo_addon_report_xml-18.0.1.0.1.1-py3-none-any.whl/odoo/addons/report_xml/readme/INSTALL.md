To install this module, you need to:

-   Install [lxml](http://lxml.de/) in Odoo's `$PYTHONPATH`.
-   Install the repository
    [reporting-engine](https://github.com/OCA/reporting-engine).

But this module does nothing for the end user by itself, so if you have
it installed it's probably because there is another module that depends
on it.
