-   Enric Tobella \<<etobella@creublanca.es>\>

-   [Tecnativa](https://www.tecnativa.com):  
    -   Jairo Llopis

-   [Avoin.Systems](https://avoin.systems/):  
    -   Tatiana Deribina

-   Iván Antón \<<ozono@ozonomultimedia.com>\>
