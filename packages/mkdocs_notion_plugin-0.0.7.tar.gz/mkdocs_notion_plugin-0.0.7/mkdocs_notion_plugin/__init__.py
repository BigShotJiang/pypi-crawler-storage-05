"""MkDocs Notion Plugin."""

from mkdocs_notion_plugin.plugin import NotionPlugin

__version__ = "0.0.6"

# Return the plugin class directly
NotionPlugin  # This registers the plugin class
