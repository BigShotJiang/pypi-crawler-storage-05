# History

## 0.2.0 (2025-09-13)

* Add core caching logic.

## 0.1.0 (2025-09-12)

* First release on PyPI.
