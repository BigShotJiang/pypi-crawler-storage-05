# Usage

To use Secrets Cache in a project:

```python
import secrets_cache
```
