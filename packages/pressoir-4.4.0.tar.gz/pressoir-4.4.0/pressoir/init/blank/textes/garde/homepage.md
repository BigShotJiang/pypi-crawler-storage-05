Page de présentation du livre.
