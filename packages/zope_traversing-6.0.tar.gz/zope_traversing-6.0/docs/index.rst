.. include:: ../README.rst


API Documentation:

.. toctree::
   :maxdepth: 2

   interfaces
   api
   adapters
   namespace
   publicationtraverse

Browser Documentation:

.. toctree::
   :maxdepth: 2

   browser/interfaces
   browser/absoluteurl


.. toctree::
   :maxdepth: 2

   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
