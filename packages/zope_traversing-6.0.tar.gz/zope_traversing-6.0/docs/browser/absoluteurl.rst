=======================
 Browser Absolute URLs
=======================

.. automodule:: zope.traversing.browser.absoluteurl
