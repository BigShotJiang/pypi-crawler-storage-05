============
 Namespaces
============

.. automodule:: zope.traversing.namespace
