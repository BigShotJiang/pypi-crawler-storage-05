"""Test utilities for StarHTML handler testing."""
