"""MCP server for Google Workspace operations."""

from mcp_google_suite.server import GoogleWorkspaceMCPServer


__version__ = "0.1.0"
__all__ = ["GoogleWorkspaceMCPServer"]
