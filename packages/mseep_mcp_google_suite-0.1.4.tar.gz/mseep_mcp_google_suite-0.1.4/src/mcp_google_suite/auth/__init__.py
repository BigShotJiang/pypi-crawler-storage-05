"""Google OAuth authentication module."""

from mcp_google_suite.auth.google_auth import GoogleAuth


__all__ = ["GoogleAuth"]
