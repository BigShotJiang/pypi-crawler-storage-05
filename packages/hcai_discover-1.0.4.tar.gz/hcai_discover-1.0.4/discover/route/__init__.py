"""Definition of all routes available withing NOVA-Server

Author:
    Dominik Schiller <dominik.schiller@uni-a.de>
Date:
    18.8.2023
"""