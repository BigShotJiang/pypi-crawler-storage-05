- Add a tour feature similar to what the `project` module defines to
  discover projects / tasks.
- Update portal tests defined in `tests/test_portal.py` to rely on tour
  specs (in JS) in order to replicate the navigation behavior of portal
  users.
