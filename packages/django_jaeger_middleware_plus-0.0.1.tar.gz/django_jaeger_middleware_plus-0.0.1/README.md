# django-jaeger-middleware-plus
适用于django及基于django框架的项目中添加jaeger(遵循opentracing API)实现的middleware. 自动采集HTTP请求、数据库查询、缓存操作等链路数据.
