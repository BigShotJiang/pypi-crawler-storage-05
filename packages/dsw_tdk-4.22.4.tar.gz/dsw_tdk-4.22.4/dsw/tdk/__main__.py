from .cli import main

# pylint: disable-next=no-value-for-parameter
main(ctx=None)
