"""Module for ingesting data to the metadata index."""
