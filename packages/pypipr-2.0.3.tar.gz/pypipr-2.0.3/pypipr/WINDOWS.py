import platform


"""
True on windows
"""
WINDOWS = platform.system() == "Windows"
