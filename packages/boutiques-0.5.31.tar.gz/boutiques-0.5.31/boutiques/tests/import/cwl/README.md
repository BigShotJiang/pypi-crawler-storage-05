Examples copied from https://github.com/common-workflow-language/common-workflow-language/tree/master/v1.0/examples

Each subdirectory contains one `.cwl` file and possibly one `.yml` file, both named after the directory. `.yml` job files from the above source were renamed for convenience, e.g. `1st-workflow-job.yml` renamed to `1st-workflow.yml` to match `1st-workflow.cwl`. Tests that we expect to fail are listed in a bad_files array in test_import and we check that exceptions are raised.
