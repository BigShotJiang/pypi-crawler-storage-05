
**Command-line tool**
=====================

.. argparse::
    :module: bosh
    :func: parser_bosh
    :prog: bosh
