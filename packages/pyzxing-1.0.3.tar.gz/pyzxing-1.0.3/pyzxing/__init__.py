# coding=utf-8
"""The root of pyzxing namespace."""
from .reader import BarCodeReader  #noqa