"""Version information for pyzxing package."""

__version__ = "1.0.3"

# For backward compatibility
VERSION = __version__