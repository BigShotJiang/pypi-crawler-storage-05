dev (17 Jan 2022)
- Use navdeep-G/setup.py as template

1.0.2 (9 Jan 2022)
- Using poetry to manage project and change structure
- Support blank in path

1.0.1 (18 April 2021)
- Fix jar preparation and add test case

1.0.0 (12 April 2021)
- Better decoding performance

0.3.5 (6 March 2021)
- Support decoding qrcode with bytes format content
- Support passing array into BarCodeReader

0.3.4 (2 March 2021)
- add points information in result

0.3.3 (29 Nov 2020)
- Update result parser
- support using absolute path

0.3.1 (28 July 2020)
- Add command line runner
- Fix download link
- Optimize cache logic

0.3 (31 May 2020)
- Support read multiple barcodes in a picture
- Scan multiple files in parallel
- Fix Linux runtime error

0.2 (29 May 2020)
- Parse raw output into structured result
- Enable using pre-compiled jar file

0.1 (28 May 2020)
- Initial release
