# mhjsmap
A MCP server for Amap route planning
## Installation
\\\bash
pip install mhjsmap
\\\