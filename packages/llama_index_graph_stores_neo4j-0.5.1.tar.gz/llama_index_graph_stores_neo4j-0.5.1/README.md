# LlamaIndex Graph Stores Integration: Neo4J
