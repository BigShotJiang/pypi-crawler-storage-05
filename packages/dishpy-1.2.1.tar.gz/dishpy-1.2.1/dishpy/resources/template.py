"""
Template for the main.py file.

Eventually, DishPy will add better templates to achieve feature parity with VEXcode, but for now you're stuck with this empty file!
"""
