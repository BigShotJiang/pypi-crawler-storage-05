from django.apps import AppConfig


class ConstanceConfig(AppConfig):
    name = "unfold.contrib.constance"
    label = "unfold_constance"
