from django.apps import AppConfig


class GuardianConfig(AppConfig):
    name = "unfold.contrib.guardian"
    label = "unfold_guardian"
