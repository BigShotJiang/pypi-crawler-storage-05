"""Interface to SXS metadata files"""
from sxscatalog.metadata import *
