"""Simple regexes to understand SXS IDs"""
from sxscatalog.utilities.sxs_identifiers import *
