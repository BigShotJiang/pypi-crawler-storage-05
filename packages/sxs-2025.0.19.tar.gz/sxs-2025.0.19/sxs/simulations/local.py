from sxscatalog.simulations.local import *
