# See also sxs.utilities.lvcnr.convert_simulation
