# `Metadata` class

::: sxscatalog.metadata.metadata.Metadata
