# `Simulations` class

::: sxs.Simulations

# `SimulationsDataFrame` class

::: sxs.simulations.simulations.SimulationsDataFrame
