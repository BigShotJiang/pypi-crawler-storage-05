# Waveforms

## `WaveformModes` class
::: sxs.WaveformModes

## `WaveformMixin` base class
::: sxs.waveforms.WaveformMixin
