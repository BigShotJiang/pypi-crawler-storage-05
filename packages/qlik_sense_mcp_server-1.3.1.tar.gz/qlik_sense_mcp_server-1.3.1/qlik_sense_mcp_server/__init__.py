"""Qlik Sense MCP Server for Enterprise APIs."""

__version__ = "1.3.1"
