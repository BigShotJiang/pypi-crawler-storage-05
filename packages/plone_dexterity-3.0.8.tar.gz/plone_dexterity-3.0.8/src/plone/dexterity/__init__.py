# Kick dynamic module factory
from . import schema  # noqa
