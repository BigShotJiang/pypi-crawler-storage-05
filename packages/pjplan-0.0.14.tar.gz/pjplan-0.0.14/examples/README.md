# pjplan: Examples

There you can find some examples about how to use **pjplan** in [jupyter](/jupyter) notebooks 
and [streamlit](/streamlit) applications. 