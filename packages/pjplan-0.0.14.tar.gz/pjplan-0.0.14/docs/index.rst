.. pjplan documentation master file, created by
   sphinx-quickstart on Sat Apr 15 13:01:36 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.



pjplan: Python library for project planning and analysis
==================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Englist <en/index>
   Русский <ru/index>


