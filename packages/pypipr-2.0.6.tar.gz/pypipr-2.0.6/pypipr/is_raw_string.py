def is_raw_string(s):
    if "\\" in s:
        return True
    return False
