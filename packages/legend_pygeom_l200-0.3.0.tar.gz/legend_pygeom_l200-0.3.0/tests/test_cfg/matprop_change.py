from __future__ import annotations

from legendoptics.tpb import tpb_refractive_index

tpb_refractive_index.replace_implementation(lambda: 1234)
