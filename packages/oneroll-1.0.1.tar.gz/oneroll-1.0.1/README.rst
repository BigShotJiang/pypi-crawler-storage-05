OneRoll
=======

    An efficient dice expression parsing tool, based on Rust and PEG grammar