# RPA-TEMU

## 本地开发

```
pip install -e .
```

## 生产安装

```
pip install rpa-temu
```