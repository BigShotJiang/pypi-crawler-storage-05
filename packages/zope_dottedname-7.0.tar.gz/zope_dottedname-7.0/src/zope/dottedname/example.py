# sample module for testing

def example():  # pragma: no cover
    pass
