Import-Module ./tasks/scripts/sh_runner.ps1

RunShFileWithGitBash -ShFilePath "./tasks/scripts/activate_venv.sh"
