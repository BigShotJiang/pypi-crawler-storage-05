. ./tasks/scripts/sh_runner.ps1

RunShFileWithGitBash -ShFilePath "./tasks/shims/dev_sync"
. ./.venv/Scripts/activate.ps1
