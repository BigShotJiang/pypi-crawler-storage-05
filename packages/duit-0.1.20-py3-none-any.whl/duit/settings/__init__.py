SETTING_ANNOTATION_ATTRIBUTE_NAME = "__duit_settings_annotation"
"""
The attribute name used to store Setting annotations in DataField objects.
"""
