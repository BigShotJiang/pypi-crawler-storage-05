ARGUMENT_ANNOTATION_ATTRIBUTE_NAME = "__duit_arguments_annotation"
"""
The attribute name used to store Argument annotations in DataField objects.
"""
