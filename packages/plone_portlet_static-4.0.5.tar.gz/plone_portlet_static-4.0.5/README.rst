Introduction
============

A Plone Portlet providing a rich-text field for more or less static text.
It is available and will be displayed where portlets can be placed.

It is part of the Plone core package.

Source Code
===========

Contributors please read the document `Process for Plone core's development <https://docs.plone.org/develop/coredev/docs/index.html>`_

Sources are at the `Plone code repository hosted at Github <https://github.com/plone/plone.portlet.static>`_.
