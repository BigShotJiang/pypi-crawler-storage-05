"""Unit test package for severstar_mfc_rs485."""
