# History

## 0.1.0 (2025-09-08)

* First release on PyPI.
