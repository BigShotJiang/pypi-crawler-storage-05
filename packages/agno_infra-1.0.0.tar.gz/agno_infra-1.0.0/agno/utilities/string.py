def to_kebab_case(input_string):
    return input_string.lower().replace(" ", "-").replace("_", "-")
