"""
Zeon - A powerful CLI tool to scaffold and manage FastAPI projects
"""

__version__ = "1.0.1"
__author__ = "Vinyas Bharadwaj"
__email__ = "vinyasbharadwaj101@gmail.com"

from .main import app

__all__ = ["app"]
