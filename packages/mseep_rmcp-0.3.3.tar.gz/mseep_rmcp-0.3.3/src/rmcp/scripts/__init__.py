"""
Build and development scripts.

Contains scripts for:
- Code formatting and linting
- Test execution  
- Build processes
- Development workflows
"""