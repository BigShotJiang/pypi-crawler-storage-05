# scitrera-app-framework

Common code and utilities for Scitrera applications and container images.

Working hard to move closed-source code to open-source, so more coming soon....