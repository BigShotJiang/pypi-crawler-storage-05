"""Configuration files for AutoClean EEG."""
