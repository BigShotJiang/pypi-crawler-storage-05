:og:title: Giskard Open Source - Tests Reference
:og:description: Documentation for test classes and utilities in Giskard open source library. Learn how to create and run tests for LLM agents.

LLM tests
^^^^^^^^^^^^^^^^^^^^^

Injections
----------
.. autofunction:: giskard.testing.tests.llm.test_llm_char_injection
.. autofunction:: giskard.testing.tests.llm.test_llm_single_output_against_strings
.. autofunction:: giskard.testing.tests.llm.test_llm_output_against_strings

LLM-as-a-judge
--------------
.. autofunction:: giskard.testing.tests.llm.test_llm_output_coherency
.. autofunction:: giskard.testing.tests.llm.test_llm_output_plausibility
.. autofunction:: giskard.testing.tests.llm.test_llm_output_against_requirement_per_row
.. autofunction:: giskard.testing.tests.llm.test_llm_single_output_against_requirement
.. autofunction:: giskard.testing.tests.llm.test_llm_output_against_requirement
.. autofunction:: giskard.testing.tests.llm.test_llm_correctness

Ground Truth
--------------
.. autofunction:: giskard.testing.tests.llm.test_llm_ground_truth
.. autofunction:: giskard.testing.tests.llm.test_llm_ground_truth_similarity
.. autofunction:: giskard.testing.tests.llm.test_llm_as_a_judge_ground_truth_similarity