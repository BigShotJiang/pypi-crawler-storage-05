"""Bindings layer tests for QuantForge"""
