"""
MODS Integration Module.

This module provides integrations between Cursus and the Model Operations and Deployment Service (MODS).
"""
