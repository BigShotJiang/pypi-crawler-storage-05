from .click_commands import execute


def console_main():
    execute()


if __name__ == "__main__":
    console_main()
