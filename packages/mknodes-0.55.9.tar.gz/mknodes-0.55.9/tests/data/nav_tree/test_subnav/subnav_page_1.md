## Code for this page

``` py
def create_static_page(nav: mknav.MkNav):
    pass  # statically loaded page, nothing to see here
```
