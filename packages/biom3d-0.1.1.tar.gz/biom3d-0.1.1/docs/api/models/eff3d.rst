EffUNet
=======

This is the encoder-decoder that use :class:`EfficientNet3D` encoder and a :class:`VGGDecoder`.


.. automodule:: biom3d.models.unet3d_eff
    :members:
