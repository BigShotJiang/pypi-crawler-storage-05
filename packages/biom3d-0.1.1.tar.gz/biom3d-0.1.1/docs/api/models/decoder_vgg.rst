VGG3D Decoder
=============

This decoder is based on nnUnet decoder, and is currently used by :class:`EffUNet` and :class:`UNet`


.. automodule:: biom3d.models.decoder_vgg_deep
    :members: