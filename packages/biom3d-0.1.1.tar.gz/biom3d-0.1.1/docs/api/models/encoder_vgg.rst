VGG3D Encoder
=============

This encoder is currently used by :class:`UNet`.


.. automodule:: biom3d.models.encoder_vgg
    :members:
