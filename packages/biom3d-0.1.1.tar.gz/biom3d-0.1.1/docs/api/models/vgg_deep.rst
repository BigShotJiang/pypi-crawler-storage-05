VGG3dDeep
=========

This is the encoder-decoder that use :class:`VGGEncoder` encoder and a :class:`VGGDecoder`. It is an adaptation nnUnet.


.. automodule:: biom3d.models.unet3d_vgg_deep
    :members:
