EfficentNet3D Encoder
=====================

This encoder is currently used by :class:`EffUNet`.


.. automodule:: biom3d.models.encoder_efficientnet3d
    :members:

.. autofunction:: biom3d.models.encoder_efficientnet3d.GlobalParams

.. autofunction:: biom3d.models.encoder_efficientnet3d.BlockArgs