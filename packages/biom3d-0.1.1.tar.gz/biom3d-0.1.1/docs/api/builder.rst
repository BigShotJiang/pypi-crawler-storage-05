Builder
==================

The Builder is the core class of biom3d. It is used to train a model or to test a model in a couple of lines of code.

.. automodule:: biom3d.builder
    :members:
