Semseg patch fast
=================

This dataloader is the default dataloader, it is inspired from nnUnet but simplified.


.. automodule:: biom3d.datasets.semseg_patch_fast
    :members: