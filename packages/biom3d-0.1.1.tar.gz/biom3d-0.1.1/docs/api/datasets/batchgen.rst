Semseg batchgen
===============

This is a transcription of nnUnet's batch generator that has the same API as a dataloader.

.. note:: 
    
    This code use the library batchgenerators that is not a part of Biom3d's dependencies. You'll have to install it separatly.

.. automodule:: biom3d.datasets.semseg_batchgen
    :members: