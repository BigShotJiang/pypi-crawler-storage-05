Datasets
========
The datasets module define dataloader or batch loader used for both training and validation.

.. toctree::
      :maxdepth: 2
      :caption: Datasets 

      batchgen.rst
      patch_fast.rst
      torchio.rst
