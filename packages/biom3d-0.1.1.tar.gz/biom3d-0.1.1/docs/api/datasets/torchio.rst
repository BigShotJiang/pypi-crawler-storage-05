Torchio
=======

Torchio dataloader, aimed principally for data augmentation.


.. automodule:: biom3d.datasets.semseg_torchio
    :members: