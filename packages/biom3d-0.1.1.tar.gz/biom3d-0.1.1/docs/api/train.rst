Train
=====

.. automodule:: biom3d.train
    :members: