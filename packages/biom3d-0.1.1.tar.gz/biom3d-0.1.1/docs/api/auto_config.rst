Auto-configuration
==================

The auto-configuration is used after the pre-processing to display in the terminal the training hyper-parameters, such as the batch size, the patch size, the augmentation patch size and the number of pooling in the U-Net model. The main function here is `biom3d.auto_config.auto_config`

.. automodule:: biom3d.auto_config
    :members: