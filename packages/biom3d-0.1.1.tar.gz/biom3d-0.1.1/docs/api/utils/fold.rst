Folds
=====

.. automodule:: biom3d.utils.fold
    :members: