Encoding
========

.. note:: 

    For the moment, this submodule is only used in preprocessing.

.. automodule:: biom3d.utils.encoding
    :members: