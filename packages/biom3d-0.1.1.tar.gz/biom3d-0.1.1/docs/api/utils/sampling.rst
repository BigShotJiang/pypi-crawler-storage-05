Sampling & Data augmentation
============================

.. note:: 

      This module is a work in progress and only implement sampling methods. We want to generalize some of the dataloaders code. 

.. automodule:: biom3d.utils.data_augmentation
    :members:
