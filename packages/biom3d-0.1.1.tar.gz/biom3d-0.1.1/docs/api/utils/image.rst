Image visualisation & resizing
==============================

.. note:: 

      Some function of this module need Napari, it is not a Biom3d dependency and need to be installed manually.

.. automodule:: biom3d.utils.image
    :members:
