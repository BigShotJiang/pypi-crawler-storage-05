Filtering & thresholding
========================

.. note:: 

      For the moment, this submodule is only used in post processing.


.. automodule:: biom3d.utils.filtering
    :members:
