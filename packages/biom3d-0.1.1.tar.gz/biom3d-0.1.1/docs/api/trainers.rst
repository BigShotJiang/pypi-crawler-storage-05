Trainers
========

.. automodule:: biom3d.trainers
    :members:
