Callbacks
=========

The Callbacks are routine called periodically during the training. Simply inherit from the biom3d.callback.Callback class and override one on its methods to create a new callback. Then add it to the biom3d.builder.Builder.build_callback method.

.. automodule:: biom3d.callbacks
    :members:
