class SerializerNotFoundError(Exception):
    """Raised when no serializer is found for an action or HTTP method."""

    pass
