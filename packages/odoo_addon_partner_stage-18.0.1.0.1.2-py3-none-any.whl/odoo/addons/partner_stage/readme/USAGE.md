Open a Contact form to see the corresponding Stage. It is visible in the
stages bar, at the top right are of the form.

The contact stage can be changed clicking on the stages bar.
