To create a new Stage:

#. Navigate to *Contacts > Configuration > Contact Stages*.

#. Create a new record, and set the name, code and a description.

#. The stage order can be modified using teh handle widget, on the list view.
