- Daniel Reis \<<dreis@opensourceintegrators.com>\>
- Urvisha Desai \<<udesai@opensourceintegrators.com>\>
* `Camptocamp <https://www.camptocamp.com>`__:

  * Maksym Yankin <maksym.yankin@camptocamp.com>

- Bert Van Groenendael \<<bert.vangroenendael@dynapps.eu>\>
