Adds stages to Contacts allowing, for example, to setup a lifecycle
workflow. The default stages are: Draft, Active and Inactive.
