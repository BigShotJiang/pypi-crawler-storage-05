from . import res_partner_stage
from . import res_partner
