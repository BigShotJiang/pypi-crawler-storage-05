from geoparser.annotator.app import run


def annotator_cli():
    run()
