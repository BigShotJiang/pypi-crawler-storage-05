from geoparser.config.config import get_gazetteer_configs
