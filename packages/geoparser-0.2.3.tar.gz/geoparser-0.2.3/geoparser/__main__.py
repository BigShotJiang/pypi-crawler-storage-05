from geoparser.cli import app


def main():  # pragma: no cover
    app()


if __name__ == "__main__":  # pragma: no cover
    main()
