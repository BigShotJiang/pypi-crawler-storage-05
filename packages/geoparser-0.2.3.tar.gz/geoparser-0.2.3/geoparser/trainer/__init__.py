from .trainer import GeoparserTrainer
