const urlBase = "{{ url_for('index') }}".slice(0,-1);
