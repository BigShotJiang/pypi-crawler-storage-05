from .geonames import GeoNames
from .swissnames3d import SwissNames3D
