if __name__ == "__main__":
    from dot.cli import app
    app()
