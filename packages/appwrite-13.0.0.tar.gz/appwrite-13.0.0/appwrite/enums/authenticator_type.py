from enum import Enum

class AuthenticatorType(Enum):
    TOTP = "totp"
