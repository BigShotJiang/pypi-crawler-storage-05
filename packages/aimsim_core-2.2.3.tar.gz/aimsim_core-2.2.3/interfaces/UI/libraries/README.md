This directory contains external GUI libraries used by AIMSim, which are both made available under the MIT license.

They are included here rather than installed from a package manager for ease of packaging on our end.