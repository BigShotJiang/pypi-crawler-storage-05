# sage_setup: distribution = sagemath-categories
from sage.misc.lazy_import import lazy_import

lazy_import('sage.typeset.ascii_art', 'ascii_art')
lazy_import('sage.typeset.unicode_art', 'unicode_art')
del lazy_import
