# sage_setup: distribution = sagemath-categories
from sage.rings.padics.padic_generic import local_print_mode

from sage.rings.padics.pow_computer import PowComputer
