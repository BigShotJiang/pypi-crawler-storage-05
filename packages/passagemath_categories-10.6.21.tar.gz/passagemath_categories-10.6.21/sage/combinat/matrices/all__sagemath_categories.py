# sage_setup: distribution = sagemath-categories
from sage.misc.lazy_import import lazy_import

lazy_import('sage.combinat.matrices.dlxcpp', 'DLXCPP')
del lazy_import
