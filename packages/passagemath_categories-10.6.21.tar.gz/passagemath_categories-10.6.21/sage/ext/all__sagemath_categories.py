# sage_setup: distribution = sagemath-categories
from sage.ext.fast_callable import fast_callable
from sage.ext.fast_eval import fast_float
