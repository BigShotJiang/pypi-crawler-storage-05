from .logger import Log, LogLevel

__version__ = "1.0.4"
__all__ = ["Log", "LogLevel"]