# r"""Easy_whitelist is a smart tool that detects the local Internet IP address and automatically updates the local Internet IP address to the cloud security group whitelist. The tool is written in Python.
# """

#__version__ = '1.0.48'
# __author__ = 'qiqileleabaobao <qiqilelebaobao@163.com>'

__all__ = []
