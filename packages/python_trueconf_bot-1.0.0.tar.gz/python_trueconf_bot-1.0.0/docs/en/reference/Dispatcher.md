# Class `Dispatcher`

Here is the reference information for the `Dispatcher` class, including all its parameters, attributes, and methods.  
You can import the `Dispatcher` class directly from the `trueconf` package:

```python
from trueconf import Dispatcher
```

::: trueconf.Dispatcher
    options:
        filters:
            - "!^_"
            - "!^__"


