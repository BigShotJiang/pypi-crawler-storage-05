import logging

dispatcher = logging.getLogger("trueconf.dispatcher")
chatbot = logging.getLogger("trueconf.client.chatbot")
