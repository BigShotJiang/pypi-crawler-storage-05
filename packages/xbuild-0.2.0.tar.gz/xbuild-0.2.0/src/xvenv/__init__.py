# xvenv version is the same as xbuild
from xbuild import __version__

__all__ = [
    "__version__",
]
