# PyBattMo
A Python wrapper around BattMo.jl
