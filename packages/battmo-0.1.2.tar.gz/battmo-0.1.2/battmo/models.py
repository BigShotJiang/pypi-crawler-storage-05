from .julia_import import jl


def LithiumIonBattery(*arg, **kwargs):
    return jl.LithiumIonBattery(*arg, **kwargs)
