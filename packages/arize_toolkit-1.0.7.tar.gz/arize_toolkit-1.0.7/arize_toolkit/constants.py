MAX_RECURSION_DEPTH = 6
ARIZE_API_URL = "https://api.arize.com"
