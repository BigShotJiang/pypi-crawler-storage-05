class OutOfBoundsError(Exception):
    """
    target geometry outside of given geometry
    """
    pass
