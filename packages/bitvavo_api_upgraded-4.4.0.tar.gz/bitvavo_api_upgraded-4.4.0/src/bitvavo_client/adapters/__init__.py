"""Optional adapters for alternative result-handling styles."""
