# UChicago

::: ggsci.palettes
    options:
      members:
        - pal_uchicago
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_uchicago
        - scale_colour_uchicago
        - scale_fill_uchicago
      show_root_heading: true
      show_source: false
