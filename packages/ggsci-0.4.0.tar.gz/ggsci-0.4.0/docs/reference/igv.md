# IGV

::: ggsci.palettes
    options:
      members:
        - pal_igv
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_igv
        - scale_colour_igv
        - scale_fill_igv
      show_root_heading: true
      show_source: false
