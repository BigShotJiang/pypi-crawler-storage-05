# AAAS

::: ggsci.palettes
    options:
      members:
        - pal_aaas
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_aaas
        - scale_colour_aaas
        - scale_fill_aaas
      show_root_heading: true
      show_source: false
