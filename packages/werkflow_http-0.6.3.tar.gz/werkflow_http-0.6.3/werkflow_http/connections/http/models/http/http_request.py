import base64
import pathlib
from typing import Dict, List, Literal, Optional, Tuple, Union
from urllib.parse import urlencode

import orjson
from pydantic import (
    BaseModel,
    StrictBytes,
    StrictInt,
    StrictStr,
    Field,
)

from .file import File
from .types import HTTPCookie, HTTPEncodableValue
from .url import URL

NEW_LINE = '\r\n'


class HTTPRequest(BaseModel):
    url: StrictStr
    method: Literal[
        "GET", 
        "POST",
        "HEAD",
        "OPTIONS", 
        "PUT", 
        "PATCH", 
        "DELETE"
    ]
    cookies: Optional[List[HTTPCookie]]=None
    auth: Optional[Tuple[str, str]]=None
    params: Optional[Dict[str, HTTPEncodableValue]]=None
    headers: Dict[str, str] | None=None
    data: Union[
        Optional[StrictStr],
        Optional[StrictBytes],
        Optional[BaseModel]
    ]=None
    files: list[File | StrictStr | pathlib.Path] | None = None
    redirects: StrictInt=3

    class Config:
        arbitrary_types_allowed=True

    def prepare(
        self,
        url: URL
    ):
        
        url_path = url.path

        if self.params and len(self.params) > 0:
            url_params = urlencode(self.params)
            url_path += f'?{url_params}'

        get_base = f"{self.method} {url.path} HTTP/1.1{NEW_LINE}"

        port = url.port or (443 if url.scheme == "https" else 80)

        hostname = url.hostname.encode("idna").decode()

        headers: dict[str, str] = {}
        if self.headers:
            headers.update(self.headers)

        if port not in [80, 443]:
            hostname = f'{hostname}:{port}'

        if isinstance(self.data, BaseModel):
            data = orjson.dumps({
                name: value for name, value in self.data.__dict__.items() if value is not None
            })
            headers['content-type'] = 'application/json'

            size = len(data)

        elif isinstance(self.data, str):
            data = self.data.encode()
            size = len(data)

        elif self.data:
            data = self.data
            size = len(self.data)

        else:
            data = self.data
            size = 0

        header_items = [
            ("HOST", hostname),
            ("User-Agent", "mercury-http"),
            ("Keep-Alive", "timeout=60, max=100000"),
            ("Content-Length", size)
        ]

        header_items.extend(headers.items())

        if self.auth:
            encoded_auth_header = base64.b64encode(f'{self.auth[0]}:{self.auth[1]}'.encode()).decode().encode('latin1').decode()
            header_items.append(
                ('Authorization', f'Basic {encoded_auth_header}')
            )

        for key, value in header_items:
            get_base += f"{key}: {value}{NEW_LINE}"

        if self.cookies:
    
            cookies = []

            for cookie_data in self.cookies:
                if len(cookie_data) == 1:
                    cookies.append(cookie_data[0])

                elif len(cookie_data) == 2:
                    cookie_name, cookie_value = cookie_data
                    cookies.append(f'{cookie_name}={cookie_value}')

            cookies = '; '.join(cookies)
            get_base += f'Set-Cookie: {cookies}{NEW_LINE}'

        return (get_base + NEW_LINE).encode(), data
