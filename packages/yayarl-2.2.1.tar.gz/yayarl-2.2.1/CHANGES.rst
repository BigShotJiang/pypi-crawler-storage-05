=========
Changelog
=========

2.2.1 (2025-09-09)
==================

Fixes
--------

- Add missing dependency `propcache`

2.2.0 (2025-09-09)
==================

Features
--------

- Bring up to date with `aio-libs/yarl` (1.20.1)

2.1.0 (2023-11-15)
==================

Features
--------

- Bring up to date with `aio-libs/yarl`

2.0.0 (2023-09-28)
==================

Features
--------

- First version of the yayarl fork; add `requests` functionality.
