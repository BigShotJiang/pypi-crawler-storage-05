# Query templates

This folder contains sql query templates for getting various photo properties

The query templates must be rendered with mako (see query_builder.py)