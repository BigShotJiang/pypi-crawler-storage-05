class TwoFactorAuthenticationRequiredError(Exception):
    pass
