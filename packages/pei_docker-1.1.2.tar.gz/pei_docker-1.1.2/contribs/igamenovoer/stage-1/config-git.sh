#!/bin/bash

git config --global user.email "igamenovoer@xx.xx"
git config --global user.name "igamenovoer"