- just check the code, DO NOT modify it
- save a report in context/logs/check/checked-<time>-(pick_a_name).md, with the following header:
  - **Title**: Code Check Report
  - **Date**: (current date)
  - **Status**: (status of the check, e.g., "All checks passed" or "Errors found")

- the report should contain
- - description of symtoms
- - problems found
- - suggestions for improvement or bugfix

- use `context7` to find documentations if needed or in doubt
- use online search to find best practices or solutions if needed or in doubt
