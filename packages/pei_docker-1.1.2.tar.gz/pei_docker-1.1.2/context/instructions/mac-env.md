# MacOS Environments

you are in a MacOS environment, which means you can use MacOS-specific tools and commands.

- use `zsh` for CLI tasks
- your python env is managed by `pixi`, use `pixi run -e dev` for development tasks, and `pixi run` for deployment tasks
- DO NOT use unicode emojis in your code