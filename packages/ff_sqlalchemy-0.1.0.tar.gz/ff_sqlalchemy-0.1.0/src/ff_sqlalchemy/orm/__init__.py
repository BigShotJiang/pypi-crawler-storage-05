from .base_model import Base, BaseModel

__all__ = [
    "Base",
    "BaseModel"
]