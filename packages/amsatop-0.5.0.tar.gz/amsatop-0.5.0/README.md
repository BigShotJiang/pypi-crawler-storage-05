# Amsatop

## What is this?

Library for building your own htop from scratch, using python.
Exclusively built for AMSA-25-26 subject at UdL.

## Check the docs

Documentation is available at [https://el-despatx.github.io/amsatop/](https://el-despatx.github.io/amsatop/)
