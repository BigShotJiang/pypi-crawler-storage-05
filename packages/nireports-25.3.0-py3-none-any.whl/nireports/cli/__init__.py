"""
Command-line interface for nireports.
"""
