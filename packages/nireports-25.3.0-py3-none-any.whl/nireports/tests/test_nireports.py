def test_import():
    import nireports  # noqa: F401
