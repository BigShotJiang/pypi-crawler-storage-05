# kinfer

This package is designed to support running real-time robotics models.

For more information, see the documentation [here](https://docs.kscale.dev/docs/k-infer).

To enable logging, set your log path in the environment variable `KINFER_LOG_PATH`. For example,
```
export KINFER_LOG_PATH=/home/dpsh/kinfer-logs
```
