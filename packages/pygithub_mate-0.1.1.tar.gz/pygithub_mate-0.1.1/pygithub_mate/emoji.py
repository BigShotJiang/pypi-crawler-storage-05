# -*- coding: utf-8 -*-


class Emoji:
    CREATE = "🆕"
    UPDATE = "🔄"
    DELETE = "🗑️"
    GET = "🔍"
