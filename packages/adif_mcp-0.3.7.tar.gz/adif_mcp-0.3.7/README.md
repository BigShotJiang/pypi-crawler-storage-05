ADIF-MCP

⚠️ Status: Deprecated – Python implementation is frozen
The Python codebase (≤ v0.3.6) is no longer maintained.
Future development is moving to Java 21 + JavaFX.

Documentation
	•	User & Developer Docs: https://adif-mcp.com
	•	Release notes & tags: GitHub Releases

Python Legacy
	•	The last working Python release: v0.3.6
	•	A tombstone branch preserves the Python sources for reference.
	•	All new development is happening in Java.

Migration Plan
	•	Existing CLI concepts (personas, providers, creds, sync) will re-emerge in Java.
	•	MkDocs remains the user-facing documentation system.
	•	Developer API docs will move to Javadoc.

License

MIT © KI7MT
