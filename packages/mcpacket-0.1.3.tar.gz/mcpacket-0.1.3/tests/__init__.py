"""Tests for mcpacket."""
