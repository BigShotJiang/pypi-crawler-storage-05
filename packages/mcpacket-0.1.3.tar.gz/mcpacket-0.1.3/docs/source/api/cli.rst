Command Line Interface
======================

The CLI module handles command-line argument parsing and application entry points.

CLI Module
----------

.. automodule:: mcpacket.cli
   :members:
   :undoc-members:
   :show-inheritance: