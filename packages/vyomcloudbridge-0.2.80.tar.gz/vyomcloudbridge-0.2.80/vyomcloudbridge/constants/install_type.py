# Auto-generated at install time
INSTALLATION_TYPE = "lite"   # or "full"
