eval "$(register-python-argcomplete3 forest)"
