from forest.main import main
exit(0 if main() else 1)
