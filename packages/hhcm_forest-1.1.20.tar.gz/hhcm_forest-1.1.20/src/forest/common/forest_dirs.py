import os

rootdir = os.getcwd()
recipesdir = os.path.join(rootdir, 'recipes')
buildroot = os.path.join(rootdir, 'build')
installdir = os.path.join(rootdir, 'install')
srcroot = os.path.join(rootdir, 'src')