# inventree-droplet-plugin

Plugin to surface Droplet info in InvenTree, pre-installed with the Droplet image.

## Setup

1. Install
Install this plugin in the webinterface with the packagename `inventree-droplet-plugin`

2. Enable
Enable the plugin in the plugin settings. You need to be signed in as a superuser for this.
**The server will restart if you enable the plugin**

## License
This project is licensed as MIT license.
