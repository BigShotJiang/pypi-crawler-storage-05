"""Top-level package for InvenTree Droplet Plugin."""

from .InvenTreeDropletPlugin import InvenTreeDropletPlugin

__all__ = [InvenTreeDropletPlugin, ]
__author__ = "Matthias Mair"
__email__ = "code@mjmair.com"
