# Examples

Examples can be found in the ``examples`` directory. The examples are:

- `Rabi_oscillation.cpp` (discussed in [switching function](switching_function.md#example))
- `computes_switching_function.cpp` (discussed in [quick start](getting_started.md#quick-start))

[Previous](switching_function.md) | [Next](running_tests.md)