from gunicorn_django_canonical_logs.monitors import saturation, timeout  # noqa: F401 registers hooks
