# openmed

A placeholder package to reserve the name on PyPI. Real library coming soon.

## Installation
```bash
pip install openmed
```

## Usage
```python
import openmed
print(openmed.__version__)
```
