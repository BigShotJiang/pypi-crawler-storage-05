# It is important to store the version number in a separate file
# so that we can read it from setup.py without importing the package
__version__ = "0.6.17"
