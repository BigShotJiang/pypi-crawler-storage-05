# Código de Conduta do Contribuidor

Adotamos o [Contributor Covenant](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).

Casos de abuso/assédio: escreva para **thiagovt.dev@gmail.com** ou abra um *Private vulnerability report*.
