## Motivo
Closes #

## O que mudou
- 

## Checklist
- [ ] Lint/format (`ruff`, `black`) passaram
- [ ] Testes cobrem a mudança (se aplicável)
- [ ] Docs/README atualizados (se aplicável)
