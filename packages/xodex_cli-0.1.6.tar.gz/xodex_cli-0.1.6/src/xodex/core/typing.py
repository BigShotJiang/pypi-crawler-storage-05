from typing import Optional

t_opt_str = Optional[str]
