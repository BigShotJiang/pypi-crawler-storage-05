def main():
    from xodex.main import main as _main

    _main()


if __name__ == "__main__":
    main()
