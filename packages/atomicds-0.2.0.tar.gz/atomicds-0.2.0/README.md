# API Client for Atomic Data Sciences

[![Testing](https://github.com/artificial-atomic-intelligence/api-client/workflows/Testing/badge.svg)](https://github.com/artificial-atomic-intelligence/api-client/actions?query=workflow:"Testing")
[![GitHub tag](https://img.shields.io/github/tag/artificial-atomic-intelligence/api-client?include_prereleases=&sort=semver&color=blue)](https://github.com/artificial-atomic-intelligence/api-client/releases/)
![Python](https://img.shields.io/badge/Python-3.9+-blue.svg?logo=python&logoColor=white)
[![License](https://img.shields.io/badge/License-GPLv3-blue)](#license)

[![view - Documentation](https://img.shields.io/badge/view-Documentation-blue?style=for-the-badge)](https://atomic-data-sciences.github.io/api-client/)
