pytest_plugins = ["pytest_order"]


class ResultIDs:
    rheed_image = ""
    rheed_stationary = ""
    rheed_rotating = ""
    xps = ""
