from llama_index.vector_stores.faiss.base import FaissVectorStore
from llama_index.vector_stores.faiss.map_store import FaissMapVectorStore

__all__ = ["FaissVectorStore", "FaissMapVectorStore"]
