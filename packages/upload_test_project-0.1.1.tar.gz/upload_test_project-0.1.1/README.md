# My Simple Math Package

이 패키지는 PyPI 배포 테스트를 위한 간단한 예제입니다.

### 설치

```bash
pip install my_simple_math_package