from .commands import invoke


if __name__ == "__main__":
    invoke()
