translations = {
    "ru": {
        "page": "страница",
        "with_tags": "с тегами",
        "without_tags": "без тегов",
    },
    "en": {
        "page": "page",
        "with_tags": "with tags",
        "without_tags": "without tags",
    },
}
