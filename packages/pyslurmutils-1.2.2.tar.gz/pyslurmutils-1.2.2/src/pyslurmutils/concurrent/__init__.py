"""SLURM API similar to python's `concurrent.futures`"""
