from enum import Enum

class eRSPileDatumGroup(Enum):
	AXIAL = "SOIL_AXIAL"
	LATERAL = "SOIL_LATERAL"
	GENERAL = "SOIL_GENERAL"