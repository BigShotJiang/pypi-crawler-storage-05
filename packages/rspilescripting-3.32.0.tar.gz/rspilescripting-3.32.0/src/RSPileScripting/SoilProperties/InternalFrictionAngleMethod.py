#Cohesionless Bored/Driven InternalFrictionAngle Enum
from enum import Enum
class InternalFrictionAngleMethod(Enum):
	USE_FRICTION_ANGLE = 1
	USE_SPT_N_VALUES = 2