# RV Image

This package contains Pydantic types to facilitate writing prediction APIs integrated into the image annotation tool 
[RV Image](https://github.com/bertiqwerty/rvimage).