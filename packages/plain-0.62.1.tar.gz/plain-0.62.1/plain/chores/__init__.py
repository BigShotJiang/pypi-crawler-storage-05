from .registry import register_chore

__all__ = ["register_chore"]
