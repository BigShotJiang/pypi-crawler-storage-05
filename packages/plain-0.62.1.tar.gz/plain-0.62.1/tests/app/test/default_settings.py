DEFAULT_SETTING: str = "unchanged default"
EXPLICIT_SETTING: str = "unchanged explicit"
ENV_SETTING: int = 0
ENV_OVERRIDDEN_SETTING: str = "unchanged env overridden"
