# synapkit

**Synapkit — a tiny, typed agent toolkit.**

This is a minimal placeholder release (`0.0.1`) 

## Install (once published)

```bash
pip install synapkit
```

