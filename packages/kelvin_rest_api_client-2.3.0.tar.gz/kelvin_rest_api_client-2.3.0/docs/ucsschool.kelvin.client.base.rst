ucsschool.kelvin.client.base module
===================================

.. automodule:: ucsschool.kelvin.client.base
   :members:
   :undoc-members:
   :show-inheritance:
