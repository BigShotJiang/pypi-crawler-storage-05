ucsschool namespace
===================

.. py:module:: ucsschool
