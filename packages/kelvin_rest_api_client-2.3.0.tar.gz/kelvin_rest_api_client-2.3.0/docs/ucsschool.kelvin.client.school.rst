ucsschool.kelvin.client.school module
=====================================

.. automodule:: ucsschool.kelvin.client.school
   :members:
   :undoc-members:
   :show-inheritance:
