ucsschool.kelvin.client.workgroup module
========================================

.. automodule:: ucsschool.kelvin.client.workgroup
   :members:
   :undoc-members:
   :show-inheritance:
