ucsschool.kelvin.client.session module
======================================

.. automodule:: ucsschool.kelvin.client.session
   :members:
   :undoc-members:
   :show-inheritance:
