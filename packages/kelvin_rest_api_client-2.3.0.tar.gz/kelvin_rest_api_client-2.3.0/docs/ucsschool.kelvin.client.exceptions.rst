ucsschool.kelvin.client.exceptions module
=========================================

.. automodule:: ucsschool.kelvin.client.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
