ucsschool.kelvin namespace
==========================

.. py:module:: ucsschool.kelvin

Subpackages
-----------

.. toctree::
   :maxdepth: 6

   ucsschool.kelvin.client
