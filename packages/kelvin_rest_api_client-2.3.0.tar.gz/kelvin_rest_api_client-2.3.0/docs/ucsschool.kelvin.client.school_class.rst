ucsschool.kelvin.client.school\_class module
============================================

.. automodule:: ucsschool.kelvin.client.school_class
   :members:
   :undoc-members:
   :show-inheritance:
