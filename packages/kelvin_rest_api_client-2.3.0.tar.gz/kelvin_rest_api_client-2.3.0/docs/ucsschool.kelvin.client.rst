ucsschool.kelvin.client package
===============================

Submodules
----------

.. toctree::
   :maxdepth: 6

   ucsschool.kelvin.client.base
   ucsschool.kelvin.client.exceptions
   ucsschool.kelvin.client.role
   ucsschool.kelvin.client.school
   ucsschool.kelvin.client.school_class
   ucsschool.kelvin.client.session
   ucsschool.kelvin.client.user
   ucsschool.kelvin.client.workgroup

Module contents
---------------

.. automodule:: ucsschool.kelvin.client
   :members:
   :undoc-members:
   :show-inheritance:
