Welcome to Python UCS\@school Kelvin REST API Client's documentation!
=====================================================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   readme
   installation
   usage
   ucsschool.kelvin.client
   contributing
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
