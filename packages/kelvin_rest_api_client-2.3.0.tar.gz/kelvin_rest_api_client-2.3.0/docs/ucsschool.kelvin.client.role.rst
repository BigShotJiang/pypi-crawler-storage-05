ucsschool.kelvin.client.role module
===================================

.. automodule:: ucsschool.kelvin.client.role
   :members:
   :undoc-members:
   :show-inheritance:
