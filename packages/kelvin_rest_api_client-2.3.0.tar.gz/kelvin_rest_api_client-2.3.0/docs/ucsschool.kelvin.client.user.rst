ucsschool.kelvin.client.user module
===================================

.. automodule:: ucsschool.kelvin.client.user
   :members:
   :undoc-members:
   :show-inheritance:
