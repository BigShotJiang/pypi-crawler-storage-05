Destral testing library
=======================

A library to do tests with our OpenERP Server (v5)

.. image:: https://travis-ci.org/gisce/destral.svg?branch=master
    :target: https://travis-ci.org/gisce/destral

.. image:: https://badge.fury.io/py/destral.svg
    :target: https://badge.fury.io/py/destral

.. note::
  The API is not stable, and can be changed.

.. epigraph::

   Code as if the next guy to maintain your code is a homicidal maniac who knows where you live.

   -- Kathy Sierra and Bert Bates
