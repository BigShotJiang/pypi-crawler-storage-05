# import sys
# print(sys.path)
# import sys
# sys.path.append('/Users/tangtang/opt/anaconda3/lib/python3.9/site-packages')
import AnChinSegmenter
AnChinSegmenter.main(input_path='./data/sample_data.txt',output_path='./data/sample_data_out.txt')