2025-03-31 Version: 2.0.23
- Update API GetTaskInfo: add response parameters Body.Data.Result.ContentExtraction.
- Update API GetTaskInfo: add response parameters Body.Data.Result.IdentityRecognition.


2025-03-31 Version: 2.0.22
- Update API CreateTask: add request parameters body.Parameters.IdentityRecognition.
- Update API CreateTask: add request parameters body.Parameters.IdentityRecognitionEnabled.
- Update API CreateTask: add request parameters body.Parameters.ContentExtraction.ExtractionContents.$.Identity.


2025-03-12 Version: 2.0.21
- Update API DeleteTranscriptionPhrases: update response param.


2025-03-03 Version: 2.0.20
- Update API CreateTask: update param body.


2025-02-05 Version: 2.0.19
- Update API CreateTask: update param body.


2024-11-22 Version: 2.0.18
- Update API CreateTask: update param body.


2024-09-10 Version: 2.0.17
- Update API CreateTask: update param body.


2024-08-15 Version: 2.0.16
- Update API GetTaskInfo: update response param.


2024-07-29 Version: 2.0.15
- Update API CreateTask: update param body.


2024-06-21 Version: 2.0.14
- Generated python 2023-09-30 for tingwu.

2024-06-21 Version: 2.0.13
- Update API CreateTask: update param body.


2024-06-14 Version: 2.0.12
- Update API CreateTask: update param body.


2024-05-21 Version: 2.0.11
- Update API CreateTask: update param body.


2024-05-20 Version: 2.0.10
- Update API CreateTask: update param body.


2024-05-15 Version: 2.0.9
- Update API CreateTask: update param body.


2024-04-12 Version: 2.0.8
- Update API GetTaskInfo: update response param.


2024-04-10 Version: 2.0.7
- Update API GetTaskInfo: update response param.


2024-03-18 Version: 2.0.6
- Update API CreateTask: update param body.
- Update API CreateTask: update response param.


2024-03-15 Version: 2.0.5
- Update API CreateTask: update param body.


2024-03-12 Version: 2.0.4
- Update API CreateTask: update response param.
- Update API GetTaskInfo: update response param.


2024-02-23 Version: 2.0.3
- Update API GetTaskInfo: update response param.


2024-01-08 Version: 2.0.2
- Generated python 2023-09-30 for tingwu.

2023-12-25 Version: 2.0.1
- Generated python 2023-09-30 for tingwu.

2023-12-20 Version: 2.0.0
- Generated python 2023-09-30 for tingwu.

2023-12-19 Version: 1.1.2
- Generated python 2023-09-30 for tingwu.

2023-12-18 Version: 1.1.1
- Generated python 2023-09-30 for tingwu.

2023-12-12 Version: 1.1.0
- Generated python 2023-09-30 for tingwu.

2023-12-01 Version: 1.0.1
- Generated python 2023-09-30 for tingwu.

2023-11-03 Version: 1.0.0
- Generated python 2023-09-30 for tingwu.

