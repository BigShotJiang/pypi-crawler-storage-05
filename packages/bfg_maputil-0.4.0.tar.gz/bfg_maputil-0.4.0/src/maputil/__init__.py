from .map2 import Run, map2

__all__ = ["map2", "Run"]
