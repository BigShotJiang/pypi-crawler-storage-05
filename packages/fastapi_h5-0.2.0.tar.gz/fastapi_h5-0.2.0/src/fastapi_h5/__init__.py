from fastapi_h5.h5routes import router

__all__ = ["router"]
