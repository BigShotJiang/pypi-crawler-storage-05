==========  =========  =========  =========  =========  =========
Parallel    Minimum    Maximum    Average    Median     Speed
==========  =========  =========  =========  =========  =========
1 chunk     0.29 sec.  0.45 sec.  0.33 sec.  0.32 sec.  1.6 MiB/s
2 chunks    0.20 sec.  0.34 sec.  0.23 sec.  0.22 sec.  2.3 MiB/s
3 chunks    0.19 sec.  0.26 sec.  0.21 sec.  0.21 sec.  2.4 MiB/s
4 chunks    0.14 sec.  0.17 sec.  0.16 sec.  0.16 sec.  3.1 MiB/s
5 chunks    0.13 sec.  0.17 sec.  0.15 sec.  0.15 sec.  3.4 MiB/s
6 chunks    0.13 sec.  0.20 sec.  0.16 sec.  0.16 sec.  3.2 MiB/s
7 chunks    0.14 sec.  0.20 sec.  0.17 sec.  0.17 sec.  3.0 MiB/s
8 chunks    0.14 sec.  0.28 sec.  0.17 sec.  0.16 sec.  3.1 MiB/s
9 chunks    0.14 sec.  0.16 sec.  0.14 sec.  0.14 sec.  3.5 MiB/s
10 chunks   0.15 sec.  0.17 sec.  0.16 sec.  0.16 sec.  3.2 MiB/s
==========  =========  =========  =========  =========  =========

* **Minimum time:** 0.13 sec. (3.7 MiB/s)
* **Maximum time:** 0.45 sec. (1.1 MiB/s)
* **Average time:** 0.19 sec. (2.7 MiB/s)
* **Median time:** 0.16 sec. (3.1 MiB/s)
