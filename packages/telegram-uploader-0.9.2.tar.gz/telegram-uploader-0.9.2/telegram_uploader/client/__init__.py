from telegram_uploader.client.telegram_manager_client import TelegramManagerClient, get_message_file_attribute


__all__ = ["TelegramManagerClient", "get_message_file_attribute"]
