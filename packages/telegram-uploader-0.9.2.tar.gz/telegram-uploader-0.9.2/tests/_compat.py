try:
    from mock import patch
except ImportError:
    from unittest.mock import patch
