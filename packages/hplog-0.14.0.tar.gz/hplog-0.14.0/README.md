# HPLOG

## About HPLOG

HPLOG (short for High Performance Logging) enables the user to log their pydantic models in a mongo DB.

> Info
> This project is a small library which is designed for exactly what it says. It is used for logging Pydantic models. In case you have questions about the library or anything else, feel free to contact me

