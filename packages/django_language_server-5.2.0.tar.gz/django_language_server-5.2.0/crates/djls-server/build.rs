fn main() {
    djls_dev::setup_python_linking();
}
