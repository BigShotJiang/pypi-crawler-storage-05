def main():
    print("Hello from secure-token CLI!")
