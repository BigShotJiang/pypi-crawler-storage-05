# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

from .target import BedrockKnowledgeBaseTarget

__all__ = ["BedrockKnowledgeBaseTarget"]
