"""A basic logger to have around just in case the user doesn't already have one."""

from .logger import BasicLogger

__all__ = ["BasicLogger"]
