"""A module with all of the loggers used in the logger manager."""
