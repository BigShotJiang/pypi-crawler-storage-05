# SPDX-License-Identifer: Apache-2.0
version = (1, 6, 2)
VERSION = "%d.%d.%d" % version
