# SPDX-License-Identifer: Apache-2.0
from .client import Client  # noqa: F401
import io4edge_client.api.digiwave.python.digiwave.v1.digiwave_pb2 as Pb  # noqa: F401
