import os
CWD = os.getcwd()
from hokusai.lib import representers
from hokusai.commands import *
