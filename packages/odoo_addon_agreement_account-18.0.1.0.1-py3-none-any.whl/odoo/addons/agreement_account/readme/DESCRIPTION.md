This module adds *Agreement* field on invoices.
