# koba
Terminal Image Renderer, made in Python.
