=========
NestedDtype
=========
.. currentmodule:: nested_pandas

Constructor
~~~~~~~~~~~
.. autosummary::
   :toctree: api/

   NestedDtype

Functions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. autosummary::
    :toctree: api/

    NestedDtype.construct_array_type
    NestedDtype.construct_from_string
    NestedDtype.from_fields
    NestedDtype.from_pandas_arrow_dtype
    NestedDtype.to_pandas_arrow_dtype