=========
Packer
=========
.. currentmodule:: nested_pandas

Functions
~~~~~~~~~
.. autosummary::
    :toctree: api/
    
    series.packer.pack
    series.packer.pack_flat
    series.packer.pack_seq
    series.packer.pack_lists