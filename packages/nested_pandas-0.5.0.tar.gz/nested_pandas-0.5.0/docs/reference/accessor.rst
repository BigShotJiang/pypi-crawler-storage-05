=========
.nest Series Accessor
=========
.. currentmodule:: nested_pandas

Constructor
~~~~~~~~~~~
.. autosummary::
   :toctree: api/

   NestSeriesAccessor

Functions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. autosummary::
    :toctree: api/

    NestSeriesAccessor.to_lists
    NestSeriesAccessor.to_flat
    NestSeriesAccessor.to_flatten_inner
    NestSeriesAccessor.with_field
    NestSeriesAccessor.with_flat_field
    NestSeriesAccessor.with_list_field
    NestSeriesAccessor.with_filled_field
    NestSeriesAccessor.without_field
    NestSeriesAccessor.query_flat
    NestSeriesAccessor.get_flat_index
    NestSeriesAccessor.get_flat_series
    NestSeriesAccessor.get_list_series
