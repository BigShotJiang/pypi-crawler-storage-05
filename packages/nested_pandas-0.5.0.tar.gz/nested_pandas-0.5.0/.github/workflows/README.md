# Workflows

The .yml files in this directory are used to define the various continuous
integration scripts that will be run on your behalf e.g. nightly as a smoke check,
or when you create a new PR.

For more information about CI and workflows, look here: https://lincc-ppt.readthedocs.io/en/latest/practices/ci.html

Or if you still have questions contact us: https://lincc-ppt.readthedocs.io/en/latest/source/contact.html