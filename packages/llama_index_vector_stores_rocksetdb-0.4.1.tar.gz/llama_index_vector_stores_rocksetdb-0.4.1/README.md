# LlamaIndex Vector_Stores Integration: Rocksetdb
