"""
Operations package for function-based CLI operations.
"""
