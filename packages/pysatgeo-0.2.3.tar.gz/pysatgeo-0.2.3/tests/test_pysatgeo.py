#!/usr/bin/env python

"""Tests for `pysatgeo` package."""


import unittest

from pysatgeo import pysatgeo


class TestPysatgeo(unittest.TestCase):
    """Tests for `pysatgeo` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
