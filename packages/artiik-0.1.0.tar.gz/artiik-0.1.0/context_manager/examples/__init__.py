"""
Example implementations for ContextManager.
"""

from .agent_example import SimpleAgent

__all__ = ["SimpleAgent"] 