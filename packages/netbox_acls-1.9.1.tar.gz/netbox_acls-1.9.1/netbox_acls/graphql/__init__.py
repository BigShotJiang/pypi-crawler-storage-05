from .schema import NetBoxACLSQuery

schema = [NetBoxACLSQuery]
