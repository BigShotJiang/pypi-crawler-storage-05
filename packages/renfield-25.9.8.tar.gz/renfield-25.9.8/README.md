# renfield

## Danger

- There is currently no need to look at this.
- No need to download this.
- Certainly do not run this.

This will be the Not1MM contest data aggregation server.

Currently it is just just a bunch of sadness.

## Recent Changes

- [Epoch] And then there was light.

## Web interface

### Run latest from pypi

> textual serve "uvx renfield@latest"

### Run from the source tree

> textual serve \_\_main\_\_.py
