# motorcortex-python

## Installation

You can conveniently install motorcortex-python with pip:

`pip3 install motorcortex-python`

or if you want to install it system-wide:

`sudo pip3 install motorcortex-python`