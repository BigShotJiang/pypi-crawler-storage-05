# SPDX-License-Identifier: MPL-2.0
"""Test package with both module/dist and version mismatch."""

from __future__ import annotations

__version__ = "1.1.post0.dev0"
