# SPDX-License-Identifier: MPL-2.0
"""Test package in a namespace."""
