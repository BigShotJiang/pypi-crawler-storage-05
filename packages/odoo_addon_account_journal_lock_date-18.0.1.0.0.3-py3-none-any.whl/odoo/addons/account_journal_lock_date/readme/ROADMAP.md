- the module does not check that all moves prior the lock date are
  posted, this could be made as part of the wizard
