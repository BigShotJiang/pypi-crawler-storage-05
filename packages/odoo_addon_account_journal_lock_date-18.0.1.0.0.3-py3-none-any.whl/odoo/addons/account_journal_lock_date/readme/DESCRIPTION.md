Lock each accounting journal independently.

In addition to the lock dates provided by standard Odoo, this module
provides a 'Lock Date' and a 'Lock Date for Non-Advisers' per journal.

This module also adds a wizard that allows you to update the 'Lock Date'
and the 'Lock Date for Non-Advisers' for several Journals at the same
time.
