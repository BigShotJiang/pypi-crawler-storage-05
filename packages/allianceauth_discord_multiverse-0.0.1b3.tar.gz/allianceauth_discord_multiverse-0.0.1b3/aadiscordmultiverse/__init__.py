"""
Service module for managing an unlimited number of discord servers from a single auth instance. It can run side by side with the core auth discord service, or completely standalone.
"""
__version__ = "0.0.1b3"
__branch__ = "beta"
__title__ = "Discord Multiverse"
