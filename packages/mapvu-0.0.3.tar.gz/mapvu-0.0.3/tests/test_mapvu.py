#!/usr/bin/env python

"""Tests for `mapvu` package."""


import unittest

from mapvu import mapvu


class TestMapvu(unittest.TestCase):
    """Tests for `mapvu` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
