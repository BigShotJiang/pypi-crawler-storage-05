"""Detector implementations"""
