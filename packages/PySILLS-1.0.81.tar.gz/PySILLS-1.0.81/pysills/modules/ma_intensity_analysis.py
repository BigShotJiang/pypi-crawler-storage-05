#!/usr/bin/env python
# -*-coding: utf-8 -*-

#-----------------------------------------------

# Name:		ma_intensity_analysis.py
# Author:	Maximilian A. Beeskow
# Version:	1.0
# Date:		18.07.2023

#-----------------------------------------------

## MODULES
import numpy as np

## MINERAL ANALYSIS - INTENSITY ANALYSIS
class MineralAnalysisIntensityAnalysis:
    def __init__(self):
        pass
