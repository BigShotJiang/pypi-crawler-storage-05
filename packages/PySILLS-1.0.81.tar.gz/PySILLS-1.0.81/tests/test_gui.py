#!/usr/bin/env python
# -*-coding: utf-8 -*-
# ----------------------
# gui.py
# Maximilian Beeskow
# 01.06.2021
# ----------------------
#
# MODULES
from modules.gui import main

# TEST
if __name__ == "__main__":
    main()
