"""Resolvers for template and derived field processing."""
