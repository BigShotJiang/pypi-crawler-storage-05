"""Utility functions for model operations."""
