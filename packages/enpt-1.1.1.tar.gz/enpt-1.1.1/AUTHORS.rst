=======
Credits
=======

Development Lead
----------------

Karl Segl <segl@gfz.de>

Contributors
------------

* Daniel Scheffler <danschef@gfz.de>
  (main developer of the EnPT source code)
* Niklas Bohn <nbohn@gfz.de>
  (main developer of the SICOR atmospheric correction source code)
* André Hollstein
* Stéphane Guillaso
* Brenner Silva
* Leonardo Alvarado
