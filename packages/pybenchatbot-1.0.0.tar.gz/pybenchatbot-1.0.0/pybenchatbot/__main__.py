from .botserver import main
main()