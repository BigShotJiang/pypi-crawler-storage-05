"""
Test package for LogMCP server

This package contains unit tests for all components of the LogMCP server.
"""
