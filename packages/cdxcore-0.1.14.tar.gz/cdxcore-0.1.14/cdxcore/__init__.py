# -*- coding: utf-8 -*-
"""
Created on June 2022
@author: hansb
"""

__version__ = "0.1.14"  # auto-updated by setup.py
