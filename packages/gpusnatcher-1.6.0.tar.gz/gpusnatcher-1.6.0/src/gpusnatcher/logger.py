from rich.console import Console
from rich.prompt import Prompt

console = Console()
prompt = Prompt()
