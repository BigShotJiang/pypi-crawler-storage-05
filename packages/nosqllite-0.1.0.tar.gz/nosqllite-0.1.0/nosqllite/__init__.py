from nosqllite.database import Database
from nosqllite.document import Document


__version__ = "0.1.0"
__author__ = "Axel Gard"
