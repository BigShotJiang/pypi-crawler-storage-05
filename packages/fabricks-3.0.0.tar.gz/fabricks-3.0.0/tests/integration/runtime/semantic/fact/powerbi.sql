select `__key`, id as `Monarch_ID`, monarch as `Monarch` from gold.scd1_complete
