select * except (__key, __timestamp, __metadata, __hash) from silver.princess_schema_drift__current
