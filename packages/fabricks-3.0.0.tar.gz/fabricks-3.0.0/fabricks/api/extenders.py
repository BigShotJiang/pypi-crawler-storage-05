from fabricks.core.extenders import extender

__all__ = ["extender"]
