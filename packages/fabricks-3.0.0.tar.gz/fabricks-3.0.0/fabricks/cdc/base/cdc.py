from fabricks.cdc.base.merger import Merger


class BaseCDC(Merger):
    pass
