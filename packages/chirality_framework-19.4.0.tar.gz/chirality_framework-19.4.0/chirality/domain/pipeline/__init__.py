"""Pipeline domain logic for the Chirality Framework."""
