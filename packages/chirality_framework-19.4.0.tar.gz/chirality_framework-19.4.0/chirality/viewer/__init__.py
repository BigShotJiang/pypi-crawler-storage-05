# Viewer module for rendering matrix snapshots
