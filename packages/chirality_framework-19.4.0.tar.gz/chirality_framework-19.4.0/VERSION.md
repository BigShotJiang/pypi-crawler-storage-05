19.4.0 — See full history in CHANGELOG.md
