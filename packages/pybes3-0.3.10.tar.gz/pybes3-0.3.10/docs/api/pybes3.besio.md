!!! warning "Rare Help for Users"
    There is **rare help** for users in this page. It is recommended to see [BESIII Data Reading](../user-manual/bes3-data-reading.md).

::: pybes3.besio

::: pybes3.besio.root_io

::: pybes3.besio.raw_io
