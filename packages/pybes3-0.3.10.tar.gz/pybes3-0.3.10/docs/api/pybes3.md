## besio
::: pybes3.wrap_uproot
---
::: pybes3.open
---
::: pybes3.concatenate
---
::: pybes3.open_raw
---
::: pybes3.concatenate_raw
---

## detectors
::: pybes3.parse_cgem_digi_id
---
::: pybes3.parse_mdc_gid
---
::: pybes3.parse_mdc_digi
---
::: pybes3.parse_mdc_digi_id
---
::: pybes3.parse_tof_digi_id
---
::: pybes3.parse_emc_digi_id
---
::: pybes3.parse_muc_digi_id
---

## tracks
::: pybes3.parse_helix
---