"""
@author: F. Ramognino       <federico.ramognino@polimi.it>
Last update:        12/06/2023

Database for reactions
"""

from libICEpost.Database import database

database.chemistry.addFolder("reactions")