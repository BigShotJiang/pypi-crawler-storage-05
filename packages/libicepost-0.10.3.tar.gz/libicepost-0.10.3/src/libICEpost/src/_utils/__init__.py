"""
Here are stored source of external packages on which the library is dependent.

Content of the module:
    - `PyFoam` (module): This is a modified version of the PyFoam library, which holds some fixes to work also on Windows operating system (within the boundaries of `libICEpost` applications)
"""
