#  ICE Revision: $Id$ 
""" Manipulating the data files

Classes that manipulate the parameter and the solution files in the
data dictionary used by the OpenFOAM applications
"""
