""" ThirdParty-Packages

Packages that were included to keep the PyFoam installation self-contained
"""
