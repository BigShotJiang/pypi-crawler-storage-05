#  ICE Revision: $Id$
""" RuntimeHook-Classes

Classes that can be executed before or after the running of the solver
"""
