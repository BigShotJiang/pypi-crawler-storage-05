"""
@author: F. Ramognino       <federico.ramognino@polimi.it>
Last update:        9/03/2023

...
"""

from .LaminarFlameSpeedModel import LaminarFlameSpeedModel
from .TabulatedLFS import TabulatedLFS