"""
@author: F. Ramognino       <federico.ramognino@polimi.it>
Last update:        19/06/2023

Tables used to store data from postprocessing of engine models.

Content of the package
    ...
"""
