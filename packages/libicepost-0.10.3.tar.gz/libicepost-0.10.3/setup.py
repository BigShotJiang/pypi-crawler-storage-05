from setuptools import setup

# setup(
#    name='libICEpost',
#    version='0.0.1',
#    description='Postprocessing of data sampled from internal combustion engines (Experimental, 1D/0D (Gasdyn), 3D (LibICE), etc.)',
#    author='Federico Ramognino',
#    author_email='federico.ramognino@polimi.it',
#    packages=['src'],  #same as name
#    install_requires=[], #external packages as dependencies
#    scripts=[]
# )

if __name__ == "__main__":
   setup()