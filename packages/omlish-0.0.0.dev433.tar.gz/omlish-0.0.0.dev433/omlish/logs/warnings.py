# @omlish-lite


##


class LoggingSetupWarning(Warning):
    pass
