"""SimpleTuner - Stable Diffusion 2.x and XL tuner."""

__version__ = "2.2.0"
