class MultiDatasetExhausted(Exception):
    pass
