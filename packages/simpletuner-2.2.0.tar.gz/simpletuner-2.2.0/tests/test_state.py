import unittest
from simpletuner.helpers.multiaspect.state import BucketStateManager


class TestBucketStateManager(unittest.TestCase):
    def setUp(self):
        pass  # TODO: Add setup code if needed

    def test_example(self):
        # TODO: Write test cases
        self.assertEqual(True, True)


if __name__ == "__main__":
    unittest.main()
