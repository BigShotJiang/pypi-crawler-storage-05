{{ module }}.{{ objname }}
{{ underline }}===========

.. autoclass:: {{ module }}.{{ objname }}
   :members:
   :undoc-members:
   :inherited-members:
