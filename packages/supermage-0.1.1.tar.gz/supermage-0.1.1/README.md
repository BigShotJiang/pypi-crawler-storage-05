[![CI](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://github.com/mjyb16/supermage/blob/master/SuperMAGE%20logo_text.svg" width="70%" height="70%">
  <source media="(prefers-color-scheme: light)" srcset="https://github.com/mjyb16/supermage/blob/master/SuperMAGE%20logo_text.svg" width="70%" height="70%">
  <img alt="SuperMAGE logo" src="https://github.com/mjyb16/supermage/blob/master/SuperMAGE%20logo_text.svg" width="70%">
</picture>

# supermage
SuperMAGE: **Super**massive black hole **ma**sses from **g**as kin**e**matics


NOTE: Active development. Non-functioning and untested code may occur. For notebooks, see other repo.
