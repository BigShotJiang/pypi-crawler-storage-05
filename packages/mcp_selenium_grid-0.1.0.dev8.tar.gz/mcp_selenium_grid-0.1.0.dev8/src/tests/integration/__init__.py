"""Integration tests for MCP Server components."""
