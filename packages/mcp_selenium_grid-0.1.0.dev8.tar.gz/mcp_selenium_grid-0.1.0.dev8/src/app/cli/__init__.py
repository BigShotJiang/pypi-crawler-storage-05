from .main import app as mcp_selenium_grid_cli

__all__ = ["mcp_selenium_grid_cli"]
