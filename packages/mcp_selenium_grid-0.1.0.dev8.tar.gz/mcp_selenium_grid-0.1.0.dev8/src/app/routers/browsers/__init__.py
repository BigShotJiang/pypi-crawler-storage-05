"""Browser management package for MCP Server."""

from app.routers.browsers.routes import router

__all__ = ["router"]
