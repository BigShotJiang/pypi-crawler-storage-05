import time, uuid
from IPython.display import display, HTML, Javascript
import ipywidgets as widgets

class iPgs:
    _hidden_out = None
    _main_instance = None

    def __init__(self, iterable, total=None, desc="", nested=False):
        self.iterable = iterable
        self.total = total if total is not None else len(iterable)
        self.desc = desc
        self.nested = nested
        self.start_time = None
        self.count = 0

        if iPgs._hidden_out is None:
            iPgs._hidden_out = widgets.Output(layout=widgets.Layout(display='none'))
            display(iPgs._hidden_out)

        # ids یکتا
        self.bar_id = f"bar_{uuid.uuid4().hex}"
        self.text_id = f"text_{uuid.uuid4().hex}"
        self.eta_id = f"eta_{uuid.uuid4().hex}"

        # HTML با استایل ETA زیبا
        html = f"""
        <div style="width:560px; font-family:'Segoe UI',Tahoma,Arial; margin:10px 0;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
            <strong style="font-size:14px">{self.desc}</strong>
            <span id="{self.text_id}" style="font-size:13px; color:#222">0/{self.total} (0.0%)</span>
          </div>
          <div style="height:14px; background:#eee; border-radius:999px; overflow:hidden; border:1px solid #ddd;">
            <div id="{self.bar_id}" style="
                height:100%;
                width:0%;
                background:linear-gradient(90deg,#0072ff,#00c6ff);
                border-radius:999px;
                transition: width 0.45s cubic-bezier(0.22,0.9,0.35,1);
                display:flex; align-items:center; justify-content:center;
                color:white; font-size:11px;">
              <span style="padding:0 6px; white-space:nowrap;">0.0%</span>
            </div>
          </div>
          <div style="margin-top:6px; display:flex; justify-content:flex-end;">
            <span id="{self.eta_id}" style="
                font-size:12px;
                background:#f8f9fa;
                border:1px solid #ddd;
                border-radius:6px;
                padding:2px 8px;
                color:#333;
                box-shadow:0 1px 2px rgba(0,0,0,0.1);
                font-family:'Consolas','Courier New',monospace;">
              ETA: --:--
            </span>
          </div>
        </div>
        """
        display(HTML(html))

        if not nested:
            iPgs._main_instance = self

    def __iter__(self):
        self.start_time = time.time()
        for item in self.iterable:
            yield item
            self.update()
        self.close()

    def update(self, n=1):
        self.count += n
        percent = (self.count / self.total) * 100
        elapsed = time.time() - self.start_time
        rate = self.count / elapsed if elapsed > 0 else 0
        remaining = (self.total - self.count) / rate if rate > 0 else 0

        m, s = divmod(int(remaining), 60)
        eta_str = f"{m:02d}:{s:02d}"

        # تشخیص Epoch یا Batch
        tag = "Epoch" if not self.nested else "Batch"

        js = f"""
        (function(){{
            var b = document.getElementById('{self.bar_id}');
            var t = document.getElementById('{self.text_id}');
            var e = document.getElementById('{self.eta_id}');
            if(b) {{
                b.style.width = '{percent:.2f}%';
                var inner = b.querySelector('span');
                if(inner) inner.textContent = '{percent:.1f}%';
            }}
            if(t) t.textContent = '{tag} {self.count}/{self.total} ({percent:.1f}%)';
            if(e) e.textContent = '{tag} ETA: {eta_str}';
        }})();
        """
        with iPgs._hidden_out:
            display(Javascript(js))

    def close(self):
        js = f"""
        (function(){{
            var b = document.getElementById('{self.bar_id}');
            var t = document.getElementById('{self.text_id}');
            var e = document.getElementById('{self.eta_id}');
            if(b) {{
                b.style.width = '100%';
                b.style.background = '#2e7d32';
                var inner = b.querySelector('span');
                if(inner) inner.textContent = '100%';
            }}
            if(t) t.textContent = '✅ {self.desc} Processed..!';
            if(e) e.textContent = 'Elapsed ✔';
        }})();
        """
        with iPgs._hidden_out:
            display(Javascript(js))
