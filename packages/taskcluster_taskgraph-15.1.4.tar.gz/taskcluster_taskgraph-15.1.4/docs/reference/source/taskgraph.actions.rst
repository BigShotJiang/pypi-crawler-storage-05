taskgraph.actions package
=========================

Submodules
----------

taskgraph.actions.add\_new\_jobs module
---------------------------------------

.. automodule:: taskgraph.actions.add_new_jobs
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.actions.cancel module
-------------------------------

.. automodule:: taskgraph.actions.cancel
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.actions.cancel\_all module
------------------------------------

.. automodule:: taskgraph.actions.cancel_all
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.actions.registry module
---------------------------------

.. automodule:: taskgraph.actions.registry
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.actions.retrigger module
----------------------------------

.. automodule:: taskgraph.actions.retrigger
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.actions.util module
-----------------------------

.. automodule:: taskgraph.actions.util
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: taskgraph.actions
   :members:
   :undoc-members:
   :show-inheritance:
