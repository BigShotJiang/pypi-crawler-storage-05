taskgraph.transforms package
============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   taskgraph.transforms.run

Submodules
----------

taskgraph.transforms.base module
--------------------------------

.. automodule:: taskgraph.transforms.base
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.transforms.from\_deps module
--------------------------------------

.. automodule:: taskgraph.transforms.from_deps
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.transforms.cached\_tasks module
-----------------------------------------

.. automodule:: taskgraph.transforms.cached_tasks
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.transforms.chunking module
------------------------------------

.. automodule:: taskgraph.transforms.chunking
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.transforms.code\_review module
----------------------------------------

.. automodule:: taskgraph.transforms.code_review
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.transforms.docker\_image module
-----------------------------------------

.. automodule:: taskgraph.transforms.docker_image
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.transforms.fetch module
---------------------------------

.. automodule:: taskgraph.transforms.fetch
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.transforms.matrix module
----------------------------------

.. automodule:: taskgraph.transforms.matrix
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.transforms.notify module
----------------------------------

.. automodule:: taskgraph.transforms.notify
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.transforms.task module
--------------------------------

.. automodule:: taskgraph.transforms.task
   :members:
   :undoc-members:
   :show-inheritance:

taskgraph.transforms.task_context module
----------------------------------------

.. automodule:: taskgraph.transforms.task_context
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: taskgraph.transforms
   :members:
   :undoc-members:
   :show-inheritance:
