"""
The `GridPath RA Toolkit <https://gridlab.org/gridpathratoolkit/>`__
datasets were developed to support the 2026 Western US case resource
adequacy study.
"""
