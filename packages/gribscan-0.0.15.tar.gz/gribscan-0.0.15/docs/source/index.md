# Welcome to gribscan's documentation!

```{toctree}
:caption: 'Contents:'
:maxdepth: 2

getting_started
magician
```

# Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
