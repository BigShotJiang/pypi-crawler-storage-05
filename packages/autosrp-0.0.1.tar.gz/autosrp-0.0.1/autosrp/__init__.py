"""Initialize the app"""

__version__ = "0.0.1"
__title__ = "AA Auto SRP"
