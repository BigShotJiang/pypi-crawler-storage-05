from setuptools import setup, find_packages

setup(
    name = 'pyquarks',
    version = '0.0.0.2',
    packages = find_packages(),
    install_requires = [],
    author = 'Prospy006',
    description = "Delivering small additions which matter",
    url = 'https://github.com/Prospy006/pyquarks'
)