
# I didn't include no class linked lists as they're a pain in the ass to fix up for one purpose.

# from .linked_lists import linked_lists
from .linked_lists_OOP import LinkedList

__all__ = ["LinkedList"]