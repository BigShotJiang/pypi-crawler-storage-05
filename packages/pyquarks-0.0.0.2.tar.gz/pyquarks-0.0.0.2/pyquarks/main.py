# This file can be used for testing purposes and such.
from pyquarks.binary_trees import BinaryTree

something = BinaryTree()

something.insert(4)
something.insert(5)
something.insert(3)
something.insert(2)
something.insert(6)

something.visualize()