from .queues import queues
from .queues_OOP import queues_OOP

__all__ = ["queues", "queues_OOP"]