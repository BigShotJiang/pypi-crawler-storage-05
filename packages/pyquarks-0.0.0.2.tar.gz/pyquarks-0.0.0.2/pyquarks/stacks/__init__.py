from .stacks import stacks
from .stacks_OOP import stacks_OOP

__all__ = ["stacks", "stacks_OOP"]