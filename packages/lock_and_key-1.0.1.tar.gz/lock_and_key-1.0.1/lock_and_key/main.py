#!/usr/bin/env python3
"""Entry point for Lock & Key CLI."""

from lock_and_key.cli import cli

if __name__ == "__main__":
    cli()
