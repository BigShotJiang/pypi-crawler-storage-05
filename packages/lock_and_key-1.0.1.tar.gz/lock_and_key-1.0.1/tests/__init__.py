# SPDX-FileCopyrightText: 2025-present WinterShadow <wolf@cyberwolf.dev>
#
# SPDX-License-Identifier: MIT
