LOCATION_RESPONSE = {
    '1': 'CPRACES - Câmara de prevenção e resolução administrativa de conflitos do ES - 7º andar', 
    '80': 'PGE - ES', 
    '2': 36, 
    '14': 'CPRACES - Câmara de prevenção e resolução administrativa de conflitos do ES - 7º andar'
}

LOCATIONS_RESPONSE = {
    'totalcount': 4, 
    'count': 4, 
    'sort': [1], 
    'order': ['ASC'], 
    'data': [
        {
            '1': 'CPRACES - Câmara de prevenção e resolução administrativa de conflitos do ES - 7º andar', 
            '80': 'PGE - ES', 
            '2': 36, 
            '14': 'CPRACES - Câmara de prevenção e resolução administrativa de conflitos do ES - 7º andar'
        }, 
        {
            '1': 'DÍVIDA ATIVA - 10º andar', 
            '80': 'PGE - ES', 
            '2': 60, 
            '14': 'DÍVIDA ATIVA - 10º andar'
        }, 
        {
            '1': 'PCA - Procuradoria de Consultoria Administrativa - 12º andar', 
            '80': 'PGE - ES', 
            '2': 8, 
            '14': 'PCA - Procuradoria de Consultoria Administrativa - 12º andar'
        }, 
        {
            '1': 'PFI - Procuradoria Fiscal - 10º andar > DÍVIDA ATIVA - 10º andar', 
            '80': 'PGE - ES', 
            '2': 39, 
            '14': 'DÍVIDA ATIVA - 10º andar'
        }
    ], 
    'content-range': '0-3/4'
}