# DO NOT EDIT
# Generated from .copier-answers.yml

from sleamdge import main

main()
