from .beacon import send_beacon  # triggers on import
