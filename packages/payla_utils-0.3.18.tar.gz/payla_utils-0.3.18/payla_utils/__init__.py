import importlib.metadata

__author__ = """Payla Services GmbH"""
__email__ = "tools@payla.de"
__version__ = importlib.metadata.version("payla_utils")
