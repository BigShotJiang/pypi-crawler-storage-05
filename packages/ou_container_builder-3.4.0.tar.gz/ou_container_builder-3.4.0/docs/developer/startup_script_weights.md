# Startup Script Weights

1. 0 - 100: Reserved: System
2. 101 - 200: Known: Packs
3. 201 - 1000: Free
