# `ou_container_builder.packs.notebook`

```{eval-rst}
.. automodule:: ou_container_builder.packs.notebook
   :members:
```
