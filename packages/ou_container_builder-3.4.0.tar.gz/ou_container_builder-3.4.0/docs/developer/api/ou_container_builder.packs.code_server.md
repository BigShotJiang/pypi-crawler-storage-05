# `ou_container_builder.packs.code_server`

```{eval-rst}
.. automodule:: ou_container_builder.packs.code_server
   :members:
```
