# Paths

/usr/share/ou - Main folder for static data
/usr/share/ou/python/system - Python system packages
/usr/share/ou/python/user - Python user packages
/usr/share/ou/startup.d - Scripts to run at startup

/var/lib/ou/python/system - Python runtime system venv
