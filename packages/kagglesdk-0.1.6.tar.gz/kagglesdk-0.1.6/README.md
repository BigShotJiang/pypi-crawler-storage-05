# Kagglesdk

Basic python bindings for Kaggle's external-facing endpoints.

These are automatically-generated, so external contributor PRs will only be accepted on documentation. Please feel free to file issues in this repository.
