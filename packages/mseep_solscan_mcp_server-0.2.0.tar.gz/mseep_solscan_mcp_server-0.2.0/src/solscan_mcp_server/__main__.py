# __main__.py

from solscan_mcp_server import main

main()
