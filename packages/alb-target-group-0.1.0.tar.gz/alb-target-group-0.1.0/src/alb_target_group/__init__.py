"""Target Group CDK Construct Package."""
from .alb_target_group_stack import TargetGroupStack
__version__ = "0.1.0"
__all__ = ["TargetGroupStack"]