"""Integration tests for Forklift application."""
