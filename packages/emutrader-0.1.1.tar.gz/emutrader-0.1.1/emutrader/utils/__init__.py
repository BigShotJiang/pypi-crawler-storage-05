"""
Utility functions and helper classes.

This package contains data providers, technical indicators,
and performance analysis tools.
"""