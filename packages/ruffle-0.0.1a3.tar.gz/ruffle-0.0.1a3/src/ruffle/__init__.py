from ruffle import setup

setup.env_vars()
setup.logging()


def main() -> None:
    print("Hello from Ruffle! ⛈️")
