"""
This file is used to import all the models in the package.
"""

from . import state_talk2knowledgegraphs
