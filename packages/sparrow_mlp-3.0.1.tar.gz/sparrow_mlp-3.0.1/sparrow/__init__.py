# sparrow/__init__.py

from .models import DynamicMLP
from .config import SparrowConfig

print("Sparrow Dynamic Architecture Library Loaded 🐦")