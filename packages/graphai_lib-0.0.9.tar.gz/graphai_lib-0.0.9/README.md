# Philosophy

1. Async-first
2. Minimize abstractions
3. One way to do one thing
4. Graph-based AI

## Installation

```
pip install -qU graphai-lib
```