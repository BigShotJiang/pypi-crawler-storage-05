# imj

Python client for [i.marcusj.tech](https://i.marcusj.tech)