from .paginator import Paginator

__all__ = ["Paginator"]
