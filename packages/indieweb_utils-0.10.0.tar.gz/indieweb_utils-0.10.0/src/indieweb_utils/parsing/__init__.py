from .parse import get_soup

__all__ = ["get_soup"]
