from .resize import reduce_image_size

__all__ = [
    "reduce_image_size",
]
