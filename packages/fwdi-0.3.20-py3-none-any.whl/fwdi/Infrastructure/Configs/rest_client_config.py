
class RestClientConfig():
    def __init__(self) -> None:
        self.server:str
        self.port:int
        self.security_layer:bool
        self.username:str
        self.password:str